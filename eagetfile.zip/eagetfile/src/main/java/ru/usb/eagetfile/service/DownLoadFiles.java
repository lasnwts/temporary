package ru.usb.eagetfile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;
import ru.usb.eagetfile.configs.Configure;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

@Service
public class DownLoadFiles {

    //Путь http
    String url;

    File file;

    @Autowired
    Configure configure;

    @Autowired
    RestTemplate restTemplate;

    public File downLoadBigFile(String urlPath, String targetPath, String fileName) {

        HttpHeaders headers = new HttpHeaders();
//        headers.setBasicAuth(configure.getMtsLogin(), configure.getMtsPassword());
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));

        // create url
        url = urlPath;

        // Определяем тип получения заголовка запроса
        RequestCallback requestCallback = request -> request.getHeaders().putAll(headers);

        //Stream the response instead of loading it all into memory
        file = restTemplate.execute(url, HttpMethod.GET, requestCallback, clientHttpResponse -> {
            Files.copy(clientHttpResponse.getBody(), Paths.get(targetPath + FileSystems.getDefault().getSeparator() + fileName), StandardCopyOption.REPLACE_EXISTING);
            File f = new File(targetPath + FileSystems.getDefault().getSeparator() + fileName);
            if (f.exists()) {
                return f;
            } else {
                return null;
            }
        });
        return file;
    }
}


