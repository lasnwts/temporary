package ru.usb.eagetfile.configs;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;

@Configuration
public class ConfigRestTemplate {

    Logger logger = LoggerFactory.getLogger(ConfigRestTemplate.class);

    @Value("${http.client.ssl.trust-store}")
    private String trustStore;
    @Value("${http.client.ssl.trust-store-password}")
    private String trustStorePassword;

    Path path;
    File jksStore;


    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

        path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() + trustStore);
        if (Files.exists(path)) {
            // действия, если файл существует
            logger.info("File :: {}::exist.Ok.", path.toString());
        } else {
            logger.error("File :: {}:: not found!!.Fail.", path.toString());
        }
        jksStore = path.toFile();


        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
        SSLContext sslContext = new SSLContextBuilder()
                .loadTrustMaterial(jksStore, trustStorePassword.toCharArray(), acceptingTrustStrategy)
                .build();
        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

        HttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(socketFactory)
                .build();

        extracted();

        return builder
                .requestFactory(() -> new HttpComponentsClientHttpRequestFactory(httpClient))
                .setConnectTimeout(Duration.ofMillis(12000))
                .setReadTimeout(Duration.ofMillis(16000))
                .build();
    }

    private void extracted() {
        System.setProperty("javax.net.ssl.trustStore", jksStore.getAbsolutePath());
        System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
        logger.info("выполнена регистрация SSL {} сертификата в системе", jksStore.getAbsolutePath());
    }

}
