package ru.usb.eagetfile.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.eagetfile.configs.Configure;
import ru.usb.eagetfile.service.DownLoadFiles;
import ru.usb.eagetfile.utils.NewFileInputStream;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", tags = "Rest API. Сервис получения файлов из ЭА")
public class RestController {

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @Autowired
    DownLoadFiles downLoadFiles;

    @Autowired
    Configure configure;

    //Запрашиваем версию сервиса
    @GetMapping("/version")
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() {
        if (configure.getVersion() == null) {
            return "version not defined";
        }
        return (configure.getVersion());
    }


    @GetMapping("/file")
    @ApiOperation(value = "Запрос URL файла",
            notes = "Файл\n" +
                    " Путь к файлу. Пример:https://goip-pro.ru/files/pdf/manual_gsm-voip-gateway_goip_1.pdf\n " +
                    "  filename - имя файла для сохранения в хранилище, пример : FileName.PDF")
    public ResponseEntity<Object> getFile(String urlFile, String fileName) {
        logger.info(">>>>>>>>>>>>>>>>>>>Request>/file>>>>>>>");
        logger.info("Имя файла::{}", fileName);
        logger.info("URL файла::{}", urlFile);
        try {
            File file = downLoadFiles.downLoadBigFile(urlFile, new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() + configure.getTmpPath(), fileName);
            logger.info("File => {}", file.getAbsolutePath());
            logger.info("File= {}", file.getName());
            logger.info("File size:={}", file.length());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(file));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    //.headers(headers)
                    .contentLength(file.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
