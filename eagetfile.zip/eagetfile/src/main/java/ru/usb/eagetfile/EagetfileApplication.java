package ru.usb.eagetfile;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.eagetfile.configs.Configure;
import ru.usb.eagetfile.service.DownLoadFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@EnableSwagger2
@SpringBootApplication
public class EagetfileApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(EagetfileApplication.class);

    @Autowired
    Configure configure;

    @Autowired
    DownLoadFiles downLoadFiles;

    public static void main(String[] args) {
        SpringApplication.run(EagetfileApplication.class, args);
    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Alexander Lyapustin", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("EA Get File. Api Title 19/09/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("license Uralsib Bank")
                .licenseUrl("https://www.uralsib.ru")
                .contact(contact)
                .build();
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("Start version of service::{}", configure.getVersion());
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() + configure.getTmpPath());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("Directory {} = created", path.toString());
        } else {
            logger.info("Directory {} = already exists", path.toString());
        }
    }
}
