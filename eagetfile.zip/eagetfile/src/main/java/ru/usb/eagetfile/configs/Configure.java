package ru.usb.eagetfile.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {

    @Value("${service.version}")
    private String version;

    @Value("${service.temppath}")
    private String tmpPath;

    //Реализация..
    public String getVersion() {
        return version;
    }

    public String getTmpPath() {
        return tmpPath;
    }
}
