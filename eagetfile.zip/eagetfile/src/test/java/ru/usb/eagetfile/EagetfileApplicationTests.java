package ru.usb.eagetfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EagetfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
