package ru.usb.zsk952235SugarCRM.config;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Service
public class SoapConfig {
    @Bean
    public Jaxb2Marshaller marshaller(){
        Jaxb2Marshaller marshaller=new Jaxb2Marshaller();
        marshaller.setPackagesToScan("ru.usb.zsk952235SugarCRM.sugarcrm");
        return marshaller;
    }
}
