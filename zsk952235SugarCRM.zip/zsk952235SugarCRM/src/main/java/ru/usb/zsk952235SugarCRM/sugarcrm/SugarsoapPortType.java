/**
 * SugarsoapPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ru.usb.zsk952235SugarCRM.sugarcrm;

public interface SugarsoapPortType extends java.rmi.Remote {

    /**
     * SOAP Proxy
     */
    public ru.usb.zsk952235SugarCRM.sugarcrm.UNIAPI_result UNIAPIt(java.lang.String token, java.lang.String system, java.lang.String method, java.lang.String packnum, java.lang.String pack) throws java.rmi.RemoteException;
}
