/**
 * UNIAPI_result.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ru.usb.zsk952235SugarCRM.sugarcrm;

import java.util.Arrays;

public class UNIAPI_result  implements java.io.Serializable {
    private java.lang.String code;

    private java.lang.String system;

    private java.lang.String method;

    private java.lang.String packnum;

    private java.lang.String pack;

    private ru.usb.zsk952235SugarCRM.sugarcrm.Error[] errors;

    private java.lang.Object _null;  // attribute

    public UNIAPI_result() {
    }

    public UNIAPI_result(
           java.lang.String code,
           java.lang.String system,
           java.lang.String method,
           java.lang.String packnum,
           java.lang.String pack,
           ru.usb.zsk952235SugarCRM.sugarcrm.Error[] errors,
           java.lang.Object _null) {
           this.code = code;
           this.system = system;
           this.method = method;
           this.packnum = packnum;
           this.pack = pack;
           this.errors = errors;
           this._null = _null;
    }


    /**
     * Gets the code value for this UNIAPI_result.
     * 
     * @return code
     */
    public java.lang.String getCode() {
        return code;
    }


    /**
     * Sets the code value for this UNIAPI_result.
     * 
     * @param code
     */
    public void setCode(java.lang.String code) {
        this.code = code;
    }


    /**
     * Gets the system value for this UNIAPI_result.
     * 
     * @return system
     */
    public java.lang.String getSystem() {
        return system;
    }


    /**
     * Sets the system value for this UNIAPI_result.
     * 
     * @param system
     */
    public void setSystem(java.lang.String system) {
        this.system = system;
    }


    /**
     * Gets the method value for this UNIAPI_result.
     * 
     * @return method
     */
    public java.lang.String getMethod() {
        return method;
    }


    /**
     * Sets the method value for this UNIAPI_result.
     * 
     * @param method
     */
    public void setMethod(java.lang.String method) {
        this.method = method;
    }


    /**
     * Gets the packnum value for this UNIAPI_result.
     * 
     * @return packnum
     */
    public java.lang.String getPacknum() {
        return packnum;
    }


    /**
     * Sets the packnum value for this UNIAPI_result.
     * 
     * @param packnum
     */
    public void setPacknum(java.lang.String packnum) {
        this.packnum = packnum;
    }


    /**
     * Gets the pack value for this UNIAPI_result.
     * 
     * @return pack
     */
    public java.lang.String getPack() {
        return pack;
    }


    /**
     * Sets the pack value for this UNIAPI_result.
     * 
     * @param pack
     */
    public void setPack(java.lang.String pack) {
        this.pack = pack;
    }


    /**
     * Gets the errors value for this UNIAPI_result.
     * 
     * @return errors
     */
    public ru.usb.zsk952235SugarCRM.sugarcrm.Error[] getErrors() {
        return errors;
    }


    /**
     * Sets the errors value for this UNIAPI_result.
     * 
     * @param errors
     */
    public void setErrors(ru.usb.zsk952235SugarCRM.sugarcrm.Error[] errors) {
        this.errors = errors;
    }


    /**
     * Gets the _null value for this UNIAPI_result.
     * 
     * @return _null
     */
    public java.lang.Object get_null() {
        return _null;
    }


    /**
     * Sets the _null value for this UNIAPI_result.
     * 
     * @param _null
     */
    public void set_null(java.lang.Object _null) {
        this._null = _null;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UNIAPI_result)) return false;
        UNIAPI_result other = (UNIAPI_result) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              this.code.equals(other.getCode()))) &&
            ((this.system==null && other.getSystem()==null) || 
             (this.system!=null &&
              this.system.equals(other.getSystem()))) &&
            ((this.method==null && other.getMethod()==null) || 
             (this.method!=null &&
              this.method.equals(other.getMethod()))) &&
            ((this.packnum==null && other.getPacknum()==null) || 
             (this.packnum!=null &&
              this.packnum.equals(other.getPacknum()))) &&
            ((this.pack==null && other.getPack()==null) || 
             (this.pack!=null &&
              this.pack.equals(other.getPack()))) &&
            ((this.errors==null && other.getErrors()==null) || 
             (this.errors!=null &&
              java.util.Arrays.equals(this.errors, other.getErrors()))) &&
            ((this._null==null && other.get_null()==null) || 
             (this._null!=null &&
              this._null.equals(other.get_null())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCode() != null) {
            _hashCode += getCode().hashCode();
        }
        if (getSystem() != null) {
            _hashCode += getSystem().hashCode();
        }
        if (getMethod() != null) {
            _hashCode += getMethod().hashCode();
        }
        if (getPacknum() != null) {
            _hashCode += getPacknum().hashCode();
        }
        if (getPack() != null) {
            _hashCode += getPack().hashCode();
        }
        if (getErrors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (get_null() != null) {
            _hashCode += get_null().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UNIAPI_result.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.sugarcrm.com/sugarcrm", "UNIAPI_result"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("_null");
        attrField.setXmlName(new javax.xml.namespace.QName("", "null"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("system");
        elemField.setXmlName(new javax.xml.namespace.QName("", "system"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("method");
        elemField.setXmlName(new javax.xml.namespace.QName("", "method"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("packnum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "packnum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pack");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pack"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errors");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.sugarcrm.com/sugarcrm", "error"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

    @Override
    public String toString() {
        return "UNIAPI_result{" +
                "code='" + code + '\'' +
                ", system='" + system + '\'' +
                ", method='" + method + '\'' +
                ", packnum='" + packnum + '\'' +
                ", pack='" + pack + '\'' +
                ", errors=" + Arrays.toString(errors) +
                '}';
    }
}
