package ru.usb.zsk952235SugarCRM.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.model.RiskModel;
import ru.usb.zsk952235SugarCRM.model.SoapSugarReq;
import ru.usb.zsk952235SugarCRM.repository.SugarRiskRepositoryImpl;
import ru.usb.zsk952235SugarCRM.service.SoapClient;
import ru.usb.zsk952235SugarCRM.service.XMLReaderAL;
import ru.usb.zsk952235SugarCRM.sugarcrm.UNIAPI_result;
import ru.usb.zsk952235SugarCRM.utils.WorkWithFiles;

import java.io.IOException;

@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер по REST API к сервису [zsk952235SugarCRM] Задача Мини проекта №952235."
        , tags = "Rest API 1. Для контроля работы сервиса.")
@RestController
public class RescontrollerRF {

    @Autowired
    Configure configure;

    @Autowired
    SoapClient soapClient;

    @Autowired
    XMLReaderAL xmlReaderAL;

    @Autowired
    SugarRiskRepositoryImpl sugarRiskRepository;

    @Autowired
    WorkWithFiles wwf;

    Logger logger = LoggerFactory.getLogger(RescontrollerRF.class);

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
        if (configure.getVersion() == null) {
            logger.info("get /version :: Request get version, but version not defiled in application.properties");
            return "version not defined";
        }
        logger.error("get /version :: Request get version, " + configure.getVersion());
        return (configure.getVersion());
    }

    @PostMapping("/import")
    //Вставляем API описание
    @ApiOperation(value = "Импорт файла XML по рискам в базу данных",
            notes = "Укажите полный путь с именем файла для загрузки. Пример C:\\AppSever\\Data\\sugar\\KYC_20220803.xml")
    public ResponseEntity<?> importFile(@RequestBody String fullFilePath) {
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>POST input record>>>>>>>>>>>>>>>>>>");
        logger.info("postRecord:/ " + fullFilePath);
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");

        if (wwf.checkFileExists(fullFilePath)) {

            //Загрузка из линейного источника или объекта
//            int iCount = xmlReaderA.readXML(fullFilePath);
            int iCount = xmlReaderAL.readXML(fullFilePath);

            if (iCount > 0) {
                return new ResponseEntity<>(
                        "Количество добавленных в базу данных:" + iCount,
                        HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        "Произошла ошибка при анализе файла, возможно файл другой структуры:" + iCount,
                        HttpStatus.BAD_REQUEST);
            }

        } else {
            return new ResponseEntity<>(
                    "Произошла ошибка файл :" + fullFilePath + " не найден! ",
                    HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/count")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос количества загруженных в последней загрузке записей",
            notes = "Берется из переменной recordFileCounter - Счетчик последней загрузки - сколько записей было загружено в БД",
            response = String.class)
    public String getCount() throws IOException {
        if (configure.getRecordFileCounter() == 0) {
            logger.error("После перезапуска сервиса загрузка не проводилась... Пока 0.");
            return "После перезапуска сервиса загрузка не проводилась... Пока 0.";
        } else {
            logger.error("Кол-во загруженных в последней операции=" + Integer.toString(configure.getRecordFileCounter()));
            return "Кол-во загруженных в последней операции=" + Integer.toString(configure.getRecordFileCounter());
        }
    }

    @GetMapping("/dbcount")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос количества записей в базе данных",
            notes = "select count(*) из таблицы рисков",
            response = String.class)
    public String getDbCount() {
        return "Количество записей в БД :: " + sugarRiskRepository.count();
    }

    @GetMapping("/inn/{inn}")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос записи из таблицы по ИНН",
            notes = " Получаем JSON. Пример ИНН: 0216995870",
            response = RiskModel.class)
    @ApiParam(value = "ИНН клиента", defaultValue = "0216995870")
    public ResponseEntity<?> getFroInn(@RequestParam String INN) {
        try {
            RiskModel riskModel = sugarRiskRepository.getByInn(INN);
            if (riskModel != null) {
                return new ResponseEntity<>(sugarRiskRepository.getByInn(INN), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Запись с ИНН = " + INN + " в таблице не найдена..", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Запись с ИНН = " + INN + " в таблице не найдена..", HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/soap")
    //Вставляем API описание
    @ApiOperation(value = "SOAP Action test",
            notes = "Метод тестирования SOAP")
    public ResponseEntity<?> soapTestAction(@RequestBody SoapSugarReq soapSugarReq) {

        logger.info("*****>>>>>>>>>>>>>>>>>>>>>POST SOAP>>>>>>>>>>>>>>>>>>>>>>>>>");
        logger.info("post request:/ " + soapSugarReq.toString());
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        UNIAPI_result uniapi_result = null;

        try {
            uniapi_result = soapClient.notiySugar(soapSugarReq);
            logger.info(" SOAP Response: " + uniapi_result.toString());
            return new ResponseEntity<>(" SOAP Response: " + uniapi_result, HttpStatus.OK);
        } catch (Exception exception) {
            logger.error("Ошибка при тестировании SOAP");
            return new ResponseEntity<>("Ошибка при тестировании SOAP: " + exception.getMessage(), HttpStatus.BAD_GATEWAY);
        }

    }


}
