package ru.usb.zsk952235SugarCRM.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.model.SoapSugarReq;
import ru.usb.zsk952235SugarCRM.utils.WorkWithFiles;

import java.io.File;
import java.nio.file.FileSystems;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class ServiceInputFile {

    Logger logger = LoggerFactory.getLogger(ServiceInputFile.class);

    @Autowired
    WorkWithFiles ww;

    @Autowired
    Configure configure;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    SoapClient soapClient;

    @Autowired
    XMLReaderAL xmlReaderAL;


    public boolean findFile() {

        /**
         * Проверка наличия директорий
         */
        if (!ww.checkPathExists(configure.getServicePathZSKFile())) {
            logger.error("Error. Директория  (поиска файла ZSK): " + configure.getServicePathZSKFile() + " не обнаружена! Работа невозможна. Дальнейшая работа невозможна");
            serviceMailError.sendMailError("Error. Директория  (поиска файла ZSK): " + configure.getServicePathZSKFile() + " не обнаружена! Работа невозможна. Дальнейшая работа невозможна");
            return false;
        }

        if (!ww.checkPathExists(configure.getServicePathMoveFile())) {
            logger.error("Error. Директория (переноса файла ZSK, для ЦФТ и ЦХД): " + configure.getServicePathMoveFile() + " не обнаружена! Работа невозможна. Дальнейшая работа невозможна.");
            serviceMailError.sendMailError("Error. Директория (переноса файла ZSK, для ЦФТ и ЦХД): " + configure.getServicePathMoveFile() + " не обнаружена! Работа невозможна. Дальнейшая работа невозможна.");
            return false;
        }

        /**
         * Получаем список файлов
         */
        List<File> files = ww.getDirFileExt(configure.getServicePathZSKFile(), configure.getMaskExtension());

        /**
         * Если файлы обнаружены, сначала файл копируем в другую директорию
         */
        if (!files.isEmpty()) {
            //Задержка в 30 секунд для обработки СКЗИ enc и sig. Свойство - download.delay
            logger.info(" Seconds = " + configure.getDownloadDelay() + " - delay between downloaded.....");
            try {
                TimeUnit.SECONDS.sleep(configure.getDownloadDelay());
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }

            //Копируем файлы в другую директорию
            files.forEach(file -> ww.copyFiles(file.getAbsolutePath(), configure.getServicePathMoveFile() + FileSystems.getDefault().getSeparator() + file.getName()));

            //Загружаем файлы
            files.forEach(file -> {
                if (xmlReaderAL.readXML(file.getAbsolutePath()) == 0) {
                    logger.error("#################################################################");
                    logger.error("# Странно ничего не загрузили из файла::" + file.getAbsolutePath());
                    logger.error("#################################################################");
                    serviceMailError.sendMailError("Проверка ЗСК – ошибка актуализации данных", "Не удалось записать данные в INT_ZSK и запустить метод ZSKRisksSetList.\r\n" +
                            "Необходимо связаться с интеграционным сервисом для выяснения ошибок.\r\n" +
                            "Реализовано в рамках МП № 952235\r\n" +
                            "Странно ничего не загрузили из файла::" + file.getAbsolutePath());
                }
                //Удаляем файл после обработки
                ww.delFiles(file.toPath());
            });
            //Отправляем SOAP запрос в SugarCRM
            SoapSugarReq soapSugarReq = new SoapSugarReq(configure.getSoapToken(), configure.getBaseSystem(),
                    configure.getBaseMethod(), null, configure.getBasePack());

            /**
             * Subject: Проверка ЗСК – ошибка передачи данных
             * Body:
             * Не удалось записать данные в INT_ZSK и запустить метод ZSKRisksSetList.
             * Необходимо связаться с интеграционным сервисом для выяснения ошибок.
             * Реализовано в рамках МП № 952235
             */
            soapClient.notiySugar(soapSugarReq);


        }
        return true;
    }

}
