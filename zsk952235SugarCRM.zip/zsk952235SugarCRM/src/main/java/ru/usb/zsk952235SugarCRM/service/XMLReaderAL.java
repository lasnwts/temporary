package ru.usb.zsk952235SugarCRM.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.model.RiskModel;
import ru.usb.zsk952235SugarCRM.repository.SugarRiskRepositoryImpl;
import ru.usb.zsk952235SugarCRM.utils.ParseDate;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Чтения XML файла с минимальной нагрузкой на память
 * <p>
 * https://www.baeldung.com/java-stax
 * https://mkyong.com/java/how-to-read-xml-file-in-java-stax-parser/
 * <p>
 * Java - урок 48.5 (StAX parser/reader (writer) XML)
 * https://www.youtube.com/watch?v=aH_86FYAMMY
 */
@Service
public class XMLReaderAL {

    @Autowired
    SugarRiskRepositoryImpl sugarRiskRepository;

    @Autowired
    ParseDate parseDate;

    Logger logger = LoggerFactory.getLogger(XMLReaderAL.class);

    //Счетчик созданных объектов
    private int ObjectCounter;

    //Счетчик ошибок в записях файла
    private int ErrorCounter;

    //Через столько объектов сделаем запсук Garbage Collector
    private int garbageCollectorCounter;

    //ID файла Реестра рисков
    private String UniqueIdentifier;

    //Дата формирования Реестра рисков
    private String Risks_Report_Date;


    @Autowired
    Configure configure;

    /**
     * Чтение XML файла и запись в базу данных
     *
     * @param fullPath - полный путь к файлу для загрузки
     * @return - количество загруженных записей
     */
    public int readXML(String fullPath) {

        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        RiskModel riskModel = null;
        //Обнуляем счетчик объектов
        ObjectCounter = 0;
        Risks_Report_Date = "";
        UniqueIdentifier = "";
        ErrorCounter = 0;
        configure.setRecordErrorCounter(0);

        //GC
        garbageCollectorCounter = configure.getGarbageCount();

        try {
            XMLEventReader reader = xmlInputFactory.createXMLEventReader(new FileInputStream(fullPath));

            while (reader.hasNext()) {
                XMLEvent nextEvent = reader.nextEvent();
//                if (configure.isLogDebug()) {
//                    logger.info(nextEvent.toString());
//                }
                if (nextEvent.isStartElement()) {
                    StartElement startElement = nextEvent.asStartElement();
//                    if (configure.isLogDebug()) {
//                        logger.info(startElement.getName().getLocalPart().toString());
//                    }
                    if (startElement.getName().getLocalPart().trim().equalsIgnoreCase("uniqueidentifier")) {
                        nextEvent = reader.nextEvent();
                        UniqueIdentifier = nextEvent.asCharacters().getData();
                    }
                    if (startElement.getName().getLocalPart().trim().equalsIgnoreCase("risks_report_date")) {
                        nextEvent = reader.nextEvent();
                        Risks_Report_Date = nextEvent.asCharacters().getData();
                    }
                    if (startElement.getName().getLocalPart().trim().equalsIgnoreCase("risk")) {
                        riskModel = new RiskModel();
                    } else {
                        switch (startElement.getName().getLocalPart().toLowerCase()) {
                            case "inn":
                                nextEvent = reader.nextEvent();
                                riskModel.setInn(nextEvent.asCharacters().getData());
                                break;
                            case "client_type":
                                nextEvent = reader.nextEvent();
                                riskModel.setClient_type(nextEvent.asCharacters().getData());
                                break;
                            case "risk_level":
                                nextEvent = reader.nextEvent();
                                riskModel.setRisk_level(nextEvent.asCharacters().getData());
                                break;
                            case "risk_date":
                                nextEvent = reader.nextEvent();
                                riskModel.setRisk_date(nextEvent.asCharacters().getData());
                                break;
                            case "mainrisk":
                                nextEvent = reader.nextEvent();
                                riskModel.setMainrisk(nextEvent.asCharacters().getData());
                                break;
                            case "addrisk1":
                                nextEvent = reader.nextEvent();
                                riskModel.setAddrisk1(nextEvent.asCharacters().getData());
                                break;
                            case "addrisk2":
                                nextEvent = reader.nextEvent();
                                riskModel.setAddrisk2(nextEvent.asCharacters().getData());
                                break;
                            case "addrisk3":
                                nextEvent = reader.nextEvent();
                                riskModel.setAddrisk3(nextEvent.asCharacters().getData());
                                break;
                        }
                    }

                }
                if (nextEvent.isEndElement()) {
                    EndElement endElement = nextEvent.asEndElement();
                    if (endElement.getName().getLocalPart().toLowerCase().equals("risk")) {
                        ObjectCounter++;

                        /**
                         * GC будет запускаться, только если значение service.garbage.count не равно 0 в application.properties
                         */
                        if (garbageCollectorCounter > 0) {
                            garbageCollectorCounter--;
                            if (garbageCollectorCounter == 0) {
                                System.gc();
                                garbageCollectorCounter = configure.getGarbageCount();
                            }
                        }
                        /**
                         * Заголовочная часть записи
                         */
                        riskModel.setUniqueidentifier(UniqueIdentifier);
                        riskModel.setRisk_report_date(Risks_Report_Date);

                        /**
                         * Проверки
                         */
                        if (!parseInt(riskModel.getRisk_level())){
                            logger.error("###############################################################");
                            logger.error("# Ошибка Risk_Level - не целое число. Запись ::" + riskModel.toString());
                            logger.error("# Номер записи в файле ::" + ObjectCounter);
                            logger.error("###############################################################");
                        }
                        if (!parseDate.parseDate(riskModel.getRisk_date())){
                            logger.error("###############################################################");
                            logger.error("# Ошибка Risk_Date! Дата должна быть в формате yyyy-MM-dd. Запись ::" + riskModel.toString());
                            logger.error("# Номер записи в файле ::" + ObjectCounter);
                            logger.error("###############################################################");
                        }

                        /**
                         * Добавляем запись в БД
                         */
                        try {
                            sugarRiskRepository.save(riskModel);
                        } catch (Exception ex) {
                            logger.error("###############################################################");
                            logger.error("# Ошибка добавления в БД записи ::" + riskModel.toString());
                            logger.error("# Номер записи в файле ::" + ObjectCounter);
                            logger.error("###############################################################");
                            ErrorCounter++;
                        }
                        if (configure.isLogDebug()) {
                            logger.info(riskModel.toString());
                        }
                        riskModel = null;
                    }
                }
            }


        } catch (XMLStreamException e) {
            logger.error("#################################################################");
            logger.error("Ошибка[XMLStreamException] при подключении к файлу для чтения:" + fullPath);
            logger.error(e.getMessage());
            logger.error("#################################################################");
            return 0;
        } catch (FileNotFoundException e) {
            logger.error("#################################################################");
            logger.error("Ошибка[FileNotFoundException] при подключении к файлу для чтения:" + fullPath);
            logger.error(e.getMessage());
            logger.error("#################################################################");
            return 0;
        }

        logger.info("");
        logger.info("--------------------------------------------------------------------------------------------------------------");
        logger.info("| Обработано  записей (всего в файле)                                = " + ObjectCounter);
        logger.info("| Количество ошибочных записей (не добавленных в таблицу)            = " + ErrorCounter);
        logger.info("--------------------------------------------------------------------------------------------------------------");
        logger.info("| Загрузка завершена. Итого Количество добавленных в таблицу записей = " + (ObjectCounter-ErrorCounter));
        logger.info("--------------------------------------------------------------------------------------------------------------");

        //Заносим количество записей в конф. для отчета
        configure.setRecordFileCounter(ObjectCounter);
        System.gc();
        return ObjectCounter;
    }


    /**
     * Проверка, чтол risk_level целое число
     * @param risk_level
     * @return true норма, false - олшибка
     */
    private boolean parseInt(String risk_level){
        try {
            Integer.parseInt(risk_level);
            return true;
        } catch (Exception exception){
            logger.error("#################################################################");
            logger.error("Ошибка парсинга целого числа");
            logger.error("#################################################################");
            return false;
        }

    }

}
