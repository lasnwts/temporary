package ru.usb.zsk952235SugarCRM;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.service.ServiceInputFile;
import ru.usb.zsk952235SugarCRM.utils.WorkWithFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@EnableSwagger2
@SpringBootApplication
public class Zsk952235SugarCrmApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(Zsk952235SugarCrmApplication.class);

    @Autowired
    Configure configure;

    @Autowired
    ServiceInputFile serviceInputFile;

    @Autowired
    WorkWithFiles ww;

    public static void main(String[] args) {
        SpringApplication.run(Zsk952235SugarCrmApplication.class, args);
    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service zsk952235SugarCRM", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Задача Проекта №952235 Реализация проверки Клиента/Предконтакта в SugarCRM на нахождение в таблице ЗСК.Rest Api Title 10/08/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }


    /*
     * Sheduler 1. Первый шедулер
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {

        //Запуск процедура автоматической проверки наличия файла и обработки его
        serviceInputFile.findFile();

    }


    @Override
    public void run(String... args) throws Exception {

        // Показываем версию
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Version of service:" + configure.getVersion());
        logger.info("-----------------------------------------------");
        logger.info("");


        // Инициализируем счетчик
        configure.setRecordFileCounter(0);


        // Проверка наличия директорий
        if (ww.checkPathExists(configure.getServicePathZSKFile())) {
            logger.info("Success. Директория (поиска файла ZSK): " + configure.getServicePathZSKFile() + " обнаружена.");
        } else {
            logger.error("Error. Директория  (поиска файла ZSK): " + configure.getServicePathZSKFile() + " не обнаружена! Работа невозможна.");
        }

        if (ww.checkPathExists(configure.getServicePathMoveFile())) {
            logger.info("Success. Директория  (переноса файла ZSK, для ЦФТ и ЦХД): " + configure.getServicePathMoveFile() + " обнаружена.");
        } else {
            logger.error("Error. Директория (переноса файла ZSK, для ЦФТ и ЦХД): " + configure.getServicePathMoveFile() + " не обнаружена! Работа невозможна.");
        }


    }
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}