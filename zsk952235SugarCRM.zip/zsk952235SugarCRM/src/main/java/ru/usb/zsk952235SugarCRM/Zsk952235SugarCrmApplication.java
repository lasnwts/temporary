package ru.usb.zsk952235SugarCRM;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.service.SoapClient;
import ru.usb.zsk952235SugarCRM.service.XMLReaderAL;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication
public class Zsk952235SugarCrmApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(Zsk952235SugarCrmApplication.class);

    @Autowired
    Configure configure;

    @Autowired
    SoapClient soapClient;

    @Autowired
    XMLReaderAL xmlReaderAL;

    public static void main(String[] args) {
        SpringApplication.run(Zsk952235SugarCrmApplication.class, args);
    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service EIC949829", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Задача Проекта №949879 Этап 2. Электронные счета фактуры, проект № 3436.Rest Api Title 12/07/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }


    @Override
    public void run(String... args) throws Exception {

        /**
         * Test zone
         */
//        System.out.println("Run ...");
//		System.out.println("run soap" );
        //soapClient.notiySugar();
        //xmlReaderAL.readXML("C:\\AppSever\\Data\\sugar\\KYC_20220803.xml");

        /**
         * End test zone
         */

        /**
         * Показываем версию
         */
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Version of service:" + configure.getVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        /**
         * Инициализируем счетчик
         */
        configure.setRecordFileCounter(0);

    }
}
