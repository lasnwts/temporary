package ru.usb.zsk952235SugarCRM.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zsk952235SugarCRM.config.Configure;
import ru.usb.zsk952235SugarCRM.model.SoapSugarReq;
import ru.usb.zsk952235SugarCRM.sugarcrm.SugarsoapLocator;
import ru.usb.zsk952235SugarCRM.sugarcrm.SugarsoapPortType;
import ru.usb.zsk952235SugarCRM.sugarcrm.UNIAPI_result;

import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import java.util.UUID;


@Service
public class SoapClient {

    Logger logger = LoggerFactory.getLogger(SoapClient.class);

    @Autowired
    Configure configure;

    /**
     * Вызываем метод в SUgarCRM для извещения о готовности
     *
     * @param soapSugarReq - модель со всеми параметрами вызова
     * @return - возврат ответа от SOAP сервиса
     */
    public UNIAPI_result notiySugar(SoapSugarReq soapSugarReq) {

        /**
         * Подготовка к вызову SOAP сервиса
         */
        logger.info("SOAP, Prepared (SoapSugarReq):" + soapSugarReq.toString());

        if (soapSugarReq.getPackNum() == null) {
            /**
             * Генерируем GUID
             */
            UUID uuid = UUID.randomUUID();
            logger.info("SOAP Action, UUID = " + String.valueOf(uuid));
            soapSugarReq.setPackNum(String.valueOf(uuid));
        }

        SugarsoapLocator sugarsoapLocator = new SugarsoapLocator();
        sugarsoapLocator.setsugarsoapPortEndpointAddress(configure.getBaseSoapUrl());

        SugarsoapPortType sugarsoapPortType = null;

        try {
            sugarsoapPortType = sugarsoapLocator.getsugarsoapPort();
        } catch (ServiceException e) {
            logger.error("ServiceException: sugarsoapLocator.getsugarsoapPort()  ::\n" + e.getMessage());
            e.printStackTrace();
            return null;
        }

        /**
         * Подготовка к вызову SOAP сервиса
         */
        logger.info("SOAP,Ready, UNIAPIt(SoapSugarReq):" + soapSugarReq.toString());

        UNIAPI_result uniapi_result = null;

        try {
            //uniapi_result = sugarsoapPortType.UNIAPIt("TONEK", "SYSTEM", "METHOD", "Packnum:"+uuid, "pack");
            uniapi_result = sugarsoapPortType.UNIAPIt(soapSugarReq.getToken(), soapSugarReq.getSystem(),
                    soapSugarReq.getMethod(), soapSugarReq.getPackNum(), soapSugarReq.getPack());
        } catch (RemoteException e) {
            logger.error("RemoteException: phonesinfoarray = phones.GETSAPIDBYPHONE(phoneNumber) ::\n" + e.getMessage());
            e.printStackTrace();
            return null;
        }

        logger.info("<<<<<<<<<<<<<<<<<<Response from SOAP Service<<<<<<<<<<<<<<<<<<<<<<");
        logger.info("SoapClient:UNIAPIt::  = " + uniapi_result.toString());
        logger.info("<<<<<<<<<<<<<<<<<end response from SOAP Service<<<<<<<<<<<<<<<<<<<");

        return uniapi_result;

    }
}
