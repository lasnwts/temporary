package ru.usb.zsk952235SugarCRM.repository;

import ru.usb.zsk952235SugarCRM.model.RiskModel;

import java.util.List;
import java.util.Map;

public interface SugarRiskRepository {
    int save(RiskModel riskModel);
    int deleteAll();
    int count();

    RiskModel getByInn(String inn);
}
