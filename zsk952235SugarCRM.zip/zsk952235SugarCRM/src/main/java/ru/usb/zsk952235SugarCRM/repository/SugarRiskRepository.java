package ru.usb.zsk952235SugarCRM.repository;

import ru.usb.zsk952235SugarCRM.model.RiskModel;

public interface SugarRiskRepository {
    int save(RiskModel riskModel);
    int deleteAll();
    int count();

    RiskModel getByInn(String inn);
}
