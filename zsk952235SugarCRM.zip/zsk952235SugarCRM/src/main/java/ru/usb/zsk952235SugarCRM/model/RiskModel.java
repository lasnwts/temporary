package ru.usb.zsk952235SugarCRM.model;


/**
 *   <RISK>
 *     <inn>0100000011</inn>
 *     <client_type>ЮЛ</client_type>
 *     <risk_level>1</risk_level>
 *     <risk_date>2022-04-06</risk_date>
 *   </RISK>
 *
 *   create table INT_ZSK
 * (
 * UNIQUEIDENTIFIER VARCHAR2(4000),
 * RISKS_REPORT_DATE DATE,
 * INN VARCHAR2(4000),
 * CLIENT_TYPE VARCHAR2(4000),
 * RISK_LEVEL NUMBER,
 * MAINRISK VARCHAR2(4000),
 * ADDRISK1 VARCHAR2(4000),
 * ADDRISK2 VARCHAR2(4000),
 * ADDRISK3 VARCHAR2(4000),
 * RISK_DATE TIMESTAMP(6)
 * )
 */

import javax.xml.crypto.Data;

/**
 * Класс модель для риска
 */
public class RiskModel {

    //ИНН ЮЛ или ИНН ИП
    private String inn;


    //Тип клиента (ЮЛ или ИП)
    private String client_type;


    //Уровень риска (средний или высокий)
    private String risk_level;


    //Дата и время присвоения текущего уровня риска
    private String risk_date;

    //ID файла Реестра рисков
    private String uniqueidentifier;


    //Дата формирования реестра
    private String risk_report_date;


    //Основной шифр типологии в формате N.NN
    private String mainrisk;

    //Дополнительный шифр типологии 1
    private String addrisk1;

    //Дополнительный шифр типологии 2
    private String addrisk2;

    //Дополнительный шифр типологии 3
    private String addrisk3;

    public RiskModel(String inn, String client_type, String risk_level, String risk_date,
                     String uniqueidentifier, String risk_report_date,
                     String mainrisk, String addrisk1, String addrisk2, String addrisk3) {
        this.inn = inn;
        this.client_type = client_type;
        this.risk_level = risk_level;
        this.risk_date = risk_date;
        this.uniqueidentifier = uniqueidentifier;
        this.risk_report_date = risk_report_date;
        this.mainrisk = mainrisk;
        this.addrisk1 = addrisk1;
        this.addrisk2 = addrisk2;
        this.addrisk3 = addrisk3;
    }

    public RiskModel() {
    }

    public RiskModel(String inn, String client_type, String risk_level, String risk_date) {
        this.inn = inn;
        this.client_type = client_type;
        this.risk_level = risk_level;
        this.risk_date = risk_date;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getClient_type() {
        return client_type;
    }

    public void setClient_type(String client_type) {
        this.client_type = client_type;
    }

    public String getRisk_level() {
        return risk_level;
    }

    public void setRisk_level(String risk_level) {
        this.risk_level = risk_level;
    }

    public String getRisk_date() {
        return risk_date;
    }

    public void setRisk_date(String risk_date) {
        this.risk_date = risk_date;
    }

    public String getUniqueidentifier() {
        return uniqueidentifier;
    }

    public void setUniqueidentifier(String uniqueidentifier) {
        this.uniqueidentifier = uniqueidentifier;
    }

    public String getRisk_report_date() {
        return risk_report_date;
    }

    public void setRisk_report_date(String risk_report_date) {
        this.risk_report_date = risk_report_date;
    }

    public String getMainrisk() {
        return mainrisk;
    }

    public void setMainrisk(String mainrisk) {
        this.mainrisk = mainrisk;
    }

    public String getAddrisk1() {
        return addrisk1;
    }

    public void setAddrisk1(String addrisk1) {
        this.addrisk1 = addrisk1;
    }

    public String getAddrisk2() {
        return addrisk2;
    }

    public void setAddrisk2(String addrisk2) {
        this.addrisk2 = addrisk2;
    }

    public String getAddrisk3() {
        return addrisk3;
    }

    public void setAddrisk3(String addrisk3) {
        this.addrisk3 = addrisk3;
    }

    @Override
    public String toString() {
        return "RiskModel{" +
                "uniqueidentifier='" + uniqueidentifier + '\'' +
                ", risk_report_date=" + risk_report_date +
                ", inn='" + inn + '\'' +
                ", client_type='" + client_type + '\'' +
                ", risk_level='" + risk_level + '\'' +
                ", risk_date='" + risk_date + '\'' +
                ", mainrisk='" + mainrisk + '\'' +
                ", addrisk1='" + addrisk1 + '\'' +
                ", addrisk2='" + addrisk2 + '\'' +
                ", addrisk3='" + addrisk3 + '\'' +
                '}';
    }
}
