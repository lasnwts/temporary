package ru.usb.zsk952235SugarCRM.model;

/**
 * "TONEK", "SYSTEM", "METHOD", "Packnum:"+uuid, "pack"
 */
public class SoapSugarReq {

    private String token;
    private String system;
    private String method;
    private String packNum;
    private String pack;

    public SoapSugarReq() {
    }

    public SoapSugarReq(String token, String system, String method, String packNum, String pack) {
        this.token = token;
        this.system = system;
        this.method = method;
        this.packNum = packNum;
        this.pack = pack;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getPackNum() {
        return packNum;
    }

    public void setPackNum(String packNum) {
        this.packNum = packNum;
    }

    public String getPack() {
        return pack;
    }

    public void setPack(String pack) {
        this.pack = pack;
    }

    @Override
    public String toString() {
        return "SoapSugarReq{" +
                "token='" + token + '\'' +
                ", system='" + system + '\'' +
                ", method='" + method + '\'' +
                ", packNum='" + packNum + '\'' +
                ", pack='" + pack + '\'' +
                '}';
    }
}
