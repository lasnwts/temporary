package ru.usb.zsk952235SugarCRM.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.usb.zsk952235SugarCRM.model.RiskModel;
import ru.usb.zsk952235SugarCRM.utils.ParseDate;
import ru.usb.zsk952235SugarCRM.utils.RiskRowMapper;

/**
 * https://www.bezkoder.com/spring-boot-jdbctemplate-example-oracle/
 */
@Repository
public class SugarRiskRepositoryImpl implements SugarRiskRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    ParseDate parseDate;

    public SugarRiskRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * insert into sugarRisk("inn","client_type","risk_level", "risk_date")
     * VALUES('78484888','ЮЛ', '1', '20.02.2022');
     */
    @Override
    public int save(RiskModel riskModel) {
        return jdbcTemplate.update("INSERT INTO INT_ZSK (uniqueidentifier, inn, client_type, risk_level, risk_date, risks_report_date, mainrisk, addrisk1, addrisk2, addrisk3) VALUES(?,?,?,?,?,?,?,?,?,?)",
                riskModel.getUniqueidentifier(), riskModel.getInn(), riskModel.getClient_type(), riskModel.getRisk_level(),
                parseDate.getDate(riskModel.getRisk_date()), parseDate.getDate(riskModel.getRisk_report_date()),
                riskModel.getMainrisk(), riskModel.getAddrisk1(), riskModel.getAddrisk2(), riskModel.getAddrisk3());
    }

    @Override
    public int deleteAll() {
        return jdbcTemplate.update("DELETE from INT_ZSK");
    }

    @Override
    public int count() {
        return jdbcTemplate.queryForObject("SELECT count(*) from INT_ZSK", Integer.class);
    }

    @Override
    public RiskModel getByInn(String inn) {
        String sql = "select UNIQUEIDENTIFIER,RISKS_REPORT_DATE,INN,CLIENT_TYPE,RISK_LEVEL,MAINRISK,ADDRISK1,ADDRISK2,ADDRISK3,RISK_DATE from INT_ZSK where  ROWNUM = 1 and inn = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{inn}, new RiskRowMapper());
    }


}
