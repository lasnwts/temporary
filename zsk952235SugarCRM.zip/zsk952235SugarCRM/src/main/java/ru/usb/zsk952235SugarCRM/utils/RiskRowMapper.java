package ru.usb.zsk952235SugarCRM.utils;


import org.springframework.jdbc.core.RowMapper;
import ru.usb.zsk952235SugarCRM.model.RiskModel;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RiskRowMapper implements RowMapper<RiskModel> {
    @Override
    public RiskModel mapRow(ResultSet resultSet, int i) throws SQLException {
        RiskModel riskModel = new RiskModel();
        riskModel.setUniqueidentifier(resultSet.getString("UNIQUEIDENTIFIER"));
        riskModel.setRisk_report_date(resultSet.getString("RISKS_REPORT_DATE"));
        riskModel.setInn(resultSet.getString("INN"));
        riskModel.setRisk_level(resultSet.getString("RISK_LEVEL"));
        riskModel.setClient_type(resultSet.getString("CLIENT_TYPE"));
        riskModel.setMainrisk(resultSet.getString("MAINRISK"));
        riskModel.setRisk_date(resultSet.getString("RISK_DATE"));
        riskModel.setAddrisk1(resultSet.getString("ADDRISK1"));
        riskModel.setAddrisk2(resultSet.getString("ADDRISK2"));
        riskModel.setAddrisk3(resultSet.getString("ADDRISK3"));
        return riskModel;
    }
}
