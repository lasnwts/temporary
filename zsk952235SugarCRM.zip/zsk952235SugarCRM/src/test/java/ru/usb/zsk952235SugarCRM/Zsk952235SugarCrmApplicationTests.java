package ru.usb.zsk952235SugarCRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zsk952235SugarCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
