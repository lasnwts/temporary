package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *         "created_timestamp": "11/29/2023 07:48:35",
 *         "client_id": "1-4HZ4-482",
 *         "other_contact_type_id": "",
 *         "id": "1-1HYPE3-628",
 *         "other_contact": "1-1HYPE3-628@AAAA.AAA"
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OtherContactData {

    @JsonProperty("created_timestamp")
    private String created_timestamp;
    @JsonProperty("client_id")
    private String client_id;

    @JsonProperty("other_contact_type_id")
    private String other_contact_type_id;

    @JsonProperty("id")
    private String  id;

    @JsonProperty("other_contact")
    private String other_contact;

    public OtherContactData() {
    }

    public OtherContactData(String created_timestamp, String client_id, String other_contact_type_id, String id, String other_contact) {
        this.created_timestamp = created_timestamp;
        this.client_id = client_id;
        this.other_contact_type_id = other_contact_type_id;
        this.id = id;
        this.other_contact = other_contact;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getOther_contact_type_id() {
        return other_contact_type_id;
    }

    public void setOther_contact_type_id(String other_contact_type_id) {
        this.other_contact_type_id = other_contact_type_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOther_contact() {
        return other_contact;
    }

    public void setOther_contact(String other_contact) {
        this.other_contact = other_contact;
    }

    @Override
    public String toString() {
        return "DataOtherContact{" +
                "created_timestamp='" + created_timestamp + '\'' +
                ", client_id='" + client_id + '\'' +
                ", other_contact_type_id='" + other_contact_type_id + '\'' +
                ", id='" + id + '\'' +
                ", other_contact='" + other_contact + '\'' +
                '}';
    }
}
