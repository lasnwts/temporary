package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Секция data
 * {
 *    "externalId":"1-IHMYC9U",
 *    "internalId":"",
 *    "data":{
 *       "owner":"",
 *       "createdTimestamp":"11/28/2023 07:33:12",
 *       "phoneNumber":"9119090567",
 *       "clientId":"1-23RH4S-25",
 *       "phoneTypeId":"0V-RKYNX",
 *       "description":"",
 *       "smsOn":"true",
 *       "id":"1-23RH7Q-484"
 *    }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PhoneData {

    @JsonProperty("ownerTypeId")
    private String ownerTypeId;

    @JsonProperty("createdTimestamp")
    private String createdTimestamp;

    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @JsonProperty("clientId")
    private String clientId;

    @JsonProperty("phoneTypeId")
    private String phoneTypeId;

    @JsonProperty("description")
    private String description;

    @JsonProperty("smsOn")
    private String smsOn;

    public PhoneData() {
        //
    }


    public String getOwnerTypeId() {
        return ownerTypeId;
    }

    public void setOwnerTypeId(String ownerTypeId) {
        this.ownerTypeId = ownerTypeId;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPhoneTypeId() {
        return phoneTypeId;
    }

    public void setPhoneTypeId(String phoneTypeId) {
        this.phoneTypeId = phoneTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSmsOn() {
        return smsOn;
    }

    public void setSmsOn(String smsOn) {
        this.smsOn = smsOn;
    }


    @Override
    public String toString() {
        return "PhoneData{" +
                "ownerTypeId='" + ownerTypeId + '\'' +
                ", createdTimestamp='" + createdTimestamp + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", clientId='" + clientId + '\'' +
                ", phoneTypeId='" + phoneTypeId + '\'' +
                ", description='" + description + '\'' +
                ", smsOn='" + smsOn + '\'' +
                '}';
    }
}
