package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Секция data
 * {
 *    "externalId":"1-IHMYC9U",
 *    "internalId":"",
 *    "data":{
 *       "owner":"",
 *       "created_timestamp":"11/28/2023 07:33:12",
 *       "phone_number":"9119090567",
 *       "client_id":"1-23RH4S-25",
 *       "phone_type_id":"0V-RKYNX",
 *       "description":"",
 *       "sms_on":"true",
 *       "id":"1-23RH7Q-484"
 *    }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PhoneData {

    @JsonProperty("owner_type_id")
    private String owner_type_id;

    @JsonProperty("created_timestamp")
    private String created_timestamp;

    @JsonProperty("phone_number")
    private String phone_number;

    @JsonProperty("client_id")
    private String client_id;

    @JsonProperty("phone_type_id")
    private String phone_type_id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("sms_on")
    private String sms_on;

    @JsonProperty("id")
    private String id;

    public PhoneData() {
    }

    public PhoneData(String owner_type_id, String created_timestamp, String phone_number, String client_id,
                     String phone_type_id, String description, String sms_on, String id) {
        this.owner_type_id = owner_type_id;
        this.created_timestamp = created_timestamp;
        this.phone_number = phone_number;
        this.client_id = client_id;
        this.phone_type_id = phone_type_id;
        this.description = description;
        this.sms_on = sms_on;
        this.id = id;
    }

    public String getOwner_type_id() {
        return owner_type_id;
    }

    public void setOwner_type_id(String owner_type_id) {
        this.owner_type_id = owner_type_id;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getPhone_type_id() {
        return phone_type_id;
    }

    public void setPhone_type_id(String phone_type_id) {
        this.phone_type_id = phone_type_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSms_on() {
        return sms_on;
    }

    public void setSms_on(String sms_on) {
        this.sms_on = sms_on;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "PhoneData{" +
                "owner_type_id='" + owner_type_id + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", client_id='" + client_id + '\'' +
                ", phone_type_id='" + phone_type_id + '\'' +
                ", description='" + description + '\'' +
                ", sms_on='" + sms_on + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
