package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.PhoneData;
import ru.usb.mobileapptosiebel.mapper.PhoneMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class PhoneSender {
    Logger logger = LoggerFactory.getLogger(PhoneSender.class);
    private final PhoneMap phoneMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public PhoneSender(PhoneMap phoneMap, AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.phoneMap = phoneMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        PhoneData phoneData = phoneMap.messageMapper(messageString);

        if (phoneData == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.phone : {}", phoneData);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */

        //created_timestamp
        if (aux.checkUnixDateTime(phoneData.getCreated_timestamp())) {
            phoneData.setCreated_timestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(phoneData.getCreated_timestamp())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(phoneMap.getJsonToStr(phoneData)), configure.getServicePhone())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
