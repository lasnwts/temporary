package ru.usb.mobileapptosiebel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.model.MessageFromKafka;
import ru.usb.mobileapptosiebel.service.kafka.produce.KafkaProducerService;
import ru.usb.mobileapptosiebel.utils.MapperMessSiebel;

/**
 * Основной процесс преобразования
 */

@Service
public class ProcessMessage {
    private final Logger logger = LoggerFactory.getLogger(ProcessMessage.class);

    private final Configure configure;

    private final KafkaProducerService kafkaProducerService;

    private final MapperMessSiebel mapperMessSiebel;

    @Autowired
    public ProcessMessage(Configure configure, KafkaProducerService kafkaProducerService, MapperMessSiebel mapperMessSiebel) {
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.mapperMessSiebel = mapperMessSiebel;
    }

    /**
     * Метод подготовки и отправки сообщения в Siebel от МП
     */

    /**
     * Метод подготовки и отправки сообщения в Siebel от МП
     *
     * @param message -- сообщение полученное по Кафка
     * @param service - топик по которому получено сообщение
     */
    public boolean sendMessSiebel(String message, String service, String packId) {

        if (message == null || service == null || packId == null) {
            return false;
        }

        /**
         * Работа над отправкой
         * Создаем новый объект -> JSON
         */
        MessageFromKafka messageFromKafka = new MessageFromKafka();
        messageFromKafka.setPackID(packId);
        messageFromKafka.setSystem_from(configure.getSystemFrom());
        messageFromKafka.setSystem_to(configure.getSystemTo());
        messageFromKafka.setService(service);
        messageFromKafka.setPack(message);
        logger.info(".");
        logger.info("UsbLog:Сообщение в топик зибель:{}", configure.getSiebelTopic());
        logger.info("UsbLog: POJO {}", messageFromKafka);
        logger.info("..");
        String jsonToSiebel = mapperMessSiebel.getJsonToStr(messageFromKafka);

        return kafkaProducerService.sendMessage(configure.getSiebelTopic(), jsonToSiebel);
    }
}
