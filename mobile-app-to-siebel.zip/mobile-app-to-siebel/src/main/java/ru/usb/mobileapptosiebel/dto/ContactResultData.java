package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

/**
 * id	Идентификатор, первичный ключ
 * job_id	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)
 * client_id	Связь с клиентом
 * debt_id	Идентификатор долга
 * node_id	Результат задачи (ID - последний узел дерева) заполняется, если контакт был добавлен с МП
 * contact_type	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
 * contact_date	Дата контакта
 * description	Адрес/телефон/онлайн контакт на котором была коммуникация
 * result	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)
 * comment	Комментарий к контакту
 * payment_amount	Сумма обещанного платежа
 * payment_date	Дата обещанного платежа
 * no_sale_reason	Описание причины
 * createdTimestamp	Дата и время создания объекта на МП
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactResultData {

    @JsonProperty("jobid")
    private String jobid; //	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)

    @JsonProperty("clientId")
    private String clientId; //	Связь с клиентом

    @JsonProperty("debtid")
    private String debtid; //	Идентификатор долга

    @JsonProperty("nodeid")
    private String nodeid; //	Результат задачи (ID - последний узел дерева) заполняется, если контакт был добавлен с МП

    @JsonProperty("contacttype")
    private String contacttype; //	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)

    @JsonProperty("contactdate")
    private String contactdate; //	Дата контакта

    @JsonProperty("description")
    private String description; //	Адрес/телефон/онлайн контакт на котором была коммуникация

    @JsonProperty("result")
    private String result; //	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)
    @JsonProperty("createdTimestamp")
    private String createdTimestamp; //	Дата и время создания объекта на МП

    @JsonProperty("fields")
    private ArrayList<Field> fields;

    public ContactResultData() {
        //
    }

    public ArrayList<Field> getFields() {
        return fields;
    }

    public void setFields(ArrayList<Field> fields) {
        this.fields = fields;
    }

    public String getJobid() {
        return jobid;
    }

    public void setJobid(String jobid) {
        this.jobid = jobid;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getDebtid() {
        return debtid;
    }

    public void setDebtid(String debtid) {
        this.debtid = debtid;
    }

    public String getNodeid() {
        return nodeid;
    }

    public void setNodeid(String nodeid) {
        this.nodeid = nodeid;
    }

    public String getContacttype() {
        return contacttype;
    }

    public void setContacttype(String contacttype) {
        this.contacttype = contacttype;
    }

    public String getContactdate() {
        return contactdate;
    }

    public void setContactdate(String contactdate) {
        this.contactdate = contactdate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @Override
    public String toString() {
        return "ContactResultData{" +
                ", jobid='" + jobid + '\'' +
                ", clientId='" + clientId + '\'' +
                ", debtid='" + debtid + '\'' +
                ", nodeid='" + nodeid + '\'' +
                ", contacttype='" + contacttype + '\'' +
                ", contactdate='" + contactdate + '\'' +
                ", description='" + description + '\'' +
                ", result='" + result + '\'' +
                ", createdTimestamp='" + createdTimestamp + '\'' +
                ", fields=" + fields +
                '}';
    }
}
