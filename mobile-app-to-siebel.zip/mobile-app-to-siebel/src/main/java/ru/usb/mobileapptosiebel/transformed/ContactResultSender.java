package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.ContactResultData;
import ru.usb.mobileapptosiebel.mapper.ContactResultMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class ContactResultSender {
    Logger logger = LoggerFactory.getLogger(ContactResultSender.class);
    private final ContactResultMap contactResultMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public ContactResultSender(ContactResultMap contactResultMap,
                               AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.contactResultMap = contactResultMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        ContactResultData contactResult = contactResultMap.messageMapper(messageString);

        if (contactResult == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.contact_result : {}", contactResult);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         *  service - Siebel.contact_result
         * Поле	Формат данных от МП	Формат данных для SIebel
         * contact_date	формат javatime количество миллисекунд прошедших с 1970 года	MM/DD/YYYY HH24:MI:SS
         * created_timestamp	формат javatime количество миллисекунд прошедших с 1970 года	MM/DD/YYYY HH24:MI:SS
         */

        //created_timestamp
        if (aux.checkUnixDateTime(contactResult.getCreated_timestamp())) {
            contactResult.setCreated_timestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(contactResult.getCreated_timestamp())));
        }
        //data.contact_date
        if (aux.checkUnixDateTime(contactResult.getContactdate())) {
            contactResult.setContactdate(aux.getDateSiebelFormatString(aux.parseUnixDate(contactResult.getContactdate())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(contactResultMap.getJsonToStr(contactResult)), configure.getServiceContactResult())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
