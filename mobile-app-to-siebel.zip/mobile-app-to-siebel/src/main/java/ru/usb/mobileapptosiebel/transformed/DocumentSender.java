package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.Document;
import ru.usb.mobileapptosiebel.mapper.DocumentMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class DocumentSender {
    Logger logger = LoggerFactory.getLogger(DocumentSender.class);
    private final DocumentMap documentMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public DocumentSender(DocumentMap documentMap, AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.documentMap = documentMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        Document document = documentMap.messageMapper(messageString);

        if (document == null || document.getData() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.document : {}", document);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */

        //created_timestamp
        if (aux.checkUnixDateTime(document.getData().getCreatedTimestamp())) {
            document.getData().setCreatedTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(document.getData().getCreatedTimestamp())));
        }

        //timestamp
        if (aux.checkUnixDateTime(document.getTimestamp())){
            document.setTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(document.getTimestamp())));
        }

        //actionTimestamp
        if (aux.checkUnixDateTime(document.getActionTimestamp())){
            document.setActionTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(document.getActionTimestamp())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(documentMap.getJsonToStr(document)), configure.getServiceDocument(), aux.getUUID())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
