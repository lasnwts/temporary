package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *  * {
 *  *    "externalId":"1-IHMYC9U",
 *  *    "internalId":"",
 *  *    "data":{
 *  *       "owner":"",
 *  *       "created_timestamp":"11/28/2023 07:33:12",
 *  *       "phone_number":"9119090567",
 *  *       "client_id":"1-23RH4S-25",
 *  *       "phone_type_id":"0V-RKYNX",
 *  *       "description":"",
 *  *       "sms_on":"true",
 *  *       "id":"1-23RH7Q-484"
 *  *    }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Phone {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;

    @JsonProperty("userLogin")
    private String userLogin;

    @JsonProperty("timestamp")
    private String timestamp;

    @JsonProperty("created_timestamp")
    private String created_timestamp;
    @JsonProperty("data")
    private PhoneData data;

    public Phone(String externalId, String internalId, PhoneData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.data = data;
    }

    public Phone(String externalId, String internalId, String userLogin, String timestamp, String created_timestamp, PhoneData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.userLogin = userLogin;
        this.timestamp = timestamp;
        this.created_timestamp = created_timestamp;
        this.data = data;
    }

    public Phone() {
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public PhoneData getData() {
        return data;
    }

    public void setData(PhoneData data) {
        this.data = data;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "externalId='" + externalId + '\'' +
                ", internalId='" + internalId + '\'' +
                ", userLogin='" + userLogin + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                ", data=" + data +
                '}';
    }
}
