package ru.usb.mobileapptosiebel.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    /**
     * Топик для отправки сообщения в iebel
     */
    @Value("${siebel.topic:siebel-kafka-router.in}")
    private String siebelTopic;

    /**
     * Параметры Json сообщения для Siebel
     * system.from=MP-Hard
     * system.to=siebel
     */
    @Value("${system.from:MP-Hard}")
    private String systemFrom;

    @Value("${system.to:siebel}")
    private String systemTo;

    /**
     * Kafka Listener
     * kafka.consumer.topic.address=external.out.address.json
     * kafka.service.address=Siebel.address
     * # 2.
     * kafka.consumer.topic.phone=external.out.address.json
     * kafka.service.phone=Siebel.phone
     * # 3.
     * kafka.consumer.topic.document=external.out.address.json
     * kafka.service.document=Siebel.document
     * # 4.
     * kafka.consumer.topic.job=external.out.address.json
     * kafka.service.job=Siebel.job
     * # 5.
     * kafka.consumer.topic.contact-result=external.out.address.json
     * kafka.service.contact-result=Siebel.contact_result
     */

    @Value("${kafka.consumer.topic.address}")
    private String topicAddress;
    @Value("${kafka.service.address}")
    private String serviceAddress;

    @Value("${kafka.consumer.topic.phone}")
    private String topicPhone;
    @Value("${kafka.service.phone}")
    private String servicePhone;

    @Value("${kafka.consumer.topic.document}")
    private String topicDocument;
    @Value("${kafka.service.document}")
    private String serviceDocument;

    @Value("${kafka.consumer.topic.job}")
    private String topicJob;
    @Value("${kafka.service.job}")
    private String serviceJob;

    @Value("${kafka.consumer.topic.contact-result}")
    private String topicContactResult;
    @Value("${kafka.service.contact-result}")
    private String serviceContactResult;

    @Value("${kafka.consumer.topic.other-contact}")
    private String topicOtherContact;
    @Value("${kafka.service.other-contact}")
    private String serviceOtherContact;

    /**
     * Application properties
     */

    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.application.version}")
    private String appVersion;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;


    /**
     * Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * service.log.debug
     * Детализация лога
     */
    @Value("${service.log.debug}")
    private boolean logDebug;


    /**
     * Security in properties     *
     */


    /**
     * Реализация)
     */
    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public boolean isLogDebug() {
        return logDebug;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    /**
     * Реализация топиков
     */
    public String getTopicAddress() {
        return topicAddress;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public String getTopicPhone() {
        return topicPhone;
    }

    public String getServicePhone() {
        return servicePhone;
    }

    public String getTopicDocument() {
        return topicDocument;
    }

    public String getServiceDocument() {
        return serviceDocument;
    }

    public String getTopicJob() {
        return topicJob;
    }

    public String getServiceJob() {
        return serviceJob;
    }

    public String getTopicContactResult() {
        return topicContactResult;
    }

    public String getServiceContactResult() {
        return serviceContactResult;
    }

    /**
     * Реализация для Siebel
     */

    public String getSystemFrom() {
        return systemFrom;
    }

    public String getSystemTo() {
        return systemTo;
    }

    public String getSiebelTopic() {
        return siebelTopic;
    }

    public String getTopicOtherContact() {
        return topicOtherContact;
    }

    public String getServiceOtherContact() {
        return serviceOtherContact;
    }
}
