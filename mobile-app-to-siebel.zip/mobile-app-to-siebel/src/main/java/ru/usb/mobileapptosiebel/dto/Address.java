package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address {
    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;
    @JsonProperty("userLogin")
    private String userLogin;

    @JsonProperty("timestamp")
    private String timestamp;

    @JsonProperty("actionTimestamp")
    private String actionTimestamp;

    @JsonProperty("data")
    private AddressData data;

    public Address() {
        //
    }

    public Address(String externalId, AddressData data) {
        this.externalId = externalId;
        this.data = data;
    }

    public Address(String externalId, String userLogin, String timestamp, String actionTimestamp, AddressData data) {
        this.externalId = externalId;
        this.userLogin = userLogin;
        this.timestamp = timestamp;
        this.actionTimestamp = actionTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public AddressData getData() {
        return data;
    }

    public void setData(AddressData data) {
        this.data = data;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public String getActionTimestamp() {
        return actionTimestamp;
    }

    public void setActionTimestamp(String actionTimestamp) {
        this.actionTimestamp = actionTimestamp;
    }

    @Override
    public String toString() {
        return "Address{" +
                "externalId='" + externalId + '\'' +
                ", userLogin='" + userLogin + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", data=" + data +
                '}';
    }
}
