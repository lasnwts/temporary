package ru.usb.mobileapptosiebel;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.mobileapptosiebel.config.Configure;


@SpringBootApplication
public class MobileAppToSiebelApplication implements CommandLineRunner {
	Logger logger = LoggerFactory.getLogger(MobileAppToSiebelApplication.class);
	private final Configure configure;
	@Autowired
	public MobileAppToSiebelApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(MobileAppToSiebelApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API Project 3197. Service Mobile-App to Siebel")
				.version(appVersion)
				.description("Проект 3197. Обмен между Мобильным приложением и Siebel." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {

		logger.info("+---------------------------------------------------------------------------------------------------------+");
		logger.info(" Created by 27.11.2023   : initial version: 0.0.1");
		logger.info("-----------------------------------------------------------------------------------------------------------");
		logger.info("| Name of service        :{}", configure.getAppName());
		logger.info("| Description of service :{}", configure.getAppDescription());
		logger.info("=---------------------------------------------------------------------------------------------------------=");
		logger.info("| Modified reason        :{}", "none");
		logger.info("---------------------------------------------------------------------------------------------------------");
	}

	/**
	 * kafka-console-producer --broker-list localhost:9092 --topic test
	 * kafka-console-consumer --bootstrap-server localhost:9092 --topic test --from-beginning
	 *
	 * kafka-server-start.bat c:\AppServer\Kafka\kafka_2.12-3.2.0\config\server.properties
	 * zookeeper-server-start.bat C:\AppServer\Kafka\kafka_2.12-3.2.0\config\zookeeper.properties
	 */
}
