package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.OtherContactData;
import ru.usb.mobileapptosiebel.mapper.OtherContactMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class OtherContactSender {
    Logger logger = LoggerFactory.getLogger(OtherContactSender.class);
    private final OtherContactMap contactMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public OtherContactSender(OtherContactMap contactMap, AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.contactMap = contactMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        OtherContactData otherContactData = contactMap.messageMapper(messageString);

        if (otherContactData == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.other_contact : {}", otherContactData);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */

        //created_timestamp
        if (aux.checkUnixDateTime(otherContactData.getCreated_timestamp())) {
            otherContactData.setCreated_timestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(otherContactData.getCreated_timestamp())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(contactMap.getJsonToStr(otherContactData)), configure.getServiceOtherContact())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
