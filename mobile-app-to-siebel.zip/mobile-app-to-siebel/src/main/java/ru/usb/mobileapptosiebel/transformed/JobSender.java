package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.Job;
import ru.usb.mobileapptosiebel.dto.JobData;
import ru.usb.mobileapptosiebel.mapper.JobMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class JobSender {
    Logger logger = LoggerFactory.getLogger(JobSender.class);
    private final JobMap jobMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public JobSender(JobMap jobMap,
                               AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.jobMap = jobMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        Job job = jobMap.messageMapper(messageString);

        if (job == null || job.getData() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.job : {}", job);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */
        //timestamp
        if (aux.checkUnixDateTime(job.getTimestamp())){
            job.setTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(job.getTimestamp())));
        }

        //actionTimestamp
        if (aux.checkUnixDateTime(job.getActionTimestamp())){
            job.setActionTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(job.getActionTimestamp())));
        }

        //created_timestamp
        if (aux.checkUnixDateTime(job.getData().getCreatedTimestamp())) {
            job.getData().setCreatedTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(job.getData().getCreatedTimestamp())));
        }
        //jobDate
        if (aux.checkUnixDateTime(job.getData().getJobDate())) {
            job.getData().setJobDate(aux.getDateSiebelFormatString(aux.parseUnixDate(job.getData().getJobDate())));
        }
        //contact_date_time
        if (aux.checkUnixDateTime(job.getData().getContactDateTime())) {
            job.getData().setContactDateTime(aux.getDateSiebelFormatString(aux.parseUnixDate(job.getData().getContactDateTime())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(jobMap.getJsonToStr(job)), configure.getServiceJob(), aux.getUUID())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
