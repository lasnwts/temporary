package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.JobData;
import ru.usb.mobileapptosiebel.mapper.JobMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class JobSender {
    Logger logger = LoggerFactory.getLogger(JobSender.class);
    private final JobMap jobMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public JobSender(JobMap jobMap,
                               AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.jobMap = jobMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        JobData jobData = jobMap.messageMapper(messageString);

        if (jobData == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.job : {}", jobData);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */

        //created_timestamp
        if (aux.checkUnixDateTime(jobData.getCreated_timestamp())) {
            jobData.setCreated_timestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(jobData.getCreated_timestamp())));
        }
        //jobDate
        if (aux.checkUnixDateTime(jobData.getJob_date())) {
            jobData.setJob_date(aux.getDateSiebelFormatString(aux.parseUnixDate(jobData.getJob_date())));
        }
        //contact_date_time
        if (aux.checkUnixDateTime(jobData.getContact_date_time())) {
            jobData.setContact_date_time(aux.getDateSiebelFormatString(aux.parseUnixDate(jobData.getContact_date_time())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(jobMap.getJsonToStr(jobData)), configure.getServiceJob())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
