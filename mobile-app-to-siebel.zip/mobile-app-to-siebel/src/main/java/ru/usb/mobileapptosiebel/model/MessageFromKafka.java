package ru.usb.mobileapptosiebel.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Сообщение универсально для Зибель
 * JSON-схема универсального запроса:
 * <p>
 * {
 * "system_from":"string",
 * "system_to":"string",
 * "service":"string",
 * "routeID":"string",
 * "mapper":"integer",
 * "packID":"string",
 * "pack":"string"
 * "error":"integer"
 * "errortext":"string"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class MessageFromKafka {

    @JsonProperty("system_from")
    private String system_from;

    @JsonProperty("system_to")
    private String system_to;

    @JsonProperty("service")
    private String service;

    @JsonProperty("routeid")
    private String routeID;

    @JsonProperty("mapper")
    private String mapper;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String errortext;

    public MessageFromKafka() {
        //none
    }

    public String getSystem_from() {
        return system_from;
    }

    public void setSystem_from(String system_from) {
        this.system_from = system_from;
    }

    public String getSystem_to() {
        return system_to;
    }

    public void setSystem_to(String system_to) {
        this.system_to = system_to;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getRouteID() {
        return routeID;
    }

    public void setRouteID(String routeID) {
        this.routeID = routeID;
    }

    public String getMapper() {
        return mapper;
    }

    public void setMapper(String mapper) {
        this.mapper = mapper;
    }

    public String getPackID() {
        return packID;
    }

    public void setPackID(String packID) {
        this.packID = packID;
    }

    public String getPack() {
        return pack;
    }

    public void setPack(String pack) {
        this.pack = pack;
    }

    public String getError() {
        if (error == null) {
            return "";
        } else {
            return error;
        }
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrortext() {
        return errortext;
    }

    public void setErrortext(String errortext) {
        this.errortext = errortext;
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }


    public String toShortString() {
        return "{" +
                "system_from='" + getWrapNull(system_from) + '\'' +
                ", system_to='" + getWrapNull(system_to) + '\'' +
                ", service='" + getWrapNull(service) + '\'' +
                ", routeID='" + getWrapNull(routeID) + '\'' +
                ", mapper='" + getWrapNull(mapper) + '\'' +
                ", packID='" + getWrapNull(packID) + '\'' +
                ", pack[length] ='" + getWrapNull(pack).trim().length() + '\'' +
                ", error='" + getWrapNull(error) + '\'' +
                ", errortext='" + getWrapNull(errortext) + '\'' +
                '}';
    }

    @Override
    public String toString() {
        return "{" +
                "system_from='" + getWrapNull(system_from) + '\'' +
                ", system_to='" + getWrapNull(system_to) + '\'' +
                ", service='" + getWrapNull(service) + '\'' +
                ", routeID='" + getWrapNull(routeID) + '\'' +
                ", mapper='" + getWrapNull(mapper) + '\'' +
                ", packID='" + getWrapNull(packID) + '\'' +
                ", pack= '" + getWrapNull(pack) + '\'' +
                ", error='" + getWrapNull(error) + '\'' +
                ", errortext='" + getWrapNull(errortext) + '\'' +
                '}';
    }
}
