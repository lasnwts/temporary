package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 №	Поле	Название поля	Тип данных
 Обязательность
 1.	id	Идентификатор документа, первичный ключ	UUID
 +
 2.	createdTimestamp	Дата и время создания объекта в МП	timestamp with time zone
 +
 3.	debtId	Связь может быть как с долгом, так и с клиентом (например первичные документы по долгу)	UUID
 4.	clientId	Вычисляемое поле, зависит от типа документа (прикреплять clientId если это запись разговора), или фото клиента	UUID
 +
 5.	name	Называние документа	varchar(1024)
 +
 6.	contentUri	Адрес/ссылка на источник документа	varchar(1024)
 +
 7.	documentTypeId	Справочник типа документа, связь с document_type	UUID
 +

 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentData {
    @JsonProperty("createdTimestamp")
    private String createdTimestamp;

    @JsonProperty("debtId")
    private String debtId;

    @JsonProperty("clientId")
    private String clientId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("contentUri")
    private String contentUri;

    @JsonProperty("documentTypeId")
    private String documentTypeId;

    public DocumentData() {
        //
    }

    public DocumentData(String createdTimestamp, String debtId, String clientId, String name,
                        String contentUri, String documentTypeId) {
        this.createdTimestamp = createdTimestamp;
        this.debtId = debtId;
        this.clientId = clientId;
        this.name = name;
        this.contentUri = contentUri;
        this.documentTypeId = documentTypeId;
    }
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getDebtId() {
        return debtId;
    }

    public void setDebtId(String debtId) {
        this.debtId = debtId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContentUri() {
        return contentUri;
    }

    public void setContentUri(String contentUri) {
        this.contentUri = contentUri;
    }

    public String getDocumentTypeId() {
        return documentTypeId;
    }

    public void setDocumentTypeId(String documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    @Override
    public String toString() {
        return "DocumentData{" +
                ", createdTimestamp='" + createdTimestamp + '\'' +
                ", debtId='" + debtId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", name='" + name + '\'' +
                ", contentUri='" + contentUri + '\'' +
                ", documentTypeId='" + documentTypeId + '\'' +
                '}';
    }
}
