package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.kafka.common.protocol.types.Field;

/**
 *
 №	Поле	Название поля	Тип данных
 Обязательность
 1.	id	Идентификатор документа, первичный ключ	UUID
 +
 2.	created_timestamp	Дата и время создания объекта в МП	timestamp with time zone
 +
 3.	debt_id	Связь может быть как с долгом, так и с клиентом (например первичные документы по долгу)	UUID
 4.	client_id	Вычисляемое поле, зависит от типа документа (прикреплять client_id если это запись разговора), или фото клиента	UUID
 +
 5.	name	Называние документа	varchar(1024)
 +
 6.	content_uri	Адрес/ссылка на источник документа	varchar(1024)
 +
 7.	document_type_id	Справочник типа документа, связь с document_type	UUID
 +

 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentData {

    @JsonProperty("id")
    private String id;

    @JsonProperty("created_timestamp")
    private String created_timestamp;

    @JsonProperty("debt_id")
    private String debt_id;

    @JsonProperty("client_id")
    private String client_id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("content_uri")
    private String content_uri;

    @JsonProperty("document_type_id")
    private String document_type_id;

    public DocumentData() {
    }

    public DocumentData(String id, String created_timestamp, String debt_id, String client_id, String name,
                        String content_uri, String document_type_id) {
        this.id = id;
        this.created_timestamp = created_timestamp;
        this.debt_id = debt_id;
        this.client_id = client_id;
        this.name = name;
        this.content_uri = content_uri;
        this.document_type_id = document_type_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    public String getDebt_id() {
        return debt_id;
    }

    public void setDebt_id(String debt_id) {
        this.debt_id = debt_id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent_uri() {
        return content_uri;
    }

    public void setContent_uri(String content_uri) {
        this.content_uri = content_uri;
    }

    public String getDocument_type_id() {
        return document_type_id;
    }

    public void setDocument_type_id(String document_type_id) {
        this.document_type_id = document_type_id;
    }

    @Override
    public String toString() {
        return "DocumentData{" +
                "id='" + id + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                ", debt_id='" + debt_id + '\'' +
                ", client_id='" + client_id + '\'' +
                ", name='" + name + '\'' +
                ", content_uri='" + content_uri + '\'' +
                ", document_type_id='" + document_type_id + '\'' +
                '}';
    }
}
