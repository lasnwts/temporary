package ru.usb.mobileapptosiebel.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.mobileapptosiebel.service.mail.ServiceMailError;
import ru.usb.mobileapptosiebel.transformed.JobSender;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Configuration
@EnableKafka
public class KafkaListenerServiceJob {
    Logger logger = LoggerFactory.getLogger(KafkaListenerServiceJob.class);
    private final ServiceMailError serviceMailError;
    private final AuxMethods aux;
    private final JobSender jobSender;

    @Autowired
    public KafkaListenerServiceJob(ServiceMailError serviceMailError, AuxMethods aux, JobSender jobSender) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.jobSender = jobSender;
    }

    @Value("${service.log.debug:false}")
    private boolean logDebug;

    @KafkaListener(topics = "${kafka.consumer.topic.job}", containerFactory = "kafkaListenerContainerFactory", groupId = "${spring.kafka.consumer.group-id}")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {
        if (logDebug) {
            logger.info("UsbLog:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener (record.value)    == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:-+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++**********+++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++**********++++++++++++++++++++++++");
        }

        /**
         * Сообщение забираем по любому
         */
        ack.acknowledge();

        /**
         * Сообщение по Kafka, готовим
         */
        String message;
        message = recordKafka.value();

        if (message == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!");
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:-+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++**********++++++++++");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()));
        } else {
            /**
             * Основная обработка
             * Отправка сообщения в ЦФТ
             */
            try {
                /**
                 * Преобразуем сообщение
                 */
                if (jobSender.getTransformSend(message)) {
                    logger.info("UsbLog: обработка сообщения успешно завершена: {}", message);
                } else {
                    logger.error("UsbLOg: Сообщение не обработано, возникла проблема: {}", message);
                }
            } catch (Exception exceptionKafkaProcessed) {
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Kafka process catch)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("UsbLog: StackTrace:", exceptionKafkaProcessed);
            }
        }
    }
}
