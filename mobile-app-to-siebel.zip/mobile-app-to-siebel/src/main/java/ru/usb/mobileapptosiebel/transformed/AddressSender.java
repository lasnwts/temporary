package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.Address;
import ru.usb.mobileapptosiebel.mapper.AddressMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class AddressSender {
    Logger logger = LoggerFactory.getLogger(AddressSender.class);
    private final AddressMap addressMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public AddressSender(AddressMap addressMap, AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.addressMap = addressMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        Address address = addressMap.messageMapper(messageString);

        if (address == null || address.getData() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.address : {}", address);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         *  timestamp
         */
        //timestamp
        if (aux.checkUnixDateTime(address.getTimestamp())){
        address.setTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(address.getTimestamp())));
        }

        //actionTimestamp
        if (aux.checkUnixDateTime(address.getActionTimestamp())){
            address.setActionTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(address.getActionTimestamp())));
        }

        //created_timestamp
        if (aux.checkUnixDateTime(address.getData().getCreatedTimestamp())) {
            address.getData().setCreatedTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(address.getData().getCreatedTimestamp())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(addressMap.getJsonToStr(address)), configure.getServiceAddress(), aux.getUUID())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
