package ru.usb.mobileapptosiebel.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.dto.DocumentData;
import ru.usb.mobileapptosiebel.utils.Utilites;

@Component
public class DocumentMap {
    Logger logger = LoggerFactory.getLogger(DocumentMap.class);
    private final Utilites utilites;
    @Autowired
    public DocumentMap(Utilites utilites) {
        this.utilites = utilites;
    }
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Мапинг строки в объект MessageFromKafka
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public DocumentData messageMapper(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [Document]: поступил объект [message] == NULL! Класс [Document]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        DocumentData document = null;

        try {
            document = objectMapper.readValue(utilites.wrapNullJson(message), DocumentData.class);
            logger.info("Object [Document]:{}", document);
            return document;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Преобразование объекта в строку JSON
     * @param document объект
     * @return - строка Json
     */
    public String getJsonToStr(DocumentData document) {

        if (document == null) {
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [document] == NULL! Класс [document] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(document);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [document] в JSON строку!");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:Описание ошибки:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
