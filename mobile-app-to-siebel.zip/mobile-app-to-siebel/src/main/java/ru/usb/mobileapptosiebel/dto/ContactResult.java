package ru.usb.mobileapptosiebel.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactResult {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;

    @JsonProperty("userLogin")
    private String userLogin;

    @JsonProperty("timestamp")
    private String timestamp;

    @JsonProperty("created_timestamp")
    private String created_timestamp;

    @JsonProperty("data")
    private ContactResultData data;

    public ContactResult() {
    }

    public ContactResult(String externalId, String internalId, String userLogin, String timestamp, String created_timestamp, ContactResultData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.userLogin = userLogin;
        this.timestamp = timestamp;
        this.created_timestamp = created_timestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public ContactResultData getData() {
        return data;
    }

    public void setData(ContactResultData data) {
        this.data = data;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    @Override
    public String toString() {
        return "ContactResult{" +
                "externalId='" + externalId + '\'' +
                ", internalId='" + internalId + '\'' +
                ", userLogin='" + userLogin + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", data=" + data +
                '}';
    }
}
