package ru.usb.mobileapptosiebel.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Класс вспомогательных методов
 */
@Component
public class AuxMethods {
    Logger logger = LoggerFactory.getLogger(AuxMethods.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Исключение пустых полей из сообщения SD
     * Как пример: "init_sapid": , замена на "init_sapid": "",
     * -------------------------------------------------------
     * {
     * "source": "SD_WFSCALL",
     * "ser_id": 14138584,
     * "init_sapid": ,
     * "init_tab_number": ,
     * "reg_created": "2023-06-09T08:50:09.000Z",
     * "deadline": ,
     * "status": "В работе",
     * "classification": "Служба финансового мониторинга / Запрос Контакт-Центра КиМБ / Заявка КЦ SMS / Процессинг",
     * "wfs_id": 1.12089e+06,
     * "wfs_start_time": "2023-06-09T09:59:57.000Z",
     * "wfs_name": "Ожидание"
     * }
     * -------------------------------------------------------
     *
     * @param message
     * @return
     */
    public String wrapNullJson(String message) {

        String messagePrepared = null;

        if (message == null) {
            return "";
        }

        if (message.contains(": ,") || message.contains(":,") || message.contains(":  ,") || message.contains(":   ,")) {
            logger.info("Сообщение содержит пустое значение в поле, что делает невозможным его распознавание[: ,]");
            logger.info("Сообщение будет модифицировано - значение =[: ,], будет заменено на строковое пустое, знак двойной кавычки");
            logger.info("Входящее сообщение, до модификации [message]:{}", message);
            String replacement = ":\"\",";
            messagePrepared = message.replace(": ,", replacement);
            messagePrepared = messagePrepared.replace(":,", replacement);
            messagePrepared = messagePrepared.replace(":  ,", replacement);
            messagePrepared = messagePrepared.replace(":   ,", replacement);
            logger.info("Обработанное сообщение [message]:{}", messagePrepared);
            return messagePrepared;
        } else {
            return message;
        }

    }


}
