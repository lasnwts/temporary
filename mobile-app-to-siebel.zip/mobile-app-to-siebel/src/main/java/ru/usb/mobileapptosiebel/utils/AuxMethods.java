package ru.usb.mobileapptosiebel.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Класс вспомогательных методов
 */
@Component
public class AuxMethods {
    Logger logger = LoggerFactory.getLogger(AuxMethods.class);

    /**
     * Форматы дат
     */
    private final DateFormat siebelTimeFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    private final DateFormat mpDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Исключение пустых полей из сообщения SD
     * Как пример: "init_sapid": , замена на "init_sapid": "",
     * -------------------------------------------------------
     * {
     * "source": "SD_WFSCALL",
     * "ser_id": 14138584,
     * "init_sapid": ,
     * "init_tab_number": ,
     * "reg_created": "2023-06-09T08:50:09.000Z",
     * "deadline": ,
     * "status": "В работе",
     * "classification": "Служба финансового мониторинга / Запрос Контакт-Центра КиМБ / Заявка КЦ SMS / Процессинг",
     * "wfs_id": 1.12089e+06,
     * "wfs_start_time": "2023-06-09T09:59:57.000Z",
     * "wfs_name": "Ожидание"
     * }
     * -------------------------------------------------------
     *
     * @param message
     * @return
     */
    public String wrapNullJson(String message) {

        String messagePrepared = null;

        if (message == null) {
            return "";
        }

        if (message.contains(": ,") || message.contains(":,") || message.contains(":  ,") || message.contains(":   ,")) {
            logger.info("Сообщение содержит пустое значение в поле, что делает невозможным его распознавание[: ,]");
            logger.info("Сообщение будет модифицировано - значение =[: ,], будет заменено на строковое пустое, знак двойной кавычки");
            logger.info("Входящее сообщение, до модификации [message]:{}", message);
            String replacement = ":\"\",";
            messagePrepared = message.replace(": ,", replacement);
            messagePrepared = messagePrepared.replace(":,", replacement);
            messagePrepared = messagePrepared.replace(":  ,", replacement);
            messagePrepared = messagePrepared.replace(":   ,", replacement);
            logger.info("Обработанное сообщение [message]:{}", messagePrepared);
            return messagePrepared;
        } else {
            return message;
        }

    }

    /**
     * Проверка соответствия даты определенному формату MM/dd/yyyy HH:mm:ss
     *
     * @param date - строка с датой
     * @return - true - соответствует. false -нет
     */
    public boolean checkDateTime(String date) {
        if (date != null) {
            try {
                parseDate(date, mpDateFormat);
                return true;
            } catch (Exception ex) {
                logger.error("UsbLog: Переданная дата={} - не соответствует формату YYYY-MM-DD", date);
                return false;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL[checkDateTime]");
            return false;
        }
    }

    /**
     * Преобразовение даты из строки в Date
     *
     * @param date - строка в виде даты
     * @return - Date
     */
    public Date parseDate(String date, DateFormat df) {
        if (date != null) {
            try {
                return df.parse(date);
            } catch (ParseException e) {
                logger.error("UsbLog: parseDate => Переданная дата={} - не соответствует формату YYYY-MM-DD", date);
                return null;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL");
            return null;
        }
    }

    /**
     * Проверка соответствия даты определенному формату 1224535654654
     *
     * @param unixDateTime - строка с датой
     * @return - true - соответствует. false -нет
     */
    public boolean checkUnixDateTime(String unixDateTime) {
        if (unixDateTime != null) {
            try {
                parseUnixDate(unixDateTime);
                return true;
            } catch (Exception ex) {
                logger.error("UsbLog: parseDate => Переданная дата[тип Long]={} - не распарсилась в дату", unixDateTime);
                return false;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL[checkDateTime]");
            return false;
        }
    }

    /**
     * Получаем дату из Unix Date Time строки
     *
     * @param unixdateTime - строка с LOng
     * @return - Дата
     */
    public Date parseUnixDate(String unixdateTime) {
        if (unixdateTime != null) {
            try {
                return new java.util.Date(Long.parseLong(unixdateTime));
            } catch (Exception exception) {
                logger.error("UsbLog: parseDate => Переданная дата[тип Long]={} - не распарсилась в дату", unixdateTime);
                return null;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL");
            return null;
        }
    }

    /**
     * Получаем дату в формате Зибель
     *
     * @param date - дата
     * @return - строка в формате Зибель
     */
    public String getDateSiebelFormatString(Date date) {
        return siebelTimeFormat.format(date);
    }

}
