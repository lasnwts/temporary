package ru.usb.test_sql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
