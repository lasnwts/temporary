package ru.usb.test_sql;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@SpringBootApplication
public class TestSqlApplication implements CommandLineRunner {

    // JDBC URL, username, and password of MySQL server
//    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
//    private static final String USERNAME = "username";
//    private static final String PASSWORD = "password";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // JDBC variables
    private static Connection connection = null;
    private static Statement statement = null;
    private static ResultSet resultSet = null;

	public static void main(String[] args) {
		SpringApplication.run(TestSqlApplication.class, args);
	}

    @Override
    public void run(String... args) throws Exception {
        try {
            // set Fetch Size
            int fetchSize = 100; // adjust fetch size according to your requirements


            // open a connection
          //  connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // set fetch size before executing the query
//            statement = connection.createStatement();
//            statement.setFetchSize(fetchSize);
            statement = jdbcTemplate.getDataSource().getConnection().createStatement();
            statement.setFetchSize(fetchSize);

            // execute Query
            String sql = "SELECT * FROM t_cik_partners";
            resultSet = statement.executeQuery(sql);


            // iterate Through ResultSet
            int rowCount = 0;
            while (resultSet.next()) {
                // process each row retrieved from the ResultSet
                String id = resultSet.getString("id");
                String name = resultSet.getString("f_first_name");
                String salary = resultSet.getString("region_name");
                System.out.println("ID: " + id + ", f_first_name: " + name + ", region_name: " + salary);
                rowCount++;
            }

            System.out.println("Total rows fetched: " + rowCount);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // close Resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
