package ru.usb.sosd964755;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.sosd964755.configure.Configure;

@SpringBootApplication
public class Sosd964755Application implements CommandLineRunner {

	@Autowired
	Configure configure;

	Logger logger = LoggerFactory.getLogger(Sosd964755Application.class);

	public static void main(String[] args) {
		SpringApplication.run(Sosd964755Application.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (Service Desk ->Simple One DBO)")
				.version(appVersion)
				.description("API для 2515 Корпоративный портал Единое окно в части интеграции с Service Desk." +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {

		logger.info("v.0.0.2 12.06.2023");
		logger.info("----------------------------------------------------------------------------------------------");
		logger.info("| Name of service        :" + configure.getAppName());
		logger.info("| Version of service     :" + configure.getAppVersion());
		logger.info("| Description of service :" + configure.getAppDescription());
		logger.info("----------------------------------------------------------------------------------------------");
		logger.info("");

	}
}
