package ru.usb.sosd964755.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import ru.usb.sosd964755.service.EmailServiceImpl;

@RestController
@RequestMapping("/api/mail")
@Tag(name = "Контроллер для проверки почтовой подсистемы", description = "Проверка отправки почты")
public class EmailController {

    private Logger LOG = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    EmailServiceImpl emailService;

    /**
     * Тест тправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public @ResponseBody
    ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                           @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmail(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            LOG.error("Error while sending out email..{}", mailException.getStackTrace());
            LOG.error("Error while sending out email..{}", mailException.fillInStackTrace());
            return new ResponseEntity<>("Unable to send email", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

}
