package ru.usb.sosd964755.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.sosd964755.configure.Configure;


@Configuration
@EnableKafka
public class kafkaListenerService {

    Logger logger = LoggerFactory.getLogger(kafkaListenerService.class);

    @Autowired
    Configure configure;


    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.delay:60}")
    private int serviceDelay;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> record, Acknowledgment ack) {
        if (logDebug) {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.partition) == " + record.partition());
            logger.info("KafkaListener(record.key)       == " + record.key());
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("KafkaListener(topic)            == " + record.topic());
            logger.info("KafkaListener(Offset)           == " + String.valueOf(record.offset()));
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        /**
         * Сообщение забираем по любому
         */
        ack.acknowledge();

        /**
         * Сообщение по Kafka, готовим
         */
        String message;
        message = String.valueOf(StringUtils.getBytesUtf8(record.value()));

        if (configure.isLogDebug()) {
            logger.info("Object MessageFromKafka::" + message.toString());
        }



            if (message == null) {
                logger.error("ERROR[KafkaListener(record.value)]]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error(" Сообщение из Kafka пришло пустое!!!");
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }




    }

}
