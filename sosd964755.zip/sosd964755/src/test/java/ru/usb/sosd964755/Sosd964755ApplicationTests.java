package ru.usb.sosd964755;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sosd964755ApplicationTests {

	@Test
	void contextLoads() {
	}

}
