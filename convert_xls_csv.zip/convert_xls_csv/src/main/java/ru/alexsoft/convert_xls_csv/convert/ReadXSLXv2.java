package ru.alexsoft.convert_xls_csv.convert;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;


public class ReadXSLXv2 {

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadXSLXv2.class);

    public Workbook workbook;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdDay = new SimpleDateFormat("dd");
    SimpleDateFormat sdMonth = new SimpleDateFormat("MM");
    SimpleDateFormat sdYear = new SimpleDateFormat("YYYY");
    DataFormatter dataFormatter = new DataFormatter(); //Date Formatter
    String lineSeparator = System.getProperty("line.separator");
    String fileName;
    String fileNameAttach;
    public boolean answer;
    private Date ddate;
    private Date nowDate = new Date();
    private String sDate;
    private int rowEnd;
    String sfDouble; //Преобразование double в строку

    /**
     * @param fileName       -- плоский файл подготовленный куском Java code
     * @param attachXLSXfile --  входной файл формата XLSX
     */
    public ReadXSLXv2(String fileName, String attachXLSXfile) {
        this.fileName = fileName;
        this.fileNameAttach = attachXLSXfile;
        this.answer = false;

        try {
            this.workbook = WorkbookFactory.create(new File(fileNameAttach));
        } catch (IOException | EncryptedDocumentException ex) {
            logger.error("Error ::" + ex);
        }
    }

    public void wFPP(String vParameter) {
        FileWriterPP.write(this.fileName, vParameter);
        FileWriterPP.write(this.fileName, "\t");
    }

    public String openBook(int NumberOfSheet, int BeginRecord, int EndRecord) {
        //test NumberOfSheet
        if (this.workbook.getNumberOfSheets() == 0 | this.workbook.getNumberOfSheets() < NumberOfSheet) {
            logger.info("Функция openBook. Файл :: " + fileNameAttach + " не содержит страницу с номером " + NumberOfSheet);
            return "Файл :: " + fileNameAttach + " не содержит страницу с номером " + NumberOfSheet;
        }

        //Record set end of convert
        if (EndRecord == 0) {
            this.rowEnd = 64000;
        } else {
            this.rowEnd = EndRecord;
        }

        // Get first sheet from the workbook
        Sheet sheet = this.workbook.getSheetAt(NumberOfSheet);

        // Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = sheet.iterator();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (row.getRowNum() < BeginRecord | row.getRowNum() > this.rowEnd) {
                continue;
            }
            // Get iterator to all cells of current row
            Iterator<Cell> cellIterator = row.cellIterator();
            int currentCell = 0;
            int previousCell = 0;

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();

                // Change to getCellType() if using POI 4.x
                CellType cellType = cell.getCellTypeEnum();
                currentCell = cell.getColumnIndex();

                /*
                    Проверим было ли значение
                */
                if (currentCell != 0) {
                    if (previousCell != currentCell - 1) {
                        while (previousCell < currentCell - 1) {
                            previousCell = previousCell + 1;
                            System.out.print(" ");
                            System.out.print("\t");
                            wFPP(" ");
                        }
                        previousCell = currentCell;
                    } else {
                        previousCell = currentCell;
                    }
                }

                switch (cellType) {
                    case _NONE:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;

                    case BOOLEAN:
                        System.out.print(cell.getBooleanCellValue());
                        wFPP(" ");
                        System.out.print("\t");
                        break;

                    case BLANK:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;

                    case FORMULA:
                        // Formula
                        System.out.print(cell.getCellFormula());
                        System.out.print("\t");
                        FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                        // Print out value evaluated by formula
                        System.out.print(evaluator.evaluate(cell).getNumberValue());
                        double formula = evaluator.evaluate(cell).getNumberValue();
                        wFPP(Double.toString(formula).trim());
                        break;

                    case STRING:
                        System.out.print(cell.getStringCellValue().replaceAll("\t", " "));
                        System.out.print("\t");
                        if (cell.getStringCellValue().replaceAll("\t", " ").trim().length() == 0) {
                            wFPP(" ");
                        } else {
                            wFPP(cell.getStringCellValue().replaceAll("\t", " ").trim());
                        }
                        break;

                    case NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            ddate = cell.getDateCellValue();
                            sDate = sdf.format(cell.getDateCellValue());
                            System.out.print(sDate);
                            wFPP(sDate);
                        } else {
                            sfDouble = String.format("%.0f", cell.getNumericCellValue());
                            if (sfDouble.length() == 0) {
                                wFPP(" ");
                            } else {
                                if (cell.getCellStyle().getDataFormatString().substring(0, 1).equalsIgnoreCase("#")) {
                                    sfDouble = String.format("%.8f", cell.getNumericCellValue());
                                } else {
                                    sfDouble = dataFormatter.formatCellValue(cell);
                                }
                                wFPP(sfDouble);
                            }
                        }

                        System.out.print("\t");
                        break;

                    case ERROR:
                        System.out.print("!");
                        System.out.print("\t");
                        wFPP("!");
                        break;

                    default:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;
                }

            }
            //Перевод Строки...
            System.out.println("");
            FileWriterPP.write(this.fileName, lineSeparator);
        }
        this.answer = true;
        return "0";
    }

    //Open Book for Name
    public String openBookForName(String NameOfSheet, int BeginRecord, int EndRecord) {
        //test NumberOfSheet
        if (this.workbook.getNumberOfSheets() == 0) {
            logger.info("Функция openBookForName. Файл :: " + fileNameAttach + " не содержит страницу с именем " + NameOfSheet);
            return "Файл :: " + fileNameAttach + " не содержит страницу с именем " + NameOfSheet;
        }

        //Test Name ogf Sheet
        int nrSheets = workbook.getNumberOfSheets();
        boolean SheetExists = false;
        String[] names = new String[nrSheets];
        for (int i = 0; i < nrSheets; i++) {
            names[i] = workbook.getSheetName(i);
            if (names[i].equalsIgnoreCase(NameOfSheet)) {
                SheetExists = true;
            }
        }
        if (!SheetExists) {
            logger.info("Функция openBookForName. Файл :: " + fileNameAttach + " не содержит страницу с именем " + NameOfSheet);
            return "Файл :: " + fileNameAttach + " не содержит страницу с именем " + NameOfSheet;
        }

        //Record set end of convert
        if (EndRecord == 0) {
            this.rowEnd = 64000;
        } else {
            this.rowEnd = EndRecord;
        }

        // Get first sheet from the workbook
        Sheet sheet = this.workbook.getSheet(NameOfSheet);

        // Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = sheet.iterator();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (row.getRowNum() < BeginRecord | row.getRowNum() > this.rowEnd) {
                continue;
            }
            // Get iterator to all cells of current row
            Iterator<Cell> cellIterator = row.cellIterator();
            int currentCell = 0;
            int previousCell = 0;

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();

                // Change to getCellType() if using POI 4.x
                CellType cellType = cell.getCellTypeEnum();
                currentCell = cell.getColumnIndex();

                /*
                    Проверим было ли значение
                */
                if (currentCell != 0) {
                    if (previousCell != currentCell - 1) {
                        while (previousCell < currentCell - 1) {
                            previousCell = previousCell + 1;
                            System.out.print(" ");
                            System.out.print("\t");
                            wFPP(" ");
                        }
                        previousCell = currentCell;
                    } else {
                        previousCell = currentCell;
                    }
                }

                switch (cellType) {
                    case _NONE:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;

                    case BOOLEAN:
                        System.out.print(cell.getBooleanCellValue());
                        wFPP(" ");
                        System.out.print("\t");
                        break;

                    case BLANK:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;

                    case FORMULA:
                        // Formula
                        System.out.print(cell.getCellFormula());
                        System.out.print("\t");
                        FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                        // Print out value evaluated by formula
                        System.out.print(evaluator.evaluate(cell).getNumberValue());
                        double formula = evaluator.evaluate(cell).getNumberValue();
                        wFPP(Double.toString(formula).trim());
                        break;

                    case STRING:
                        System.out.print(cell.getStringCellValue().replaceAll("\t", " "));
                        System.out.print("\t");
                        if (cell.getStringCellValue().replaceAll("\t", " ").trim().length() == 0) {
                            wFPP(" ");
                        } else {
                            wFPP(cell.getStringCellValue().replaceAll("\t", " ").trim());
                        }
                        break;

                    case NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            ddate = cell.getDateCellValue();
                            sDate = sdf.format(cell.getDateCellValue());
                            System.out.print(sDate);
                            wFPP(sDate);
                        } else {
                            sfDouble = String.format("%.0f", cell.getNumericCellValue());
                            if (sfDouble.length() == 0) {
                                wFPP(" ");
                            } else {
                                if (cell.getCellStyle().getDataFormatString().substring(0, 1).equalsIgnoreCase("#")) {
                                    sfDouble = String.format("%.8f", cell.getNumericCellValue());
                                } else {
                                    sfDouble = dataFormatter.formatCellValue(cell);
                                }
                                wFPP(sfDouble);
                            }
                        }

                        System.out.print("\t");
                        break;

                    case ERROR:
                        System.out.print("!");
                        System.out.print("\t");
                        wFPP("!");
                        break;

                    default:
                        System.out.print(" ");
                        System.out.print("\t");
                        wFPP(" ");
                        break;
                }

            }
            //Перевод Строки...
            System.out.println("");
            FileWriterPP.write(this.fileName, lineSeparator);
        }
        this.answer = true;
        return "0";
    }

    public void closeWorkBook() {
        if (this.workbook != null) {
            try {
                workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
