package ru.alexsoft.convert_xls_csv.rescontroller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.alexsoft.convert_xls_csv.config.ConfigApplication;
import ru.alexsoft.convert_xls_csv.convert.ReadXSLXv2;
import ru.alexsoft.convert_xls_csv.model.FileModel;
import ru.alexsoft.convert_xls_csv.service.uploadService;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("api/v1")
@ApiOperation(value = "Rest controller", notes = "Контроллер преобразования страниц файла XLS в CSV")
public class RescontrollerMF {

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(RescontrollerMF.class);

    //Класс для преобразования
    ReadXSLXv2 readXSLXv2;  //Класс для преобразования файла
    int BeginConvertRecord; //Начало преобразования
    int EndConvertRecord;   //Конец преобразования
    int ListConvertNumber;  //Номер страницы для преобразования
    int positionExtensiоn;   //Позиция точки в имени файла

    @Autowired
    uploadService uploadService;

    @Autowired
    ConfigApplication configApplication;

    @PostMapping("/convert")
    //Вставляем API описание
    @ApiOperation(value = "Передача файла для преобразования",
            notes = "Запись будет добавлена",
            response = FileModel.class)
    public ResponseEntity<Resource> converting(
            @ApiParam(name = "filename", value = "Имя файла Excel документа", defaultValue = "")
            @RequestParam(value = "filename", required = false, defaultValue = "") String filename,
            @ApiParam(name = "filepath", value = "Путь к файлу Excel документа", defaultValue = "")
            @RequestParam(value = "filepath", required = false, defaultValue = "") String filepath,
            @ApiParam(name = "pageName", value = "Имя листа Excel документа", required = false, defaultValue = "Лист1")
            @RequestParam(required = false, value = "pageName", defaultValue = "Лист1") String pageName,
            @ApiParam(name = "pageNumber", value = "Номер листа Excel документа", defaultValue = "0")
            @RequestParam(required = false, value = "pageNumber") String pageNumber,
            @ApiParam(name = "rowNumberBegin", value = "Номер записи на странице, с которой надо начать преобразование.", defaultValue = "0")
            @RequestParam(required = false, value = "rowNumberBegin") String rowNumberBegin,
            @ApiParam(name = "rowNumberEnded", value = "Номер записа на странице, на которой заканчиваем преобразование", defaultValue = "0")
            @RequestParam(required = false, value = "rowNumberEnded") String rowNumberEnded,
            @RequestParam(value = "file", required = false) MultipartFile file) throws IOException {
        /*
            Проверяем, если передан сам файл - ответ возвращаем в этом же сеансе
            Если file пустой, то смотрим Имя файла из переменной, пытаемся работать с этим файлом.
            И возвращаем Имя файла после преобразования
         */
        HttpHeaders headers = new HttpHeaders();

        /*
        Если передан сам файл непустой..
         */
        if (file != null) {
            //Передан файл
            File fileInput = new File(uploadService.uploadFileToServer(file));

            try {
                ListConvertNumber = Integer.parseInt(pageNumber);
            } catch (NumberFormatException ex) {
                ListConvertNumber = 0;
                logger.error("Ошибка преобразования типа pageNumber " + ex);
            }

            try {
                BeginConvertRecord = Integer.parseInt(rowNumberBegin);
            } catch (NumberFormatException ex) {
                BeginConvertRecord = 0;
                logger.error("Ошибка преобразования типа rowNumberBegin " + ex);
            }

            try {
                EndConvertRecord = Integer.parseInt(rowNumberEnded);
            } catch (NumberFormatException ex) {
                EndConvertRecord = 0;
                logger.error("Ошибка преобразования типа rowNumberEnded " + ex);
            }

            positionExtensiоn = file.getOriginalFilename().lastIndexOf(".");
            File fileoutput = new File(configApplication.getOnlyPathFile() + file.getOriginalFilename().substring(0, positionExtensiоn) + ".txt");
            fileoutput.delete();
            readXSLXv2 = new ReadXSLXv2(fileoutput.getAbsolutePath(), configApplication.getOnlyPathFile() + file.getOriginalFilename());
            if (pageName.equalsIgnoreCase("Лист1") || pageName.isEmpty()) {
                readXSLXv2.openBook(ListConvertNumber, BeginConvertRecord, EndConvertRecord);
            } else {
                readXSLXv2.openBookForName(pageName, BeginConvertRecord, EndConvertRecord);
            }
            readXSLXv2.closeWorkBook();
            fileInput.delete();

            Path path = Paths.get(fileoutput.getAbsolutePath());
            ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));

            headers.add("Content-Disposition", "attachment; filename=" + file.getOriginalFilename().substring(0, positionExtensiоn) + ".txt");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(fileoutput.length())
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } else {
            //Передано имя файла, самого файла нет
            if (filename == null) {
                filename = "";
            }
            //Передан путь к файлу
            if (filepath == null) {
                filepath = "";
            }
            /*
            Если передана ссылка на файл в сети
             */
            if (filename.isEmpty() || filename.length() < 4) {
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                        .headers(headers)
                        .contentType(MediaType.TEXT_PLAIN)
                        .body(new ByteArrayResource("Имя файла должно быть заполнено! Если вы не передаете сам файл.".getBytes(StandardCharsets.UTF_8)));
            } else {
                File fileinput = new File(filepath + "/" + filename);
                if (!fileinput.exists()) {
                    String answerError = "Файл :: " + fileinput.toString() + " не существует или недоступен сервису!";
                    return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                            .headers(headers)
                            .contentType(MediaType.TEXT_PLAIN)
                            .body(new ByteArrayResource(answerError.getBytes(StandardCharsets.UTF_8)));
                }

                try {
                    ListConvertNumber = Integer.parseInt(pageNumber);
                } catch (NumberFormatException ex) {
                    ListConvertNumber = 0;
                    logger.error("Ошибка преобразования типа pageNumber " + ex);
                }

                try {
                    BeginConvertRecord = Integer.parseInt(rowNumberBegin);
                } catch (NumberFormatException ex) {
                    BeginConvertRecord = 0;
                    logger.error("Ошибка преобразования типа rowNumberBegin " + ex);
                }

                try {
                    EndConvertRecord = Integer.parseInt(rowNumberEnded);
                } catch (NumberFormatException ex) {
                    EndConvertRecord = 0;
                    logger.error("Ошибка преобразования типа rowNumberEnded " + ex);
                }

                positionExtensiоn = filename.lastIndexOf(".");
                File fileOutput = new File(filepath + "/" + filename.substring(0, positionExtensiоn) + ".txt");
                fileOutput.delete();
                readXSLXv2 = new ReadXSLXv2(fileOutput.getAbsolutePath(), fileinput.getAbsolutePath());
                if (pageName.equalsIgnoreCase("Лист1") || pageName.isEmpty()) {
                    readXSLXv2.openBook(ListConvertNumber, BeginConvertRecord, EndConvertRecord);
                } else {
                    readXSLXv2.openBookForName(pageName, BeginConvertRecord, EndConvertRecord);
                }
                readXSLXv2.closeWorkBook();

                String answerGood = filename.substring(0, positionExtensiоn) + ".txt";
                return ResponseEntity.ok()
                        .headers(headers)
                        .contentType(MediaType.TEXT_PLAIN)
                        .body(new ByteArrayResource(answerGood.getBytes(StandardCharsets.UTF_8)));
            }
        }
    }

}
