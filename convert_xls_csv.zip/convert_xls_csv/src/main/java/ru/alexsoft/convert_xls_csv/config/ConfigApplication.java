package ru.alexsoft.convert_xls_csv.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties()
public class ConfigApplication {

    private String fullPathFile;

    @Value("${logging.level.root}")
    private String logLevel;

    @Value("${pathfile}")
    private String pathfile;

    public String getOnlyPathFile() {
        if (pathfile == null) {
            fullPathFile = "C:/AppSever/Data/transform_file/";
        } else {
            fullPathFile = pathfile;
        }

        if (fullPathFile.contains("/")) {
            if (!fullPathFile.substring(fullPathFile.length() - 1).equalsIgnoreCase("/"))
                fullPathFile = fullPathFile + "/";
        } else {
            fullPathFile = fullPathFile + "/";
        }

        return fullPathFile;
    }


    public String getFullPathFile(String filename) {
        if (pathfile == null) {
            fullPathFile = "C:/AppSever/Data/transform_file/";
        } else {
            fullPathFile = pathfile;
        }

        if (fullPathFile.contains("/")) {
            if (!fullPathFile.substring(fullPathFile.length() - 1).equalsIgnoreCase("/"))
                fullPathFile = fullPathFile + "/";
        } else {
            fullPathFile = fullPathFile + "/";
        }

        return fullPathFile+filename.trim();
    }

    //=====================
    private String uploadDir;

    public String getUploadDir() {
        return uploadDir;
    }

    public void setUploadDir(String uploadDir) {
        this.uploadDir = uploadDir;
    }

    public String getPathfile() {
        return pathfile;
    }

}
