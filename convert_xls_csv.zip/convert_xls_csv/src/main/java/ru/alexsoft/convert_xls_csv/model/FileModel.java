package ru.alexsoft.convert_xls_csv.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Файл XLS для преобразования. Эта же структура используется в качестве ответа")
public class FileModel {

    //Имя файла
    @ApiModelProperty(notes = "Имя файла для преобразования")
    private String filename;

    //Путь к файлу
    @ApiModelProperty(notes = "Каталог для файла")
    private String filepath;

    //Имя страницы
    @ApiModelProperty(notes = "Имя страницы для преобразования, если пустой, то берется номер страницы, если номера тоже нет, берется первый лист документа.")
    private String pageName;

    //Номер страницы
    @ApiModelProperty(notes = "Номер страницы для преобразования, опционально. Если нет, то берется имя страницы, если имени нет, берется первый лист документа.")
    private int pageNumber;

    //Номер записи с которой начинаем
    @ApiModelProperty(notes = "Номер записи на странице, с которой надо начать преобразование. Как правило это табличная часть. Еслои его нет, преобразование идет с первой записи листа.")
    private int rowNumberBegin;

    //Номер записи на странице для завершенеия преобразования
    @ApiModelProperty(notes = "Номер записа на странице, на которой заканчиваем преобразование, опионально. При отсутствии преобразование идет до конца листа.")
    private int rowNumberEnded;

    //Имя страницы
    @ApiModelProperty(notes = "Строка в которой выводится информация о ошибках")
    private String errorResponse;

    public FileModel() {
    }

    public FileModel(String filename, String filepath, String pageName, int pageNumber, int rowNumberBegin, int rowNumberEnded) {
        this.filename = filename;
        this.filepath = filepath;
        this.pageName = pageName;
        this.pageNumber = pageNumber;
        this.rowNumberBegin = rowNumberBegin;
        this.rowNumberEnded = rowNumberEnded;
    }

    @Override
    public String toString() {
        return "FileModel{" +
                "filename='" + filename + '\'' +
                "filepath='" + filepath + '\'' +
                ", pageName='" + pageName + '\'' +
                ", pageNumber=" + pageNumber +
                ", rowNumberBegin=" + rowNumberBegin +
                ", rowNumberEnded=" + rowNumberEnded +
                '}';
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getRowNumberBegin() {
        return rowNumberBegin;
    }

    public void setRowNumberBegin(int rowNumberBegin) {
        this.rowNumberBegin = rowNumberBegin;
    }

    public int getRowNumberEnded() {
        return rowNumberEnded;
    }

    public void setRowNumberEnded(int rowNumberEnded) {
        this.rowNumberEnded = rowNumberEnded;
    }

    public String getErrorResponse() {
        return errorResponse;
    }

    public void setErrorResponse(String errorResponse) {
        this.errorResponse = errorResponse;
    }

}
