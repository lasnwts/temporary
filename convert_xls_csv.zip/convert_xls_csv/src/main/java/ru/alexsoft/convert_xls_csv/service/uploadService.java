package ru.alexsoft.convert_xls_csv.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ru.alexsoft.convert_xls_csv.config.ConfigApplication;

import java.io.File;
import java.io.IOException;

@Service
public class uploadService {

    @Autowired
    ConfigApplication configApplication;

    public void uploadFile(MultipartFile file) throws IOException {
        file.transferTo(new File(configApplication.getOnlyPathFile() + file.getOriginalFilename()));
    }

    public String uploadFileToServer(MultipartFile file) throws IOException {
        file.transferTo(new File(configApplication.getOnlyPathFile() + file.getOriginalFilename()));
        return configApplication.getOnlyPathFile() + file.getOriginalFilename();
    }
}
