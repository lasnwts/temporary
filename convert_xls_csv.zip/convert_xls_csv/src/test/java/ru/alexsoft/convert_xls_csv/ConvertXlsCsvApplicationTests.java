package ru.alexsoft.convert_xls_csv;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import ru.alexsoft.convert_xls_csv.rescontroller.RescontrollerMF;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
class ConvertXlsCsvApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private RescontrollerMF resControllerMF;

    /*
    Просто проверка на существование контроллера
     */
    @Test
    void contextLoads() {
        assertThat(resControllerMF).isNotNull();
    }


}
