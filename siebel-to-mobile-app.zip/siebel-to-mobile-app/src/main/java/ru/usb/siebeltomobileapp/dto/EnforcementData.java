package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnforcementData {
    @JsonProperty("id")
    private String id;

    @JsonProperty("debt_id")
    private String debt_id;

    @JsonProperty("judicial_proceeding_id")
    private String judicial_proceeding_id;

    @JsonProperty("number")
    private String number;

    @JsonProperty("date")
    private String date;

    @JsonProperty("amount")
    private String amount;

    @JsonProperty("excitation_date")
    private String excitation_date;

    @JsonProperty("end_date")
    private String end_date;

    @JsonProperty("basis_end_enforcement_proceeding")
    private String basis_end_enforcement_proceeding;

    @JsonProperty("arest_date")
    private String arest_date;
    @JsonProperty("type")
    private String type;

    @JsonProperty("enforcment_number")
    private String enforcment_number;

    @JsonProperty("fssp_name")
    private String fssp_name;

    @JsonProperty("status")
    private String status;

    @JsonProperty("result")
    private String result;

    @JsonProperty("client")
    private String client;

    @JsonProperty("thrid_party")
    private String thrid_party;

    @JsonProperty("left_to_pay")
    private String left_to_pay;

    public EnforcementData() {
    }

    public EnforcementData(String id, String debt_id, String judicial_proceeding_id, String number, String date,
                           String amount, String excitation_date, String end_date, String basis_end_enforcement_proceeding,
                           String arest_date, String type, String enforcment_number, String fssp_name, String status,
                           String result, String client, String thrid_party, String left_to_pay) {
        this.id = id;
        this.debt_id = debt_id;
        this.judicial_proceeding_id = judicial_proceeding_id;
        this.number = number;
        this.date = date;
        this.amount = amount;
        this.excitation_date = excitation_date;
        this.end_date = end_date;
        this.basis_end_enforcement_proceeding = basis_end_enforcement_proceeding;
        this.arest_date = arest_date;
        this.type = type;
        this.enforcment_number = enforcment_number;
        this.fssp_name = fssp_name;
        this.status = status;
        this.result = result;
        this.client = client;
        this.thrid_party = thrid_party;
        this.left_to_pay = left_to_pay;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDebt_id() {
        return debt_id;
    }

    public void setDebt_id(String debt_id) {
        this.debt_id = debt_id;
    }

    public String getJudicial_proceeding_id() {
        return judicial_proceeding_id;
    }

    public void setJudicial_proceeding_id(String judicial_proceeding_id) {
        this.judicial_proceeding_id = judicial_proceeding_id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getExcitation_date() {
        return excitation_date;
    }

    public void setExcitation_date(String excitation_date) {
        this.excitation_date = excitation_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getBasis_end_enforcement_proceeding() {
        return basis_end_enforcement_proceeding;
    }

    public void setBasis_end_enforcement_proceeding(String basis_end_enforcement_proceeding) {
        this.basis_end_enforcement_proceeding = basis_end_enforcement_proceeding;
    }

    public String getArest_date() {
        return arest_date;
    }

    public void setArest_date(String arest_date) {
        this.arest_date = arest_date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEnforcment_number() {
        return enforcment_number;
    }

    public void setEnforcment_number(String enforcment_number) {
        this.enforcment_number = enforcment_number;
    }

    public String getFssp_name() {
        return fssp_name;
    }

    public void setFssp_name(String fssp_name) {
        this.fssp_name = fssp_name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getThrid_party() {
        return thrid_party;
    }

    public void setThrid_party(String thrid_party) {
        this.thrid_party = thrid_party;
    }

    public String getLeft_to_pay() {
        return left_to_pay;
    }

    public void setLeft_to_pay(String left_to_pay) {
        this.left_to_pay = left_to_pay;
    }

    @Override
    public String toString() {
        return "EnforcementData{" +
                "id='" + id + '\'' +
                ", debt_id='" + debt_id + '\'' +
                ", judicial_proceeding_id='" + judicial_proceeding_id + '\'' +
                ", number='" + number + '\'' +
                ", date='" + date + '\'' +
                ", amount='" + amount + '\'' +
                ", excitation_date='" + excitation_date + '\'' +
                ", end_date='" + end_date + '\'' +
                ", basis_end_enforcement_proceeding='" + basis_end_enforcement_proceeding + '\'' +
                ", arest_date='" + arest_date + '\'' +
                ", type='" + type + '\'' +
                ", enforcment_number='" + enforcment_number + '\'' +
                ", fssp_name='" + fssp_name + '\'' +
                ", status='" + status + '\'' +
                ", result='" + result + '\'' +
                ", client='" + client + '\'' +
                ", thrid_party='" + thrid_party + '\'' +
                ", left_to_pay='" + left_to_pay + '\'' +
                '}';
    }
}
