package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DebtData {
    @JsonProperty("id")
    private String id;

    @JsonProperty("client_id")
    private String client_id;
    @JsonProperty("filter_type_id")
    private String filter_type_id;

    @JsonProperty("stage_type")
    private String stage_type;

    @JsonProperty("debt_number")
    private String debt_number;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("agreement_date")
    private String agreement_date;
    @JsonProperty("cession_agreement_date")
    private String cession_agreement_date;

    @JsonProperty("is_ep")
    private String is_ep;

    @JsonProperty("name_counter_party")
    private String name_counter_party;

    @JsonProperty("next_payment_date")
    private String next_payment_date;

    @JsonProperty("overdue_days")
    private String overdue_days;

    @JsonProperty("credit_type")
    private String credit_type;

    @JsonProperty("return_period")
    private String return_period;

    @JsonProperty("product_type")
    private String product_type;

    @JsonProperty("credit_sum")
    private String credit_sum;
    @JsonProperty("comission_sum")
    private String comission_sum;

    @JsonProperty("duty_sum")
    private String duty_sum;

    @JsonProperty("main_debt_sum")
    private String main_debt_sum;

    @JsonProperty("monthly_payment")
    private String monthly_payment;

    @JsonProperty("percent_sum")
    private String percent_sum;

    @JsonProperty("overdue_percent_sum")
    private String overdue_percent_sum;

    @JsonProperty("penalty_sum")
    private String penalty_sum;
    @JsonProperty("total_sum")
    private String total_sum;

    @JsonProperty("total_written_off")
    private String total_written_off;

    @JsonProperty("fair_delay_total")
    private String fair_delay_total;

    @JsonProperty("overdue_date")
    private String overdue_date;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("organisation_branch")
    private String organisation_branch;


    @JsonProperty("organisation_division")
    private String organisation_division;

    @JsonProperty("loan_account_number")
    private String loan_account_number;

    @JsonProperty("status_ABS")
    private String status_ABS;

    @JsonProperty("cancellation_date")
    private String cancellation_date;

    @JsonProperty("last_payment_amount")
    private String last_payment_amount;

    @JsonProperty("last_payment_date")
    private String last_payment_date;

    @JsonProperty("presence_of_collateral")
    private String presence_of_collateral;

    @JsonProperty("judgment_effective_date")
    private String judgment_effective_date;


    @JsonProperty("current_debt_basic")
    private String current_debt_basic;

    @JsonProperty("current_debt_percent")
    private String current_debt_percent;

    @JsonProperty("fines_payment")
    private String fines_payment;

    @JsonProperty("debt_amount_arrest")
    private String debt_amount_arrest;

    @JsonProperty("stage_start_date")
    private String stage_start_date;

    @JsonProperty("sales_rep_full_name")
    private String sales_rep_full_name;

    @JsonProperty("bankr_stage")
    private String bankr_stage;

    public DebtData() {
    }

    public DebtData(String id, String client_id, String filter_type_id, String stage_type, String debt_number,
                    String comment, String agreement_date, String cession_agreement_date, String is_ep,
                    String name_counter_party, String next_payment_date, String overdue_days, String credit_type,
                    String return_period, String product_type, String credit_sum, String comission_sum, String duty_sum,
                    String main_debt_sum, String monthly_payment, String percent_sum, String overdue_percent_sum,
                    String penalty_sum, String total_sum, String total_written_off, String fair_delay_total,
                    String overdue_date, String currency, String organisation_branch, String organisation_division,
                    String loan_account_number, String status_ABS, String cancellation_date, String last_payment_amount,
                    String last_payment_date, String presence_of_collateral, String judgment_effective_date,
                    String current_debt_basic, String current_debt_percent, String fines_payment,
                    String debt_amount_arrest, String stage_start_date, String sales_rep_full_name,
                    String bankr_stage) {
        this.id = id;
        this.client_id = client_id;
        this.filter_type_id = filter_type_id;
        this.stage_type = stage_type;
        this.debt_number = debt_number;
        this.comment = comment;
        this.agreement_date = agreement_date;
        this.cession_agreement_date = cession_agreement_date;
        this.is_ep = is_ep;
        this.name_counter_party = name_counter_party;
        this.next_payment_date = next_payment_date;
        this.overdue_days = overdue_days;
        this.credit_type = credit_type;
        this.return_period = return_period;
        this.product_type = product_type;
        this.credit_sum = credit_sum;
        this.comission_sum = comission_sum;
        this.duty_sum = duty_sum;
        this.main_debt_sum = main_debt_sum;
        this.monthly_payment = monthly_payment;
        this.percent_sum = percent_sum;
        this.overdue_percent_sum = overdue_percent_sum;
        this.penalty_sum = penalty_sum;
        this.total_sum = total_sum;
        this.total_written_off = total_written_off;
        this.fair_delay_total = fair_delay_total;
        this.overdue_date = overdue_date;
        this.currency = currency;
        this.organisation_branch = organisation_branch;
        this.organisation_division = organisation_division;
        this.loan_account_number = loan_account_number;
        this.status_ABS = status_ABS;
        this.cancellation_date = cancellation_date;
        this.last_payment_amount = last_payment_amount;
        this.last_payment_date = last_payment_date;
        this.presence_of_collateral = presence_of_collateral;
        this.judgment_effective_date = judgment_effective_date;
        this.current_debt_basic = current_debt_basic;
        this.current_debt_percent = current_debt_percent;
        this.fines_payment = fines_payment;
        this.debt_amount_arrest = debt_amount_arrest;
        this.stage_start_date = stage_start_date;
        this.sales_rep_full_name = sales_rep_full_name;
        this.bankr_stage = bankr_stage;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getFilter_type_id() {
        return filter_type_id;
    }

    public void setFilter_type_id(String filter_type_id) {
        this.filter_type_id = filter_type_id;
    }

    public String getStage_type() {
        return stage_type;
    }

    public void setStage_type(String stage_type) {
        this.stage_type = stage_type;
    }

    public String getDebt_number() {
        return debt_number;
    }

    public void setDebt_number(String debt_number) {
        this.debt_number = debt_number;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAgreement_date() {
        return agreement_date;
    }

    public void setAgreement_date(String agreement_date) {
        this.agreement_date = agreement_date;
    }

    public String getCession_agreement_date() {
        return cession_agreement_date;
    }

    public void setCession_agreement_date(String cession_agreement_date) {
        this.cession_agreement_date = cession_agreement_date;
    }

    public String getIs_ep() {
        return is_ep;
    }

    public void setIs_ep(String is_ep) {
        this.is_ep = is_ep;
    }

    public String getName_counter_party() {
        return name_counter_party;
    }

    public void setName_counter_party(String name_counter_party) {
        this.name_counter_party = name_counter_party;
    }

    public String getNext_payment_date() {
        return next_payment_date;
    }

    public void setNext_payment_date(String next_payment_date) {
        this.next_payment_date = next_payment_date;
    }

    public String getOverdue_days() {
        return overdue_days;
    }

    public void setOverdue_days(String overdue_days) {
        this.overdue_days = overdue_days;
    }

    public String getCredit_type() {
        return credit_type;
    }

    public void setCredit_type(String credit_type) {
        this.credit_type = credit_type;
    }

    public String getReturn_period() {
        return return_period;
    }

    public void setReturn_period(String return_period) {
        this.return_period = return_period;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getCredit_sum() {
        return credit_sum;
    }

    public void setCredit_sum(String credit_sum) {
        this.credit_sum = credit_sum;
    }

    public String getComission_sum() {
        return comission_sum;
    }

    public void setComission_sum(String comission_sum) {
        this.comission_sum = comission_sum;
    }

    public String getDuty_sum() {
        return duty_sum;
    }

    public void setDuty_sum(String duty_sum) {
        this.duty_sum = duty_sum;
    }

    public String getMain_debt_sum() {
        return main_debt_sum;
    }

    public void setMain_debt_sum(String main_debt_sum) {
        this.main_debt_sum = main_debt_sum;
    }

    public String getMonthly_payment() {
        return monthly_payment;
    }

    public void setMonthly_payment(String monthly_payment) {
        this.monthly_payment = monthly_payment;
    }

    public String getPercent_sum() {
        return percent_sum;
    }

    public void setPercent_sum(String percent_sum) {
        this.percent_sum = percent_sum;
    }

    public String getOverdue_percent_sum() {
        return overdue_percent_sum;
    }

    public void setOverdue_percent_sum(String overdue_percent_sum) {
        this.overdue_percent_sum = overdue_percent_sum;
    }

    public String getPenalty_sum() {
        return penalty_sum;
    }

    public void setPenalty_sum(String penalty_sum) {
        this.penalty_sum = penalty_sum;
    }

    public String getTotal_sum() {
        return total_sum;
    }

    public void setTotal_sum(String total_sum) {
        this.total_sum = total_sum;
    }

    public String getTotal_written_off() {
        return total_written_off;
    }

    public void setTotal_written_off(String total_written_off) {
        this.total_written_off = total_written_off;
    }

    public String getFair_delay_total() {
        return fair_delay_total;
    }

    public void setFair_delay_total(String fair_delay_total) {
        this.fair_delay_total = fair_delay_total;
    }

    public String getOverdue_date() {
        return overdue_date;
    }

    public void setOverdue_date(String overdue_date) {
        this.overdue_date = overdue_date;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOrganisation_branch() {
        return organisation_branch;
    }

    public void setOrganisation_branch(String organisation_branch) {
        this.organisation_branch = organisation_branch;
    }

    public String getOrganisation_division() {
        return organisation_division;
    }

    public void setOrganisation_division(String organisation_division) {
        this.organisation_division = organisation_division;
    }

    public String getLoan_account_number() {
        return loan_account_number;
    }

    public void setLoan_account_number(String loan_account_number) {
        this.loan_account_number = loan_account_number;
    }

    public String getStatus_ABS() {
        return status_ABS;
    }

    public void setStatus_ABS(String status_ABS) {
        this.status_ABS = status_ABS;
    }

    public String getCancellation_date() {
        return cancellation_date;
    }

    public void setCancellation_date(String cancellation_date) {
        this.cancellation_date = cancellation_date;
    }

    public String getLast_payment_amount() {
        return last_payment_amount;
    }

    public void setLast_payment_amount(String last_payment_amount) {
        this.last_payment_amount = last_payment_amount;
    }

    public String getLast_payment_date() {
        return last_payment_date;
    }

    public void setLast_payment_date(String last_payment_date) {
        this.last_payment_date = last_payment_date;
    }

    public String getPresence_of_collateral() {
        return presence_of_collateral;
    }

    public void setPresence_of_collateral(String presence_of_collateral) {
        this.presence_of_collateral = presence_of_collateral;
    }

    public String getJudgment_effective_date() {
        return judgment_effective_date;
    }

    public void setJudgment_effective_date(String judgment_effective_date) {
        this.judgment_effective_date = judgment_effective_date;
    }

    public String getCurrent_debt_basic() {
        return current_debt_basic;
    }

    public void setCurrent_debt_basic(String current_debt_basic) {
        this.current_debt_basic = current_debt_basic;
    }

    public String getCurrent_debt_percent() {
        return current_debt_percent;
    }

    public void setCurrent_debt_percent(String current_debt_percent) {
        this.current_debt_percent = current_debt_percent;
    }

    public String getFines_payment() {
        return fines_payment;
    }

    public void setFines_payment(String fines_payment) {
        this.fines_payment = fines_payment;
    }

    public String getDebt_amount_arrest() {
        return debt_amount_arrest;
    }

    public void setDebt_amount_arrest(String debt_amount_arrest) {
        this.debt_amount_arrest = debt_amount_arrest;
    }

    public String getStage_start_date() {
        return stage_start_date;
    }

    public void setStage_start_date(String stage_start_date) {
        this.stage_start_date = stage_start_date;
    }

    public String getSales_rep_full_name() {
        return sales_rep_full_name;
    }

    public void setSales_rep_full_name(String sales_rep_full_name) {
        this.sales_rep_full_name = sales_rep_full_name;
    }

    public String getBankr_stage() {
        return bankr_stage;
    }

    public void setBankr_stage(String bankr_stage) {
        this.bankr_stage = bankr_stage;
    }

    @Override
    public String toString() {
        return "DebtData{" +
                "id='" + id + '\'' +
                ", client_id='" + client_id + '\'' +
                ", filter_type_id='" + filter_type_id + '\'' +
                ", stage_type='" + stage_type + '\'' +
                ", debt_number='" + debt_number + '\'' +
                ", comment='" + comment + '\'' +
                ", agreement_date='" + agreement_date + '\'' +
                ", cession_agreement_date='" + cession_agreement_date + '\'' +
                ", is_ep='" + is_ep + '\'' +
                ", name_counter_party='" + name_counter_party + '\'' +
                ", next_payment_date='" + next_payment_date + '\'' +
                ", overdue_days='" + overdue_days + '\'' +
                ", credit_type='" + credit_type + '\'' +
                ", return_period='" + return_period + '\'' +
                ", product_type='" + product_type + '\'' +
                ", credit_sum='" + credit_sum + '\'' +
                ", comission_sum='" + comission_sum + '\'' +
                ", duty_sum='" + duty_sum + '\'' +
                ", main_debt_sum='" + main_debt_sum + '\'' +
                ", monthly_payment='" + monthly_payment + '\'' +
                ", percent_sum='" + percent_sum + '\'' +
                ", overdue_percent_sum='" + overdue_percent_sum + '\'' +
                ", penalty_sum='" + penalty_sum + '\'' +
                ", total_sum='" + total_sum + '\'' +
                ", total_written_off='" + total_written_off + '\'' +
                ", fair_delay_total='" + fair_delay_total + '\'' +
                ", overdue_date='" + overdue_date + '\'' +
                ", currency='" + currency + '\'' +
                ", organisation_branch='" + organisation_branch + '\'' +
                ", organisation_division='" + organisation_division + '\'' +
                ", loan_account_number='" + loan_account_number + '\'' +
                ", status_ABS='" + status_ABS + '\'' +
                ", cancellation_date='" + cancellation_date + '\'' +
                ", last_payment_amount='" + last_payment_amount + '\'' +
                ", last_payment_date='" + last_payment_date + '\'' +
                ", presence_of_collateral='" + presence_of_collateral + '\'' +
                ", judgment_effective_date='" + judgment_effective_date + '\'' +
                ", current_debt_basic='" + current_debt_basic + '\'' +
                ", current_debt_percent='" + current_debt_percent + '\'' +
                ", fines_payment='" + fines_payment + '\'' +
                ", debt_amount_arrest='" + debt_amount_arrest + '\'' +
                ", stage_start_date='" + stage_start_date + '\'' +
                ", sales_rep_full_name='" + sales_rep_full_name + '\'' +
                ", bankr_stage='" + bankr_stage + '\'' +
                '}';
    }
}
