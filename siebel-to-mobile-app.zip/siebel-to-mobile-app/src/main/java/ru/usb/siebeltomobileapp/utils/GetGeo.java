package ru.usb.siebeltomobileapp.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.model.Geo;
import ru.usb.siebeltomobileapp.model.GeoResponse;
import ru.usb.siebeltomobileapp.repository.GeoRepository;

import java.util.List;
import java.util.function.Consumer;

/**
 * Класс для получения ГЕО координат
 */
@Component
public class GetGeo {
    Logger logger = LoggerFactory.getLogger(GetGeo.class);
    private final GeoRepository geoRepository;

    @Autowired
    public GetGeo(GeoRepository geoRepository) {
        this.geoRepository = geoRepository;
    }

    /**
     * Получаем координаты
     *
     * @param externalId - входной Id
     * @return
     */
    public GeoResponse getGeos(String externalId, String packId) {
        if (externalId == null) {
            return null;
        }
        List<Geo> geos = null;
        GeoResponse geoResponse = new GeoResponse("", false, externalId); //Инициализация

        try {
            geos = geoRepository.getAllCoordinates(externalId);
            if (geos.isEmpty()) {
                logger.info("Запрос в БД с externalId={} - вернул пустой ответ", externalId);
                geoResponse.setResult("Адрес не обогащен данными по геокоординатам. Рассматриваемый адрес отсутствует в DB DMBY");
            } else {
                if (!geos.get(0).getGeoLan().trim().isEmpty() && !geos.get(0).getGeoLon().trim().isEmpty()) {
                    geoResponse.setSuccess(true);
                    geoResponse.getGeo().setGeoLan(geos.get(0).getGeoLan().trim());
                    geoResponse.getGeo().setGeoLon(geos.get(0).getGeoLon().trim());
                } else {
                    geoResponse.setSuccess(false);
                    geoResponse.setResult("Адрес не обогащен данными по геокоординатам. Для рассматриваемого адреса в DB DMBY отсутствуют данные по геокооррдинатам");
                }
                logger.info("UsbLog:Количество строк в ответе по Координатам={}", geos.size());
                geos.forEach(geo -> logger.info("UsbLog:Geo LAN={}, LON={}", geo.getGeoLan(), geo.getGeoLon()));
            }
            logger.info("UsbLog: Получены координаты:{}", geoResponse);
            return geoResponse;
        } catch (Exception e) {
            geoResponse.setSuccess(false);
            geoResponse.setResult("Не удалось подключиться к DB DMBY.");
            logger.error("UsbLog: Возникла ошибка при выполнении обращения к БД Geo");
            logger.error("UsbLog: PrnStack", e);
            return geoResponse;
        }
    }
}
