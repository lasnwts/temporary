package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO Address
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressData {
    @JsonProperty("id")
    private String id;
    @JsonProperty("last_result")
    private String last_result;
    @JsonProperty("address_string")
    private String address_string;
    @JsonProperty("client_id")
    private String client_id;
    @JsonProperty("description")
    private String description;
    @JsonProperty("is_primary")
    private String is_primary;
    @JsonProperty("lat")
    private String lat;
    @JsonProperty("lon")
    private String lon;
    @JsonProperty("address_type_id")
    private String address_type_id;
    @JsonProperty("created_timestamp")
    private String created_timestamp;
    @JsonProperty("country")
    private String country;
    @JsonProperty("postal_code")
    private String postal_code;
    @JsonProperty("region")
    private String region;
    @JsonProperty("city")
    private String city;
    @JsonProperty("settlement")
    private String settlement;
    @JsonProperty("street")
    private String street;
    @JsonProperty("house")
    private String house;
    @JsonProperty("frame")
    private String frame;
    @JsonProperty("block")
    private String block;
    @JsonProperty("flat")
    private String flat;

    public AddressData() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress_string() {
        return address_string;
    }

    public void setAddress_string(String address_string) {
        this.address_string = address_string;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIs_primary() {
        return is_primary;
    }

    public void setIs_primary(String is_primary) {
        this.is_primary = is_primary;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public String getAddress_type_id() {
        return address_type_id;
    }

    public void setAddress_type_id(String address_type_id) {
        this.address_type_id = address_type_id;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSettlement() {
        return settlement;
    }

    public void setSettlement(String settlement) {
        this.settlement = settlement;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getFrame() {
        return frame;
    }

    public void setFrame(String frame) {
        this.frame = frame;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getFlat() {
        return flat;
    }

    public void setFlat(String flat) {
        this.flat = flat;
    }

    public String getLast_result() {
        return last_result;
    }

    public void setLast_result(String last_result) {
        this.last_result = last_result;
    }

    @Override
    public String toString() {
        return "AddressData{" +
                "id='" + id + '\'' +
                ", last_result='" + last_result + '\'' +
                ", address_string='" + address_string + '\'' +
                ", client_id='" + client_id + '\'' +
                ", description='" + description + '\'' +
                ", is_primary='" + is_primary + '\'' +
                ", lat='" + lat + '\'' +
                ", lon='" + lon + '\'' +
                ", address_type_id='" + address_type_id + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                ", country='" + country + '\'' +
                ", postal_code='" + postal_code + '\'' +
                ", region='" + region + '\'' +
                ", city='" + city + '\'' +
                ", settlement='" + settlement + '\'' +
                ", street='" + street + '\'' +
                ", house='" + house + '\'' +
                ", frame='" + frame + '\'' +
                ", block='" + block + '\'' +
                ", flat='" + flat + '\'' +
                '}';
    }
}
