package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Client;
import ru.usb.siebeltomobileapp.mapper.ClientMAP;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class ClientSender {
    Logger logger = LoggerFactory.getLogger(ClientSender.class);

    private final ClientMAP clientMAP;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public ClientSender(ClientMAP clientMAP, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.clientMAP = clientMAP;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        Client client = clientMAP.messageMapper(messageString);

        if (client == null || client.getData() == null || client.getData().getId() == null || client.getData().getFull_name() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.client : {}", client);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         *  service - MP.client
         * Поле	Формат данных от SIebel	Формат данных для МП
         * 2. actuality_date	MM/DD/YYYY HH24:MI:SS	YYYY-MM-DD
         * 1 birthday	MM/DD/YYYY	YYYY-MM-DD
         * 3 passport_issue_date	MM/DD/YYYY HH24:MI:SS	YYYY-MM-DD
         * 4 death_date	MM/DD/YYYY	YYYY-MM-DD
         */
        //1  birthday	MM/DD/YYYY	YYYY-MM-DD
        if (aux.checkDate(client.getData().getBirthday())) {
            client.getData().setBirthday(aux.getMpDate(client.getData().getBirthday()));
        }
        //2  actuality_date	MM/DD/YYYY HH24:MI:SS	YYYY-MM-DD
        if (aux.checkDateTime(client.getData().getActuality_date())) {
            client.getData().setActuality_date(aux.getMpDateTime(client.getData().getActuality_date()));
        }
        //3 passport_issue_date	MM/DD/YYYY HH24:MI:SS	YYYY-MM-DD
        if (aux.checkDateTime(client.getData().getPassport_issue_date())) {
            client.getData().setPassport_issue_date(aux.getMpDateTime(client.getData().getPassport_issue_date()));
        }
        //4  4 death_date
        if (aux.checkDate(client.getData().getDeath_date())) {
            client.getData().setDeath_date(aux.getMpDate((client.getData().getDeath_date())));
        }

        //Отправка
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(clientMAP.getJsonToStr(client)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(clientMAP.getJsonToStr(client)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(clientMAP.getJsonToStr(client)));
            return false;
        }
    }
}
