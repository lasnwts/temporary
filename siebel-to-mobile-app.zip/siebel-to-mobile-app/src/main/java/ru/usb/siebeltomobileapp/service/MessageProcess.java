package ru.usb.siebeltomobileapp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.usb.siebeltomobileapp.model.MessageFromKafka;
import ru.usb.siebeltomobileapp.service.mail.ServiceMailError;
import ru.usb.siebeltomobileapp.utils.AuxMethods;
import ru.usb.siebeltomobileapp.utils.RouteFinder;

@Service
public class MessageProcess {

    Logger logger = LoggerFactory.getLogger(MessageProcess.class);
    private final RouteFinder routeFinder;
    private final AuxMethods aux;
    private final ServiceMailError serviceMailError;


    private final BaseProcessed baseProcessed;

    public MessageProcess(RouteFinder routeFinder, AuxMethods aux, ServiceMailError serviceMailError, BaseProcessed baseProcessed) {
        this.routeFinder = routeFinder;
        this.aux = aux;
        this.serviceMailError = serviceMailError;
        this.baseProcessed = baseProcessed;
    }


    /**
     * Маршрутизатор
     * @param message - сообщение из Кафка
     */
    public void getRoute(MessageFromKafka message) {
        String route = routeFinder.getRoute(message);
        if (route == null) {
            logger.error("Не найден маршрут для service:{}, полное сообщение (без тега:pack):{}", message.getService(), message);
            serviceMailError.sendMailError("Проект 3197. Поток 3.1. от Siebel в Мобильное приложение. \r\n" +
                    " Не найден маршрут для (No route found for) service:" + aux.getWrapNull(message.getService())
                    + "\r\n сообщение(message):\r\n" + aux.getWrapNull(message.toString()));
            message.setError("Router:404");
            message.setErrortext("Не найден маршрут для (No route found for) service:" + message.getService());
        } else {
            logger.info("UsbLog:Найден маршрут [топик]={} для сообщения:{}", route, aux.getWrapNull(message.getPack()));
            logger.info("UsbLog:Попытка отправки сообщения в Topic={}; ", route);

            /**
             * Обработка сообщений и отправка их по топикам
             */
            baseProcessed.getProcess(message, route);
        }
    }
}