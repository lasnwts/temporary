package ru.usb.siebeltomobileapp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.siebeltomobileapp.model.MessageFromKafka;

import ru.usb.siebeltomobileapp.transformed.*;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

/**
 * Основной процесс обработки сообщений
 * Мапирование в POJO
 * Форматирование Дат
 * Отправка сообщений в необходимые топики
 */
@Service
public class BaseProcessed {

    private final AuxMethods aux;
    private final PhoneSender phoneSender;
    private final OtherContactSender contactSender;
    private final JudicialSender judicialSender;
    private final EnforcementSender enforcementSender;
    private final DebtSender debtSender;
    private final ClientSender clientSender;
    private final RelationSender relationSender;
    private final JobSender jobSender;
    private final ContactResultSender contactResultSender;
    private final MpDeleteSender mpDeleteSender;
    private final AddressSender addressSender;
    private final StringSender stringSender;

    @Autowired
    public BaseProcessed(AuxMethods aux, PhoneSender phoneSender, OtherContactSender contactSender,
                         JudicialSender judicialSender, EnforcementSender enforcementSender,
                         DebtSender debtSender, ClientSender clientSender, RelationSender relationSender,
                         JobSender jobSender, ContactResultSender contactResultSender, MpDeleteSender mpDeleteSender,
                         AddressSender addressSender, StringSender stringSender) {
        this.aux = aux;
        this.phoneSender = phoneSender;
        this.contactSender = contactSender;
        this.judicialSender = judicialSender;
        this.enforcementSender = enforcementSender;
        this.debtSender = debtSender;
        this.clientSender = clientSender;
        this.relationSender = relationSender;
        this.jobSender = jobSender;
        this.contactResultSender = contactResultSender;
        this.mpDeleteSender = mpDeleteSender;
        this.addressSender = addressSender;
        this.stringSender = stringSender;
    }

    Logger logger = LoggerFactory.getLogger(BaseProcessed.class);

    public boolean getProcess(MessageFromKafka messageFromKafka, String route) {

        logger.info("UsbLog:=====================================<[Старт Обработки]>======================================================");

        if (messageFromKafka == null) {
            logger.error("UsbLog: Ошибка переданное сообщение MessageFromKafka==NULL!");
            return false;
        }

        //Определяем тип объекта Phone
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.phone")) {
            return logResults(route, phoneSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //* Определяем тип объекта OtherContact
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.other_contact")) {
            return logResults(route, contactSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.judicial
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.judicial")) {
            return logResults(route, judicialSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.enforcement
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.enforcement")) {
            return logResults(route, enforcementSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.debt
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.debt")) {
            return logResults(route, debtSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.client
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.client")) {
            return logResults(route, clientSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.relation
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.relation")) {
            return logResults(route, relationSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.job
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.job")) {
            return logResults(route, jobSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.contact_result
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.contact_result")) {
            return logResults(route, contactResultSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.contact_result
        //MP.delete_debt /MP.delete_contact_tree_node /MP.delete_form_field_contact_tree /MP.delete_list_entry
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.delete_debt") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.delete_contact_tree_node") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.delete_form_field_contact_tree") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.delete_list_entry")) {
            return logResults(route, mpDeleteSender.getTransformSend(messageFromKafka.getPack(), route));
        }

        //Определяем service - MP.address
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.address")) {
            return logResults(route, addressSender.getTransformSend(messageFromKafka.getPack(), route, messageFromKafka.getPackID()));
        }

        //Все остальные топики
        if (aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.assign_debt") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.assign_job") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.document") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.pladge") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.real_estate") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.movables") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.address_type") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.phone_type") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.other_contact_type") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.document_type") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.contact_tree_node") ||
                aux.getWrapNull(messageFromKafka.getService()).equalsIgnoreCase("MP.list_entry")) {
            return logResults(route, stringSender.getTransformSend(messageFromKafka.getPack(), route, messageFromKafka.getService()));
        }
        logger.info("UsbLog:----------------------------------<обработка завершена>------------------------------------------");
        return true;
    }

    /**
     * Метод для вывода в лог
     *
     * @param topic - топик для МП
     * @param flag  - успех или нет
     */
    private boolean logResults(String topic, boolean flag) {
        if (flag) {
            logger.info("UsbLog:Успешная отправка сообщения в топик МП {}", topic);
        } else {
            logger.error("UsbLog:Произошла ошибка при отправке сообщения в топик МП {}", topic);
        }
        return flag; //По любому просто отдаем флаг - результат
    }

}
