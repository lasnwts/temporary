package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Relation;
import ru.usb.siebeltomobileapp.mapper.RelationMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class RelationSender {
    Logger logger = LoggerFactory.getLogger(RelationSender.class);

    private final RelationMap relationMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public RelationSender(RelationMap relationMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.relationMap = relationMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        Relation relation = relationMap.messageMapper(messageString);

        if (relation == null || relation.getData() == null || relation.getData().getId() == null || relation.getData().getClient_id() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.relation : {}", relation);


        /**
         * service - MP.relation
         * Поле	Формат данных от SIebel	Формат данных для МП
         * birthday	MM/DD/YYYY	YYYY-MM-DD
         */

        //1 birthday
        if (aux.checkDate(relation.getData().getBirthday())) {
            relation.getData().setBirthday(aux.getMpDate(relation.getData().getBirthday()));
        }

        //отправка
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(relationMap.getJsonToStr(relation)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(relationMap.getJsonToStr(relation)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(relationMap.getJsonToStr(relation)));
            return false;
        }
    }
}
