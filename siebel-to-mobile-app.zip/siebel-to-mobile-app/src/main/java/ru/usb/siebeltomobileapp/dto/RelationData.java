package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор, первичный ключ
 * client_id	Связь с клиентом
 * birthday	Дата рождения
 * main_address	Строка основного адреса
 * person_full_name	ФИО связи
 * relation_reason	Причина связи (напр. совпадает телефон)
 * status	Статус подтверждения
 * relation_type	Тип связи
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelationData {
    @JsonProperty("id")
    private String id;//	Идентификатор, первичный ключ

    @JsonProperty("client_id")
    private String  client_id;	//Связь с клиентом

    @JsonProperty("birthday")
    private String  birthday;	//Дата рождения

    @JsonProperty("main_address")
    private String  main_address;//	Строка основного адреса

    @JsonProperty("person_full_name")
    private String  person_full_name;	//ФИО связи

    @JsonProperty("relation_reason")
    private String  relation_reason;//	Причина связи (напр. совпадает телефон)

    @JsonProperty("status")
    private String  status;	//Статус подтверждения

    @JsonProperty("relation_type")
    private String  relation_type;///	Тип связи

    public RelationData() {
    }

    public RelationData(String id, String client_id, String birthday, String main_address, String person_full_name, String relation_reason, String status, String relation_type) {
        this.id = id;
        this.client_id = client_id;
        this.birthday = birthday;
        this.main_address = main_address;
        this.person_full_name = person_full_name;
        this.relation_reason = relation_reason;
        this.status = status;
        this.relation_type = relation_type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getMain_address() {
        return main_address;
    }

    public void setMain_address(String main_address) {
        this.main_address = main_address;
    }

    public String getPerson_full_name() {
        return person_full_name;
    }

    public void setPerson_full_name(String person_full_name) {
        this.person_full_name = person_full_name;
    }

    public String getRelation_reason() {
        return relation_reason;
    }

    public void setRelation_reason(String relation_reason) {
        this.relation_reason = relation_reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRelation_type() {
        return relation_type;
    }

    public void setRelation_type(String relation_type) {
        this.relation_type = relation_type;
    }

    @Override
    public String toString() {
        return "RelationData{" +
                "id='" + id + '\'' +
                ", client_id='" + client_id + '\'' +
                ", birthday='" + birthday + '\'' +
                ", main_address='" + main_address + '\'' +
                ", person_full_name='" + person_full_name + '\'' +
                ", relation_reason='" + relation_reason + '\'' +
                ", status='" + status + '\'' +
                ", relation_type='" + relation_type + '\'' +
                '}';
    }
}
