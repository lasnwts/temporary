package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор, первичный ключ
 * job_id	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)
 * client_id	Связь с клиентом
 * debt_id	Идентификатор долга
 * node_id	Результат задачи (ID - последний узел дерева) заполняется, если контакт был добавлен с МП
 * contact_type	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
 * contact_date	Дата контакта
 * description	Адрес/телефон/онлайн контакт на котором была коммуникация
 * result	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)
 * comment	Комментарий к контакту
 * payment_amount	Сумма обещанного платежа
 * payment_date	Дата обещанного платежа
 * no_sale_reason	Описание причины
 * created_timestamp	Дата и время создания объекта на МП
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactResultData {

    @JsonProperty("id")
    private String id; //	Идентификатор, первичный ключ

    @JsonProperty("job_id")
    private String job_id; //	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)

    @JsonProperty("client_id")
    private String client_id; //	Связь с клиентом

    @JsonProperty("debt_id")
    private String debt_id; //	Идентификатор долга

    @JsonProperty("node_id")
    private String node_id; //	Результат задачи (ID - последний узел дерева) заполняется, если контакт был добавлен с МП

    @JsonProperty("contact_type")
    private String contact_type; //	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)

    @JsonProperty("contact_date")
    private String contact_date; //	Дата контакта

    @JsonProperty("description")
    private String description; //	Адрес/телефон/онлайн контакт на котором была коммуникация

    @JsonProperty("result")
    private String result; //	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)

    @JsonProperty("comment")
    private String comment; //	Комментарий к контакту

    @JsonProperty("payment_amount")
    private String payment_amount; //	Сумма обещанного платежа

    @JsonProperty("payment_date")
    private String payment_date; //	Дата обещанного платежа

    @JsonProperty("no_sale_reason")
    private String no_sale_reason; //	Описание причины

    @JsonProperty("created_timestamp")
    private String created_timestamp; //	Дата и время создания объекта на МП

    public ContactResultData() {
    }

    public ContactResultData(String id, String job_id, String client_id, String debt_id, String node_id,
                             String contact_type, String contact_date, String description, String result,
                             String comment, String payment_amount, String payment_date,
                             String no_sale_reason, String created_timestamp) {
        this.id = id;
        this.job_id = job_id;
        this.client_id = client_id;
        this.debt_id = debt_id;
        this.node_id = node_id;
        this.contact_type = contact_type;
        this.contact_date = contact_date;
        this.description = description;
        this.result = result;
        this.comment = comment;
        this.payment_amount = payment_amount;
        this.payment_date = payment_date;
        this.no_sale_reason = no_sale_reason;
        this.created_timestamp = created_timestamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJob_id() {
        return job_id;
    }

    public void setJob_id(String job_id) {
        this.job_id = job_id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getDebt_id() {
        return debt_id;
    }

    public void setDebt_id(String debt_id) {
        this.debt_id = debt_id;
    }

    public String getNode_id() {
        return node_id;
    }

    public void setNode_id(String node_id) {
        this.node_id = node_id;
    }

    public String getContact_type() {
        return contact_type;
    }

    public void setContact_type(String contact_type) {
        this.contact_type = contact_type;
    }

    public String getContact_date() {
        return contact_date;
    }

    public void setContact_date(String contact_date) {
        this.contact_date = contact_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPayment_amount() {
        return payment_amount;
    }

    public void setPayment_amount(String payment_amount) {
        this.payment_amount = payment_amount;
    }

    public String getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(String payment_date) {
        this.payment_date = payment_date;
    }

    public String getNo_sale_reason() {
        return no_sale_reason;
    }

    public void setNo_sale_reason(String no_sale_reason) {
        this.no_sale_reason = no_sale_reason;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    @Override
    public String toString() {
        return "ContactResultData{" +
                "id='" + id + '\'' +
                ", job_id='" + job_id + '\'' +
                ", client_id='" + client_id + '\'' +
                ", debt_id='" + debt_id + '\'' +
                ", node_id='" + node_id + '\'' +
                ", contact_type='" + contact_type + '\'' +
                ", contact_date='" + contact_date + '\'' +
                ", description='" + description + '\'' +
                ", result='" + result + '\'' +
                ", comment='" + comment + '\'' +
                ", payment_amount='" + payment_amount + '\'' +
                ", payment_date='" + payment_date + '\'' +
                ", no_sale_reason='" + no_sale_reason + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                '}';
    }
}
