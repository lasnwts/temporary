package ru.usb.siebeltomobileapp.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор, первичный ключ
 * client_id	Связь с клиентом
 * contact_date_time	Дата-время выхода на контакт
 * contact_type	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
 * debt_id	Идентификатор долга
 * address_id	Адрес, если это DEPARTURE
 * phone_id	Телефон, если это CALL
 * judical_id	Судебное производство, если это JUDICAL
 * enforcment_id	Исполнительное производство, если это ENFORCEMENT
 * other_contact_id	Онлайн контакт, если это ONLINE
 * job_date	Дата постановки задания
 * status	Могут быть значения: CREATED, COMPLETE, CANCELED
 * created_timestamp	Дата и время создания объекта на МП
 * job_type	Текстовое значение типа задания (для
 * задач созданных в МП берутся данные из contact_tree_node)
 * job_subtype	Текстовое значение подтипа задания (для задач созданных в МП берутся данные из contact_tree_node)
 * node_id	Идентификатор узла подтипа задания из связанного дерева (для запуска дерева
 * регистрации результата с данного шага)
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobData {

    @JsonProperty("id")
    private String id; //	Идентификатор, первичный ключ

    @JsonProperty("client_id")
    private String client_id; //	Связь с клиентом

    @JsonProperty("contact_date_time")
    private String contact_date_time; //	Дата-время выхода на контакт

    @JsonProperty("contact_type")
    private String contact_type; //	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
    @JsonProperty("debt_id")
    private String debt_id; //	Идентификатор долга

    @JsonProperty("address_id")
    private String address_id; //	Адрес, если это DEPARTURE

    @JsonProperty("phone_id")
    private String phone_id; //	Телефон, если это CALL

    @JsonProperty("judical_id")
    private String judical_id; //	Судебное производство, если это JUDICAL

    @JsonProperty("enforcment_id")
    private String enforcment_id; //	Исполнительное производство, если это ENFORCEMENT

    @JsonProperty("other_contact_id")
    private String other_contact_id; //	Онлайн контакт, если это ONLINE

    @JsonProperty("job_date")
    private String job_date; //	Дата постановки задания

    @JsonProperty("court")
    private String status; //	Могут быть значения: CREATED, COMPLETE, CANCELED

    @JsonProperty("status")
    private String created_timestamp; //	Дата и время создания объекта на МП

    @JsonProperty("job_type")
    private String job_type; //	Текстовое значение типа задания (для задач созданных в МП берутся данные из contact_tree_node)

    @JsonProperty("job_subtype")
    private String job_subtype; //	Текстовое значение подтипа задания (для задач созданных в МП берутся данные из contact_tree_node)

    @JsonProperty("node_id")
    private String node_id; //	Идентификатор узла подтипа задания из связанного дерева (для запуска дерева  регистрации результата с данного шага)

    public JobData() {
    }

    public JobData(String id, String client_id, String contact_date_time, String contact_type, String debt_id,
                   String address_id, String phone_id, String judical_id, String enforcment_id, String other_contact_id,
                   String job_date, String status, String created_timestamp, String job_type,
                   String job_subtype, String node_id) {
        this.id = id;
        this.client_id = client_id;
        this.contact_date_time = contact_date_time;
        this.contact_type = contact_type;
        this.debt_id = debt_id;
        this.address_id = address_id;
        this.phone_id = phone_id;
        this.judical_id = judical_id;
        this.enforcment_id = enforcment_id;
        this.other_contact_id = other_contact_id;
        this.job_date = job_date;
        this.status = status;
        this.created_timestamp = created_timestamp;
        this.job_type = job_type;
        this.job_subtype = job_subtype;
        this.node_id = node_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getContact_date_time() {
        return contact_date_time;
    }

    public void setContact_date_time(String contact_date_time) {
        this.contact_date_time = contact_date_time;
    }

    public String getContact_type() {
        return contact_type;
    }

    public void setContact_type(String contact_type) {
        this.contact_type = contact_type;
    }

    public String getDebt_id() {
        return debt_id;
    }

    public void setDebt_id(String debt_id) {
        this.debt_id = debt_id;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getPhone_id() {
        return phone_id;
    }

    public void setPhone_id(String phone_id) {
        this.phone_id = phone_id;
    }

    public String getJudical_id() {
        return judical_id;
    }

    public void setJudical_id(String judical_id) {
        this.judical_id = judical_id;
    }

    public String getEnforcment_id() {
        return enforcment_id;
    }

    public void setEnforcment_id(String enforcment_id) {
        this.enforcment_id = enforcment_id;
    }

    public String getOther_contact_id() {
        return other_contact_id;
    }

    public void setOther_contact_id(String other_contact_id) {
        this.other_contact_id = other_contact_id;
    }

    public String getJob_date() {
        return job_date;
    }

    public void setJob_date(String job_date) {
        this.job_date = job_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreated_timestamp() {
        return created_timestamp;
    }

    public void setCreated_timestamp(String created_timestamp) {
        this.created_timestamp = created_timestamp;
    }

    public String getJob_type() {
        return job_type;
    }

    public void setJob_type(String job_type) {
        this.job_type = job_type;
    }

    public String getJob_subtype() {
        return job_subtype;
    }

    public void setJob_subtype(String job_subtype) {
        this.job_subtype = job_subtype;
    }

    public String getNode_id() {
        return node_id;
    }

    public void setNode_id(String node_id) {
        this.node_id = node_id;
    }

    @Override
    public String toString() {
        return "JobData{" +
                "id='" + id + '\'' +
                ", client_id='" + client_id + '\'' +
                ", contact_date_time='" + contact_date_time + '\'' +
                ", contact_type='" + contact_type + '\'' +
                ", debt_id='" + debt_id + '\'' +
                ", address_id='" + address_id + '\'' +
                ", phone_id='" + phone_id + '\'' +
                ", judical_id='" + judical_id + '\'' +
                ", enforcment_id='" + enforcment_id + '\'' +
                ", other_contact_id='" + other_contact_id + '\'' +
                ", job_date='" + job_date + '\'' +
                ", status='" + status + '\'' +
                ", created_timestamp='" + created_timestamp + '\'' +
                ", job_type='" + job_type + '\'' +
                ", job_subtype='" + job_subtype + '\'' +
                ", node_id='" + node_id + '\'' +
                '}';
    }
}
