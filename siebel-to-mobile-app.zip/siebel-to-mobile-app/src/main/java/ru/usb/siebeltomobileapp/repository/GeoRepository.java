package ru.usb.siebeltomobileapp.repository;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.usb.siebeltomobileapp.model.Geo;

import java.util.List;

@Repository
public class GeoRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public GeoRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Geo> getAllCoordinates(String externalId) {
        return jdbcTemplate.query(
                "select t.GEO_LAT as geoLan, t.GEO_LON as geoLon from T_DADATA_GEO_HISTORY t where t.ID_ADRESS =:extId",
                new MapSqlParameterSource()
                        .addValue("extId", externalId),
                new BeanPropertyRowMapper<>(Geo.class)
        );
    }
}
