package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.ContactResult;
import ru.usb.siebeltomobileapp.mapper.ContactResultMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class ContactResultSender {
    Logger logger = LoggerFactory.getLogger(ContactResultSender.class);

    private final ContactResultMap contactResultMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public ContactResultSender(ContactResultMap contactResultMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.contactResultMap = contactResultMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        ContactResult contactResult = contactResultMap.messageMapper(messageString);

        if (contactResult == null || contactResult.getData() == null || contactResult.getData().getId() == null || contactResult.getData().getClient_id() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.contact_result : {}", contactResult);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         service - MP.contact_result
         Поле	Формат данных от SIebel	Формат данных для МП
         contact_date	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         payment_date	MM/DD/YYYY	YYYY-MM-DD
         created_timestamp	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         */
        //contact_date
        if (aux.checkDateTime(contactResult.getData().getContact_date())) {
            contactResult.getData().setContact_date(aux.getUnixTime(contactResult.getData().getContact_date()));
        }
        //payment_date MM/DD/YYYY	YYYY-MM-DD
        if (aux.checkDate(contactResult.getData().getPayment_date())) {
            contactResult.getData().setPayment_date(aux.getMpDate(contactResult.getData().getPayment_date()));
        }
        //created_timestamp
        if (aux.checkDateTime(contactResult.getData().getCreated_timestamp())) {
            contactResult.getData().setCreated_timestamp(aux.getMpDateTime(contactResult.getData().getCreated_timestamp()));
        }

        //Отправка
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(contactResultMap.getJsonToStr(contactResult)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(contactResultMap.getJsonToStr(contactResult)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(contactResultMap.getJsonToStr(contactResult)));
            return false;
        }
    }
}
