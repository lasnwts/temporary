package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * {
 * "externalId": "1-IHMYC7R",
 * "internalId": "",
 * "data": {
 * "court": "Нотариус города Стеритамак РБ Бусалаева Наталья Алексеевна",
 * "result_of_courts_decision": "Совершена ИН",
 * "status": "Завершено",
 * "monitoring_result": "Сбор документов завершен",
 * "debt_id": "1-23RN74-17",
 * "number_cases_in_court": "У-0000605027-0",
 * "submission_claim_date": "",
 * "court_claim_sending_date": "",
 * "type": "Исполнительная надпись",
 * "id": "1-HPB8FZX",
 * "amount_judgment": "0",
 * "amount_requirements": "90986.81"
 * }
 * }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JudicialData {

    @JsonProperty("court")
    private String court; // "Нотариус города Стерлитамак РБ Бусалаева Наталья Алексеевна",

    @JsonProperty("result_of_courts_decision")
    private String result_of_courts_decision; //Совершена ИН

    @JsonProperty("status")
    private String status; //Завершено

    @JsonProperty("monitoring_result")
    private String monitoring_result; //Сбор документов завершен

    @JsonProperty("debt_id")
    private String debt_id; //1-23RN74-17

    @JsonProperty("number_cases_in_court")
    private String number_cases_in_court; //0000605027-0

    @JsonProperty("submission_claim_date")
    private String submission_claim_date;

    @JsonProperty("court_claim_sending_date")
    private String court_claim_sending_date;

    @JsonProperty("type")
    private String type; //Исполнительная надпись

    @JsonProperty("id")
    private String id; //1-HPB8FZX

    @JsonProperty("amount_judgment")
    private String amount_judgment; //0

    @JsonProperty("amount_requirements")
    private String amount_requirements; //90986.81

    public JudicialData() {
    }

    public JudicialData(String court, String result_of_courts_decision, String status, String monitoring_result, String debt_id, String number_cases_in_court,
                        String submission_claim_date, String court_claim_sending_date, String type, String id, String amount_judgment, String amount_requirements) {
        this.court = court;
        this.result_of_courts_decision = result_of_courts_decision;
        this.status = status;
        this.monitoring_result = monitoring_result;
        this.debt_id = debt_id;
        this.number_cases_in_court = number_cases_in_court;
        this.submission_claim_date = submission_claim_date;
        this.court_claim_sending_date = court_claim_sending_date;
        this.type = type;
        this.id = id;
        this.amount_judgment = amount_judgment;
        this.amount_requirements = amount_requirements;
    }

    public String getCourt() {
        return court;
    }

    public void setCourt(String court) {
        this.court = court;
    }

    public String getResult_of_courts_decision() {
        return result_of_courts_decision;
    }

    public void setResult_of_courts_decision(String result_of_courts_decision) {
        this.result_of_courts_decision = result_of_courts_decision;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMonitoring_result() {
        return monitoring_result;
    }

    public void setMonitoring_result(String monitoring_result) {
        this.monitoring_result = monitoring_result;
    }

    public String getDebt_id() {
        return debt_id;
    }

    public void setDebt_id(String debt_id) {
        this.debt_id = debt_id;
    }

    public String getNumber_cases_in_court() {
        return number_cases_in_court;
    }

    public void setNumber_cases_in_court(String number_cases_in_court) {
        this.number_cases_in_court = number_cases_in_court;
    }

    public String getSubmission_claim_date() {
        return submission_claim_date;
    }

    public void setSubmission_claim_date(String submission_claim_date) {
        this.submission_claim_date = submission_claim_date;
    }

    public String getCourt_claim_sending_date() {
        return court_claim_sending_date;
    }

    public void setCourt_claim_sending_date(String court_claim_sending_date) {
        this.court_claim_sending_date = court_claim_sending_date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAmount_judgment() {
        return amount_judgment;
    }

    public void setAmount_judgment(String amount_judgment) {
        this.amount_judgment = amount_judgment;
    }

    public String getAmount_requirements() {
        return amount_requirements;
    }

    public void setAmount_requirements(String amount_requirements) {
        this.amount_requirements = amount_requirements;
    }

    @Override
    public String toString() {
        return "DebtData{" +
                "court='" + court + '\'' +
                ", result_of_courts_decision='" + result_of_courts_decision + '\'' +
                ", status='" + status + '\'' +
                ", monitoring_result='" + monitoring_result + '\'' +
                ", debt_id='" + debt_id + '\'' +
                ", number_cases_in_court='" + number_cases_in_court + '\'' +
                ", submission_claim_date='" + submission_claim_date + '\'' +
                ", court_claim_sending_date='" + court_claim_sending_date + '\'' +
                ", type='" + type + '\'' +
                ", id='" + id + '\'' +
                ", amount_judgment='" + amount_judgment + '\'' +
                ", amount_requirements='" + amount_requirements + '\'' +
                '}';
    }
}
