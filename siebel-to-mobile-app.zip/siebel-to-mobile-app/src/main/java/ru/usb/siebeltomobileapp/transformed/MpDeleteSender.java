package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.MpDelete;
import ru.usb.siebeltomobileapp.mapper.MpDeleteMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class MpDeleteSender {
    Logger logger = LoggerFactory.getLogger(MpDeleteSender.class);

    private final MpDeleteMap mpDeleteMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public MpDeleteSender(MpDeleteMap mpDeleteMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.mpDeleteMap = mpDeleteMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка phoneString ==NULL");
            return false;
        }

        MpDelete mpDelete = mpDeleteMap.messageMapper(messageString);

        if (mpDelete == null || mpDelete.getExternalId() == null || mpDelete.getDeleteTimestamp() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.delete : {}", mpDelete);

        //Проверяем дату и меняем в случае ее присутствия
        if (aux.checkDateTime(mpDelete.getDeleteTimestamp())) {
            mpDelete.setDeleteTimestamp(aux.getUnixTime(mpDelete.getDeleteTimestamp()));
        }

        //Отправлен сообщение в топик
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(mpDeleteMap.getJsonToStr(mpDelete)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(mpDeleteMap.getJsonToStr(mpDelete)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(mpDeleteMap.getJsonToStr(mpDelete)));
            return false;
        }

    }
}
