package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Judicial;
import ru.usb.siebeltomobileapp.mapper.JudicialMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class JudicialSender {

    Logger logger = LoggerFactory.getLogger(JudicialSender.class);

    private final JudicialMap judicialMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public JudicialSender(JudicialMap judicialMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.judicialMap = judicialMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route      - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        Judicial judicial = judicialMap.messageMapper(messageString);

        if (judicial == null || judicial.getData() == null || judicial.getData().getMonitoring_result() == null
                || judicial.getData().getId() == null || judicial.getData().getDebt_id() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.judicial : {}", judicial);

        //Проверяем дату и меняем в случае ее присутствия
        if (aux.checkDate(judicial.getData().getSubmission_claim_date())) {
            judicial.getData().setSubmission_claim_date(aux.getMpDate(judicial.getData().getSubmission_claim_date()));
        }
        if (aux.checkDate(judicial.getData().getCourt_claim_sending_date())) {
            judicial.getData().setCourt_claim_sending_date(aux.getMpDate(judicial.getData().getCourt_claim_sending_date()));
        }

        //Отправлен сообщение в топик
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(judicialMap.getJsonToStr(judicial)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(judicialMap.getJsonToStr(judicial)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(judicialMap.getJsonToStr(judicial)));
            return false;
        }

    }
}
