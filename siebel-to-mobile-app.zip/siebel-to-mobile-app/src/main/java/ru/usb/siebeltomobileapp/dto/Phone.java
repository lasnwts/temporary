package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *  * {
 *  *    "externalId":"1-IHMYC9U",
 *  *    "internalId":"",
 *  *    "data":{
 *  *       "owner":"",
 *  *       "created_timestamp":"11/28/2023 07:33:12",
 *  *       "phone_number":"9119090567",
 *  *       "client_id":"1-23RH4S-25",
 *  *       "phone_type_id":"0V-RKYNX",
 *  *       "description":"",
 *  *       "sms_on":"true",
 *  *       "id":"1-23RH7Q-484"
 *  *    }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Phone {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;

    @JsonProperty("deleteTimestamp")
    private String deleteTimestamp;
    @JsonProperty("data")
    private PhoneData data;

    public Phone() {
    }

    public Phone(String externalId, String internalId, PhoneData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.data = data;
    }

    public Phone(String externalId, String internalId, String deleteTimestamp, PhoneData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.deleteTimestamp = deleteTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public PhoneData getData() {
        return data;
    }

    public void setData(PhoneData data) {
        this.data = data;
    }

    public String getDeleteTimestamp() {
        return deleteTimestamp;
    }

    public void setDeleteTimestamp(String deleteTimestamp) {
        this.deleteTimestamp = deleteTimestamp;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "externalId='" + externalId + '\'' +
                ", internalId='" + internalId + '\'' +
                ", data=" + data +
                '}';
    }
}
