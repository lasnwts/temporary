package ru.usb.siebeltomobileapp.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.config.KafkaRoutes;
import ru.usb.siebeltomobileapp.model.MessageFromKafka;
import ru.usb.siebeltomobileapp.model.topiclist;

import java.util.function.Consumer;

/**
 * Класс поиска маршрута для сообщения
 * Используется класс KafkaRoutes для сопоставления маршрута
 */
@Component
public class RouteFinder {

    Logger logger = LoggerFactory.getLogger(RouteFinder.class);

    private final KafkaRoutes kafkaRoutes;

    private String route;
    @Autowired
    public RouteFinder(KafkaRoutes kafkaRoutes) {
        this.kafkaRoutes = kafkaRoutes;
    }

    /**
     * Метод поиска маршрута по тэгам system_to
     *
     * @param message - сообщение от Кафка в универсальном формате
     * @return - строка с именем топика
     */
    public String getRoute(MessageFromKafka message) {

        /**
         * Если маршруты не прочитаны. Возвращаем null
         * Значит нет маршрута
         */
        if (kafkaRoutes.getTopiclist().isEmpty()) {
            logger.info("Справочник маршрутов пуст, искать маршруты негде. Заполните topiclist");
            return null;
        }

        //Инициализируем маршрут
        route = null;

        try {
            kafkaRoutes.getTopiclist().forEach(new Consumer<>() {
                @Override
                public void accept(topiclist topiclist) {

                    if (topiclist.getService().trim().equalsIgnoreCase(message.getService().trim().toLowerCase())) {
                        route = topiclist.getTopicsystemto().trim();
                        throw new RuntimeException();
                    }
                }
            });

        } catch (RuntimeException breakException) {
            logger.info("Найден маршрут[topic]" + route + " для сообщения, в систему systemto::" + message.getSystem_to().trim().toLowerCase());
        }

        if (route == null) {
            logger.info("Маршрут не найден, для сообщения" + message.toString());
        }
        return route;
    }
}
