package ru.usb.siebeltomobileapp.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.model.MessageFromKafka;

@Component
public class MessKafkaMapper {

    Logger logger = LoggerFactory.getLogger(MessKafkaMapper.class);

    private final Utilites utilites;

    @Autowired
    public MessKafkaMapper(Utilites utilites) {
        this.utilites = utilites;
    }

    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Мапинг строки в объект MessageFromKafka
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public MessageFromKafka mapKafkaMessage(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [MessKafkaMapper]:[mapKafkaMessage] поступил объект [message] == NULL! Класс [MessageFromKafka] метод [mapKafkaMessage]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        MessageFromKafka messageFromKafka = null;

        try {
            messageFromKafka = objectMapper.readValue(utilites.wrapNullJson(message), MessageFromKafka.class);
            logger.info("Object [MessageFromKafka]:{}", messageFromKafka);
            return messageFromKafka;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

}
