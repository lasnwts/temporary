package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Enforcement {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;

    @JsonProperty("deleteTimestamp")
    private String deleteTimestamp;

    @JsonProperty("data")
    private EnforcementData data;

    public Enforcement() {
    }

    public Enforcement(String externalId, String internalId, EnforcementData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.data = data;
    }

    public Enforcement(String externalId, String internalId, String deleteTimestamp, EnforcementData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.deleteTimestamp = deleteTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public EnforcementData getData() {
        return data;
    }

    public void setData(EnforcementData data) {
        this.data = data;
    }

    public String getDeleteTimestamp() {
        return deleteTimestamp;
    }

    public void setDeleteTimestamp(String deleteTimestamp) {
        this.deleteTimestamp = deleteTimestamp;
    }

    @Override
    public String toString() {
        return "Enforcement{" +
                "externalId='" + externalId + '\'' +
                ", internalId='" + internalId + '\'' +
                ", data=" + data +
                '}';
    }
}
