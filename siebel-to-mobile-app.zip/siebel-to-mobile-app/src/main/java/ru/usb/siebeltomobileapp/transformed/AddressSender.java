package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.config.Configure;
import ru.usb.siebeltomobileapp.dto.Address;
import ru.usb.siebeltomobileapp.mapper.AddressMap;
import ru.usb.siebeltomobileapp.model.GeoResponse;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;
import ru.usb.siebeltomobileapp.utils.GetGeo;
import ru.usb.siebeltomobileapp.utils.SiebelSender;

@Component
public class AddressSender {
    Logger logger = LoggerFactory.getLogger(AddressSender.class);
    private final AddressMap addressMap;
    private final KafkaProducerService kafkaProducerService;
    private final AuxMethods aux;
    private final GetGeo getGeo;
    private final SiebelSender siebelSender;

    @Autowired
    public AddressSender(AddressMap addressMap, KafkaProducerService kafkaProducerService, AuxMethods aux, GetGeo getGeo, SiebelSender siebelSender) {
        this.addressMap = addressMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
        this.getGeo = getGeo;
        this.siebelSender = siebelSender;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @param packId        - PackId из сообщения kafka
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route, String packId) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        Address address = addressMap.messageMapper(messageString);

        if (address == null || address.getData() == null || address.getData().getId() == null || address.getData().getClient_id() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.address : {}", address);


        /**
         * service - MP.address
         * Поле	Формат данных от SIebel	Формат данных для МП
         * created_timestamp	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         */

        //1 created_timestamp
        if (aux.checkDateTime(address.getData().getCreated_timestamp())) {
            address.getData().setCreated_timestamp(aux.getMpDate(address.getData().getCreated_timestamp()));
        }

        /**
         * Обогащение геокоординатами
         */
        GeoResponse geo = getGeo.getGeos(address.getExternalId(), packId);
        if (geo != null) {
            if (geo.isSuccess()) {
                address.getData().setLat(geo.getGeo().getGeoLan());
                address.getData().setLon(geo.getGeo().getGeoLon());
            }
            //Отправка сообщения в Зибель
            siebelSender.sendToSiebel(geo);
        }
        //отправка сообщения в МП
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(addressMap.getJsonToStr(address)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(addressMap.getJsonToStr(address)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(addressMap.getJsonToStr(address)));
            return false;
        }
    }
}
