package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactResult {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("internalId")
    private String internalId;

    @JsonProperty("deleteTimestamp")
    private String deleteTimestamp;

    @JsonProperty("data")
    private ContactResultData data;

    public ContactResult() {
    }

    public ContactResult(String externalId, String internalId, ContactResultData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.data = data;
    }

    public ContactResult(String externalId, String internalId, String deleteTimestamp, ContactResultData data) {
        this.externalId = externalId;
        this.internalId = internalId;
        this.deleteTimestamp = deleteTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getInternalId() {
        return internalId;
    }

    public void setInternalId(String internalId) {
        this.internalId = internalId;
    }

    public ContactResultData getData() {
        return data;
    }

    public void setData(ContactResultData data) {
        this.data = data;
    }

    public String getDeleteTimestamp() {
        return deleteTimestamp;
    }

    public void setDeleteTimestamp(String deleteTimestamp) {
        this.deleteTimestamp = deleteTimestamp;
    }

    @Override
    public String toString() {
        return "ContactResult{" +
                "externalId='" + externalId + '\'' +
                ", internalId='" + internalId + '\'' +
                ", data=" + data +
                '}';
    }
}
