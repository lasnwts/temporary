package ru.usb.siebeltomobileapp;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.siebeltomobileapp.config.Configure;
import ru.usb.siebeltomobileapp.config.KafkaRoutes;

@SpringBootApplication
public class SiebelToMobileAppApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(SiebelToMobileAppApplication.class);

    private final Configure configure;
    private final KafkaRoutes kafkaRoutes;
    @Autowired
    public SiebelToMobileAppApplication(Configure configure, KafkaRoutes kafkaRoutes) {
        this.configure = configure;
        this.kafkaRoutes = kafkaRoutes;
    }

    public static void main(String[] args) {
        SpringApplication.run(SiebelToMobileAppApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API (Project 3197. Service Siebel to Mobile App")
                .version(appVersion)
                .description("Проект 3197. Обмен между Siebel и Мобильным приложением." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        logger.info("+---------------------------------------------------------------------------------------------------------+");
        logger.info(" Created by 09.08.2023   : initial version: ver. 0.0.1");
        logger.info("-----------------------------------------------------------------------------------------------------------");
        logger.info("| Name of service        :{}", configure.getAppName());
        logger.info("| Description of service :{}", configure.getAppDescription());
        logger.info("=---------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason        :{}", configure.getAppDescription());
        logger.info("---------------------------------------------------------------------------------------------------------");
        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info(" <<<<<<<<<<<<Список сервисов и топиков >>>>>>>>>>>>>>>");
        kafkaRoutes.getTopiclist().forEach(topiclist -> {
            logger.info("+---------------------------------------------------+");
            logger.info("Topic:      |{}", topiclist.getTopicsystemto());
            logger.info("service:    |{}", topiclist.getService());
        });
        logger.info("#####################################################");

    }
}
