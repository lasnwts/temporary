package ru.usb.siebeltomobileapp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Сообщение универсально для Зибель
 * JSON-схема универсального запроса:
 * <p>
 * {
 * "system_from":"string",
 * "system_to":"string",
 * "service":"string",
 * "routeID":"string",
 * "mapper":"integer",
 * "packID":"string",
 * "pack":"string"
 * "error":"integer"
 * "errortext":"string"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class MessageFromKafka {
    @JsonProperty("system_from")
    private String system_from;

    @JsonProperty("system_to")
    private String system_to;

    @JsonProperty("service")
    private String service;

    @JsonProperty("routeid")
    private String routeID;

    @JsonProperty("mapper")
    private String mapper;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    private String errortext;

    public MessageFromKafka() {
    }

    public MessageFromKafka(String system_from, String system_to, String service,
                            String routeID, String mapper, String packID, String pack,
                            String error, String errortext) {
        this.system_from = system_from;
        this.system_to = system_to;
        this.service = service;
        this.routeID = routeID;
        this.mapper = mapper;
        this.packID = packID;
        this.pack = pack;
        this.error = error;
        this.errortext = errortext;
    }

    public String getSystem_from() {
        return system_from;
    }

    public void setSystem_from(String system_from) {
        this.system_from = system_from;
    }

    public String getSystem_to() {
        return system_to;
    }

    public void setSystem_to(String system_to) {
        this.system_to = system_to;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getRouteID() {
        return routeID;
    }

    public void setRouteID(String routeID) {
        this.routeID = routeID;
    }

    public String getMapper() {
        return mapper;
    }

    public void setMapper(String mapper) {
        this.mapper = mapper;
    }

    public String getPackID() {
        return packID;
    }

    public void setPackID(String packID) {
        this.packID = packID;
    }

    public String getPack() {
        return pack;
    }

    public void setPack(String pack) {
        this.pack = pack;
    }

    public String getError() {
        if (error == null) {
            return "";
        } else {
            return error;
        }
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrortext() {
        return errortext;
    }

    public void setErrortext(String errortext) {
        this.errortext = errortext;
    }

    @Override
    public String toString() {
        return "{" +
                "system_from='" + system_from + '\'' +
                ", system_to='" + system_to + '\'' +
                ", service='" + service + '\'' +
                ", routeID='" + routeID + '\'' +
                ", mapper='" + mapper + '\'' +
                ", packID='" + packID + '\'' +
                ", error='" + error + '\'' +
                ", errortext='" + errortext + '\'' +
                '}';
    }

    public String toStringV2() {
        return "MessageFromKafka{" +
                "system_from='" + system_from + '\'' +
                ", system_to='" + system_to + '\'' +
                ", service='" + service + '\'' +
                ", routeID='" + routeID + '\'' +
                ", mapper='" + mapper + '\'' +
                ", packID='" + packID + '\'' +
                ", pack='" + pack + '\'' +
                ", error='" + error + '\'' +
                ", errortext='" + errortext + '\'' +
                '}';
    }
}
