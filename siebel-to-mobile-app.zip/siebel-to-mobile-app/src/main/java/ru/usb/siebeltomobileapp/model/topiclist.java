package ru.usb.siebeltomobileapp.model;

import org.springframework.stereotype.Component;

@Component
public class topiclist {

    public String service;
    public String topicsystemto;

    public topiclist() {
    }

    public topiclist(String service, String topicsystemto) {
        this.service = service;
        this.topicsystemto = topicsystemto;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getTopicsystemto() {
        return topicsystemto;
    }

    public void setTopicsystemto(String topicsystemto) {
        this.topicsystemto = topicsystemto;
    }

    @Override
    public String toString() {
        return "topiclist{" +
                "service='" + service + '\'' +
                ", topicsystemto='" + topicsystemto + '\'' +
                '}';
    }
}
