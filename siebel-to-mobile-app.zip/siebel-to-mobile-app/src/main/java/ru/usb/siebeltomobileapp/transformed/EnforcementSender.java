package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Enforcement;
import ru.usb.siebeltomobileapp.mapper.EnforcementMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class EnforcementSender {

    Logger logger = LoggerFactory.getLogger(EnforcementSender.class);

    private final EnforcementMap enforcementMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public EnforcementSender(EnforcementMap enforcementMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.enforcementMap = enforcementMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
        }

        Enforcement enforcement = enforcementMap.messageMapper(messageString);

        if (enforcement == null || enforcement.getData() == null || enforcement.getData().getId() == null
                || enforcement.getData().getDebt_id() == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.enforcement : {}", enforcement);

        //Проверяем дату и меняем в случае ее присутствия
        //end_date
        if (aux.checkDate(enforcement.getData().getEnd_date())) {
            enforcement.getData().setEnd_date(aux.getMpDate(enforcement.getData().getEnd_date()));
        }
        //date
        if (aux.checkDateTime(enforcement.getData().getDate())) {
            enforcement.getData().setDate(aux.getMpDateTime(enforcement.getData().getDate()));
        }
        //excitation_date
        if (aux.checkDateTime(enforcement.getData().getExcitation_date())) {
            enforcement.getData().setExcitation_date(aux.getMpDateTime(enforcement.getData().getExcitation_date()));
        }

        //excitation_date
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(enforcementMap.getJsonToStr(enforcement)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(enforcementMap.getJsonToStr(enforcement)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(enforcementMap.getJsonToStr(enforcement)));
            return false;
        }

    }
}
