package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор клиента
 * actuality_date	Дата актуальности
 * birthday	Дата рождения
 * full_name	ФИО полностью
 * last_name	Фамилия
 * first_name	Имя
 * middle_name	Отчество
 * passport_issue_date	Дата выдачи паспорта
 * passport_issuer	Кто выдал паспорт
 * passport	Серия-номер паспорта
 * organization	Место работы
 * place_work	Место работы (должность)
 * client_alert	Алерты по пользователю (мошенник! Нельзя контактировать! И прочее…)
 * debts_count	Количество долгов
 * debts_sum 	Сумма долгов
 * sum_payments	Сумма платежей
 * all_osz	Общая сумма задолженности
 * lawsuit_avail	Есть ли исполнительные производства
 * death_date	Дата смерти
 * debt_overdue_count	Всего договоров на просрочке поле "в т.ч. на просрочке"
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientData {

    @JsonProperty("id")
    private String id; //	Идентификатор клиента

    @JsonProperty("actuality_date")
    private String actuality_date; //	Дата актуальности

    @JsonProperty("birthday")
    private String birthday; //	Дата рождения

    @JsonProperty("full_name")
    private String full_name; //	ФИО полностью

    @JsonProperty("last_name")
    private String last_name; //	Фамилия

    @JsonProperty("first_name")
    private String first_name; //	Имя

    @JsonProperty("middle_name")
    private String middle_name; //	Отчество

    @JsonProperty("passport_issue_date")
    private String passport_issue_date; //	Дата выдачи паспорта

    @JsonProperty("passport_issuer")
    private String passport_issuer; //	Кто выдал паспорт

    @JsonProperty("passport")
    private String passport; //	Серия-номер паспорта

    @JsonProperty("organization")
    private String organization; //	Место работы

    @JsonProperty("place_work")
    private String place_work; //	Место работы (должность)

    @JsonProperty("client_alert")
    private String client_alert; //	Алерты по пользователю (мошенник! Нельзя контактировать! И прочее…)

    @JsonProperty("debts_count")
    private String debts_count; //	Количество долгов

    @JsonProperty("debts_sum")
    private String debts_sum; // 	Сумма долгов

    @JsonProperty("sum_payments")
    private String sum_payments; //	Сумма платежей

    @JsonProperty("all_osz")
    private String all_osz; //	Общая сумма задолженности

    @JsonProperty("lawsuit_avail")
    private String lawsuit_avail; //	Есть ли исполнительные производства

    @JsonProperty("death_date")
    private String death_date; //	Дата смерти

    @JsonProperty("debt_overdue_count")
    private String debt_overdue_count; //	Всего договоров на просрочке поле "в т.ч. на просрочке"

    public ClientData() {
    }

    public ClientData(String id, String actuality_date, String birthday, String full_name, String last_name,
                      String first_name, String middle_name, String passport_issue_date, String passport_issuer,
                      String passport, String organization, String place_work, String client_alert, String debts_count,
                      String debts_sum, String sum_payments, String all_osz, String lawsuit_avail, String death_date,
                      String debt_overdue_count) {
        this.id = id;
        this.actuality_date = actuality_date;
        this.birthday = birthday;
        this.full_name = full_name;
        this.last_name = last_name;
        this.first_name = first_name;
        this.middle_name = middle_name;
        this.passport_issue_date = passport_issue_date;
        this.passport_issuer = passport_issuer;
        this.passport = passport;
        this.organization = organization;
        this.place_work = place_work;
        this.client_alert = client_alert;
        this.debts_count = debts_count;
        this.debts_sum = debts_sum;
        this.sum_payments = sum_payments;
        this.all_osz = all_osz;
        this.lawsuit_avail = lawsuit_avail;
        this.death_date = death_date;
        this.debt_overdue_count = debt_overdue_count;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getActuality_date() {
        return actuality_date;
    }

    public void setActuality_date(String actuality_date) {
        this.actuality_date = actuality_date;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getMiddle_name() {
        return middle_name;
    }

    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }

    public String getPassport_issue_date() {
        return passport_issue_date;
    }

    public void setPassport_issue_date(String passport_issue_date) {
        this.passport_issue_date = passport_issue_date;
    }

    public String getPassport_issuer() {
        return passport_issuer;
    }

    public void setPassport_issuer(String passport_issuer) {
        this.passport_issuer = passport_issuer;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getPlace_work() {
        return place_work;
    }

    public void setPlace_work(String place_work) {
        this.place_work = place_work;
    }

    public String getClient_alert() {
        return client_alert;
    }

    public void setClient_alert(String client_alert) {
        this.client_alert = client_alert;
    }

    public String getDebts_count() {
        return debts_count;
    }

    public void setDebts_count(String debts_count) {
        this.debts_count = debts_count;
    }

    public String getDebts_sum() {
        return debts_sum;
    }

    public void setDebts_sum(String debts_sum) {
        this.debts_sum = debts_sum;
    }

    public String getSum_payments() {
        return sum_payments;
    }

    public void setSum_payments(String sum_payments) {
        this.sum_payments = sum_payments;
    }

    public String getAll_osz() {
        return all_osz;
    }

    public void setAll_osz(String all_osz) {
        this.all_osz = all_osz;
    }

    public String getLawsuit_avail() {
        return lawsuit_avail;
    }

    public void setLawsuit_avail(String lawsuit_avail) {
        this.lawsuit_avail = lawsuit_avail;
    }

    public String getDeath_date() {
        return death_date;
    }

    public void setDeath_date(String death_date) {
        this.death_date = death_date;
    }

    public String getDebt_overdue_count() {
        return debt_overdue_count;
    }

    public void setDebt_overdue_count(String debt_overdue_count) {
        this.debt_overdue_count = debt_overdue_count;
    }

    @Override
    public String toString() {
        return "ClientData{" +
                "id='" + id + '\'' +
                ", actuality_date='" + actuality_date + '\'' +
                ", birthday='" + birthday + '\'' +
                ", full_name='" + full_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", first_name='" + first_name + '\'' +
                ", middle_name='" + middle_name + '\'' +
                ", passport_issue_date='" + passport_issue_date + '\'' +
                ", passport_issuer='" + passport_issuer + '\'' +
                ", passport='" + passport + '\'' +
                ", organization='" + organization + '\'' +
                ", place_work='" + place_work + '\'' +
                ", client_alert='" + client_alert + '\'' +
                ", debts_count='" + debts_count + '\'' +
                ", debts_sum='" + debts_sum + '\'' +
                ", sum_payments='" + sum_payments + '\'' +
                ", all_osz='" + all_osz + '\'' +
                ", lawsuit_avail='" + lawsuit_avail + '\'' +
                ", death_date='" + death_date + '\'' +
                ", debt_overdue_count='" + debt_overdue_count + '\'' +
                '}';
    }
}
