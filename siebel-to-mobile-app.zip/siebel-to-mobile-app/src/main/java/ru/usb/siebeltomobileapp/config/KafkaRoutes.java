package ru.usb.siebeltomobileapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "routes")
public class KafkaRoutes {

    private List<ru.usb.siebeltomobileapp.model.topiclist>   topiclist = new ArrayList<>();

    public KafkaRoutes() {
        //empty contruction
    }

    public List<ru.usb.siebeltomobileapp.model.topiclist> getTopiclist() {
        return topiclist;
    }

    public void setTopiclist(List<ru.usb.siebeltomobileapp.model.topiclist> topiclist) {
        this.topiclist = topiclist;
    }
}
