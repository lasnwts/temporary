package ru.usb.siebeltomobileapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiebelToMobileAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
