package ru.usb.bankrupt_stop_list_person.model.kih;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "DM_SFM_IP_BLKLST_CML_FT")
public class KihView {

    /**
     *  DM_SFM.DM_SFM_IP_BLKLST_CML_FT
     * ADD_DATE timestamp,
     * INN varchar(25),
     * CTG INTEGER,
     * NAME VARCHAR2(255)
     * INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ADD_DATE")
    private Date addDate;

    @Id
    @Column(name = "INN")
    private String inn;

    @Column(name = "OGRN")
    private String ogrn;

    @Column(name ="NAME")
    private String name;

    @Column(name = "TYPE")
    private String type;

    @Column(name ="NAME_FULL")
    private String nameFull;

    @Column(name ="NOTE")
    private String note;



}
