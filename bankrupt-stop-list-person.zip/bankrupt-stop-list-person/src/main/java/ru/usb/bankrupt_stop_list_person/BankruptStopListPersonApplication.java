package ru.usb.bankrupt_stop_list_person;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.bankrupt_stop_list_person.configure.TG;
import ru.usb.bankrupt_stop_list_person.utils.ApiLyaer;

@Log4j2
@SpringBootApplication
public class BankruptStopListPersonApplication implements CommandLineRunner {

	private final ApiLyaer apiLyaer;

	@Autowired
	public BankruptStopListPersonApplication(ApiLyaer apiLyaer) {
		this.apiLyaer = apiLyaer;
	}

	public static void main(String[] args) {
		SpringApplication.run(BankruptStopListPersonApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (bankrupt-stop-list-company)")
				.version(appVersion)
				.description("API bankrupt-stop-list-company." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {

		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		log.info("{}: Created by 12.06.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", TG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
		log.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);
		log.info("{}: Modified reason                   : 0.0.10", TG.UsbLogInfo);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);

		//Установим начальные переменные
		apiLyaer.setChdReady(false); //считаем, что ЦХД не готово
		apiLyaer.setWorkFlow(false); //выгрузки еще не включилась
		apiLyaer.setWorkTime(false); //время работы не наступило
	}
}
