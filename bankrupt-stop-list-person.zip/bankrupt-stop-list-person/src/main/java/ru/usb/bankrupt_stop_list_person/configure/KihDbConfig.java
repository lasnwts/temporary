package ru.usb.bankrupt_stop_list_person.configure;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;

/**
 * Конфигурация Oracle
 */

@Configuration
@ConfigurationProperties
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "kihEntityManagerFactory",
        transactionManagerRef = "kihTransactionManager",
        basePackages = {
                "ru.usb.bankrupt_stop_list_person.repository.kih"
        })
public class KihDbConfig {

    @Value("${kih.schema}")
    private String defSchema;


    @Bean(name = "kihDataSource")
    @ConfigurationProperties(prefix = "spring.kih.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }


    @Bean(name = "kihEntityManagerFactory")
    @Qualifier("kihEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                       @Qualifier("kihDataSource") DataSource dataSource) {

        HashMap<String, Object> properties = new HashMap<>();
        //properties.put("hibernate.hbm2ddl.auto", "validate");
        properties.put("hibernate.default_schema", defSchema);
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");

        return builder.dataSource(dataSource)
                .properties(properties)
                .packages("ru.usb.bankrupt_stop_list_person.model.kih")
//                .persistenceUnit("Test2")
                .build();
    }


    @Bean(name = "kihTransactionManager")
    public PlatformTransactionManager bookTransactionManager(@Qualifier("kihEntityManagerFactory") EntityManagerFactory kihEntityManagerFactory) {
        return new JpaTransactionManager(kihEntityManagerFactory);
    }


}
