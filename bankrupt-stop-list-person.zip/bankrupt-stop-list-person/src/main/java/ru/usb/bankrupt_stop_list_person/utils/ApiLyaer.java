package ru.usb.bankrupt_stop_list_person.utils;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import ru.usb.bankrupt_stop_list_person.configure.Configure;
import ru.usb.bankrupt_stop_list_person.configure.TG;
import ru.usb.bankrupt_stop_list_person.repository.cb.CreSlCompanyRepo;
import ru.usb.bankrupt_stop_list_person.repository.kih.KihRepo;
import ru.usb.bankrupt_stop_list_person.service.DeleteRecord;
import ru.usb.bankrupt_stop_list_person.service.mail.ServiceMailError;


@Log4j2
@Component
public class ApiLyaer {

    private final CreSlCompanyRepo slCompanyRepo;
    private final KihRepo kihRepo;
    private final DeleteRecord deleteRecord;
    private final Configure configure;

    private final ServiceMailError serviceMailError;

    private static final String CONST = "<br>\n\r";

    @Autowired
    public ApiLyaer(CreSlCompanyRepo slCompanyRepo, KihRepo kihRepo, DeleteRecord deleteRecord, Configure configure,
                   ServiceMailError serviceMailError) {
        this.slCompanyRepo = slCompanyRepo;
        this.kihRepo = kihRepo;
        this.deleteRecord = deleteRecord;
        this.configure = configure;
        this.serviceMailError = serviceMailError;
    }

    /**
     * Число записей
     * @return - результат в виде строки
     */
    public String getCount(){
        return "Записи за сегодня ЦХД=" + kihRepo.getCount() + " CreditBility=" + slCompanyRepo.getCount();
    }

    /**
     * Удаление NumInsert из CRE
     * @param numInsert - ID записей
     */
    public void deleteNumInsert(int numInsert){
        log.info("{}:Получена команда на удаление NumInsert= {}", TG.UsbLogInfo, numInsert);
        deleteRecord.deleteProcedure(numInsert);
    }

    /**
     * Получегние статуса процесса
     * @return - строка со статусом
     */
    public String getStatus(){
        String result="Исключаемые компании:" + CONST +
                "Число обработанных (просмотренных) записей   :" + configure.getProcessedExRecord() + CONST +
                "Число добавленных в CRE исключаемых компаний :" + configure.getAddExRecord() + CONST +
                "Добавляемые компании:" + CONST +
                "Число обработанных (просмотренных) записей   :" + configure.getProcessedInRecord() + CONST +
                "Число добавленных в CRE включаемых  компаний :" + configure.getAddInRecord();

        log.info("{}: Получен запрос на состояние процесса:{}", TG.UsbLogInfo, result);
        return result;
    }

    /**
     * Прерываени процесса выгрузки
     * @return - строка с информацией
     */
    public String breakProcess(){
        log.info("{}: Получен запрос на прерывание процесса.", TG.UsbLogInfo);
        String result="Состояние выгрузки перед прерыванием процесса." + CONST +
                "Исключаемые компании:" + CONST +
                "Число обработанных (просмотренных) записей  :" + configure.getProcessedExRecord() + CONST +
                "Число добавленных в CRE исключаемых компаний:" + configure.getAddExRecord() + CONST +
                "Добавляемые компании:" + CONST +
                "Число обработанных (просмотренных) записей  :" + configure.getProcessedInRecord() + CONST +
                "Число добавленных в CRE включаемых  компаний:" + configure.getAddInRecord();
        configure.setMistakeSync(true); //Устанавливаем наличие ошибки
        return result;
    }


    //Получаем готова витрина? = true
    public boolean getChdReady(){
        return configure.isChdReady();
    }

    //Потоки уже работают? = true
    public boolean getWorkFlow(){
        return configure.isWorkFlow();
    }

    //Время работы? = true
    public boolean getWorkTime(){
        return configure.isWorkTime();
    }

    //Установить готовность ЦХД
    public void setChdReady(boolean ready){
        log.info("{} Устанавливаем готовность ЦХД в {}", TG.UsbLogInfo, ready);
        configure.setChdReady(ready);
    }

    //Установить признак, что выгрузка запущена
    public void setWorkFlow(boolean working){
        log.info("{} Устанавливаем, что выгрузка активна в {}", TG.UsbLogInfo, working);
        configure.setWorkFlow(working);
    }

    //Устанавливаем, что время для выгрузки наступило
    public void setWorkTime(boolean work){
        log.info("{} Наступило время для работы потоков? true-да, false-нет ::{}", TG.UsbLogInfo, work);
        configure.setWorkTime(work);
    }

    //Проверка того, что ЦХД готово
    public void checkReadyChd(){
        if(kihRepo.getReady()>0){
            log.info("{}: ЦХД готово.", TG.UsbLogInfo);
            setChdReady(true);
        }
    }

    //Отправка почты
    public void sendMessage(String body){
        serviceMailError.sendMailErrorSubject("FSD_стоп_листы_выгрузка", body);
    }

}
