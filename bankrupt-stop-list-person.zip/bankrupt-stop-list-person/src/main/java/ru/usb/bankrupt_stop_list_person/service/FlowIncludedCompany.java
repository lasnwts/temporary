package ru.usb.bankrupt_stop_list_person.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.bankrupt_stop_list_person.configure.Configure;
import ru.usb.bankrupt_stop_list_person.configure.TG;
import ru.usb.bankrupt_stop_list_person.model.kih.KihView;
import ru.usb.bankrupt_stop_list_person.repository.kih.KihRepo;
import ru.usb.bankrupt_stop_list_person.service.mail.ServiceMailError;


import javax.persistence.EntityManager;
import java.sql.SQLException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Stream;

@Log4j2
@Service
public class FlowIncludedCompany {

    int lineCount;

    //@Autowired
    @Qualifier("kihEntityManagerFactory")
    private final EntityManager entityManager;

    private final KihRepo kihRepo;
    private final Configure configure;
    private final KihExecutors kihExecutors;
    private final SaveCompanyIncluded saveCompanyIncluded;
    private final DeleteRecord deleteRecord;
    private final ProcedureService procedureService;

    private final ServiceMailError serviceMailError;


    @Autowired
    public FlowIncludedCompany(@Qualifier("kihEntityManagerFactory")EntityManager entityManager, KihRepo kihRepo,
                               Configure configure, KihExecutors kihExecutors, SaveCompanyIncluded saveCompanyIncluded,
                               DeleteRecord deleteRecord, ProcedureService procedureService,
                               ServiceMailError serviceMailError) {
        this.entityManager = entityManager;
        this.kihRepo = kihRepo;
        this.configure = configure;
        this.kihExecutors = kihExecutors;
        this.saveCompanyIncluded = saveCompanyIncluded;
        this.deleteRecord = deleteRecord;
        this.procedureService = procedureService;
        this.serviceMailError = serviceMailError;
    }

    @Transactional(value = "kihTransactionManager", readOnly = true)
    public void startFlowCompany() {

        //Получаем список записей из базы
        Stream<KihView> fTableStream = null;
        //Получаем список записей из базы
        CopyOnWriteArrayList<KihView> kihViewList = new CopyOnWriteArrayList<>();


        try {
            int recordCount = kihRepo.getCount();
            log.info("{} Число записей в таблице: [KIH]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                log.info("{} Поскольку число записей в таблице: [KIH]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return;
            }
            fTableStream = kihRepo.getStreamAll();
            if (!checkStream(fTableStream)) {
                log.error("{} fTableStream = KihView.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return;
            }

            lineCount = 0;
            configure.setThreadSync(0);
            configure.setAddInRecord(0); //Счетчик добавленных
            configure.setProcessedInRecord(0); //общее число обработанных
            //Проверяем если есть ошибка выходим
            if (configure.getMistakeSync()){
                log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                return;
            }
            fTableStream.forEach(fTable -> {
                log.debug("line count={}", lineCount);
                log.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                configure.setProcessedInRecord(lineCount);
                //Проверяем если есть ошибка выходим
                if (configure.getMistakeSync()){
                    log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                    throw new RuntimeException("Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.");
                }
                kihExecutors.getExecutor(fTable, kihViewList);
                entityManager.detach(fTable); //Очищаем

                if (lineCount > 500 && !kihViewList.isEmpty()){
                    try {
                        saveCompanyIncluded.save(kihViewList, configure.getNumInsert());
                        kihViewList.clear();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            if (!kihViewList.isEmpty()){
                try {
                    saveCompanyIncluded.save(kihViewList, configure.getNumInsert());
                    kihViewList.clear();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            //############################################################################################################################
            log.info("{}: Обработано записей из БД Credit Bility:{}", TG.UsbLogInfo, lineCount);
            log.info("{}: Останавливаем процесс обработки включаемых компаний [FlowIncludedCompany]", TG.UsbLogInfo);
            configure.setIncludedReadySync(true);
        } catch (Exception e) {
            configure.setMistakeSync(true); //Устанавливаем, наличие ошибки
            log.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            log.error("{}:Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[KihView]:{}", TG.UsbLogError, e.getMessage());
            log.error("{}:!PrintStackTrace:", TG.UsbLogError, e);
            serviceMailError.sendMailErrorSubject("FSD_стоп_листы_выгрузка",
                    "Возможно возникла какая то проблема:\n\rОписание::"+ e.getMessage());
            //Удаляем записи
            deleteRecord.deleteProcedure(configure.getNumInsert());
        } finally {
            if (fTableStream != null){
                fTableStream.close();
            }
        }
        log.info("{}:Закончен процесс добавления компаний в стоп-лист. Внесено: {}, всего обработано:{} записей.", TG.UsbLogInfo, configure.getAddInRecord(), configure.getProcessedInRecord());
        //Все хорошо, проверяем готовность потоков
        if (!configure.getMistakeSync() && configure.getExcludedReadySync()){
            //дергаем процедуру
            log.info("{}: Запускаем процедуру.", TG.UsbLogInfo);
            //procedureService.insertProcedureCre("COMPANY");
        }
    }


    /**
     * Проверка, что поток не NULL
     *
     * @param fTableStream - поток
     * @return - if exist = true
     */
    public boolean checkStream(Stream<KihView> fTableStream) {
        if (fTableStream == null) {
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            log.error("!!!!!!!!!!!!!  Stream<KihView     >                               !!!!!!!!!!");
            log.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }

}
