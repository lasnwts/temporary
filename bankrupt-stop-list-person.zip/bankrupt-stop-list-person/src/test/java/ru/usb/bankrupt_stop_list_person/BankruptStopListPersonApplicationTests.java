package ru.usb.bankrupt_stop_list_person;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankruptStopListPersonApplicationTests {

	@Test
	void contextLoads() {
	}

}
