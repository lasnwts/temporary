package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class PrcScheme implements Serializable {

   public String S;
   public String P_CODE;
   public String PRC;
   public String DATE_BEG;
   public String DATE_END;
   public String DEPART_FOR_CUT;

}