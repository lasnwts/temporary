package ru.usb.xbank_intgr_credit.service.loadfile;

/**
 * Ошибка кодировки при загрузке файла
 */
public class InvalidCharsetException extends Exception{
    public InvalidCharsetException(String message) {
        super(message);
    }
}
