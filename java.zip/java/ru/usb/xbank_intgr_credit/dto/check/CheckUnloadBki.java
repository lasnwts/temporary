package ru.usb.xbank_intgr_credit.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.dto.UnloadBki;
import ru.usb.xbank_intgr_credit.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckUnloadBki {
    private UnloadBki unloadBki;//Список кредитных договоров
    private LoadError loadError; //Ошибки

}
