package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.PrcSchemePosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class PrcSchemeHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public PrcSchemeHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;P_CODE;PRC;DATE_BEG;DATE_END

    /**
     * Преобразование строки в объект PrcSchemePosition
     * @param line - строка
     * @return - объект PrcSchemePosition
     */
    public PrcSchemePosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        PrcSchemePosition prcSchemePosition = new PrcSchemePosition();
        prcSchemePosition.setS(support.getPosition("S", values));
        prcSchemePosition.setPCode(support.getPosition("P_CODE", values));
        prcSchemePosition.setPrc(support.getPosition("PRC", values));
        prcSchemePosition.setDateBeg(support.getPosition("DATE_BEG", values));
        prcSchemePosition.setDateEnd(support.getPosition("DATE_END", values));
        return prcSchemePosition;
    }

}
