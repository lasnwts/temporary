package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;
import ru.usb.xbank_intgr_credit.model.LoadError;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class DogovMapper {

    private final Configure configure;

    @Autowired
    public DogovMapper(Configure configure) {
        this.configure = configure;
    }

    /**
     * Маппинг строки файла в объект
     *
     * @param line              - строка файла
     * @param dogovHeadPosition - позиция заголовков
     * @param fileName          - имя файла
     * @param numInsert         - номер записи
     * @param lineNumber        - номер строки в файле
     * @return - объект
     */
    public CheckDogov map(String line, DogovHeadPosition dogovHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        Dogov dogov = new Dogov();
        //Константы
        dogov.setNumInsert(numInsert);
        dogov.setFileName(configure.getArchiveName());
        dogov.setInputDate(new Date());

        try {
            if (dogovHeadPosition.getS() > -1) {
                dogov.setS(values[dogovHeadPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getClient() > -1) {
                dogov.setClient(values[dogovHeadPosition.getClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:CLIENT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSymbol() > -1) {
                dogov.setSymbol(values[dogovHeadPosition.getSymbol()]);
            } else {
                setLoadError("Не найден обязательный параметр:SYMBOL", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SYMBOL" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SYMBOL: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getNdogUs() > -1) {
                dogov.setNdogUs(values[dogovHeadPosition.getNdogUs()]);
            } else {
                setLoadError("Не найден обязательный параметр:NDOG_US", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:NDOG_US" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:NDOG_US: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDepart() > -1) {
                dogov.setDepart(getDepart(values[dogovHeadPosition.getDepart()])); //3-х символьное поле
                dogov.setDepartTbank(values[dogovHeadPosition.getDepart()]);//Прямое поле depart tbank
            } else {
                setLoadError("Не найден обязательный параметр:DEPART", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DEPART" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DEPART: {}", LG.USBLOGERROR, Thread.currentThread().getId(),e.getMessage());
        }


        try {
            if (dogovHeadPosition.getDateBeg() > -1 && checkDateLine(values[dogovHeadPosition.getDateBeg() ])) {
                dogov.setDateBeg(convertDateToSqlDate(parseDateLine(values[dogovHeadPosition.getDateBeg()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_BEG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_BEG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateEnd() > -1 && checkDateLine(values[dogovHeadPosition.getDateEnd()])) {
                dogov.setDateEnd(convertDateToSqlDate(parseDateLine(values[dogovHeadPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_END" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSum() > -1 && checkDecimalBool(values[dogovHeadPosition.getSum()])) {
                dogov.setSum(parseDecimal(values[dogovHeadPosition.getSum()]));
            } else {
                dogov.setSum(parseDecimal("0.00")); //Ставим 0 если пусто
                setLoadError("Обязательный параметр:SUM установлен в 0", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkp() > -1 && checkDecimalBool(values[dogovHeadPosition.getSumVkp()])) {
                dogov.setSumVkp(parseDecimal(values[dogovHeadPosition.getSumVkp()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_VKP: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPrc() > -1 && checkDecimalBool(values[dogovHeadPosition.getSumVkpPrc()])) {
                dogov.setSumVkpPrc(parseDecimal(values[dogovHeadPosition.getSumVkpPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PRC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_VKP_PRC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpDeb() > -1 && checkDecimalBool(values[dogovHeadPosition.getSumVkpDeb()])) {
                dogov.setSumVkpDeb(parseDecimal(values[dogovHeadPosition.getSumVkpDeb()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_DEB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_DEB" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_VKP_DEB: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPrcDeb() > -1 && checkDecimalBool(values[dogovHeadPosition.getSumVkpPrcDeb()])) {
                dogov.setSumVkpPrcDeb(parseDecimal(values[dogovHeadPosition.getSumVkpPrcDeb()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PRC_DEB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PRC_DEB" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_VKP_PRC_DEB: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPen() > -1 && checkDecimalBool(values[dogovHeadPosition.getSumVkpPen()])) {
                dogov.setSumVkpPen(parseDecimal(values[dogovHeadPosition.getSumVkpPen()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PEN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PEN" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_VKP_PEN: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateBki() > -1 && checkDateLine(values[dogovHeadPosition.getDateBki()])) {
                dogov.setDateBki(convertDateToSqlDate(parseDateLine(values[dogovHeadPosition.getDateBki()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BKI", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_BKI" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_BKI: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateOffer() > -1 && checkDateLine(values[dogovHeadPosition.getDateOffer()])) {
                dogov.setDateOffer(convertDateToSqlDate(parseDateLine(values[dogovHeadPosition.getDateOffer()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_OFFER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_OFFER" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_OFFER: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPskPrcBeg() > -1 && checkDecimalBool(values[dogovHeadPosition.getPskPrcBeg()])) {
                dogov.setPskPrcBeg(parseDecimal(values[dogovHeadPosition.getPskPrcBeg()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_PRC_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_PRC_BEG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PSK_PRC_BEG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        //PSK_PRC_BEG;PSK_BEG;PSK_PRC;PSK;UID;PROCESSED;PROCESSED_TEXT

        try {
            if (dogovHeadPosition.getPskBeg() > -1 && checkDecimalBool(values[dogovHeadPosition.getPskBeg()])) {
                dogov.setPskBeg(parseDecimal(values[dogovHeadPosition.getPskBeg()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_BEG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PSK_BEG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPskPrc() > -1 && checkDecimalBool(values[dogovHeadPosition.getPskPrc()])) {
                dogov.setPskPrc(parseDecimal(values[dogovHeadPosition.getPskPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_PRC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PSK_PRC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPsk() > -1 && checkDecimalBool(values[dogovHeadPosition.getPsk()])) {
                dogov.setPsk(parseDecimal(values[dogovHeadPosition.getPsk()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PSK: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getUid() > -1) {
                dogov.setUid(values[dogovHeadPosition.getUid()]);
            } else {
                setLoadError("Не найден обязательный параметр:UID", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:UID" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:UID: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        //20.11.2024 PDN;SUMM_PDN
        try {
            if (dogovHeadPosition.getPdn() > -1 && checkDecimalBool(values[dogovHeadPosition.getPdn()])) {
                dogov.setPdn(parseDecimal(values[dogovHeadPosition.getPdn()]));
            } else {
                setLoadError("Не найден обязательный параметр:PDN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PDN" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PDN: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSummPdn() > -1 && checkDecimalBool(values[dogovHeadPosition.getSummPdn()])) {
                dogov.setSummPdn(parseDecimal(values[dogovHeadPosition.getSummPdn()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUMM_PDN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUMM_PDN" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUMM_PDN: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        return new CheckDogov(dogov, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java. sql. Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Получаем 3-х значный код департамента. Пример 0-099-043-50 => 099
     * @param departTBank - код департамента от Тбанк
     * @return - код департамента из 3 символов
     */
    public String getDepart(String departTBank){
        if (departTBank == null || departTBank.isEmpty()) {
            return "";
        } else if (departTBank.trim().length() < 5) {
            return departTBank;
        } else {
            return departTBank.trim().substring(2,5);
        }
    }


}
