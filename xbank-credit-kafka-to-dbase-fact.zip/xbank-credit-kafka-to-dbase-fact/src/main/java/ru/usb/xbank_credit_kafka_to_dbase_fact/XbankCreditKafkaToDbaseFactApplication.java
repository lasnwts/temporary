package ru.usb.xbank_credit_kafka_to_dbase_fact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XbankCreditKafkaToDbaseFactApplication {

	public static void main(String[] args) {
		SpringApplication.run(XbankCreditKafkaToDbaseFactApplication.class, args);
	}

}
