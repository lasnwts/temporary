package ru.usb.xbank_credit_kafka_to_dbase_fact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XbankCreditKafkaToDbaseFactApplicationTests {

	@Test
	void contextLoads() {
	}

}
