package ru.usb.chdefs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChdEfsApplicationTests {

	@Test
	void contextLoads() {
	}

}
