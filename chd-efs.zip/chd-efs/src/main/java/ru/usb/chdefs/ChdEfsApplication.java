package ru.usb.chdefs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChdEfsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChdEfsApplication.class, args);
	}

}
