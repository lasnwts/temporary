package ru.usb.insurance_registers_sovkombank.service.ftp;

import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.cert.X509Certificate;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

import static it.sauronsoftware.ftp4j.FTPClient.TYPE_BINARY;

@Log4j2
@Service
public class FtpsClient {

    @Value("${ftps.server}")
    private String server;

    @Value("${ftps.port}")
    private int port;

    @Value("${ftps.charset}")
    private String charSet;

    // iterates over the files and prints details for each
    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    private SSLSocketFactory getSSLContext() {
        TrustManager[] trustManager = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
                //
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
                //
            }
        }};
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustManager, new SecureRandom());
        } catch (NoSuchAlgorithmException e) {
            log.error("{}: Ошибка алгоритма NoSuchAlgorithmException: {}", LG.UsbLogError, e.getMessage());
            log.debug("{}: Ошибка Stack NoSuchAlgorithmException: {}", LG.UsbLogError, e);
        } catch (KeyManagementException e) {
            log.error("{}: Ошибка алгоритма KeyManagementException: {}", LG.UsbLogError, e.getMessage());
            log.debug("{}: Ошибка Stack KeyManagementException: {}", LG.UsbLogError, e);
        }
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
        return sslSocketFactory;
    }

    /**
     * Получение списка файлов в каталоге
     *
     * @param user      - пользователь под который будет отправка
     * @param password  - пароль  под который будет отправка
     * @param directory - директория куда отправить
     * @return - Listб список файлов в каталоге
     * @throws IOException - ошибка
     */
    public Optional<List<String>> getListFile(String user, String password, String directory)
            throws FTPIllegalReplyException, IOException, FTPException, FTPAbortedException, FTPDataTransferException, FTPListParseException {
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        client.connect(server, port);
        client.login(user, password);
        client.setCharset(Charset.forName(charSet).toString());
        if (directory != null) {
            log.info("{}: Получен запрос на список файлов в директории:{}, логин={}", LG.UsbLogInfo, directory, user);
            client.changeDirectory(directory);
        } else {
            log.info("{}: Получен запрос на список файлов в основной директории:{}, логин={}", LG.UsbLogInfo, client.currentDirectory(), user);
        }
        FTPFile[] files = client.list();
        log.info("{}: Количество файлов в директории Count= {}", LG.UsbLogInfo, files.length);
        log.info("{}: Подключение к серверу FTPS для получения списка файлов", LG.UsbLogInfo);
        if (files.length > 0) {
            List<String> stringList = new ArrayList<>();
            for (FTPFile file : files) {
                String details = file.getName();
                if (file.getType() == 1) {
                    details = "[" + details + " DIR]";
                }
                details += " size: " + file.getSize();
                details += " date: " + dateFormater.format(file.getModifiedDate().getTime());
                stringList.add(details);
            }
            client.disconnect(true);
            return Optional.of(stringList);
        }
        client.disconnect(true);
        return Optional.empty();
    }

    /**
     * Отправка файл
     *
     * @param user
     * @param password
     * @param directory
     * @param file
     * @return
     */
    public FtpsResponse sendFile(String user, String password, String directory, File file) throws FTPIllegalReplyException, IOException, FTPException {
        File file2 = new File(file.getAbsolutePath());
        FtpsResponse ftpsResponse = new FtpsResponse();
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        try {
            client.connect(server, port);
            client.login(user, password);
            client.setCharset(Charset.forName(charSet).toString());
            client.setType(TYPE_BINARY);
            client.setPassive(true);
            client.setAutoNoopTimeout(3000);
            if (directory != null) {
                log.info("{}: Подключение к серверу FTPS[login={}] для отправки файла:{} в директорию:{}, размером={}", LG.UsbLogInfo, user, file.getAbsolutePath(), directory, file.length());
                client.changeDirectory(directory);
            } else {
                log.info("{}: Подключение к серверу FTPS[login={}] для отправки файла:{} в текущую директорию, размером={}", LG.UsbLogInfo, user, file.getAbsolutePath(), file.length());
            }
            client.upload(file, 0);
            FTPFile[] ftpFile = client.list(file.getName());
            long s1 = Arrays.stream(ftpFile).findFirst().get().getSize();
            long s3 = file.length();
            while (s1 < s3){
                client.upload(file, Arrays.stream(ftpFile).findFirst().get().getSize());
                ftpFile = client.list(file.getName());
                s1 = Arrays.stream(ftpFile).findFirst().get().getSize();
            }
            ftpsResponse.setMessage("Файл " + file.getName() + " записан в директорию.");
            ftpsResponse.setHttpStatus(HttpStatus.OK);
            log.info("{}: Файл:{}, записан в директорию.", LG.UsbLogInfo, file.getName());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        } catch (FTPException e) {
            log.error("{}: Возникла ошибка [FTPException] при передаче файла {}", LG.UsbLogError, e.getMessage());
            log.debug("{}: Stack при передаче файла {}", LG.UsbLogError, e);
            ftpsResponse.setHttpStatus(HttpStatus.FORBIDDEN);
            ftpsResponse.setMessage(e.getMessage());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        } catch (FTPIllegalReplyException | IllegalStateException | IOException | FTPAbortedException |
                 FTPDataTransferException | FTPListParseException e) {
            log.error("{}: Возникла ошибка [IllegalStateException | IOException| FTPIllegalReplyException | FTPException | FTPAbortedException | FTPDataTransferException ] при передаче файла {}", LG.UsbLogError, e.getMessage());
            log.error("{}: Stack при передаче файла {}", LG.UsbLogError, e);
            ftpsResponse.setHttpStatus(HttpStatus.SERVICE_UNAVAILABLE);
            ftpsResponse.setMessage(e.getMessage());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        }
        return ftpsResponse;
    }
}


