package ru.usb.insurance_registers_sovkombank.service.ftp;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;
import ru.usb.insurance_registers_sovkombank.utils.NewFileInputStream;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ClientFTPS {

    @Value("${ftps.server}")
    private String server;
    @Value("${ftps.port}")
    private int port;
    // iterates over the files and prints details for each
    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private SSLContext tlsSection() {
        TrustManager[] trustManagers = new TrustManager[]{new X509TrustManager() {
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                //
            }

            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                //
            }
        }};
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustManagers, new SecureRandom());
        } catch (Exception e) {
            log.error("{} Stcak trace :{}", LG.UsbLogError, e);
        }
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
        return sslContext;
    }

    /**
     * Метод отправки файла в директорию FTPS сервера
     *
     * @param file      - отправляемый файл
     * @param user      - пользователь под который будет отправка
     * @param password  - пароль  под который будет отправка
     * @param directory - директория куда отправить
     * @throws SocketException - ошибка
     * @throws IOException     - ошибка
     */
    public FtpsResponse get(String fileName, File file, String user, String password, String directory) throws SocketException, IOException {
        FTPSClient client = new FTPSClient(tlsSection());
        client.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
        FtpsResponse ftpsResponse = new FtpsResponse(client.getReplyCode(), client.getReplyString(), HttpStatus.METHOD_NOT_ALLOWED);
        try {
            client.connect(server, port);
            client.execAUTH("TLS"); //SSL
            log.info("{}: Подключение к серверу FTPS для передачи файла:{}", LG.UsbLogInfo, client.getReplyString());
        } catch (Exception e){
            log.error("{}: Возникла ошибка:{} при подключении к серверу FTPS для передачи файла. Error{}", LG.UsbLogError, client.getReplyString(), e.getMessage());
            log.debug("{}: Stack Trace Error", LG.UsbLogError, e);
            ftpsResponse = new FtpsResponse(client.getReplyCode(), client.getReplyString(), HttpStatus.FORBIDDEN);
            return ftpsResponse;
        }
        if (client.login(user, password)) {
            client.execPBSZ(0);
            client.execPROT("P");
            client.setFileType(FTP.BINARY_FILE_TYPE);
            client.enterLocalPassiveMode();
            if (client.changeWorkingDirectory(directory)){
                client.changeWorkingDirectory(directory); //Переключаемся в нужную директорию
            } else {
                ftpsResponse.setCode(client.getReplyCode());
                ftpsResponse.setMessage(client.getReplyString());
                ftpsResponse.setHttpStatus(HttpStatus.NOT_FOUND);
                return ftpsResponse;
            }
            InputStream inputs = new FileInputStream(file);
            client.setControlEncoding("UTF-8");
//            client.setControlEncoding("CP1251");//.setControlEncoding("CP1251");
            //client.sendCommand("OPTS UTF8 ON");
                    //.sendCommand("OPTS UTF8 ON")
            //.setControlEncoding("UTF-8");
//StandardCharsets.UTF_8.encode(fileName)
            client.storeFile(new String(fileName.getBytes("UTF-8")), inputs); //Отправка файла
//            client.storeFile(fileName, inputs); //Отправка файла
            ftpsResponse.setCode(client.getReplyCode());
            ftpsResponse.setMessage(client.getReplyString());
            if (client.getReplyCode() == 226){
             ftpsResponse.setHttpStatus(HttpStatus.OK);
            } else {
                ftpsResponse.setHttpStatus(HttpStatus.BAD_REQUEST);
            }
            log.info("{} Результат отправки: Code:{} Message:{}", LG.UsbLogInfo, client.getReplyCode(), client.getReplyString());
            inputs.close(); //Закрываем файл
            client.logout();
            client.disconnect();
            return ftpsResponse;
        }
        log.error("{} Сбой подключения к серверу: Code:{} Message:{}", LG.UsbLogInfo, client.getReplyCode(), client.getReplyString());
        ftpsResponse.setCode(client.getReplyCode());
        ftpsResponse.setMessage(client.getReplyString());
        ftpsResponse.setHttpStatus(HttpStatus.FORBIDDEN);
        client.logout();
        client.disconnect();
        return ftpsResponse;
    }

    /**
     * Получение списка файлов в каталоге
     *
     * @param user      - пользователь под который будет отправка
     * @param password  - пароль  под который будет отправка
     * @param directory - директория куда отправить
     * @return - Listб список файлов в каталоге
     * @throws SocketException - ошибка
     * @throws IOException     - ошибка
     */
    public Optional<List<String>> getListFile(String user, String password, String directory) throws IOException {
        FTPSClient client = new FTPSClient(tlsSection());
        client.connect(server, port);
        client.execAUTH("TLS"); //SSL
        log.info("{}: Подключение к серверу FTPS для получения списка файлов:{}", LG.UsbLogInfo, client.getReplyCode());
        if (client.login(user, password)) {
            client.execPBSZ(0);
            client.execPROT("P");
            client.setFileType(FTP.BINARY_FILE_TYPE);
            client.enterLocalPassiveMode();
            client.changeWorkingDirectory(directory); //Переключаемся в нужную директорию
            FTPFile[] files = client.listFiles();
            if (files != null && files.length > 0) {
                List<String> stringList = new ArrayList<>();
                for (FTPFile file : files) {
                    String details = file.getName();
                    if (file.isDirectory()) {
                        details = "[" + details + " DIR]";
                    }
                    details += "\t\t" + file.getSize();
                    details += "\t\t" + dateFormater.format(file.getTimestamp().getTime());
                    stringList.add(details);
                }
                client.logout();
                client.disconnect();
                return Optional.of(stringList);
            }
            client.logout();
            client.disconnect();
            return Optional.empty();
        }
        client.logout();
        client.disconnect();
        return Optional.empty();
    }
}
