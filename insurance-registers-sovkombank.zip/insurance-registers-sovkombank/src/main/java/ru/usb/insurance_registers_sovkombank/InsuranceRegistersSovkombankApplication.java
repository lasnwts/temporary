package ru.usb.insurance_registers_sovkombank;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.config.SSLConfig;
import ru.usb.insurance_registers_sovkombank.service.ftp.FtpsClients;
import ru.usb.insurance_registers_sovkombank.service.ftp.ClientFTPS;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

@Log4j2
@SpringBootApplication
public class InsuranceRegistersSovkombankApplication implements CommandLineRunner {

	@Autowired
	FtpsClients ftpsClients;
	@Autowired
	SSLConfig sslConfig;
	@Autowired
	ClientFTPS clientFTPS;

	public static void main(String[] args) {
		SpringApplication.run(InsuranceRegistersSovkombankApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (bankrupt-stop-list-company)")
				.version(appVersion)
				.description("API bankrupt-stop-list-company." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {

		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			log.info("{}: Directory:{}= created", LG.UsbLogInfo, path);
		} else {
			log.info("{}: Directory: {}= already exists", LG.UsbLogInfo, path);
		}

		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", LG.UsbLogInfo);
		log.info("{}: Created by 04.09.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", LG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", LG.UsbLogInfo);
		log.info("{}: Описание пакетов                  :", LG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", LG.UsbLogInfo);
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", LG.UsbLogInfo);
		log.info("{}: Modified reason                   : 0.0.10", LG.UsbLogInfo);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", LG.UsbLogInfo);

	//	sslConfig.sslConfig();
		System.setProperty("jdk.tls.useExtendedMasterSecret", "false");
		//ftpsClients.get2();

		//ru_o_preliminary_samples-ZIPReader.log C:\AppServer\Data\
		//        String server = "192.168.1.151";
//        String user = "ftpuser";
//        String password = "dREZfag23e";
	//	byte[] fileContent = Files.readAllBytes(new File("C:\\AppServer\\Data\\ru_o_preliminary_samples-ZIPReader.log").toPath());
//		clientFTPS.get( new File("C:\\AppServer\\Data\\ru_o_preliminary_samples-ZIPReader.log"),"ftpuser", "dREZfag23e", "test2");
//		log.info("========================= test2");
//
//		Optional<List<String>> s =  clientFTPS.getListFile("ftpuser", "dREZfag23e", "test2");
//		if (s.isPresent()){
//			List<String> s1 = s.get();
//			s1.forEach(new Consumer<String>() {
//				@Override
//				public void accept(String s) {
//					log.info("FILE::{}", s);
//				}
//			});
//		}
//		log.info("========================= корень");
//		Optional<List<String>> sq = clientFTPS.getListFile("ftpuser", "dREZfag23e", "..");
//		if (sq.isPresent()){
//			List<String> s1 = sq.get();
//			s1.forEach(new Consumer<String>() {
//				@Override
//				public void accept(String s) {
//					log.info("FILE::{}", s);
//				}
//			});
//		}


	}
}
