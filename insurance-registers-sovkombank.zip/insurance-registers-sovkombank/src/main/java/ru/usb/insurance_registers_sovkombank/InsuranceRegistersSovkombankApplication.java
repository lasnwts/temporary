package ru.usb.insurance_registers_sovkombank;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.service.ApiLayer;
import ru.usb.insurance_registers_sovkombank.service.ftp.FtpsClient;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * Документация
 * https://www.sauronsoftware.it/projects/ftp4j/
 * https://sourceforge.net/projects/ftp4j/
 * https://github.com/asbachb/ftp4j
 */

@Log4j2
@SpringBootApplication
public class InsuranceRegistersSovkombankApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceRegistersSovkombankApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:0.0.10}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (insurance-registers-sovkombank)")
				.version(appVersion)
				.description("API insurance-registers-sovkombank." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {

		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			log.info("{}: Directory:{}= created", LG.UsbLogInfo, path);
		} else {
			log.info("{}: Directory: {}= already exists", LG.UsbLogInfo, path);
		}

		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", LG.UsbLogInfo);
		log.info("{}: Created by 04.09.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", LG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", LG.UsbLogInfo);
		log.info("{}: insurance-registers-sovkombank    :", LG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", LG.UsbLogInfo);
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", LG.UsbLogInfo);
		log.info("{}: Modified reason                   : 0.0.10", LG.UsbLogInfo);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", LG.UsbLogInfo);

		System.setProperty("jdk.tls.useExtendedMasterSecret", "false");
		System.setProperty("ftp4j.activeDataTransfer.acceptTimeout", "5000");
	}
}
