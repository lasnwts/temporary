package ru.usb.insurance_registers_sovkombank.service.ftp;

public class v1_SSLSessionReuseFTPSClient {
}
