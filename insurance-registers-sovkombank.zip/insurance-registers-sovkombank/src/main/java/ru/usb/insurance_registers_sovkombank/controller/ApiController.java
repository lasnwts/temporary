package ru.usb.insurance_registers_sovkombank.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;
import ru.usb.insurance_registers_sovkombank.service.ApiLayer;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с потоками из БК в ЕФС. ", description = "<Включение, отключение сервиса>")
public class ApiController {

    private final ApiLayer apiLayer;

    @Autowired
    public ApiController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }


    @PostMapping(value = "/files", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/files. Метод:POST. Загрузка файла в хранилище:Upload",
            description = "Введите логин, пароль и директорию и бинарный файл.")
    public ResponseEntity<Map<String, String>> upload2(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam("directory") String directory,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        try {
            result.put("key", "1");
            result.put("path", "2");
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }


    @PostMapping(value = "/upload", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Выберите файл ля проверки в SandBox и нажмите Execute. Вы получите ответ в виде Json. Загрузите его в метод:createScanTaskFile.")
    public ResponseEntity<Map<String, String>> upload(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam("directory") String directory,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        log.info("{}: Поступил запрос на загрузку файла:{}, размером:{} на FTPS сервер.", LG.UsbLogInfo, files.getOriginalFilename(), files.getSize());
        try {
            File file = apiLayer.upload(files.getOriginalFilename(), files.getBytes());
            FtpsResponse ftpsResponse = apiLayer.sendFileToFtps(files.getOriginalFilename(), file,login, password, directory);
            apiLayer.delFile(file);
            result.put("file", file.getName());
            result.put("size", String.valueOf(file.length()));
            result.put("Code", String.valueOf(ftpsResponse.getCode()));
            result.put("Message", ftpsResponse.getMessage());
            return ResponseEntity.status(ftpsResponse.getHttpStatus()).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }


    @PostMapping(value = "/list")
    @Operation(summary = "Получить список файлов в директории.")
    public ResponseEntity<List<String>> getlist(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam("directory") String directory) {
        log.info("{}: Поступил запрос на список файлов в директории:{} на FTPS сервер.", LG.UsbLogInfo, directory);
        try {
            return ResponseEntity.status(HttpStatus.OK).body(apiLayer.getFiles(login, password, directory));
        } catch (Exception e) {
            log.warn("{}:  Возникла ошибка при запроса списка файлов. Ошибка - Не критичная:{}",LG.UsbLogWarning, e.getMessage());
            List<String> stringList = new ArrayList<>();
            stringList.add("Возникла ошибка при запроса списка файлов.");
            stringList.add(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(stringList);
        }
    }



}
