package ru.usb.insurance_registers_sovkombank.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;
import ru.usb.insurance_registers_sovkombank.service.ApiLayer;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер API. СТРАХОВАНИЕ_Автоматические реестры, направляемые в СК АО «Совкомбанк Страхование».Version:0.0.10")
public class ApiController {

    private final ApiLayer apiLayer;

    @Autowired
    public ApiController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }

    @PostMapping(value = "/upload", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Отправка файла на FTPS. Выберите файл для загрузки на ftps сервер.",description = "Введите логин, пароль и директорию (необязательно) и бинарный файл.")
    public ResponseEntity<Map<String, String>> upload(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        log.info("{}: Поступил запрос на загрузку файла:{}, размером:{} на FTPS сервер.", LG.UsbLogInfo, files.getOriginalFilename(), files.getSize());
        try {
            File file = apiLayer.upload(files.getOriginalFilename(), files.getBytes());
            FtpsResponse ftpsResponse = apiLayer.sendFileToFtps(login, password, directory, new File(file.getAbsolutePath()));
            apiLayer.delFile(file);
            if (ftpsResponse.getHttpStatus().is2xxSuccessful()){
                result.put("success", ftpsResponse.getMessage());
            } else {
                result.put("error", ftpsResponse.getMessage());
            }
            return ResponseEntity.status(ftpsResponse.getHttpStatus()).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("{}: Произошла ошибка, при отправке файла в FTPS:{}", LG.UsbLogError, e.getMessage());
            log.debug("{}: Stack trace, при отправке файла в FTPS:", LG.UsbLogError, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }


    @PostMapping(value = "/list")
    @Operation(summary = "Получить список файлов в директории.", description = "Введите логин, пароль и директорию (необязательно).")
    public ResponseEntity<List<String>> getlist(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory) {
        log.info("{}: Поступил запрос на список файлов в директории:{} на FTPS сервер.", LG.UsbLogInfo, directory);
        try {
            List<String> stringList = apiLayer.getList(login,password, directory);
            return ResponseEntity.status(HttpStatus.OK).body(stringList);
        } catch (Exception e) {
            log.warn("{}:  Возникла ошибка при запроса списка файлов. Ошибка - Не критичная:{}",LG.UsbLogWarning, e.getMessage());
            List<String> stringList = new ArrayList<>();
            stringList.add("Возникла ошибка при запроса списка файлов.");
            stringList.add(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(stringList);
        }
    }



}
