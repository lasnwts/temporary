package ru.usb.insurance_registers_sovkombank.model;

import lombok.*;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class FtpsResponse {
    private int code;
    private String message;
    private HttpStatus httpStatus;

    @Override
    public String toString() {
        return "FtpsResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", httpStatus=" + httpStatus +
                '}';
    }
}
