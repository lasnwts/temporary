package ru.usb.insurance_registers_sovkombank.service;

import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;
import ru.usb.insurance_registers_sovkombank.service.ftp.FtpsClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiLayer {

    private final FtpsClient ftpsClient;

    @Autowired
    public ApiLayer(FtpsClient ftpsClient) {
        this.ftpsClient = ftpsClient;
    }

    /**
     * Запись файла во временный каталог
     *
     * @param name    - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()) {
            log.debug("{}:file.canWrite()=true", LG.UsbLogInfo);
        }
        if (file.canRead()) {
            log.debug("{}:file.canRead()=true", LG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
            iofs.close();
        } catch (Exception e) {
            log.error("{}: Error2: FileOutputStream(file).write(content):", LG.UsbLogError, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     * @return - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(1000);
            if (Files.deleteIfExists(facFile.toPath())) {
                log.info("{}: Файл:{} удален из временной директории", LG.UsbLogInfo, facFile.getAbsolutePath());
            } else {
                log.info("{}: Файл:{} не был удален из временной директории!", LG.UsbLogInfo, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            log.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.UsbLogError, facFile.getAbsolutePath(), e.getMessage());
            log.debug("{}: Stack trace:", LG.UsbLogError, e);
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Отправка файла FTPS
     *
     * @param file      - файл
     * @param user      - login
     * @param password  - пароль
     * @param directory - директория
     * @return - FtpsResponse
     */
    public FtpsResponse sendFileToFtps(String user, String password, String directory, File file) {
        try {
            return ftpsClient.sendFile(user, password, directory, file);
        } catch (FTPIllegalReplyException | IOException | FTPException e) {
            log.error("{}: [ApiLayer] Ошибка при выполнении записи файла на сервер:{}", LG.UsbLogError, e.getMessage());
            return new FtpsResponse(403, e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Получение списка файлов в директории
     *
     * @param user      - логин
     * @param password  - пароль
     * @param directory - директория
     * @return - список файлов
     * @throws FTPIllegalReplyException - ошибка
     * @throws FTPAbortedException      - ошибка
     * @throws FTPDataTransferException - ошибка
     * @throws IOException              - ошибка
     * @throws FTPListParseException    - ошибка
     * @throws FTPException             - ошибка
     */
    public List<String> getList(String user, String password, String directory)
            throws FTPIllegalReplyException, FTPAbortedException, FTPDataTransferException, IOException, FTPListParseException, FTPException {
        Optional<List<String>> listOptional = ftpsClient.getListFile(user, password, directory);
        return listOptional.orElseGet(ArrayList::new);
    }


}
