package ru.usb.insurance_registers_sovkombank.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.insurance_registers_sovkombank.config.LG;
import ru.usb.insurance_registers_sovkombank.model.FtpsResponse;
import ru.usb.insurance_registers_sovkombank.service.ftp.ClientFTPS;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiLayer {

    private final ClientFTPS clientFTPS;

    @Autowired
    public ApiLayer(ClientFTPS clientFTPS) {
        this.clientFTPS = clientFTPS;
    }

    /**
     * Запись файла во временный каталог
     *
     * @param name - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()){

            log.debug("{}:file.canWrite()=true", LG.UsbLogInfo);
        }
        if (file.canRead()){
            log.debug("{}:file.canRead()=true", LG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}: Error2: FileOutputStream(file).write(content):", LG.UsbLogError, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Удалить файл из временной директории
     * @param facFile - FacFile
     * @return - FacFile
     * @throws IOException - ошибка
     */
    public boolean delFile(File facFile) throws IOException {
        if (Files.deleteIfExists(facFile.toPath())){
            log.info("{}: Файл:{} удален из временной директории", LG.UsbLogInfo, facFile.getAbsolutePath());
            return true;
        } else {
            log.info("{}: Файл:{} не был удален из временной директории!", LG.UsbLogInfo, facFile.getAbsolutePath());
            return false;
        }
    }

    /**
     * Отправка файла FTPS
     * @param file - файл
     * @param user - login
     * @param password - пароль
     * @param directory - директория
     * @return - FtpsResponse
     * @throws IOException - ошибка
     */
    public FtpsResponse sendFileToFtps(String fileName, File file, String user, String password, String directory) throws IOException {
        return clientFTPS.get(fileName, file, user, password, directory);
    }

    /**
     * Получение списка файлов в директории
     * @param user - логин
     * @param password - пароль
     * @param directory - директория
     * @return - список файлов
     * @throws IOException - ошибка
     */
    public List<String> getFiles(String user, String password, String directory) throws IOException {
        Optional<List<String>> listOptional = clientFTPS.getListFile(user, password, directory);
        return listOptional.orElseGet(ArrayList::new);
    }


}
