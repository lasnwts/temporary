package ru.usb.insurance_registers_sovkombank.service.ftp;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.stereotype.Service;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@Log4j2
@Service
public class FtpsClients {

    String server = "192.168.1.151";
    String user = "ftpuser";
    String password = "dREZfag23e";

    public void getFile() throws IOException {
        FTPSClient f = new SSLSessionReuseFTPSClient2();
        f.connect(server, 21);
        log.info("getReplyCode:{}", f.getReplyCode());
        //f.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
        f.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out), true));
        f.login(user, password);
        log.info("getReplyCode, pass:{}", f.getReplyCode());
        f.execPBSZ(0);
        log.info("getReplyCode, P:{}", f.getReplyCode());
        f.execPROT("P");
        log.info("getReplyCode,0:{}", f.getReplyCode());
        f.enterLocalPassiveMode();

        String remote = "samFromClient.txt"; //Place on FTP
        File fis = new File("C:/AppServer/Data/r.ttxlist-keys.txt");          //Place on your Client
        //Your FTP reads from the inputstream and store the file on remote-path
        InputStream inputs = new FileInputStream(fis);
        f.storeFile(remote, inputs);
        inputs.close();
        //f.logout();
        //FTPFile[] files = f.listFiles("");
        f.disconnect();
        return;
    }

    public void get2() {
        try {

            FTPSClient ftpClient = new FTPSClient("tls", false);

            ftpClient.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));

            ftpClient.connect(server, 21);

            int reply = ftpClient.getReplyCode();

            log.info("getReplyCode, pass:{}", ftpClient.getReplyCode());

            log.info("getReplyCode, P:{}", ftpClient.getReplyCode());
            ftpClient.execPBSZ(0);
            ftpClient.execPROT("P");

            if (FTPReply.isPositiveCompletion(reply)) {
                ftpClient.enterLocalPassiveMode();
                ftpClient.login(user, password);
                ftpClient.enterLocalPassiveMode();
//                FileOutputStream outputStream = new FileOutputStream(tempfile);
//                ftpClient.setFileType(FTPClient.ASCII_FILE_TYPE);
//                ftpClient.retrieveFile("test.txt", outputStream);
//                outputStream.close();
                String remote = "new.txt"; //Place on FTP


                File fis = new File("C:/AppServer/Data/r.ttxlist-keys.txt");          //Place on your Client
                //Your FTP reads from the inputstream and store the file on remote-path
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fis));
                boolean res = ftpClient.storeFile(remote, bis);
                log.info("res={}", res);
                bis.close();

                //

                // lists files and directories in the current working directory
                FTPFile[] files = ftpClient.listFiles();

                // iterates over the files and prints details for each
                DateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                for (FTPFile file : files) {
                    String details = file.getName();
                    if (file.isDirectory()) {
                        details = "[" + details + "]";
                    }
                    details += "\t\t" + file.getSize();
                    details += "\t\t" + dateFormater.format(file.getTimestamp().getTime());
                    System.out.println(details);
                }

                ftpClient.logout();
                ftpClient.disconnect();
            }
        } catch (IOException ioe) {
            System.out.println("FTP client received network error");
        }
    }

}
