package ru.usb.insurance_registers_sovkombank.config;

import lombok.extern.log4j.Log4j2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class SSLConfig {

    private static final Logger log = LoggerFactory.getLogger(SSLConfig.class);
    @Value("${http.client.ssl.trust-store}")
    private String trustStore;
    @Value("${http.client.ssl.trust-store-password}")
    private String tsPass;

    @EventListener(ApplicationReadyEvent.class)
    @Order(1)
    public void sslConfig() {
        Path path;
        try {
            path = Paths.get(trustStore);
            log.info("UsbLogInfo:Файл сертификата: существует{} существует", path.toString());
            extracted(path.toString());

        } catch (Exception exception) {
            log.error("UsbLogError: Произошла ошибка, возможно файл сертификата: {} не найден", trustStore);
            log.error("UsbLogError: SSLConfig: {}", exception.getMessage());
        }
    }

    private void extracted(String path) {
//        System.setProperty("javax.net.ssl.trustStore", path);
//        System.setProperty("javax.net.ssl.trustStorePassword", tsPass);
//        log.info("UsbLogInfo: SSL:[{}] сертификат зарегистрирован в системе", path);
    }

}
