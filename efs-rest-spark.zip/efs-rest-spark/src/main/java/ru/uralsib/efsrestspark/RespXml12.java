package ru.uralsib.efsrestspark;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.List;

// Класс для парсинга xml ответа из spark
@JsonIgnoreProperties(ignoreUnknown = true)
@JacksonXmlRootElement(localName = "SiebelMessage")
public class RespXml12 {
    @JacksonXmlProperty(localName = "ReqID")
    String reqid;
    @JacksonXmlProperty(localName = "ReqCode")
    String reqcode;
    @JacksonXmlProperty(localName = "ReqMsg")
    String reqmsg;

    @JacksonXmlProperty(localName = "Company")
    @JacksonXmlElementWrapper(localName = "ListOfCompany")
    List<listofcompany> listofcompany;

    public static class listofcompany {
        @JacksonXmlProperty(localName = "SparkID")
        String sparkid;
        @JacksonXmlProperty(localName = "INN")
        String inn;
        @JacksonXmlProperty(localName = "OGRN")
        String ogrn;

        @JacksonXmlProperty(localName = "Leader")
        String leader;
        @JacksonXmlProperty(localName = "OKVED")
        String okved;
        @JacksonXmlProperty(localName = "Status")
        String status;
        @JacksonXmlProperty(localName = "DateFirstReg")
        String datefirstreq;


        public String getSparkid() { return sparkid; }

        public void setSparkid(String sparkid) { this.sparkid = sparkid; }

        public String getInn() { return inn; }

        public void setInn(String inn) { this.inn = inn; }
        public String getOgrn() { return ogrn; }

        public void setOgrn(String ogrn) { this.ogrn = ogrn; }

        public String getLeader() { return leader; }

        public void setLeader(String leader) { this.leader = leader; }
        public String getOkved() { return okved; }

        public void setOkved(String okved) { this.okved = okved; }
        public String getStatus() { return status; }

        public void setStatus(String status) { this.status = status; }
        public String getDatefirstreq() { return datefirstreq; }

        public void setDatefirstreq(String datefirstreq) { this.datefirstreq = datefirstreq; }


    }
    public String getReqid() {
        return reqid;
    }

    public void setReqid(String reqid) {
        this.reqid = reqid;
    }

    public  String getReqcode() {
        return reqcode;
    }

    public void setReqcode(String reqcode) {
        this.reqcode = reqcode;
    }

    public String getReqmsg() {
        return reqmsg;
    }

    public void setReqmsg(String reqmsg) {
        this.reqmsg = reqmsg;
    }
    public List<RespXml12.listofcompany> getListofcompany() {
        return listofcompany;
    }

    public void setListofcompany(List<RespXml12.listofcompany> listofcompany) {
        this.listofcompany = listofcompany;
    }

}
