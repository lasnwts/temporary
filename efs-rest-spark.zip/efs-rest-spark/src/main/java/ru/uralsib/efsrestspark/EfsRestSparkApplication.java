package ru.uralsib.efsrestspark;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableSwagger2
public class EfsRestSparkApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EfsRestSparkApplication.class, args);
	}

	private static final Logger log = LoggerFactory.getLogger(EfsRestSparkApplication.class);

	/**
	 * Секция о программе
	 */
	@Value("${info.application.name}")
	private String appName;

	@Value("${info.application.description}")
	private String appDescription;

	@Bean
	public Docket swaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(Predicates.or(
						PathSelectors.ant("/v1/**")
				))
				.apis(RequestHandlerSelectors.basePackage("ru.uralsib"))
				.build()
				.apiInfo(apiInfo());
	}


	private ApiInfo apiInfo() {
		Contact contact = new Contact("Pushin Sergey", "../", "PushinSD@spb.uralsib.ru");
		return new ApiInfoBuilder()
				.title("Spring boot 2 Api Title 23/01/2024")
				.description("Api Definition by @Sergey")
				.version("0.0.1")
				.license("Apache 2.0")
				.licenseUrl("http://www.apache.org/license/LICENSE-2.0")
				.contact(contact)
				.build();
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		log.info("{}: Created by 07.10.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", LG.USBLOGINFO);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", LG.USBLOGINFO);
		log.info("{}: Описание пакетов                  : ", LG.USBLOGINFO);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		log.info("{}: Name of service                   : {}", LG.USBLOGINFO, appName);
		log.info("{}: Description of service            : {}", LG.USBLOGINFO, appDescription);
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.10", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.11 Класс ApiLyaer, метод insertAttr. Изменено наименование операции, на графики каникул", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.16 Пред. прод 03.02.2025", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.17 Прод. 14.02.2025, заблокировано проставление статуса apiLayer.updateStageHistory(FINISHED), EXP_DOC_STATUS", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.18 Прод. 14.02.2025, заблокировано проставление статуса stage_history set EXP_BLOB_STATUS", LG.USBLOGINFO);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", LG.USBLOGINFO);

	}
}
