package ru.uralsib.efsrestspark;

import io.swagger.annotations.ApiModel;

import java.util.List;


@ApiModel(description = "Ответ на входной запрос")

public class responseTEST {

    private String sparkid;
    private String ogrn;
    private String innd;
    private String shortname;
    private String leader;
    private String okved;
    private String status;
    private String datefirstreq;
    private String legaladdress;





    List<branchrosstat> branchrosstat;
    public static class branchrosstat {

        private String sparkids;
        private String inns;


        public String getInns() {
            return inns;
        }

        public void setInns(String inns) {
            this.inns = inns;
        }

        public String getSparkids() {
            return sparkids;
        }

        public void setSparkids(String sparkids) {
            this.sparkids = sparkids;
        }


    }
    private String error;


    public responseTEST() {
        super();
    }

    public responseTEST(String sparkid, String ogrn, String innd, String shortname,
                        String leader, String okved, String status, String datefirstreq,
                        String legaladdress) {
        this.sparkid = sparkid;
        this.ogrn = ogrn;
        this.innd = innd;
        this.shortname = shortname;
        this.leader = leader;
        this.okved = okved;
        this.status = status;
        this.datefirstreq = datefirstreq;
        this.legaladdress = legaladdress;
       /* this.sparkids = sparkids;
        this.inns = inns;
        this.ogrns = ogrns;
        this.names = names;
        this.managers = managers;
        this.addresss = addresss;
        this.notdata = notdata;
*/

    }

    public String getSparkid() {
        return sparkid;
    }

    public void setSparkid(String sparkid) {
        this.sparkid = sparkid;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getInnd() {
        return innd;
    }

    public void setInnd(String innd) {
        this.innd = innd;
    }
    public  String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {  this.shortname = shortname;  }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public String getOkved() {
        return okved;
    }

    public void setOkved(String okved) {
        this.okved = okved;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDatefirstreq() {
        return datefirstreq;
    }

    public void setDatefirstreq(String datefirstreq) {
        this.datefirstreq = datefirstreq;
    }

    public String getLegaladdress() {       return legaladdress;
    }

    public void setLegaladdress(String legaladdress) {
        this.legaladdress = legaladdress;
    }


   /* public List<response.coownerrosstat> getCoownerrosstat() {
        return coownerrosstat;
    }

    public void setCoownerrosstat(List<response.coownerrosstat> coownerrosstat) {        this.coownerrosstat = coownerrosstat;
    }
*/

    public List<branchrosstat> getBranchrosstat() {
        return branchrosstat;
    }

    public void setBranchrosstat(List<branchrosstat> branchrosstat) {        this.branchrosstat = branchrosstat;
    }

    public  String getError() {
        return error;
    }

    public void setError(String error) {  this.error = error;  }


}
