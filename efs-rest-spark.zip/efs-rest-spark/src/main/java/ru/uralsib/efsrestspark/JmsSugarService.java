package ru.uralsib.efsrestspark;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

@Component
public class JmsSugarService {
   // private static final Logger log = LoggerFactory.getLogger(JmsDboReplyService.class);
   private static final Logger log = LoggerFactory.getLogger(RestControl.class);

    @Value("${jms.queueSugar}")
    private String queue;
    @Value("${jms.queueSugar12}")
    private String queue12;
    @Value("${jms.timeout}")
    private int timeout;

    // Дебаг
    @Value("${log.debug}")
    private int logDebug;

    @Autowired
    JmsTemplate jmsTemplate;



    // Метод сериализации xml запроса в spark
    public static String serializeToXMLSugar(String reqid, String inn) {
        log.info("UsbLogInfo : " + "Сериализации xml для spark");
        try {

            XmlMapper xmlMapper = new XmlMapper();
            return xmlMapper.writeValueAsString(new request(reqid,inn));
        } catch (JsonProcessingException e) {
            log.error("UsbLogWarning : " + "Ошибка сериализации xml для spark: " + e.getMessage());
            return null;
        }
    }

    // Метод десериализации xml запроса в spark
    public static responseXMM deserializeToXMLSugar(String xmlStr) {
        log.info("UsbLogInfo : " + "Десериализации xml из spark");
        try {
            XmlMapper xmlMapper = new XmlMapper();

            return xmlMapper.readValue(xmlStr, responseXMM.class);
        } catch (JsonProcessingException e) {
            log.error("UsbLogWarning : " + "Ошибка десериализации xml из spark: " + e.getMessage());
            return null;
        }
    }
   public static response12 deserializeToXMLSugar12(String xmlStr) {
        log.info("UsbLogInfo : " + "Десериализации xml из spark");
        try {
            XmlMapper xmlMapper = new XmlMapper();

            return xmlMapper.readValue(xmlStr, response12.class);
        } catch (JsonProcessingException e) {
            log.error("UsbLogWarning : " + "Ошибка десериализации xml из spark: " + e.getMessage());
            return null;
        }
    }


    // Метод отправки сообщения в Spark с ожиданием ответа
   /* public response send(String inn) throws JMSException {
        log.info("UsbLogInfo : " + "Подготовка к отправке JMS сообщения в Spark");
        jmsTemplate.setReceiveTimeout(timeout);

        Message receive = jmsTemplate.sendAndReceive(queue, new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {

                String msgXml = serializeToXMLSugar(inn);
                if (msgXml != null) {
                    TextMessage msg = session.createTextMessage(msgXml);
                    msg.setJMSReplyTo(session.createQueue(queue));
                    if (logDebug == 1) {
                        log.info("UsbLogDebug : " + "Сформировано сообщение для Spark: " + msg);
                    } else {
                        log.info("UsbLogInfo : " + "Сформировано сообщение для Spark");
                    }
                    return msg;
                } else {
                    log.error("UsbLogWarning : " + "Ошибка формирования сообщения для Spark");
                    throw new JMSException("Ошибка формирования сообщения для Spark");
                }
            }
        });
        if (logDebug == 1) {
            log.info("UsbLogDebug : " + "Получено ответное JMS сообщения от Spark: " + receive);
        } else {
            log.info("UsbLogInfo : " + "Получено ответное JMS сообщения от Spark");
        }

        if (receive != null) {
            return deserializeToXMLSugar(((TextMessage) receive).getText());
        } else {
            return null;
        }
    }*/
    public responseXMM send(String reqid,String inn) throws JMSException {
        log.info("UsbLogInfo : " + "Подготовка к отправке JMS сообщения в Spark " + reqid);
        jmsTemplate.setReceiveTimeout(timeout);

        Message receive = jmsTemplate.sendAndReceive(queue, new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {

                String msgXml = serializeToXMLSugar(reqid,inn);
                if (msgXml != null) {
                    TextMessage msg = session.createTextMessage(msgXml);
                    msg.setJMSReplyTo(session.createQueue(queue));
                    if (logDebug == 1) {
                        log.info("UsbLogDebug : " + "Сформировано сообщение для Spark: " + msg);
                    } else {
                        log.info("UsbLogInfo : " + "Сформировано сообщение для Spark");
                    }
                    return msg;
                } else {
                    log.error("UsbLogWarning : " + "Ошибка формирования сообщения для Spark");
                    throw new JMSException("Ошибка формирования сообщения для Spark");
                }
            }
        });
        if (logDebug == 1) {
            log.info("UsbLogDebug : " + "Получено ответное JMS сообщения от Spark: " + receive);
        } else {
            log.info("UsbLogInfo : " + "Получено ответное JMS сообщения от Spark");
        }

        if (receive != null) {
            log.info("UsbLogInfo : " + "ответ " + receive.getBody(String.class));
             // return receive.getBody(String.class);
          return deserializeToXMLSugar(((TextMessage) receive).getText());

        } else {
            return null;
        }
    }

    public responseXMM send2(String reqid, String inn) throws JMSException {
        log.info("UsbLogInfo : " + "Подготовка к отправке JMS сообщения в Spark");
        jmsTemplate.setReceiveTimeout(timeout);

        Message receive = jmsTemplate.sendAndReceive(queue12, new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {

                String msgXml = serializeToXMLSugar(reqid,inn);
                if (msgXml != null) {
                    TextMessage msg = session.createTextMessage(msgXml);
                    msg.setJMSReplyTo(session.createQueue(queue12));
                    if (logDebug == 1) {
                        log.info("UsbLogDebug : " + "Сформировано сообщение для Spark: " + msg);
                    } else {
                        log.info("UsbLogInfo : " + "Сформировано сообщение для Spark");
                    }
                    return msg;
                } else {
                    log.error("UsbLogWarning : " + "Ошибка формирования сообщения для Spark");
                    throw new JMSException("Ошибка формирования сообщения для Spark");
                }
            }
        });
        if (logDebug == 1) {
            log.info("UsbLogDebug : " + "Получено ответное JMS сообщения от Spark: " + receive);
        } else {
            log.info("UsbLogInfo : " + "Получено ответное JMS сообщения от Spark");
        }

        if (receive != null) {
            return deserializeToXMLSugar(((TextMessage) receive).getText());
        } else {
            return null;
        }
    }
}
