package ru.uralsib.efsrestspark;

import io.swagger.annotations.ApiModel;


@ApiModel(description = "Ответ на входной запрос")

public class responseXMM {

    private String xml;







    public responseXMM() {
        super();
    }

    public responseXMM(String xml, String ogrn, String innd, String shortname,
                       String leader, String okved, String status, String datefirstreq,
                       String legaladdress) {
        this.xml = xml;

       /* this.sparkids = sparkids;
        this.inns = inns;
        this.ogrns = ogrns;
        this.names = names;
        this.managers = managers;
        this.addresss = addresss;
        this.notdata = notdata;
*/

    }

    public String getXml() {
        return xml;
    }

    public void setXml(String xml) {
        this.xml = xml;
    }






   /* public List<response.coownerrosstat> getCoownerrosstat() {
        return coownerrosstat;
    }

    public void setCoownerrosstat(List<response.coownerrosstat> coownerrosstat) {        this.coownerrosstat = coownerrosstat;
    }


    public List<response.branchrosstat> getBranchrosstat() {
        return branchrosstat;
    }

    public void setBranchrosstat(List<response.branchrosstat> branchrosstat) {        this.branchrosstat = branchrosstat;
    }*/

}
