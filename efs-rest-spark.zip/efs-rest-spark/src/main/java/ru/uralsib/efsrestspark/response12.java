package ru.uralsib.efsrestspark;

import io.swagger.annotations.ApiModel;


@ApiModel(description = "Ответ на входной запрос")

public class response12 {

    private String sparkid;
    private String ogrn;
    private String innd;
    private String shortname;
    private String leader;
    private String okved;
    private String status;
    private String datefirstreq;
    private String legaladdress;


   // List<response.coownerrosstat> coownerrosstat;
    //public static class coownerrosstat {
        private String sparkids;
        private String inns;
        private String ogrns;
        private String names;
        private String managers;
        private String addresss;
        private String notdata;
        public String getSparkids() {
            return sparkids;
        }

        public void setSparkids(String sparkids) {
            this.sparkids = sparkids;
        }

        public String getOgrns() {
            return ogrns;
        }

        public void setOgrns(String ogrns) {
            this.ogrns = ogrns;
        }
        public String getInns() {
            return inns;
        }

        public void setInns(String inns) {
            this.inns = inns;
        }

        public  String getNames() {
            return names;
        }

        public void setNames(String names) {  this.names = names;  }

        public  String getManagers() {
            return managers;
        }

        public void setManagers(String managers) {  this.managers= managers;  }
        public  String getAddresss() {
            return addresss;
        }

        public void setAddresss(String addresss) {  this.addresss = addresss;  }

        public  String getNotdata(){return notdata;}
        public void setNotdata(String notdata){this.notdata = notdata;}
   // }

  //  List<response.branchrosstat> branchrosstat;
   // public static class branchrosstat {
        private String bname;
        private String bspark;
        private String baddress;
        private String binn;
        private String bogrn;
        private String bmanager;
    private String error;
        public String getBname() {
            return bname;
        }

        public void setBname(String bname) {
            this.bname = bname;
        }

        public String getBspark() {
            return bspark;
        }

        public void setBspark(String bspark) {
            this.bspark = bspark;
        }
        public String getBaddress() {
            return baddress;
        }

        public void setBaddress(String baddress) {
            this.baddress = baddress;
        }

        public  String getBinn() {
            return binn;
        }

        public void setBinn(String binn) {  this.binn = binn;  }

        public  String getBogrn() {
            return bogrn;
        }

        public void setBogrn(String bogrn) {  this.bogrn= bogrn;  }
        public  String getBmanager() {
            return bmanager;
        }

        public void setBmanager(String bmanager) {  this.bmanager = bmanager;  }
    public  String getError() {
        return error;
    }

    public void setError(String error) {  this.error = error;  }


    //}



    public response12() {
        super();
    }

    public response12(String sparkid, String ogrn, String innd, String shortname,
                      String leader, String okved, String status, String datefirstreq,
                      String legaladdress) {
        this.sparkid = sparkid;
        this.ogrn = ogrn;
        this.innd = innd;
        this.shortname = shortname;
        this.leader = leader;
        this.okved = okved;
        this.status = status;
        this.datefirstreq = datefirstreq;
        this.legaladdress = legaladdress;
       /* this.sparkids = sparkids;
        this.inns = inns;
        this.ogrns = ogrns;
        this.names = names;
        this.managers = managers;
        this.addresss = addresss;
        this.notdata = notdata;
*/

    }

    public String getSparkid() {
        return sparkid;
    }

    public void setSparkid(String sparkid) {
        this.sparkid = sparkid;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getInnd() {
        return innd;
    }

    public void setInnd(String innd) {
        this.innd = innd;
    }
    public  String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {  this.shortname = shortname;  }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public String getOkved() {
        return okved;
    }

    public void setOkved(String okved) {
        this.okved = okved;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDatefirstreq() {
        return datefirstreq;
    }

    public void setDatefirstreq(String datefirstreq) {
        this.datefirstreq = datefirstreq;
    }

    public String getLegaladdress() {       return legaladdress;
    }

    public void setLegaladdress(String legaladdress) {
        this.legaladdress = legaladdress;
    }


   /* public List<response.coownerrosstat> getCoownerrosstat() {
        return coownerrosstat;
    }

    public void setCoownerrosstat(List<response.coownerrosstat> coownerrosstat) {        this.coownerrosstat = coownerrosstat;
    }


    public List<response.branchrosstat> getBranchrosstat() {
        return branchrosstat;
    }

    public void setBranchrosstat(List<response.branchrosstat> branchrosstat) {        this.branchrosstat = branchrosstat;
    }*/

}
