package ru.uralsib.efsrestspark;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.jms.JMSException;
import java.util.concurrent.*;


@RestController
@RequestMapping("/v1")
@Api(value = "user", tags = "Контроллер для передачи в Spark")
public class RestControl {
    private static final Logger log = LoggerFactory.getLogger(RestControl.class);

    @Autowired
    private JmsSugarService jmsSugarService;

    @Value("${log.debug}")
    private int logDebug;

    @GetMapping(path = "spark", produces = MediaType.APPLICATION_XML_VALUE)
    @ApiOperation(value = "Запрос данных из Spark по заданному ИНН ",
            notes = "Пример:\n" +
                    "    reqid: 1-IHRPT8\n" +
                    "    inn:  0278109628,\n")
    public ResponseEntity<Object> spark(@RequestParam("reqid") String reqid, @RequestParam("inn") String inn) throws JsonProcessingException, JMSException, ExecutionException, InterruptedException {

        if (logDebug == 1) {
            log.info("UsbLogInfo : Получен запрос от : reqid=" + reqid + " inn=" + inn);
        } else {
            log.info("UsbLogInfo : Получен запрос ");
        }

        //Новый оператор
        ExecutorService executor = Executors.newSingleThreadExecutor();

        XmlMapper xmlMapper = new XmlMapper();
        RespXml respXml = new RespXml();
        RespXml12 respXml12 = new RespXml12();
        if (inn.length() >= 9 & inn.length() <= 10) {
            Future<String> future = executor.submit(new Task(reqid, inn, jmsSugarService));
            String resp = null;
            try {
                System.out.println("Started..");
                resp = future.get(12, TimeUnit.SECONDS);
                System.out.println(resp);
                System.out.println("Finished!");
            } catch (TimeoutException | InterruptedException | ExecutionException e) {
                future.cancel(true);
                System.out.println("Terminated!");
            }
            executor.shutdownNow();

            //responseXMM resp = jmsSugarService.send(reqid, inn);
            if (resp != null) {
                log.info("UsbLogInfo : Сформировано и отправлено JMS сообщение для DBO [ИНН больше 8, и меньше 11 символов]:inn={}", inn);
            } else {
                log.error("UsbLogError : Ошибка обработки сообщения от Spark.[ИНН больше 8, и меньше 11 символов], inn={}", inn);
                throw new JMSException("Ошибка обработки сообщения от Spark");
            }
            return ResponseEntity.status(HttpStatus.OK).header("Content-Type", "text/xml").body(resp);
        } else if (inn.length() >= 11 & inn.length() <= 12) {
            responseXMM response12 = jmsSugarService.send2(reqid, inn);
            if (response12 != null) {
                log.info("UsbLogInfo : " + "Сформировано и отправлено JMS сообщение для DBO");
            } else {
                log.error("UsbLogError : " + "Ошибка обработки сообщения от Spark");
                throw new JMSException("Ошибка обработки сообщения от Spark");
            }
            return ResponseEntity.status(HttpStatus.OK).header("Content-Type", "text/xml").body(response12.getXml());
        } else {
            respXml.reqid = reqid;
            respXml.reqcode = "1";
            respXml.reqmsg = "ИНН компании должен содержать 9 или 10 цифр без учета лидирующих нулей; ИНН индивидуального предпринимателя должен содержать 11 или 12 цифр";
            log.error("UsbLogError : Ошибка пришедшего запроса");
            String xml = xmlMapper.writeValueAsString(respXml);
            return ResponseEntity.status(HttpStatus.OK).header("Content-Type", "text/xml").body(xml);
        }
    }
}

class Task implements Callable<String> {
    private final String inn;
    private final String reqid;
    private JmsSugarService jmsSugarService;

    public Task(String inn, String reqid, JmsSugarService jmsSugarService) {
        this.inn = inn;
        this.reqid = reqid;
        this.jmsSugarService = jmsSugarService;
    }

    @Override
    public String call() throws Exception {
        Thread.sleep(4000); // Just to demo a long running task of 4 seconds.
        responseXMM resp = jmsSugarService.send(reqid, inn);
        return  resp.getXml();
    }
}