package ru.uralsib.efsrestspark;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


//@ApiModel(value = "Request ", description = "Входящий Rest запрос")


public class request {
    @ApiModelProperty(value = "reqid")
    private String reqid;
    @ApiModelProperty(value = "inn")
    private String inn;

    public request(String reqid,String inn) {
        this.reqid = reqid;
        this.inn = inn;
    }

    public String getInn() {
        return inn;
    }
public String getReqid(){return reqid;}
    @Override
    public String toString() {
        return
                "inn ='" + inn + '\'' +'}';
    }

    public void setInn(String inn) {
        this.inn = inn;
    }
public void setReqid(String reqid){this.reqid = reqid;}


}