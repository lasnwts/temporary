package ru.usb.adpibsortm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdpIbsoRtmApplicationTests {

	@Test
	void contextLoads() {
	}

}
