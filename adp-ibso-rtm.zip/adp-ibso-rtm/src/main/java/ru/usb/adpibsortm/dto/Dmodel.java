package ru.usb.adpibsortm.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.*;

@Schema(description = "Информация о объекте бла-бла")
public class Dmodel {

    @Schema(description = "id - номер клиента")
    @Min(1) //Минимальное число
    @Max(999999999) //макисмальное число в базне, например поле имеет размерность 10
    @NotNull //не может быть null
    private long id;
    @Schema(description = "name - Имя клиента")
    @NotBlank //не может быть пустым
    @Size(min = 0, max = 255) //минимальное число символов в строке, максимальное число символов в строке
    private String name;
    @Schema(description = "description - полное описание клиента")
    private String description;

    public Dmodel() {
    }

    public Dmodel(long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Dmodel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
