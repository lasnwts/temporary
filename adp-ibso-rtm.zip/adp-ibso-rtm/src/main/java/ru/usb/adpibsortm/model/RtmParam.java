package ru.usb.adpibsortm.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Параметр из сообщения RTM
 * Пример:
 * {
 * "PARAM_NAME": "CERTIFICATE_NUMBER",
 * "PARAM_TYPE": "STRING",
 * "PARAM_VALUE": "8009 929682"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RtmParam {

    //PARAM_NAME - имя параметра
    @JsonProperty("PARAM_NAME")
    private String param_name;

    //PARAM_TYPE - тип параметра
    @JsonProperty("PARAM_TYPE")
    private String param_type;

    //PARAM_VALUE - значение переменной
    @JsonProperty("PARAM_VALUE")
    private String param_value;

    public RtmParam() {
    }

    public RtmParam(String param_name, String param_type, String param_value) {
        this.param_name = param_name;
        this.param_type = param_type;
        this.param_value = param_value;
    }

    public String getParam_name() {
        return param_name;
    }

    public void setParam_name(String param_name) {
        this.param_name = param_name;
    }

    public String getParam_type() {
        return param_type;
    }

    public void setParam_type(String param_type) {
        this.param_type = param_type;
    }

    public String getParam_value() {
        return param_value;
    }

    public void setParam_value(String param_value) {
        this.param_value = param_value;
    }

    @Override
    public String toString() {
        return "RtmParam{" +
                "param_name='" + param_name + '\'' +
                ", param_type='" + param_type + '\'' +
                ", param_value='" + param_value + '\'' +
                '}';
    }
}
