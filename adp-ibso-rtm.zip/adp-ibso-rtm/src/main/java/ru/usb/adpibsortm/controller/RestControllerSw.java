package ru.usb.adpibsortm.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.adpibsortm.configure.Configure;
import ru.usb.adpibsortm.dto.Dmodel;
import ru.usb.adpibsortm.model.RtmParam;

import java.util.List;

/**
 * Создание Swagger
 * Подключение Springdoc для автоматизации документирования REST API
 * https://www.youtube.com/watch?v=12eztbR51kA
 *
 * Создание RestController (правда на kotlin)
 * https://www.youtube.com/watch?v=NWA64jwA7pg *
 *
 * Описание команд
 * https://devmark.ru/article/springdoc-rest-api
 */

/**
 * @Hidden - прячет контроллер целиком
 */
//@Hidden
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Короткое наименование", description = "длинное наименование контроллера")
public class RestControllerSw {


    @Autowired
    Configure configure;

    private Logger logger = LoggerFactory.getLogger(RestControllerSw.class);


    @GetMapping("/getstr/{str}")
    @Operation(summary = "Получаем строку + что то еще.")
    public String getTestString(
            @Parameter(description = "Введите строку")
            @PathVariable("str") String str) {
        return "This is get:" + str;
    }

    @GetMapping("/getobject/{id}")
    @Operation(summary = "Получаем строку + что то еще.")
    public Dmodel getTestString(
            @Parameter(description = "Введите строку")
            @PathVariable("id") int id) {
        Dmodel dmodel = new Dmodel(1,"John", "Taker");
        return dmodel;
    }

    @PostMapping("/{id}")
    @Operation(summary = "Создание нового объекта")
    public Dmodel postNewDmodel(
            @Parameter(description = "Номер объекта")
            @PathVariable("id") int id,
            @Parameter(description = "Объект Dmodel")
            @RequestBody(required = true)  Dmodel dmodel)    {
        Dmodel dmodel1 = new Dmodel(id, dmodel.getName(), dmodel.getDescription());
        return dmodel1;
    }

    @PostMapping("/message")
    @Operation(summary = "Можно передать сообщение из RTM. Сообщение будет передано в Ритейл.")
    public ResponseEntity sentRtmMessage(@RequestBody List<RtmParam> rtmMessage){

        if(rtmMessage==null || rtmMessage.isEmpty()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания сообщения из РТМ");
        }

        logger.info(configure.getInfoLevel(), rtmMessage.toString());


        return new ResponseEntity<>(rtmMessage, HttpStatus.OK);
    }

    @PostMapping("/param")
    @Operation(summary = "Можно передать один параметр из сообщение из RTM. Сообщение никуда не передается, просто парсится и возвращается в ответ")
    public ResponseEntity parseRtmParam(@RequestBody RtmParam rtmParam){

        if(rtmParam==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания единичного параметра сообщения из РТМ");
        }

        return new ResponseEntity<>(rtmParam, HttpStatus.OK);
    }


}
