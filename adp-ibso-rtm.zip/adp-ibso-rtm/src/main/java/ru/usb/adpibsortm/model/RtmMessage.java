package ru.usb.adpibsortm.model;

import java.util.List;

/**
 * Сообщение из RTM (Real Time Marketing) состоящее из отдельных сообщений типа
 * RtmParam, пример:
 * {
 *         "PARAM_NAME": "CERTIFICATE_NUMBER",
 *         "PARAM_TYPE": "STRING",
 *         "PARAM_VALUE": "8009 929682"
 *     }
 *
 */
public class RtmMessage {

    private  List<RtmParam> rtmParamList;

    public RtmMessage() {
    }

    public RtmMessage(List<RtmParam> rtmParamList) {
        this.rtmParamList = rtmParamList;
    }

    public List<RtmParam> getRtmParamList() {
        return rtmParamList;
    }

    public void setRtmParamList(List<RtmParam> rtmParamList) {
        this.rtmParamList = rtmParamList;
    }

    @Override
    public String toString() {
        return "RtmMessage{" +
                "rtmParamList=" + rtmParamList +
                '}';
    }
}
