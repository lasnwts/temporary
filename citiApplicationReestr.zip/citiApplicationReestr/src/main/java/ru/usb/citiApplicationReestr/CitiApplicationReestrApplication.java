package ru.usb.citiApplicationReestr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.citiApplicationReestr.config.Configure;
import ru.usb.citiApplicationReestr.service.LoadFileCiti;
import ru.usb.citiApplicationReestr.service.PrepareLoadFile;
import ru.usb.citiApplicationReestr.utils.WorkWithFiles;

@SpringBootApplication
public class CitiApplicationReestrApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(CitiApplicationReestrApplication.class);

	@Autowired
	Configure configure;

	@Autowired
	LoadFileCiti loadFileCiti; //Подготовка к загрузке

	@Autowired
	WorkWithFiles withFiles;

	public static void main(String[] args) {
		SpringApplication.run(CitiApplicationReestrApplication.class, args);
	}

	/**
	 * Автозапуск
	 */
	@Override
	public void run(String... args) throws Exception {

		// Показываем версию
		logger.info("");
		logger.info("-----------------------------------------------");
		logger.info("| Service:" + configure.getAppName());
		logger.info("| Version of service:" + configure.getAppVersion());
		logger.info("-----------------------------------------------");
		logger.info("");

		/**
		 * Проверка директорий
		 */
		if (withFiles.checkPathExists(configure.getFileDirectory())) {
			logger.info("Success. Директория: " + configure.getFileDirectory() + " обнаружена.");
		} else {
			logger.error("Error. Директория: " + configure.getFileDirectory() + " не обнаружена! Будет сделана попытка создания директории.");
			withFiles.createdDirectory(configure.getFileDirectory());
		}
		if (withFiles.checkPathExists(configure.getFileMovedDoneDirectory())) {
			logger.info("Success. Директория: " + configure.getFileMovedDoneDirectory() + " обнаружена.");
		} else {
			logger.error("Error. Директория: " + configure.getFileMovedDoneDirectory() + " не обнаружена! Будет сделана попытка создания директории.");
			withFiles.createdDirectory(configure.getFileMovedDoneDirectory());
		}

	}

	/*
	 * Sheduler 1. Первый шедулер
	 */
	@Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
	public void BaseJob() {
		//Загрузка файлов
		loadFileCiti.loadFile();
	}
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {

}