package ru.usb.citiApplicationReestr.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {


    @Value("${info.app.name}")
    private String appName;

    @Value("${info.app.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;

    @Value("${file.directory}")
    private String fileDirectory; //директория где должен находиться файл

    @Value("${file.ext}")
    private String fileExt;  //расширение имени файла для анализа
    @Value("${file.delete}")
    private boolean fileDelete;  //true - удалить файлы после обработки, false - переместить в директорию file.moved
    @Value("${file.moved}")
    private String fileMovedDoneDirectory; //Директория куда будем передавать файлы после обработки

    @Value("${service.debug:false}")
    private boolean debugMode; //Режим работы, true - максимальное логирование

    @Value("${file.rename}")
    private String fileRename; //Расширение для переименования


    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:Проверка ЗСК – ошибка передачи данных}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;


    /**
     * Реализация
     */

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public String getFileDirectory() {
        return fileDirectory;
    }

    public String getFileExt() {
        return fileExt;
    }

    public boolean isFileDelete() {
        return fileDelete;
    }

    public String getFileMovedDoneDirectory() {
        return fileMovedDoneDirectory;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    public String getFileRename() {
        return fileRename;
    }
}
