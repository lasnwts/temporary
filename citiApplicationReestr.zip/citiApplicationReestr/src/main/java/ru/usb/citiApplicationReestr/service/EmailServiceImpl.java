package ru.usb.citiApplicationReestr.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.citiApplicationReestr.config.Configure;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Objects;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    JavaMailSender emailSender;

    @Autowired
    Configure configure;

    Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Override
    public void sendSimpleEmail(String toAddress, String subject, String message) {

        logger.info("Send email message, toAddress:" + toAddress + " |subject:" + subject + " |message:" + message);
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom(configure.getMailFrom());
        String[] mailRecepients = toAddress.split(",");
        simpleMailMessage.setTo(mailRecepients);
        simpleMailMessage.setCc(mailRecepients);
        simpleMailMessage.setSubject(subject);
        simpleMailMessage.setSentDate(new Date());
        simpleMailMessage.setText(message);
        emailSender.send(simpleMailMessage);
    }

    @Override
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment) throws MessagingException, FileNotFoundException {
        logger.info("Send email message, toAddress:" + toAddress + " |subject:" + subject + " |message:" + message + " |attachment" + attachment);
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
        messageHelper.setFrom(configure.getMailFrom());
        String[] mailRecepients = toAddress.split(",");
        messageHelper.setTo(mailRecepients);
        messageHelper.setSubject(subject);
        messageHelper.setText(message);
        FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
        messageHelper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
        emailSender.send(mimeMessage);
    }
}
