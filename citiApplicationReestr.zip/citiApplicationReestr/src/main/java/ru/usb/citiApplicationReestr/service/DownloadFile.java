package ru.usb.citiApplicationReestr.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citiApplicationReestr.config.Configure;
import ru.usb.citiApplicationReestr.model.Reestr1;
import ru.usb.citiApplicationReestr.model.RequestJob;
import ru.usb.citiApplicationReestr.repository.JpaRepoReestr1;
import ru.usb.citiApplicationReestr.repository.JpaRepositoryRequestJob;
import ru.usb.citiApplicationReestr.utils.CsvLineParser;
import ru.usb.citiApplicationReestr.utils.WorkWithFiles;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Модуль загрузки файлов в Базу Данных
 */
@Service
public class DownloadFile {

    Logger logger = LoggerFactory.getLogger(DownloadFile.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    CsvLineParser csvLineParser;

    @Autowired
    JpaRepositoryRequestJob jpaRepositoryRequestJob;

    @Autowired
    JpaRepoReestr1 jpaRepoReestr1;

    File file;

    String symbolSeparator = ";"; //разделитель

    boolean checkStructureFile; //Проверка структуры файла.

    int totalCountLines, errorCountLines; //общее кол-во строк и строк с ошибкой

    /**
     * Метод загрузки файла в базу данных
     *
     * @return
     */
    public boolean parseAndDownloadFile() {

        List<RequestJob> requestJobList = new ArrayList<>();
        //Получаем все готовые к загрузке файлы.
        requestJobList = jpaRepositoryRequestJob.getAllJobStatusCode(1);

        //Ничего нет для загрузки, просто выходим
        if (requestJobList.isEmpty()) {
            return false;
        }

        //Идем по всем файлам, готовым к загрзуке
        requestJobList.forEach(new Consumer<RequestJob>() {
            @Override
            public void accept(RequestJob requestJob) {
                /**
                 * Ставим статус, запись в обработке
                 */
                setStatus(requestJob, 2, "downloaded", 0, 0);
                logger.info("Файл готов к загрузке:{}", requestJob.toString());

                File file = new File(requestJob.getAbsolutename());
                if (!file.exists()) {
                    setStatus(requestJob, 3, "file not exist", 0, 0);
                } else {
                    //Реализовано через Consumer::
                    try {
                        //Готовим номер строки
                        AtomicInteger rownum = new AtomicInteger();
                        totalCountLines = 0;
                        errorCountLines = 0; // обнуляем счетчики
                        //Будем проверять структуру
                        checkStructureFile = true; //считаем, что файл нормальный)
                        //Читаем файл построчно
                        Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251")).forEach(new Consumer<String>() {
                            @Override
                            public void accept(String s) {
                                rownum.getAndIncrement();
                                totalCountLines = rownum.get();
                                if (configure.isDebugMode()) {
                                    System.out.println(s);
                                }
                                if (rownum.get() == 1) {
                                    //Проверяем, что структура файла не нарушена.
                                    if (s.toLowerCase().contains(csvLineParser.getCsvHeader().toLowerCase())) {
                                        checkStructureFile = true;
                                    } else {
                                        checkStructureFile = false;
                                        logger.error("ERROR:Структура файла нарушена!{}", file.getAbsolutePath());
                                        logger.error("ERROR:Должна быть такая структура:{}", csvLineParser.getCsvHeader());
                                        logger.error("ERROR:Получена из файла такая структура:{}", s);
                                        setStatus(requestJob, 3, "failed parse.File header structure broken.", totalCountLines, errorCountLines);
                                        changeFile(file, "error");
                                    }
                                }
                                //Первая строка файла?
                                if (s.toLowerCase().contains(csvLineParser.getCsvHeader().toLowerCase())) {
                                    //да, просто выходим
                                    if (configure.isDebugMode()) {
                                        logger.info("Обнаружена первая строка файла CSV");
                                        logger.info("{}", s);
                                    }
                                } else {
                                    if (checkStructureFile) {
                                        Reestr1 reestr1 = csvLineParser.parseCsvToPOJO(s, symbolSeparator, configure.isDebugMode(), rownum.get());
                                        if (reestr1 == null) {
                                            logger.error("ERROR:parseAndDownloadFile:requestJobList:Number string:{}", rownum.get());
                                            logger.error("Ошибка в строке:{}", s);
                                            errorCountLines = errorCountLines + 1;
                                        } else {
                                            reestr1.setNumStr(rownum.get());
                                            reestr1.setFILENAME(file.getName());
                                            reestr1.setInputDate(new Date());
                                            try {
                                                jpaRepoReestr1.saveAndFlush(reestr1);
                                            } catch (Exception e) {
                                                logger.error("ERROR:parseAndDownloadFile:requestJobList:Number string:{}", rownum.get());
                                                logger.error("Ошибка вставки при обработке строки:{}", s);
                                                logger.error("Ошибка вставки объекта:{}", reestr1.toString());
                                                setStatus(requestJob, 5, "failed process.Bad insert record", totalCountLines, errorCountLines);
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    } catch (IOException e) {
                        logger.error("ERROR:parseAndDownloadFile:requestJobList:Failed to read file:{}", file.getAbsolutePath());
                        setStatus(requestJob, 3, "Failed to read file.", totalCountLines, errorCountLines);
                        changeFile(file, "error");
                    }
                }
                if (checkStructureFile) {
                    logger.info("File успешно обработан:{}", file.getAbsolutePath());
                    setStatus(requestJob, 6, "completed", totalCountLines, errorCountLines);
                    if (configure.isFileDelete()) {
                        changeFile(file, "delete");
                    } else {
                        changeFile(file, "moved");
                    }
                } else {
                    logger.error("ERROR:Структура файла нарушена!{}", file.getAbsolutePath());
                    setStatus(requestJob, 3, "failed parse.File header structure broken.", totalCountLines, errorCountLines);
                    changeFile(file, "error");
                }
            }
        });

        return true;
    }


    /**
     * Установка статуса записи
     *
     * @param requestJob -  запись
     * @param code       - код
     * @param status     - статус в строке
     */
    private void setStatus(RequestJob requestJob, int code, String status, int totalCountLines, int errorCountLines) {
        requestJob.setDateprocessed(new Date());
        requestJob.setStatuscode(code);
        requestJob.setStatus(status);
        requestJob.setTotalCountLines(totalCountLines);
        requestJob.setErrorCountLines(errorCountLines);
        jpaRepositoryRequestJob.save(requestJob);
    }

    /**
     * Изменение файла
     *
     * @param file
     */
    private void changeFile(File file, String action) {

        if (action == null) {
            logger.error("changeFile:action=null - action не может быть null, delete, error, moved");
        } else {

            /**
             * Удаляем файлы, если стоит признак удалить
             */
            if (action.contains("delete")) {
                withFiles.delFiles(file.toPath());
            }

            /**
             * Переименовываем в *.error
             */
            if (action.contains("error")) {
                withFiles.moveFileSName(file.getAbsolutePath(), file.getAbsolutePath().trim() + ".error");
            }

            /**
             * Перемещение файлов
             */
            if (action.contains("moved")) {

                if (configure.getFileRename() == null || configure.getFileRename().isEmpty() || configure.getFileRename().length() == 0) {
                    if (withFiles.checkPathExists(configure.getFileMovedDoneDirectory())) {
                        withFiles.moveFileSName(file.getAbsolutePath(), configure.getFileMovedDoneDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                    } else {
                        withFiles.moveFileSName(file.getAbsolutePath(), file.getAbsolutePath().trim() + ".done");
                    }
                } else {
                    withFiles.moveFileSName(file.getAbsolutePath(), file.getAbsolutePath().trim() + "." + configure.getFileRename());
                }
            }
        }
    }


}
