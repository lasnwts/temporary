package ru.usb.citiApplicationReestr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Cервис загрузки файлов из СИТИ
 */
@Service
public class LoadFileCiti {
    @Autowired
    PrepareLoadFile prepareLoadFile;

    @Autowired
    DownloadFile downloadFile;

    /**
     * Подготовка файлов к загрузке
     */
    public void loadFile() {
        //Подготовка файлов к загрузке
        prepareLoadFile.prepareFiles();

        //Загрузка информации из файла
        downloadFile.parseAndDownloadFile();
    }


}
