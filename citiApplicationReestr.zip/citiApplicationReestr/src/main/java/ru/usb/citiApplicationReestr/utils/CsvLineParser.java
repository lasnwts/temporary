package ru.usb.citiApplicationReestr.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.citiApplicationReestr.model.Reestr1;

/**
 * Объект парсер строки в POJO
 */
@Component
public class CsvLineParser {
    Logger logger = LoggerFactory.getLogger(CsvLineParser.class);

    @Autowired
    ParseDate parseDate;

    /**
     * Заголовок файла CSV Reesr1
     */
    private String headerCSV = "customer_number;CLNT_SURNM_TXT;CLNT_FRSTNM_TXT;CLNT_MID_TXT;CLNT_BIRTH_DT;Birth_place;CLNT_RESIDENT_IND;CLNT_NTNLITY_CDE;CLNT_TAX_ID;CLNT_SEX_CDE;CLNT_GRB_MARITAL_STAT_CDE;CLNT_GRB_EDU_CDE;credit_limit;base_rte;days_past_due;clnt_prim_doc_typ;clnt_prim_doc_id;clnt_doc_issue_dt;clnt_doc_expirty_dt;issue_place;Mobile_phone_number;Office_phone_number;Home_phone_number;CLNT_EMAIL1_ADDR;CLNT_EMAIL2_ADDR;Home_Address;Reg_Address;reg_date;Office_Address;Legal_Address;Empl_month;CLNT_EMPMT_JOB_TITLE_CDE;EM_INN;CLNT_EMPLR_NM;income_type;income_amt;income_CCY;FIO;CLNT_DPNDNT_CNT;wave_number;database_generation_date";

    public String getCsvHeader() {
        return headerCSV;
    }

    /**
     * Парсинг файла
     *
     * @param csLine - строка для парсинга
     * @return - true - успешно распарсен, false - проблема
     */
    public Reestr1 parseCsvToPOJO(String csLine, String symbolSeparator, boolean debugMode, long rownum) {

        if (csLine == null || symbolSeparator == null) {
            logger.error("Error:CsvLineParser:parseCsvToPOJO:Странно передана строка = NULL!");
        } else {

            //Первая строка файла?
            if (csLine.toLowerCase().contains(headerCSV.toLowerCase())) {
                //да, просто выходим
            } else {
                /**
                 * aString - array String, split
                 */
                if (csLine.contains(symbolSeparator)) {
                    String[] aString = csLine.split(symbolSeparator);
                    Reestr1 reestr1 = getPOJO(aString, rownum);
                    if (debugMode) {
                        logger.info("POJO:reestr1:{}", reestr1.toString());
                    }
                    return reestr1;
                }
            }
        }
        return null;
    }

    /**
     * customer_number	1	0
     * CLNT_SURNM_TXT	2	1
     * CLNT_FRSTNM_TXT	3	2
     * CLNT_MID_TXT	4	3
     * CLNT_BIRTH_DT	5	4  (date)
     * Birth_place	6	5
     * CLNT_RESIDENT_IND	7	6
     * CLNT_NTNLITY_CDE	8	7
     * CLNT_TAX_ID	9	8
     * CLNT_SEX_CDE	10	9
     * CLNT_GRB_MARITAL_STAT_CDE	11	10
     * CLNT_GRB_EDU_CDE	12	11
     * credit_limit	13	12
     * base_rte	14	13
     * days_past_due	15	14
     * clnt_prim_doc_typ	16	15
     * clnt_prim_doc_id	17	16
     * clnt_doc_issue_dt	18	17   (date)
     * clnt_doc_expirty_dt	19	18   (date)
     * issue_place	20	19
     * Mobile_phone_number	21	20
     * Office_phone_number	22	21
     * Home_phone_number	23	22
     * CLNT_EMAIL1_ADDR	24	23
     * CLNT_EMAIL2_ADDR	25	24
     * Home_Address	26	25
     * Reg_Address	27	26
     * reg_date	28	27         (date)
     * Office_Address	29	28
     * Legal_Address	30	29
     * Empl_month	31	30
     * CLNT_EMPMT_JOB_TITLE_CDE	32	31
     * EM_INN	33	32
     * CLNT_EMPLR_NM	34	33
     * income_type	35	34
     * income_amt	36	35
     * income_CCY	37	36
     * FIO	38	37
     * CLNT_DPNDNT_CNT	39	38
     * wave_number	40	39
     * database_generation_date	41	40  (date)
     */
    private Reestr1 getPOJO(String[] aString, long rownum) {
        Reestr1 reestr1 = new Reestr1();
        if (aString.length > 0) {
            reestr1.setCustomer_number(aString[0]);
        }
        if (aString.length > 1) {
            reestr1.setClnt_surnm_txt(aString[1]);
        }
        if (aString.length > 2) {
            reestr1.setClnt_frstnm_txt(aString[2]);
        }
        if (aString.length > 3) {
            reestr1.setClnt_mid_txt(aString[3]);
        }
        if (aString.length > 4) {
            if (parseDate.parseDate(aString[4])) {
                reestr1.setClnt_birth_dt(parseDate.getDate(aString[4]));
            } else {
                logger.error("ERROR:Поле Clnt_birth_dt:Номер строки{}, значение {}", rownum, aString[4]);
            }
        }
        if (aString.length > 5) {
            reestr1.setBirth_place(aString[5]);
        }
        if (aString.length > 6) {
            reestr1.setClnt_resident_ind(aString[6]);
        }
        if (aString.length > 7) {
            reestr1.setClnt_ntnlite_cde(aString[7]);
        }
        if (aString.length > 8) {
            reestr1.setClnt_tax_id(aString[8]);
        }
        if (aString.length > 9) {
            reestr1.setClnt_sex_cde(aString[9]);
        }
        if (aString.length > 10) {
            reestr1.setClnt_grb_marital_stat_cde(aString[10]);
        }
        if (aString.length > 11) {
            reestr1.setClnt_grb_edu_cde(aString[11]);
        }
        if (aString.length > 12) {
            reestr1.setCredit_limit(aString[12]);
        }
        if (aString.length > 13) {
            reestr1.setBase_rte(aString[13]);
        }
        if (aString.length > 14) {
            reestr1.setDays_past_due(aString[14]);
        }
        if (aString.length > 15) {
            reestr1.setClnt_prim_doc_typ(aString[15]);
        }
        if (aString.length > 16) {
            reestr1.setClnt_prim_doc_id(aString[16]);
        }
        if (aString.length > 17) {
            if (parseDate.parseDate(aString[17])) {
                reestr1.setClnt_doc_issue_dt(parseDate.getDate(aString[17]));
            } else {
                logger.error("ERROR:Поле Clnt_doc_issue_dt:Номер строки{}, значение {}", rownum, aString[17]);
            }
        }
        if (aString.length > 18) {
            if (parseDate.parseDate(aString[18])) {
                reestr1.setClnt_doc_expirty_dt(parseDate.getDate(aString[18]));
            } else {
                logger.error("ERROR:Поле Clnt_doc_expirty_dt:Номер строки{}, значение {}", rownum, aString[18]);
            }
        }
        if (aString.length > 19) {
            reestr1.setIssue_place(aString[19]);
        }
        if (aString.length > 20) {
            reestr1.setMobile_phone_number(aString[20]);
        }
        if (aString.length > 21) {
            reestr1.setOffice_phone_number(aString[21]);
        }
        if (aString.length > 22) {
            reestr1.setHome_phone_number(aString[22]);
        }
        if (aString.length > 23) {
            reestr1.setClnt_email1_addr(aString[23]);
        }
        if (aString.length > 24) {
            reestr1.setClnt_email2_addr(aString[24]);
        }
        if (aString.length > 25) {
            reestr1.setHome_address(aString[25]);
        }
        if (aString.length > 26) {
            reestr1.setReg_address(aString[26]);
        }
        if (aString.length > 27) {
            if (parseDate.parseDate(aString[27])) {
                reestr1.setReg_date(parseDate.getDate(aString[27]));
            } else {
                logger.error("ERROR:Поле Reg_date:Номер строки{}, значение {}", rownum, aString[27]);
            }
        }
        if (aString.length > 28) {
            reestr1.setOffice_address(aString[28]);
        }
        if (aString.length > 29) {
            reestr1.setLegal_address(aString[29]);
        }
        if (aString.length > 30) {
            reestr1.setEmpl_month(aString[30]);
        }
        if (aString.length > 31) {
            reestr1.setClnt_empmt_job_title_cde(aString[31]);
        }
        if (aString.length > 32) {
            reestr1.setEm_inn(aString[32]);
        }
        if (aString.length > 33) {
            reestr1.setClnt_emplr_nm(aString[33]);
        }
        if (aString.length > 34) {
            reestr1.setIncome_type(aString[34]);
        }
        if (aString.length > 35) {
            reestr1.setIncome_amt(aString[35]);
        }
        if (aString.length > 36) {
            reestr1.setIncome_ccy(aString[36]);
        }
        if (aString.length > 37) {
            reestr1.setFio(aString[37]);
        }
        if (aString.length > 38) {
            reestr1.setClnt_dpndnt_cnt(aString[38]);
        }
        if (aString.length > 39) {
            reestr1.setWave_number(aString[39]);
        }
        if (aString.length > 40) {
            if (parseDate.parseDate(aString[40])) {
                reestr1.setDatabase_generation_date(parseDate.getDate(aString[40]));
            } else {
                logger.error("ERROR:Поле Database_generation_date:Номер строки{}, значение {}", rownum, aString[40]);
            }
        }
        return reestr1;
    }

}
