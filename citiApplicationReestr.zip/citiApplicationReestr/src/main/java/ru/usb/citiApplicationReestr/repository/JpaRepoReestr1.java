package ru.usb.citiApplicationReestr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citiApplicationReestr.model.Reestr1;

public interface JpaRepoReestr1 extends JpaRepository<Reestr1, Long> {

}
