package ru.usb.citiApplicationReestr.model;

import org.hibernate.annotations.GenericGenerator;
import com.opencsv.bean.CsvBindByPosition;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "citireestr1")
public class Reestr1 {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long uuid;


    @Column(name = "CUSTOMER_NUMBER")
    private String customer_number;
    @CsvBindByPosition(position = 1)
    @Column(name = "CLNT_SURNM_TXT")
    private String clnt_surnm_txt;

    @CsvBindByPosition(position = 2)
    @Column(name = "CLNT_FRSTNM_TXT")
    private String clnt_frstnm_txt;

    @CsvBindByPosition(position = 3)
    @Column(name = "CLNT_MID_TXT")
    private String clnt_mid_txt;

    @CsvBindByPosition(position = 4)
    @Column(name = "CLNT_BIRTH_DT")
    private LocalDate clnt_birth_dt;

    @CsvBindByPosition(position = 5)
    @Column(name = "BIRTH_PLACE")
    private String birth_place;

    @CsvBindByPosition(position = 6)
    @Column(name = "CLNT_RESIDENT_IND")
    private String clnt_resident_ind;

    @CsvBindByPosition(position = 7)
    @Column(name = "CLNT_NTNLITY_CDE")
    private String clnt_ntnlite_cde;

    @CsvBindByPosition(position = 8)
    @Column(name = "CLNT_TAX_ID")
    private String clnt_tax_id;

    @CsvBindByPosition(position = 9)
    @Column(name = "CLNT_SEX_CDE")
    private String clnt_sex_cde;

    @CsvBindByPosition(position = 10)
    @Column(name = "CLNT_GRB_MARITAL_STAT_CDE")
    private String clnt_grb_marital_stat_cde;

    @CsvBindByPosition(position = 11)
    @Column(name = "CLNT_GRB_EDU_CDE")
    private String clnt_grb_edu_cde;

    @CsvBindByPosition(position = 12)
    @Column(name = "CREDIT_LIMIT")
    private String credit_limit;

    @CsvBindByPosition(position = 13)
    @Column(name = "BASE_RTE")
    private String base_rte;

    @CsvBindByPosition(position = 14)
    @Column(name = "DAYS_PAST_DUE")
    private String days_past_due;

    @CsvBindByPosition(position = 15)
    @Column(name = "CLNT_PRIM_DOC_TYP")
    private String clnt_prim_doc_typ;

    @CsvBindByPosition(position = 16)
    @Column(name = "CLNT_PRIM_DOC_ID")
    private String clnt_prim_doc_id;

    @CsvBindByPosition(position = 17)
    @Column(name = "CLNT_DOC_ISSUE_DT")
    private LocalDate clnt_doc_issue_dt;

    @CsvBindByPosition(position = 18)
    @Column(name = "CLNT_DOC_EXPIRTY_DT")
    private LocalDate clnt_doc_expirty_dt;

    @CsvBindByPosition(position = 19)
    @Column(name = "ISSUE_PLACE")
    private String issue_place;

    @CsvBindByPosition(position = 20)
    @Column(name = "MOBILE_PHONE_NUMBER")
    private String Mobile_phone_number;

    @CsvBindByPosition(position = 21)
    @Column(name = "OFFICE_PHONE_NUMBER")
    private String office_phone_number;

    @CsvBindByPosition(position = 22)
    @Column(name = "HOME_PHONE_NUMBER")
    private String home_phone_number;

    @CsvBindByPosition(position = 23)
    @Column(name = "CLNT_EMAIL1_ADDR")
    private String clnt_email1_addr;

    @CsvBindByPosition(position = 24)
    @Column(name = "CLNT_EMAIL2_ADDR")
    private String clnt_email2_addr;

    @CsvBindByPosition(position = 25)
    @Column(name = "HOME_ADDRESS")
    private String home_address;

    @CsvBindByPosition(position = 26)
    @Column(name = "REG_ADDRESS")
    private String reg_address;

    @CsvBindByPosition(position = 27)
    @Column(name = "REG_DATE")
    private LocalDate reg_date;

    @CsvBindByPosition(position = 28)
    @Column(name = "OFFICE_ADDRESS")
    private String office_address;

    @CsvBindByPosition(position = 29)
    @Column(name = "LEGAL_ADDRESS")
    private String legal_address;

    @CsvBindByPosition(position = 30)
    @Column(name = "EMPL_MONTH")
    private String empl_month;

    @CsvBindByPosition(position = 31)
    @Column(name = "CLNT_EMPMT_JOB_TITLE_CDE")
    private String clnt_empmt_job_title_cde;

    @CsvBindByPosition(position = 32)
    @Column(name = "EM_INN")
    private String em_inn;

    @CsvBindByPosition(position = 33)
    @Column(name = "CLNT_EMPLR_NM")
    private String clnt_emplr_nm;

    @CsvBindByPosition(position = 34)
    @Column(name = "INCOME_TYPE")
    private String income_type;

    @CsvBindByPosition(position = 35)
    @Column(name = "INCOME_AMT")
    private String income_amt;

    @CsvBindByPosition(position = 36)
    @Column(name = "INCOME_CCY")
    private String income_ccy;

    @CsvBindByPosition(position = 37)
    @Column(name = "FIO")
    private String fio;

    @CsvBindByPosition(position = 38)
    @Column(name = "CLNT_DPNDNT_CNT")
    private String clnt_dpndnt_cnt;

    @CsvBindByPosition(position = 39)
    @Column(name = "WAVE_NUMBER")
    private String wave_number;

    @CsvBindByPosition(position = 40)
    @Column(name = "DATABASE_GENERATION_DATE")
    private LocalDate database_generation_date;

    /**
     * Поля для контроля вставки
     */
    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int numStr;

    public Reestr1() {
    }

    public LocalDate getClnt_birth_dt() {
        return clnt_birth_dt;
    }

    public void setClnt_birth_dt(LocalDate clnt_birth_dt) {
        this.clnt_birth_dt = clnt_birth_dt;
    }

    public LocalDate getClnt_doc_issue_dt() {
        return clnt_doc_issue_dt;
    }

    public void setClnt_doc_issue_dt(LocalDate clnt_doc_issue_dt) {
        this.clnt_doc_issue_dt = clnt_doc_issue_dt;
    }

    public LocalDate getClnt_doc_expirty_dt() {
        return clnt_doc_expirty_dt;
    }

    public void setClnt_doc_expirty_dt(LocalDate clnt_doc_expirty_dt) {
        this.clnt_doc_expirty_dt = clnt_doc_expirty_dt;
    }

    public LocalDate getReg_date() {
        return reg_date;
    }

    public void setReg_date(LocalDate reg_date) {
        this.reg_date = reg_date;
    }

    public LocalDate getDatabase_generation_date() {
        return database_generation_date;
    }

    public void setDatabase_generation_date(LocalDate database_generation_date) {
        this.database_generation_date = database_generation_date;
    }

    /**
     * ***************************************************************************
     * Реализация
     * ***************************************************************************
     */


    public long getUuid() {
        return uuid;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public String getCustomer_number() {
        return customer_number;
    }

    public void setCustomer_number(String customer_number) {
        this.customer_number = customer_number;
    }

    public String getClnt_surnm_txt() {
        return clnt_surnm_txt;
    }

    public void setClnt_surnm_txt(String clnt_surnm_txt) {
        this.clnt_surnm_txt = clnt_surnm_txt;
    }

    public String getClnt_frstnm_txt() {
        return clnt_frstnm_txt;
    }

    public void setClnt_frstnm_txt(String clnt_frstnm_txt) {
        this.clnt_frstnm_txt = clnt_frstnm_txt;
    }

    public String getClnt_mid_txt() {
        return clnt_mid_txt;
    }

    public void setClnt_mid_txt(String clnt_mid_txt) {
        this.clnt_mid_txt = clnt_mid_txt;
    }

    public String getBirth_place() {
        return birth_place;
    }

    public void setBirth_place(String birth_place) {
        this.birth_place = birth_place;
    }

    public String getClnt_resident_ind() {
        return clnt_resident_ind;
    }

    public void setClnt_resident_ind(String clnt_resident_ind) {
        this.clnt_resident_ind = clnt_resident_ind;
    }

    public String getClnt_ntnlite_cde() {
        return clnt_ntnlite_cde;
    }

    public void setClnt_ntnlite_cde(String clnt_ntnlite_cde) {
        this.clnt_ntnlite_cde = clnt_ntnlite_cde;
    }

    public String getClnt_tax_id() {
        return clnt_tax_id;
    }

    public void setClnt_tax_id(String clnt_tax_id) {
        this.clnt_tax_id = clnt_tax_id;
    }

    public String getClnt_sex_cde() {
        return clnt_sex_cde;
    }

    public void setClnt_sex_cde(String clnt_sex_cde) {
        this.clnt_sex_cde = clnt_sex_cde;
    }

    public String getClnt_grb_marital_stat_cde() {
        return clnt_grb_marital_stat_cde;
    }

    public void setClnt_grb_marital_stat_cde(String clnt_grb_marital_stat_cde) {
        this.clnt_grb_marital_stat_cde = clnt_grb_marital_stat_cde;
    }

    public String getClnt_grb_edu_cde() {
        return clnt_grb_edu_cde;
    }

    public void setClnt_grb_edu_cde(String clnt_grb_edu_cde) {
        this.clnt_grb_edu_cde = clnt_grb_edu_cde;
    }

    public String getCredit_limit() {
        return credit_limit;
    }

    public void setCredit_limit(String credit_limit) {
        this.credit_limit = credit_limit;
    }

    public String getBase_rte() {
        return base_rte;
    }

    public void setBase_rte(String base_rte) {
        this.base_rte = base_rte;
    }

    public String getDays_past_due() {
        return days_past_due;
    }

    public void setDays_past_due(String days_past_due) {
        this.days_past_due = days_past_due;
    }

    public String getClnt_prim_doc_typ() {
        return clnt_prim_doc_typ;
    }

    public void setClnt_prim_doc_typ(String clnt_prim_doc_typ) {
        this.clnt_prim_doc_typ = clnt_prim_doc_typ;
    }

    public String getClnt_prim_doc_id() {
        return clnt_prim_doc_id;
    }

    public void setClnt_prim_doc_id(String clnt_prim_doc_id) {
        this.clnt_prim_doc_id = clnt_prim_doc_id;
    }

    public String getIssue_place() {
        return issue_place;
    }

    public void setIssue_place(String issue_place) {
        this.issue_place = issue_place;
    }

    public String getMobile_phone_number() {
        return Mobile_phone_number;
    }

    public void setMobile_phone_number(String mobile_phone_number) {
        Mobile_phone_number = mobile_phone_number;
    }

    public String getOffice_phone_number() {
        return office_phone_number;
    }

    public void setOffice_phone_number(String office_phone_number) {
        this.office_phone_number = office_phone_number;
    }

    public String getHome_phone_number() {
        return home_phone_number;
    }

    public void setHome_phone_number(String home_phone_number) {
        this.home_phone_number = home_phone_number;
    }

    public String getClnt_email1_addr() {
        return clnt_email1_addr;
    }

    public void setClnt_email1_addr(String clnt_email1_addr) {
        this.clnt_email1_addr = clnt_email1_addr;
    }

    public String getClnt_email2_addr() {
        return clnt_email2_addr;
    }

    public void setClnt_email2_addr(String clnt_email2_addr) {
        this.clnt_email2_addr = clnt_email2_addr;
    }

    public String getHome_address() {
        return home_address;
    }

    public void setHome_address(String home_address) {
        this.home_address = home_address;
    }

    public String getReg_address() {
        return reg_address;
    }

    public void setReg_address(String reg_address) {
        this.reg_address = reg_address;
    }

    public String getOffice_address() {
        return office_address;
    }

    public void setOffice_address(String office_address) {
        this.office_address = office_address;
    }

    public String getLegal_address() {
        return legal_address;
    }

    public void setLegal_address(String legal_address) {
        this.legal_address = legal_address;
    }

    public String getEmpl_month() {
        return empl_month;
    }

    public void setEmpl_month(String empl_month) {
        this.empl_month = empl_month;
    }

    public String getClnt_empmt_job_title_cde() {
        return clnt_empmt_job_title_cde;
    }

    public void setClnt_empmt_job_title_cde(String clnt_empmt_job_title_cde) {
        this.clnt_empmt_job_title_cde = clnt_empmt_job_title_cde;
    }

    public String getEm_inn() {
        return em_inn;
    }

    public void setEm_inn(String em_inn) {
        this.em_inn = em_inn;
    }

    public String getClnt_emplr_nm() {
        return clnt_emplr_nm;
    }

    public void setClnt_emplr_nm(String clnt_emplr_nm) {
        this.clnt_emplr_nm = clnt_emplr_nm;
    }

    public String getIncome_type() {
        return income_type;
    }

    public void setIncome_type(String income_type) {
        this.income_type = income_type;
    }

    public String getIncome_amt() {
        return income_amt;
    }

    public void setIncome_amt(String income_amt) {
        this.income_amt = income_amt;
    }

    public String getIncome_ccy() {
        return income_ccy;
    }

    public void setIncome_ccy(String income_ccy) {
        this.income_ccy = income_ccy;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getClnt_dpndnt_cnt() {
        return clnt_dpndnt_cnt;
    }

    public void setClnt_dpndnt_cnt(String clnt_dpndnt_cnt) {
        this.clnt_dpndnt_cnt = clnt_dpndnt_cnt;
    }

    public String getWave_number() {
        return wave_number;
    }

    public void setWave_number(String wave_number) {
        this.wave_number = wave_number;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return numStr;
    }

    public void setNumStr(int numStr) {
        this.numStr = numStr;
    }

    @Override
    public String toString() {
        return "Reestr1{" +
                "uuid=" + uuid +
                ", customer_number='" + customer_number + '\'' +
                ", clnt_surnm_txt='" + clnt_surnm_txt + '\'' +
                ", clnt_frstnm_txt='" + clnt_frstnm_txt + '\'' +
                ", clnt_mid_txt='" + clnt_mid_txt + '\'' +
                ", clnt_birth_dt='" + clnt_birth_dt + '\'' +
                ", birth_place='" + birth_place + '\'' +
                ", clnt_resident_ind='" + clnt_resident_ind + '\'' +
                ", clnt_ntnlite_cde='" + clnt_ntnlite_cde + '\'' +
                ", clnt_tax_id='" + clnt_tax_id + '\'' +
                ", clnt_sex_cde='" + clnt_sex_cde + '\'' +
                ", clnt_grb_marital_stat_cde='" + clnt_grb_marital_stat_cde + '\'' +
                ", clnt_grb_edu_cde='" + clnt_grb_edu_cde + '\'' +
                ", credit_limit='" + credit_limit + '\'' +
                ", base_rte='" + base_rte + '\'' +
                ", days_past_due='" + days_past_due + '\'' +
                ", clnt_prim_doc_typ='" + clnt_prim_doc_typ + '\'' +
                ", clnt_prim_doc_id='" + clnt_prim_doc_id + '\'' +
                ", clnt_doc_issue_dt='" + clnt_doc_issue_dt + '\'' +
                ", clnt_doc_expirty_dt='" + clnt_doc_expirty_dt + '\'' +
                ", issue_place='" + issue_place + '\'' +
                ", Mobile_phone_number='" + Mobile_phone_number + '\'' +
                ", office_phone_number='" + office_phone_number + '\'' +
                ", ome_phone_number='" + home_phone_number + '\'' +
                ", clnt_email1_addr='" + clnt_email1_addr + '\'' +
                ", clnt_email2_addr='" + clnt_email2_addr + '\'' +
                ", home_address='" + home_address + '\'' +
                ", reg_address='" + reg_address + '\'' +
                ", reg_date='" + reg_date + '\'' +
                ", office_address='" + office_address + '\'' +
                ", legal_address='" + legal_address + '\'' +
                ", empl_month='" + empl_month + '\'' +
                ", clnt_empmt_job_title_cde='" + clnt_empmt_job_title_cde + '\'' +
                ", em_inn='" + em_inn + '\'' +
                ", clnt_emplr_nm='" + clnt_emplr_nm + '\'' +
                ", income_type='" + income_type + '\'' +
                ", income_amt='" + income_amt + '\'' +
                ", income_ccy='" + income_ccy + '\'' +
                ", fio='" + fio + '\'' +
                ", clnt_dpndnt_cnt='" + clnt_dpndnt_cnt + '\'' +
                ", wave_number='" + wave_number + '\'' +
                ", database_generation_date='" + database_generation_date + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                ", numStr=" + numStr +
                '}';
    }
}
