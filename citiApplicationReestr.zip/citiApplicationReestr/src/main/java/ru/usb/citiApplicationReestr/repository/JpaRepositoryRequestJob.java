package ru.usb.citiApplicationReestr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.citiApplicationReestr.model.RequestJob;

import javax.persistence.QueryHint;
import java.util.List;

import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaRepositoryRequestJob extends JpaRepository<RequestJob, Long> {

    /**
     * Получаем записи из Job по статусам
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
    })
    @Query(value ="select uuid, absolutename, dateinitial,dateprocessed,filename,filesize,status,statuscode,total_count_lines,error_count_lines from citijobreestr1 where statuscode=?1"
            , nativeQuery = true)
    List<RequestJob> getAllJobStatusCode(int code);

    /**
     * Получаем записи из Job по статусам и имени
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
    })
    @Query(value ="select uuid, absolutename, dateinitial,dateprocessed,filename,filesize,status,statuscode,total_count_lines,error_count_lines from citijobreestr1 where statuscode=?1 and absolutename=?2"
            , nativeQuery = true)
    List<RequestJob> getFileNameCode(int code, String fileName);


    /**
     * Получаем записи из Job по имени
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
    })
    @Query(value ="select uuid, absolutename, dateinitial,dateprocessed,filename,filesize,status,statuscode,total_count_lines,error_count_lines" +
            " from citijobreestr1 where statuscode not in (3,4,6) and absolutename=?1"
            , nativeQuery = true)
    List<RequestJob> getFileName(String fileName);

}
