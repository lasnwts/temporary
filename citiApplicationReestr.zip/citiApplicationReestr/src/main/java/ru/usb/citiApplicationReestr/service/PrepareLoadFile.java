package ru.usb.citiApplicationReestr.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citiApplicationReestr.config.Configure;
import ru.usb.citiApplicationReestr.model.RequestJob;
import ru.usb.citiApplicationReestr.repository.JpaRepositoryRequestJob;
import ru.usb.citiApplicationReestr.utils.WorkWithFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;

/**
 * Подготовка к загрзуке файлов
 */
@Service
public class PrepareLoadFile {

    Logger logger = LoggerFactory.getLogger(PrepareLoadFile.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    JpaRepositoryRequestJob jpaRepositoryRequestJob;

    public void prepareFiles() {

        /**
         * Просмотр директории
         */
        List<File> fileList = new ArrayList<>();

        /**
         * Запускаем сканирование каталога c файлами из СИТИ
         */
        fileList = withFiles.getDirList(configure.getFileDirectory());
        //Если файлы есть то отрабатываем по каждому файл
        if (fileList.size() > 0) {

            fileList.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {

                    if (withFiles.getExtensionFromFile(file).toUpperCase().contains(configure.getFileExt().toUpperCase())) {

                        logger.info("#####################################[Найден файл]##############################################");
                        logger.info("File:Найден файл формата :{} :{}", configure.getFileExt(), file.getAbsolutePath());

                        RequestJob requestJob = checkFileNameCode(file);

                        //Если объекта в базе нет, сохраняем новый
                        if (requestJob == null) {
                            saveNewJob(file);
                        } else {

                            //Проверяем размер, если  он увеличился, то обновляем размер и дату и ждем
                            if (requestJob.getFilesize() < file.length()) {
                                saveNewSize(file, requestJob);
                            } else {
                                //Проверяем, что файл не залочен
                                if (withFiles.isFilelocked(file)) {
                                    logger.info("File:заблокирован, видимо идет запись, пропускаем обработку:{}", configure.getFileExt(), file.getAbsolutePath());
                                } else {
                                    /**
                                     * Можно включать обработку файла
                                     */
                                    saveReadyFile(requestJob);
                                }
                            }
                        }
                        logger.info("######################################[Обработка завершена]##########################################");
                    }
                }
            });
        }
    }

    /**
     * Получаем в базе
     */
    private RequestJob checkFileNameCode(File file) {
        List<RequestJob> requestJobList = new ArrayList<>();
        requestJobList = jpaRepositoryRequestJob.getFileName(file.getAbsolutePath());
        if (requestJobList.size() > 0) {
            return requestJobList.get(0);
        } else {
            return null;
        }

    }

    /**
     * Обнаружен, запрошена загрузка (requested) 0
     * Готов к загрузке (ready download) 1
     * В процессе загрузки (downloaded) 2
     * Ошибка парсинга загрузки файла (failed parse) 3
     * Ошибка обработки при вставке в базу (failed process) 4
     * Обработка завершена (completed) 5
     */

    /**
     * Сохраняем в базу новое задание на обработку файла
     *
     * @param file File для внесения в БД
     * @return - успех true;
     */
    private boolean saveNewJob(File file) {
        RequestJob requestJob = new RequestJob();
        requestJob.setDateinitial(new Date());
        requestJob.setDateprocessed(new Date());
        requestJob.setFilename(file.getName());
        requestJob.setAbsolutename(file.getAbsolutePath());
        requestJob.setStatus("requested");
        requestJob.setStatuscode(0);
        requestJob.setFilesize(file.length());
        try {
            jpaRepositoryRequestJob.save(requestJob);
            logger.info("Success Save RequestJob:{}", requestJob.toString());
            return true;
        } catch (Exception exception) {
            logger.error("Error save RequestJob:{}", requestJob.toString());
            logger.error("Error:", exception.getMessage());
            return false;
        }
    }

    /**
     * Обновление записи в БД (размер, и время)
     *
     * @param file       - новый файл
     * @param requestJob - запись в БД
     */
    private void saveNewSize(File file, RequestJob requestJob) {
        requestJob.setDateprocessed(new Date());
        requestJob.setFilesize(file.length());
        jpaRepositoryRequestJob.save(requestJob);
    }

    /**
     * Обновление записи в БД (файл готов к загрузке)
     *
     * @param requestJob - объект записи
     */
    private void saveReadyFile(RequestJob requestJob) {
        if (requestJob.getStatuscode() == 0) {
            requestJob.setDateprocessed(new Date());
            requestJob.setStatuscode(1);
            requestJob.setStatus("ready download");
            jpaRepositoryRequestJob.save(requestJob);
        }
    }


}



