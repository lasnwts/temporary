package ru.usb.citiApplicationReestr.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Модель для работы с файлами реестров
 */
@Entity
@Table(indexes = {@Index(name = "mulitIndex1", columnList = "statuscode, absolutename")},
        name = "citijobreestr1")
public class RequestJob {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long uuid;


    //Дата, tmpstamp - постановка задачи в очередь
    private Date dateinitial;

    //Имя файла реестра csv
    private String filename;

    //Путь к файлу реестра полный
    private String absolutename;

    //размер файла
    private long filesize;

    /**
     * Обнаружен, запрошена загрузка (requested) 0
     * Готов к загрузке (ready download) 1
     * В процессе загрузки (downloaded) 2
     * Ошибка парсинга загрузки файла (failed parse) 3
     * Ошибка обработки при вставке в базу (failed process) 4
     * Обработка завершена (success processed) 5
     * Обработка завершена (completed) 6
     */
    private int statuscode;

    /**
     * Обнаружен, запрошена загрузка (requested) 0
     * Готов к загрузке (ready download) 1
     * В процессе загрузки (downloaded) 2
     * Ошибка парсинга загрузки файла (failed parse) 3
     * Ошибка обработки при вставке в базу (failed process) 4
     * Обработка завершена (success processed) 5
     * Обработка завершена (completed) 6
     */
    private String status;

    /**
     * Дата и время обработки файла
     */
    private Date dateprocessed;

    // Количество строк всего
    @Column(name = "TOTAL_COUNT_LINES")
    private int totalCountLines;

    // Количество строк с ошибкой из файла
    @Column(name = "ERROR_COUNT_LINES")
    private int errorCountLines;


    public RequestJob() {
    }

    public RequestJob(long uuid, Date dateinitial, String filename, String absolutename, long filesize,
                      int statuscode, String status, Date dateprocessed, int totalCountLines, int errorCountLines) {
        this.uuid = uuid;
        this.dateinitial = dateinitial;
        this.filename = filename;
        this.absolutename = absolutename;
        this.filesize = filesize;
        this.statuscode = statuscode;
        this.status = status;
        this.dateprocessed = dateprocessed;
        this.totalCountLines = totalCountLines;
        this.errorCountLines = errorCountLines;
    }

    public long getUuid() {
        return uuid;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public Date getDateinitial() {
        return dateinitial;
    }

    public void setDateinitial(Date dateinitial) {
        this.dateinitial = dateinitial;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getAbsolutename() {
        return absolutename;
    }

    public void setAbsolutename(String absolutename) {
        this.absolutename = absolutename;
    }

    public long getFilesize() {
        return filesize;
    }

    public void setFilesize(long filesize) {
        this.filesize = filesize;
    }

    public int getStatuscode() {
        return statuscode;
    }

    public void setStatuscode(int statuscode) {
        this.statuscode = statuscode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDateprocessed() {
        return dateprocessed;
    }

    public void setDateprocessed(Date dateprocessed) {
        this.dateprocessed = dateprocessed;
    }

    public int getTotalCountLines() {
        return totalCountLines;
    }

    public void setTotalCountLines(int totalCountLines) {
        this.totalCountLines = totalCountLines;
    }

    public int getErrorCountLines() {
        return errorCountLines;
    }

    public void setErrorCountLines(int errorCountLines) {
        this.errorCountLines = errorCountLines;
    }

    @Override
    public String toString() {
        return "RequestJob{" +
                "uuid=" + uuid +
                ", dateinitial=" + dateinitial +
                ", filename='" + filename + '\'' +
                ", absolutename='" + absolutename + '\'' +
                ", filesize=" + filesize +
                ", statuscode=" + statuscode +
                ", status='" + status + '\'' +
                ", dateprocessed=" + dateprocessed +
                ", totalCountLines=" + totalCountLines +
                ", errorCountLines=" + errorCountLines +
                '}';
    }
}
