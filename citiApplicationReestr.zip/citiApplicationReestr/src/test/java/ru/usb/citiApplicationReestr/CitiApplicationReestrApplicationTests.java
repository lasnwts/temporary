package ru.usb.citiApplicationReestr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiApplicationReestrApplicationTests {

	@Test
	void contextLoads() {
	}

}
