package com.bmarlin.sw278test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sw278testApplicationTests {

	@Test
	void contextLoads() {
	}

}
