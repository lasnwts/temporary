package com.bmarlin.sw278test.controller;

import com.bmarlin.sw278test.dto.Dmodel;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

/**
 * Создание Swagger
 * Подключение Springdoc для автоматизации документирования REST API
 * https://www.youtube.com/watch?v=12eztbR51kA
 *
 * Создание RestController (правда на kotlin)
 * https://www.youtube.com/watch?v=NWA64jwA7pg *
 *
 * Описание команд
 * https://devmark.ru/article/springdoc-rest-api
 */

/**
 * @Hidden - прячет контроллер целиком
 */
//@Hidden
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Короткое наименование", description = "длинное наименование контроллера")
public class RestControllerSw {

    @GetMapping("/getstr/{str}")
    @Operation(summary = "Получаем строку + что то еще.")
    public String getTestString(
            @Parameter(description = "Введите строку")
            @PathVariable("str") String str) {
        return "This is get:" + str;
    }

    @GetMapping("/getobject/{id}")
    @Operation(summary = "Получаем строку + что то еще.")
    public Dmodel getTestString(
            @Parameter(description = "Введите строку")
            @PathVariable("id") int id) {
        Dmodel dmodel = new Dmodel(1,"John", "Taker");
        return dmodel;
    }

    @PostMapping("/{id}")
    @Operation(summary = "Создание нового объекта")
    public Dmodel postNewDmodel(
            @Parameter(description = "Номер объекта")
            @PathVariable("id") int id,
            @Parameter(description = "Объект Dmodel")
            @RequestBody(required = true)  Dmodel dmodel)    {
        Dmodel dmodel1 = new Dmodel(id, dmodel.getName(), dmodel.getDescription());
        return dmodel1;
    }

}
