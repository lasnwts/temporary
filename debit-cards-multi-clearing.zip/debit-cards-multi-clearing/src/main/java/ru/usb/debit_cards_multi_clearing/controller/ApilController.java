package ru.usb.debit_cards_multi_clearing.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;
import ru.usb.debit_cards_multi_clearing.service.ApiService;
import ru.usb.debit_cards_multi_clearing.service.mail.EmailServiceImpl;
import ru.usb.debit_cards_multi_clearing.util.Sutils;

import java.util.List;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api")
@Tag(name = "Контроллер для проверки почтовой подсистемы", description = "Проверка отправки почты")
public class ApilController {

    private final Logger logger = LoggerFactory.getLogger(ApilController.class);
    private final EmailServiceImpl emailService;
    private final Sutils support;
    private final ApiService apiService;
    private final Configure configure;

    @Autowired
    public ApilController(EmailServiceImpl emailService, Sutils support, ApiService apiService, Configure configure) {
        this.emailService = emailService;
        this.support = support;
        this.apiService = apiService;
        this.configure = configure;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/mail/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                                  @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmailThrow(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            logger.error("{}: while sending out email..", LG.USBLOGERROR, mailException);
            return new ResponseEntity<>("Unable to send email: \n\r " + support.getWrapNull(mailException.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

    @GetMapping(value = "/source")
    @Operation(summary = "Получить список файлов в источнике")
    public ResponseEntity<String> getSourceList() {
        logger.info("{}:Web API: Получить список файлов в источнике", LG.USBLOGINFO);
        List<String> list = apiService.getListFiles(configure.getSourceFileUrl());
        list.forEach(s -> logger.info("{}:Web API: Список файлов в источнике: {}", LG.USBLOGINFO, s));
        if (list.isEmpty()) {
            return new ResponseEntity<>("No files found", HttpStatus.OK);
        }
        if (list.size() == 1) {
            return new ResponseEntity<>(list.get(0), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(support.getWrapNull(list.toString()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/destination")
    @Operation(summary = "Получить список файлов в [Destination], в каталоге назначения")
    public ResponseEntity<String> getDestinationList() {
        logger.info("{}:Web API: Получить список файлов в Destination", LG.USBLOGINFO);
        List<String> list = apiService.getListFiles(configure.getDestinationFileUrl());
        list.forEach(s -> logger.info("{}:Web API: Список файлов в destination: {}", LG.USBLOGINFO, s));
        if (list.isEmpty()) {
            return new ResponseEntity<>("No files found", HttpStatus.OK);
        }
        if (list.size() == 1) {
            return new ResponseEntity<>(list.get(0), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(support.getWrapNull(list.toString()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/destination-test")
    @Operation(summary = "Проверка доступности каталога Destination")
    public ResponseEntity<String> getDestinationTest() {
        logger.info("{}:Web API: Проверить доступность каталога Destination", LG.USBLOGINFO);
        if (apiService.testConnectDestination()) {
            return new ResponseEntity<>("Destination is available", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Destination is not available", HttpStatus.OK);
        }
    }

    @GetMapping(value = "/source-test")
    @Operation(summary = "Проверка доступности каталога Souce")
    public ResponseEntity<String> getSourceTest() {
        logger.info("{}:Web API: Проверить доступность каталога Source", LG.USBLOGINFO);
        if (apiService.testConnectDestination()) {
            return new ResponseEntity<>("Source is available", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Source is not available", HttpStatus.OK);
        }
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        configure.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (configure.isServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }

}
