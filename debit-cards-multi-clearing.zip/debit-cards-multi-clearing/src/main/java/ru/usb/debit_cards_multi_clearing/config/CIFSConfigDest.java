package ru.usb.debit_cards_multi_clearing.config;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Log4j2
@Configuration
public class CIFSConfigDest {
    @Value("${destination.file.domain}")
    private String domain;
    @Value("${destination.file.username}")
    private String username;
    @Value("${destination.file.password}")
    private String password;

    @Bean
    public CIFSContext doAuthDest() throws CIFSException {
        try {
            NtlmPasswordAuthenticator auth = new NtlmPasswordAuthenticator(domain, username, password);
            Properties properties = new Properties();
            properties.setProperty("jcifs.smb.client.responseTimeout", "20000");
            PropertyConfiguration configuration = new PropertyConfiguration(properties);
            return new BaseContext(configuration).withCredentials(auth);
        } catch (Exception e) {
            log.error("{} Ошибка инициализации smb:{}", LG.USBLOGERROR, e.getMessage());
            log.error("{} Stack Trace smb:", LG.USBLOGERROR, e);
            throw e;
        }
    }
}
