package ru.usb.debit_cards_multi_clearing.service.smb;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.smb.session.SmbSessionFactory;
import org.springframework.stereotype.Service;
import ru.usb.debit_cards_multi_clearing.config.CIFSConfig;
import ru.usb.debit_cards_multi_clearing.config.CIFSConfigDest;
import ru.usb.debit_cards_multi_clearing.config.LG;


import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Log4j2
public class SmbService {

    private final CIFSContext cifsContext;
    private final CIFSConfig cifsConfig;
    private final CIFSConfigDest cifsConfigDest;

    //Переменные
    FileOutputStream fileOutputStream;
    InputStream fileInputStream;
    byte[] buf;
    int len;


    @Autowired
    public SmbService(CIFSContext cifsContext, CIFSConfig cifsConfig, CIFSConfigDest cifsConfigDest) {
        this.cifsContext = cifsContext;
        this.cifsConfig = cifsConfig;
        this.cifsConfigDest = cifsConfigDest;
    }

    /**
     * Запись файла на шару
     *
     * @param fileName название файла, полное с путем
     * @param file     данные файла
     * @throws Exception ошибка записи
     */
    public void writeSmbFile(String fileName, byte[] file, int thread) throws Exception {
        String path = fileName;
        SmbFile smbFile = new SmbFile(path, cifsContext);
        try (SmbFileOutputStream smbfos = new SmbFileOutputStream(smbFile)) {
            smbfos.write(file);
            log.info("{}:T{}: Файл {} успешно записан", LG.USBLOGINFO, thread, fileName);
        } catch (IOException e) {
            log.error("{}:T{}: Ошибка при записи файла {}", LG.USBLOGERROR, thread, e.getMessage());
            throw e;
        }
    }

    /**
     * Создание каталога SMB
     *
     * @param path - путь к каталогу
     * @return - true если создан
     */
    public boolean createDirectory(String path) {
        SmbFile smbFile = null;
        try {
            smbFile = new SmbFile(path, cifsContext);
        } catch (MalformedURLException e) {
            log.error("{}: Ошибка при авторизации {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
        try {
            smbFile.mkdir();
            return true;
        } catch (SmbException e) {
            log.error("{}: Ошибка при попытке создания каталога {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
    }


    /**
     * Получение списка файлов
     * Get list files from smb
     */
    public Optional<List<String>> getList(String path) {
        List<String> list = new ArrayList<>();
        if (path == null || path.isEmpty()) {
            log.error("{}: Ошибка [path == null || path.isEmpty()] при получении списка файлов", LG.USBLOGERROR);
            return Optional.empty();
        }
        if (cifsContext == null) {
            log.error("{}: Ошибка [cifsContext == null] при получении списка файлов", LG.USBLOGERROR);
            return Optional.empty();
        }
        if (!path.toLowerCase().contains("smb://")) {
            path = "smb://" + path;
        }

        if (!connectToSmb(path)) {
            log.error("{}: [SmbService.getList] Ошибка при подключении к шаре:{}", LG.USBLOGERROR, path);
            return Optional.empty();
        }

        try {
            SmbFile smb = new SmbFile(path, cifsContext);
            SmbFile[] files = smb.listFiles();

            //Печатаем список файлов, + добавляем их в вывод
            for (SmbFile file : files) {
                log.info("Файл: {}", file.getName());
                if (!file.isDirectory()) {
                    list.add(file.getName());
                }
            }
            return Optional.of(list);
        } catch (MalformedURLException e) {
            log.error("{}: Ошибка [MalformedURLException] при получении списка файлов: {}", LG.USBLOGERROR, e.getMessage());
        } catch (SmbException e) {
            log.error("{}: Ошибка [SmbException] при получении списка файлов: {}", LG.USBLOGERROR, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Удаление файла с шары
     *
     * @param fullFileName название файла
     * @return true если удалось удалить
     */
    public boolean deleteFile(String fullFileName) {
        try (SmbFile smbFile = new SmbFile(fullFileName, cifsConfig.doAuth())) {
            smbFile.delete();
            log.info("{}: Файл {} успешно удален", LG.USBLOGINFO, fullFileName);
            return true;
        } catch (IOException e) {
            log.error("{}: Ошибка при удалении файла {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack Ошибка при удалении файла:", LG.USBLOGERROR, e);
            return false;
        }
    }

    /**
     * Коннект к SMB
     *
     * @param pathToSmb - путь к шаре
     * @return - true если подключение установлено
     */
    public boolean connectToSmb(String pathToSmb) {
        SmbFile pathConnect;
        boolean flgConnect = false;
        int i = 0;
        do {
            i++;
            log.info("{}: Попытка:{} соединения с smb шарой:{}", LG.USBLOGINFO, i, pathToSmb);
            try {
                pathConnect = new SmbFile(pathToSmb, cifsConfig.doAuth());
                pathConnect.connect();
                Thread.sleep(1000);
                flgConnect = pathConnect.exists();
            } catch (Exception e) {
                log.error("{}:connectToSmb={}.pathConnect.connect: Возникла ошибка={}", LG.USBLOGERROR, pathToSmb, e.getMessage());
                Thread.currentThread().interrupt();
                flgConnect = false;
            }
        } while (!flgConnect && i < 5);
        return flgConnect;
    }


    /**
     * Закрытие
     *
     * @param pathToSmb
     * @throws CIFSException
     * @throws MalformedURLException
     */
    public void closeToSmb(String pathToSmb) throws CIFSException, MalformedURLException {
        SmbFile pathConnect;
        pathConnect = new SmbFile(pathToSmb, cifsConfig.doAuth());
        pathConnect.close();
    }

    /**
     * Получение файла с шары
     *
     * @param filePath путь к файлу
     */
    public void smbCopyFile(String filePath, String destinationPath, long thread) throws IOException {
        SmbFile fileToGet;
        try {
            fileToGet = new SmbFile(filePath, cifsConfig.doAuth());
            fileToGet.connect();
        } catch (Exception e) {
            log.error("{}:T{}:smbCopyFile:SmbFile fileToGet: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}:smbCopyFile:SmbFile fileToGet: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
        SmbFile smbDestination;
        try {
            smbDestination = new SmbFile(destinationPath, cifsConfigDest.doAuthDest());
            smbDestination.connect();
        } catch (Exception e) {
            log.error("{}:T{}:smbCopyFile:SmbFile smbDestination: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}:smbCopyFile:SmbFile smbDestination: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
        try (InputStream in = new BufferedInputStream(new SmbFileInputStream(fileToGet));
             OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(smbDestination))) {
            byte[] buffer = new byte[131072];
            len = 0; //Read length
            while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush(); //The refresh buffer output stream
            log.info("{}:T{}: Файл:{}, скопирован в:{}", LG.USBLOGINFO, thread, filePath, destinationPath);
        } catch (Exception e) {
            log.error("{}:T{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.error("{}:T{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getLocalizedMessage());
            log.debug("{}:T{}:InputStream/OutputStream: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
    }


    /**
     * Сравнение размеров файла
     *
     * @param filePath        - исходный файл
     * @param destinationPath - файл назгначение в ЕФС
     * @param thread          - номер потока
     * @return - true - файлы одинаковы, false - разные
     * @throws IOException - ошибка доступа
     */
    public boolean compareSmbFile(String filePath, String destinationPath, long thread) {
        SmbFile fileToGet;
        try {
            fileToGet = new SmbFile(filePath, cifsConfig.doAuth());
            fileToGet.connect();
        } catch (Exception e) {
            log.error("{}:T{}:compareSmbFile:SmbFile fileToGet: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }
        SmbFile smbDestination;
        try {
            smbDestination = new SmbFile(destinationPath, cifsConfigDest.doAuthDest());
            smbDestination.connect();
        } catch (Exception e) {
            log.error("{}:T{}:compareSmbFile:SmbFile smbDestination: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }
        //Сравнение файлов
        try {
            if (fileToGet.length() == smbDestination.length()) {
                log.info("{}:T{} Размер={} файлов:[Источник[Source]:{}, Назначение[Destination]:{}] равна.", LG.USBLOGINFO, thread, fileToGet.length(), filePath, destinationPath);
                return true;
            } else {
                log.error("{}:T{} Ошибка! Размер файлов разный! [Источник[Source]:{}, размер={}, Назначение[Destination]:{}, размер={}].", LG.USBLOGINFO, thread, filePath, fileToGet.length(), destinationPath, smbDestination.length());
                return false;
            }
        } catch (SmbException e) {
            log.error("{}:T{}:compareSmbFile: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }
    }

    /**
     * Получаем файлы с сетевой шары
     *
     * @param directories - сетевой ресурс, где лежат файлы
     * @throws IOException - исключение при работе с файлами
     */
    public void proceedFiles(String directories) throws IOException {
        SmbSessionFactory sessionFactory = cifsConfig.smbSessionFactory();
        SmbFile[] smbFiles = sessionFactory.getSession().list(cifsConfig.getSubDirectory() + "/" + directories);
        for (SmbFile smbFile : smbFiles) {
            if (smbFile.isDirectory()) {
                log.info("{}: Directory:{}", LG.USBLOGINFO, smbFile.getName());
            } else {
                log.info("{}: File:{}, Size:{}", LG.USBLOGINFO, smbFile.getName(), smbFile.length());
                fileOutputStream = new FileOutputStream(cifsConfig.getNetFileShare() + "/" + smbFile.getName());
                fileInputStream = smbFile.getInputStream();
                buf = new byte[16 * 1024 * 1024];
                while ((len = fileInputStream.read(buf)) > 0) {
                    fileOutputStream.write(buf, 0, len);
                }
                fileInputStream.close();
                fileOutputStream.close();
                File file = new File(cifsConfig.getNetFileShare() + FileSystems.getDefault().getSeparator() + smbFile.getName());
                if (file.exists()) {
                    log.info("{}: Файл {} успешно записан во временную директорию", LG.USBLOGINFO, file.getName());
                } else {
                    log.warn("{}: Файл {} не записан", LG.USBLOGERROR, file.getName());
                }
                if (!mkSubDir(directories)) {
                    log.warn("{}: Не удалось создать каталог:{}", LG.USBLOGERROR, directories);
                    log.warn("{}: Копирование файла: {} отменяется", LG.USBLOGERROR, smbFile.getName());
                } else {
                    //Копируем файлы из локальной директории в сетевую папку
                    if (copyFile(directories, smbFile.getName(), file)) {
                        smbFile.delete();
                        smbFile.close();
                        if (Files.deleteIfExists(file.toPath())) {
                            log.info("{}: Файл {} успешно скопирован и удален из источника", LG.USBLOGINFO, smbFile.getName());
                        }
                    }
                }
            }
        }
        //Закрываем сессию источника
        sessionFactory.getSession().close();
    }


    /**
     * Создание подкаталога
     *
     * @param netPathResource - путь к ресурсу, например = 022
     * @return - true если создано
     */
    public boolean mkSubDir(String netPathResource) {
        //Создаем
        SmbFile smbFile = null;
        try {
            smbFile = new SmbFile(cifsConfigDest.getDestUrl() + "/" + netPathResource, cifsConfigDest.doAuthDest());
        } catch (MalformedURLException e) {
            log.error("{}:mkSubDir: Возникла ошибка[MalformedURLException]:{} при создании каталога={}", LG.USBLOGERROR, e.getMessage(), cifsConfigDest.getDestUrl() + "/" + netPathResource);
            return false;
        } catch (CIFSException e) {
            log.error("{}:mkSubDir: Возникла ошибка[CIFSException]:{} при создании каталога={}", LG.USBLOGERROR, e.getMessage(), cifsConfigDest.getDestUrl() + "/" + netPathResource);
            return false;
        }
        try {
            if (!smbFile.exists()) {
                smbFile.mkdir();
            }
        } catch (SmbException e) {
            log.error("{}:mkSubDir: Возникла ошибка[SmbException]:{} при создании каталога={}", LG.USBLOGERROR, e.getMessage(), cifsConfigDest.getDestUrl() + "/" + netPathResource);
            smbFile.close(); //Закрываем файл
            return false;
        }
        smbFile.close(); //Закрываем файл
        return true;
    }

    /**
     * Копирование файла
     *
     * @param netPathResource - путь к ресурсу, например = 022
     * @param fileName        - имя файла
     * @return - true если создано
     */
    public boolean copyFile(String netPathResource, String fileName, File file) {
        SmbFile smbFile = null;
        try {
            smbFile = new SmbFile(cifsConfigDest.getDestUrl() + "/" + netPathResource + "/" + fileName, cifsConfigDest.doAuthDest());
        } catch (MalformedURLException e) {
            log.warn("{}:copyFile: Возникла ошибка[MalformedURLException]:{} при создании каталога={}", LG.USBLOGERROR, e.getMessage(), cifsConfigDest.getDestUrl() + "/" + netPathResource);
            smbFile.close();
            return false;
        } catch (CIFSException e) {
            log.warn("{}:copyFile: Возникла ошибка[CIFSException]:{} при создании каталога={}", LG.USBLOGERROR, e.getMessage(), cifsConfigDest.getDestUrl() + "/" + netPathResource);
            smbFile.close();
            return false;
        }
        try (InputStream in = new java.io.FileInputStream(file.getAbsolutePath());
             OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(smbFile))) {
            byte[] buffer = new byte[131072];
            len = 0; //Read length
            while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush(); //The refresh buffer output stream
            smbFile.close();
            log.info("{}: Файл:{}, скопирован в:{}", LG.USBLOGINFO, "filePath", "destinationPath");
        } catch (Exception e) {
            log.warn("{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, e.getMessage());
            log.warn("{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, e.getLocalizedMessage());
            log.debug("{}:InputStream/OutputStream: Stack", LG.USBLOGERROR, e);
            smbFile.close(); //Закрываем файл
            return false;
        }
        smbFile.close(); //Закрываем файл
        return true;
    }

}
