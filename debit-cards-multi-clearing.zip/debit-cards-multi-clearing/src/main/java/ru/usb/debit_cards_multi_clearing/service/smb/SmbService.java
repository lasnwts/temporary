package ru.usb.debit_cards_multi_clearing.service.smb;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.debit_cards_multi_clearing.config.CIFSConfig;
import ru.usb.debit_cards_multi_clearing.config.CIFSConfigDest;
import ru.usb.debit_cards_multi_clearing.config.LG;


import java.io.*;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Log4j2
public class SmbService {

    private final CIFSContext cifsContext;
    private final CIFSConfig cifsConfig;
    private final CIFSConfigDest cifsConfigDest;

    @Autowired
    public SmbService(CIFSContext cifsContext, CIFSConfig cifsConfig, CIFSConfigDest cifsConfigDest) {
        this.cifsContext = cifsContext;
        this.cifsConfig = cifsConfig;
        this.cifsConfigDest = cifsConfigDest;
    }

    /**
     * Запись файла на шару
     *
     * @param fileName название файла, полное с путем
     * @param file     данные файла
     * @throws Exception ошибка записи
     */
    public void writeSmbFile(String fileName, byte[] file, int thread) throws Exception {
        String path = fileName;
        SmbFile smbFile = new SmbFile(path, cifsContext);
        try (SmbFileOutputStream smbfos = new SmbFileOutputStream(smbFile)) {
            smbfos.write(file);
            log.info("{}:T{}: Файл {} успешно записан", LG.USBLOGINFO, thread, fileName);
        } catch (IOException e) {
            log.error("{}:T{}: Ошибка при записи файла {}", LG.USBLOGERROR, thread, e.getMessage());
            throw e;
        }
    }

    /**
     * Создание каталога SMB
     * @param path - путь к каталогу
     * @return - true если создан
     */
    public boolean createDirectory(String path) {
        SmbFile smbFile = null;
        try {
            smbFile = new SmbFile(path, cifsContext);
        } catch (MalformedURLException e) {
            log.error("{}: Ошибка при авторизации {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
        try {
            smbFile.mkdir();
            return true;
        } catch (SmbException e) {
            log.error("{}: Ошибка при попытке создания каталога {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
    }


    /**
     * Получение списка файлов
     * Get list files from smb
     */
    public Optional<List<String>> getList(String path) {
        List<String> list = new ArrayList<>();
        if (path == null || path.isEmpty()) {
            log.error("{}: Ошибка [path == null || path.isEmpty()] при получении списка файлов", LG.USBLOGERROR);
            return Optional.empty();
        }
        if (cifsContext == null) {
            log.error("{}: Ошибка [cifsContext == null] при получении списка файлов", LG.USBLOGERROR);
            return Optional.empty();
        }
        if (!path.toLowerCase().contains("smb://")){
            path = "smb://" + path;
        }

        if (!connectToSmb(path)) {
            log.error("{}: [SmbService.getList] Ошибка при подключении к шаре:{}", LG.USBLOGERROR, path);
            return Optional.empty();
        }

        try {
            SmbFile smb = new SmbFile(path, cifsContext);
            SmbFile[] files = smb.listFiles();

            //Печатаем список файлов, + добавляем их в вывод
            for (SmbFile file : files) {
                log.info("Файл: {}", file.getName());
                if (!file.isDirectory()) {
                    list.add(file.getName());
                }
            }
            return Optional.of(list);
        } catch (MalformedURLException e) {
            log.error("{}: Ошибка [MalformedURLException] при получении списка файлов: {}", LG.USBLOGERROR, e.getMessage());
        } catch (SmbException e) {
            log.error("{}: Ошибка [SmbException] при получении списка файлов: {}", LG.USBLOGERROR, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Удаление файла с шары
     *
     * @param fullFileName название файла
     * @return true если удалось удалить
     */
    public boolean deleteFile(String fullFileName) {
        try (SmbFile smbFile = new SmbFile(fullFileName, cifsConfig.doAuth())) {
            smbFile.delete();
            log.info("{}: Файл {} успешно удален", LG.USBLOGINFO, fullFileName);
            return true;
        } catch (IOException e) {
            log.error("{}: Ошибка при удалении файла {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack Ошибка при удалении файла:", LG.USBLOGERROR, e);
            return false;
        }
    }

    /**
     * Коннект к SMB
     *
     * @param pathToSmb - путь к шаре
     * @return - true если подключение установлено
     */
    public boolean connectToSmb(String pathToSmb) {
        SmbFile pathConnect;
        boolean flgConnect = false;
        int i = 0;
        do {
            i++;
            log.info("{}: Попытка:{} соединения с smb шарой:{}", LG.USBLOGINFO, i, pathToSmb);
            try {
                pathConnect = new SmbFile(pathToSmb, cifsConfig.doAuth());
                pathConnect.connect();
                Thread.sleep(1000);
                flgConnect = pathConnect.exists();
            } catch (Exception e) {
                log.error("{}:connectToSmb={}.pathConnect.connect: Возникла ошибка={}", LG.USBLOGERROR, pathToSmb, e.getMessage());
                Thread.currentThread().interrupt();
                flgConnect = false;
            }
        } while (!flgConnect && i < 5);
        return flgConnect;
    }


    /**
     * Закрытие
     *
     * @param pathToSmb
     * @throws CIFSException
     * @throws MalformedURLException
     */
    public void closeToSmb(String pathToSmb) throws CIFSException, MalformedURLException {
        SmbFile pathConnect;
        pathConnect = new SmbFile(pathToSmb, cifsConfig.doAuth());
        pathConnect.close();
    }

    /**
     * Получение файла с шары
     *
     * @param filePath путь к файлу
     */
    public void smbCopyFile(String filePath, String destinationPath, long thread) throws IOException {
        SmbFile fileToGet;
        try {
            fileToGet = new SmbFile(filePath, cifsConfig.doAuth());
            fileToGet.connect();
        } catch (Exception e) {
            log.error("{}:T{}:smbCopyFile:SmbFile fileToGet: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}:smbCopyFile:SmbFile fileToGet: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
        SmbFile smbDestination;
        try {
            smbDestination = new SmbFile(destinationPath, cifsConfigDest.doAuthDest());
            smbDestination.connect();
        } catch (Exception e) {
            log.error("{}:T{}:smbCopyFile:SmbFile smbDestination: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}:smbCopyFile:SmbFile smbDestination: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
        try (InputStream in = new BufferedInputStream(new SmbFileInputStream(fileToGet));
             OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(smbDestination))) {
            byte[] buffer = new byte[131072];
            int len = 0; //Read length
            while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush(); //The refresh buffer output stream
            log.info("{}:T{}: Файл:{}, скопирован в:{}", LG.USBLOGINFO, thread, filePath, destinationPath);
        } catch (Exception e) {
            log.error("{}:T{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            log.error("{}:T{}:InputStream/OutputStream: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getLocalizedMessage());
            log.debug("{}:T{}:InputStream/OutputStream: Stack", LG.USBLOGERROR, thread, e);
            throw e;
        }
    }


    /**
     * Сравнение размеров файла
     *
     * @param filePath        - исходный файл
     * @param destinationPath - файл назгначение в ЕФС
     * @param thread          - номер потока
     * @return - true - файлы одинаковы, false - разные
     * @throws IOException - ошибка доступа
     */
    public boolean compareSmbFile(String filePath, String destinationPath, long thread) {
        SmbFile fileToGet;
        try {
            fileToGet = new SmbFile(filePath, cifsConfig.doAuth());
            fileToGet.connect();
        } catch (Exception e) {
            log.error("{}:T{}:compareSmbFile:SmbFile fileToGet: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }
        SmbFile smbDestination;
        try {
            smbDestination = new SmbFile(destinationPath, cifsConfigDest.doAuthDest());
            smbDestination.connect();
        } catch (Exception e) {
            log.error("{}:T{}:compareSmbFile:SmbFile smbDestination: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }
        //Сравнение файлов
        try {
            if (fileToGet.length() == smbDestination.length()) {
                log.info("{}:T{} Размер={} файлов:[Источник[Source]:{}, Назначение[Destination]:{}] равна.", LG.USBLOGINFO, thread, fileToGet.length(), filePath, destinationPath);
                return true;
            } else {
                log.error("{}:T{} Ошибка! Размер файлов разный! [Источник[Source]:{}, размер={}, Назначение[Destination]:{}, размер={}].", LG.USBLOGINFO, thread, filePath, fileToGet.length(), destinationPath, smbDestination.length());
                return false;
            }
        } catch (SmbException e) {
            log.error("{}:T{}:compareSmbFile: Возникла ошибка={}", LG.USBLOGERROR, thread, e.getMessage());
            return false;
        }

    }


}
