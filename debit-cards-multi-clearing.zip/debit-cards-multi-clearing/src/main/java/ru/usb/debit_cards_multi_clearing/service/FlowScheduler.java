package ru.usb.debit_cards_multi_clearing.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;
import ru.usb.debit_cards_multi_clearing.service.smb.SmbService;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Component
@EnableScheduling
@Log4j2
public class FlowScheduler {

    private final SmbService smbService;
    private final ApiService apiService;
    private final Configure configure;

    public FlowScheduler(SmbService smbService, ApiService apiService, Configure configure) {
        this.smbService = smbService;
        this.apiService = apiService;
        this.configure = configure;
    }

    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerExcluded() {
        if (configure.isServiceEnabled()) {
            //Цикл по каталогам
            for (String s : configure.getArrayOfDirectories()) {
                //Do your stuff here
                log.info("{}: Анализируем каталог на наличие файлов: {}", LG.USBLOGINFO, s);
                Optional<List<String>> list = smbService.getList(configure.getSourceFileUrl() + s + "/");
                if (list.isEmpty()) {
                    log.info("{}: Каталог пуст: {}", LG.USBLOGINFO, s);
                } else {
                    log.info("{}: Количество обнаруженных файлов List files: {}", LG.USBLOGINFO, list.get().size());
                    list.get().forEach(file -> {
                        log.info("{}: File: {}", LG.USBLOGINFO, file);
                        apiService.startCopyFile(Collections.singletonList(file), configure.getSourceFileUrl() + "/" + s + "/", configure.getDestinationFileUrl() + "/" + s + "/");
                    });
                }
            }
        }
    }
}
