package ru.usb.debit_cards_multi_clearing.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;


@Component
@EnableScheduling
@Log4j2
public class FlowScheduler {

    private final ApiService apiService;
    private final Configure configure;

    public FlowScheduler(ApiService apiService, Configure configure) {
        this.apiService = apiService;
        this.configure = configure;
    }

    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerExcluded() {
        if (configure.isServiceEnabled()) {
            //Цикл по каталогам
            for (String s : configure.getArrayOfDirectories()) {
                //Do your stuff here
                log.info("{}: --- <Анализируем каталог на наличие файлов: {}> --- ", LG.USBLOGINFO, s);
                apiService.proceedFiles(s + "/");
                log.info("{}: --- <Обработка файлов в каталоге: {} - завершена> --- ", LG.USBLOGINFO, s);
            }
        }
    }
}
