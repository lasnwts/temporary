package ru.usb.debit_cards_multi_clearing.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;
import ru.usb.debit_cards_multi_clearing.service.smb.SmbService;

import java.util.List;
import java.util.Optional;

@Component
@EnableScheduling
@Log4j2
public class FlowScheduler {

    private final SmbService smbService;
    private final ApiService apiService;
    private final Configure configure;

    public FlowScheduler(SmbService smbService, ApiService apiService, Configure configure) {
        this.smbService = smbService;
        this.apiService = apiService;
        this.configure = configure;
    }

    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerExcluded() {
       if (configure.isServiceEnabled()){
           Optional<List<String>> list = smbService.getList(configure.getSourceFileUrl());
           if (list.isEmpty()) {
               return;
           }
           log.info("{}: Количество обнаруженных файлоы List files: {}", LG.USBLOGINFO, list.get().size());
           list.get().forEach(s -> log.info("{}: File: {}", LG.USBLOGINFO, s));
           apiService.startCopyFile(list.get());
       }
    }
}
