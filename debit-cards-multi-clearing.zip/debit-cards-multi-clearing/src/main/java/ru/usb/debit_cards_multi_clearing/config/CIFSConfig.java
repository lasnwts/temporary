package ru.usb.debit_cards_multi_clearing.config;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.DialectVersion;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.FileSystemResource;
import org.springframework.integration.smb.session.SmbSession;
import org.springframework.integration.smb.session.SmbSessionFactory;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Конфигурация SMB
 *             CIFSContext cifsContext = new BaseContext(configuration).withCredentials(auth);
 *             return cifsContext;
 *             throw e;
 */
@Log4j2
@Getter
@Configuration
public class CIFSConfig {
    @Value("${source.file.domain}")
    private String domain;
    @Value("${source.file.username}")
    private String username;
    @Value("${source.file.password}")
    private String password;
    @Value("${source.file.host}")
    private String host;
    @Value("${source.file.port}")
    private int port;
    @Value("${source.file.share}")
    private String share;
    @Value("${net.file.share:transform}")
    private String netFileShare;
    @Value("${source.file.subdir}")
    private String subDirectory;

    @Bean
    @Primary
    public CIFSContext doAuth() throws CIFSException {
        try {
            NtlmPasswordAuthenticator auth = new NtlmPasswordAuthenticator(domain, username, password);
            Properties properties = new Properties();
            properties.setProperty("jcifs.smb.client.responseTimeout", "20000");
            PropertyConfiguration configuration = new PropertyConfiguration(properties);
            return new BaseContext(configuration).withCredentials(auth);
        } catch (Exception e) {
            log.error("{} Ошибка инициализации smb:{}", LG.USBLOGERROR, e.getMessage());
            log.error("{} Stack Trace smb:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    @Bean
    public SmbSessionFactory smbSessionFactory() {
        SmbSessionFactory smbSession = new SmbSessionFactory();
        smbSession.setHost(host);
        smbSession.setPort(port);
        smbSession.setDomain(domain);
        smbSession.setUsername(username);
        smbSession.setPassword(password);
        smbSession.setShareAndDir(share);
        smbSession.setSmbMinVersion(DialectVersion.SMB210);
        smbSession.setSmbMaxVersion(DialectVersion.SMB311);
        return smbSession;
    }

    @Bean
    public SmbSession smbSession(SmbSessionFactory smbSessionFactory) {
        return smbSessionFactory.getSession();
    }

    /**
     * Закрытие сессии
     * @param smbSession - сессия
     */
    public void closeSession(SmbSession smbSession) {
        smbSession.close();
    }

    /**
     * Получить путь к временной локальной папке
     * @return - путь к временной папке
     */
    public Path getNetFileShare() {
        return Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + netFileShare);
    }

}
