package ru.usb.debit_cards_multi_clearing.service;

import jcifs.CIFSException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;
import ru.usb.debit_cards_multi_clearing.service.smb.SmbService;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiService {

    private final SmbService smbService;
    private final Configure configure;

    public ApiService(SmbService smbService, Configure configure) {
        this.smbService = smbService;
        this.configure = configure;
    }

    /**
     * Получение списка файлов
     *
     * @param path - путь к файлам
     * @return - список файлов
     */
    public List<String> getListFiles(String path) {
        List<String> list = new ArrayList<>();
        if (path != null) {
            Optional<List<String>> listOptional = smbService.getList(path);
            if (listOptional.isPresent()) {
                list = listOptional.get();
            }
        }
        return list;
    }

    /**
     * Проверка подключения к шаре Source
     *
     * @return - true если подключение установлено
     */
    public boolean testConnectSource() {
        return smbService.connectToSmb(configure.getSourceFileUrl());
    }

    /**
     * Проверка подключения к шаре Destination
     *
     * @return - true если подключение установлено
     */
    public boolean testConnectDestination() {
        return smbService.connectToSmb(configure.getDestinationFileUrl());
    }


    /**
     * Удаление файла
     *
     * @param fullFileName - полное имя файла
     * @return - true если удалось удалить
     */
    public boolean deleteFile(String fullFileName) {
        return smbService.deleteFile(fullFileName);
    }

    /**
     * Копирование файла
     *
     * @param sourceFile      - полное имя файла
     * @param destinationFile - полное имя файла
     */
    public void copyFile(String sourceFile, String destinationFile) {
        try {
            smbService.smbCopyFile(sourceFile, destinationFile, 1);
        } catch (IOException e) {
            log.error("{}: [ApiService.copyFile] Ошибка при копировании файла: {}", LG.USBLOGERROR, e.getMessage());
        }
    }


    /**
     * Копирование файла
     *
     * @param listFiles       - список файлов
     * @param pathSource      - путь к SMB файлам
     * @param pathDestination - путь к SMB файлам
     */
    public void startCopyFile(List<String> listFiles, String pathSource, String pathDestination) {
        if (listFiles == null || listFiles.isEmpty()) {
            log.info("{}: [ApiService.startCopyFile] Список файлов пуст", LG.USBLOGINFO);
            return;
        }
        if (!smbService.connectToSmb(configure.getDestinationFileUrl())) {
            log.error("{}: [ApiService.startCopyFile] Не удалось подключиться к шаре[configure.getDestinationFileUrl()]:{}", LG.USBLOGERROR, configure.getDestinationFileUrl());
            return;
        }
        if (!smbService.connectToSmb(configure.getSourceFileUrl())) {
            log.error("{}: [ApiService.startCopyFile] Не удалось подключиться к шаре:{}", LG.USBLOGERROR, configure.getSourceFileUrl());
            return;
        }
        if (!smbService.connectToSmb(pathDestination)) {
            log.error("{}: [ApiService.startCopyFile] Не удалось подключиться к шаре[pathDestination]:{}", LG.USBLOGERROR, pathDestination);
            if (smbService.createDirectory(pathDestination)) {
                log.info("{}: [ApiService.startCopyFile] Директория {} создана", LG.USBLOGINFO, pathDestination);
            } else {
                log.error("{}: [ApiService.startCopyFile] Не удалось создать директорию:{}", LG.USBLOGERROR, pathDestination);
                return;
            }
        }
        processFile(listFiles, pathSource, pathDestination); //Обработка файлов
        closeToSmb(pathDestination); //Закрываем соединения с SMB
    }

    /**
     * Закрываем соединения с SMB
     *
     * @param pathDestination - путь к SMB файлам
     */
    private void closeToSmb(String pathDestination) {
        //Закрываем соединение
        try {
            smbService.closeToSmb(configure.getSourceFileUrl());
            log.info("{}: [ApiService.startCopyFile.getSourceFileUrl] Соединение с {} закрыто", LG.USBLOGINFO, configure.getSourceFileUrl());
        } catch (CIFSException e) {
            log.error("{}: [ApiService.startCopyFile.getSourceFileUrl[CIFSException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}: [ApiService.startCopyFile.getSourceFileUrl[MalformedURLException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        }
        try {
            smbService.closeToSmb(configure.getDestinationFileUrl());
            log.info("{}: [ApiService.startCopyFile.getDestinationFileUrl] Соединение с {} закрыто", LG.USBLOGINFO, configure.getDestinationFileUrl());
        } catch (CIFSException e) {
            log.error("{}: [ApiService.startCopyFile.getDestinationFileUrl[CIFSException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}: [ApiService.startCopyFile.getDestinationFileUrl[MalformedURLException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        }
        try {
            smbService.closeToSmb(pathDestination);
            log.info("{}: [ApiService.startCopyFile.closeToSmb] Соединение с [pathDestination] {} закрыто", LG.USBLOGINFO, pathDestination);
        } catch (CIFSException e) {
            log.error("{}: [ApiService.startCopyFile.closeToSmb[CIFSException]] Ошибка при закрытии соединения[pathDestination]:{}: {}", LG.USBLOGERROR, pathDestination, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}: [ApiService.startCopyFile.closeToSmb[MalformedURLException]] Ошибка при закрытии соединения[pathDestination]:{}: {}", LG.USBLOGERROR, pathDestination, e.getMessage());
        }
    }

    /**
     * Копирование файла
     *
     * @param listFiles       - список файлов
     * @param pathSource      - путь к SMB файлам
     * @param pathDestination - путь к SMB файлам
     */
    private void processFile(List<String> listFiles, String pathSource, String pathDestination) {
        // Копируем файлы
        for (String file : listFiles) {
            log.info("{}: [ApiService.startCopyFile] Копирование файла:{}{} в папку {}{}", LG.USBLOGINFO, pathSource, file, pathDestination, file);
            copyFile(pathSource + file, pathDestination + file);
            compareFiles(file, pathSource, pathDestination); //Сравнение файлов
        }
    }

    /**
     * Сравнение файлов
     *
     * @param file            - имя файла
     * @param pathSource      - путь к SMB файлам
     * @param pathDestination - путь к SMB файлам
     */
    private void compareFiles(String file, String pathSource, String pathDestination) {
        if (smbService.compareSmbFile(pathSource + file, pathDestination + file, 1)) {
            log.info("{}: [ApiService.startCopyFile] Файл:{}{} успешно скопирован", LG.USBLOGINFO, pathDestination, file);
            if (configure.isDeleteFile()) {
                log.info("{}: [ApiService.startCopyFile] Попытка удаления файла:{}{}", LG.USBLOGINFO, pathSource, file);
                if (smbService.deleteFile(pathSource + file)) {
                    log.info("{}: [ApiService.startCopyFile] Удаление файла:{}{} прошло успешно", LG.USBLOGINFO, pathSource, file);
                } else {
                    log.error("{}: [ApiService.startCopyFile] Удаление файла:{}{} не удалось", LG.USBLOGERROR, pathSource, file);
                }
            }
        } else {
            log.error("{}: [ApiService.startCopyFile] Файл:{}{} не скопирован полностью. Возникла ошибка при копировании.", LG.USBLOGERROR, pathDestination, file);
            if (smbService.deleteFile(pathDestination + file)) {
                log.info("{}: [ApiService.startCopyFile] Удаление файла:{}{}, скопированного не полностью, прошло успешно", LG.USBLOGINFO, pathDestination, file);
            } else {
                log.error("{}: [ApiService.startCopyFile] Удаление файла:{}{},  скопированного не полностью, не удалось", LG.USBLOGERROR, pathDestination, file);
            }
        }
    }


    /**
     * Копирование файлов в локальную директорию
     * @param sourceDirectory - путь к SMB файлам
     */
    public void proceedFiles(String sourceDirectory) {
        try {
            smbService.proceedFiles(sourceDirectory);
        } catch (IOException e) {
            log.error("{}: [ApiService.proceedFiles] Ошибка при копировании файлов: {}", LG.USBLOGERROR, e.getMessage());
        }
    }


}
