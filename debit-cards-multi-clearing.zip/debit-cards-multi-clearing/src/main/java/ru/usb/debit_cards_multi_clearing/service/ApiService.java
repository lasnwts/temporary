package ru.usb.debit_cards_multi_clearing.service;

import jcifs.CIFSException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.debit_cards_multi_clearing.config.Configure;
import ru.usb.debit_cards_multi_clearing.config.LG;
import ru.usb.debit_cards_multi_clearing.service.smb.SmbService;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiService {

    private final SmbService smbService;
    private final Configure configure;

    public ApiService(SmbService smbService, Configure configure) {
        this.smbService = smbService;
        this.configure = configure;
    }

    /**
     * Получение списка файлов
     *
     * @param path - путь к файлам
     * @return - список файлов
     */
    public List<String> getListFiles(String path) {
        List<String> list = new ArrayList<>();
        if (path != null) {
            Optional<List<String>> listOptional = smbService.getList(path);
            if (listOptional.isPresent()) {
                list = listOptional.get();
            }
        }
        return list;
    }

    /**
     * Проверка подключения к шаре Source
     *
     * @return - true если подключение установлено
     */
    public boolean testConnectSource(){
        return smbService.connectToSmb(configure.getSourceFileUrl());
    }

    /**
     * Проверка подключения к шаре Destination
     *
     * @return - true если подключение установлено
     */
    public boolean testConnectDestination(){
        return smbService.connectToSmb(configure.getDestinationFileUrl());
    }


    /**
     * Удаление файла
     *
     * @param fullFileName - полное имя файла
     * @return - true если удалось удалить
     */
    public boolean deleteFile(String fullFileName) {
        return smbService.deleteFile(fullFileName);
    }

    /**
     * Копирование файла
     *
     * @param sourceFile      - полное имя файла
     * @param destinationFile - полное имя файла
     */
    public void copyFile(String sourceFile, String destinationFile) {
        try {
            smbService.smbCopyFile(sourceFile, destinationFile, 1);
        } catch (IOException e) {
            log.error("{}: [ApiService.copyFile] Ошибка при копировании файла: {}", LG.USBLOGERROR, e.getMessage());
        }
    }


    /**
     * Копирование файла
     *
     * @param listFiles - список файлов
     */
    public void startCopyFile(List<String> listFiles) {
        if (listFiles == null || listFiles.isEmpty()) {
            log.info("{}: [ApiService.startCopyFile] Список файлов пуст", LG.USBLOGINFO);
            return;
        }

        if (!smbService.connectToSmb(configure.getDestinationFileUrl())) {
            log.error("{}: [ApiService.startCopyFile] Не удалось подключиться к шаре:{}", LG.USBLOGERROR, configure.getDestinationFileUrl());
            return;
        }
        if (!smbService.connectToSmb(configure.getSourceFileUrl())) {
            log.error("{}: [ApiService.startCopyFile] Не удалось подключиться к шаре:{}", LG.USBLOGERROR, configure.getSourceFileUrl());
            return;
        }
        processFile(listFiles); //Обработка файлов
        closeToSmb(); //Закрываем соединения с SMB
    }

    /**
     * Закрываем соединения с SMB
     */
    private void closeToSmb() {
        //Закрываем соединение
        try {
            smbService.closeToSmb(configure.getSourceFileUrl());
            log.info("{}: [ApiService.startCopyFile.getSourceFileUrl] Соединение с {} закрыто", LG.USBLOGINFO, configure.getSourceFileUrl());
        } catch (CIFSException e) {
            log.error("{}: [ApiService.startCopyFile.getSourceFileUrl[CIFSException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}: [ApiService.startCopyFile.getSourceFileUrl[MalformedURLException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        }
        try {
            smbService.closeToSmb(configure.getDestinationFileUrl());
            log.info("{}: [ApiService.startCopyFile.getDestinationFileUrl] Соединение с {} закрыто", LG.USBLOGINFO, configure.getDestinationFileUrl());
        } catch (CIFSException e) {
            log.error("{}: [ApiService.startCopyFile.getDestinationFileUrl[CIFSException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}: [ApiService.startCopyFile.getDestinationFileUrl[MalformedURLException]] Ошибка при закрытии соединения: {}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Копирование файла
     *
     * @param listFiles - список файлов
     */
    private void processFile(List<String> listFiles) {
        // Копируем файлы
        for (String file : listFiles) {
            log.info("{}: [ApiService.startCopyFile] Копирование файла:{}{} в папку {}{}", LG.USBLOGINFO, configure.getSourceFileUrl(), file, configure.getDestinationFileUrl(), file);
            copyFile(configure.getSourceFileUrl() + file, configure.getDestinationFileUrl() + file);
            compareFiles(file); //Сравнение файлов
        }
    }

    /**
     * Сравнение файлов
     *
     * @param file - имя файла
     */
    private void compareFiles(String file) {
        if (smbService.compareSmbFile(configure.getSourceFileUrl() + file, configure.getDestinationFileUrl() + file, 1)) {
            log.info("{}: [ApiService.startCopyFile] Файл:{}{} успешно скопирован", LG.USBLOGINFO, configure.getDestinationFileUrl(), file);
            if (configure.isDeleteFile()) {
                log.info("{}: [ApiService.startCopyFile] Попытка удаления файла:{}{}", LG.USBLOGINFO, configure.getSourceFileUrl(), file);
                if (smbService.deleteFile(configure.getSourceFileUrl() + file)) {
                    log.info("{}: [ApiService.startCopyFile] Удаление файла:{}{} прошло успешно", LG.USBLOGINFO, configure.getSourceFileUrl(), file);
                } else {
                    log.error("{}: [ApiService.startCopyFile] Удаление файла:{}{} не удалось", LG.USBLOGERROR, configure.getSourceFileUrl(), file);
                }
            }
        } else {
            log.error("{}: [ApiService.startCopyFile] Файл:{}{} не скопирован полностью. Возникла ошибка при копировании.", LG.USBLOGERROR, configure.getDestinationFileUrl(), file);
            if (smbService.deleteFile(configure.getDestinationFileUrl() + file)) {
                log.info("{}: [ApiService.startCopyFile] Удаление файла:{}{}, скопированного не полностью, прошло успешно", LG.USBLOGINFO, configure.getDestinationFileUrl(), file);
            } else {
                log.error("{}: [ApiService.startCopyFile] Удаление файла:{}{},  скопированного не полностью, не удалось", LG.USBLOGERROR, configure.getDestinationFileUrl(), file);
            }
        }
    }


}
