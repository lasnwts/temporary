package ru.usb.debit_cards_multi_clearing;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class
DebitCardsMultiClearingApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(DebitCardsMultiClearingApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DebitCardsMultiClearingApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:0.0.11}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (debit-cards-multi-clearing)")
				.version(appVersion)
				.description("API Transfer file from source SMB to destination SMB. Сервис переноса файлов.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info(".");
		logger.info("..");
		logger.info(":-----------------------------------------------------------------------------------------------------------------------------------------------------------+" );
		logger.info("| Name service                   : debit-cards-multi-clearing" );
		logger.info("| Version of service             : 0.0.10" );
		logger.info("| Date created                   : 04/02/2025" );
		logger.info("+----------------------------------------------------------------------------------------------------------------------------------------------------------+" );
		logger.info("| МП 978219                      : ДЕБЕТОВЫЕ КАРТЫ_Мультиклиринг по картам ФЛ и ЮЛ");
		logger.info("| Ссылка на МП                   : https://sdportal/mprojects/978219");
		logger.info("| Ссылка на Confluence           : https://confluence.uralsib.ru/display/INTEGRATION/168+-+debit-cards-multi-clearing");
		logger.info(":+---------------------------------------------------------------------------------------------------------------------------------------------------------+" );
		logger.info("| Описание                       : ");
		logger.info("| -------------------------------: ");
		logger.info("| Розничное банковское обслуживание / Расчетно-кассовое обслуживание физических лиц / Выпуск и обслуживание дебетовых карт / Сопровождение продукта");
		logger.info("| Сервис производит перенос файлов из сетевой шарфы Ритейла в другую сетевую шару");
		logger.info(":+---------------------------------------------------------------------------------------------------------------------------------------------------------+" );
		logger.info("| Version: 0.0.11, Date modified : 14/02/2025, Reason Modified: Добавлены каталоги к SMB шаре 001,022,024,028,032,047,099" );
		logger.info("+=----------------------------------------------------------------------------------------------------------------------------------------------------------_" );
	}
}
