package ru.usb.debit_cards_multi_clearing;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DebitCardsMultiClearingApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(DebitCardsMultiClearingApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DebitCardsMultiClearingApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:0.0.10}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (debit-cards-multi-clearing)")
				.version(appVersion)
				.description("API Transfer file from source SMB to destination SMB. Сервис переноса файлов.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info(".");
		logger.info("..");
		logger.info(":----------------------------------------------------------------------------------------------------------------------------------------------------------+" );
		logger.info("| Name service                                                         : debit-cards-multi-clearing" );
		logger.info("| Version of service                                                   : 0.0.10" );
		logger.info("| Date created                                                         : 04/02/2025" );
		logger.info("+-----------------------------------------------------------------------------------------------------------------------------------------------------------_" );
	}
}
