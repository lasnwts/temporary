package ru.usb.debit_cards_multi_clearing.util;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

@Component
public class Sutils {

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Получение имени файла из URL
      * @param url - переданная ссылка
     * @return - имя файла
     */
    public String getNameFromUrl(String url) {
        if (url == null || url.isEmpty()) {
            return "";
        } else {
            return FilenameUtils.getName(url);
        }
    }

}
