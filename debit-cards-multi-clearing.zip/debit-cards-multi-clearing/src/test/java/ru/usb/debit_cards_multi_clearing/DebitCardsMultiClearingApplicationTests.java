package ru.usb.debit_cards_multi_clearing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebitCardsMultiClearingApplicationTests {

	@Test
	void contextLoads() {
	}

}
