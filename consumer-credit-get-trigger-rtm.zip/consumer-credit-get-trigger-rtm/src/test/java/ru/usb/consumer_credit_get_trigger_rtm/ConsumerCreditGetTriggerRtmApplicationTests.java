package ru.usb.consumer_credit_get_trigger_rtm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerCreditGetTriggerRtmApplicationTests {

	@Test
	void contextLoads() {
	}

}
