package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

/**
 * Ошибка кодировки при загрузке файла
 */
public class InvalidCharsetException extends Exception{
    public InvalidCharsetException(String message) {
        super(message);
    }
}
