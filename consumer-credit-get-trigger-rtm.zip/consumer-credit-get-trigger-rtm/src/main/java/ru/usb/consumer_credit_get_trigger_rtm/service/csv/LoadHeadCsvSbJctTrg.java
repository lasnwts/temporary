package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.utils.Support;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Service
public class LoadHeadCsvSbJctTrg {

    private final CsvSbJctTrgHeadMap csvSbJctTrgHeadMap;
    private final Support support;

    @Autowired
    public LoadHeadCsvSbJctTrg(CsvSbJctTrgHeadMap csvSbJctTrgHeadMap, Support support) {
        this.csvSbJctTrgHeadMap = csvSbJctTrgHeadMap;
        this.support = support;
    }

    Logger log = LoggerFactory.getLogger(LoadHeadCsvSbJctTrg.class);


    /**
     *  Получение заголовка файла CSV
     * @param file - файл для загрузки
     * @param fileName - имя файла
     * @param thread - номер потока
     * @return - заголовок файла
     */
    public Optional<CsvSbJctTrgHeadPosition> loadFile(File file, String fileName, long thread) {

        //Если файла не существует, выходим
        if (file == null || !file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadHeadCsvSbJctTrg, переданный Файл {} не существует", LG.USBLOGERROR, thread, fileName);
            return null;
        }

        log.info("{}:T{}: Подготовка процесса: Load LoadHeadCsvSbJctTrg к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), support.formatDateTime(new Date()));
        AtomicReference<CsvSbJctTrgHeadPosition> sbJctTrgHeadPositionAtomicReference = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadHeadCsvSbJctTrg, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));

        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8).filter(s -> s.contains("PRIMARY_ID_TYPE"))) {
            lines.forEach(line -> {
                        try {
                            sbJctTrgHeadPositionAtomicReference.set(csvSbJctTrgHeadMap.map(line.trim())); //разбираем, что где находится в строке
                        } catch (Exception e) {
                            log.error("{}:T{}: Возникла Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}:::Stack_trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            long endTime = System.currentTimeMillis();
            log.info("{}:T{}: Завершение процесса: LoadHeadCsvSbJctTrg. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
            return Optional.ofNullable(sbJctTrgHeadPositionAtomicReference.get());
        } catch (IOException e) {
            log.error("{}:T{}: Возникла Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}:Stack-trace:", LG.USBLOGERROR, thread, e);
            return Optional.empty();
        }
    }
}
