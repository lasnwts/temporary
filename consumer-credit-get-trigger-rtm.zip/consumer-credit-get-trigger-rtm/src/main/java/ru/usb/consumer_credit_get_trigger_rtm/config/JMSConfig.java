package ru.usb.consumer_credit_get_trigger_rtm.config;

import com.tibco.tibjms.TibjmsConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;

import javax.jms.ConnectionFactory;


/** Class JMSConfig
 * @author Maria-Viktoria
 * Класс регистрирует свойства для получения подключения к JMS из файла application.properties
 */
@Configuration
@EnableJms
public class JMSConfig {

    /**
     * адрес url брокера сообщений
     */
    @Value("${tibco.jmsUrl}")
    private String jmsUrl;

    /**
     * логин для брокера сообщений
     */
    @Value("${tibco.username}")
    private String username;

    /**
     * пароль для брокера сообщений
     */
    @Value("${tibco.password}")
    private String password;


    /**
     *
     * Объект ConnectionFactory инкапсулирует набор параметров конфигурации подключения,
     * определенных в данном примере в application.properties и используется для создания соединения с поставщиком JMS.
     *Для работы необходимо подключить зависимость tibjms 8.2
     * https://docs.oracle.com/javaee/7/api/javax/jms/ConnectionFactory.html
     * @return -Объект ConnectionFactory
     *
     */
    @Bean("jmsConnectionFactory")
    public ConnectionFactory connectionFactory() {
        TibjmsConnectionFactory factory = new TibjmsConnectionFactory(jmsUrl);

        factory.setUserName(username);
        factory.setUserPassword(password);
        return factory;
    }


}

