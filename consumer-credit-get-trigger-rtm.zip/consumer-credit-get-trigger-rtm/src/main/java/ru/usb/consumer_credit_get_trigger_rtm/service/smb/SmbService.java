package ru.usb.consumer_credit_get_trigger_rtm.service.smb;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.CIFSConfig;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.SmbFileDto;

import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;


@Service
public class SmbService {

    private final CIFSConfig cifsConfig;
    private final Config config;
    private CIFSContext cifsContext;

    Logger log = LoggerFactory.getLogger(SmbService.class);

    @Autowired
    public SmbService(CIFSConfig cifsConfig, Config config) {
        this.cifsConfig = cifsConfig;
        this.config = config;
    }

    /**
     * Запись файла на шару
     *
     * @param fileName название файла, полное с путем
     * @param file     данные файла
     * @throws Exception ошибка записи
     */
    public void writeSmbFile(String fileName, byte[] file, int thread) {
        try (SmbFileOutputStream smbFos = new SmbFileOutputStream(new SmbFile(fileName, cifsContext))) {
            smbFos.write(file);
            log.info("{}:T{}: Файл {} успешно записан", LG.USBLOGINFO, thread, fileName);
        } catch (SmbException e) {
            log.error("{}:T{}: Ошибка [SmbException] при записи файла {}", LG.USBLOGERROR, thread, e.getMessage());
        } catch (MalformedURLException e) {
            log.error("{}:T{}: Ошибка [MalformedURLException] при записи файла {}", LG.USBLOGERROR, thread, e.getMessage());
        } catch (IOException e) {
            log.error("{}:T{}: Ошибка [IOException] при записи файла {}", LG.USBLOGERROR, thread, e.getMessage());
        }
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     * @return - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(1000);
            if (Files.deleteIfExists(facFile.toPath())) {
                log.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, facFile.getAbsolutePath());
            } else {
                log.info("{}: Файл:{} не был удален из временной директории!", LG.USBLOGINFO, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            log.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.USBLOGERROR, facFile.getAbsolutePath(), e.getMessage());
            log.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            Thread.currentThread().interrupt();
        }
    }


    /**
     * Удаление файла smbFile
     *
     * @param smbFile -
     * @return - true если удалось удалить
     */
    public boolean deleteSmbFile(SmbFile smbFile) {
        try {
            smbFile.delete();
            log.info("{}:[deleteSmbFile] Файл {} успешно удален", LG.USBLOGINFO, smbFile.getUncPath());
            return true;
        } catch (IOException e) {
            log.error("{}: [deleteSmbFile] Ошибка при удалении файла {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack Ошибка при удалении файла:", LG.USBLOGERROR, e);
            return false;
        }
    }

    /**
     * Удаление файла с шары
     *
     * @param fullFileName название файла
     * @return true если удалось удалить
     */
    public boolean deleteFile(String fullFileName, CIFSContext cifsContext) {
        try (SmbFile smbFile = new SmbFile(fullFileName, cifsContext)) {
            smbFile.delete();
            log.info("Файл {} успешно удален", fullFileName);
            return true;
        } catch (IOException e) {
            log.error("Ошибка при удалении файла {}", e.getMessage());
            log.debug("Stack Ошибка при удалении файла:", e);
            return false;
        }
    }

    /**
     * Аутентификация
     *
     * @return - CIFSContext
     */
    public CIFSContext getCifsConfig() {
        cifsContext = cifsConfig.doAuth();
        return cifsContext;
    }

    /**
     * Проверка наличия файла на шаре
     *
     * @return true если есть
     */
    public boolean checkSmb() {
        if (cifsContext == null) {
            return false;
        }
        try {
            return cifsContext.get(config.getSmbFileUrl()).exists();
        } catch (CIFSException e) {
            log.error("{}:checkSmb: Возникла ошибка={}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
    }

    /**
     * Закрытие
     */
    public void closeToSmb(String pathToSmb, CIFSContext cifsContext) {
        SmbFile pathConnect;
        try {
            pathConnect = new SmbFile(pathToSmb, cifsContext);
            pathConnect.close();
        } catch (Exception e) {
            log.error("{}:closeToSmb.pathConnect.close: Возникла ошибка={}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Копирование файла с шары
     *
     * @param fileSource      - исходный файл
     * @param fileDestination - файл назначение, скопированный
     */
    public SmbFileDto copySmbFile(SmbFile fileSource, SmbFile fileDestination) {
        log.info("{}:Подготовка копирования файлов. [copySmbFile] Файл источник:{}, должен быть скопирован в:{}", LG.USBLOGINFO, fileSource.getUncPath(), fileDestination.getUncPath());
        try (InputStream in = new BufferedInputStream(new SmbFileInputStream(fileSource));
             OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(fileDestination))) {
            byte[] buffer = new byte[131072];
            int len = 0; //Read length
            while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush(); //The refresh buffer output stream
            log.info("{}:[copySmbFile] Файл:{}, скопирован в:{}", LG.USBLOGINFO, fileSource.getUncPath(), fileDestination.getUncPath());
            return new SmbFileDto(fileSource, fileDestination);
        } catch (Exception e) {
            log.error("{}:[copySmbFile] Возникла ошибка={}", LG.USBLOGERROR, e.getMessage());
            log.debug("Stack", e);
            return new SmbFileDto(); //Пустой
        }
    }


    /**
     * Копирование файла с шары в локальный файл
     *
     * @param smbFile  - исходный файл
     * @param fileName - файл назначение, скопированный
     */
    public File copySmbFileToFile(SmbFile smbFile, String fileName) throws InvalidFileException {
        InputStream in = null;
        OutputStream out = null;
        log.info("{}:Подготовка копирования файла на локальный диск для загрузки. [copySmbFileToFile] Файл источник:{}, должен быть скопирован в локальную папку:{}", LG.USBLOGINFO, smbFile.getUncPath(), fileName);
        try {
            in = new SmbFileInputStream(smbFile); // Use SmbFileInputStream
            out = new FileOutputStream(new File(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + config.getNetFileShare() + FileSystems.getDefault().getSeparator() +
                    fileName));
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }

        } catch (MalformedURLException | SmbException | FileNotFoundException e) {
            throw new InvalidFileException(e.getMessage());
        } catch (IOException e) {
            throw new InvalidFileException(e.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    throw new InvalidFileException(e.getMessage());
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    throw new InvalidFileException(e.getMessage());
                }
            }
        }
        log.info("{}:[copySmbFileToFile] Файл:{}, скопирован в локальную папку:{}", LG.USBLOGINFO, smbFile.getUncPath(), fileName);
        return new File(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare() + FileSystems.getDefault().getSeparator() +
                fileName);
    }


    /**
     * Получение файла с шары
     *
     * @param filePath путь к файлу
     */
    public Optional<SmbFile> getSmbFile(String filePath, CIFSContext cifsContext) {
        try (SmbFile smbFile = new SmbFile(filePath, cifsContext)) {
            smbFile.connect();
            return Optional.of(smbFile);
        } catch (Exception e) {
            log.error("{}:getSmbFile: Возникла ошибка={}", LG.USBLOGERROR, e.getMessage());
            return Optional.empty();
        }
    }


    /**
     * Сравнение файлов
     *
     * @param fileSource      - файл источник
     * @param fileDestination - файл получатель
     * @return - true если файлы равны
     */
    public boolean compareSmbFile(SmbFile fileSource, SmbFile fileDestination) {
        try {
            //Сравнение файлов
            if (fileSource.length() == fileDestination.length()) {
                log.info("{}:[compareSmbFile] Размер={} файлов:[Источник:{}, Получатель:{}] равна. Можно удалять исходный файл.", LG.USBLOGINFO, fileSource.length(), fileSource.getUncPath(), fileDestination.getUncPath());
                return true;
            } else {
                log.warn("{}:[compareSmbFile] Ошибка! Размер файлов разный![Источник:{}, размер файла:{}, Получатель:{}, размер файла:{}] равна. Можно удалять исходный файл.",
                        LG.USBLOGINFO, fileSource.getUncPath(), fileSource.length(), fileDestination.getUncPath(), fileDestination.length());
                return false;
            }
        } catch (SmbException e) {
            log.warn("{}:[compareSmbFile] Возникла ошибка при попытке сравнения файлов исходного:{} и скопированного:{}", LG.USBLOGERROR, fileSource.getUncPath(), fileDestination.getUncPath());
            return false;
        }
    }


    /**
     * Получение списка файлов
     *
     * @param pathToSmb путь к файлу
     * @return - список файлов
     */
    public Optional<List<SmbFile>> getSmbFileList(String pathToSmb, CIFSContext cifsContext) {
        log.info("{}: Запущен процесс получения списка файлов в каталоге: {}, с CIFSContext", LG.USBLOGINFO, pathToSmb);
        try (SmbFile smbFile = new SmbFile(pathToSmb, cifsContext)) {
            SmbFile[] smbFiles = smbFile.listFiles();
            for (SmbFile smbFile1 : smbFiles) {
                log.debug("smbFile1.getUncPath() = {}", smbFile1.getUncPath());
            }
            return Optional.of(List.of(smbFiles));
        } catch (Exception e) {
            log.error("{}:getSmbFileList(String pathToSmb, CIFSContext cifsContext): Возникла ошибка при попытке получить список файлов в каталоге:{}, описание ошибки:{}", LG.USBLOGERROR, pathToSmb, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Получение списка файлов
     *
     * @param pathToSmb путь к файлу
     * @return - список файлов
     */
    public Optional<List<SmbFile>> getSmbFileList(String pathToSmb) {
        log.debug("{}: Запущен процесс получения списка файлов в каталоге: {}, без CIFSContext", LG.USBLOGINFO, pathToSmb);
        try (SmbFile smbFile = new SmbFile(pathToSmb, cifsContext)) {
            SmbFile[] smbFiles = smbFile.listFiles();
            for (SmbFile smbFile1 : smbFiles) {
                log.debug("smbFile1.getUncPath() = {}", smbFile1.getUncPath());
            }
            return Optional.of(List.of(smbFiles));
        } catch (Exception e) {
            log.error("{}: getSmbFileList(String pathToSmb): Возникла ошибка при попытке получить список файлов в каталоге:{}, описание ошибки:{}", LG.USBLOGERROR, pathToSmb, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Очистка каталога smbFileUrl
     */
    public void cleanSmbFileService() {

        LocalDate todayOut = LocalDate.now().minusDays(config.getOutFileOld()); //Текущая дата - 30 дней
        LocalDate todayErr = LocalDate.now().minusDays(config.getErrFileOld()); //Текущая дата - 30 дней

        //Проверка контекста
        if (cifsContext == null) {
            cifsContext = getCifsConfig();
        }
        //Ошибка подключения
        if (cifsContext == null) {
            log.error("{}:cleanSmbFileService: Возникла ошибка при попытке получить CIFSContext", LG.USBLOGERROR);
            return;
        }

        //Обрабатываем список файлов в каталоге out
        Optional<List<SmbFile>> getSmbFileList = getSmbFileList(config.getSmbFileUrl() + "out/", cifsContext);
        getSmbFileList.ifPresent(smbFiles -> smbFiles.forEach(smbFile1 -> {
            LocalDate localDate = convertLongToLocalDate(getLastFileAccess(smbFile1));
            if (todayOut.isAfter(localDate)) {
                if (deleteSmbFile(smbFile1)) {
                    log.info("{}:[out] cleanSmbFileService: Файл {} успешно удален", LG.USBLOGINFO, smbFile1.getUncPath());
                } else {
                    log.error("{}:[out] cleanSmbFileService: Ошибка при удалении файла {}", LG.USBLOGERROR, smbFile1.getUncPath());
                }
            }
        }));

        //Обрабатываем список файлов в каталоге err
        Optional<List<SmbFile>> getErrSmbFileList  = getSmbFileList(config.getSmbFileUrl() + "err/", cifsContext);
        getErrSmbFileList.ifPresent(smbFiles -> smbFiles.forEach(smbFile1 -> {
            LocalDate localDate = convertLongToLocalDate(getLastFileAccess(smbFile1));
            if (todayErr.isAfter(localDate)) {
                if (deleteSmbFile(smbFile1)) {
                    log.info("{}:[err] cleanSmbFileService: Файл {} успешно удален", LG.USBLOGINFO, smbFile1.getUncPath());
                } else {
                    log.error("{}:[err] cleanSmbFileService: Ошибка при удалении файла {}", LG.USBLOGERROR, smbFile1.getUncPath());
                }
            }
        }));
    }

    /**
     * Получение последнего доступа к файлу
     *
     * @param smbFile - файл
     * @return - время последнего доступа
     */
    public long getLastFileAccess(SmbFile smbFile) {
        try {
            return smbFile.lastAccess();
        } catch (SmbException e) {
            log.error("{}: Возникла ошибка при попытке получить дата - время доступа к файлу SMB:{} SMB Exception:{} ", LG.USBLOGERROR, smbFile.getUncPath(), e.getMessage());
            return 0;
        }
    }

    /**
     * Конвертация даты в локальную
     *
     * @param fileTime - тип данных в формате FileTime
     * @return - LocalDate
     */
    public LocalDate convertFileTimeToLocalDate(FileTime fileTime) {
        Instant instant = fileTime.toInstant();
        return instant.atZone(ZoneId.systemDefault()).toLocalDate();
    }


    /**
     * Конвертация даты в локальную
     * @param epochTimeMillis - тип данных в формате long
     * @return - LocalDate
     */
    public LocalDate convertLongToLocalDate(long epochTimeMillis) {
        Instant instant = Instant.ofEpochMilli(epochTimeMillis);
        ZoneId zoneId = ZoneId.systemDefault(); // Use the system default time zone
        return instant.atZone(zoneId).toLocalDateTime().toLocalDate();
    }

}
