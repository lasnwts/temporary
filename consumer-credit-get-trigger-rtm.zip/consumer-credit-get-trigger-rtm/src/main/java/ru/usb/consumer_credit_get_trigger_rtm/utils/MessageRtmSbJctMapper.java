package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.model.MessageToRtm;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrg;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class MessageRtmSbJctMapper {

    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    Logger log = LoggerFactory.getLogger(MessageRtmSbJctMapper.class);

    /**
     * Мапирование объекта
     *
     * @param csvSbJctTrg - объект для маппинга
     * @return - MessageToRtm
     */
    public MessageToRtm map(CsvSbJctTrg csvSbJctTrg) {
        MessageToRtm message = new MessageToRtm();
        message.setSource("OKB_event");
        message.setEventType("OKB_TRIGGER");
        message.setFileType("SBJCTTRG");
        message.setEventDateTime(dateFormater.format(new Date()));
        message.setExternalSubjectId(csvSbJctTrg.getExternalSubjectId()); //Пока неизвестно
        message.setPrimaryIdType(csvSbJctTrg.getPrimaryIdType()); //1
        message.setPrimaryIdNumber(csvSbJctTrg.getPrimaryIdNumber());//2
        message.setSurname(csvSbJctTrg.getSurname());//3
        message.setForename1(csvSbJctTrg.getForename1());//4
        message.setForename2(csvSbJctTrg.getForename2());//5
        message.setBirthDate(csvSbJctTrg.getBirthDate());//6
        message.setTotalOutstandingBalanceOld(csvSbJctTrg.getTotalOutstandingBalanceOld());//7
        message.setTotalOutstandingBalanceNew(csvSbJctTrg.getTotalOutstandingBalanceNew());//8
        message.setTotalMonthlyInstallmentOld(csvSbJctTrg.getTotalMonthlyInstallmentOld());//9
        message.setTotalMonthlyInstallmentNew(csvSbJctTrg.getTotalMonthlyInstallmentNew());//10
        message.setTotalCreditLimitOld(csvSbJctTrg.getTotalCreditLimitOld());//11
        message.setTotalCreditLimitNew(csvSbJctTrg.getTotalCreditLimitNew());//12
        message.setTotalArrearsBalanceOld(csvSbJctTrg.getTotalArrearsBalanceOld());//13
        message.setTotalArrearsBalanceNew(csvSbJctTrg.getTotalArrearsBalanceNew());//14
        message.setNoOfDelinqAcc1DOld(csvSbJctTrg.getNoOfDelinqAcc1DOld());//15
        message.setNoOfDelinqAcc1DNew(csvSbJctTrg.getNoOfDelinqAcc1DNew());//16
        message.setNoOfDelinqAcc30DOld(csvSbJctTrg.getNoOfDelinqAcc30DOld());//17
        message.setNoOfDelinqAcc30DNew(csvSbJctTrg.getNoOfDelinqAcc30DNew());//18
        message.setNoOfDelinqAcc60DOld(csvSbJctTrg.getNoOfDelinqAcc60DOld());//19
        message.setNoOfDelinqAcc60DNew(csvSbJctTrg.getNoOfDelinqAcc60DNew());//20
        message.setNoOfDelinqAcc90DOld(csvSbJctTrg.getNoOfDelinqAcc90DOld());//21
        message.setNoOfDelinqAcc90DNew(csvSbJctTrg.getNoOfDelinqAcc90DNew());//22
        message.setNoOfActiveCaisAccountOld(csvSbJctTrg.getNoOfActiveCaisAccountOld());//23
        message.setNoOfActiveCaisAccountNew(csvSbJctTrg.getNoOfActiveCaisAccountNew());//24
        message.setNoOfSubsKeepAccOld(csvSbJctTrg.getNoOfSubsKeepAccOld());//25
        message.setNoOfSubsKeepAccNew(csvSbJctTrg.getNoOfSubsKeepAccNew());//26
        message.setNoOfCapsRecPrev1M(csvSbJctTrg.getNoOfCapsRecPrev1M());//27
        message.setNoOfCapsRecPrev2M(csvSbJctTrg.getNoOfCapsRecPrev2M());//28
        message.setNoOfCapsRecPrev3M(csvSbJctTrg.getNoOfCapsRecPrev3M());//29
        message.setNoOfCapsRecPrev6M(csvSbJctTrg.getNoOfCapsRecPrev6M());//30
        message.setTriggerId(csvSbJctTrg.getTriggerId());//31
        message.setRunDate(csvSbJctTrg.getRunDate());//32
        return message;
    }
}
