package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.model.MessageToRtm;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrg;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Маппер для CsvAccNtTrg в MessageToRtm
 */
@Component
public class MessageRtmAccMapper {

    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    Logger log = LoggerFactory.getLogger(MessageRtmAccMapper.class);

    /**
     * Мапирование объекта
     * @param csvAccNtTrg - объект для маппинга
     * @return - MessageToRtm
     */
    public MessageToRtm map(CsvAccNtTrg csvAccNtTrg){
        MessageToRtm message = new MessageToRtm();
        message.setSource("OKB_event");
        message.setEventType("OKB_TRIGGER");
        message.setEventDateTime(dateFormater.format(new Date()));
        message.setFileType("ACCNTTRG");
        message.setExternalSubjectId(csvAccNtTrg.getExternalSubjectId()); //Пока неизвестно
        message.setPrimaryIdType(csvAccNtTrg.getPrimaryIdType());
        message.setPrimaryIdNumber(csvAccNtTrg.getPrimaryIdNumber());
        message.setSurname(csvAccNtTrg.getSurname());
        message.setForename1(csvAccNtTrg.getForename1());
        message.setForename2(csvAccNtTrg.getForename2());
        message.setBirthDate(csvAccNtTrg.getBirthDate());
        message.setTriggerId(csvAccNtTrg.getTriggerId());
        message.setSubscriberCode(csvAccNtTrg.getSubscriberCode());
        message.setSubscriberName(csvAccNtTrg.getSubscriberName());
        message.setTriggerCreationDate(csvAccNtTrg.getTriggerCreationDate());
        message.setOwnTriggerIndicator(csvAccNtTrg.getOwnTriggerIndicator());
        message.setTriggerDate(csvAccNtTrg.getTriggerDate());
        message.setStartDate(csvAccNtTrg.getStartDate());
        message.setClosedDate(csvAccNtTrg.getClosedDate());
        message.setApplicantType(csvAccNtTrg.getApplicantType());
        message.setFinanceProduct(csvAccNtTrg.getFinanceProduct());
        message.setAccountNumber(csvAccNtTrg.getAccountNumber());
        message.setCreditFacilityIndicator(csvAccNtTrg.getCreditFacilityIndicator());
        message.setSpecialStatus(csvAccNtTrg.getSpecialStatus());
        message.setFinancePurpose(csvAccNtTrg.getFinancePurpose());
        message.setFinanceAmount(csvAccNtTrg.getFinanceAmount());
        message.setCreditLimitOld(csvAccNtTrg.getCreditLimitOld());
        message.setCreditLimitNew(csvAccNtTrg.getCreditLimitNew());
        message.setDefaultDate(csvAccNtTrg.getDefaultDate());
        message.setLitigationDate(csvAccNtTrg.getLitigationDate());
        message.setWriteOffDate(csvAccNtTrg.getWriteOffDate());
        message.setLastPaymentDate(csvAccNtTrg.getLastPaymentDate());
        message.setOutstandingBalanceOld(csvAccNtTrg.getOutstandingBalanceOld());
        message.setOutstandingBalanceNew(csvAccNtTrg.getOutstandingBalanceNew());
        message.setScheduledPaymentAmountOld(csvAccNtTrg.getScheduledPaymentAmountOld());
        message.setScheduledPaymentAmountNew(csvAccNtTrg.getScheduledPaymentAmountNew());
        message.setArrearsAmountOld(csvAccNtTrg.getArrearsAmountOld());
        message.setArrearsAmountNew(csvAccNtTrg.getArrearsAmountNew());
        message.setPaymentStatusOld(csvAccNtTrg.getPaymentStatusOld());
        message.setPaymentStatusNew(csvAccNtTrg.getPaymentStatusNew());
        message.setCurrencyCode(csvAccNtTrg.getCurrencyCode());
        message.setPostcode(csvAccNtTrg.getPostcode());
        message.setRegionCode(csvAccNtTrg.getRegionCode());
        message.setEnquiryReasonCode(csvAccNtTrg.getEnquiryReasonCode());
        return message;
    }

}
