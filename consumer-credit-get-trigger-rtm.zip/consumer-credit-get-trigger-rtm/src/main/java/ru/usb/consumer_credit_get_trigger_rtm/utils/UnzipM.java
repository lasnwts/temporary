package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.service.mail.ServiceMailError;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Component
public class UnzipM {

    private final ServiceMailError serviceMailError;
    private final Config config;

    @Autowired
    public UnzipM(ServiceMailError serviceMailError, Config config) {
        this.serviceMailError = serviceMailError;
        this.config = config;
    }

    Logger log = LoggerFactory.getLogger(UnzipM.class);

    /**
     * Метод распаковки архива ZIP
     * //        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), Charset.forName("windows-1251"))
     *
     * @param fileZip       - файл который надо распаковать (полный путь с именем)
     * @throws IOException - исключение ввода-вывода
     */
    public Optional<List<Path>> unzipFile(String fileZip, String directoryName) throws Exception {
        log.info("{}: Распаковка архива => ZipApi.UnzipFile file:{} в каталог:{}", LG.USBLOGINFO, fileZip, directoryName);
        File destDir = new File(directoryName);
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), StandardCharsets.UTF_8);
        FileOutputStream fos = null;
        ZipEntry zipEntry;
        File newFile = null;
        File parent = null;
        try {
            zipEntry = zis.getNextEntry();
            while (zipEntry != null) {
                newFile = newFile(destDir, zipEntry);
                if (zipEntry.isDirectory()) {
                    if (!newFile.isDirectory() && !newFile.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + newFile);
                    }
                } else {
                    // fix for Windows-created archives
                    parent = newFile.getParentFile();
                    if (!parent.isDirectory() && !parent.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + parent);
                    }
                    // write file content
                    fos = new FileOutputStream(newFile);
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.close();
                }
                zipEntry = zis.getNextEntry();
            }
            zis.closeEntry();
            zis.close();
        } catch (Exception e) {
            String error = "Ошибка при распаковке архива:" + fileZip + " в каталог:" + directoryName + "Error:" + e.getMessage();
            try {
                zis.closeEntry();
            } catch (Exception e2) {
                log.error("{}:Ошибка при закрытии потоков[zis.closeEntry()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            try {
                zis.close();
            } catch (Exception e2) {
                log.error("{}:Ошибка при закрытии потоков[zis.close()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            log.error("{}:Ошибка при распаковке архива:{}Error:{}", LG.USBLOGERROR, fileZip, e.getMessage());
            if (zis != null) {
                zis.close();
            }
            if (fos != null) {
                fos.close();
            }
            if (newFile != null) {
                Files.deleteIfExists(newFile.toPath());
            }
            if (parent != null) {
                Files.deleteIfExists(parent.toPath());
            }
            if (destDir != null) {
                Files.deleteIfExists(destDir.toPath());
            }
            throw new Exception(error); //Передаем прерывание
        }
        log.info("{}: Распаковка архива завершена => ZipApi.UnzipFile file:{} в каталог:{}", LG.USBLOGINFO, fileZip, directoryName);
        Thread.sleep(200);
        Files.deleteIfExists(Paths.get(fileZip));
        try (Stream<Path> list = Files.find(Paths.get(directoryName), Integer.MAX_VALUE, (filePath, fileAttr) -> fileAttr.isRegularFile() || fileAttr.isDirectory())) {
            return Optional.of(list.collect(Collectors.toList()));
        } catch (IOException e) {
            log.error("{}:Ошибка при построении списка распакованных файлов в каталоге:{}Error:{}", LG.USBLOGERROR, directoryName, e.getMessage());
            return Optional.empty();
        }
    }


    /**
     * Вспомогательный класс.
     * Этот метод защищает от записи файлов в файловую систему вне целевой папки. Эта уязвимость называется ZipApi Slip,
     * почитать об этой уязвимости https://snyk.io/research/zip-slip-vulnerability
     *
     * @param destinationDir - Файл архива, с полным именем
     * @param zipEntry       - каталог (сетевая папка) куда будет распакован архив
     * @return - File (путь к файлу)
     * @throws IOException - исключение ввода-вывода
     */
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }
        return destFile;
    }

    /**
     * Распаковка файла
     *
     * @param file - файл
     * @return - список файлов
     */
    public Optional<List<Path>> unzipFileWrap(File file) {
        try {
            Optional<List<Path>> pathList = unzipFile(file.getAbsolutePath(), getPath().toString());
            if (pathList.isPresent()) {
                log.info("{}: File {} unzipped to {}", LG.USBLOGINFO, file.getAbsolutePath(), pathList);
            } else {
                log.error("{}: File {} not unzipped. Каталог пустой!", LG.USBLOGERROR, file.getAbsolutePath());
                serviceMailError.sendMailErrorSubject("Ошибка распаковки файла", "Ошибка распаковки файла."
                        + "\n Имя файла: " + file.getName() + "\n"
                        + "\n Дата : " + formatDateTime(new Date()) + "\n"
                        + "\n Сообщение об ошибке: После распаковки => Каталог пустой!");
                Files.deleteIfExists(file.toPath());
                cleanTempDirectory();
                return Optional.empty();
            }
            return pathList; //отдаем список
        } catch (Exception e) {
            log.error("{}: Error unzipping file: {}", LG.USBLOGERROR, e.getMessage());
            serviceMailError.sendMailErrorSubject("Ошибка распаковки файла", "Ошибка распаковки файла."
                    + "\n Имя файла: " + file.getName() + "\n"
                    + "\n Дата : " + formatDateTime(new Date()) + "\n"
                    + "\n Сообщение об ошибке: ошибка при разархивации файла");
            try {
                Files.deleteIfExists(file.toPath());
                cleanTempDirectory();
            } catch (IOException ex) {
                log.error("{}: Error deleting file: {}", LG.USBLOGERROR, ex.getMessage());
            }
            return Optional.empty();
        }
    }

    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Очистка директории
     */
    public void cleanTempDirectory() {
        try {
            FileUtils.cleanDirectory(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + config.getNetFileShare()).toFile());
        } catch (Exception e) {
            log.error("{}:Support.cleanTempDirectory:Ошибка при удалении директории {}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Получить путь к временной папке
     *
     * @return - путь к файлу
     */
    public Path getPath(){
        return Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare());
    }

}
