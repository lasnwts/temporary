package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.check.CheckCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;
import ru.usb.consumer_credit_get_trigger_rtm.service.ems.SendExecutors;
import ru.usb.consumer_credit_get_trigger_rtm.utils.CsvAccNtTrgMapper;
import ru.usb.consumer_credit_get_trigger_rtm.utils.Support;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Service
public class LoadAccNtTrgFile {

    private final Config config;
    private final CsvAccNtTrgHeadMap csvAccNtTrgHeadMap;
    private final Support support;
    private final CsvAccNtTrgMapper csvAccNtTrgMapper;
    private final SendExecutors sendExecutors;


    Logger log = LoggerFactory.getLogger(LoadAccNtTrgFile.class);

    public LoadAccNtTrgFile(Config config, CsvAccNtTrgHeadMap csvAccNtTrgHeadMap, Support support, CsvAccNtTrgMapper csvAccNtTrgMapper, SendExecutors sendExecutors) {
        this.config = config;
        this.csvAccNtTrgHeadMap = csvAccNtTrgHeadMap;
        this.support = support;
        this.csvAccNtTrgMapper = csvAccNtTrgMapper;
        this.sendExecutors = sendExecutors;
    }

    public List<LoadError> loadFile(File file, long thread) throws Exception {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadAccNtTrgFile, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }


        log.info("{}:T{}: Подготовка процесса: Load LoadAccNtTrgFile к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), support.formatDateTime(new Date()));
        AtomicReference<CsvAccNtTrgHeadPosition> accNtTrgHeadPositionAtomicReference = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadAccNtTrgFile, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                accNtTrgHeadPositionAtomicReference.set(csvAccNtTrgHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckCsvAccNtTrg checkCsvAccNtTrg = csvAccNtTrgMapper.map(line.trim(), accNtTrgHeadPositionAtomicReference.get(), file.getName(), count.get());
                                config.incrementThreads();
                                sendExecutors.getTask(checkCsvAccNtTrg.getCsvAccNtTrg().toString());
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadAccNtTrgFile, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
            throw new IOException(e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadAccNtTrgFile. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }


}
