package ru.usb.consumer_credit_get_trigger_rtm.service.smb;


/**
 * Ошибка при загрузке файла
 */
public class InvalidFileException extends Exception{
    public InvalidFileException(String message) {
        super(message);
    }
}
