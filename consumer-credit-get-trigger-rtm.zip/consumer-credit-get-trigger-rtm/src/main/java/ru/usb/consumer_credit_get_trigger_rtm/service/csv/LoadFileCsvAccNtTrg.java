package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.check.CheckCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;
import ru.usb.consumer_credit_get_trigger_rtm.service.ems.SendExecutors;
import ru.usb.consumer_credit_get_trigger_rtm.service.ems.SenderService;
import ru.usb.consumer_credit_get_trigger_rtm.utils.CsvAccNtTrgMapper;
import ru.usb.consumer_credit_get_trigger_rtm.utils.MessageRtmAccMapper;
import ru.usb.consumer_credit_get_trigger_rtm.utils.Support;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
public class LoadFileCsvAccNtTrg {

    private final SendExecutors sendExecutors;
    private final Support support;
    private final CsvAccNtTrgMapper csvAccNtTrgMapper;
    private final SenderService senderService;
    private final MessageRtmAccMapper messageRtmAccMapper;
    private final Config config;

    Logger log = LoggerFactory.getLogger(LoadFileCsvAccNtTrg.class);

    @Autowired
    public LoadFileCsvAccNtTrg(SendExecutors sendExecutors, Support support, CsvAccNtTrgMapper csvAccNtTrgMapper,
                               SenderService senderService, MessageRtmAccMapper messageRtmAccMapper, Config config) {
        this.sendExecutors = sendExecutors;
        this.support = support;
        this.csvAccNtTrgMapper = csvAccNtTrgMapper;
        this.senderService = senderService;
        this.messageRtmAccMapper = messageRtmAccMapper;
        this.config = config;
    }

    /**
     * Загрузка данных из файла
     *
     * @param file                    - файл для загрузки
     * @param fileName                - имя файла
     * @param csvAccNtTrgHeadPosition - заголовок файла
     * @param thread                  - номер потока
     * @return - список ошибок
     */
    public List<LoadError> loadFile(File file, String fileName, CsvAccNtTrgHeadPosition csvAccNtTrgHeadPosition, long thread, boolean smbFlag) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (file == null || !file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadAccNtTrgFile, переданный Файл:{} не существует, равен NULL", LG.USBLOGERROR, fileName, thread);
            loadErrorList.add(new LoadError(0, fileName, "Файл  - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        log.info("{}:T{}: Подготовка процесса: Load LoadAccNtTrgFile к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), support.formatDateTime(new Date()));
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadAccNtTrgFile, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));

        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            count.set(0);
            final AtomicInteger countGc = new AtomicInteger();
            lines.forEach(line -> {
                        countGc.incrementAndGet(); //+1 на каждую строку
                        if (countGc.get() > 20000) {
                            log.info("{}:T{}: Обработано в процессе: LoadAccNtTrgFile, количество записей={}", LG.USBLOGINFO, thread, count.get());
                            System.gc();
                            countGc.set(0);
                        }
                        try {
                            CheckCsvAccNtTrg checkCsvAccNtTrg = csvAccNtTrgMapper.map(line.trim(), csvAccNtTrgHeadPosition, file.getName(), count.get());
                            if (checkCsvAccNtTrg != null && checkCsvAccNtTrg.getCsvAccNtTrg() != null && checkCsvAccNtTrg.getLoadError() != null
                                    && checkCsvAccNtTrg.getCsvAccNtTrg().getSubscriberCode() != null
                                    && !checkCsvAccNtTrg.getCsvAccNtTrg().getSubscriberCode().equalsIgnoreCase("SUBSCRIBER_CODE")
                                    && checkCsvAccNtTrg.isExists() && !checkCsvAccNtTrg.getLoadError().isStatus()) {
                                //true - много потоковый вариант
                                if (config.isServiceMultiThreadEnabled()) {
                                    sendExecutors.getTask(messageRtmAccMapper.map(checkCsvAccNtTrg.getCsvAccNtTrg()).toCSV());
                                } else {
                                    senderService.sendMessage(messageRtmAccMapper.map(checkCsvAccNtTrg.getCsvAccNtTrg()).toCSV(), Thread.currentThread().getId());
                                }
                                count.incrementAndGet(); //+1 на каждую строку
                            }
                            if (checkCsvAccNtTrg != null && checkCsvAccNtTrg.getLoadError() != null && checkCsvAccNtTrg.getLoadError().isStatus()){
                                loadErrorList.add(checkCsvAccNtTrg.getLoadError());
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadAccNtTrgFile, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
        }

        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadAccNtTrgFile. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        //Удаляем временный файл
        if (smbFlag) {
            delFile(file);
        }
        return loadErrorList;
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     * @return - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(10);
            if (Files.deleteIfExists(facFile.toPath())) {
                log.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, facFile.getAbsolutePath());
            } else {
                log.info("{}: Файл:{} не был удален из временной директории!", LG.USBLOGINFO, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            log.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.USBLOGERROR, facFile.getAbsolutePath(), e.getMessage());
            log.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            Thread.currentThread().interrupt();
        }
    }
}
