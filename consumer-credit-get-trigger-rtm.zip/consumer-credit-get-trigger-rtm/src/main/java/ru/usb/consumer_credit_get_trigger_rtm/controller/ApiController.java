package ru.usb.consumer_credit_get_trigger_rtm.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;
import ru.usb.consumer_credit_get_trigger_rtm.service.ApiLayer;
import ru.usb.consumer_credit_get_trigger_rtm.service.FlowFileOperation;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@Tag(name = "Контроллер ввода данных", description = "Установка даты, получение отчета")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);
    private final ApiLayer apiLayer;
    private final FlowFileOperation flowFileOperation;

    @Autowired
    public ApiController(ApiLayer apiLayer, FlowFileOperation flowFileOperation) {
        this.apiLayer = apiLayer;
        this.flowFileOperation = flowFileOperation;
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        apiLayer.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (apiLayer.getServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    @PostMapping(value = "/upload", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Отправка файла на обработку для RTM. Выберите файл для загрузки на сервер.", description = "Выберите файл для загрузки.")
    public ResponseEntity<Map<String, String>> upload(
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        logger.info("{}: Поступил запрос на загрузку файла:{}, размером:{} на сервер.", LG.USBLOGINFO, files.getOriginalFilename(), files.getSize());
        try {
            File file = apiLayer.upload(files.getOriginalFilename(), files.getBytes());
            List<LoadError> loadErrors = flowFileOperation.processedFile(file);
            if (loadErrors.isEmpty()) {
                result.put("message", "Файл загружен на сервер, но содержит ошибки");
            } else {
                if (loadErrors.get(0).isStatus()) {
                    result.put("error", "Ошибка при загрузке файла:" +loadErrors.get(0).getFileName() + ". Описание ошибки:" + loadErrors.get(0).getErrorMessage());
                } else {
                    result.put("message", "Файл :" + loadErrors.get(0).getFileName() + " успешно обработан.");
                }

            }
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            logger.error("{}: Произошла ошибка, при отправке файла в FTPS:{}", LG.USBLOGERROR, e.getMessage());
            logger.debug("{}: Stack trace, при отправке файла в FTPS:", LG.USBLOGERROR, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }


}
