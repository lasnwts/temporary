package ru.usb.consumer_credit_get_trigger_rtm.service.ems;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;


/**
 * Cервис передачи в ActiveMq
 */

@Service
public class SenderService {

    Logger logger = LoggerFactory.getLogger(SenderService.class);


    private JmsTemplate jmsTemplate;

    @Autowired
    public SenderService(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    @Value("${tibco.queue.rtm}")
    private String queueTibco;

    /**
     * Convert and publish the message to the queue
     *
     * @param body - сообщение
     */
    public void sendMessage(String body, long thread) {
        if (body==null || body.isEmpty()){
            return;
        }
        try {
//            jmsTemplate.convertAndSend(queueTibco, body);
            logger.debug("{}: EMS:Producer:Thread={}, send to queue={}, message={}", LG.USBLOGINFO, thread, queueTibco, body);
        } catch (Exception e){
            logger.error("{}:Ошибка отправки сообщения по EMS:Thread={}, send to queue={}, message={}", LG.USBLOGERROR, thread, queueTibco, body);
        }
    }
}
