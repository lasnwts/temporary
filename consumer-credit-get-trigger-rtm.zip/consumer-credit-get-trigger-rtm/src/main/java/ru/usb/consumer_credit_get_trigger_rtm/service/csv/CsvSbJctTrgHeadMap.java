package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrgHeadPosition;


/**
 * PRIMARY_ID_TYPE
 * PRIMARY_ID_NUMBER
 * SURNAME
 * FORENAME1
 * FORENAME2
 * BIRTH_DATE
 * TOTAL_OUTSTANDING_BALANCE_OLD
 * TOTAL_OUTSTANDING_BALANCE_NEW
 * TOTAL_MONTHLY_INSTALLMENT_OLD
 * TOTAL_MONTHLY_INSTALLMENT_NEW
 * TOTAL_CREDIT_LIMIT_OLD
 * TOTAL_CREDIT_LIMIT_NEW
 * TOTAL_ARREARS_BALANCE_OLD
 * TOTAL_ARREARS_BALANCE_NEW
 * WORST_CURRENT_PAYMENT_STATUS_OLD
 * WORST_CURRENT_PAYMENT_STATUS_NEW
 * NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD
 * NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW
 * NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD
 * NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW
 * NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD
 * NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW
 * NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD
 * NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW
 * NO_OF_ACTIVE_CAIS_ACCOUNT_OLD
 * NO_OF_ACTIVE_CAIS_ACCOUNT_NEW
 * NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_OLD
 * NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_NEW
 * NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_1_MONTH
 * NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_2_MONTH
 * NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_3_MONTH
 * NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_6_MONTH
 * TRIGGER_ID
 * RUN_DATE
 */

@Component
public class CsvSbJctTrgHeadMap {
    private static final String COMMA_DELIMITER = ",";


    /**
     * Маппинг строки в объект
     *
     * @param line - строка из файла с заголовками
     * @return - объект CsvSbJctTrgHeadPosition
     */
    public CsvSbJctTrgHeadPosition map(String line) {

        CsvSbJctTrgHeadPosition csvSbJctTrgHeadPosition = new CsvSbJctTrgHeadPosition();
        String[] values = line.split(COMMA_DELIMITER);

        if (values.length == 0) {
            csvSbJctTrgHeadPosition.setTitlePresent(false);
            return csvSbJctTrgHeadPosition;
        }

        //1
        csvSbJctTrgHeadPosition.setPrimaryIdType(getPosition("PRIMARY_ID_TYPE", values));
        //2
        csvSbJctTrgHeadPosition.setPrimaryIdNumber(getPosition("PRIMARY_ID_NUMBER", values));
        //3
        csvSbJctTrgHeadPosition.setSurname(getPosition("SURNAME", values));
        //4
        csvSbJctTrgHeadPosition.setForename1(getPosition("FORENAME1", values));
        //5
        csvSbJctTrgHeadPosition.setForename2(getPosition("FORENAME2", values));
        //6
        csvSbJctTrgHeadPosition.setBirthDate(getPosition("BIRTH_DATE", values));
        //7
        csvSbJctTrgHeadPosition.setTotalOutstandingBalanceOld(getPosition("TOTAL_OUTSTANDING_BALANCE_OLD", values));
        //8
        csvSbJctTrgHeadPosition.setTotalOutstandingBalanceNew(getPosition("TOTAL_OUTSTANDING_BALANCE_NEW", values));
        //9
        csvSbJctTrgHeadPosition.setTotalMonthlyInstallmentOld(getPosition("TOTAL_MONTHLY_INSTALLMENT_OLD", values));
        //10
        csvSbJctTrgHeadPosition.setTotalMonthlyInstallmentNew(getPosition("TOTAL_MONTHLY_INSTALLMENT_NEW", values));
        //11
        csvSbJctTrgHeadPosition.setTotalCreditLimitOld(getPosition("TOTAL_CREDIT_LIMIT_OLD", values));
        //12
        csvSbJctTrgHeadPosition.setTotalCreditLimitNew(getPosition("TOTAL_CREDIT_LIMIT_NEW", values));
        //13
        csvSbJctTrgHeadPosition.setTotalArrearsBalanceOld(getPosition("TOTAL_ARREARS_BALANCE_OLD", values));
        //14
        csvSbJctTrgHeadPosition.setTotalArrearsBalanceNew(getPosition("TOTAL_ARREARS_BALANCE_NEW", values));
        //15
        csvSbJctTrgHeadPosition.setWorstCurrentPaymentStatusOld(getPosition("WORST_CURRENT_PAYMENT_STATUS_OLD", values));
        //16
        csvSbJctTrgHeadPosition.setWorstCurrentPaymentStatusNew(getPosition("WORST_CURRENT_PAYMENT_STATUS_NEW", values));
        //17
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc1DOld(getPosition("NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD", values));
        //18
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc1DNew(getPosition("NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW", values));
        //19
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc30DOld(getPosition("NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD", values));
        //20
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc30DNew(getPosition("NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW", values));
        //21
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc60DOld(getPosition("NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD", values));
        //22
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc60DNew(getPosition("NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW", values));
        //23
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc90DOld(getPosition("NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD", values));
        //24
        csvSbJctTrgHeadPosition.setNoOfDelinqAcc90DNew(getPosition("NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW", values));
        //25
        csvSbJctTrgHeadPosition.setNoOfActiveCaisAccountOld(getPosition("NO_OF_ACTIVE_CAIS_ACCOUNT_OLD", values));
        //26
        csvSbJctTrgHeadPosition.setNoOfActiveCaisAccountNew(getPosition("NO_OF_ACTIVE_CAIS_ACCOUNT_NEW", values));
        //27
        csvSbJctTrgHeadPosition.setNoOfSubsKeepAccOld(getPosition("NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_OLD", values));
        //28
        csvSbJctTrgHeadPosition.setNoOfSubsKeepAccNew(getPosition("NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_NEW", values));
        //29
        csvSbJctTrgHeadPosition.setNoOfCapsRecPrev1M(getPosition("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_1_MONTH", values));
        //30
        csvSbJctTrgHeadPosition.setNoOfCapsRecPrev2M(getPosition("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_2_MONTH", values));
        //31
        csvSbJctTrgHeadPosition.setNoOfCapsRecPrev3M(getPosition("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_3_MONTH", values));
        //32
        csvSbJctTrgHeadPosition.setNoOfCapsRecPrev6M(getPosition("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_6_MONTH", values));
        //33
        csvSbJctTrgHeadPosition.setTriggerId(getPosition("TRIGGER_ID", values));
        //34
        csvSbJctTrgHeadPosition.setRunDate(getPosition("RUN_DATE", values));
        //35
        csvSbJctTrgHeadPosition.setExternalSubjectId(getPosition("EXTERNAL_SUBJECT_ID", values));
        //
        csvSbJctTrgHeadPosition.setTitlePresent(true);
        return csvSbJctTrgHeadPosition;
    }


    /**
     * Получение позиции
     *
     * @param key    - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values) {

        for (int i = 0; i < values.length; i++) {
            if (values[i].equalsIgnoreCase(key)) {
                return i;
            }
        }
        return -1;
    }

}
