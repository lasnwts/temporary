package ru.usb.consumer_credit_get_trigger_rtm.service.ems;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;


import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;


@Service
public class SendExecutors {

    private final Config configure;
    private final SenderService senderService;

    Logger log = LoggerFactory.getLogger(SendExecutors.class);

    @Autowired
    public SendExecutors(Config configure, SenderService senderService) {
        this.configure = configure;
        this.senderService = senderService;
    }

    /**
     * инициализация: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String body) {

        log.debug("{}:T{}: Запуск getTask потока копирования файла, с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), body);
        log.debug("{}:T{}: getTask:Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        try {
            executorService.execute(new MyThread(body));
        } catch (Exception e) {
            log.error("{}:T{}: Error:executorService.execute(new MyThread(String reportFileName))::{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
            log.debug("{}:T{}: STACK Error:executorService.execute(new MyThread(String reportFileName))::", LG.USBLOGERROR, Thread.currentThread().getId(), e);
        }
    }

    class MyThread implements Runnable {
        String message;

        MyThread(String body) {
            message = body;
            new Thread(this);
        }

        public void run() {
            senderService.sendMessage(message, Thread.currentThread().getId());
            //Подвал нормального завершения потока
            log.debug("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.decrementThreads();
            log.debug("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }
    }
}
