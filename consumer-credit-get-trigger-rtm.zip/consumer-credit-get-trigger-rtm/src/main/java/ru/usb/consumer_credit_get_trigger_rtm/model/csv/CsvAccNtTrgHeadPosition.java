package ru.usb.consumer_credit_get_trigger_rtm.model.csv;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Класс для хранения позиции в файле
 */
public class CsvAccNtTrgHeadPosition {

    //1
    private int subscriberCode;

    //2
    private int subscriberName;

    //3
    private int primaryIdType;

    //4
    private int primaryIdNumber;

    //5
    private int surname;

    //6
    private int forename1;

    //7
    private int forename2;

    //8
    private int birthDate;

    //9
    private int triggerId;

    //10
    private int triggerCreationDate;

    //11
    private int ownTriggerIndicator;

    //12
    private int triggerDate;

    //13
    private int startDate;

    //14
    private int closedDate;

    //15
    private int applicantType;

    //16
    private int financeProduct;

    //17
    private int accountNumber;

    //18
    private int creditFacilityIndicator;

    //19
    private int specialStatus;

    //20
    private int financePurpose;

    //21
    private int financeAmount;

    //22
    private int creditLimitOld;

    //23
    private int creditLimitNew;

    //24
    private int defaultDate;

    //25
    private int litigationDate;

    //26
    private int writeOffDate;

    //27
    private int lastPaymentDate;

    //28
    private int outstandingBalanceOld;

    //29
    private int outstandingBalanceNew;

    //30
    private int scheduledPaymentAmountOld;

    //31
    private int scheduledPaymentAmountNew;

    //32
    private int arrearsAmountOld;

    //33
    private int arrearsAmountNew;

    //34
    private int paymentStatusOld;

    //35
    private int paymentStatusNew;

    //36
    private int currencyCode;

    //37
    private int postcode;

    //38
    private int regionCode;

    //39
    private int enquiryReasonCode;

    //40
    private int externalSubjectId;

    //Наличие заголовка
    private boolean titlePresent;

    public CsvAccNtTrgHeadPosition() {
        //empty
    }

    public CsvAccNtTrgHeadPosition(int subscriberCode, int subscriberName, int primaryIdType, int primaryIdNumber,
                                   int surname, int forename1, int forename2, int birthDate, int triggerId,
                                   int triggerCreationDate, int ownTriggerIndicator, int triggerDate,
                                   int startDate, int closedDate, int applicantType, int financeProduct,
                                   int accountNumber, int creditFacilityIndicator, int specialStatus, int financePurpose,
                                   int financeAmount, int creditLimitOld, int creditLimitNew, int defaultDate, int litigationDate,
                                   int writeOffDate, int lastPaymentDate, int outstandingBalanceOld, int outstandingBalanceNew,
                                   int scheduledPaymentAmountOld, int scheduledPaymentAmountNew, int arrearsAmountOld, int arrearsAmountNew,
                                   int paymentStatusOld, int paymentStatusNew, int currencyCode, int postcode, int regionCode,
                                   int enquiryReasonCode, boolean titlePresent) {
        this.subscriberCode = subscriberCode;
        this.subscriberName = subscriberName;
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.triggerId = triggerId;
        this.triggerCreationDate = triggerCreationDate;
        this.ownTriggerIndicator = ownTriggerIndicator;
        this.triggerDate = triggerDate;
        this.startDate = startDate;
        this.closedDate = closedDate;
        this.applicantType = applicantType;
        this.financeProduct = financeProduct;
        this.accountNumber = accountNumber;
        this.creditFacilityIndicator = creditFacilityIndicator;
        this.specialStatus = specialStatus;
        this.financePurpose = financePurpose;
        this.financeAmount = financeAmount;
        this.creditLimitOld = creditLimitOld;
        this.creditLimitNew = creditLimitNew;
        this.defaultDate = defaultDate;
        this.litigationDate = litigationDate;
        this.writeOffDate = writeOffDate;
        this.lastPaymentDate = lastPaymentDate;
        this.outstandingBalanceOld = outstandingBalanceOld;
        this.outstandingBalanceNew = outstandingBalanceNew;
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
        this.arrearsAmountOld = arrearsAmountOld;
        this.arrearsAmountNew = arrearsAmountNew;
        this.paymentStatusOld = paymentStatusOld;
        this.paymentStatusNew = paymentStatusNew;
        this.currencyCode = currencyCode;
        this.postcode = postcode;
        this.regionCode = regionCode;
        this.enquiryReasonCode = enquiryReasonCode;
        this.titlePresent = titlePresent;
    }

    public CsvAccNtTrgHeadPosition(int subscriberCode, int subscriberName, int primaryIdType, int primaryIdNumber,
                                   int surname, int forename1, int forename2, int birthDate, int triggerId,
                                   int triggerCreationDate, int ownTriggerIndicator, int triggerDate, int startDate,
                                   int closedDate, int applicantType, int financeProduct, int accountNumber,
                                   int creditFacilityIndicator, int specialStatus, int financePurpose, int financeAmount,
                                   int creditLimitOld, int creditLimitNew, int defaultDate, int litigationDate,
                                   int writeOffDate, int lastPaymentDate, int outstandingBalanceOld, int outstandingBalanceNew,
                                   int scheduledPaymentAmountOld, int scheduledPaymentAmountNew, int arrearsAmountOld,
                                   int arrearsAmountNew, int paymentStatusOld, int paymentStatusNew, int currencyCode, int postcode,
                                   int regionCode, int enquiryReasonCode, int externalSubjectId, boolean titlePresent) {
        this.subscriberCode = subscriberCode;
        this.subscriberName = subscriberName;
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.triggerId = triggerId;
        this.triggerCreationDate = triggerCreationDate;
        this.ownTriggerIndicator = ownTriggerIndicator;
        this.triggerDate = triggerDate;
        this.startDate = startDate;
        this.closedDate = closedDate;
        this.applicantType = applicantType;
        this.financeProduct = financeProduct;
        this.accountNumber = accountNumber;
        this.creditFacilityIndicator = creditFacilityIndicator;
        this.specialStatus = specialStatus;
        this.financePurpose = financePurpose;
        this.financeAmount = financeAmount;
        this.creditLimitOld = creditLimitOld;
        this.creditLimitNew = creditLimitNew;
        this.defaultDate = defaultDate;
        this.litigationDate = litigationDate;
        this.writeOffDate = writeOffDate;
        this.lastPaymentDate = lastPaymentDate;
        this.outstandingBalanceOld = outstandingBalanceOld;
        this.outstandingBalanceNew = outstandingBalanceNew;
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
        this.arrearsAmountOld = arrearsAmountOld;
        this.arrearsAmountNew = arrearsAmountNew;
        this.paymentStatusOld = paymentStatusOld;
        this.paymentStatusNew = paymentStatusNew;
        this.currencyCode = currencyCode;
        this.postcode = postcode;
        this.regionCode = regionCode;
        this.enquiryReasonCode = enquiryReasonCode;
        this.externalSubjectId = externalSubjectId;
        this.titlePresent = titlePresent;
    }

    public int getSubscriberCode() {
        return subscriberCode;
    }

    public void setSubscriberCode(int subscriberCode) {
        this.subscriberCode = subscriberCode;
    }

    public int getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(int subscriberName) {
        this.subscriberName = subscriberName;
    }

    public int getPrimaryIdType() {
        return primaryIdType;
    }

    public void setPrimaryIdType(int primaryIdType) {
        this.primaryIdType = primaryIdType;
    }

    public int getPrimaryIdNumber() {
        return primaryIdNumber;
    }

    public void setPrimaryIdNumber(int primaryIdNumber) {
        this.primaryIdNumber = primaryIdNumber;
    }

    public int getSurname() {
        return surname;
    }

    public void setSurname(int surname) {
        this.surname = surname;
    }

    public int getForename1() {
        return forename1;
    }

    public void setForename1(int forename1) {
        this.forename1 = forename1;
    }

    public int getForename2() {
        return forename2;
    }

    public void setForename2(int forename2) {
        this.forename2 = forename2;
    }

    public int getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(int birthDate) {
        this.birthDate = birthDate;
    }

    public int getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(int triggerId) {
        this.triggerId = triggerId;
    }

    public int getTriggerCreationDate() {
        return triggerCreationDate;
    }

    public void setTriggerCreationDate(int triggerCreationDate) {
        this.triggerCreationDate = triggerCreationDate;
    }

    public int getOwnTriggerIndicator() {
        return ownTriggerIndicator;
    }

    public void setOwnTriggerIndicator(int ownTriggerIndicator) {
        this.ownTriggerIndicator = ownTriggerIndicator;
    }

    public int getTriggerDate() {
        return triggerDate;
    }

    public void setTriggerDate(int triggerDate) {
        this.triggerDate = triggerDate;
    }

    public int getStartDate() {
        return startDate;
    }

    public void setStartDate(int startDate) {
        this.startDate = startDate;
    }

    public int getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(int closedDate) {
        this.closedDate = closedDate;
    }

    public int getApplicantType() {
        return applicantType;
    }

    public void setApplicantType(int applicantType) {
        this.applicantType = applicantType;
    }

    public int getFinanceProduct() {
        return financeProduct;
    }

    public void setFinanceProduct(int financeProduct) {
        this.financeProduct = financeProduct;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getCreditFacilityIndicator() {
        return creditFacilityIndicator;
    }

    public void setCreditFacilityIndicator(int creditFacilityIndicator) {
        this.creditFacilityIndicator = creditFacilityIndicator;
    }

    public int getSpecialStatus() {
        return specialStatus;
    }

    public void setSpecialStatus(int specialStatus) {
        this.specialStatus = specialStatus;
    }

    public int getFinancePurpose() {
        return financePurpose;
    }

    public void setFinancePurpose(int financePurpose) {
        this.financePurpose = financePurpose;
    }

    public int getFinanceAmount() {
        return financeAmount;
    }

    public void setFinanceAmount(int financeAmount) {
        this.financeAmount = financeAmount;
    }

    public int getCreditLimitOld() {
        return creditLimitOld;
    }

    public void setCreditLimitOld(int creditLimitOld) {
        this.creditLimitOld = creditLimitOld;
    }

    public int getCreditLimitNew() {
        return creditLimitNew;
    }

    public void setCreditLimitNew(int creditLimitNew) {
        this.creditLimitNew = creditLimitNew;
    }

    public int getDefaultDate() {
        return defaultDate;
    }

    public void setDefaultDate(int defaultDate) {
        this.defaultDate = defaultDate;
    }

    public int getLitigationDate() {
        return litigationDate;
    }

    public void setLitigationDate(int litigationDate) {
        this.litigationDate = litigationDate;
    }

    public int getWriteOffDate() {
        return writeOffDate;
    }

    public void setWriteOffDate(int writeOffDate) {
        this.writeOffDate = writeOffDate;
    }

    public int getLastPaymentDate() {
        return lastPaymentDate;
    }

    public void setLastPaymentDate(int lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    public int getOutstandingBalanceOld() {
        return outstandingBalanceOld;
    }

    public void setOutstandingBalanceOld(int outstandingBalanceOld) {
        this.outstandingBalanceOld = outstandingBalanceOld;
    }

    public int getOutstandingBalanceNew() {
        return outstandingBalanceNew;
    }

    public void setOutstandingBalanceNew(int outstandingBalanceNew) {
        this.outstandingBalanceNew = outstandingBalanceNew;
    }

    public int getScheduledPaymentAmountOld() {
        return scheduledPaymentAmountOld;
    }

    public void setScheduledPaymentAmountOld(int scheduledPaymentAmountOld) {
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
    }

    public int getScheduledPaymentAmountNew() {
        return scheduledPaymentAmountNew;
    }

    public void setScheduledPaymentAmountNew(int scheduledPaymentAmountNew) {
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
    }

    public int getArrearsAmountOld() {
        return arrearsAmountOld;
    }

    public void setArrearsAmountOld(int arrearsAmountOld) {
        this.arrearsAmountOld = arrearsAmountOld;
    }

    public int getArrearsAmountNew() {
        return arrearsAmountNew;
    }

    public void setArrearsAmountNew(int arrearsAmountNew) {
        this.arrearsAmountNew = arrearsAmountNew;
    }

    public int getPaymentStatusOld() {
        return paymentStatusOld;
    }

    public void setPaymentStatusOld(int paymentStatusOld) {
        this.paymentStatusOld = paymentStatusOld;
    }

    public int getPaymentStatusNew() {
        return paymentStatusNew;
    }

    public void setPaymentStatusNew(int paymentStatusNew) {
        this.paymentStatusNew = paymentStatusNew;
    }

    public int getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(int currencyCode) {
        this.currencyCode = currencyCode;
    }

    public int getPostcode() {
        return postcode;
    }

    public void setPostcode(int postcode) {
        this.postcode = postcode;
    }

    public int getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(int regionCode) {
        this.regionCode = regionCode;
    }

    public int getEnquiryReasonCode() {
        return enquiryReasonCode;
    }

    public void setEnquiryReasonCode(int enquiryReasonCode) {
        this.enquiryReasonCode = enquiryReasonCode;
    }

    public boolean isTitlePresent() {
        return titlePresent;
    }

    public void setTitlePresent(boolean titlePresent) {
        this.titlePresent = titlePresent;
    }

    public int getExternalSubjectId() {
        return externalSubjectId;
    }

    public void setExternalSubjectId(int externalSubjectId) {
        this.externalSubjectId = externalSubjectId;
    }
}
