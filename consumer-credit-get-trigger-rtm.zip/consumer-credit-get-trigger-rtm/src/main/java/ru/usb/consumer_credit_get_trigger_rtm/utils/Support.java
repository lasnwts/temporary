package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class Support {

    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(Support.class);

    private final Config config;

    @Autowired
    public Support(Config config) {
        this.config = config;
    }

    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param toFile   - куда (полный путь с именем)
     */
    public boolean moveFileSName(String fromFile, String toFile) throws InterruptedException {

        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile);

        if (from.toFile().exists()) {
            logger.info("{}: Успешно, Файл: {} - существует, Размер файла: {}", LG.USBLOGINFO, from.toFile().getAbsolutePath(), from.toFile().length());
        } else {
            logger.error("{}: Фатальная ошибка, Файл: {} - НЕ существует!!", LG.USBLOGINFO, from.toFile().getAbsolutePath());
            return false;
        }

        if (Files.exists(to.getParent())) {
            logger.debug("{}: Успешно, директория: {} -  существует", LG.USBLOGINFO, to.getParent());
        } else {
            logger.error("{}: Фатальная ошибка, потеряна директория куда планируется копировать файл!: {} - НЕТ сейчас подключения!!", LG.USBLOGERROR, to.getParent());
            return false;
        }

        logger.info("{}: Выполняю перемещение файла {} в {}", LG.USBLOGINFO, from, to);

        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            //Выполняем задержку, чтобы файл загрузился
            logger.info("{}: Выполняем задержку после копирования файла{}, на {} миллисекунд.", LG.USBLOGINFO, fromFile, 20);
            // в течение 1000 миллисекунд
            Thread.sleep(20);
            logger.info("{}: Проверяем, что файл скопирован?..", LG.USBLOGINFO);
            //Проверяем, что файл существует
            if (checkFileExists(to.toString())) {
                if (Files.deleteIfExists(from)) {
                    logger.info("{}: Удален файл источник:{}", LG.USBLOGINFO, from);
                } else {
                    logger.error("{}: Возникла ошибка при попытке удалить файл источник:{} ", LG.USBLOGERROR, from);
                }
                logger.info("{}: Файл {} успешно скопирован в {}", LG.USBLOGINFO, from, to);
                return true;
            } else {
                logger.error("{}: Возникла ошибка при проверке существования файла в папке назначения. Error for operation - move:: file::{}  moved to:{} ", LG.USBLOGERROR,
                        from, to);
                return false;
            }
        } catch (IOException e) {
            logger.error("{}: Error for operation move:[catch (IOException e)]: file::{} moved to:{}", LG.USBLOGERROR, from, to);
            logger.debug("{}: PrintStackTrace[catch (IOException e)]:", LG.USBLOGWARNING, e);
            return false;
        }
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameFull) {
        Path path = Paths.get(fileNameFull);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :String: [{}] not Exist.", LG.USBLOGWARNING, fileNameFull);
        return false;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :File: [{}] not Exist.", LG.USBLOGWARNING, fileNameFull);
        return false;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkDirExists(Path fileNameFull) {
        if (Files.exists(fileNameFull) && Files.isDirectory(fileNameFull)) {
            return true;
        }
        logger.info("{}: File :Path: [{}] not Exist.", LG.USBLOGWARNING, fileNameFull);
        return false;
    }

    /**
     * Получение пути
     *
     * @param path - путь
     * @return - путь
     */
    public Path getPaths(String path) {
        return Paths.get(path);
    }


    /**
     * Функция замены символов по FSD
     * Файл представляется в текстовом формате. В качестве разделителя полей используется точка с запятой ‘;’ (формат CSV).
     * Если точка с запятой встречается внутри поля, то все поле заключается в двойные кавычки (символ “ – H34).
     * Если поле содержит двойные кавычки, то все поле заключается в двойные кавычки и двойная кавычка экранируется также двойной кавычкой.
     * Пример: "Магазин ""Пятерочка"""
     *
     * @param line строка для замены
     * @return - обработанная строка
     */
    public String getWrapLine(String line) {
        if (line == null) {
            return "";
        }
        if (line.contains("\"")) {
            line = line.replace("\"", "\"\"");
        }
        if (line.contains(";")) {
            line = "\"" + line + "\"";
        }
        return line;
    }

    /**
     * Получение списка файлов
     *
     * @param startDir - директория
     * @return - список строк
     */
    public Optional<List<String>> listFilesController(String startDir) {
        try (Stream<Path> walk = Files.walk(Paths.get(startDir))) {
            return Optional.of(walk.filter(Files::isRegularFile)
                    .map(Path::toString).collect(Collectors.toList()));
        } catch (IOException e) {
            logger.error("{}: Произошла ошибка при сканировании каталога:{}, класс FileTransferService. метод listFiles(String startDir)", LG.USBLOGWARNING, startDir);
            logger.debug("{}}: ошибка:", LG.USBLOGWARNING, e);
            return Optional.empty();
        }
    }

    /**
     * Проверка файла на завершение загрузки
     *
     * @return - результат проверки
     */
    public boolean checkFileDone(String fileStr) {
        if (fileStr == null) {
            return false;
        }
        File ff = new File(fileStr);
        if (ff.exists()) {
            for (int timeout = 100; timeout > 0; timeout--) {
                RandomAccessFile ran = null;
                try {
                    ran = new RandomAccessFile(ff, "rw");
                    break; // no errors, done waiting
                } catch (Exception ex) {
                    logger.info("{}: File:{} lockable: Файл не доступен! {} Попробую еще раз...", LG.USBLOGINFO, fileStr, ex.getMessage());
                } finally {
                    if (ran != null) try {
                        ran.close();
                    } catch (IOException ex) {
                        //do nothing
                    }
                    ran = null;
                }
                try {
                    Thread.sleep(100); // wait a bit then try again
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            }
            logger.info("{}: File:{} lockable: Файл стал доступен! Можно обрабатывать!", LG.USBLOGINFO, fileStr);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Очистить список файлов в каталоге /out и /err
     */
    public void cleanOldFiles() {
        LocalDate todayOut = LocalDate.now().minusDays(config.getOutFileOld()); //Текущая дата - 30 дней
        LocalDate todayErr = LocalDate.now().minusDays(config.getErrFileOld()); //Текущая дата - 30 дней

        //Обрабатываем файлы
        if (checkDirExists(getPaths(config.getFileUrl() + FileSystems.getDefault().getSeparator() + "out"))) {
            listFilesController(config.getFileUrl() + FileSystems.getDefault().getSeparator() + "out").ifPresent(files -> files.forEach(file -> {
                try {
                    // method to read the file attributes.
                    BasicFileAttributes fatr = Files.readAttributes(Path.of(file), BasicFileAttributes.class);
                    LocalDate localDate = convertFileTimeToLocalDate(fatr.lastAccessTime());
                    logger.info("{}:OUT: Файл:{} имеют метку даты и времени последнего доступа:lastAccessTime:{}", LG.USBLOGINFO, file, localDate);
                    if (todayOut.isAfter(localDate)) {
                        if (Files.deleteIfExists(getPaths(file))) {
                            logger.info("{}:OUT: Файл:{} удален из директории:{}", LG.USBLOGINFO, file, config.getFileUrl() + FileSystems.getDefault().getSeparator() + "out");
                        } else {
                            logger.info("{}:OUT: Ошибка удаления файла:{} из директории:{}", LG.USBLOGINFO, file, config.getFileUrl() + FileSystems.getDefault().getSeparator() + "out");
                        }
                    }
                } catch (IOException ex) {
                    logger.error("{}:OUT: Произошла ошибка при попытке удалить файл:{}, ошибка:{}", LG.USBLOGERROR, file, ex.getMessage());
                    logger.debug("{}:OUT: Stack Trace - ошибка при попытке удалить файл:{}, ошибка:", LG.USBLOGERROR, file, ex);
                }
            }));
        }
        if (checkDirExists(getPaths(config.getFileUrl() + FileSystems.getDefault().getSeparator() + "err"))) {
            listFilesController(config.getFileUrl() + FileSystems.getDefault().getSeparator() + "err").ifPresent(files -> files.forEach(file -> {
                try {
                    // method to read the file attributes.
                    BasicFileAttributes fatErrr = Files.readAttributes(Path.of(file), BasicFileAttributes.class);
                    LocalDate localDate = convertFileTimeToLocalDate(fatErrr.lastAccessTime());
                    logger.info("{}:ERR: Файл:{} имеют метку даты и времени последнего доступа:lastAccessTime:{}", LG.USBLOGINFO, file, localDate);
                    if (todayErr.isAfter(localDate)) {
                        if (Files.deleteIfExists(getPaths(file))) {
                            logger.info("{}:ERR: Файл:{} удален из директории:{}", LG.USBLOGINFO, file, config.getFileUrl() + FileSystems.getDefault().getSeparator() + "err");
                        } else {
                            logger.info("{}:ERR: Ошибка удаления файла:{} из директории:{}", LG.USBLOGINFO, file, config.getFileUrl() + FileSystems.getDefault().getSeparator() + "err");
                        }
                    }
                } catch (IOException ex) {
                    logger.error("{}:ERR: Произошла ошибка при попытке удалить файл:{}, ошибка:{}", LG.USBLOGERROR, file, ex.getMessage());
                    logger.debug("{}:ERR: Stack Trace - ошибка при попытке удалить файл:{}, ошибка:", LG.USBLOGERROR, file, ex);
                }
            }));
        }
    }


    /**
     * Конвертирование LocalDate в Date
     *
     * @param dateToConvert - localDate
     * @return - Date
     */
    public Date convertToDateViaInstant(LocalDate dateToConvert) {
        return java.util.Date.from(dateToConvert.atStartOfDay()
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }

    /**
     * Конвертация даты в локальную
     *
     * @param dateToConvert - тип данных в формате Date
     * @return - LocalDate
     */
    public LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        return dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    /**
     * Конвертация даты в локальную
     *
     * @param fileTime - тип данных в формате FileTime
     * @return - LocalDate
     */
    public LocalDate convertFileTimeToLocalDate(FileTime fileTime) {
        Instant instant = fileTime.toInstant();
        return instant.atZone(ZoneId.systemDefault()).toLocalDate();
    }

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    /**
     * Получить дату файла
     *
     * @return - LocalDate
     */
    public String getOldFileDate() {
        return LocalDate.now().minusDays(config.getOutFileOld()).format(formatter); //Текущая дата - 30 дней
    }

    /**
     * Получить дату файла
     *
     * @return - LocalDate
     */
    public String getErrFileDate() {
        return LocalDate.now().minusDays(config.getErrFileOld()).format(formatter); //Текущая дата - 30 дней
    }

}


