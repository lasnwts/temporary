package ru.usb.consumer_credit_get_trigger_rtm.model.check;

import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;

public class CheckCsvSbJctTrg {

    private CsvSbJctTrg csvSbJctTrg;
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация

    public CheckCsvSbJctTrg() {
        //empty
    }

    public CheckCsvSbJctTrg(CsvSbJctTrg csvSbJctTrg, LoadError loadError, boolean exists) {
        this.csvSbJctTrg = csvSbJctTrg;
        this.loadError = loadError;
        this.exists = exists;
    }

    public CsvSbJctTrg getCsvSbJctTrg() {
        return csvSbJctTrg;
    }

    public void setCsvSbJctTrg(CsvSbJctTrg csvSbJctTrg) {
        this.csvSbJctTrg = csvSbJctTrg;
    }

    public LoadError getLoadError() {
        return loadError;
    }

    public void setLoadError(LoadError loadError) {
        this.loadError = loadError;
    }

    public boolean isExists() {
        return exists;
    }

    public void setExists(boolean exists) {
        this.exists = exists;
    }
}
