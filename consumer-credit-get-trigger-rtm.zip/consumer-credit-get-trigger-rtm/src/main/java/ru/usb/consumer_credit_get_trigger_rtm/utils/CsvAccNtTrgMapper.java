package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.check.CheckCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;

import java.text.SimpleDateFormat;
import java.util.Date;


@Component
public class CsvAccNtTrgMapper {

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");
    Logger log = LoggerFactory.getLogger(CsvAccNtTrgMapper.class);
    private static final String COMMA_DELIMITER = ",";

    private final Config config;

    @Autowired
    public CsvAccNtTrgMapper(Config config) {
        this.config = config;
    }

    public CheckCsvAccNtTrg map(String line, CsvAccNtTrgHeadPosition position, String fileName, int lineNumber) {

        String[] values = line.split(COMMA_DELIMITER);

        //Пустая срока
        if (values.length < 2) {
            return new CheckCsvAccNtTrg(new CsvAccNtTrg(), new LoadError(lineNumber, fileName, line, "Пустая строка, пропускаем.", new Date(), false), false);
        }

        //Не заполненная строка
        if (values.length < 5) {
            return new CheckCsvAccNtTrg(new CsvAccNtTrg(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        CsvAccNtTrg csvAccNtTrg = new CsvAccNtTrg();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        csvAccNtTrg.setFileName(fileName);
        csvAccNtTrg.setNumLine(lineNumber);


        //1
        try {
            if (position.getSubscriberCode() > -1) {
                csvAccNtTrg.setSubscriberCode(check(values[position.getSubscriberCode()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUBSCRIBER_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUBSCRIBER_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUBSCRIBER_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SUBSCRIBER_CODE: ", LG.USBLOGERROR, e);
        }

        //2
        try {
            if (position.getSubscriberName() > -1) {
                csvAccNtTrg.setSubscriberName(check(values[position.getSubscriberName()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUBSCRIBER_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUBSCRIBER_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUBSCRIBER_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SUBSCRIBER_NAME: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getPrimaryIdType() > -1) {
                csvAccNtTrg.setPrimaryIdType(check(values[position.getPrimaryIdType()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRIMARY_ID_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRIMARY_ID_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PRIMARY_ID_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PRIMARY_ID_TYPE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getPrimaryIdNumber() > -1) {
                csvAccNtTrg.setPrimaryIdNumber(check(values[position.getPrimaryIdNumber()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRIMARY_ID_NUMBER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRIMARY_ID_NUMBER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PRIMARY_ID_NUMBER: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PRIMARY_ID_NUMBER: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getSurname() > -1) {
                csvAccNtTrg.setSurname(check(values[position.getSurname()]));
            } else {
                setLoadError("Не найден обязательный параметр:SURNAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SURNAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SURNAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SURNAME: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getForename1() > -1) {
                csvAccNtTrg.setForename1(check(values[position.getForename1()]));
            } else {
                setLoadError("Не найден обязательный параметр:FORENAME1", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FORENAME1" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FORENAME1: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FORENAME1: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getForename2() > -1) {
                csvAccNtTrg.setForename2(check(values[position.getForename2()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FORENAME2" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FORENAME2: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FORENAME2: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getBirthDate() > -1) {
                csvAccNtTrg.setBirthDate(check(values[position.getBirthDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:BIRTH_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:BIRTH_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, BIRTH_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getTriggerId() > -1) {
                csvAccNtTrg.setTriggerId(check(values[position.getTriggerId()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TRIGGER_ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TRIGGER_ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TRIGGER_ID: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getTriggerCreationDate() > -1) {
                csvAccNtTrg.setTriggerCreationDate(check(values[position.getTriggerCreationDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TRIGGER_CREATION_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TRIGGER_CREATION_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TRIGGER_CREATION_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getOwnTriggerIndicator() > -1) {
                csvAccNtTrg.setOwnTriggerIndicator(check(values[position.getOwnTriggerIndicator()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OWN_TRIGGER_INDICATOR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:OWN_TRIGGER_INDICATOR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, OWN_TRIGGER_INDICATOR: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getTriggerDate() > -1) {
                csvAccNtTrg.setTriggerDate(check(values[position.getTriggerDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TRIGGER_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TRIGGER_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TRIGGER_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getStartDate() > -1) {
                csvAccNtTrg.setStartDate(check(values[position.getStartDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:START_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:START_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, START_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getClosedDate() > -1) {
                csvAccNtTrg.setClosedDate(check(values[position.getClosedDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CLOSED_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLOSED_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, CLOSED_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getApplicantType() > -1) {
                csvAccNtTrg.setApplicantType(check(values[position.getApplicantType()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:APPLICANT_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:APPLICANT_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, APPLICANT_TYPE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getFinanceProduct() > -1) {
                csvAccNtTrg.setFinanceProduct(check(values[position.getFinanceProduct()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FINANCE_PRODUCT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FINANCE_PRODUCT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FINANCE_PRODUCT: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getSpecialStatus() > -1) {
                csvAccNtTrg.setSpecialStatus(check(values[position.getSpecialStatus()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SPECIAL_STATUS" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SPECIAL_STATUS: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SPECIAL_STATUS: ", LG.USBLOGERROR, e);
        }


        try {
            if (position.getFinancePurpose() > -1) {
                csvAccNtTrg.setFinancePurpose(check(values[position.getFinancePurpose()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FINANCE_PURPOSE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FINANCE_PURPOSE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FINANCE_PURPOSE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getFinanceAmount() > -1) {
                csvAccNtTrg.setFinanceAmount(check(values[position.getFinanceAmount()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FINANCE_AMOUNT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FINANCE_AMOUNT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FINANCE_AMOUNT: ", LG.USBLOGERROR, e);
        }

        //creditLimitNew
        try {
            if (position.getCreditLimitNew() > -1) {
                csvAccNtTrg.setCreditLimitNew(check(values[position.getCreditLimitNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CREDIT_LIMIT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CREDIT_LIMIT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, CREDIT_LIMIT_NEW: ", LG.USBLOGERROR, e);
        }

        //creditLimitOld
        try {
            if (position.getCreditLimitOld() > -1) {
                csvAccNtTrg.setCreditLimitOld(check(values[position.getCreditLimitOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CREDIT_LIMIT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CREDIT_LIMIT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, CREDIT_LIMIT_OLD: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getCurrencyCode() > -1) {
                csvAccNtTrg.setCurrencyCode(check(values[position.getCurrencyCode()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CURRENCY_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CURRENCY_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, CURRENCY_CODE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getPaymentStatusNew() > -1) {
                csvAccNtTrg.setPaymentStatusNew(check(values[position.getPaymentStatusNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PAYMENT_STATUS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PAYMENT_STATUS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PAYMENT_STATUS_NEW: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getPaymentStatusOld() > -1) {
                csvAccNtTrg.setPaymentStatusOld(check(values[position.getPaymentStatusOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PAYMENT_STATUS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PAYMENT_STATUS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PAYMENT_STATUS_OLD: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getAccountNumber() > -1) {
                csvAccNtTrg.setAccountNumber(check(values[position.getAccountNumber()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACCOUNT_NUMBER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ACCOUNT_NUMBER: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ACCOUNT_NUMBER: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getCreditFacilityIndicator() > -1) {
                csvAccNtTrg.setCreditFacilityIndicator(check(values[position.getCreditFacilityIndicator()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CREDIT_FACILITY_INDICATOR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CREDIT_FACILITY_INDICATOR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, CREDIT_FACILITY_INDICATOR: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getDefaultDate() > -1) {
                csvAccNtTrg.setDefaultDate(check(values[position.getDefaultDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DEFAULT_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DEFAULT_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, DEFAULT_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getLitigationDate() > -1) {
                csvAccNtTrg.setLitigationDate(check(values[position.getLitigationDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:LITIGATION_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:LITIGATION_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, LITIGATION_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getWriteOffDate() > -1) {
                csvAccNtTrg.setWriteOffDate(check(values[position.getWriteOffDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:WRITE_OFF_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:WRITE_OFF_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, WRITE_OFF_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getLastPaymentDate() > -1) {
                csvAccNtTrg.setLastPaymentDate(check(values[position.getLastPaymentDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:LAST_PAYMENT_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:LAST_PAYMENT_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, LAST_PAYMENT_DATE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getOutstandingBalanceNew() > -1) {
                csvAccNtTrg.setOutstandingBalanceNew(check(values[position.getOutstandingBalanceNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OUTSTANDING_BALANCE_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:OUTSTANDING_BALANCE_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, OUTSTANDING_BALANCE_NEW: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getOutstandingBalanceOld() > -1) {
                csvAccNtTrg.setOutstandingBalanceOld(check(values[position.getOutstandingBalanceOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OUTSTANDING_BALANCE_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:OUTSTANDING_BALANCE_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, OUTSTANDING_BALANCE_OLD: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getScheduledPaymentAmountNew() > -1) {
                csvAccNtTrg.setScheduledPaymentAmountNew(check(values[position.getScheduledPaymentAmountNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SCHEDULED_PAYMENT_AMOUNT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SCHEDULED_PAYMENT_AMOUNT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SCHEDULED_PAYMENT_AMOUNT_NEW: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getScheduledPaymentAmountOld() > -1) {
                csvAccNtTrg.setScheduledPaymentAmountOld(check(values[position.getScheduledPaymentAmountOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SCHEDULED_PAYMENT_AMOUNT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SCHEDULED_PAYMENT_AMOUNT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SCHEDULED_PAYMENT_AMOUNT_OLD: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getArrearsAmountNew() > -1) {
                csvAccNtTrg.setArrearsAmountNew(check(values[position.getArrearsAmountNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ARREARS_AMOUNT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ARREARS_AMOUNT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ARREARS_AMOUNT_NEW: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getArrearsAmountOld() > -1) {
                csvAccNtTrg.setArrearsAmountOld(check(values[position.getArrearsAmountOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ARREARS_AMOUNT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ARREARS_AMOUNT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ARREARS_AMOUNT_OLD: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getPostcode() > -1) {
                csvAccNtTrg.setPostcode(check(values[position.getPostcode()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:POSTCODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:POSTCODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, POSTCODE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getRegionCode() > -1) {
                csvAccNtTrg.setRegionCode(check(values[position.getRegionCode()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:REGION_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:REGION_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, REGION_CODE: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getEnquiryReasonCode() > -1) {
                csvAccNtTrg.setEnquiryReasonCode(check(values[position.getEnquiryReasonCode()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ENQUIRY_REASON_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ENQUIRY_REASON_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ENQUIRY_REASON_CODE: ", LG.USBLOGERROR, e);
        }

        //externalSubjectId
        try {
               if (position.getExternalSubjectId() > -1) {
                csvAccNtTrg.setExternalSubjectId(check(values[position.getExternalSubjectId()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:EXTERNAL_SUBJECT_ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:EXTERNAL_SUBJECT_ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, EXTERNAL_SUBJECT_ID: ", LG.USBLOGERROR, e);
        }

        //Возврат
        return new CheckCsvAccNtTrg(csvAccNtTrg, loadError, true);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote1(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("'", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote2(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("\"", "*");
        }
    }
    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getFirstQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String firstChar = line.substring(0, 1);
            if (firstChar.equalsIgnoreCase("\"")) {
                return line.substring(1, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка
     * @param line -
     * @return
     */
    public String getLastQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String lastChar = line.substring(line.length() - 1);
            if (lastChar.equalsIgnoreCase("\"")) {
                return line.substring(0, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка над строкой
     * @param line - строка
     * @return - строка
     */
    public String getLineTrim(String line){
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String check(String line) {
        return rQuote1(rQuote2(getLastQuote(getFirstQuote(getLineTrim(line))))).trim();
    }

}
