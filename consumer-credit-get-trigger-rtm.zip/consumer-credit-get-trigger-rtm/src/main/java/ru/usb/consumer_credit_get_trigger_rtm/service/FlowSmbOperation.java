package ru.usb.consumer_credit_get_trigger_rtm.service;

import jcifs.smb.SmbFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.SmbFileDto;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadFileCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadFileCsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadHeadCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadHeadCsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.mail.ServiceMailError;
import ru.usb.consumer_credit_get_trigger_rtm.service.smb.SmbService;

import java.io.File;
import java.util.List;
import java.util.Optional;

@Service
public class FlowSmbOperation {

    private final Config config;
    private final LoadFileCsvAccNtTrg loadFileCsvAccNtTrg;
    private final LoadFileCsvSbJctTrg loadFileCsvSbJctTrg;
    private final LoadHeadCsvAccNtTrg loadHeadCsvAccNtTrg;
    private final LoadHeadCsvSbJctTrg loadHeadCsvSbJctTrg;
    private final SmbService smbService;
    private final ServiceMailError serviceMailError;

    @Autowired
    public FlowSmbOperation(Config config, LoadFileCsvAccNtTrg loadFileCsvAccNtTrg, LoadFileCsvSbJctTrg loadFileCsvSbJctTrg,
                            LoadHeadCsvAccNtTrg loadHeadCsvAccNtTrg, LoadHeadCsvSbJctTrg loadHeadCsvSbJctTrg,
                            SmbService smbService, ServiceMailError serviceMailError) {
        this.config = config;
        this.loadFileCsvAccNtTrg = loadFileCsvAccNtTrg;
        this.loadFileCsvSbJctTrg = loadFileCsvSbJctTrg;
        this.loadHeadCsvAccNtTrg = loadHeadCsvAccNtTrg;
        this.loadHeadCsvSbJctTrg = loadHeadCsvSbJctTrg;
        this.smbService = smbService;
        this.serviceMailError = serviceMailError;
    }

    Logger logger = LoggerFactory.getLogger(FlowSmbOperation.class);

    /**
     * Старт обработки файлов
     */
    public void start() {
        logger.debug("{}: start processed...", LG.USBLOGINFO);
        smbService.getCifsConfig(); //Подключаемся...
        Optional<List<SmbFile>> smbFileList; //Готовим переменные
        //Получаем список файлов
        if (smbService.checkSmb()) {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl() + "in/");
        } else {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl() + "in/", smbService.getCifsConfig());
        }
        try {
            //Обрабатываем файлы
            if (smbFileList.isPresent()) {
                logger.debug("smbFileList.isPresent() = true");
                logger.debug("smbFileList.size() = {}", smbFileList.get().size());
                for (SmbFile smbFile : smbFileList.get()) {
                    if (smbFile.isFile()) {
                        logger.debug("{}: File:обнаружен, передан на анализ:smbFile.getUncPath() = {}", LG.USBLOGINFO, smbFile.getUncPath());
                        //Проверка, что это файл - ACCNTTRG
                        if (smbFile.getUncPath().toUpperCase().contains("ACCNTTRG")) {
                            logger.info("{}: File:взят в обработку:smbFile.getUncPath() = {}", LG.USBLOGINFO, smbFile.getUncPath());
                            File file = smbService.copySmbFileToFile(smbFile, smbFile.getName());
                            Optional<CsvAccNtTrgHeadPosition> csvAccNtTrgHeadPosition = loadHeadCsvAccNtTrg.loadFile(file, smbFile.getName(), 1);
                            if (csvAccNtTrgHeadPosition.isPresent()) {
                                logger.info("{}: File:Получен список переменных файла. Заголовок файла:smbFile.getUncPath() = {}", LG.USBLOGINFO, smbFile.getUncPath());
                                List<LoadError> loadErrors = loadFileCsvAccNtTrg.loadFile(file, smbFile.getName(), csvAccNtTrgHeadPosition.get(), 1, true);
                                //Если все в порядке, то копируем в папку out
                                if (loadErrors.isEmpty()) {
                                    SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "out/" + smbFile.getName(), smbService.getCifsConfig()));
                                    //Сравниваем файлы и удаляем исходный файл
                                    checkCopySmbFile(smbFileDto);
                                } else {
                                    logger.warn("{}:!!!![ACCNTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                                    serviceMailError.sendMailErrorSubject("Ошибка при обработке файла типа:[ACCNTTRG] триггеров РТМ", getLogger(loadErrors));
                                    SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "err/" + smbFile.getName(), smbService.getCifsConfig()));
                                    //Сравниваем файлы и удаляем исходный файл
                                    checkCopySmbFile(smbFileDto);
                                }
                            } else {
                                logger.warn("{}:!!!![ACCNTTRG] csvAccNtTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, smbFile.getUncPath());
                                serviceMailError.sendMailErrorSubject("Ошибка при обработке файла типа:[ACCNTTRG] триггеров РТМ", "Файл не содержит заголово:" + smbFile.getUncPath());
                                SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "err/" + smbFile.getName(), smbService.getCifsConfig()));
                                //Сравниваем файлы и удаляем исходный файл
                                checkCopySmbFile(smbFileDto);
                            }
                        }
                        //Проверка файла SBJCTTRG
                        if (smbFile.getUncPath().toUpperCase().contains("SBJCTTRG")) {
                            logger.info("{}: File:SBJCTTRG:взят в обработку:smbFile.getUncPath() = {}", LG.USBLOGINFO, smbFile.getUncPath());
                            File file = smbService.copySmbFileToFile(smbFile, smbFile.getName());
                            Optional<CsvSbJctTrgHeadPosition> csvSbJctTrgHeadPosition = loadHeadCsvSbJctTrg.loadFile(file, smbFile.getName(), 1);
                            if (csvSbJctTrgHeadPosition.isPresent()) {
                                logger.info("{}: File:SBJCTTRG:Получен список переменных файла. Заголовок файла:smbFile.getUncPath() = {}", LG.USBLOGINFO, smbFile.getUncPath());
                                List<LoadError> loadErrors = loadFileCsvSbJctTrg.loadFile(file, smbFile.getName(), csvSbJctTrgHeadPosition.get(), 1, true);
                                //Если все в порядке, то копируем в папку out
                                if (loadErrors.isEmpty()) {
                                    SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "out/" + smbFile.getName(), smbService.getCifsConfig()));
                                    //Сравниваем файлы и удаляем исходный файл
                                    checkCopySmbFile(smbFileDto);
                                } else {
                                    logger.warn("{}:!!!![SBJCTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                                    serviceMailError.sendMailErrorSubject("Ошибка при обработке файла типа:[SBJCTTRG] триггеров РТМ", getLogger(loadErrors));
                                    SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "err/" + smbFile.getName(), smbService.getCifsConfig()));
                                    //Сравниваем файлы и удаляем исходный файл
                                    checkCopySmbFile(smbFileDto);
                                }
                            } else {
                                logger.warn("{}:!!!![SBJCTTRG] csvAccNtTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, smbFile.getUncPath());
                                serviceMailError.sendMailErrorSubject("Ошибка при обработке файла типа:[SBJCTTRG] триггеров РТМ", "Файл не содержит заголово:" + smbFile.getUncPath());
                                SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileUrl() + "err/" + smbFile.getName(), smbService.getCifsConfig()));
                                //Сравниваем файлы и удаляем исходный файл
                                checkCopySmbFile(smbFileDto);
                            }
                        }
                    } else {
                        logger.info("Directory::smbFile.getUncPath() = {}", smbFile.getUncPath());
                    }
                }
            } else {
                logger.info("smbFileList.isPresent() = false");
            }
        } catch (Exception e) {
            if (!e.getMessage().contains("The process cannot access the file because it is being used by another process.")) {
                serviceMailError.sendMailErrorSubject("Ошибка при обработке файла триггеров РТМ", e.getMessage());
            }
            logger.error("{} Возникла ошибка в процессе обработки. Error:{}", LG.USBLOGWARNING, e.getMessage());
        }
        logger.debug("{}: end processed....", LG.USBLOGINFO);
    }

    /**
     * Сравниваем файлы, удаляем исходный файл
     *
     * @param smbFileDto - объект с файлами
     */
    private void checkCopySmbFile(SmbFileDto smbFileDto) {
        if (smbService.compareSmbFile(smbFileDto.getFileSource(), smbFileDto.getFileDestination())) {
            if (smbService.deleteSmbFile(smbFileDto.getFileSource())) {
                logger.info("{}:: Файл:{} удален после обработки.", LG.USBLOGINFO, smbFileDto.getFileSource().getUncPath());
            } else {
                logger.info("{}: Файл:{} не удален", LG.USBLOGWARNING, smbFileDto.getFileSource().getUncPath());
            }
        }
    }

    /**
     * Формируем сообщение об ошибке
     *
     * @param loadErrors - список ошибок
     * @return - сообщение об ошибке
     */
    private String getLogger(List<LoadError> loadErrors) {
        StringBuilder message = new StringBuilder(" ");
        for (LoadError loadError : loadErrors) {
            logger.warn("{}: loadError = {}", LG.USBLOGWARNING, loadError);
            message.append(loadError.toString()).append("\n");
        }
        return message.toString();
    }

}
