package ru.usb.consumer_credit_get_trigger_rtm.model;

import java.util.List;

public class ErrLIstFiles {

    private List<String> stringList;

    public ErrLIstFiles(List<String> stringList) {
        this.stringList = stringList;
    }

    public ErrLIstFiles() {
        //epty
    }

    public List<String> getStringList() {
        return stringList;
    }

    public void setStringList(List<String> stringList) {
        this.stringList = stringList;
    }

    @Override
    public String toString() {
        return "ErrLIstFiles{" +
                "stringList=" + stringList +
                '}';
    }
}
