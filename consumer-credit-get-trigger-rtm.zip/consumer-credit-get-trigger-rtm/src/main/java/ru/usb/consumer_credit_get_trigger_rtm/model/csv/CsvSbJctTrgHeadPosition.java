package ru.usb.consumer_credit_get_trigger_rtm.model.csv;

/**
 * Класс для хранения позиции в файле
 */
public class CsvSbJctTrgHeadPosition {
    //1
    private int primaryIdType;
    //2
    private int primaryIdNumber;
    //3
    private int surname;
    //4
    private int forename1;
    //5
    private int forename2;
    //6
    private int birthDate;
    //7
    private int totalOutstandingBalanceOld;
    //8
    private int totalOutstandingBalanceNew;
    //9
    private int totalMonthlyInstallmentOld;
    //10
    private int totalMonthlyInstallmentNew;
    //11
    private int totalCreditLimitOld;
    //12
    private int totalCreditLimitNew;
    //13
    private int totalArrearsBalanceOld;
    //14
    private int totalArrearsBalanceNew;
    //15
    private int worstCurrentPaymentStatusOld;
    //16
    private int worstCurrentPaymentStatusNew;
    //17
    private int noOfDelinqAcc1DOld;
    //18
    private int noOfDelinqAcc1DNew;
    //19
    private int noOfDelinqAcc30DOld;
    //20
    private int noOfDelinqAcc30DNew;
    //21
    private int noOfDelinqAcc60DOld;
    //22
    private int noOfDelinqAcc60DNew;
    //23
    private int noOfDelinqAcc90DOld;
    //24
    private int noOfDelinqAcc90DNew;
    //25
    private int noOfActiveCaisAccountOld;
    //26
    private int noOfActiveCaisAccountNew;
    //27
    private int noOfSubsKeepAccOld;
    //28
    private int noOfSubsKeepAccNew;
    //29
    private int noOfCapsRecPrev1M;
    //30
    private int noOfCapsRecPrev2M;
    //31
    private int noOfCapsRecPrev3M;
    //32
    private int noOfCapsRecPrev6M;
    //33
    private int triggerId;
    //34
    private int runDate;
    //35
    private int externalSubjectId;
    //Наличие заголовка
    private boolean titlePresent;

    public CsvSbJctTrgHeadPosition() {
        //empty
    }

    public CsvSbJctTrgHeadPosition(int primaryIdType, int primaryIdNumber, int surname, int forename1, int forename2,
                                   int birthDate, int totalOutstandingBalanceOld, int totalOutstandingBalanceNew,
                                   int totalMonthlyInstallmentOld, int totalMonthlyInstallmentNew, int totalCreditLimitOld,
                                   int totalCreditLimitNew, int totalArrearsBalanceOld, int totalArrearsBalanceNew,
                                   int worstCurrentPaymentStatusOld, int worstCurrentPaymentStatusNew, int noOfDelinqAcc1DOld,
                                   int noOfDelinqAcc1DNew, int noOfDelinqAcc30DOld, int noOfDelinqAcc30DNew, int noOfDelinqAcc60DOld,
                                   int noOfDelinqAcc60DNew, int noOfDelinqAcc90DOld, int noOfDelinqAcc90DNew, int noOfActiveCaisAccountOld,
                                   int noOfActiveCaisAccountNew, int noOfSubsKeepAccOld, int noOfSubsKeepAccNew, int noOfCapsRecPrev1M,
                                   int noOfCapsRecPrev2M, int noOfCapsRecPrev3M, int noOfCapsRecPrev6M, int triggerId,
                                   int runDate, boolean titlePresent) {
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.triggerId = triggerId;
        this.runDate = runDate;
        this.titlePresent = titlePresent;
    }

    public CsvSbJctTrgHeadPosition(int primaryIdType, int primaryIdNumber, int surname, int forename1, int forename2,
                                   int birthDate, int totalOutstandingBalanceOld, int totalOutstandingBalanceNew,
                                   int totalMonthlyInstallmentOld, int totalMonthlyInstallmentNew, int totalCreditLimitOld,
                                   int totalCreditLimitNew, int totalArrearsBalanceOld, int totalArrearsBalanceNew,
                                   int worstCurrentPaymentStatusOld, int worstCurrentPaymentStatusNew, int noOfDelinqAcc1DOld,
                                   int noOfDelinqAcc1DNew, int noOfDelinqAcc30DOld, int noOfDelinqAcc30DNew, int noOfDelinqAcc60DOld,
                                   int noOfDelinqAcc60DNew, int noOfDelinqAcc90DOld, int noOfDelinqAcc90DNew, int noOfActiveCaisAccountOld,
                                   int noOfActiveCaisAccountNew, int noOfSubsKeepAccOld, int noOfSubsKeepAccNew, int noOfCapsRecPrev1M,
                                   int noOfCapsRecPrev2M, int noOfCapsRecPrev3M, int noOfCapsRecPrev6M, int triggerId, int runDate,
                                   int externalSubjectId, boolean titlePresent) {
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.triggerId = triggerId;
        this.runDate = runDate;
        this.externalSubjectId = externalSubjectId;
        this.titlePresent = titlePresent;
    }

    public int getPrimaryIdType() {
        return primaryIdType;
    }

    public void setPrimaryIdType(int primaryIdType) {
        this.primaryIdType = primaryIdType;
    }

    public int getPrimaryIdNumber() {
        return primaryIdNumber;
    }

    public void setPrimaryIdNumber(int primaryIdNumber) {
        this.primaryIdNumber = primaryIdNumber;
    }

    public int getSurname() {
        return surname;
    }

    public void setSurname(int surname) {
        this.surname = surname;
    }

    public int getForename1() {
        return forename1;
    }

    public void setForename1(int forename1) {
        this.forename1 = forename1;
    }

    public int getForename2() {
        return forename2;
    }

    public void setForename2(int forename2) {
        this.forename2 = forename2;
    }

    public int getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(int birthDate) {
        this.birthDate = birthDate;
    }

    public int getTotalOutstandingBalanceOld() {
        return totalOutstandingBalanceOld;
    }

    public void setTotalOutstandingBalanceOld(int totalOutstandingBalanceOld) {
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
    }

    public int getTotalOutstandingBalanceNew() {
        return totalOutstandingBalanceNew;
    }

    public void setTotalOutstandingBalanceNew(int totalOutstandingBalanceNew) {
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
    }

    public int getTotalMonthlyInstallmentOld() {
        return totalMonthlyInstallmentOld;
    }

    public void setTotalMonthlyInstallmentOld(int totalMonthlyInstallmentOld) {
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
    }

    public int getTotalMonthlyInstallmentNew() {
        return totalMonthlyInstallmentNew;
    }

    public void setTotalMonthlyInstallmentNew(int totalMonthlyInstallmentNew) {
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
    }

    public int getTotalCreditLimitOld() {
        return totalCreditLimitOld;
    }

    public void setTotalCreditLimitOld(int totalCreditLimitOld) {
        this.totalCreditLimitOld = totalCreditLimitOld;
    }

    public int getTotalCreditLimitNew() {
        return totalCreditLimitNew;
    }

    public void setTotalCreditLimitNew(int totalCreditLimitNew) {
        this.totalCreditLimitNew = totalCreditLimitNew;
    }

    public int getTotalArrearsBalanceOld() {
        return totalArrearsBalanceOld;
    }

    public void setTotalArrearsBalanceOld(int totalArrearsBalanceOld) {
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
    }

    public int getTotalArrearsBalanceNew() {
        return totalArrearsBalanceNew;
    }

    public void setTotalArrearsBalanceNew(int totalArrearsBalanceNew) {
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
    }

    public int getWorstCurrentPaymentStatusOld() {
        return worstCurrentPaymentStatusOld;
    }

    public void setWorstCurrentPaymentStatusOld(int worstCurrentPaymentStatusOld) {
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
    }

    public int getWorstCurrentPaymentStatusNew() {
        return worstCurrentPaymentStatusNew;
    }

    public void setWorstCurrentPaymentStatusNew(int worstCurrentPaymentStatusNew) {
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
    }

    public int getNoOfDelinqAcc1DOld() {
        return noOfDelinqAcc1DOld;
    }

    public void setNoOfDelinqAcc1DOld(int noOfDelinqAcc1DOld) {
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
    }

    public int getNoOfDelinqAcc1DNew() {
        return noOfDelinqAcc1DNew;
    }

    public void setNoOfDelinqAcc1DNew(int noOfDelinqAcc1DNew) {
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
    }

    public int getNoOfDelinqAcc30DOld() {
        return noOfDelinqAcc30DOld;
    }

    public void setNoOfDelinqAcc30DOld(int noOfDelinqAcc30DOld) {
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
    }

    public int getNoOfDelinqAcc30DNew() {
        return noOfDelinqAcc30DNew;
    }

    public void setNoOfDelinqAcc30DNew(int noOfDelinqAcc30DNew) {
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
    }

    public int getNoOfDelinqAcc60DOld() {
        return noOfDelinqAcc60DOld;
    }

    public void setNoOfDelinqAcc60DOld(int noOfDelinqAcc60DOld) {
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
    }

    public int getNoOfDelinqAcc60DNew() {
        return noOfDelinqAcc60DNew;
    }

    public void setNoOfDelinqAcc60DNew(int noOfDelinqAcc60DNew) {
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
    }

    public int getNoOfDelinqAcc90DOld() {
        return noOfDelinqAcc90DOld;
    }

    public void setNoOfDelinqAcc90DOld(int noOfDelinqAcc90DOld) {
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
    }

    public int getNoOfDelinqAcc90DNew() {
        return noOfDelinqAcc90DNew;
    }

    public void setNoOfDelinqAcc90DNew(int noOfDelinqAcc90DNew) {
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
    }

    public int getNoOfActiveCaisAccountOld() {
        return noOfActiveCaisAccountOld;
    }

    public void setNoOfActiveCaisAccountOld(int noOfActiveCaisAccountOld) {
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
    }

    public int getNoOfActiveCaisAccountNew() {
        return noOfActiveCaisAccountNew;
    }

    public void setNoOfActiveCaisAccountNew(int noOfActiveCaisAccountNew) {
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
    }

    public int getNoOfSubsKeepAccOld() {
        return noOfSubsKeepAccOld;
    }

    public void setNoOfSubsKeepAccOld(int noOfSubsKeepAccOld) {
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
    }

    public int getNoOfSubsKeepAccNew() {
        return noOfSubsKeepAccNew;
    }

    public void setNoOfSubsKeepAccNew(int noOfSubsKeepAccNew) {
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
    }

    public int getNoOfCapsRecPrev1M() {
        return noOfCapsRecPrev1M;
    }

    public void setNoOfCapsRecPrev1M(int noOfCapsRecPrev1M) {
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
    }

    public int getNoOfCapsRecPrev2M() {
        return noOfCapsRecPrev2M;
    }

    public void setNoOfCapsRecPrev2M(int noOfCapsRecPrev2M) {
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
    }

    public int getNoOfCapsRecPrev3M() {
        return noOfCapsRecPrev3M;
    }

    public void setNoOfCapsRecPrev3M(int noOfCapsRecPrev3M) {
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
    }

    public int getNoOfCapsRecPrev6M() {
        return noOfCapsRecPrev6M;
    }

    public void setNoOfCapsRecPrev6M(int noOfCapsRecPrev6M) {
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
    }

    public int getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(int triggerId) {
        this.triggerId = triggerId;
    }

    public int getRunDate() {
        return runDate;
    }

    public void setRunDate(int runDate) {
        this.runDate = runDate;
    }

    public boolean isTitlePresent() {
        return titlePresent;
    }

    public void setTitlePresent(boolean titlePresent) {
        this.titlePresent = titlePresent;
    }

    public int getExternalSubjectId() {
        return externalSubjectId;
    }

    public void setExternalSubjectId(int externalSubjectId) {
        this.externalSubjectId = externalSubjectId;
    }
}
