package ru.usb.consumer_credit_get_trigger_rtm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.service.smb.SmbService;
import ru.usb.consumer_credit_get_trigger_rtm.utils.Support;

@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final Support support;
    private final SmbService smbService;
    private final FlowFileOperation flowFileOperation;
    private final FlowSmbOperation flowSmbOperation;


    @Autowired
    public FlowScheduler(Config config, Support support, SmbService smbService, FlowFileOperation flowFileOperation, FlowSmbOperation flowSmbOperation) {
        this.config = config;
        this.support = support;
        this.smbService = smbService;
        this.flowFileOperation = flowFileOperation;
        this.flowSmbOperation = flowSmbOperation;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    //Очистка файловых шар от старых файлов
    @Scheduled(cron = "${cron-scheduler}")
    public void startScheduler() {
        logger.info("{} cron-start. Стартовал процесс очистки каталогов /out и /err от старых файлов.", LG.USBLOGINFO);
        logger.info("{} Файлы  в каталоге /out - старше даты:{} будут удалены.", LG.USBLOGINFO, support.getOldFileDate());
        logger.info("{} Файлы  в каталоге /err - старше даты:{} будут удалены.", LG.USBLOGINFO, support.getErrFileDate());
        if (config.isServiceEnabled()) {
            if (config.isSmbEnable()) {
                //Доступ через SMB
                smbService.cleanSmbFileService();
            } else {
                //Прямой доступ к файлам
                support.cleanOldFiles();
            }
        }
        logger.info("{} cron-stop. Время работы наступило.", LG.USBLOGINFO);
    }

    /**
     * Запускаем каждые 300 миллисекунд
     * Сканиирование сетевых файловых шар
     */
    @Scheduled(initialDelay = 10L, fixedDelayString = "${scheduler.delay}")
    public void schedulers() {
        if (config.isServiceEnabled()) {
            if (config.isSmbEnable()) {
                //Включен режим многопоточной обработки
                flowSmbOperation.start(); //Если включен smb.enable=true
            } else {
                //Режим одно поточной обработки
                flowFileOperation.start(); //Если включен smb.enable=false
            }
        }
    }

    /**
     * Периодическая очистка памяти
     * В случае если включена многопоточность
     */
    @Scheduled(initialDelay = 10L, fixedDelay = 25000)
    public void gcScheduler() {
        if (config.isServiceEnabled()) {
            if (config.isServiceMultiThreadEnabled()) {
                System.gc(); //Периодическая очистка памяти
            }
        }
    }


}



