package ru.usb.consumer_credit_get_trigger_rtm.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 1	SOURCE
 * 2	EVENT_TYPE
 * 3	EVENT_DATETIME
 * 4	FILE_TYPE
 * 5	EXTERNAL_SUBJECT_ID
 * 6	PRIMARY_ID_TYPE
 * 7	PRIMARY_ID_NUMBER
 * 8	SURNAME
 * 9	FORENAME1
 * 10	FORENAME2
 * 11	BIRTH_DATE
 * 12	TRIGGER_ID
 * 13	SUBSCRIBER_CODE
 * 14	SUBSCRIBER_NAME
 * 15	TRIGGER_CREATION_DATE
 * 16	OWN_TRIGGER_INDICATOR
 * 17	TRIGGER_DATE
 * 18	START_DATE
 * 19	CLOSED_DATE
 * 20	APPLICANT_TYPE
 * 21	FINANCE_PRODUCT
 * 22	ACCOUNT_NUMBER
 * 23	CREDIT_FACILITY_INDICATOR
 * 24	SPECIAL_STATUS
 * 25	FINANCE_PURPOSE
 * 26	FINANCE_AMOUNT
 * 27	CREDIT_LIMIT_OLD
 * 28	CREDIT_LIMIT_NEW
 * 29	DEFAULT_DATE
 * 30	LITIGATION_DATE
 * 31	WRITE_OFF_DATE
 * 32	LAST_PAYMENT_DATE
 * 33	OUTSTANDING_BALANCE_OLD
 * 34	OUTSTANDING_BALANCE_NEW
 * 35	SCHEDULED_PAYMENT_AMOUNT_OLD
 * 36	SCHEDULED_PAYMENT_AMOUNT_NEW
 * 37	ARREARS_AMOUNT_OLD
 * 38	ARREARS_AMOUNT_NEW
 * 39	PAYMENT_STATUS_OLD
 * 40	PAYMENT_STATUS_NEW
 * 41	CURRENCY_CODE
 * 42	POSTCODE
 * 43	REGION_CODE
 * 44	ENQUIRY_REASON_CODE
 * 45	TOTAL_OUTSTANDING_BALANCE_OLD
 * 46	TOTAL_OUTSTANDING_BALANCE_NEW
 * 47	TOTAL_MONTHLY_INSTALLMENT_OLD
 * 48	TOTAL_MONTHLY_INSTALLMENT_NEW
 * 49	TOTAL_CREDIT_LIMIT_OLD
 * 50	TOTAL_CREDIT_LIMIT_NEW
 * 51	TOTAL_ARREARS_BALANCE_OLD
 * 52	TOTAL_ARREARS_BALANCE_NEW
 * 53	WORST_CUR_PAY_STATUS_OLD
 * 54	WORST_CUR_PAY_STATUS_NEW
 * 55	NO_OF_DELINQ_ACC_1_D_OLD
 * 56	NO_OF_DELINQ_ACC_1_D_NEW
 * 57	NO_OF_DELINQ_ACC_30_D_OLD
 * 58	NO_OF_DELINQ_ACC_30_D_NEW
 * 59	NO_OF_DELINQ_ACC_60_D_OLD
 * 60	NO_OF_DELINQ_ACC_60_D_NEW
 * 61	NO_OF_DELINQ_ACC_90_D_OLD
 * 62	NO_OF_DELINQ_ACC_90_D_NEW
 * 63	NO_OF_ACTIVE_CAIS_ACCOUNT_OLD
 * 64	NO_OF_ACTIVE_CAIS_ACCOUNT_NEW
 * 65	NO_OF_SUBS_KEEP_ACC_OLD
 * 66	NO_OF_SUBS_KEEP_ACC_NEW
 * 67	NO_OF_CAPS_REC_PREV_1_M
 * 68	NO_OF_CAPS_REC_PREV_2_M
 * 69	NO_OF_CAPS_REC_PREV_3_M
 * 70	NO_OF_CAPS_REC_PREV_6_M
 * 71	RUN_DATE
 */

public class MessageToRtm {
    //1
    @JsonProperty("SOURCE")
    private String source; // SOURCE

    //2
    @JsonProperty("EVENT_TYPE")
    private String eventType;

    //3
    @JsonProperty("EVENT_DATETIME")
    private String eventDateTime;

    //4
    @JsonProperty("FILE_TYPE")
    private String fileType;

    //5
    @JsonProperty("EXTERNAL_SUBJECT_ID")
    private String externalSubjectId;

    //6
    @JsonProperty("PRIMARY_ID_TYPE")
    private String primaryIdType;

    //7
    @JsonProperty("PRIMARY_ID_NUMBER")
    private String primaryIdNumber;

    //8
    @JsonProperty("SURNAME")
    private String surname;

    //9
    @JsonProperty("FORENAME1")
    private String forename1;

    //10
    @JsonProperty("FORENAME2")
    private String forename2;

    //11
    @JsonProperty("BIRTH_DATE")
    private String birthDate;

    //12
    @JsonProperty("TRIGGER_ID")
    private String triggerId;

    //13
    @JsonProperty("SUBSCRIBER_CODE")
    private String subscriberCode;

    //14
    @JsonProperty("SUBSCRIBER_NAME")
    private String subscriberName;

    //15
    @JsonProperty("TRIGGER_CREATION_DATE")
    private String triggerCreationDate;

    //16
    @JsonProperty("OWN_TRIGGER_INDICATOR")
    private String ownTriggerIndicator;

    //17
    @JsonProperty("TRIGGER_DATE")
    private String triggerDate;

    //18
    @JsonProperty("START_DATE")
    private String startDate;

    //19
    @JsonProperty("CLOSED_DATE")
    private String closedDate;

    //20
    @JsonProperty("APPLICANT_TYPE")
    private String applicantType;

    //21
    @JsonProperty("FINANCE_PRODUCT")
    private String financeProduct;

    //22
    @JsonProperty("ACCOUNT_NUMBER")
    private String accountNumber;

    //23
    @JsonProperty("CREDIT_FACILITY_INDICATOR")
    private String creditFacilityIndicator;

    //24
    @JsonProperty("SPECIAL_STATUS")
    private String specialStatus;

    //25
    @JsonProperty("FINANCE_PURPOSE")
    private String financePurpose;

    //26
    @JsonProperty("FINANCE_AMOUNT")
    private String financeAmount;

    //27
    @JsonProperty("CREDIT_LIMIT_OLD")
    private String creditLimitOld;

    //28
    @JsonProperty("CREDIT_LIMIT_NEW")
    private String creditLimitNew;

    //29
    @JsonProperty("DEFAULT_DATE")
    private String defaultDate;

    //30
    @JsonProperty("LITIGATION_DATE")
    private String litigationDate;

    //31
    @JsonProperty("WRITE_OFF_DATE")
    private String writeOffDate;

    //32
    @JsonProperty("LAST_PAYMENT_DATE")
    private String lastPaymentDate;

    //33
    @JsonProperty("OUTSTANDING_BALANCE_OLD")
    private String outstandingBalanceOld;

    //34
    @JsonProperty("OUTSTANDING_BALANCE_NEW")
    private String outstandingBalanceNew;

    //35
    @JsonProperty("SCHEDULED_PAYMENT_AMOUNT_OLD")
    private String scheduledPaymentAmountOld;

    //36
    @JsonProperty("SCHEDULED_PAYMENT_AMOUNT_NEW")
    private String scheduledPaymentAmountNew;

    //37
    @JsonProperty("ARREARS_AMOUNT_OLD")
    private String arrearsAmountOld;

    //38
    @JsonProperty("ARREARS_AMOUNT_NEW")
    private String arrearsAmountNew;

    //39
    @JsonProperty("PAYMENT_STATUS_OLD")
    private String paymentStatusOld;

    //40
    @JsonProperty("PAYMENT_STATUS_NEW")
    private String paymentStatusNew;

    //41
    @JsonProperty("CURRENCY_CODE")
    private String currencyCode;

    //42
    @JsonProperty("POSTCODE")
    private String postcode;

    //43
    @JsonProperty("REGION_CODE")
    private String regionCode;

    //44
    @JsonProperty("ENQUIRY_REASON_CODE")
    private String enquiryReasonCode;

    //45
    @JsonProperty("TOTAL_OUTSTANDING_BALANCE_OLD")
    private String totalOutstandingBalanceOld;

    //46
    @JsonProperty("TOTAL_OUTSTANDING_BALANCE_NEW")
    private String totalOutstandingBalanceNew;

    //47
    @JsonProperty("TOTAL_MONTHLY_INSTALLMENT_OLD")
    private String totalMonthlyInstallmentOld;

    //48
    @JsonProperty("TOTAL_MONTHLY_INSTALLMENT_NEW")
    private String totalMonthlyInstallmentNew;

    //49
    @JsonProperty("TOTAL_CREDIT_LIMIT_OLD")
    private String totalCreditLimitOld;

    //50
    @JsonProperty("TOTAL_CREDIT_LIMIT_NEW")
    private String totalCreditLimitNew;

    //51
    @JsonProperty("TOTAL_ARREARS_BALANCE_OLD")
    private String totalArrearsBalanceOld;

    //52
    @JsonProperty("TOTAL_ARREARS_BALANCE_NEW")
    private String totalArrearsBalanceNew;

    //53
    @JsonProperty("WORST_CUR_PAY_STATUS_OLD")
    private String worstCurPayStatusOld;

    //54
    @JsonProperty("WORST_CUR_PAY_STATUS_NEW")
    private String worstCurPayStatusNew;

    //55
    @JsonProperty("NO_OF_DELINQ_ACC_1_D_OLD")
    private String noOfDelinqAcc1DOld;

    //56
    @JsonProperty("NO_OF_DELINQ_ACC_1_D_NEW")
    private String noOfDelinqAcc1DNew;

    //57
    @JsonProperty("NO_OF_DELINQ_ACC_30_D_OLD")
    private String noOfDelinqAcc30DOld;

    //58
    @JsonProperty("NO_OF_DELINQ_ACC_30_D_NEW")
    private String noOfDelinqAcc30DNew;

    //59
    @JsonProperty("NO_OF_DELINQ_ACC_60_D_OLD")
    private String noOfDelinqAcc60DOld;

    //60
    @JsonProperty("NO_OF_DELINQ_ACC_60_D_NEW")
    private String noOfDelinqAcc60DNew;

    //61
    @JsonProperty("NO_OF_DELINQ_ACC_90_D_OLD")
    private String noOfDelinqAcc90DOld;

    //62
    @JsonProperty("NO_OF_DELINQ_ACC_90_D_NEW")
    private String noOfDelinqAcc90DNew;

    //63
    @JsonProperty("NO_OF_ACTIVE_CAIS_ACCOUNT_OLD")
    private String noOfActiveCaisAccountOld;

    //64
    @JsonProperty("NO_OF_ACTIVE_CAIS_ACCOUNT_NEW")
    private String noOfActiveCaisAccountNew;

    //65
    @JsonProperty("NO_OF_SUBS_KEEP_ACC_OLD")
    private String noOfSubsKeepAccOld;

    //66
    @JsonProperty("NO_OF_SUBS_KEEP_ACC_NEW")
    private String noOfSubsKeepAccNew;

    //67
    @JsonProperty("NO_OF_CAPS_REC_PREV_1_M")
    private String noOfCapsRecPrev1M;

    //68
    @JsonProperty("NO_OF_CAPS_REC_PREV_2_M")
    private String noOfCapsRecPrev2M;

    //69
    @JsonProperty("NO_OF_CAPS_REC_PREV_3_M")
    private String noOfCapsRecPrev3M;

    //70
    @JsonProperty("NO_OF_CAPS_REC_PREV_6_M")
    private String noOfCapsRecPrev6M;

    //71
    @JsonProperty("RUN_DATE")
    private String runDate;

    public MessageToRtm() {
        //empty
    }

    public MessageToRtm(String source, String eventType, String eventDateTime, String fileType, String externalSubjectId, String primaryIdType, String primaryIdNumber, String surname, String forename1, String forename2, String birthDate, String triggerId, String subscriberCode, String subscriberName, String triggerCreationDate, String ownTriggerIndicator, String triggerDate, String startDate, String closedDate, String applicantType, String financeProduct, String accountNumber, String creditFacilityIndicator, String specialStatus, String financePurpose, String financeAmount, String creditLimitOld, String creditLimitNew, String defaultDate, String litigationDate, String writeOffDate, String lastPaymentDate, String outstandingBalanceOld, String outstandingBalanceNew, String scheduledPaymentAmountOld, String scheduledPaymentAmountNew, String arrearsAmountOld, String arrearsAmountNew, String paymentStatusOld, String paymentStatusNew, String currencyCode, String postcode, String regionCode, String enquiryReasonCode, String totalOutstandingBalanceOld, String totalOutstandingBalanceNew, String totalMonthlyInstallmentOld, String totalMonthlyInstallmentNew, String totalCreditLimitOld, String totalCreditLimitNew, String totalArrearsBalanceOld, String totalArrearsBalanceNew, String worstCurPayStatusOld, String worstCurPayStatusNew, String noOfDelinqAcc1DOld, String noOfDelinqAcc1DNew, String noOfDelinqAcc30DOld, String noOfDelinqAcc30DNew, String noOfDelinqAcc60DOld, String noOfDelinqAcc60DNew, String noOfDelinqAcc90DOld, String noOfDelinqAcc90DNew, String noOfActiveCaisAccountOld, String noOfActiveCaisAccountNew, String noOfSubsKeepAccOld, String noOfSubsKeepAccNew, String noOfCapsRecPrev1M, String noOfCapsRecPrev2M, String noOfCapsRecPrev3M, String noOfCapsRecPrev6M, String runDate) {
        this.source = source;
        this.eventType = eventType;
        this.eventDateTime = eventDateTime;
        this.fileType = fileType;
        this.externalSubjectId = externalSubjectId;
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.triggerId = triggerId;
        this.subscriberCode = subscriberCode;
        this.subscriberName = subscriberName;
        this.triggerCreationDate = triggerCreationDate;
        this.ownTriggerIndicator = ownTriggerIndicator;
        this.triggerDate = triggerDate;
        this.startDate = startDate;
        this.closedDate = closedDate;
        this.applicantType = applicantType;
        this.financeProduct = financeProduct;
        this.accountNumber = accountNumber;
        this.creditFacilityIndicator = creditFacilityIndicator;
        this.specialStatus = specialStatus;
        this.financePurpose = financePurpose;
        this.financeAmount = financeAmount;
        this.creditLimitOld = creditLimitOld;
        this.creditLimitNew = creditLimitNew;
        this.defaultDate = defaultDate;
        this.litigationDate = litigationDate;
        this.writeOffDate = writeOffDate;
        this.lastPaymentDate = lastPaymentDate;
        this.outstandingBalanceOld = outstandingBalanceOld;
        this.outstandingBalanceNew = outstandingBalanceNew;
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
        this.arrearsAmountOld = arrearsAmountOld;
        this.arrearsAmountNew = arrearsAmountNew;
        this.paymentStatusOld = paymentStatusOld;
        this.paymentStatusNew = paymentStatusNew;
        this.currencyCode = currencyCode;
        this.postcode = postcode;
        this.regionCode = regionCode;
        this.enquiryReasonCode = enquiryReasonCode;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurPayStatusOld = worstCurPayStatusOld;
        this.worstCurPayStatusNew = worstCurPayStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.runDate = runDate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventDateTime() {
        return eventDateTime;
    }

    public void setEventDateTime(String eventDateTime) {
        this.eventDateTime = eventDateTime;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getExternalSubjectId() {
        return externalSubjectId;
    }

    public void setExternalSubjectId(String externalSubjectId) {
        this.externalSubjectId = externalSubjectId;
    }

    public String getPrimaryIdType() {
        return primaryIdType;
    }

    public void setPrimaryIdType(String primaryIdType) {
        this.primaryIdType = primaryIdType;
    }

    public String getPrimaryIdNumber() {
        return primaryIdNumber;
    }

    public void setPrimaryIdNumber(String primaryIdNumber) {
        this.primaryIdNumber = primaryIdNumber;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getForename1() {
        return forename1;
    }

    public void setForename1(String forename1) {
        this.forename1 = forename1;
    }

    public String getForename2() {
        return forename2;
    }

    public void setForename2(String forename2) {
        this.forename2 = forename2;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getSubscriberCode() {
        return subscriberCode;
    }

    public void setSubscriberCode(String subscriberCode) {
        this.subscriberCode = subscriberCode;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getTriggerCreationDate() {
        return triggerCreationDate;
    }

    public void setTriggerCreationDate(String triggerCreationDate) {
        this.triggerCreationDate = triggerCreationDate;
    }

    public String getOwnTriggerIndicator() {
        return ownTriggerIndicator;
    }

    public void setOwnTriggerIndicator(String ownTriggerIndicator) {
        this.ownTriggerIndicator = ownTriggerIndicator;
    }

    public String getTriggerDate() {
        return triggerDate;
    }

    public void setTriggerDate(String triggerDate) {
        this.triggerDate = triggerDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(String closedDate) {
        this.closedDate = closedDate;
    }

    public String getApplicantType() {
        return applicantType;
    }

    public void setApplicantType(String applicantType) {
        this.applicantType = applicantType;
    }

    public String getFinanceProduct() {
        return financeProduct;
    }

    public void setFinanceProduct(String financeProduct) {
        this.financeProduct = financeProduct;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCreditFacilityIndicator() {
        return creditFacilityIndicator;
    }

    public void setCreditFacilityIndicator(String creditFacilityIndicator) {
        this.creditFacilityIndicator = creditFacilityIndicator;
    }

    public String getSpecialStatus() {
        return specialStatus;
    }

    public void setSpecialStatus(String specialStatus) {
        this.specialStatus = specialStatus;
    }

    public String getFinancePurpose() {
        return financePurpose;
    }

    public void setFinancePurpose(String financePurpose) {
        this.financePurpose = financePurpose;
    }

    public String getFinanceAmount() {
        return financeAmount;
    }

    public void setFinanceAmount(String financeAmount) {
        this.financeAmount = financeAmount;
    }

    public String getCreditLimitOld() {
        return creditLimitOld;
    }

    public void setCreditLimitOld(String creditLimitOld) {
        this.creditLimitOld = creditLimitOld;
    }

    public String getCreditLimitNew() {
        return creditLimitNew;
    }

    public void setCreditLimitNew(String creditLimitNew) {
        this.creditLimitNew = creditLimitNew;
    }

    public String getDefaultDate() {
        return defaultDate;
    }

    public void setDefaultDate(String defaultDate) {
        this.defaultDate = defaultDate;
    }

    public String getLitigationDate() {
        return litigationDate;
    }

    public void setLitigationDate(String litigationDate) {
        this.litigationDate = litigationDate;
    }

    public String getWriteOffDate() {
        return writeOffDate;
    }

    public void setWriteOffDate(String writeOffDate) {
        this.writeOffDate = writeOffDate;
    }

    public String getLastPaymentDate() {
        return lastPaymentDate;
    }

    public void setLastPaymentDate(String lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    public String getOutstandingBalanceOld() {
        return outstandingBalanceOld;
    }

    public void setOutstandingBalanceOld(String outstandingBalanceOld) {
        this.outstandingBalanceOld = outstandingBalanceOld;
    }

    public String getOutstandingBalanceNew() {
        return outstandingBalanceNew;
    }

    public void setOutstandingBalanceNew(String outstandingBalanceNew) {
        this.outstandingBalanceNew = outstandingBalanceNew;
    }

    public String getScheduledPaymentAmountOld() {
        return scheduledPaymentAmountOld;
    }

    public void setScheduledPaymentAmountOld(String scheduledPaymentAmountOld) {
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
    }

    public String getScheduledPaymentAmountNew() {
        return scheduledPaymentAmountNew;
    }

    public void setScheduledPaymentAmountNew(String scheduledPaymentAmountNew) {
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
    }

    public String getArrearsAmountOld() {
        return arrearsAmountOld;
    }

    public void setArrearsAmountOld(String arrearsAmountOld) {
        this.arrearsAmountOld = arrearsAmountOld;
    }

    public String getArrearsAmountNew() {
        return arrearsAmountNew;
    }

    public void setArrearsAmountNew(String arrearsAmountNew) {
        this.arrearsAmountNew = arrearsAmountNew;
    }

    public String getPaymentStatusOld() {
        return paymentStatusOld;
    }

    public void setPaymentStatusOld(String paymentStatusOld) {
        this.paymentStatusOld = paymentStatusOld;
    }

    public String getPaymentStatusNew() {
        return paymentStatusNew;
    }

    public void setPaymentStatusNew(String paymentStatusNew) {
        this.paymentStatusNew = paymentStatusNew;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getEnquiryReasonCode() {
        return enquiryReasonCode;
    }

    public void setEnquiryReasonCode(String enquiryReasonCode) {
        this.enquiryReasonCode = enquiryReasonCode;
    }

    public String getTotalOutstandingBalanceOld() {
        return totalOutstandingBalanceOld;
    }

    public void setTotalOutstandingBalanceOld(String totalOutstandingBalanceOld) {
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
    }

    public String getTotalOutstandingBalanceNew() {
        return totalOutstandingBalanceNew;
    }

    public void setTotalOutstandingBalanceNew(String totalOutstandingBalanceNew) {
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
    }

    public String getTotalMonthlyInstallmentOld() {
        return totalMonthlyInstallmentOld;
    }

    public void setTotalMonthlyInstallmentOld(String totalMonthlyInstallmentOld) {
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
    }

    public String getTotalMonthlyInstallmentNew() {
        return totalMonthlyInstallmentNew;
    }

    public void setTotalMonthlyInstallmentNew(String totalMonthlyInstallmentNew) {
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
    }

    public String getTotalCreditLimitOld() {
        return totalCreditLimitOld;
    }

    public void setTotalCreditLimitOld(String totalCreditLimitOld) {
        this.totalCreditLimitOld = totalCreditLimitOld;
    }

    public String getTotalCreditLimitNew() {
        return totalCreditLimitNew;
    }

    public void setTotalCreditLimitNew(String totalCreditLimitNew) {
        this.totalCreditLimitNew = totalCreditLimitNew;
    }

    public String getTotalArrearsBalanceOld() {
        return totalArrearsBalanceOld;
    }

    public void setTotalArrearsBalanceOld(String totalArrearsBalanceOld) {
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
    }

    public String getTotalArrearsBalanceNew() {
        return totalArrearsBalanceNew;
    }

    public void setTotalArrearsBalanceNew(String totalArrearsBalanceNew) {
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
    }

    public String getWorstCurPayStatusOld() {
        return worstCurPayStatusOld;
    }

    public void setWorstCurPayStatusOld(String worstCurPayStatusOld) {
        this.worstCurPayStatusOld = worstCurPayStatusOld;
    }

    public String getWorstCurPayStatusNew() {
        return worstCurPayStatusNew;
    }

    public void setWorstCurPayStatusNew(String worstCurPayStatusNew) {
        this.worstCurPayStatusNew = worstCurPayStatusNew;
    }

    public String getNoOfDelinqAcc1DOld() {
        return noOfDelinqAcc1DOld;
    }

    public void setNoOfDelinqAcc1DOld(String noOfDelinqAcc1DOld) {
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
    }

    public String getNoOfDelinqAcc1DNew() {
        return noOfDelinqAcc1DNew;
    }

    public void setNoOfDelinqAcc1DNew(String noOfDelinqAcc1DNew) {
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
    }

    public String getNoOfDelinqAcc30DOld() {
        return noOfDelinqAcc30DOld;
    }

    public void setNoOfDelinqAcc30DOld(String noOfDelinqAcc30DOld) {
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
    }

    public String getNoOfDelinqAcc30DNew() {
        return noOfDelinqAcc30DNew;
    }

    public void setNoOfDelinqAcc30DNew(String noOfDelinqAcc30DNew) {
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
    }

    public String getNoOfDelinqAcc60DOld() {
        return noOfDelinqAcc60DOld;
    }

    public void setNoOfDelinqAcc60DOld(String noOfDelinqAcc60DOld) {
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
    }

    public String getNoOfDelinqAcc60DNew() {
        return noOfDelinqAcc60DNew;
    }

    public void setNoOfDelinqAcc60DNew(String noOfDelinqAcc60DNew) {
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
    }

    public String getNoOfDelinqAcc90DOld() {
        return noOfDelinqAcc90DOld;
    }

    public void setNoOfDelinqAcc90DOld(String noOfDelinqAcc90DOld) {
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
    }

    public String getNoOfDelinqAcc90DNew() {
        return noOfDelinqAcc90DNew;
    }

    public void setNoOfDelinqAcc90DNew(String noOfDelinqAcc90DNew) {
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
    }

    public String getNoOfActiveCaisAccountOld() {
        return noOfActiveCaisAccountOld;
    }

    public void setNoOfActiveCaisAccountOld(String noOfActiveCaisAccountOld) {
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
    }

    public String getNoOfActiveCaisAccountNew() {
        return noOfActiveCaisAccountNew;
    }

    public void setNoOfActiveCaisAccountNew(String noOfActiveCaisAccountNew) {
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
    }

    public String getNoOfSubsKeepAccOld() {
        return noOfSubsKeepAccOld;
    }

    public void setNoOfSubsKeepAccOld(String noOfSubsKeepAccOld) {
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
    }

    public String getNoOfSubsKeepAccNew() {
        return noOfSubsKeepAccNew;
    }

    public void setNoOfSubsKeepAccNew(String noOfSubsKeepAccNew) {
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
    }

    public String getNoOfCapsRecPrev1M() {
        return noOfCapsRecPrev1M;
    }

    public void setNoOfCapsRecPrev1M(String noOfCapsRecPrev1M) {
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
    }

    public String getNoOfCapsRecPrev2M() {
        return noOfCapsRecPrev2M;
    }

    public void setNoOfCapsRecPrev2M(String noOfCapsRecPrev2M) {
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
    }

    public String getNoOfCapsRecPrev3M() {
        return noOfCapsRecPrev3M;
    }

    public void setNoOfCapsRecPrev3M(String noOfCapsRecPrev3M) {
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
    }

    public String getNoOfCapsRecPrev6M() {
        return noOfCapsRecPrev6M;
    }

    public void setNoOfCapsRecPrev6M(String noOfCapsRecPrev6M) {
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
    }

    public String getRunDate() {
        return runDate;
    }

    public void setRunDate(String runDate) {
        this.runDate = runDate;
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote1(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("'", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote2(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("\"", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String check(String line) {
        return rQuote1(rQuote2(line));
    }

    public String toCSV() {
        return
                "SOURCE,'" + check(source) + '\'' +
                        ",EVENT_TYPE,'" + check(eventType) + '\'' +
                        ",EVENT_DATETIME,'" + check(eventDateTime) + '\'' +
                        ",FILE_TYPE,'" + check(fileType) + '\'' +
                        ",EXTERNAL_SUBJECT_ID,'" + check(externalSubjectId) + '\'' +
                        ",PRIMARY_ID_TYPE,'" + check(primaryIdType) + '\'' +
                        ",PRIMARY_ID_NUMBER,'" + check(primaryIdNumber) + '\'' +
                        ",SURNAME,'" + check(surname) + '\'' +
                        ",FORENAME1,'" + check(forename1) + '\'' +
                        ",FORENAME2,'" + check(forename2) + '\'' +
                        ",BIRTH_DATE,'" + check(birthDate) + '\'' +
                        ",TRIGGER_ID,'" + check(triggerId) + '\'' +
                        ",SUBSCRIBER_CODE,'" + check(subscriberCode) + '\'' +
                        ",SUBSCRIBER_NAME,'" + check(subscriberName) + '\'' +
                        ",TRIGGER_CREATION_DATE,'" + check(triggerCreationDate) + '\'' +
                        ",OWN_TRIGGER_INDICATOR,'" + check(ownTriggerIndicator) + '\'' +
                        ",TRIGGER_DATE,'" + check(triggerDate) + '\'' +
                        ",START_DATE,'" + check(startDate) + '\'' +
                        ",CLOSED_DATE,'" + check(closedDate) + '\'' +
                        ",APPLICANT_TYPE,'" + check(applicantType) + '\'' +
                        ",FINANCE_PRODUCT,'" + check(financeProduct) + '\'' +
                        ",ACCOUNT_NUMBER,'" + check(accountNumber) + '\'' +
                        ",CREDIT_FACILITY_INDICATOR,'" + check(creditFacilityIndicator) + '\'' +
                        ",SPECIAL_STATUS,'" + check(specialStatus) + '\'' +
                        ",FINANCE_PURPOSE,'" + check(financePurpose) + '\'' +
                        ",FINANCE_AMOUNT,'" + check(financeAmount) + '\'' +
                        ",CREDIT_LIMIT_OLD,'" + check(creditLimitOld) + '\'' +
                        ",CREDIT_LIMIT_NEW,'" + check(creditLimitNew) + '\'' +
                        ",DEFAULT_DATE,'" + check(defaultDate) + '\'' +
                        ",LITIGATION_DATE,'" + check(litigationDate) + '\'' +
                        ",WRITE_OFF_DATE,'" + check(writeOffDate) + '\'' +
                        ",LAST_PAYMENT_DATE,'" + check(lastPaymentDate) + '\'' +
                        ",OUTSTANDING_BALANCE_OLD,'" + check(outstandingBalanceOld) + '\'' +
                        ",OUTSTANDING_BALANCE_NEW,'" + check(outstandingBalanceNew) + '\'' +
                        ",SCHEDULED_PAYMENT_AMOUNT_OLD,'" + check(scheduledPaymentAmountOld) + '\'' +
                        ",SCHEDULED_PAYMENT_AMOUNT_NEW,'" + check(scheduledPaymentAmountNew) + '\'' +
                        ",ARREARS_AMOUNT_OLD,'" + check(arrearsAmountOld) + '\'' +
                        ",ARREARS_AMOUNT_NEW,'" + check(arrearsAmountNew) + '\'' +
                        ",PAYMENT_STATUS_OLD,'" + check(paymentStatusOld) + '\'' +
                        ",PAYMENT_STATUS_NEW,'" + check(paymentStatusNew) + '\'' +
                        ",CURRENCY_CODE,'" + check(currencyCode) + '\'' +
                        ",POSTCODE,'" + check(postcode) + '\'' +
                        ",REGION_CODE,'" + check(regionCode) + '\'' +
                        ",ENQUIRY_REASON_CODE,'" + check(enquiryReasonCode) + '\'' +
                        ",TOTAL_OUTSTANDING_BALANCE_OLD,'" + check(totalOutstandingBalanceOld) + '\'' +
                        ",TOTAL_OUTSTANDING_BALANCE_NEW,'" + check(totalOutstandingBalanceNew) + '\'' +
                        ",TOTAL_MONTHLY_INSTALLMENT_OLD,'" + check(totalMonthlyInstallmentOld) + '\'' +
                        ",TOTAL_MONTHLY_INSTALLMENT_NEW,'" + check(totalMonthlyInstallmentNew) + '\'' +
                        ",TOTAL_CREDIT_LIMIT_OLD,'" + check(totalCreditLimitOld) + '\'' +
                        ",TOTAL_CREDIT_LIMIT_NEW,'" + check(totalCreditLimitNew) + '\'' +
                        ",TOTAL_ARREARS_BALANCE_OLD,'" + check(totalArrearsBalanceOld) + '\'' +
                        ",TOTAL_ARREARS_BALANCE_NEW,'" + check(totalArrearsBalanceNew) + '\'' +
                        ",WORST_CUR_PAY_STATUS_OLD,'" + check(worstCurPayStatusOld) + '\'' +
                        ",WORST_CUR_PAY_STATUS_NEW,'" + check(worstCurPayStatusNew) + '\'' +
                        ",NO_OF_DELINQ_ACC_1_D_OLD,'" + check(noOfDelinqAcc1DOld) + '\'' +
                        ",NO_OF_DELINQ_ACC_1_D_NEW,'" + check(noOfDelinqAcc1DNew) + '\'' +
                        ",NO_OF_DELINQ_ACC_30_D_OLD,'" + check(noOfDelinqAcc30DOld) + '\'' +
                        ",NO_OF_DELINQ_ACC_30_D_NEW,'" + check(noOfDelinqAcc30DNew) + '\'' +
                        ",NO_OF_DELINQ_ACC_60_D_OLD,'" + check(noOfDelinqAcc60DOld) + '\'' +
                        ",NO_OF_DELINQ_ACC_60_D_NEW,'" + check(noOfDelinqAcc60DNew) + '\'' +
                        ",NO_OF_DELINQ_ACC_90_D_OLD,'" + check(noOfDelinqAcc90DOld) + '\'' +
                        ",NO_OF_DELINQ_ACC_90_D_NEW,'" + check(noOfDelinqAcc90DNew) + '\'' +
                        ",NO_OF_ACTIVE_CAIS_ACCOUNT_OLD,'" + check(noOfActiveCaisAccountOld) + '\'' +
                        ",NO_OF_ACTIVE_CAIS_ACCOUNT_NEW,'" + check(noOfActiveCaisAccountNew) + '\'' +
                        ",NO_OF_SUBS_KEEP_ACC_OLD,'" + check(noOfSubsKeepAccOld) + '\'' +
                        ",NO_OF_SUBS_KEEP_ACC_NEW,'" + check(noOfSubsKeepAccNew) + '\'' +
                        ",NO_OF_CAPS_REC_PREV_1_M,'" + check(noOfCapsRecPrev1M) + '\'' +
                        ",NO_OF_CAPS_REC_PREV_2_M,'" + check(noOfCapsRecPrev2M) + '\'' +
                        ",NO_OF_CAPS_REC_PREV_3_M,'" + check(noOfCapsRecPrev3M) + '\'' +
                        ",NO_OF_CAPS_REC_PREV_6_M,'" + check(noOfCapsRecPrev6M) + '\'' +
                        ",RUN_DATE,'" + check(runDate) + '\'';
    }
}
