package ru.usb.consumer_credit_get_trigger_rtm.model.csv;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * ==================================================================================================
 * Состав полей файла ACCNTTRG
 * ==================================================================================================
 * NN	Поле		Комментарий
 * 1	SUBSCRIBER_CODE	-	Код подписчика (SIN)
 * 2	SUBSCRIBER_NAME	-	Наименование подписчика / Краткое описание вида деятельности источника
 * 3	PRIMARY_ID_TYPE	-	Тип основного удостоверяющего документа
 * 4	PRIMARY_ID_NUMBER	-	Номер основного удостоверяющего документа
 * 5	SURNAME	-	Фамилия
 * 6	FORENAME1	-	Имя
 * 7	FORENAME2	-	Отчество
 * 8	BIRTH_DATE	-	Дата рождения
 * 9	TRIGGER_ID	-	Код сработавшего триггера
 * 10	TRIGGER_CREATION_DATE	-	Дата срабатывания триггера
 * 11	OWN_TRIGGER_INDICATOR	-	Индикатор собственного счета Пользователя
 * 12	TRIGGER_DATE	-	Дата события, которое наступило в банке
 * 13	START_DATE	-	Дата открытия счета
 * 14	CLOSED_DATE	-	Дата закрытия счета
 * 15	APPLICANT_TYPE	-	Тип заявителя
 * 16	FINANCE_PRODUCT	-	Тип продукта
 * 17	ACCOUNT_NUMBER	-	Номер счета
 * 18	CREDIT_FACILITY_INDICATOR	-	Статус кредитной линии
 * 19	SPECIAL_STATUS	-	Специальный статус
 * 20	FINANCE_PURPOSE	-	Цель финансирования
 * 21	FINANCE_AMOUNT	-	Размер кредитования (сумма средств), руб.
 * 22	CREDIT_LIMIT_OLD	-	Старое значение кредитного лимита
 * 23	CREDIT_LIMIT_NEW	-	Новое значение кредитного лимита
 * 24	DEFAULT_DATE	-	Дата, когда счет перешел в статус «Неуплата»
 * 25	LITIGATION_DATE	-	Дата принятия судебного акта
 * 26	WRITE_OFF_DATE	-	Дата списания счета
 * 27	LAST_PAYMENT_DATE	-	Дата последнего платежа
 * 28	OUTSTANDING_BALANCE_OLD	-	Старое значение общего объема задолженности по счету
 * 29	OUTSTANDING_BALANCE_NEW	-	Новое значение общего объема задолженности по счету
 * 30	SCHEDULED_PAYMENT_AMOUNT_OLD	-	Старое значение объема планового платежа
 * 31	SCHEDULED_PAYMENT_AMOUNT_NEW	-	Новое значение объема планового платежа
 * 32	ARREARS_AMOUNT_OLD	-	Старое значение объема просроченной задолженности
 * 33	ARREARS_AMOUNT_NEW	-	Новое значение объема просроченной задолженности
 * 34	PAYMENT_STATUS_OLD	-	Старое значение статуса платежа
 * 35	PAYMENT_STATUS_NEW	-	Новое значение статуса платежа
 * 36	CURRENCY_CODE	-	Код валюты счета
 * 37	POSTCODE	-	Почтовый индекс (не уточняется какой именно)
 * 38	REGION_CODE	-	Код региона
 * 39	ENQUIRY_REASON_CODE	-	Цель запроса
 */

public class CsvAccNtTrg {

    //1
    @JsonProperty("SUBSCRIBER_CODE")
    private String subscriberCode;

    //2
    @JsonProperty("SUBSCRIBER_NAME")
    private String subscriberName;

    //3
    @JsonProperty("PRIMARY_ID_TYPE")
    private String primaryIdType;

    //4
    @JsonProperty("PRIMARY_ID_NUMBER")
    private String primaryIdNumber;

    //5
    @JsonProperty("SURNAME")
    private String surname;

    //6
    @JsonProperty("FORENAME1")
    private String forename1;

    //7
    @JsonProperty("FORENAME2")
    private String forename2;

    //8
    @JsonProperty("BIRTH_DATE")
    private String birthDate;

    //9
    @JsonProperty("TRIGGER_ID")
    private String triggerId;

    //10
    @JsonProperty("TRIGGER_CREATION_DATE")
    private String triggerCreationDate;

    //11
    @JsonProperty("OWN_TRIGGER_INDICATOR")
    private String ownTriggerIndicator;

    //12
    @JsonProperty("TRIGGER_DATE")
    private String triggerDate;

    //13
    @JsonProperty("START_DATE")
    private String startDate;

    //14
    @JsonProperty("CLOSED_DATE")
    private String closedDate;

    //15
    @JsonProperty("APPLICANT_TYPE")
    private String applicantType;

    //16
    @JsonProperty("FINANCE_PRODUCT")
    private String financeProduct;

    //17
    @JsonProperty("ACCOUNT_NUMBER")
    private String accountNumber;

    //18
    @JsonProperty("CREDIT_FACILITY_INDICATOR")
    private String creditFacilityIndicator;

    //19
    @JsonProperty("SPECIAL_STATUS")
    private String specialStatus;

    //20
    @JsonProperty("FINANCE_PURPOSE")
    private String financePurpose;

    //21
    @JsonProperty("FINANCE_AMOUNT")
    private String financeAmount;

    //22
    @JsonProperty("CREDIT_LIMIT_OLD")
    private String creditLimitOld;

    //23
    @JsonProperty("CREDIT_LIMIT_NEW")
    private String creditLimitNew;

    //24
    @JsonProperty("DEFAULT_DATE")
    private String defaultDate;

    //25
    @JsonProperty("LITIGATION_DATE")
    private String litigationDate;

    //26
    @JsonProperty("WRITE_OFF_DATE")
    private String writeOffDate;

    //27
    @JsonProperty("LAST_PAYMENT_DATE")
    private String lastPaymentDate;

    //28
    @JsonProperty("OUTSTANDING_BALANCE_OLD")
    private String outstandingBalanceOld;

    //29
    @JsonProperty("OUTSTANDING_BALANCE_NEW")
    private String outstandingBalanceNew;

    //30
    @JsonProperty("SCHEDULED_PAYMENT_AMOUNT_OLD")
    private String scheduledPaymentAmountOld;

    //31
    @JsonProperty("SCHEDULED_PAYMENT_AMOUNT_NEW")
    private String scheduledPaymentAmountNew;

    //32
    @JsonProperty("ARREARS_AMOUNT_OLD")
    private String arrearsAmountOld;

    //33
    @JsonProperty("ARREARS_AMOUNT_NEW")
    private String arrearsAmountNew;

    //34
    @JsonProperty("PAYMENT_STATUS_OLD")
    private String paymentStatusOld;

    //35
    @JsonProperty("PAYMENT_STATUS_NEW")
    private String paymentStatusNew;

    //36
    @JsonProperty("CURRENCY_CODE")
    private String currencyCode;

    //37
    @JsonProperty("POSTCODE")
    private String postcode;

    //38
    @JsonProperty("REGION_CODE")
    private String regionCode;

    //39
    @JsonProperty("ENQUIRY_REASON_CODE")
    private String enquiryReasonCode;

    //40
    @JsonProperty("EXTERNAL_SUBJECT_ID")
    private String externalSubjectId;

    @JsonProperty("FILENAME")
    private String fileName;//Файл

    @JsonProperty("NUMLINE")
    private int numLine;//номер строки


    public CsvAccNtTrg() {
        //empty
    }

    public CsvAccNtTrg(String subscriberCode, String subscriberName, String primaryIdType, String primaryIdNumber,
                       String surname, String forename1, String forename2, String birthDate, String triggerId,
                       String triggerCreationDate, String ownTriggerIndicator, String triggerDate, String startDate,
                       String closedDate, String applicantType, String financeProduct, String accountNumber,
                       String creditFacilityIndicator, String specialStatus, String financePurpose, String financeAmount,
                       String creditLimitOld, String creditLimitNew, String defaultDate, String litigationDate,
                       String writeOffDate, String lastPaymentDate, String outstandingBalanceOld, String outstandingBalanceNew,
                       String scheduledPaymentAmountOld, String scheduledPaymentAmountNew, String arrearsAmountOld,
                       String arrearsAmountNew, String paymentStatusOld, String paymentStatusNew, String currencyCode,
                       String postcode, String regionCode, String enquiryReasonCode, String fileName, int numLine) {
        this.subscriberCode = subscriberCode;
        this.subscriberName = subscriberName;
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.triggerId = triggerId;
        this.triggerCreationDate = triggerCreationDate;
        this.ownTriggerIndicator = ownTriggerIndicator;
        this.triggerDate = triggerDate;
        this.startDate = startDate;
        this.closedDate = closedDate;
        this.applicantType = applicantType;
        this.financeProduct = financeProduct;
        this.accountNumber = accountNumber;
        this.creditFacilityIndicator = creditFacilityIndicator;
        this.specialStatus = specialStatus;
        this.financePurpose = financePurpose;
        this.financeAmount = financeAmount;
        this.creditLimitOld = creditLimitOld;
        this.creditLimitNew = creditLimitNew;
        this.defaultDate = defaultDate;
        this.litigationDate = litigationDate;
        this.writeOffDate = writeOffDate;
        this.lastPaymentDate = lastPaymentDate;
        this.outstandingBalanceOld = outstandingBalanceOld;
        this.outstandingBalanceNew = outstandingBalanceNew;
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
        this.arrearsAmountOld = arrearsAmountOld;
        this.arrearsAmountNew = arrearsAmountNew;
        this.paymentStatusOld = paymentStatusOld;
        this.paymentStatusNew = paymentStatusNew;
        this.currencyCode = currencyCode;
        this.postcode = postcode;
        this.regionCode = regionCode;
        this.enquiryReasonCode = enquiryReasonCode;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public CsvAccNtTrg(String subscriberCode, String subscriberName, String primaryIdType, String primaryIdNumber,
                       String surname, String forename1, String forename2, String birthDate, String triggerId, String triggerCreationDate,
                       String ownTriggerIndicator, String triggerDate, String startDate, String closedDate, String applicantType,
                       String financeProduct, String accountNumber, String creditFacilityIndicator, String specialStatus, String financePurpose,
                       String financeAmount, String creditLimitOld, String creditLimitNew, String defaultDate, String litigationDate,
                       String writeOffDate, String lastPaymentDate, String outstandingBalanceOld, String outstandingBalanceNew,
                       String scheduledPaymentAmountOld, String scheduledPaymentAmountNew, String arrearsAmountOld, String arrearsAmountNew,
                       String paymentStatusOld, String paymentStatusNew, String currencyCode, String postcode, String regionCode,
                       String enquiryReasonCode, String externalSubjectId, String fileName, int numLine) {
        this.subscriberCode = subscriberCode;
        this.subscriberName = subscriberName;
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.triggerId = triggerId;
        this.triggerCreationDate = triggerCreationDate;
        this.ownTriggerIndicator = ownTriggerIndicator;
        this.triggerDate = triggerDate;
        this.startDate = startDate;
        this.closedDate = closedDate;
        this.applicantType = applicantType;
        this.financeProduct = financeProduct;
        this.accountNumber = accountNumber;
        this.creditFacilityIndicator = creditFacilityIndicator;
        this.specialStatus = specialStatus;
        this.financePurpose = financePurpose;
        this.financeAmount = financeAmount;
        this.creditLimitOld = creditLimitOld;
        this.creditLimitNew = creditLimitNew;
        this.defaultDate = defaultDate;
        this.litigationDate = litigationDate;
        this.writeOffDate = writeOffDate;
        this.lastPaymentDate = lastPaymentDate;
        this.outstandingBalanceOld = outstandingBalanceOld;
        this.outstandingBalanceNew = outstandingBalanceNew;
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
        this.arrearsAmountOld = arrearsAmountOld;
        this.arrearsAmountNew = arrearsAmountNew;
        this.paymentStatusOld = paymentStatusOld;
        this.paymentStatusNew = paymentStatusNew;
        this.currencyCode = currencyCode;
        this.postcode = postcode;
        this.regionCode = regionCode;
        this.enquiryReasonCode = enquiryReasonCode;
        this.externalSubjectId = externalSubjectId;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public String getSubscriberCode() {
        return subscriberCode;
    }

    public void setSubscriberCode(String subscriberCode) {
        this.subscriberCode = subscriberCode;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getPrimaryIdType() {
        return primaryIdType;
    }

    public void setPrimaryIdType(String primaryIdType) {
        this.primaryIdType = primaryIdType;
    }

    public String getPrimaryIdNumber() {
        return primaryIdNumber;
    }

    public void setPrimaryIdNumber(String primaryIdNumber) {
        this.primaryIdNumber = primaryIdNumber;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getForename1() {
        return forename1;
    }

    public void setForename1(String forename1) {
        this.forename1 = forename1;
    }

    public String getForename2() {
        return forename2;
    }

    public void setForename2(String forename2) {
        this.forename2 = forename2;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getTriggerCreationDate() {
        return triggerCreationDate;
    }

    public void setTriggerCreationDate(String triggerCreationDate) {
        this.triggerCreationDate = triggerCreationDate;
    }

    public String getOwnTriggerIndicator() {
        return ownTriggerIndicator;
    }

    public void setOwnTriggerIndicator(String ownTriggerIndicator) {
        this.ownTriggerIndicator = ownTriggerIndicator;
    }

    public String getTriggerDate() {
        return triggerDate;
    }

    public void setTriggerDate(String triggerDate) {
        this.triggerDate = triggerDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(String closedDate) {
        this.closedDate = closedDate;
    }

    public String getApplicantType() {
        return applicantType;
    }

    public void setApplicantType(String applicantType) {
        this.applicantType = applicantType;
    }

    public String getFinanceProduct() {
        return financeProduct;
    }

    public void setFinanceProduct(String financeProduct) {
        this.financeProduct = financeProduct;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCreditFacilityIndicator() {
        return creditFacilityIndicator;
    }

    public void setCreditFacilityIndicator(String creditFacilityIndicator) {
        this.creditFacilityIndicator = creditFacilityIndicator;
    }

    public String getSpecialStatus() {
        return specialStatus;
    }

    public void setSpecialStatus(String specialStatus) {
        this.specialStatus = specialStatus;
    }

    public String getFinancePurpose() {
        return financePurpose;
    }

    public void setFinancePurpose(String financePurpose) {
        this.financePurpose = financePurpose;
    }

    public String getFinanceAmount() {
        return financeAmount;
    }

    public void setFinanceAmount(String financeAmount) {
        this.financeAmount = financeAmount;
    }

    public String getCreditLimitOld() {
        return creditLimitOld;
    }

    public void setCreditLimitOld(String creditLimitOld) {
        this.creditLimitOld = creditLimitOld;
    }

    public String getCreditLimitNew() {
        return creditLimitNew;
    }

    public void setCreditLimitNew(String creditLimitNew) {
        this.creditLimitNew = creditLimitNew;
    }

    public String getDefaultDate() {
        return defaultDate;
    }

    public void setDefaultDate(String defaultDate) {
        this.defaultDate = defaultDate;
    }

    public String getLitigationDate() {
        return litigationDate;
    }

    public void setLitigationDate(String litigationDate) {
        this.litigationDate = litigationDate;
    }

    public String getWriteOffDate() {
        return writeOffDate;
    }

    public void setWriteOffDate(String writeOffDate) {
        this.writeOffDate = writeOffDate;
    }

    public String getLastPaymentDate() {
        return lastPaymentDate;
    }

    public void setLastPaymentDate(String lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    public String getOutstandingBalanceOld() {
        return outstandingBalanceOld;
    }

    public void setOutstandingBalanceOld(String outstandingBalanceOld) {
        this.outstandingBalanceOld = outstandingBalanceOld;
    }

    public String getOutstandingBalanceNew() {
        return outstandingBalanceNew;
    }

    public void setOutstandingBalanceNew(String outstandingBalanceNew) {
        this.outstandingBalanceNew = outstandingBalanceNew;
    }

    public String getScheduledPaymentAmountOld() {
        return scheduledPaymentAmountOld;
    }

    public void setScheduledPaymentAmountOld(String scheduledPaymentAmountOld) {
        this.scheduledPaymentAmountOld = scheduledPaymentAmountOld;
    }

    public String getScheduledPaymentAmountNew() {
        return scheduledPaymentAmountNew;
    }

    public void setScheduledPaymentAmountNew(String scheduledPaymentAmountNew) {
        this.scheduledPaymentAmountNew = scheduledPaymentAmountNew;
    }

    public String getArrearsAmountOld() {
        return arrearsAmountOld;
    }

    public void setArrearsAmountOld(String arrearsAmountOld) {
        this.arrearsAmountOld = arrearsAmountOld;
    }

    public String getArrearsAmountNew() {
        return arrearsAmountNew;
    }

    public void setArrearsAmountNew(String arrearsAmountNew) {
        this.arrearsAmountNew = arrearsAmountNew;
    }

    public String getPaymentStatusOld() {
        return paymentStatusOld;
    }

    public void setPaymentStatusOld(String paymentStatusOld) {
        this.paymentStatusOld = paymentStatusOld;
    }

    public String getPaymentStatusNew() {
        return paymentStatusNew;
    }

    public void setPaymentStatusNew(String paymentStatusNew) {
        this.paymentStatusNew = paymentStatusNew;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getEnquiryReasonCode() {
        return enquiryReasonCode;
    }

    public void setEnquiryReasonCode(String enquiryReasonCode) {
        this.enquiryReasonCode = enquiryReasonCode;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getNumLine() {
        return numLine;
    }

    public void setNumLine(int numLine) {
        this.numLine = numLine;
    }

    public String getExternalSubjectId() {
        return externalSubjectId;
    }

    public void setExternalSubjectId(String externalSubjectId) {
        this.externalSubjectId = externalSubjectId;
    }

    @Override
    public String toString() {
        return "CsvAccNtTrg{" +
                "subscriberCode='" + subscriberCode + '\'' +
                ", subscriberName='" + subscriberName + '\'' +
                ", primaryIdType='" + primaryIdType + '\'' +
                ", primaryIdNumber='" + primaryIdNumber + '\'' +
                ", surname='" + surname + '\'' +
                ", forename1='" + forename1 + '\'' +
                ", forename2='" + forename2 + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", triggerId='" + triggerId + '\'' +
                ", triggerCreationDate='" + triggerCreationDate + '\'' +
                ", ownTriggerIndicator='" + ownTriggerIndicator + '\'' +
                ", triggerDate='" + triggerDate + '\'' +
                ", startDate='" + startDate + '\'' +
                ", closedDate='" + closedDate + '\'' +
                ", applicantType='" + applicantType + '\'' +
                ", financeProduct='" + financeProduct + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", creditFacilityIndicator='" + creditFacilityIndicator + '\'' +
                ", specialStatus='" + specialStatus + '\'' +
                ", financePurpose='" + financePurpose + '\'' +
                ", financeAmount='" + financeAmount + '\'' +
                ", creditLimitOld='" + creditLimitOld + '\'' +
                ", creditLimitNew='" + creditLimitNew + '\'' +
                ", defaultDate='" + defaultDate + '\'' +
                ", litigationDate='" + litigationDate + '\'' +
                ", writeOffDate='" + writeOffDate + '\'' +
                ", lastPaymentDate='" + lastPaymentDate + '\'' +
                ", outstandingBalanceOld='" + outstandingBalanceOld + '\'' +
                ", outstandingBalanceNew='" + outstandingBalanceNew + '\'' +
                ", scheduledPaymentAmountOld='" + scheduledPaymentAmountOld + '\'' +
                ", scheduledPaymentAmountNew='" + scheduledPaymentAmountNew + '\'' +
                ", arrearsAmountOld='" + arrearsAmountOld + '\'' +
                ", arrearsAmountNew='" + arrearsAmountNew + '\'' +
                ", paymentStatusOld='" + paymentStatusOld + '\'' +
                ", paymentStatusNew='" + paymentStatusNew + '\'' +
                ", currencyCode='" + currencyCode + '\'' +
                ", postcode='" + postcode + '\'' +
                ", regionCode='" + regionCode + '\'' +
                ", enquiryReasonCode='" + enquiryReasonCode + '\'' +
                '}';
    }

}
