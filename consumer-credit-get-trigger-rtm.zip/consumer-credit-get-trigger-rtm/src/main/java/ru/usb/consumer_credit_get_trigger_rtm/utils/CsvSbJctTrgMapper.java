package ru.usb.consumer_credit_get_trigger_rtm.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.check.CheckCsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class CsvSbJctTrgMapper {

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    Logger log = LoggerFactory.getLogger(CsvSbJctTrgMapper.class);
    private static final String COMMA_DELIMITER = ",";

    private final Config config;

    @Autowired
    public CsvSbJctTrgMapper(Config config) {
        this.config = config;
    }

    /**
     * Маппинг строки в объект
     *
     * @param line       - строка для маппинга
     * @param position   - позиция в строке
     * @param fileName   - имя файла
     * @param lineNumber - номер строки в файле
     * @return - объект
     */
    public CheckCsvSbJctTrg map(String line, CsvSbJctTrgHeadPosition position, String fileName, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        //Пустая срока
        if (values.length < 2) {
            return new CheckCsvSbJctTrg(new CsvSbJctTrg(), new LoadError(lineNumber, fileName, line, "Пустая строка, пропускаем.", new Date(), false), false);
        }
        //Не заполненная строка
        if (values.length < 5) {
            return new CheckCsvSbJctTrg(new CsvSbJctTrg(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        CsvSbJctTrg csvSbJctTrg = new CsvSbJctTrg();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        csvSbJctTrg.setFileName(fileName);
        csvSbJctTrg.setNumLine(lineNumber);

        //1
        try {
            if (position.getPrimaryIdType() > -1) {
                csvSbJctTrg.setPrimaryIdType(check(values[position.getPrimaryIdType()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRIMARY_ID_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRIMARY_ID_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PRIMARY_ID_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PRIMARY_ID_TYPE: ", LG.USBLOGERROR, e);
        }

        //2
        try {
            if (position.getPrimaryIdNumber() > -1) {
                csvSbJctTrg.setPrimaryIdNumber(check(values[position.getPrimaryIdNumber()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRIMARY_ID_NUMBER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRIMARY_ID_NUMBER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PRIMARY_ID_NUMBER: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, PRIMARY_ID_NUMBER: ", LG.USBLOGERROR, e);
        }

        //3
        try {
            if (position.getSurname() > -1) {
                csvSbJctTrg.setSurname(check(values[position.getSurname()]));
            } else {
                setLoadError("Не найден обязательный параметр:SURNAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SURNAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SURNAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, SURNAME: ", LG.USBLOGERROR, e);
        }

        //4
        try {
            if (position.getForename1() > -1) {
                csvSbJctTrg.setForename1(check(values[position.getForename1()]));
            } else {
                setLoadError("Не найден обязательный параметр:FORENAME1", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FORENAME1" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FORENAME1: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FORENAME1: ", LG.USBLOGERROR, e);
        }

        //5
        try {
            if (position.getForename2() > -1) {
                csvSbJctTrg.setForename2(check(values[position.getForename2()]));
            } else {
                setLoadError("Не найден обязательный параметр:FORENAME2", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FORENAME2" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FORENAME2: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, FORENAME2: ", LG.USBLOGERROR, e);
        }

        //6
        try {
            if (position.getBirthDate() > -1) {
                csvSbJctTrg.setBirthDate(check(values[position.getBirthDate()]));
            } else {
                setLoadError("Не найден обязательный параметр:BIRTH_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:BIRTH_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:BIRTH_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, BIRTH_DATE: ", LG.USBLOGERROR, e);
        }

        //7
        try {
            if (position.getTotalOutstandingBalanceOld() > -1) {
                csvSbJctTrg.setTotalOutstandingBalanceOld(check(values[position.getTotalOutstandingBalanceOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_OUTSTANDING_BALANCE_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_OUTSTANDING_BALANCE_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_OUTSTANDING_BALANCE_OLD: ", LG.USBLOGERROR, e);
        }

        //8
        try {
            if (position.getTotalOutstandingBalanceNew() > -1) {
                csvSbJctTrg.setTotalOutstandingBalanceNew(check(values[position.getTotalOutstandingBalanceNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_OUTSTANDING_BALANCE_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_OUTSTANDING_BALANCE_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_OUTSTANDING_BALANCE_NEW: ", LG.USBLOGERROR, e);
        }

        //9
        try {
            if (position.getTotalMonthlyInstallmentOld() > -1) {
                csvSbJctTrg.setTotalMonthlyInstallmentOld(check(values[position.getTotalMonthlyInstallmentOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_MONTHLY_INSTALLMENT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_MONTHLY_INSTALLMENT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_MONTHLY_INSTALLMENT_OLD: ", LG.USBLOGERROR, e);
        }

        //10
        try {
            if (position.getTotalMonthlyInstallmentNew() > -1) {
                csvSbJctTrg.setTotalMonthlyInstallmentNew(check(values[position.getTotalMonthlyInstallmentNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_MONTHLY_INSTALLMENT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_MONTHLY_INSTALLMENT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_MONTHLY_INSTALLMENT_NEW: ", LG.USBLOGERROR, e);
        }

        //11
        try {
            if (position.getTotalCreditLimitOld() > -1) {
                csvSbJctTrg.setTotalCreditLimitOld(check(values[position.getTotalCreditLimitOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_CREDIT_LIMIT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_CREDIT_LIMIT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_CREDIT_LIMIT_OLD: ", LG.USBLOGERROR, e);
        }

        //12
        try {
            if (position.getTotalCreditLimitNew() > -1) {
                csvSbJctTrg.setTotalCreditLimitNew(check(values[position.getTotalCreditLimitNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_CREDIT_LIMIT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_CREDIT_LIMIT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_CREDIT_LIMIT_NEW: ", LG.USBLOGERROR, e);
        }

        //13
        try {
            if (position.getTotalArrearsBalanceOld() > -1) {
                csvSbJctTrg.setTotalArrearsBalanceOld(check(values[position.getTotalArrearsBalanceOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_ARREARS_BALANCE_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_ARREARS_BALANCE_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_ARREARS_BALANCE_OLD: ", LG.USBLOGERROR, e);
        }

        //14
        try {
            if (position.getTotalArrearsBalanceNew() > -1) {
                csvSbJctTrg.setTotalArrearsBalanceNew(check(values[position.getTotalArrearsBalanceNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_ARREARS_BALANCE_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TOTAL_ARREARS_BALANCE_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TOTAL_ARREARS_BALANCE_NEW: ", LG.USBLOGERROR, e);
        }

        //15
        try {
            if (position.getWorstCurrentPaymentStatusOld() > -1) {
                csvSbJctTrg.setWorstCurrentPaymentStatusOld(check(values[position.getWorstCurrentPaymentStatusOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:WORST_CURRENT_PAYMENT_STATUS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:WORST_CURRENT_PAYMENT_STATUS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, WORST_CURRENT_PAYMENT_STATUS_OLD: ", LG.USBLOGERROR, e);
        }

        //16
        try {
            if (position.getWorstCurrentPaymentStatusNew() > -1) {
                csvSbJctTrg.setWorstCurrentPaymentStatusNew(check(values[position.getWorstCurrentPaymentStatusNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:WORST_CURRENT_PAYMENT_STATUS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:WORST_CURRENT_PAYMENT_STATUS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, WORST_CURRENT_PAYMENT_STATUS_NEW: ", LG.USBLOGERROR, e);
        }

        //17
        try {
            if (position.getNoOfDelinqAcc1DOld() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc1DOld(check(values[position.getNoOfDelinqAcc1DOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD: ", LG.USBLOGERROR, e);
        }

        //18
        try {
            if (position.getNoOfDelinqAcc1DNew() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc1DNew(check(values[position.getNoOfDelinqAcc1DNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW: ", LG.USBLOGERROR, e);
        }

        //19
        try {
            if (position.getNoOfDelinqAcc30DOld() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc30DOld(check(values[position.getNoOfDelinqAcc30DOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD: ", LG.USBLOGERROR, e);
        }

        //20
        try {
            if (position.getNoOfDelinqAcc30DNew() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc30DNew(check(values[position.getNoOfDelinqAcc30DNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW: ", LG.USBLOGERROR, e);
        }

        //21
        try {
            if (position.getNoOfDelinqAcc60DOld() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc60DOld(check(values[position.getNoOfDelinqAcc60DOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD: ", LG.USBLOGERROR, e);
        }

        //22
        try {
            if (position.getNoOfDelinqAcc60DNew() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc60DNew(check(values[position.getNoOfDelinqAcc60DNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW: ", LG.USBLOGERROR, e);
        }

        //23
        try {
            if (position.getNoOfDelinqAcc90DOld() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc90DOld(check(values[position.getNoOfDelinqAcc90DOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD: ", LG.USBLOGERROR, e);
        }

        //24
        try {
            if (position.getNoOfDelinqAcc90DNew() > -1) {
                csvSbJctTrg.setNoOfDelinqAcc90DNew(check(values[position.getNoOfDelinqAcc90DNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW: ", LG.USBLOGERROR, e);
        }

        //25
        try {
            if (position.getNoOfActiveCaisAccountOld() > -1) {
                csvSbJctTrg.setNoOfActiveCaisAccountOld(check(values[position.getNoOfActiveCaisAccountOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_ACTIVE_CAIS_ACCOUNT_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_ACTIVE_CAIS_ACCOUNT_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_ACTIVE_CAIS_ACCOUNT_OLD: ", LG.USBLOGERROR, e);
        }

        //26
        try {
            if (position.getNoOfActiveCaisAccountNew() > -1) {
                csvSbJctTrg.setNoOfActiveCaisAccountNew(check(values[position.getNoOfActiveCaisAccountNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_ACTIVE_CAIS_ACCOUNT_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_ACTIVE_CAIS_ACCOUNT_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_ACTIVE_CAIS_ACCOUNT_NEW: ", LG.USBLOGERROR, e);
        }

        //27
        try {
            if (position.getNoOfSubsKeepAccOld() > -1) {
                csvSbJctTrg.setNoOfSubsKeepAccOld(check(values[position.getNoOfSubsKeepAccOld()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_SUBS_KEEP_ACC_OLD" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_SUBS_KEEP_ACC_OLD: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_SUBS_KEEP_ACC_OLD: ", LG.USBLOGERROR, e);
        }

        //28
        try {
            if (position.getNoOfSubsKeepAccNew() > -1) {
                csvSbJctTrg.setNoOfSubsKeepAccNew(check(values[position.getNoOfSubsKeepAccNew()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_SUBS_KEEP_ACC_NEW" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_SUBS_KEEP_ACC_NEW: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_SUBS_KEEP_ACC_NEW: ", LG.USBLOGERROR, e);
        }

        //29
        try {
            if (position.getNoOfCapsRecPrev1M() > -1) {
                csvSbJctTrg.setNoOfCapsRecPrev1M(check(values[position.getNoOfCapsRecPrev1M()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_CAPS_REC_PREV_1M" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_CAPS_REC_PREV_1M: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_CAPS_REC_PREV_1M: ", LG.USBLOGERROR, e);
        }

        //30
        try {
            if (position.getNoOfCapsRecPrev2M() > -1) {
                csvSbJctTrg.setNoOfCapsRecPrev2M(check(values[position.getNoOfCapsRecPrev2M()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_CAPS_REC_PREV_2M" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_CAPS_REC_PREV_2M: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_CAPS_REC_PREV_2M: ", LG.USBLOGERROR, e);
        }

        //31
        try {
            if (position.getNoOfCapsRecPrev3M() > -1) {
                csvSbJctTrg.setNoOfCapsRecPrev3M(check(values[position.getNoOfCapsRecPrev3M()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_CAPS_REC_PREV_3M" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_CAPS_REC_PREV_3M: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_CAPS_REC_PREV_3M: ", LG.USBLOGERROR, e);
        }

        //32
        try {
            if (position.getNoOfCapsRecPrev6M() > -1) {
                csvSbJctTrg.setNoOfCapsRecPrev6M(check(values[position.getNoOfCapsRecPrev6M()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NO_OF_CAPS_REC_PREV_6M" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NO_OF_CAPS_REC_PREV_6M: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, NO_OF_CAPS_REC_PREV_6M: ", LG.USBLOGERROR, e);
        }

        //33
        try {
            if (position.getTriggerId() > -1) {
                csvSbJctTrg.setTriggerId(check(values[position.getTriggerId()]));
            } else {
                setLoadError("Не найден обязательный параметр::TRIGGER_ID", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TRIGGER_ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TRIGGER_ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, TRIGGER_ID: ", LG.USBLOGERROR, e);
        }

        //34
        try {
            if (position.getRunDate() > -1) {
                csvSbJctTrg.setRunDate(check(values[position.getRunDate()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:RUN_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:RUN_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, RUN_DATE: ", LG.USBLOGERROR, e);
        }

        //35
        // externalSubjectId
        try {
            if (position.getExternalSubjectId() > -1) {
                csvSbJctTrg.setExternalSubjectId(check(values[position.getExternalSubjectId()]));
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:EXTERNAL_SUBJECT_ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:EXTERNAL_SUBJECT_ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, EXTERNAL_SUBJECT_ID: ", LG.USBLOGERROR, e);
        }


        //Возврат
        return new CheckCsvSbJctTrg(csvSbJctTrg, loadError, true);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote1(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("'", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote2(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("\"", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getFirstQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String firstChar = line.substring(0, 1);
            if (firstChar.equalsIgnoreCase("\"")) {
                return line.substring(1, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка
     * @param line -
     * @return
     */
    public String getLastQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String lastChar = line.substring(line.length() - 1);
            if (lastChar.equalsIgnoreCase("\"")) {
                return line.substring(0, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка над строкой
     * @param line - строка
     * @return - строка
     */
    public String getLineTrim(String line){
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (') следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String check(String line) {
        return rQuote1(rQuote2(getLastQuote(getFirstQuote(getLineTrim(line))))).trim();
    }

}
