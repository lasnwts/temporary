package ru.usb.consumer_credit_get_trigger_rtm.service.csv;

import org.springframework.stereotype.Component;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;

/**
 *    Поля (Filed)
 * SUBSCRIBER_CODE
 * SUBSCRIBER_NAME
 * PRIMARY_ID_TYPE
 * PRIMARY_ID_NUMBER
 * SURNAME
 * FORENAME1
 * FORENAME2
 * BIRTH_DATE
 * TRIGGER_ID
 * TRIGGER_CREATION_DATE
 * OWN_TRIGGER_INDICATOR
 * TRIGGER_DATE
 * START_DATE
 * CLOSED_DATE
 * APPLICANT_TYPE
 * FINANCE_PRODUCT
 * ACCOUNT_NUMBER
 * CREDIT_FACILITY_INDICATOR
 * SPECIAL_STATUS
 * FINANCE_PURPOSE
 * FINANCE_AMOUNT
 * CREDIT_LIMIT_OLD
 * CREDIT_LIMIT_NEW
 * DEFAULT_DATE
 * LITIGATION_DATE
 * WRITE_OFF_DATE
 * LAST_PAYMENT_DATE
 * OUTSTANDING_BALANCE_OLD
 * OUTSTANDING_BALANCE_NEW
 * SCHEDULED_PAYMENT_AMOUNT_OLD
 * SCHEDULED_PAYMENT_AMOUNT_NEW
 * ARREARS_AMOUNT_OLD
 * ARREARS_AMOUNT_NEW
 * PAYMENT_STATUS_OLD
 * PAYMENT_STATUS_NEW
 * CURRENCY_CODE
 * POSTCODE
 * REGION_CODE
 * ENQUIRY_REASON_CODE
 */
@Component
public class CsvAccNtTrgHeadMap {

    private static final String COMMA_DELIMITER = ",";

    /**
     * Маппинг строки в объект
     * @param line - строка из файла с заголовками
     * @return - объект CsvAccNtTrgHeadPosition
     */
    public CsvAccNtTrgHeadPosition map(String line) {
        CsvAccNtTrgHeadPosition csvAccNtTrgHeadPosition = new CsvAccNtTrgHeadPosition();
        String[] values = line.split(COMMA_DELIMITER);
        if (values.length == 0) {
            csvAccNtTrgHeadPosition.setTitlePresent(false);
            return csvAccNtTrgHeadPosition;
        }
        //1
        csvAccNtTrgHeadPosition.setSubscriberCode(getPosition("SUBSCRIBER_CODE", values));
        //2
        csvAccNtTrgHeadPosition.setSubscriberName(getPosition("SUBSCRIBER_NAME", values));
        //3
        csvAccNtTrgHeadPosition.setPrimaryIdType(getPosition("PRIMARY_ID_TYPE", values));
        //4
        csvAccNtTrgHeadPosition.setPrimaryIdNumber(getPosition("PRIMARY_ID_NUMBER", values));
        //5
        csvAccNtTrgHeadPosition.setSurname(getPosition("SURNAME", values));
        //6
        csvAccNtTrgHeadPosition.setForename1(getPosition("FORENAME1", values));
        //7
        csvAccNtTrgHeadPosition.setForename2(getPosition("FORENAME2", values));
        //8
        csvAccNtTrgHeadPosition.setBirthDate(getPosition("BIRTH_DATE", values));
        //9
        csvAccNtTrgHeadPosition.setTriggerId(getPosition("TRIGGER_ID", values));
        //10
        csvAccNtTrgHeadPosition.setTriggerCreationDate(getPosition("TRIGGER_CREATION_DATE", values));
        //11
        csvAccNtTrgHeadPosition.setOwnTriggerIndicator(getPosition("OWN_TRIGGER_INDICATOR", values));
        //12
        csvAccNtTrgHeadPosition.setTriggerDate(getPosition("TRIGGER_DATE", values));
        //13
        csvAccNtTrgHeadPosition.setStartDate(getPosition("START_DATE", values));
        //14
        csvAccNtTrgHeadPosition.setClosedDate(getPosition("CLOSED_DATE", values));
        //15
        csvAccNtTrgHeadPosition.setApplicantType(getPosition("APPLICANT_TYPE", values));
        //16
        csvAccNtTrgHeadPosition.setFinanceProduct(getPosition("FINANCE_PRODUCT", values));
        //17
        csvAccNtTrgHeadPosition.setAccountNumber(getPosition("ACCOUNT_NUMBER", values));
        //18
        csvAccNtTrgHeadPosition.setCreditFacilityIndicator(getPosition("CREDIT_FACILITY_INDICATOR", values));
        //19
        csvAccNtTrgHeadPosition.setSpecialStatus(getPosition("SPECIAL_STATUS", values));
        //20
        csvAccNtTrgHeadPosition.setFinancePurpose(getPosition("FINANCE_PURPOSE", values));
        //21
        csvAccNtTrgHeadPosition.setFinanceAmount(getPosition("FINANCE_AMOUNT", values));
        //22
        csvAccNtTrgHeadPosition.setCreditLimitOld(getPosition("CREDIT_LIMIT_OLD", values));
        //23
        csvAccNtTrgHeadPosition.setCreditLimitNew(getPosition("CREDIT_LIMIT_NEW", values));
        //24
        csvAccNtTrgHeadPosition.setDefaultDate(getPosition("DEFAULT_DATE", values));
        //25
        csvAccNtTrgHeadPosition.setLitigationDate(getPosition("LITIGATION_DATE", values));
        //26
        csvAccNtTrgHeadPosition.setWriteOffDate(getPosition("WRITE_OFF_DATE", values));
        //27
        csvAccNtTrgHeadPosition.setLastPaymentDate(getPosition("LAST_PAYMENT_DATE", values));
        //28
        csvAccNtTrgHeadPosition.setOutstandingBalanceOld(getPosition("OUTSTANDING_BALANCE_OLD", values));
        //29
        csvAccNtTrgHeadPosition.setOutstandingBalanceNew(getPosition("OUTSTANDING_BALANCE_NEW", values));
        //30
        csvAccNtTrgHeadPosition.setScheduledPaymentAmountOld(getPosition("SCHEDULED_PAYMENT_AMOUNT_OLD", values));
        //31
        csvAccNtTrgHeadPosition.setScheduledPaymentAmountNew(getPosition("SCHEDULED_PAYMENT_AMOUNT_NEW", values));
        //32
        csvAccNtTrgHeadPosition.setArrearsAmountOld(getPosition("ARREARS_AMOUNT_OLD", values));
        //33
        csvAccNtTrgHeadPosition.setArrearsAmountNew(getPosition("ARREARS_AMOUNT_NEW", values));
        //34
        csvAccNtTrgHeadPosition.setPaymentStatusOld(getPosition("PAYMENT_STATUS_OLD", values));
        //35
        csvAccNtTrgHeadPosition.setPaymentStatusNew(getPosition("PAYMENT_STATUS_NEW", values));
        //36
        csvAccNtTrgHeadPosition.setCurrencyCode(getPosition("CURRENCY_CODE", values));
        //37
        csvAccNtTrgHeadPosition.setPostcode(getPosition("POSTCODE", values));
        //38
        csvAccNtTrgHeadPosition.setRegionCode(getPosition("REGION_CODE", values));
        //39
        csvAccNtTrgHeadPosition.setEnquiryReasonCode(getPosition("ENQUIRY_REASON_CODE", values));
        //40
        csvAccNtTrgHeadPosition.setExternalSubjectId(getPosition("EXTERNAL_SUBJECT_ID", values));
        csvAccNtTrgHeadPosition.setTitlePresent(true);
        return csvAccNtTrgHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }

}
