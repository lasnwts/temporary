package ru.usb.consumer_credit_get_trigger_rtm.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvSbJctTrgHeadPosition;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadFileCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadFileCsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadHeadCsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.csv.LoadHeadCsvSbJctTrg;
import ru.usb.consumer_credit_get_trigger_rtm.service.mail.ServiceMailError;
import ru.usb.consumer_credit_get_trigger_rtm.utils.Support;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class FlowFileOperation {

    private static final String SUBJECT = "Ошибка при обработке файла типа:[ACCNTTRG] триггеров РТМ";

    private final Config config;
    private final LoadFileCsvAccNtTrg loadFileCsvAccNtTrg;
    private final LoadFileCsvSbJctTrg loadFileCsvSbJctTrg;
    private final LoadHeadCsvAccNtTrg loadHeadCsvAccNtTrg;
    private final LoadHeadCsvSbJctTrg loadHeadCsvSbJctTrg;
    private final Support support;
    private final ServiceMailError serviceMailError;

    @Autowired
    public FlowFileOperation(Config config, LoadFileCsvAccNtTrg loadFileCsvAccNtTrg, LoadFileCsvSbJctTrg loadFileCsvSbJctTrg,
                             LoadHeadCsvAccNtTrg loadHeadCsvAccNtTrg, LoadHeadCsvSbJctTrg loadHeadCsvSbJctTrg, Support support,
                             ServiceMailError serviceMailError) {
        this.config = config;
        this.loadFileCsvAccNtTrg = loadFileCsvAccNtTrg;
        this.loadFileCsvSbJctTrg = loadFileCsvSbJctTrg;
        this.loadHeadCsvAccNtTrg = loadHeadCsvAccNtTrg;
        this.loadHeadCsvSbJctTrg = loadHeadCsvSbJctTrg;
        this.support = support;
        this.serviceMailError = serviceMailError;
    }

    Logger logger = LoggerFactory.getLogger(FlowFileOperation.class);

    /**
     * Старт обработки файлов
     */
    public void start() {
        logger.debug("{}:FileOperation start processed...", LG.USBLOGINFO);
        if (!support.checkDirExists(support.getPaths(config.getFileUrl()))) {
            logger.error("{} Директория с файлами:{} недоступна! ", LG.USBLOGERROR, config.getFileUrl());
            serviceMailError.sendMailErrorSubject(SUBJECT, "Директория с файлами недоступна сервису! " + config.getFileUrl());
            return;
        }
        //Получаем список файлов
        Optional<List<String>> listFiles = support.listFilesController(config.getFileUrl() + "in/");

        try {
            //Обрабатываем файлы
            if (listFiles.isPresent()) {
                logger.debug("listFiles.isPresent() = true");
                logger.debug("listFiles.size() = {}", listFiles.get().size());
                for (String fileName : listFiles.get()) {
                    File file = new File(fileName);
                    if (!file.exists() || !file.isFile()) {
                        continue;
                    }
                    //!fileName.contains("ACCNTTRG") ||
                    if (fileName.toUpperCase().contains("ACCNTTRG") && support.checkFileDone(fileName)) {
                        Optional<CsvAccNtTrgHeadPosition> csvAccNtTrgHeadPosition = loadHeadCsvAccNtTrg.loadFile(file, fileName, 1);
                        if (csvAccNtTrgHeadPosition.isPresent()) {
                            List<LoadError> loadErrors = loadFileCsvAccNtTrg.loadFile(file, fileName, csvAccNtTrgHeadPosition.get(), 1, false);
                            //Если все в порядке, то копируем в папку out
                            if (loadErrors.isEmpty()) {
                                File fileOut = new File(config.getFileUrl() + "out/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                            } else {
                                logger.warn("{}:!!!![ACCNTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                                serviceMailError.sendMailErrorSubject(SUBJECT, getLogger(loadErrors));
                                File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                            }
                        } else {
                            logger.warn("{}:!!!![ACCNTTRG] csvAccNtTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                            serviceMailError.sendMailErrorSubject(SUBJECT, "Файл не содержит заголовок:" + file.getAbsolutePath());
                            File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                            support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                        }
                    }
                    //SBJCTTRG
                    if (fileName.toUpperCase().contains("SBJCTTRG") && support.checkFileDone(fileName)) {
                        Optional<CsvSbJctTrgHeadPosition> csvSbJctTrgHeadPosition = loadHeadCsvSbJctTrg.loadFile(file, fileName, 1);
                        if (csvSbJctTrgHeadPosition.isPresent()) {
                            List<LoadError> loadErrors = loadFileCsvSbJctTrg.loadFile(file, fileName, csvSbJctTrgHeadPosition.get(), 1, false);
                            //Если все в порядке, то копируем в папку out
                            if (loadErrors.isEmpty()) {
                                File fileOut = new File(config.getFileUrl() + "out/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                            } else {
                                logger.warn("{}:!!!![SBJCTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                                serviceMailError.sendMailErrorSubject(SUBJECT, getLogger(loadErrors));
                                File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                            }
                        } else {
                            logger.warn("{}:!!!![SBJCTTRG] CsvSbJctTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                            serviceMailError.sendMailErrorSubject(SUBJECT, "Файл не содержит заголовок:" + file.getAbsolutePath());
                            File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                            support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                        }
                    }
                }
            } else {
                logger.info("{}: Optional<List<String>> listFiles() = false", LG.USBLOGINFO);
            }
        } catch (InterruptedException e) {
            serviceMailError.sendMailErrorSubject("Ошибка при обработке файла триггеров РТМ", e.getMessage());
            logger.error("{}", e.getMessage());
            Thread.currentThread().interrupt();
        }
        logger.debug("{}: end processed....", LG.USBLOGINFO);
    }


    /**
     * Обработка файла
     * переданного по Web API
     *
     * @param file - файл
     */
    public List<LoadError> processedFile(File file) {
        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем
        if (!file.exists() || !file.isFile()) {
            logger.warn("{}:!!!![processedFile] file:{} is not exists or is not file !!!!", LG.USBLOGWARNING, file.getAbsolutePath());
            LoadError loadError = new LoadError(0, file.getName(), "Файл не существует или не является файлом", "Ошибка загрузки файла", new Date(), true);
            loadErrorList.add(loadError);
            return loadErrorList;
        }
        try {
            //!fileName.contains("ACCNTTRG") ||
            if (file.getName().toUpperCase().contains("ACCNTTRG") && support.checkFileDone(file.getAbsolutePath())) {
                Optional<CsvAccNtTrgHeadPosition> csvAccNtTrgHeadPosition = loadHeadCsvAccNtTrg.loadFile(file, file.getAbsolutePath(), 1);
                if (csvAccNtTrgHeadPosition.isPresent()) {
                    List<LoadError> loadErrors = loadFileCsvAccNtTrg.loadFile(file, file.getAbsolutePath(), csvAccNtTrgHeadPosition.get(), 1, false);
                    //Если все в порядке, то копируем в папку out
                    if (loadErrors.isEmpty()) {
                        File fileOut = new File(config.getFileUrl() + "out/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                    } else {
                        logger.warn("{}:!!!![processedFile-ACCNTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                        serviceMailError.sendMailErrorSubject(SUBJECT, getLogger(loadErrors));
                        File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                    }
                } else {
                    logger.warn("{}:!!!![processedFile-ACCNTTRG] csvAccNtTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                    serviceMailError.sendMailErrorSubject(SUBJECT, "Файл загружается через Web API[ACCNTTRG]:" + file.getAbsolutePath());
                    File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                    support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                }
            }
            //SBJCTTRG
            if (file.getName().toUpperCase().contains("SBJCTTRG") && support.checkFileDone(file.getAbsolutePath())) {
                Optional<CsvSbJctTrgHeadPosition> csvSbJctTrgHeadPosition = loadHeadCsvSbJctTrg.loadFile(file, file.getAbsolutePath(), 1);
                if (csvSbJctTrgHeadPosition.isPresent()) {
                    List<LoadError> loadErrors = loadFileCsvSbJctTrg.loadFile(file, file.getAbsolutePath(), csvSbJctTrgHeadPosition.get(), 1, false);
                    //Если все в порядке, то копируем в папку out
                    if (loadErrors.isEmpty()) {
                        File fileOut = new File(config.getFileUrl() + "out/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                    } else {
                        logger.warn("{}:!!!![processedFile-SBJCTTRG] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                        serviceMailError.sendMailErrorSubject(SUBJECT, getLogger(loadErrors));
                        File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                    }
                } else {
                    logger.warn("{}:!!!![processedFile-SBJCTTRG] CsvSbJctTrgHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                    serviceMailError.sendMailErrorSubject(SUBJECT, "Файл загружается через Web API[SBJCTTRG]:" + file.getAbsolutePath());
                    File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                    support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                }
            }
            LoadError loadError = new LoadError(0, file.getName(), "Обработка файла: " + file.getName() + " успешно завершена", "", new Date(), false);
            loadErrorList.add(loadError);
            return loadErrorList;
        } catch (InterruptedException e) {
            logger.warn("{}: Произошла ошибка: {}, при обработке файла:{}, загруженного через Web API.", LG.USBLOGWARNING, e.getMessage(), file.getName());
            LoadError loadError = new LoadError(0, file.getName(), "Обработка файла" + file.getName(), "Ошибка обработки файла" + e.getMessage(), new Date(), true);
            loadErrorList.add(loadError);
            Thread.currentThread().interrupt();
            return loadErrorList;
        }
    }


    /**
     * Формируем сообщение об ошибке
     *
     * @param loadErrors - список ошибок
     * @return - сообщение об ошибке
     */
    private String getLogger(List<LoadError> loadErrors) {
        StringBuilder message = new StringBuilder(" ");
        for (LoadError loadError : loadErrors) {
            logger.warn("{}: loadError = {}", LG.USBLOGWARNING, loadError);
            message.append(loadError.toString()).append("\n");
        }
        return message.toString();
    }

}
