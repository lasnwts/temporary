package ru.usb.consumer_credit_get_trigger_rtm.model.check;

import ru.usb.consumer_credit_get_trigger_rtm.model.csv.CsvAccNtTrg;
import ru.usb.consumer_credit_get_trigger_rtm.model.csv.LoadError;

public class CheckCsvAccNtTrg {

    private CsvAccNtTrg csvAccNtTrg;
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация

    public CheckCsvAccNtTrg() {
        //empty
    }

    public CheckCsvAccNtTrg(CsvAccNtTrg csvAccNtTrg, LoadError loadError, boolean exists) {
        this.csvAccNtTrg = csvAccNtTrg;
        this.loadError = loadError;
        this.exists = exists;
    }

    public CsvAccNtTrg getCsvAccNtTrg() {
        return csvAccNtTrg;
    }

    public void setCsvAccNtTrg(CsvAccNtTrg csvAccNtTrg) {
        this.csvAccNtTrg = csvAccNtTrg;
    }

    public LoadError getLoadError() {
        return loadError;
    }

    public void setLoadError(LoadError loadError) {
        this.loadError = loadError;
    }

    public boolean isExists() {
        return exists;
    }

    public void setExists(boolean exists) {
        this.exists = exists;
    }
}
