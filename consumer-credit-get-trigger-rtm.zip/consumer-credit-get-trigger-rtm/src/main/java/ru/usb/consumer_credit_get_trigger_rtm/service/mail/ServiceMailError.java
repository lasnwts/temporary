package ru.usb.consumer_credit_get_trigger_rtm.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;
import ru.usb.consumer_credit_get_trigger_rtm.model.MessageError;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class ServiceMailError {

    public static final long MINUTE = 60000; // 1 минута

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ServiceMailError.class);

    private final MessageError messageError;
    private final Config config;
    private final EmailService emailService;

    @Autowired
    public ServiceMailError(MessageError messageError, Config config, EmailService emailService) {
        this.messageError = messageError;
        this.config = config;
        this.emailService = emailService;
    }

    /**
     * Проверка когда отправляли почту в последний раз
     *
     * @return -- true - можно отправлять письмо, false - еще не прошло время с последней отправки
     */
    public boolean checkMail() {
        if (messageError.getDate() == null) {
            logger.info("{}: Email error еще ни разу не отправлялся с момента запуска сервиса, можно отправлять.", LG.USBLOGINFO);
            return true;
        } else {
            String slog = "Email error был отправлен:" + getFormattedDate(messageError.getDate()) +
                    ", сейчас::"+getFormattedDate(new Date())+" что превысило время ожидания в минутах: "+ config.getMailDelayMinutes();

            if (new Date().after(new Date(messageError.getDate().getTime() + config.getMailDelayMinutes() * MINUTE))) {
                logger.info("{}:{},{}", LG.USBLOGINFO, slog, " - можно отправлять");
                return true;
            } else {
                logger.info("{}:{},{}", LG.USBLOGINFO, slog, " - отправлять нельзя!");
                return false;
            }
        }
    }

    /**
     * Отправка почтового сообщения администраторам
     *
     * @param body - тело сообщения
     */
    public void sendMailError(String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(config.getMailTo(), config.getMailSubjects(), body);
            messageError.setBody(body);
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(config.getMailSubjects());
            messageError.setDate(new Date());
            logger.info("{} Отправлено письмо по адресам:{} Сообщение=:{}", LG.USBLOGINFO, config.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailErrorSubject(String subject, String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(config.getMailTo(), subject, body);
            messageError.setBody(getWnull(body));
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(getWnull(config.getMailSubjects()));
            messageError.setDate(new Date());
            logger.info("{}: Отправлено письмо по адресам:{} Сообщение:{}", LG.USBLOGINFO, config.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailSubject(String subject, String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(config.getMailTo(), subject, body);
            messageError.setBody(getWnull(body));
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(getWnull(config.getMailSubjects()));
            messageError.setDate(new Date());
            logger.info("{}:[sendMailSubject] Отправлено письмо по адресам:{} Сообщение:{}", LG.USBLOGINFO, config.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailBusinessSubject(String subject, String body) {
        emailService.sendSimpleEmail(config.getMailToBusiness(), subject, body);
        messageError.setBody(body);
        messageError.setCount(messageError.getCount() + 1);
        messageError.setSubject(config.getMailSubjects());
        messageError.setDate(new Date());
        logger.info("{}: Отправлено письмо по адресам:{}, тема:{} Сообщение :{}", LG.USBLOGINFO, config.getMailTo(), subject, messageError);
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWnull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Преобразуем даты в строку
     *
     * @param date - дата
     * @return - строка с датой
     */
    private String getFormattedDate(Date date) {
        if (date == null) {
            logger.error("{}: [getFormattedDate] вместо date передан NULL", LG.USBLOGWARNING);
            return "";
        }
        try {
            return getWnull(sdf.format(date));
        } catch (Exception e) {
            logger.error("{}: [getFormattedDate] возникла ошибка при преобразовании даты в строку", LG.USBLOGWARNING);
            return "";
        }

    }
}
