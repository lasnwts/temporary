package ru.usb.consumer_credit_get_trigger_rtm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.consumer_credit_get_trigger_rtm.config.Config;
import ru.usb.consumer_credit_get_trigger_rtm.config.LG;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;

@Service
public class ApiLayer {

    private final Config config;
    private final Logger logger = LoggerFactory.getLogger(ApiLayer.class);


    @Autowired
    public ApiLayer(Config config) {
        this.config = config;
    }



    /**
     * Установка включения сервиса
     *
     * @param enabled - true - сервис включен, false - сервис выключен
     */
    public void setServiceEnabled(boolean enabled) {
        config.setServiceEnabled(enabled);
    }

    /**
     * Включен или выключен сервис
     *
     * @return -  - true - сервис включен, false - сервис выключен
     */
    public boolean getServiceEnabled() {
        return config.isServiceEnabled();
    }

    /**
     * Запись файла во временный каталог
     *
     * @param name    - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare() + FileSystems.getDefault().getSeparator() +
                name);
        if (file.canWrite()) {
            logger.debug("{}:file.canWrite()=true", LG.USBLOGINFO);
        }
        if (file.canRead()) {
            logger.debug("{}:file.canRead()=true", LG.USBLOGINFO);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     * @return - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(1000);
            if (Files.deleteIfExists(facFile.toPath())) {
                logger.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, facFile.getAbsolutePath());
            } else {
                logger.info("{}: Файл:{} не был удален из временной директории!", LG.USBLOGINFO, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            logger.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.USBLOGERROR, facFile.getAbsolutePath(), e.getMessage());
            logger.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            Thread.currentThread().interrupt();
        }
    }



}
