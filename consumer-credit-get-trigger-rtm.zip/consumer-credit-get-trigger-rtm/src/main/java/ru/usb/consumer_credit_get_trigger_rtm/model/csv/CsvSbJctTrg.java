package ru.usb.consumer_credit_get_trigger_rtm.model.csv;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * =============================================================================================
 * Состав полей файла SBJCTTRG
 * =============================================================================================
 * Поле		Комментарий
 * 1	PRIMARY_ID_TYPE	-	Тип основного удостоверяющего документа
 * 2	PRIMARY_ID_NUMBER	-	Номер основного удостоверяющего документа
 * 3	SURNAME	-	Фамилия
 * 4	FORENAME1	-	Имя
 * 5	FORENAME2	-	Отчество
 * 6	BIRTH_DATE	-	Дата рождения
 * 7	TOTAL_OUTSTANDING_BALANCE_OLD	-	Старое значение объема задолженности по всем счетам
 * 8	TOTAL_OUTSTANDING_BALANCE_NEW	-	Новое значение объема задолженности по всем счетам
 * 9	TOTAL_MONTHLY_INSTALLMENT_OLD	-	Старое значение размера ежемесячного платежа
 * 10	TOTAL_MONTHLY_INSTALLMENT_NEW	-	Новое значение размера ежемесячного платежа
 * 11	TOTAL_CREDIT_LIMIT_OLD	-	Старое значение общего кредитного лимита
 * 12	TOTAL_CREDIT_LIMIT_NEW	-	Новое значение общего кредитного лимита
 * 13	TOTAL_ARREARS_BALANCE_OLD	-	Старое значение объема просроченной задолженности
 * 14	TOTAL_ARREARS_BALANCE_NEW	-	Новое значение объема просроченной задолженности
 * 15	WORST_CURRENT_PAYMENT_STATUS_OLD	-	Старое значение наихудшего платежного статуса по всем счетам
 * 16	WORST_CURRENT_PAYMENT_STATUS_NEW	-	Новое значение наихудшего платежного статуса по всем счетам
 * 17	NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD	-	Старое значение количества счетов с просрочкой в 1+ дней
 * 18	NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW	-	Новое значение количества счета с просрочкой в 1+ дней
 * 19	NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD	-	Старое значение количества счетов с просрочкой в 30+ дней
 * 20	NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW	-	Новое значение количества счета с просрочкой в 30+ дней
 * 21	NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD	-	Старое значение количества счетов с просрочкой в 60+ дней
 * 22	NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW	-	Новое значение количества счета с просрочкой в 60+ дней
 * 23	NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD	-	Старое значение количества счетов с просрочкой в 90+ дней
 * 24	NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW	-	Новое значение количества счета с просрочкой в 90+ дней
 * 25	NO_OF_ACTIVE_CAIS_ACCOUNT_OLD	-	Старое значение общего количества активных счетов
 * 26	NO_OF_ACTIVE_CAIS_ACCOUNT_NEW	-	Новое значение общего количества активных счетов
 * 27	NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_OLD	-	Старое значение количества банков, где размещены кредитные счета клиента
 * 28	NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_NEW	-	Новое значение количества банков, где размещены кредитные счета клиента
 * 29	NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_1_MONTH	-	Количество запросов на кредит за последний месяц
 * 30	NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_2_MONTH	-	Количество запросов на кредит за последние 2 месяца
 * 31	NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_3_MONTH	-	Количество запросов на кредит за последние 3 месяца
 * 32	NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_6_MONTH	-	Количество запросов на кредит за последние 6 месяцев
 * 33	TRIGGER_ID	-	Код сработавшего триггера
 * 34	RUN_DATE	-	Дата срабатывания триггера
 */

public class CsvSbJctTrg {
    //1
    @JsonProperty("PRIMARY_ID_TYPE")
    private String primaryIdType;
    //2
    @JsonProperty("PRIMARY_ID_NUMBER")
    private String primaryIdNumber;
    //3
    @JsonProperty("SURNAME")
    private String surname;
    //4
    @JsonProperty("FORENAME1")
    private String forename1;
    //5
    @JsonProperty("FORENAME2")
    private String forename2;
    //6
    @JsonProperty("BIRTH_DATE")
    private String birthDate;
    //7
    @JsonProperty("TOTAL_OUTSTANDING_BALANCE_OLD")
    private String totalOutstandingBalanceOld;
    //8
    @JsonProperty("TOTAL_OUTSTANDING_BALANCE_NEW")
    private String totalOutstandingBalanceNew;
    //9
    @JsonProperty("TOTAL_MONTHLY_INSTALLMENT_OLD")
    private String totalMonthlyInstallmentOld;
    //10
    @JsonProperty("TOTAL_MONTHLY_INSTALLMENT_NEW")
    private String totalMonthlyInstallmentNew;
    //11
    @JsonProperty("TOTAL_CREDIT_LIMIT_OLD")
    private String totalCreditLimitOld;
    //12
    @JsonProperty("TOTAL_CREDIT_LIMIT_NEW")
    private String totalCreditLimitNew;
    //13
    @JsonProperty("TOTAL_ARREARS_BALANCE_OLD")
    private String totalArrearsBalanceOld;
    //14
    @JsonProperty("TOTAL_ARREARS_BALANCE_NEW")
    private String totalArrearsBalanceNew;
    //15
    @JsonProperty("WORST_CURRENT_PAYMENT_STATUS_OLD")
    private String worstCurrentPaymentStatusOld;
    //16
    @JsonProperty("WORST_CURRENT_PAYMENT_STATUS_NEW")
    private String worstCurrentPaymentStatusNew;
    //17
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_OLD")
    private String noOfDelinqAcc1DOld;
    //18
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_1_DAYS_NEW")
    private String noOfDelinqAcc1DNew;
    //19
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_OLD")
    private String noOfDelinqAcc30DOld;
    //20
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_30_DAYS_NEW")
    private String noOfDelinqAcc30DNew;
    //21
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_OLD")
    private String noOfDelinqAcc60DOld;
    //22
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_60_DAYS_NEW")
    private String noOfDelinqAcc60DNew;
    //23
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_OLD")
    private String noOfDelinqAcc90DOld;
    //24
    @JsonProperty("NO_OF_DELINQUENCY_ACCOUNT_90_DAYS_NEW")
    private String noOfDelinqAcc90DNew;
    //25
    @JsonProperty("NO_OF_ACTIVE_CAIS_ACCOUNT_OLD")
    private String noOfActiveCaisAccountOld;
    //26
    @JsonProperty("NO_OF_ACTIVE_CAIS_ACCOUNT_NEW")
    private String noOfActiveCaisAccountNew;
    //27
    @JsonProperty("NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_OLD")
    private String noOfSubsKeepAccOld;
    //28
    @JsonProperty("NO_OF_SUBSCRIBERS_KEEPING_ACCOUNTS_NEW")
    private String noOfSubsKeepAccNew;
    //29
    @JsonProperty("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_1_MONTH")
    private String noOfCapsRecPrev1M;
    //30
    @JsonProperty("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_2_MONTH")
    private String noOfCapsRecPrev2M;
    //31
    @JsonProperty("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_3_MONTH")
    private String noOfCapsRecPrev3M;
    //32
    @JsonProperty("NO_OF_CAPS_RECORDS_WITHIN_PREVIOUS_6_MONTH")
    private String noOfCapsRecPrev6M;
    //33
    @JsonProperty("TRIGGER_ID")
    private String triggerId;
    //34
    @JsonProperty("RUN_DATE")
    private String runDate;

    //35
    @JsonProperty("EXTERNAL_SUBJECT_ID ")
    private String externalSubjectId;

    @JsonProperty("FILENAME")
    private String fileName;//Файл

    @JsonProperty("NUMLINE")
    private int numLine;//номер строки

    public CsvSbJctTrg() {
        //empty
    }

    public CsvSbJctTrg(String primaryIdType, String primaryIdNumber, String surname, String forename1, String forename2,
                       String birthDate, String totalOutstandingBalanceOld, String totalOutstandingBalanceNew,
                       String totalMonthlyInstallmentOld, String totalMonthlyInstallmentNew, String totalCreditLimitOld,
                       String totalCreditLimitNew, String totalArrearsBalanceOld, String totalArrearsBalanceNew,
                       String worstCurrentPaymentStatusOld, String worstCurrentPaymentStatusNew, String noOfDelinqAcc1DOld,
                       String noOfDelinqAcc1DNew, String noOfDelinqAcc30DOld, String noOfDelinqAcc30DNew,
                       String noOfDelinqAcc60DOld, String noOfDelinqAcc60DNew, String noOfDelinqAcc90DOld,
                       String noOfDelinqAcc90DNew, String noOfActiveCaisAccountOld, String noOfActiveCaisAccountNew,
                       String noOfSubsKeepAccOld, String noOfSubsKeepAccNew, String noOfCapsRecPrev1M, String noOfCapsRecPrev2M,
                       String noOfCapsRecPrev3M, String noOfCapsRecPrev6M, String triggerId, String runDate) {
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.triggerId = triggerId;
        this.runDate = runDate;
    }

    public CsvSbJctTrg(String primaryIdType, String primaryIdNumber, String surname, String forename1, String forename2,
                       String birthDate, String totalOutstandingBalanceOld, String totalOutstandingBalanceNew,
                       String totalMonthlyInstallmentOld, String totalMonthlyInstallmentNew, String totalCreditLimitOld,
                       String totalCreditLimitNew, String totalArrearsBalanceOld, String totalArrearsBalanceNew,
                       String worstCurrentPaymentStatusOld, String worstCurrentPaymentStatusNew, String noOfDelinqAcc1DOld,
                       String noOfDelinqAcc1DNew, String noOfDelinqAcc30DOld, String noOfDelinqAcc30DNew, String noOfDelinqAcc60DOld,
                       String noOfDelinqAcc60DNew, String noOfDelinqAcc90DOld, String noOfDelinqAcc90DNew, String noOfActiveCaisAccountOld,
                       String noOfActiveCaisAccountNew, String noOfSubsKeepAccOld, String noOfSubsKeepAccNew, String noOfCapsRecPrev1M,
                       String noOfCapsRecPrev2M, String noOfCapsRecPrev3M, String noOfCapsRecPrev6M, String triggerId, String runDate,
                       String fileName, int numLine) {
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.triggerId = triggerId;
        this.runDate = runDate;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public CsvSbJctTrg(String primaryIdType, String primaryIdNumber, String surname, String forename1, String forename2,
                       String birthDate, String totalOutstandingBalanceOld, String totalOutstandingBalanceNew,
                       String totalMonthlyInstallmentOld, String totalMonthlyInstallmentNew, String totalCreditLimitOld,
                       String totalCreditLimitNew, String totalArrearsBalanceOld, String totalArrearsBalanceNew,
                       String worstCurrentPaymentStatusOld, String worstCurrentPaymentStatusNew, String noOfDelinqAcc1DOld,
                       String noOfDelinqAcc1DNew, String noOfDelinqAcc30DOld, String noOfDelinqAcc30DNew, String noOfDelinqAcc60DOld,
                       String noOfDelinqAcc60DNew, String noOfDelinqAcc90DOld, String noOfDelinqAcc90DNew, String noOfActiveCaisAccountOld,
                       String noOfActiveCaisAccountNew, String noOfSubsKeepAccOld, String noOfSubsKeepAccNew, String noOfCapsRecPrev1M,
                       String noOfCapsRecPrev2M, String noOfCapsRecPrev3M, String noOfCapsRecPrev6M, String triggerId, String runDate,
                       String externalSubjectId, String fileName, int numLine) {
        this.primaryIdType = primaryIdType;
        this.primaryIdNumber = primaryIdNumber;
        this.surname = surname;
        this.forename1 = forename1;
        this.forename2 = forename2;
        this.birthDate = birthDate;
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
        this.totalCreditLimitOld = totalCreditLimitOld;
        this.totalCreditLimitNew = totalCreditLimitNew;
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
        this.triggerId = triggerId;
        this.runDate = runDate;
        this.externalSubjectId = externalSubjectId;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public String getPrimaryIdType() {
        return primaryIdType;
    }

    public void setPrimaryIdType(String primaryIdType) {
        this.primaryIdType = primaryIdType;
    }

    public String getPrimaryIdNumber() {
        return primaryIdNumber;
    }

    public void setPrimaryIdNumber(String primaryIdNumber) {
        this.primaryIdNumber = primaryIdNumber;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getForename1() {
        return forename1;
    }

    public void setForename1(String forename1) {
        this.forename1 = forename1;
    }

    public String getForename2() {
        return forename2;
    }

    public void setForename2(String forename2) {
        this.forename2 = forename2;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getTotalOutstandingBalanceOld() {
        return totalOutstandingBalanceOld;
    }

    public void setTotalOutstandingBalanceOld(String totalOutstandingBalanceOld) {
        this.totalOutstandingBalanceOld = totalOutstandingBalanceOld;
    }

    public String getTotalOutstandingBalanceNew() {
        return totalOutstandingBalanceNew;
    }

    public void setTotalOutstandingBalanceNew(String totalOutstandingBalanceNew) {
        this.totalOutstandingBalanceNew = totalOutstandingBalanceNew;
    }

    public String getTotalMonthlyInstallmentOld() {
        return totalMonthlyInstallmentOld;
    }

    public void setTotalMonthlyInstallmentOld(String totalMonthlyInstallmentOld) {
        this.totalMonthlyInstallmentOld = totalMonthlyInstallmentOld;
    }

    public String getTotalMonthlyInstallmentNew() {
        return totalMonthlyInstallmentNew;
    }

    public void setTotalMonthlyInstallmentNew(String totalMonthlyInstallmentNew) {
        this.totalMonthlyInstallmentNew = totalMonthlyInstallmentNew;
    }

    public String getTotalCreditLimitOld() {
        return totalCreditLimitOld;
    }

    public void setTotalCreditLimitOld(String totalCreditLimitOld) {
        this.totalCreditLimitOld = totalCreditLimitOld;
    }

    public String getTotalCreditLimitNew() {
        return totalCreditLimitNew;
    }

    public void setTotalCreditLimitNew(String totalCreditLimitNew) {
        this.totalCreditLimitNew = totalCreditLimitNew;
    }

    public String getTotalArrearsBalanceOld() {
        return totalArrearsBalanceOld;
    }

    public void setTotalArrearsBalanceOld(String totalArrearsBalanceOld) {
        this.totalArrearsBalanceOld = totalArrearsBalanceOld;
    }

    public String getTotalArrearsBalanceNew() {
        return totalArrearsBalanceNew;
    }

    public void setTotalArrearsBalanceNew(String totalArrearsBalanceNew) {
        this.totalArrearsBalanceNew = totalArrearsBalanceNew;
    }

    public String getWorstCurrentPaymentStatusOld() {
        return worstCurrentPaymentStatusOld;
    }

    public void setWorstCurrentPaymentStatusOld(String worstCurrentPaymentStatusOld) {
        this.worstCurrentPaymentStatusOld = worstCurrentPaymentStatusOld;
    }

    public String getWorstCurrentPaymentStatusNew() {
        return worstCurrentPaymentStatusNew;
    }

    public void setWorstCurrentPaymentStatusNew(String worstCurrentPaymentStatusNew) {
        this.worstCurrentPaymentStatusNew = worstCurrentPaymentStatusNew;
    }

    public String getNoOfDelinqAcc1DOld() {
        return noOfDelinqAcc1DOld;
    }

    public void setNoOfDelinqAcc1DOld(String noOfDelinqAcc1DOld) {
        this.noOfDelinqAcc1DOld = noOfDelinqAcc1DOld;
    }

    public String getNoOfDelinqAcc1DNew() {
        return noOfDelinqAcc1DNew;
    }

    public void setNoOfDelinqAcc1DNew(String noOfDelinqAcc1DNew) {
        this.noOfDelinqAcc1DNew = noOfDelinqAcc1DNew;
    }

    public String getNoOfDelinqAcc30DOld() {
        return noOfDelinqAcc30DOld;
    }

    public void setNoOfDelinqAcc30DOld(String noOfDelinqAcc30DOld) {
        this.noOfDelinqAcc30DOld = noOfDelinqAcc30DOld;
    }

    public String getNoOfDelinqAcc30DNew() {
        return noOfDelinqAcc30DNew;
    }

    public void setNoOfDelinqAcc30DNew(String noOfDelinqAcc30DNew) {
        this.noOfDelinqAcc30DNew = noOfDelinqAcc30DNew;
    }

    public String getNoOfDelinqAcc60DOld() {
        return noOfDelinqAcc60DOld;
    }

    public void setNoOfDelinqAcc60DOld(String noOfDelinqAcc60DOld) {
        this.noOfDelinqAcc60DOld = noOfDelinqAcc60DOld;
    }

    public String getNoOfDelinqAcc60DNew() {
        return noOfDelinqAcc60DNew;
    }

    public void setNoOfDelinqAcc60DNew(String noOfDelinqAcc60DNew) {
        this.noOfDelinqAcc60DNew = noOfDelinqAcc60DNew;
    }

    public String getNoOfDelinqAcc90DOld() {
        return noOfDelinqAcc90DOld;
    }

    public void setNoOfDelinqAcc90DOld(String noOfDelinqAcc90DOld) {
        this.noOfDelinqAcc90DOld = noOfDelinqAcc90DOld;
    }

    public String getNoOfDelinqAcc90DNew() {
        return noOfDelinqAcc90DNew;
    }

    public void setNoOfDelinqAcc90DNew(String noOfDelinqAcc90DNew) {
        this.noOfDelinqAcc90DNew = noOfDelinqAcc90DNew;
    }

    public String getNoOfActiveCaisAccountOld() {
        return noOfActiveCaisAccountOld;
    }

    public void setNoOfActiveCaisAccountOld(String noOfActiveCaisAccountOld) {
        this.noOfActiveCaisAccountOld = noOfActiveCaisAccountOld;
    }

    public String getNoOfActiveCaisAccountNew() {
        return noOfActiveCaisAccountNew;
    }

    public void setNoOfActiveCaisAccountNew(String noOfActiveCaisAccountNew) {
        this.noOfActiveCaisAccountNew = noOfActiveCaisAccountNew;
    }

    public String getNoOfSubsKeepAccOld() {
        return noOfSubsKeepAccOld;
    }

    public void setNoOfSubsKeepAccOld(String noOfSubsKeepAccOld) {
        this.noOfSubsKeepAccOld = noOfSubsKeepAccOld;
    }

    public String getNoOfSubsKeepAccNew() {
        return noOfSubsKeepAccNew;
    }

    public void setNoOfSubsKeepAccNew(String noOfSubsKeepAccNew) {
        this.noOfSubsKeepAccNew = noOfSubsKeepAccNew;
    }

    public String getNoOfCapsRecPrev1M() {
        return noOfCapsRecPrev1M;
    }

    public void setNoOfCapsRecPrev1M(String noOfCapsRecPrev1M) {
        this.noOfCapsRecPrev1M = noOfCapsRecPrev1M;
    }

    public String getNoOfCapsRecPrev2M() {
        return noOfCapsRecPrev2M;
    }

    public void setNoOfCapsRecPrev2M(String noOfCapsRecPrev2M) {
        this.noOfCapsRecPrev2M = noOfCapsRecPrev2M;
    }

    public String getNoOfCapsRecPrev3M() {
        return noOfCapsRecPrev3M;
    }

    public void setNoOfCapsRecPrev3M(String noOfCapsRecPrev3M) {
        this.noOfCapsRecPrev3M = noOfCapsRecPrev3M;
    }

    public String getNoOfCapsRecPrev6M() {
        return noOfCapsRecPrev6M;
    }

    public void setNoOfCapsRecPrev6M(String noOfCapsRecPrev6M) {
        this.noOfCapsRecPrev6M = noOfCapsRecPrev6M;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getRunDate() {
        return runDate;
    }

    public void setRunDate(String runDate) {
        this.runDate = runDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getNumLine() {
        return numLine;
    }

    public void setNumLine(int numLine) {
        this.numLine = numLine;
    }

    public String getExternalSubjectId() {
        return externalSubjectId;
    }

    public void setExternalSubjectId(String externalSubjectId) {
        this.externalSubjectId = externalSubjectId;
    }

    @Override
    public String toString() {
        return "CsvSbJctTrg{" +
                "primaryIdType='" + primaryIdType + '\'' +
                ", primaryIdNumber='" + primaryIdNumber + '\'' +
                ", surname='" + surname + '\'' +
                ", forename1='" + forename1 + '\'' +
                ", forename2='" + forename2 + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", totalOutstandingBalanceOld='" + totalOutstandingBalanceOld + '\'' +
                ", totalOutstandingBalanceNew='" + totalOutstandingBalanceNew + '\'' +
                ", totalMonthlyInstallmentOld='" + totalMonthlyInstallmentOld + '\'' +
                ", totalMonthlyInstallmentNew='" + totalMonthlyInstallmentNew + '\'' +
                ", totalCreditLimitOld='" + totalCreditLimitOld + '\'' +
                ", totalCreditLimitNew='" + totalCreditLimitNew + '\'' +
                ", totalArrearsBalanceOld='" + totalArrearsBalanceOld + '\'' +
                ", totalArrearsBalanceNew='" + totalArrearsBalanceNew + '\'' +
                ", worstCurrentPaymentStatusOld='" + worstCurrentPaymentStatusOld + '\'' +
                ", worstCurrentPaymentStatusNew='" + worstCurrentPaymentStatusNew + '\'' +
                ", noOfDelinqAcc1DOld='" + noOfDelinqAcc1DOld + '\'' +
                ", noOfDelinqAcc1DNew='" + noOfDelinqAcc1DNew + '\'' +
                ", noOfDelinqAcc30DOld='" + noOfDelinqAcc30DOld + '\'' +
                ", noOfDelinqAcc30DNew='" + noOfDelinqAcc30DNew + '\'' +
                ", noOfDelinqAcc60DOld='" + noOfDelinqAcc60DOld + '\'' +
                ", noOfDelinqAcc60DNew='" + noOfDelinqAcc60DNew + '\'' +
                ", noOfDelinqAcc90DOld='" + noOfDelinqAcc90DOld + '\'' +
                ", noOfDelinqAcc90DNew='" + noOfDelinqAcc90DNew + '\'' +
                ", noOfActiveCaisAccountOld='" + noOfActiveCaisAccountOld + '\'' +
                ", noOfActiveCaisAccountNew='" + noOfActiveCaisAccountNew + '\'' +
                ", noOfSubsKeepAccOld='" + noOfSubsKeepAccOld + '\'' +
                ", noOfSubsKeepAccNew='" + noOfSubsKeepAccNew + '\'' +
                ", noOfCapsRecPrev1M='" + noOfCapsRecPrev1M + '\'' +
                ", noOfCapsRecPrev2M='" + noOfCapsRecPrev2M + '\'' +
                ", noOfCapsRecPrev3M='" + noOfCapsRecPrev3M + '\'' +
                ", noOfCapsRecPrev6M='" + noOfCapsRecPrev6M + '\'' +
                ", triggerId='" + triggerId + '\'' +
                ", runDate='" + runDate + '\'' +
                '}';
    }
}
