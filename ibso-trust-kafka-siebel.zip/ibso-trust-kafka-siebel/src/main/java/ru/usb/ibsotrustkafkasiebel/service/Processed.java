package ru.usb.ibsotrustkafkasiebel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.model.IbsoTrustSiebel;
import ru.usb.ibsotrustkafkasiebel.repository.TrustRepositoryImpl;
import ru.usb.ibsotrustkafkasiebel.service.kafka.KafkaProducerService;
import ru.usb.ibsotrustkafkasiebel.service.mail.ServiceMailError;
import ru.usb.ibsotrustkafkasiebel.utils.AuxMethods;
import ru.usb.ibsotrustkafkasiebel.utils.MapMessFromKafka;
import ru.usb.ibsotrustkafkasiebel.utils.MapMessToSiebel;
import ru.usb.ibsotrustkafkasiebel.utils.MapperIbsoToClob;
import java.util.List;

@Service
public class Processed {
    Logger logger = LoggerFactory.getLogger(Processed.class);
    private final ServiceMailError serviceMailError;
    private final AuxMethods aux;
    private final Configure configure;
    private final TrustRepositoryImpl trustRepository;
    private final KafkaProducerService producerService;
    private final MapperIbsoToClob mapperIbsoToClob;
    private final MapMessFromKafka mapMessFromKafka;
    private final MapMessToSiebel mapMessToSiebel;

    @Autowired
    public Processed(ServiceMailError serviceMailError, AuxMethods aux, Configure configure,
                     TrustRepositoryImpl trustRepository, KafkaProducerService producerService,
                     MapperIbsoToClob mapperIbsoToClob, MapMessFromKafka mapMessFromKafka,
                     MapMessToSiebel mapMessToSiebel) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.configure = configure;
        this.trustRepository = trustRepository;
        this.producerService = producerService;
        this.mapperIbsoToClob = mapperIbsoToClob;
        this.mapMessFromKafka = mapMessFromKafka;
        this.mapMessToSiebel = mapMessToSiebel;
    }

    /**
     * Процесс переноса информации
     */
    public void baseProcess() {
        List<IbsoTrustSiebel> siebelList = trustRepository.findByGrowId(configure.getMaxValueId());
        if (siebelList != null && !siebelList.isEmpty()) {
            siebelList.forEach(ibso -> {
                logWriteDebug(ibso);
                try {
                    producerService.sendMessage(configure.getSiebelTopic(), null,
                            mapMessFromKafka.getJsonToStr(mapMessToSiebel.getMessKafka(mapMessFromKafka.getPackToStr(mapperIbsoToClob.getClob(ibso)),
                                    configure.getSystemService(), ibso.getPackId())));
                    if (configure.getMaxValueId() < ibso.getId()) {
                        configure.setMaxValueId(ibso.getId());
                    }
                } catch (Exception e) {
                    logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+");
                    logger.error("UsbLog:Ошибка отправки в топик:{} - сообщения:{}", configure.getSiebelTopic(), ibso);
                    logger.error("UsbLog:Ошибка", e);
                    logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
                    serviceMailError.sendMailErrorSubject(" Сообщение не удалось отправить в Зибель ", aux.getWrapNull(ibso.toString()));
                }
            });
            /**
             * После отправки сообщений в Зибель, пишем номер последнего отправленного сообщения
             */
            configure.setKeyValue(configure.getKeyValue() + 1);
            producerService.sendMessage(configure.getIbsoTopicTrust(), Long.toString(configure.getKeyValue() + 1), Long.toString(configure.getMaxValueId()));
        }
    }


    /**
     * Запись в лог, если LogDebug =  true
     *
     * @param ibso -- Объект
     */
    private void logWriteDebug(IbsoTrustSiebel ibso) {
        if (configure.isLogDebug()) {
            logger.info("UsbLog:{}", ibso);
        }
    }
}
