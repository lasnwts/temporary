package ru.usb.ibsotrustkafkasiebel.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.service.mail.ServiceMailError;
import ru.usb.ibsotrustkafkasiebel.utils.AuxMethods;

@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;
    private final AuxMethods aux;
    private final Configure configure;

    @Autowired
    public KafkaListenerService(ServiceMailError serviceMailError, AuxMethods aux, Configure configure) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.configure = configure;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {
        if (logDebug) {
            logger.info("UsbLog:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener (record.value)    == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        /**
         * Сообщение забираем по любому
         * ack.acknowledge();
         */

        /**
         * Сообщение по Kafka, готовим
         */
        String message;
        String key;
        message = recordKafka.value();
        try {
            key = String.valueOf(recordKafka.key());
        } catch (Exception e) {
            logger.error("UsbLog:!ERROR!!!!!!!!!!!!!!!!!!  key = String.valueOf(recordKafka.key());!ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:!ERROR!", e);
            key = "0";
            logger.error("key=0");
        }


        if (message == null && key == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!");
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()));
        } else {

            /**
             * Сообщение по Kafka,
             *
             */
            long keyValue = aux.getLong(key);
            configure.setOffsetNow(recordKafka.offset());
            if (configure.getKeyValue() < keyValue) {
                setConfigureValue(message, keyValue);
            }
        }
    }

    /**
     * Обработка сообщения
     *
     * @param message  - тело сообщения
     * @param keyValue - ключ
     */
    private void setConfigureValue(String message, long keyValue) {
        if (aux.getLong(message) > 0) {
            configure.setMaxValueId(aux.getLong(message));
            configure.setKeyValue(keyValue);
            if (configure.isLogDebug()) {
                logger.info("UsbLog:Установлены значения max ID из таблицы:{}", configure.getMaxValueId());
                logger.info("UsbLog:Установлены значения ключа key={}  из топика:{}", configure.getKeyValue(), configure.getIbsoTopicTrust());
            }
        }
    }
}
