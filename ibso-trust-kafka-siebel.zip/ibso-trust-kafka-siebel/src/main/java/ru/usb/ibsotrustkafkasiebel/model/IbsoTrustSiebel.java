package ru.usb.ibsotrustkafkasiebel.model;

import java.util.Date;

/**
 * Таблица TRUST_KAFKA_CONNECT
 * DATETIME,
 * TYPEV ,
 * initiatorFio ,
 * initiatorId ,
 * confidantFio ,
 * confidantId ,
 * trustName ,
 * trustNumber
 * //    @Temporal(TemporalType.TIMESTAMP)
 */
public class IbsoTrustSiebel {
    private long id;
    private Date datetime;
    private String type;
    private String initiatorFio;
    private String initiatorId;
    private String confidantFio;
    private String confidantId;
    private String trustName;
    private String trustNumber;

    public IbsoTrustSiebel() {
        //
    }

    public IbsoTrustSiebel(Date datetime, String type, String initiatorFio, String initiatorId,
                           String confidantFio, String confidantId, String trustName, String trustNumber) {
        this.datetime = datetime;
        this.type = type;
        this.initiatorFio = initiatorFio;
        this.initiatorId = initiatorId;
        this.confidantFio = confidantFio;
        this.confidantId = confidantId;
        this.trustName = trustName;
        this.trustNumber = trustNumber;
    }

    public IbsoTrustSiebel(long id, Date datetime, String type, String initiatorFio, String initiatorId,
                           String confidantFio, String confidantId, String trustName, String trustNumber) {
        this.id = id;
        this.datetime = datetime;
        this.type = type;
        this.initiatorFio = initiatorFio;
        this.initiatorId = initiatorId;
        this.confidantFio = confidantFio;
        this.confidantId = confidantId;
        this.trustName = trustName;
        this.trustNumber = trustNumber;
    }

    public String getPackId(){
        return Long.toString(id);
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDatetime() {
        return datetime;
    }

    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInitiatorFio() {
        return initiatorFio;
    }

    public void setInitiatorFio(String initiatorFio) {
        this.initiatorFio = initiatorFio;
    }

    public String getInitiatorId() {
        return initiatorId;
    }

    public void setInitiatorId(String initiatorId) {
        this.initiatorId = initiatorId;
    }

    public String getConfidantFio() {
        return confidantFio;
    }

    public void setConfidantFio(String confidantFio) {
        this.confidantFio = confidantFio;
    }

    public String getConfidantId() {
        return confidantId;
    }

    public void setConfidantId(String confidantId) {
        this.confidantId = confidantId;
    }

    public String getTrustName() {
        return trustName;
    }

    public void setTrustName(String trustName) {
        this.trustName = trustName;
    }

    public String getTrustNumber() {
        return trustNumber;
    }

    public void setTrustNumber(String trustNumber) {
        this.trustNumber = trustNumber;
    }

    @Override
    public String toString() {
        return "IbsoTrustSiebel{" +
                "id=" + id +
                ", datetime=" + datetime +
                ", type='" + type + '\'' +
                ", initiatorFio='" + initiatorFio + '\'' +
                ", initiatorId='" + initiatorId + '\'' +
                ", confidantFio='" + confidantFio + '\'' +
                ", confidantId='" + confidantId + '\'' +
                ", trustName='" + trustName + '\'' +
                ", trustNumber='" + trustNumber + '\'' +
                '}';
    }
}
