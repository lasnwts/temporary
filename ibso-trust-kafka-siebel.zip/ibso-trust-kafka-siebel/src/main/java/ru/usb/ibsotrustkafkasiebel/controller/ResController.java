package ru.usb.ibsotrustkafkasiebel.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.model.IbsoTrustSiebel;
import ru.usb.ibsotrustkafkasiebel.repository.TrustRepositoryImpl;
import ru.usb.ibsotrustkafkasiebel.service.kafka.KafkaProducerService;
import ru.usb.ibsotrustkafkasiebel.utils.AuxMethods;
import ru.usb.ibsotrustkafkasiebel.utils.MapMessFromKafka;
import ru.usb.ibsotrustkafkasiebel.utils.MapMessToSiebel;
import ru.usb.ibsotrustkafkasiebel.utils.MapperIbsoToClob;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер REST API", description = "Инициатива 792. МП 939150. Информирование Клиента и основной точки обслуживания о регистрации доверенности.")
public class ResController {
    private final Logger logger = LoggerFactory.getLogger(ResController.class);
    private final Configure configure;
    private final KafkaProducerService kafkaProducerService;
    private final TrustRepositoryImpl trustRepository;
    private final KafkaProducerService producerService;
    private final MapperIbsoToClob mapperIbsoToClob;
    private final MapMessFromKafka mapMessFromKafka;
    private final MapMessToSiebel mapMessToSiebel;
    private final AuxMethods aux;

    @Autowired
    public ResController(Configure configure, KafkaProducerService kafkaProducerService, TrustRepositoryImpl trustRepository,
                         KafkaProducerService producerService, MapperIbsoToClob mapperIbsoToClob,
                         MapMessFromKafka mapMessFromKafka, MapMessToSiebel mapMessToSiebel, AuxMethods aux) {
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.trustRepository = trustRepository;
        this.producerService = producerService;
        this.mapperIbsoToClob = mapperIbsoToClob;
        this.mapMessFromKafka = mapMessFromKafka;
        this.mapMessToSiebel = mapMessToSiebel;
        this.aux = aux;
    }


    @GetMapping(value = "/value")
    @Operation(summary = "Получить информацию о максимальном значении ID выборки ")
    public ResponseEntity<String> getMaxValue() {
        logger.info("UsbLog:Запрос на получение максимальных значений выборки =)");
        return new ResponseEntity<>("Максимальное значение ID:" + configure.getMaxValueId() + "\n" + "<br>" +
                "Значение ключа кафка Key:" + configure.getKeyValue() + "\n <br>" +
                "Значение Offset:" + configure.getOffsetUnder()
                , HttpStatus.OK);
    }

    @GetMapping(value = "/count")
    @Operation(summary = "Получить информацию о количестве записей в таблице")
    public ResponseEntity<String> getCount() {
        int count = trustRepository.count();
        logger.info("UsbLog:Запрос на информацию о количестве записей в таблице:{}", count);
        return new ResponseEntity<>("Количество записей в таблице:" + count
                , HttpStatus.OK);
    }

    @GetMapping(value = "/id")
    @Operation(summary = "Получить запись из таблицы БД, по id")
    public ResponseEntity<IbsoTrustSiebel> getIbsoRecord(@RequestParam("id") long id) {
        logger.info("UsbLog: Запрос объект а - запись из таблицы с id={}", id);
        Optional<IbsoTrustSiebel> optional = trustRepository.findById(id);
        if (optional.isPresent()) {
            logger.info("UsbLog:Запись из БД:{}", optional.get());
            return new ResponseEntity<>(optional.get(), HttpStatus.OK);
        } else {
            logger.info("UsbLog:Записи с id={} нет в базе данных", id);
            return new ResponseEntity<>(new IbsoTrustSiebel(), HttpStatus.FOUND);
        }
    }

    /**
     * Установка значений MaxValue
     *
     * @param maxValue - число
     * @return - информация о новом значении
     */
    @PutMapping(value = "/value")
    @Operation(summary = "Изменить (установить) id выборки из таблицы. Максимальном значении ID выборки maxValue")
    public ResponseEntity<String> setMaxValue(@RequestParam("0") long maxValue) {
        logger.info("UsbLog:Запрос на установку максимальных значений выборки maxValue={}", maxValue);
        long newKey = configure.getKeyValue() + 10;
        logger.info("UsbLog: Key={}", newKey);
        kafkaProducerService.sendMessage(configure.getIbsoTopicTrust(), Long.toString(newKey), Long.toString(maxValue));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            logger.error("UsbLog:");
            Thread.currentThread().interrupt();
        }
        return new ResponseEntity<>("Максимальное значение ID:" + configure.getMaxValueId() + "\n<br>" +
                "Значение ключа кафка Key:" + configure.getKeyValue() + "\n<br>" +
                "Значение Offset:" + configure.getOffsetUnder()
                , HttpStatus.OK);
    }

    @PostMapping(value = "/")
    @Operation(summary = "Отправить сообщение в Зибель")
    public ResponseEntity<String> sendMessage(@RequestBody IbsoTrustSiebel ibso) {
        logger.info("UsbLog: Запрос, отправить запись в Siebel={}", ibso);
        try {
            producerService.sendMessage(configure.getSiebelTopic(), null,
                    mapMessFromKafka.getJsonToStr(mapMessToSiebel.getMessKafka(mapMessFromKafka.getPackToStr(mapperIbsoToClob.getClob(ibso)),
                            configure.getSystemService(), ibso.getPackId())));
            return new ResponseEntity<>("Сообщение успешно отправлено", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+");
            logger.error("UsbLog:Ошибка отправки в топик:{} - сообщения:{}", configure.getSiebelTopic(), ibso);
            logger.error("UsbLog:Ошибка", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return new ResponseEntity<>("Ошибка отправки в топик:" + configure.getSiebelTopic() + " - сообщения:" + ibso, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Получаем значение isValueDone     *
     *
     * @return
     */
    @GetMapping(value = "/allow")
    @Operation(summary = "Посмотреть, разрешен экспорт данных из таблицы? true - разрешен, false - запрещен.")
    public ResponseEntity<String> getValueDone() {
        logger.info("UsbLog: Запрос  Получаем значение isValueDone= {}, adminValueDone={}", configure.isValueDone(), configure.isValueAdminDone());
        return getResponseEnt();
    }

    /**
     * Получаем значение isValueDone     *
     *
     * @return
     */
    @PutMapping(value = "/allow")
    @Operation(summary = "Установить - экспорт данных из таблицы. true - разрешен, false - запрещен.")
    public ResponseEntity<String> setValueDone(@RequestParam (required = true) boolean newValue) {
        logger.info("UsbLog: Запрос  Получаем Новое значение изх запроса={}, старое значение ValeDone= isValueDone= {}", newValue, configure.isValueDone());
        configure.setValueAdminDone(newValue);
        return getResponseEnt();
    }

    private ResponseEntity<String> getResponseEnt(){

        if (configure.isValueDone() && configure.isValueAdminDone()) {
            return new ResponseEntity<>("Работа процесса переноса данных из Таблицы -" + aux.getWrapNull(configure.getTableName()) + " - разрешена. Value="
                    + configure.isValueDone() + " , service.admin.allow=" + configure.isValueAdminDone(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Работа процесса переноса данных из Таблицы::" + aux.getWrapNull(configure.getTableName()) + " - ЗАПРЕЩЕНА! Value="
                    + configure.isValueDone() + " , service.admin.allow=" + configure.isValueAdminDone(), HttpStatus.OK);
        }

    }

}
