package ru.usb.ibsotrustkafkasiebel.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.ibsotrustkafkasiebel.model.MessageFromKafka;
import ru.usb.ibsotrustkafkasiebel.model.TrustClob;


@Component
public class MapMessFromKafka {
    Logger logger = LoggerFactory.getLogger(MapMessFromKafka.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Преобразование объекта в строку JSON
     *
     * @param messageFromKafka объект
     * @return - строка Json
     */
    public String getJsonToStr(MessageFromKafka messageFromKafka) {

        if (messageFromKafka == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [MessageFromKafka] == NULL! Класс [MapMessFromKafka] метод [getJsonToStr]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(messageFromKafka);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [MessageFromKafka] в JSON строку! Класс [MapMessFromKafka] метод [getJsonToStr]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

    /**
     * Переводим в сьтроковое представление объект TrustClob
     * @param trustClob - объект
     * @return - строка
     */
    public String getPackToStr(TrustClob trustClob) {

        if (trustClob == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [trustClob] == NULL! Класс [MapMessFromKafka] метод [getPackToStr]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(trustClob);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [TrustClob] в JSON строку! Класс [MapMessFromKafka] метод [getPackToStr]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

}
