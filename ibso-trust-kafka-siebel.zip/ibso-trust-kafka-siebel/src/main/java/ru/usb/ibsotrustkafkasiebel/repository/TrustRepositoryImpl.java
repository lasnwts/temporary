package ru.usb.ibsotrustkafkasiebel.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.model.IbsoTrustSiebel;

import java.util.List;
import java.util.Optional;

@Repository
public class TrustRepositoryImpl implements TrustRepository {
    int count = 0;
    Logger logger = LoggerFactory.getLogger(TrustRepositoryImpl.class);
    private final JdbcTemplate jdbcTemplate;
    private final Configure configure;

    @Autowired
    public TrustRepositoryImpl(JdbcTemplate jdbcTemplate, Configure configure) {
        this.jdbcTemplate = jdbcTemplate;
        this.configure = configure;
    }

    @Override
    public int count() {
        count = 0;
        try {
            count = Optional.ofNullable(jdbcTemplate.queryForObject("select count(*) from " + configure.getTableName(), Integer.class)).orElse(0);
        } catch (Exception e) {
            logger.error("UsbLog:+!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:TrustRepository:count():", e);
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
        return count;
    }

    @Override
    public int save(IbsoTrustSiebel ibso) {
        return Optional.of(jdbcTemplate.update("insert into " + configure.getTableName() + " (DATETIME, TYPE , INITIATOR_FIO , INITIATOR_ID , CONFIDANT_FIO , " +
                "CONFIDANT_ID , TRUST_NAME , TRUST_NUMBER) " +
                "values(?,?, ?, ?, ?, ?, ?, ?)", ibso.getDatetime(), ibso.getType(), ibso.getInitiatorFio(), ibso.getInitiatorId(), ibso.getConfidantFio(), ibso.getConfidantId(), ibso.getTrustName(), ibso.getTrustNumber()
        )).orElse(0);
    }

    @Override
    public int update(IbsoTrustSiebel ibso) {
        return Optional.of(jdbcTemplate.update("update " + configure.getTableName() + " set DATETIME = ?, TYPE =? , INITIATOR_FIO=? , INITIATOR_ID = ?, CONFIDANT_FIO = ? , CONFIDANT_ID = ? , TRUST_NAME = ?, TRUST_NUMBER =? where id = ?",
                ibso.getDatetime(), ibso.getType(), ibso.getInitiatorFio(), ibso.getInitiatorId(), ibso.getConfidantFio(), ibso.getConfidantId(), ibso.getTrustName(), ibso.getTrustNumber(), ibso.getId()
        )).orElse(0);

    }

    @Override
    public int deleteById(Long id) {
        return Optional.of(jdbcTemplate.update("delete from where id = ?", id)).orElse(0);
    }

    /**
     * this.datetime = datetime;
     * this.type = type;
     * this.initiatorFio = INITIATOR_FIO;
     * this.initiatorId = initiatorId;
     * this.confidantFio = confidantFio;
     * this.confidantId = CONFIDANT_ID;
     * this.trustName = trustName;
     * this.trustNumber = trustNumber;
     *
     * @return
     */
    @Override
    public List<IbsoTrustSiebel> findAll() {
        return jdbcTemplate.query(
                " select ID, DATETIME, TYPE , INITIATOR_FIO , INITIATOR_ID , CONFIDANT_FIO , CONFIDANT_ID , TRUST_NAME , TRUST_NUMBER from " +
                        configure.getTableName(),
                (rs, rowNum) ->
                        new IbsoTrustSiebel(
                                rs.getLong("id"),
                                rs.getTimestamp("datetime"),
                                rs.getString("type"),
                                rs.getString("INITIATOR_FIO"),
                                rs.getString("INITIATOR_ID"),
                                rs.getString("CONFIDANT_FIO"),
                                rs.getString("CONFIDANT_ID"),
                                rs.getString("TRUST_NAME"),
                                rs.getString("TRUST_NUMBER")
                        )
        );
    }


    @Override
    public List<IbsoTrustSiebel> findByGrowId(Long id) {
        return jdbcTemplate.query(
                "select ID, DATETIME, TYPE , INITIATOR_FIO , INITIATOR_ID , CONFIDANT_FIO , CONFIDANT_ID , TRUST_NAME , TRUST_NUMBER from "
                        + configure.getTableName() + " where id > ?",
                new Object[]{id},
                (rs, rowNum) ->
                        new IbsoTrustSiebel(
                                rs.getLong("id"),
                                rs.getTimestamp("datetime"),
                                rs.getString("type"),
                                rs.getString("INITIATOR_FIO"),
                                rs.getString("INITIATOR_ID"),
                                rs.getString("CONFIDANT_FIO"),
                                rs.getString("CONFIDANT_ID"),
                                rs.getString("TRUST_NAME"),
                                rs.getString("TRUST_NUMBER")
                        )
        );
    }

    @Override
    public Optional<IbsoTrustSiebel> findById(Long id) {
        try {
            return jdbcTemplate.queryForObject(
                    "select ID, DATETIME, TYPE , INITIATOR_FIO , INITIATOR_ID , CONFIDANT_FIO , CONFIDANT_ID , TRUST_NAME , TRUST_NUMBER from "
                            + configure.getTableName() + " where  ROWNUM = 1 and id = ?",
                    new Object[]{id},
                    (rs, rowNum) ->
                            Optional.of(new IbsoTrustSiebel(
                                    rs.getLong("id"),
                                    rs.getTimestamp("datetime"),
                                    rs.getString("type"),
                                    rs.getString("INITIATOR_FIO"),
                                    rs.getString("INITIATOR_ID"),
                                    rs.getString("CONFIDANT_FIO"),
                                    rs.getString("CONFIDANT_ID"),
                                    rs.getString("TRUST_NAME"),
                                    rs.getString("TRUST_NUMBER")
                            ))
            );
        } catch (EmptyResultDataAccessException e) {
            logger.error("!!!!!!!!!!!!!!!!!<ERROR jdbcTemplate.queryForObject  start>!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Execption:", e);
            logger.error("!!!!!!!!!!!!!!!!!<ERROR jdbcTemplate.queryForObject stop>!!!!!!!!!!!!!!!!!!!!!!");
            return Optional.empty();
        }
    }
}
