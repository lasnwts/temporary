package ru.usb.ibsotrustkafkasiebel.repository;

import ru.usb.ibsotrustkafkasiebel.model.IbsoTrustSiebel;

import java.util.List;
import java.util.Optional;

public interface TrustRepository {

    int count();

    int save(IbsoTrustSiebel ibsoTrustSiebel);

    int update(IbsoTrustSiebel ibsoTrustSiebel);

    int deleteById(Long id);

    List<IbsoTrustSiebel> findAll();

    List<IbsoTrustSiebel> findByGrowId(Long id);

    Optional<IbsoTrustSiebel> findById(Long id);

}
