package ru.usb.ibsotrustkafkasiebel.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.model.MessageFromKafka;

@Component
public class MapMessToSiebel {

    Logger logger = LoggerFactory.getLogger(MapMessToSiebel.class);
    private Configure configure;

    @Autowired
    public MapMessToSiebel(Configure configure) {
        this.configure = configure;
    }

    /**
     * Метод подготовки и отправки сообщения в Siebel от МП
     */

    /**
     * Метод подготовки и отправки сообщения в Siebel от МП
     *
     * @param message -- сообщение полученное по Кафка
     * @param service - топик по которому получено сообщение
     */
    public MessageFromKafka getMessKafka(String message, String service, String packId) {

        if (message == null || service == null || packId == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+");
            logger.error("UsbLog:Ошибка в класс MapMessToSiebel метод getMessKafka передано значение NULL!");
            logger.error("UsbLog:messge={}, service={}, packId={}", message, service, packId);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
        }

        /**
         * Работа над отправкой
         * Создаем новый объект -> JSON
         */
        MessageFromKafka messageFromKafka = new MessageFromKafka();
        messageFromKafka.setPackID(packId);
        messageFromKafka.setSystem_from(configure.getSystemFrom());
        messageFromKafka.setSystem_to(configure.getSystemTo());
        messageFromKafka.setService(service);
        messageFromKafka.setPack(message);
        logger.info(".");
        logger.info("UsbLog:Сообщение в топик зибель:{}", configure.getSiebelTopic());
        logger.info("UsbLog: POJO {}", messageFromKafka);
        logger.info("..");
        return messageFromKafka;
    }
}
