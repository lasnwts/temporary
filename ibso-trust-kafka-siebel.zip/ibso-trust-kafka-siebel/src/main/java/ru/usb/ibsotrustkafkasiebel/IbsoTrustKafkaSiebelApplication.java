package ru.usb.ibsotrustkafkasiebel;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.ibsotrustkafkasiebel.configure.Configure;
import ru.usb.ibsotrustkafkasiebel.service.Processed;


@SpringBootApplication
public class IbsoTrustKafkaSiebelApplication implements CommandLineRunner {
    private final Configure configure;
    private final Processed processed;

    @Autowired
    public IbsoTrustKafkaSiebelApplication(Configure configure, Processed processed) {
        this.configure = configure;
        this.processed = processed;
    }

    Logger logger = LoggerFactory.getLogger(IbsoTrustKafkaSiebelApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(IbsoTrustKafkaSiebelApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Initiative 792. Service (ibso-trust-kafka-siebel) transmit to EFS notifications about the registration from Retail")
                .version(appVersion)
                .description("Инициатива 792. МП 939150. Информирование Клиента и основной точки обслуживания о регистрации доверенности." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info("+---------------------------------------------------------------------------------------------------------+");
        logger.info(" Created by 16.02.2024   : Author: LyapustinAS");
        logger.info("-----------------------------------------------------------------------------------------------------------");
        logger.info("| Name of service        :{}", "ibso-trust-kafka-siebel");
        logger.info("| Description of service :{}", "Между Ритейл и ЕФС требуется реализовать онлайн интеграцию Ритейл – KAFKA – ЕФС,");
        logger.info("| .                      :{}", " для передачи в ЕФС уведомлений о регистрации доверенности на клиента частного");
        logger.info("| ..                     :{}", "  или премиального банка. На основе этих уведомлений ЕФС будет создавать ");
        logger.info("| ...                    :{}", "  задания для персональных менеджеров и руководителей ЧБ.");
        logger.info("| ....                   :{}", "Для этого в ритейле требуется создать таблицу «TRUST_KAFKA_CONNECT», ");
        logger.info("| .....                  :{}", "  в которую Ритейл будет помещать уведомления для ЕФС. Из этой таблицы");
        logger.info("| ......                 :{}", "  инкремент будет забирать Kafka JDBC Connector, преобразовывать его в json");
        logger.info("| .......                :{}", "   и размещать в топике KAFKA ЕФС.");
        logger.info("=---------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason        :{}", "0.0.1 Первая версия                                                       ");
        logger.info("---------------------------------------------------------------------------------------------------------");

        /**
         * Устанавливаем параметры
         */
        configure.setKeyValue(0L);
        configure.setMaxValueId(0L);
        configure.setOffsetNow(1L);
        configure.setOffsetUnder(0L);
        configure.setValueDone(false);
    }

    /**
     * Sheduler
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void serviceJobScheduler() {
        if (configure.isValueDone() && configure.isValueAdminDone()) {
            processed.baseProcess();
        } else {
            if (configure.getOffsetNow() == configure.getOffsetUnder()) {
                configure.setValueDone(true);
            } else {
                configure.setOffsetUnder(configure.getOffsetNow());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    logger.error("!!!!!!!!!!!!!!!!!<ERROR send Thread.sleep>!!!!!!!!!!!!!!!!!!!!!!");
                    logger.error("UsbLog:InterruptedException:", e);
                    logger.error("!!!!!!!!!!!!!!!!!<ERROR send Thread.sleep>!!!!!!!!!!!!!!!!!!!!!!");
                    Thread.currentThread().interrupt();
                }
            }
            printKey(); //Печатаем состояние ключей
        }
    }

    private void printKey() {
        if (configure.isLogDebug() && !configure.isValueDone()) {
            logger.info("*****************************************************+");
            logger.info("* Config done      flag={} *", configure.isValueDone());
            logger.info("* ------------------------------------------------------");
            logger.info("* Config     MaxValueId={} *", configure.getMaxValueId());
            logger.info("* -------------------------------------------------------");
            logger.info("* Config       KeyValue={} *", configure.getKeyValue());
            logger.info("* -------------------------------------------------------");
            logger.info("* Config   Offset under={} *", configure.getOffsetUnder());
            logger.info("* Config   Offset   now={} *", configure.getOffsetNow());
            logger.info("******************************************************-");
        }
    }


}


@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /**
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}

