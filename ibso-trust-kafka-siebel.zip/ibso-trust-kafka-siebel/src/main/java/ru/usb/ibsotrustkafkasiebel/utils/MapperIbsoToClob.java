package ru.usb.ibsotrustkafkasiebel.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.ibsotrustkafkasiebel.model.IbsoTrustSiebel;
import ru.usb.ibsotrustkafkasiebel.model.TrustClob;

@Component
public class MapperIbsoToClob {

    Logger logger = LoggerFactory.getLogger(MapperIbsoToClob.class);

    //@JsonProperty("TRUST_NUMBER")

    /**
     * Получаем TrustClob
     * @param ibso =- запись из IBSO
     * @return - Готовый объект Clob для тега Pack
     */
    public TrustClob getClob(IbsoTrustSiebel ibso){
        if (ibso != null){
            return new TrustClob(ibso.getType(), ibso.getInitiatorFio(), ibso.getInitiatorId(),
                    ibso.getConfidantFio(), ibso.getConfidantId(), ibso.getTrustName(), ibso.getTrustNumber());
        } else {
            return new TrustClob();
        }
    }




}
