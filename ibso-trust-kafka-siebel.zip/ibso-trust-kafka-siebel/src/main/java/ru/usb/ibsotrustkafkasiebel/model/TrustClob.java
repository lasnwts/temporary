package ru.usb.ibsotrustkafkasiebel.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Атрибут 	Обяз	Пример значения
 * TYPE	Y	Premium
 *
 * INITIATOR_FIO	Y	СЕМЕНОВА ИННА БОРИСОВНА
 * INITIATOR_ID	Y	554008941147
 * CONFIDANT_FIO	Y	СЕМЕНОВА АНАСТАСИЯ ВАЛЕРЬЕВНА
 * CONFIDANT_ID	Y	406100314554
 * TRUST_NAME	Y	Депозиты ФЛ
 * TRUST_NUMBER	Y	4643389
 * --
 * "Type":"CHBB",
 * "Initiator_fio":"СЕМЕНОВА ИННА БОРИСОВНА",
 * 		"INITIATOR_ID":"554008941147",
 * 		"Confidant_fio":"СЕМЕНОВА АНАСТАСИЯ ВАЛЕРЬЕВНА",
 * 		"Confidant_id":"406100314554",
 * "TRUST_NAME":"ВОО",
 * 		"TRUST_NUMBER":"4643389",
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class TrustClob {

    @JsonProperty("Type")
    private String type;

    @JsonProperty("Initiator_fio")
    private String initiatorFio;

    @JsonProperty("INITIATOR_ID")
    private String initiatorID;

    @JsonProperty("Confidant_fio")
    private String confidantFio;

    @JsonProperty("Confidant_id")
    private String confidantID;

    @JsonProperty("TRUST_NAME")
    private String trustName;

    @JsonProperty("TRUST_NUMBER")
    private String trustNumber;

    public TrustClob() {
        //
    }

    public TrustClob(String type, String initiatorFio, String initiatorID, String confidantFio,
                     String confidantID, String trustName, String trustNumber) {
        this.type = type;
        this.initiatorFio = initiatorFio;
        this.initiatorID = initiatorID;
        this.confidantFio = confidantFio;
        this.confidantID = confidantID;
        this.trustName = trustName;
        this.trustNumber = trustNumber;
    }

    @JsonProperty("Type")
    public String getType() {
        return type;
    }

    @JsonProperty("Type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("Initiator_fio")
    public String getInitiatorFio() {
        return initiatorFio;
    }

    @JsonProperty("Initiator_fio")
    public void setInitiatorFio(String initiatorFio) {
        this.initiatorFio = initiatorFio;
    }

    @JsonProperty("INITIATOR_ID")
    public String getInitiatorID() {
        return initiatorID;
    }

    @JsonProperty("INITIATOR_ID")
    public void setInitiatorID(String initiatorID) {
        this.initiatorID = initiatorID;
    }

    @JsonProperty("Confidant_fio")
    public String getConfidantFio() {
        return confidantFio;
    }

    @JsonProperty("Confidant_fio")
    public void setConfidantFio(String confidantFio) {
        this.confidantFio = confidantFio;
    }

    @JsonProperty("Confidant_id")
    public String getConfidantID() {
        return confidantID;
    }

    @JsonProperty("Confidant_id")
    public void setConfidantID(String confidantID) {
        this.confidantID = confidantID;
    }

    @JsonProperty("TRUST_NAME")
    public String getTrustName() {
        return trustName;
    }

    @JsonProperty("TRUST_NAME")
    public void setTrustName(String trustName) {
        this.trustName = trustName;
    }

    @JsonProperty("TRUST_NUMBER")
    public String getTrustNumber() {
        return trustNumber;
    }

    @JsonProperty("TRUST_NUMBER")
    public void setTrustNumber(String trustNumber) {
        this.trustNumber = trustNumber;
    }

    @Override
    public String toString() {
        return "TrustClob{" +
                "type='" + type + '\'' +
                ", initiatorFio='" + initiatorFio + '\'' +
                ", initiatorID='" + initiatorID + '\'' +
                ", confidantFio='" + confidantFio + '\'' +
                ", confidantID='" + confidantID + '\'' +
                ", trustName='" + trustName + '\'' +
                ", trustNumber='" + trustNumber + '\'' +
                '}';
    }
}
