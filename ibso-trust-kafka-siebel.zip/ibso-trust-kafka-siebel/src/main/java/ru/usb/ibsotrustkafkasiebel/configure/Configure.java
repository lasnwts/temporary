package ru.usb.ibsotrustkafkasiebel.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    /**
     * Управление смещением при старте программы
     * maxValueId; // Максимальное значение, которое было считано из БД
     * keyValue;   //Максимальное значение ключа (по нему будем определять, какое значение maxValueId брать в работу)
     */
    private long maxValueId; // Максимальное значение, которое было считано из БД
    private long keyValue;   //Максимальное значение ключа (по нему будем определять, какое значение maxValueId брать в работу)
    private boolean valueDone; //true - когда все значения из топика получены

    @Value("${service.admin.allow:false}")
    private boolean valueAdminDone; //true - когда все значения из топика получены, разрешения или запрещения от администратора
    private long offsetNow;
    private long offsetUnder;

    @Value("${service.table}")
    private String tableName;

    @Value("${kafka.consumer.topic}")
    private String ibsoTopicTrust;

    /**
     * Топик для отправки сообщения в Siebel
     */
    @Value("${siebel.topic:siebel-kafka-router.in}")
    private String siebelTopic;

    /**
     * Параметры Json сообщения для Siebel
     * system.from=MP-Hard
     * system.to=siebel
     */
    @Value("${system.from}")
    private String systemFrom;

    @Value("${system.to:siebel}")
    private String systemTo;

    @Value("${system.service}")
    private String systemService;

    /**
     * Application properties
     */

    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.application.version}")
    private String appVersion;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;


    /**
     * Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * service.log.debug
     * Детализация лога
     */
    @Value("${service.log.debug}")
    private boolean logDebug;


    /**
     * Security in properties     *
     */


    /**
     * Реализация)
     */
    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public boolean isLogDebug() {
        return logDebug;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    /**
     * Реализация для Siebel
     */

    public String getSystemFrom() {
        return systemFrom;
    }

    public String getSystemTo() {
        return systemTo;
    }

    public String getSiebelTopic() {
        return siebelTopic;
    }

    /**
     * Робота с max Value
     */
    public synchronized long getMaxValueId() {
        return maxValueId;
    }

    public synchronized void setMaxValueId(long maxValueId) {
        this.maxValueId = maxValueId;
    }

    public synchronized long getKeyValue() {
        return keyValue;
    }

    public synchronized void setKeyValue(long keyValue) {
        this.keyValue = keyValue;
    }

    public String getIbsoTopicTrust() {
        return ibsoTopicTrust;
    }

    public String getSystemService() {
        return systemService;
    }

    public long getOffsetNow() {
        return offsetNow;
    }

    public void setOffsetNow(long offsetNow) {
        this.offsetNow = offsetNow;
    }

    public long getOffsetUnder() {
        return offsetUnder;
    }

    public void setOffsetUnder(long offsetUnder) {
        this.offsetUnder = offsetUnder;
    }

    public boolean isValueDone() {
        return valueDone;
    }

    public String getTableName() {
        return tableName;
    }

    public void setValueDone(boolean valueDone) {
        this.valueDone = valueDone;
    }

    public boolean isValueAdminDone() {
        return valueAdminDone;
    }

    public void setValueAdminDone(boolean valueAdminDone) {
        this.valueAdminDone = valueAdminDone;
    }
}
