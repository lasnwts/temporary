package ru.usb.ibsotrustkafkasiebel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbsoTrustKafkaSiebelApplicationTests {

	@Test
	void contextLoads() {
	}

}
