package ru.alexsoft.pojotoxml;

import org.apache.juneau.html.HtmlSerializer;
import org.apache.juneau.json.JsonParser;
import org.apache.juneau.json.JsonSerializer;
import org.apache.juneau.xml.XmlSerializer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.alexsoft.pojotoxml.model.Product;

@SpringBootApplication
public class PojoToXmlApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(PojoToXmlApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("----------------------Start----------------------");

		//serialization:
		//pojo to json:
		JsonSerializer jsonSerializer =	JsonSerializer.DEFAULT_READABLE;
		String sellerNames[] = {"Neon Enterprise", "ABC Software", "XYZ IT solutions"};
		Product product = new Product("MAcbookPro", 1000, "White", sellerNames);
		String json = jsonSerializer.serialize(product);
		System.out.println("<JSON>");
		System.out.println(json);
		System.out.println("");

		System.out.println("******************");

		//pojo to xml:
		XmlSerializer xmlSerializer = XmlSerializer.DEFAULT_NS_SQ_READABLE;
		String xml = xmlSerializer.serialize(product);
		System.out.println("");
		System.out.println("<XML>");
		System.out.println(xml);
		System.out.println("");

		System.out.println("******************");

		//pojo to HTML:
		HtmlSerializer htmlSerializer = HtmlSerializer.DEFAULT_SQ_READABLE;
		String html = htmlSerializer.serialize(product);
		System.out.println("");
		System.out.println("<HTML>");
		System.out.println(html);
		System.out.println("");
		System.out.println("******************");
		System.out.println("");
		//deserialization:
		//JSON to POJO:
		JsonParser jsonParser = JsonParser.DEFAULT;
		String jsonVal = "{\n"
				+ "	\"color\": \"White\",\n"
				+ "	\"name\": \"MAcbookPro\",\n"
				+ "	\"price\": 1000,\n"
				+ "	\"sellerNames\": [\n"
				+ "		\"Neon Enterprise\",\n"
				+ "		\"ABC Software\",\n"
				+ "		\"XYZ IT solutions\"\n"
				+ "	]\n"
				+ "}";
		Product pro = jsonParser.parse(jsonVal, Product.class);
		System.out.println(pro.getColor());
		System.out.println(pro.getPrice());
		System.out.println("----------------------End  ----------------------");
	}
}
