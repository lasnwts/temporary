package ru.alexsoft.pojotoxml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PojoToXmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
