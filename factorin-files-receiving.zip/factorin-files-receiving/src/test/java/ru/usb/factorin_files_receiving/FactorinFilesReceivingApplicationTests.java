package ru.usb.factorin_files_receiving;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactorinFilesReceivingApplicationTests {

	@Test
	void contextLoads() {
	}

}
