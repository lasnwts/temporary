package ru.usb.factorin_files_receiving.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.Configure;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.sandbox.SandBoxResponse;
import ru.usb.factorin_files_receiving.model.sandboxresp.SandBoxCheck;
import ru.usb.factorin_files_receiving.service.factoring.GetFile;
import ru.usb.factorin_files_receiving.service.sandbox.CheckSandBox;
import ru.usb.factorin_files_receiving.service.sandbox.PutSandBox;
import ru.usb.factorin_files_receiving.service.token.GetToken;
import ru.usb.factorin_files_receiving.utils.MapperCheckSandBox;
import ru.usb.factorin_files_receiving.utils.MapperFacFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Optional;


@Log4j2
@Service
public class ApiLyaer {
    private final GetToken getToken;
    private final Configure configure;
    private final GetFile getFile;
    private final PutSandBox putSandBox;
    private final CheckSandBox checkSandBox;
    private final MapperFacFile mapperFacFile;
    private final MapperCheckSandBox mapperCheckSandBox;


    @Autowired
    public ApiLyaer(GetToken getToken, Configure configure, GetFile getFile, PutSandBox putSandBox,
                    CheckSandBox checkSandBox, MapperFacFile mapperFacFile, MapperCheckSandBox mapperCheckSandBox) {
        this.getToken = getToken;
        this.configure = configure;
        this.getFile = getFile;
        this.putSandBox = putSandBox;
        this.checkSandBox = checkSandBox;
        this.mapperFacFile = mapperFacFile;
        this.mapperCheckSandBox = mapperCheckSandBox;
    }

    /**
     * Запросить текущий токен
     *
     * @return - Токен
     */
    public String getToken() {
        if (configure.getTokenSync().isEmpty()) {
            getToken.getToken();
        }
        printTokenInfo();
        return configure.getTokenSync();
    }


    /**
     * Печать статуса токена в Configuration
     */
    private void printTokenInfo() {
        log.info("{}:Token info. Status Code={}", TG.UsbLogInfo, configure.getStatusCode());
        log.info("{}:Token info. Token={}", TG.UsbLogInfo, configure.getTokenSync());
    }

    /**
     * Запись файла во временный каталог
     *
     * @param name    - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()) {
            log.debug("{}:file.canWrite()=true", TG.UsbLogInfo);
        }
        if (file.canRead()) {
            log.debug("{}:file.canRead()=true", TG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:Error:FileOutputStream(file).write(content):{}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:FileOutputStream.write(content):stackTrace:", TG.UsbLogError, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Получить FacFile по uid
     *
     * @param uid - uid
     * @return - FacFile
     */
    public FacFile getUidFacFile(String uid) {
        return getFile.getFile(uid);
    }

    /**
     * Получить FacFile по File
     *
     * @param file - файл
     * @return - FacFile
     */
    public FacFile getFacFile(File file) {
        FacFile facFile = new FacFile();
        facFile.setFile(file);
        facFile.setName(file.getName());
        return facFile;
    }


    /**
     * Отправить файл в SandBox, из Rest API.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile putSandBox(FacFile facFile) {
        return putSandBox.putFileToSandBox(facFile);
    }

    /**
     * Проверить, что файл загружен и проверяется в SandBox.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile checkSandBox(FacFile facFile) {
        return checkSandBox.checkSandBox(facFile);
    }

    /**
     * Получить FacFile из json строки.
     * @param json - json строка
     * @return - FacFile
     */
    public Optional<FacFile> getFacString(String json){
        return mapperFacFile.getFacFile(json);
    }

    /**
     * Удалить файл из временной директории
     * @param facFile - FacFile
     * @return - FacFile
     * @throws IOException - ошибка
     */
    public FacFile delFile(FacFile facFile) throws IOException {
        if (Files.deleteIfExists(facFile.getFile().toPath())){
            facFile.setMessage("Файл удален из временной директории");
        } else {
            facFile.setMessage("Файл не удален из временной директории!");
        }
        return facFile;
    }

    /**
     * Получение объекта SandBoxCheck из json строки.
     * @param json - json строка
     * @return - SandBoxCheck
     */
    public Optional<SandBoxCheck> getSandBoxCheck(String json){
        return mapperCheckSandBox.getCheckSandBox(json);
    }
}
