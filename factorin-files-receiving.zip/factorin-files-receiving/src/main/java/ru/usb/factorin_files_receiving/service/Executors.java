package ru.usb.factorin_files_receiving.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.Configure;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.FactoringDocument;
import ru.usb.factorin_files_receiving.model.S3Result;
import ru.usb.factorin_files_receiving.service.factoring.GetFileThread;
import ru.usb.factorin_files_receiving.service.kafka.KafkaProducerService;
import ru.usb.factorin_files_receiving.service.mail.ServiceMailError;
import ru.usb.factorin_files_receiving.service.s3.AmazonS3ServiceImpl;
import ru.usb.factorin_files_receiving.service.sandbox.CheckSandBox;
import ru.usb.factorin_files_receiving.service.sandbox.PutSandBox;
import ru.usb.factorin_files_receiving.utils.MapperData;
import ru.usb.factorin_files_receiving.utils.MapperEvents;
import ru.usb.factorin_files_receiving.utils.Sutils;


import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Executor service
 */

@Service
public class Executors {
    /**
     * host.timeout=60
     * host.delta=20
     */

    @Value("${host.timeout:60}")
    private long hostTimeOut;

    @Value("${host.delta:10}")
    private long delta;

    //Constant
    String factoring = "Factorin";
    String message = "Message";


    private final MapperEvents mapperEvents;
    private final GetFileThread getFileThread;
    private final Sutils su;
    private final KafkaProducerService kafkaProducerService;
    private final Configure configure;
    private final ServiceMailError serviceMailError;
    private final MapperData mapperData;
    private final AmazonS3ServiceImpl amazonS3Service;
    private final CheckSandBox checkSandBox;
    private final PutSandBox putSandBox;


    /**
     * инициализация: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    @Autowired
    public Executors(MapperEvents mapperEvents, GetFileThread getFileThread, Sutils su,
                     KafkaProducerService kafkaProducerService, Configure configure,
                     ServiceMailError serviceMailError, MapperData mapperData,
                     AmazonS3ServiceImpl amazonS3Service, CheckSandBox checkSandBox,
                     PutSandBox putSandBox) {
        this.mapperEvents = mapperEvents;
        this.getFileThread = getFileThread;
        this.su = su;
        this.kafkaProducerService = kafkaProducerService;
        this.configure = configure;
        this.serviceMailError = serviceMailError;
        this.mapperData = mapperData;
        this.amazonS3Service = amazonS3Service;
        this.checkSandBox = checkSandBox;
        this.putSandBox = putSandBox;
    }

    Logger log = LoggerFactory.getLogger(Executors.class);


    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        log.info("{}:Запуск getTask потока, с сообщением:{}", TG.UsbLogInfo, messageBody);
        log.info("{}:Длина очереди задач:{}", TG.UsbLogInfo, configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            log.error("{}:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", TG.UsbLogError, e);
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
        }
        log.info("{}:Поток передан на запуск в executor service. Поток с сообщением:{}", TG.UsbLogInfo, messageBody);
    }

    class MyThread implements Runnable {
        String message;
        String kafkaMessage;
        CountDownLatch latch;


        MyThread(CountDownLatch c, String messageBody) {
            latch = c;
            message = messageBody;
            new Thread(this);
        }

        public void run() {
            log.info("{}:Запуск потока id={}", TG.UsbLogInfo, Thread.currentThread().getId());

            /**-
             * Основной процесс
             * @param value - сообщение из Кафка
             */
            //1 Проверяем, что событие парсится в документ событий
            Optional<FactoringDocument> factoringDocument = mapperEvents.getDocument(message);
            if (factoringDocument.isPresent()) {
                log.debug("{}:T{} Получено сообщение для обработки:{}", TG.UsbLogInfo, Thread.currentThread().getId(), factoringDocument);
                if (needFile(factoringDocument.get())) {
                    //2.1 Если событие существует, то...
                    process(factoringDocument.get());
                } else {
                    log.info("{}:T{} Событие {} не требует создания файла", TG.UsbLogInfo, Thread.currentThread().getId(), factoringDocument.get().getEventId());
                }
            } else {
                log.error("{}:T{} Error: Сообщение не распарсилось в объект событий:FactoringDocument, поэтому его просто игнорируем. Сообщение с кафка:{}", TG.UsbLogError,
                        Thread.currentThread().getId(), message);
            }
            //Подвал завершения потока
            log.info("{}:Поток завершен id={}", TG.UsbLogInfo, Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.info("{}:::Длина очереди задач={}", TG.UsbLogInfo, configure.getThreads());
        }

        /**
         * Описание потока начало
         */

        /**
         * Необходимо ли создавать файл для события
         *
         * @param factoringDocument - событие
         * @return - true, если нужен файл
         */
        private boolean needFile(FactoringDocument factoringDocument) {
            return !factoringDocument.getRegisterTemplateCode().equalsIgnoreCase("ReesterApproved")
                    || !factoringDocument.getEventName().equalsIgnoreCase("app_signed_factor");
        }

        /**
         * Получаем файл события и обрабатываем его
         *
         * @param factoringDocument - событие
         */
        private void process(FactoringDocument factoringDocument) {
            FacFile facFile;
            //2.1 Если событие существует, то пытаемся получить файл
            int i = 1;
            do {
                facFile = getFileThread.getFile(factoringDocument.getObjectId(), String.valueOf(Thread.currentThread().getId()));
                if (facFile != null && facFile.getStatus() == HttpStatus.OK) {
                    log.info("{}:T{} Получен файл:{}", TG.UsbLogInfo, Thread.currentThread().getId(), facFile);
                    break;
                }
                try {
                    log.info("{}:T{} Ждем {} секунд, попытка №{}", TG.UsbLogInfo, Thread.currentThread().getId(), hostTimeOut + i * delta, i);
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:T{} Ошибка при ожидании, InterruptedException:{}", TG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11;
                }
                i++; //+ 1 счетчик
            } while (i < 11 && facFile != null && facFile.getStatus() != HttpStatus.OK);

            //Продолжение обработки
            nextStepProcessing(facFile, factoringDocument);
        }


        /**
         * Продолжение обработки
         *
         * @param facFile           - файл события
         * @param factoringDocument - событие
         */
        private void nextStepProcessing(FacFile facFile, FactoringDocument factoringDocument) {
            if (facFile == null || facFile.getStatus() != HttpStatus.OK) {
                log.error("{}:T{} Файл не получен:{}", TG.UsbLogInfo, Thread.currentThread().getId(), facFile);
                //Factorin недоступен
                /**
                 * Формируем сообщение XML в data топик, при отсутствии связи с Factoring
                 * */
                try {
                    sendToDataTopic(su.createDataEvent(mapperData.getXML(message, null, null, new java.util.Date(),
                            null, null, "Factorin недоступен»"), new Date(), factoring, false, null, null, null, null));
                } catch (JsonProcessingException e) {
                    log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! [ Factorin недоступен» ] !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError, Thread.currentThread().getId());
                    log.error("{}:T{} Ошибка преобразования объекта [FactoringData] в JSON строку", TG.UsbLogError, Thread.currentThread().getId());
                    log.error("{}:T{} Описание ошибки:{}", TG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                    log.debug("{}:T{} Описание ошибки:", TG.UsbLogError, Thread.currentThread().getId(), e);
                    if (facFile != null && facFile.getMessage() != null) {
                        //Здесь сделать отправку почтовой ошибки
                        serviceMailError.sendMailErrorSubject("«Factorin недоступен»" + "Сервис получения данных из факторинга:" + configure.getAppName(),
                                "Ошибка преобразования объекта [FactoringData] в JSON строку. Описание ошибки:" + e.getMessage() + "\n\r" +
                                        ", message: " + facFile.getMessage());
                    } else {
                        serviceMailError.sendMailErrorSubject("«Factorin недоступен»" + "Сервис получения данных из факторинга:" + configure.getAppName(),
                                "Ошибка преоб�ования объекта [FactoringData] в JSON строку. Описание ошибки:" + e.getMessage());
                    }

                }
            } else {
                processDone(facFile, factoringDocument); //Дальнейшая обработка
            }
        }

        //Отправка сообщений в топик Data
        private void sendToDataTopic(String message) {
            kafkaProducerService.sendMessage(configure.getDataTopic(), "1", message);
        }


        /**
         * Отправка файла в s3
         */
        private S3Result pullFileToS3(S3Result s3Result, String bucket) {
            if (s3Result.getFacFile().getFile() != null) {
                try {
                    s3Result.setTag(amazonS3Service.putObject(bucket, s3Result.getFacFile().getFile().getName(), s3Result.getFacFile().getFile()));
                    if (s3Result.getTag() != null) {
                        s3Result.setResult(true);
                        log.info("{}:T{} Файл успешно записан в s3. Ссылка:{}", TG.UsbLogInfo, Thread.currentThread().getId(), s3Result.getTag());
                    } else {
                        s3Result.setResult(false);
                        log.info("{}:T{} Ошибка записи файла:{} в s3. Bucket:{}", TG.UsbLogInfo, Thread.currentThread().getId(),
                                s3Result.getFacFile().getFile().getName(), bucket);
                    }
                } catch (Exception e) {
                    log.error("{}:T{} Ошибка при отправке файла в s3:{}", TG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                    log.debug("{}:T{} Stack, Ошибка при отправке файла в s3:", TG.UsbLogError, Thread.currentThread().getId(), e);
                    s3Result.setResult(false);
                    s3Result.setDescription(e.getMessage());
                }
            } else {
                s3Result.setDescription("file == NULL!");
                s3Result.setResult(false);
            }
            return s3Result;
        }

        /**
         * Попытка отправить файл в s3, если не получается, то пытаемся снова
         *
         * @param facFile - FacFile
         * @return - S3Result
         */
        private S3Result pushS3Repeat(FacFile facFile, String bucket) {
            S3Result s3Result = new S3Result();
            s3Result.setFacFile(facFile);
            s3Result.setResult(false);
            int i = 1;
            do {
                if (pullFileToS3(s3Result, bucket).isResult()) {
                    break;
                }
                try {
                    log.info("{}:T{} pullFileToS3(s3Result), result={} Ждем {} секунд, попытка №{}", TG.UsbLogInfo, Thread.currentThread().getId(),
                            s3Result.isResult(), hostTimeOut + i * delta, i);
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:T{} pullFileToS3(s3Result) Ошибка, InterruptedException:{}", TG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11; //выходим
                }
                i++; //+ 1 счетчик
            } while (i < 11 && !s3Result.isResult());
            return s3Result;
        }

        /**
         * Отправка в s3 и запись в Data topic
         *
         * @param facFile           - FacFile
         * @param factoringDocument - FactoringDocument
         * @param bucket            - имя Bucket
         * @param deletedFile       - true файл удалить, false - нет
         */
        private S3Result toS3Bucket(FacFile facFile, FactoringDocument factoringDocument, String bucket, boolean deletedFile) {
            //Отправляем в bucket
            S3Result s3Result = pushS3Repeat(facFile, bucket);
            //Проверяем, если все в порядке, то завершаем.
            if (!s3Result.isResult()) {
                /**
                 * При этом количество попыток должно быть не менее 10 и обработка попыток должна выполняться нелинейно,
                 * т.е. каждая новая попытка с большим интервалом времени ожидания. Если все попытки завершены,
                 * то микросервис по п. 2.1.3 должен сгенерировать и передать сообщение по Email в службу технической
                 * поддержки (ServiceDesk), которое должно содержать наименование сервиса, сообщение («Не удалось передать в S3»),
                 * значения полей EventId, ObjectId, ShouldUnsubscribeOnSuccess.
                 */
                sendToDataTopic2(s3Result, factoringDocument, "Не удалось передать в S3", false);
                log.error("{}:T{} Ошибка при записи файла в s3:{}", TG.UsbLogError, Thread.currentThread().getId(), s3Result.getDescription());
                //Не удалось передать в S3
                serviceMailError.sendMailErrorSubject("Не удалось передать в S3",
                        "Не удалось передать в S3: \n\r" +
                                "--\n\r" +
                                "Исходное сообщение: " + factoringDocument + "\n\r" +
                                "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                "Файл: " + s3Result.getFacFile().getFile().getName());
                deletedFile = true; //Удаляем файл после неудачной попытке записать в s3
            }
            //Удаляем файл с диска
            delFileFromTemp(deletedFile, s3Result);
            return s3Result;
        }


        /**
         * Удаляем файл с диска, если он есть
         *
         * @param deletedFile - true, если файл нужно удалить
         * @param s3Result    - результат операции с S3
         */
        public void delFileFromTemp(boolean deletedFile, S3Result s3Result) {
            //Удаляем файл с диска
            if (deletedFile && s3Result.getFacFile().getFile().exists()) {
                log.info("{}:{} Удаляем более ненужный файл из временной директории:{} ", TG.UsbLogInfo, Thread.currentThread().getId(),
                        s3Result.getFacFile().getFile().getAbsolutePath());
                try {
                    Files.delete(s3Result.getFacFile().getFile().toPath());
                } catch (IOException e) {
                    log.error("{}:T{} Ошибка при удалении файла с диска:{}", TG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                }
            }
        }


        /**
         * Отправка в Data topic
         *
         * @param s3Result          -
         * @param factoringDocument -
         */
        public void sendToDataTopic2(S3Result s3Result, FactoringDocument factoringDocument, String msg, boolean result) {
            if (msg == null) msg = "";
            try {
                if (result) {
                    sendToDataTopic(su.createDataEvent(mapperData.getXML(message, s3Result.getFacFile().getFile().getName(), factoringDocument.getEventId(),
                                    new Date(), null, null, getMsg(msg, s3Result.getTag())), new Date(), factoring,
                            true, factoringDocument.getRegisterTemplateCode(), factoringDocument.getEventName(), factoringDocument.getEventId(),
                            factoringDocument.getObjectId()));
                } else {
                    sendToDataTopic(su.createDataEvent(mapperData.getXML(message, s3Result.getFacFile().getFile().getName(), factoringDocument.getEventId(),
                                    new Date(), null, null, getMsg(msg, s3Result.getTag())), new Date(), factoring,
                            false, factoringDocument.getRegisterTemplateCode(), factoringDocument.getEventName(), factoringDocument.getEventId(),
                            factoringDocument.getObjectId()));
                }
            } catch (JsonProcessingException e) {
                log.error("{}: T{}Ошибка при формировании сообщения в топик Data:{}, ошибка:{}, сообщение: {}", TG.UsbLogError, Thread.currentThread().getId(),
                        configure.getDataTopic(),
                        e.getMessage(), factoringDocument);
                serviceMailError.sendMailErrorSubject("Ошибка при формировании сообщения в топик Data",
                        "Шаг: Класс MessageProcess:  sendToDataTopic(su.createDataEvent(mapperData.getXML(...\n\r" +
                                "Ошибка:" + e.getMessage() + "\n\r" +
                                "--\n\r" +
                                "Исходное сообщение: " + factoringDocument + "\n\r" +
                                "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                "--\n\r" +
                                "Исходное сообщение: " + factoringDocument + "\n\r" +
                                "Результат обработки (S3Result): " + s3Result);
            }
        }

        /**
         * Получаем сообщение
         *
         * @param msg1 - сообщение 1
         * @param msg2 - сообщение 2
         * @return - сообщение
         */
        private String getMsg(String msg1, String msg2) {
            if (msg1 == null || msg1.isEmpty()) {
                if (msg2 == null || msg2.isEmpty()) {
                    return "";
                } else {
                    return msg2;
                }
            } else {
                return msg1;
            }
        }

        /**
         * Загрузка файла в SandBox
         *
         * @param s3Result - S3Result
         * @return - S3Result
         */
        public S3Result uploadFileToSandBox(S3Result s3Result) {
            if (s3Result.isResult()) {
                FacFile facFile = null;
                int i = 1;
                do {
                    facFile = putSandBox.putFileToSandBox(s3Result.getFacFile());
                    if (facFile.getCheckStatus() == 200) {
                        break;
                    }
                    try {
                        log.info("{}:T{} utSandBox.putFileToSandBox(s3Result.getFacFile()), result={} Ждем {} секунд, попытка №{}", TG.UsbLogInfo, Thread.currentThread().getId(),
                                facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                        Thread.sleep((hostTimeOut + i * delta) * 1000);
                    } catch (InterruptedException e) {
                        log.error("{}:T{} utSandBox.putFileToSandBox(s3Result.getFacFile()) Ошибка ожидания, InterruptedException:{}", TG.UsbLogError, Thread.currentThread().getId(),
                                e.getMessage());
                        Thread.currentThread().interrupt();
                        i = 11; //выходим
                    }
                    i++; //+ 1 счетчик
                } while (facFile.getCheckStatus() != 200 && i < 11);
                s3Result.setFacFile(facFile);
            } else {
                s3Result.getFacFile().setCheckStatus(-1); //Файл не загружен
                s3Result.getFacFile().setCheckMessage("Файл не загружался для проверки, потому что ранее не удалось загрузить фал в карантинный бакет s3");
            }
            return s3Result;
        }


        /**
         * Проверка файла
         *
         * @param facFile - FacFile
         * @return - true - break, false (условия не совпали)
         */
        private boolean checkClean(FacFile facFile) {
            if (facFile.getCheckStatus() == 200 && facFile.getResult().getVerdict().equalsIgnoreCase("CLEAN")
                    && facFile.getResult().getScanState().equalsIgnoreCase("FULL")) {
                facFile.setCheckStatus(201); //Успешно проверен
                facFile.setCheckMessage("Файл проверен успешно");
                return true;
            }
            if (facFile.getCheckStatus() == 200 && (facFile.getResult().getVerdict().equalsIgnoreCase("VIRUS")
                    || facFile.getResult().getVerdict().equalsIgnoreCase("DANGEROUS"))) {
                facFile.setCheckStatus(601); //Успешно проверен
                facFile.setCheckMessage("Файл содержит вирус!");
                log.info("{}:T{} Файл:{} содержит вирус.", TG.UsbLogInfo, Thread.currentThread().getId(), facFile.getFile().getName());
                return true;
            }
            if (facFile.getCheckStatus() == 401 || facFile.getCheckStatus() == 405) {
                facFile.setCheckMessage("Ошибка авторизации");
                log.error("{}:T{} Ошибка авторизации, файл:{} не проверить!.", TG.UsbLogError, Thread.currentThread().getId(), facFile.getFile().getName());
                return true;
            }
            if (facFile.getCheckStatus() == 404) {
                facFile.setCheckMessage("SandBox потерял файл!");
                log.error("{}:T{} SandBox потерял файл:{}. Придется его передать снова на проверку.", TG.UsbLogError, Thread.currentThread().getId(), facFile.getFile().getName());
                return true;
            }

            return false; //.Условия не совпали
        }

        /**
         * Проверка SandBox
         *
         * @param s3Result - S3Result
         * @return - S3Result
         */
        public S3Result checkSandBox(S3Result s3Result) {
            if (s3Result.isResult() && s3Result.getFacFile() != null && s3Result.getFacFile().getCheckStatus() == 200
                    && s3Result.getFacFile().getFileUri() != null && !s3Result.getFacFile().getFileUri().isEmpty()) {

                FacFile facFile = null;
                int i = 1;
                do {
                    facFile = checkSandBox.checkSandBox(s3Result.getFacFile());
                    /***
                     * В результате выполнения запроса PT Sandbox направляет сообщение с кодом 200 и текстом сообщения. Если в тексте сообщения указаны значения в полях:
                     * ­	scan_state = FULL;
                     * ­	verdict = CLEAN,
                     * то файл успешно прошел проверку и допускается для передачи в S3-хранилище (NetApp) в бакет постоянного хранения
                     */
                    if (checkClean(facFile)) {
                        break; //выходим
                    }
                    try {
                        log.info("{}:T{} checkSandBox.checkSandBox(s3Result.getFacFile(), result={} Ждем окончания проверки файла {} секунд, попытка №{}", TG.UsbLogInfo, Thread.currentThread().getId(),
                                facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                        Thread.sleep((hostTimeOut + i * delta) * 1000);
                    } catch (InterruptedException e) {
                        log.error("{}:T{} checkSandBox.checkSandBox(s3Result.getFacFile(), InterruptedException:{}", TG.UsbLogError,
                                Thread.currentThread().getId(), e.getMessage());
                        Thread.currentThread().interrupt();
                        i = 11; //выходим
                    }
                    i++; //+ 1 счетчик
                } while (i < 11);
                s3Result.setFacFile(facFile);
            } else {
                if (s3Result.getFacFile() != null){
                    s3Result.getFacFile().setCheckStatus(400); //Файл не загружен
                    s3Result.getFacFile().setCheckMessage("Возникли проблемы: ошибка в процессе передачи на проверку");
                }
            }
            return s3Result;
        }


        /**
         * Завершение обработки
         *
         * @param facFile           - FacFile
         * @param factoringDocument - FactoringDocument
         */
        public void processDone(FacFile facFile, FactoringDocument factoringDocument) {
            //Проверяем надо передавать в SandBox?
            if (configure.isCheckSandbox()) {
                //1.Помещаем файл в карантинный бакет и не удаляем! = toS3Bucket
                //2.Отправить файл на проверку в SandBox и удалить  = uploadFileToSandBox
                S3Result s3Result = uploadFileToSandBox(toS3Bucket(facFile, factoringDocument, configure.getBucketQuarantine(), false));

                //Запустить процедуру проверки check SandBox 401 и 405 отправить письмо и завершить работу
                if (s3Result.getFacFile().getCheckStatus() != 200) {
                    log.error("{}:T{} PT Sandbox проблема. processDone.uploadFileToSandBox(toS3Bucket.Описание ошибки:{}", TG.UsbLogError,
                            Thread.currentThread().getId(), s3Result.getFacFile().getCheckMessage());
                    serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема. Сервис получения новых данных из факторинга:" + configure.getAppName(),
                            "Ошибка при загрузке файла в SandBox для проверки. " + "\n\r" +
                                    "Имя файла: " + s3Result.getFacFile().getFile().getName() + "\n\r" +
                                    "Исходное сообщение: " + factoringDocument + "\n\r" +
                                    "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                    "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                    "--\n\r"
                                    + "\n\r" + "Status: " + s3Result.getFacFile().getCheckStatus() + "\n\r" +
                                    "Описание ошибки: " + s3Result.getFacFile().getCheckMessage()
                                    + "\n\r" + "Bucket: " + configure.getBucketQuarantine() + "\n\r" + " message: " + su.getWrapNull(facFile.getMessage()));
                    if (s3Result.getFacFile().getFile().exists()) {
                        //Удаляем файл с диска
                        delFileFromTemp(true, s3Result);
                    }
                } else {
                    //Файл успешно загружен в SandBox, идем его проверять
                    checkProcedureSandBox(facFile, s3Result, factoringDocument);
                }
            } else {
                //Отправляем в bucket
                toS3Bucket(facFile, factoringDocument, configure.getBucketBase(), true); //удалить файл после помещения в s3
            }
        }


        /**
         * Проверка Procedure SandBox
         *
         * @param facFile           - файл
         * @param s3Result          - S3Result
         * @param factoringDocument - FactoringDocument
         */
        private void checkProcedureSandBox(FacFile facFile, S3Result s3Result, FactoringDocument factoringDocument) {
            //checkSandBox(s3Result) - проверка файла в sandBox.
            S3Result s3ResultNow = checkSandBox(s3Result);
            switch (s3ResultNow.getFacFile().getCheckStatus()) {
                case 201: //Успешно проверен
                    success201(s3ResultNow, factoringDocument, facFile); //Все хорошо
                    break;
                case 401: //Ошибка
                    s3ResultNow.getFacFile().setCheckMessage("Возникла проблема с авторизацией, code=401");
                    sendLetterSmall(s3ResultNow, factoringDocument); //Пишем письмо
                    break;
                //Если файл потеряла система проверки, надо будет заново все прогнать,
                //Для этого просто отправим сообщение заново в топик event
                case 404: //Ошибка
                    log.info("{}:T{} PT Sandbox проблема. SandBox потерял файл - Ошибка 404. Возвращаю сообщение Factoring event в обработку:{}", TG.UsbLogError,
                            Thread.currentThread().getId(), mapperEvents.getJson(factoringDocument));
                    kafkaProducerService.sendMessage(configure.getEventTopic(), "404", mapperEvents.getJson(factoringDocument));
                    //Удаляем из
                    amazonS3Service.deleteFile(configure.getBucketQuarantine(), s3ResultNow.getFacFile().getFile().getName()); //Удаляем файл из карантина
                    break;
                case 405: //Ошибка
                    s3ResultNow.getFacFile().setCheckMessage("Возникла проблема с авторизацией, code=405");
                    sendLetterSmall(s3ResultNow, factoringDocument); //Пишем по аторизации
                    break;
                case 601: //Вирус
                    log.info("{}:T{} checkSandBox. Обнаружен вирус!", TG.UsbLogInfo, Thread.currentThread().getId());
                    s3ResultNow.getFacFile().setCheckMessage("Обнаружен вирус!");
                    if (s3Result.getFacFile().getResult() != null && s3Result.getFacFile().getResult().getVerdict() != null
                            && s3Result.getFacFile().getResult().getScanState() != null) {
                        log.info("{}:T{} checkSandBox. Результат проверки: ScanStat={}, Verdict={}", TG.UsbLogInfo, Thread.currentThread().getId(),
                                s3Result.getFacFile().getResult().getScanState(),
                                s3Result.getFacFile().getResult().getVerdict());
                        sendLetterBig(s3ResultNow, factoringDocument);
                    } else {
                        sendLetterSmall(s3ResultNow, factoringDocument);
                    }
                    //Удаляем из
                    amazonS3Service.deleteFile(configure.getBucketQuarantine(), s3ResultNow.getFacFile().getFile().getName()); //Удаляем файл из карантина
                    break;
                default:
                    log.error("{}:T{} PT Sandbox проблема. processDone.checkSandBox(s3Result) Описание:{}", TG.UsbLogError,
                            Thread.currentThread().getId(), s3Result.getFacFile().getCheckMessage());
                    //Файл проверен на вирусы, что то не так, пишем его состояние
                    if (s3Result.getFacFile().getResult() != null && s3Result.getFacFile().getResult().getVerdict() != null
                            && s3Result.getFacFile().getResult().getScanState() != null) {
                        log.info("{}:checkSandBox. Результат проверки: ScanStat={}, Verdict={}", TG.UsbLogInfo, s3Result.getFacFile().getResult().getScanState(),
                                s3Result.getFacFile().getResult().getVerdict());
                        sendLetterBig(s3ResultNow, factoringDocument);
                    } else {
                        sendLetterSmall(s3ResultNow, factoringDocument);
                    }
                    //Удаляем из
                    amazonS3Service.deleteFile(configure.getBucketQuarantine(), s3ResultNow.getFacFile().getFile().getName()); //Удаляем файл из карантина
                    break; //default
            }
            delFileFromTemp(true, s3ResultNow); //в любом случае удаляем временный файл с диска
        }


        /**
         * Обертка над значением null в строке
         *
         * @param line - переданная строка
         * @return - строка после проверки на NULL.
         */
        public String getWrapNull(String line) {
            if (line == null) {
                return "";
            } else {
                return line.trim();
            }
        }

        /**
         * Успешно проверенный файл без проблем
         *
         * @param s3ResultNow       -
         * @param factoringDocument -
         * @param facFile           -
         */
        private void success201(S3Result s3ResultNow, FactoringDocument factoringDocument, FacFile facFile) {
            try {
                log.info("{}:T{} Файл:{} успешно проверен. Удаляем его из карантинного бакета:{}", TG.UsbLogInfo, Thread.currentThread().getId(),
                        s3ResultNow.getFacFile().getFile().getName(), configure.getBucketQuarantine());
                amazonS3Service.deleteFile(configure.getBucketQuarantine(), s3ResultNow.getFacFile().getFile().getName()); //Удаляем файл из карантина
                //Отправляем в bucket
                if (toS3Bucket(facFile, factoringDocument, configure.getBucketBase(), true).isResult()) {//удалить файл после помещения в s3
                    log.info("{}:T{} Файл:{} успешно передан в бакет:{} ", TG.UsbLogInfo, Thread.currentThread().getId(),
                            s3ResultNow.getFacFile().getFile().getName(), configure.getBucketBase());
                    /**
                     * 11.	По результату выполнения п. 10 микросервис по п. 2.1.3 должен
                     * сформировать и записать сообщение в топик Kafka «factorin-to-activefactoring.data.0»
                     * (операция в ОТАР «Записать сообщение в топик Kafka «FactoringDocumentData»,
                     * записать в логи»). Обязательные параметры сообщения приведены в таблице 7.
                     */
                    //Отправляем в топик Data сообщение
                    sendToDataTopic2(s3ResultNow, factoringDocument, "Файл передан в хранилище s3:" + s3ResultNow.getTag(), true);
                }
            } catch (Exception e) {
                log.error("{}:T{} Возникла ошибка при попытке удалить файл:{} из бакета:{}, ссылка:{}", TG.UsbLogError, Thread.currentThread().getId(),
                        s3ResultNow.getFacFile().getFile().getName(), configure.getBucketQuarantine(), s3ResultNow.getTag());
                serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема.  Возникла ошибка при попытке удалить файл из s3 бакета:" + su.getWrapNull(s3ResultNow.getTag()),
                        "Ошибка  Описание ошибки: " + e.getMessage()
                                + "\n\r" + "Bucket: " + configure.getBucketQuarantine() + "\n\r" + " message: " + su.getWrapNull(facFile.getMessage()));
                delFileFromTemp(true, s3ResultNow); //подчищаем файл в случае неудачи при копировании
            }
        }


        /**
         * Отправка почтового сообщения, что есть проблема с авторизацией
         *
         * @param s3ResultNow       -
         * @param factoringDocument
         */
        private void sendLetterSmall(S3Result s3ResultNow, FactoringDocument factoringDocument) {
            serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема:" + configure.getAppName(),
                    "Ошибка при проверке файла в SandBox" + "\n\r" +
                            "Имя файла: " + s3ResultNow.getFacFile().getFile().getName() + "\n\r" +
                            "Исходное сообщение: " + factoringDocument + "\n\r" +
                            "EventId: " + factoringDocument.getEventId() + "\n\r" +
                            "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                            "--\n\r"
                            + "\n\r" + "Status: " + s3ResultNow.getFacFile().getCheckStatus() + "\n\r" +
                            "Описание ошибки: " + s3ResultNow.getFacFile().getCheckMessage());
        }

        /**
         * Письмо с более полной информацией
         *
         * @param s3ResultNow
         * @param factoringDocument
         */
        private void sendLetterBig(S3Result s3ResultNow, FactoringDocument factoringDocument) {
            serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема. " + "Сервис получения файла из факторинга:" + configure.getAppName(),
                    "Ошибка при проверке файла в SandBox" + "\n\r" +
                            "Имя файла: " + s3ResultNow.getFacFile().getFile().getName() + "\n\r" +
                            "Исходное сообщение: " + factoringDocument + "\n\r" +
                            "EventId: " + factoringDocument.getEventId() + "\n\r" +
                            "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                            "--\n\r"
                            + "\n\r" + "Status: " + s3ResultNow.getFacFile().getCheckStatus() + "\n\r" +
                            "--\n\r"
                            + "\n\r" + "ScanStat: " + s3ResultNow.getFacFile().getResult().getScanState() + "\n\r"
                            + "\n\r" + "Verdict: " + s3ResultNow.getFacFile().getResult().getVerdict() + "\n\r"
                            + "--\n\r"
                            + "Описание ошибки: " + s3ResultNow.getFacFile().getCheckMessage());
        }


        /**
         * Описание потока конец
         */

    }


}
