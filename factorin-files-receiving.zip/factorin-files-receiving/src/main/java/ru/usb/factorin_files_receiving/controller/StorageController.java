package ru.usb.factorin_files_receiving.controller;


import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.factorin_files_receiving.service.s3.AmazonS3Service;


import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/s3")
public class StorageController {
    private final AmazonS3Service s3Service;

    @Autowired
    public StorageController(@Qualifier("amazonS3ServiceImpl") AmazonS3Service s3Service) {
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/{bucketName}/files", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/{bucketName}/files. Метод : Upload. Метод загрузки файла в хранилище в корзину Bucket.")
    public Map<String, String> upload(
            @PathVariable("bucketName") String bucketName,
            @RequestPart(value = "file") MultipartFile files) throws Exception {
        s3Service.uploadFile(bucketName, files.getOriginalFilename(), files.getBytes());
        Map<String, String> result = new HashMap<>();
        result.put("key", files.getOriginalFilename());
        result.put("path", s3Service.getFileLink(bucketName, files.getOriginalFilename()));
        return result;
    }

    @GetMapping(value = "/{bucketName}/{keyName}", consumes = "application/octet-stream")
    @Operation(summary = "/{bucketName}/{keyName}. Метод Download file (получить / скачать файл) Метод получения файла из хранилища.")
    public ResponseEntity<ByteArrayResource> downloadFile(
            @PathVariable("bucketName") String bucketName,
            @PathVariable("keyName") String keyName) throws Exception {
        byte[] data = s3Service.downloadFile(bucketName, keyName);
        ByteArrayResource resource = new ByteArrayResource(data);

        ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                .filename(keyName, StandardCharsets.UTF_8)
                .build();
        return ResponseEntity
                .ok()
                .contentLength(data.length)
                .header("Content-type", "application/octet-stream")
                .header("Content-disposition", contentDisposition.toString())
                .body(resource);
    }

    @DeleteMapping("/{bucketName}/files/{keyName}")
    @Operation(summary = "/{bucketName}/files/{keyName}. Метод Delete Удаление файла из хранилища. bucketName - имя корзины, keyName - имя файла")
    public void delete(
            @PathVariable("bucketName") String bucketName,
            @PathVariable(value = "keyName") String keyName) throws Exception {
        s3Service.deleteFile(bucketName, keyName);
    }

    @GetMapping("/{bucketName}/files")
    @Operation(summary = "/{bucketName}/files. Метод Get list Objects in buckets. Получить список всех файлов в корзине хранилища")
    public List<String> listObjects(
            @PathVariable("bucketName") String bucketName) throws Exception {
        return s3Service.listFiles(bucketName);
    }

    @GetMapping("/{bucketName}/{key}")
    @Operation(summary = "/{bucketName}/{key}}. Метод ge tKey Link. Получить ссылку на файл.")
    public String getKeyLink(
            @PathVariable(name = "bucketName") String bucketName,
            @PathVariable(name = "key") String key) throws Exception {
        return s3Service.getFileLink(bucketName, key);
    }

}
