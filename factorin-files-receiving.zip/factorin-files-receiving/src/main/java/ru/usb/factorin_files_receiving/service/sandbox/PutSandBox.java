package ru.usb.factorin_files_receiving.service.sandbox;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.sandbox.SandBoxResponse;

import java.util.Date;

/**
 * Отправка файла в сэндбокс (песочница) *
 */

@Log4j2
@Service
public class PutSandBox {

    // Sandbox
    @Value("${sandbox.url-upload}")
    String sandboxUrlUpload;

    @Value("${sandbox.token}")
    String sandboxToken;

    public FacFile putFileToSandBox(FacFile facFile) {
        log.info("{}: Отправка файла:{} в SandBox на проверку", TG.UsbLogInfo, facFile.getFile().getAbsolutePath());
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-API-Key", sandboxToken);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        FileSystemResource fileSystemResource = new FileSystemResource(facFile.getFile().getAbsolutePath());
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileSystemResource);
        HttpEntity<Object> entity = new HttpEntity<>(body, headers);
        RestTemplate restTemplate = new RestTemplate();
        try {
            ResponseEntity<SandBoxResponse> response = restTemplate.postForEntity(sandboxUrlUpload, entity, SandBoxResponse.class);
            log.info("{}: Response:{}", TG.UsbLogInfo, response.getBody());
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && response.getBody().getData() != null && response.getBody().getErrors() != null) {
                facFile.setCheckStatus(200); //успешно передан на проверку
                facFile.setFileUri(response.getBody().getData().getFileUri());
                facFile.setCheckMessage("Файл передан в песочницу для проверки");
                facFile.setDate(new Date()); //Проставим дату
                facFile.setErrors(response.getBody().getErrors());
                log.info("{}: Файл передан в песочницу. Файл:{}", TG.UsbLogInfo, facFile.toString());
                return facFile;
            } else {
                facFile.setCheckStatus(response.getStatusCodeValue()); //ошибка передачи на проверку
                if (response.getBody() != null && response.getBody().getData() != null
                        && response.getBody().getData().getFileUri() != null){
                    facFile.setFileUri(response.getBody().getData().getFileUri());
                }
                facFile.setCheckMessage("Ошибка передачи файла в SandBox");
                facFile.setDate(new Date()); //Проставим дату
                if (response.getBody() != null && response.getBody().getErrors() != null){
                    facFile.setErrors(response.getBody().getErrors());
                }
            }
        } catch (HttpServerErrorException | HttpClientErrorException | ResourceAccessException e) {
            log.error("{}: Ошибка:{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: Ошибка: stack:{}", TG.UsbLogError, e);
            facFile.setCheckStatus(400); //ошибка передачи на проверку
            facFile.setCheckMessage(e.getMessage());
            return facFile; //возвращаем файл для дальнейшего разбора
        }
        log.info("{}: PutSandBox finished, File={}", TG.UsbLogInfo, facFile.getFile().getAbsolutePath());
        return facFile;
    }
}
