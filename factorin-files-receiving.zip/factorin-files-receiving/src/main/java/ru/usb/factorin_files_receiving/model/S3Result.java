package ru.usb.factorin_files_receiving.model;

import lombok.*;

/**
 * Результат обработки файла из факторинга в S3
 * S3Result =)
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class S3Result {

    private String tag; //ссылка на Файл в s3
    private FacFile facFile; //Обрабатываемый файл
    private boolean result;  //Успех = true, false - мимо
    private String description; // Описание ошибки


}
