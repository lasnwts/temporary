package ru.usb.factorin_files_receiving.model.sandbox;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.ArrayList;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SandBoxResponse {
    @JsonProperty("errors")
    private ArrayList<Errors> errors;
    @JsonProperty("data")
    private Data data;
}
