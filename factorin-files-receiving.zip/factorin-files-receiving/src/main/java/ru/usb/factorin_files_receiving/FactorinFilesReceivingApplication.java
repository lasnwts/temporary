package ru.usb.factorin_files_receiving;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.utils.MapperData;
import ru.usb.factorin_files_receiving.utils.Sutils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@Log4j2
@EnableScheduling
@SpringBootApplication
public class FactorinFilesReceivingApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(FactorinFilesReceivingApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API (factorin-files-receiving)")
                .version(appVersion)
                .description("API factorin-files-receiving, a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            log.info("{}: Directory:{}= created", TG.UsbLogInfo, path.toString());
        } else {
            log.info("{}: Directory: {}= already exists", TG.UsbLogInfo, path.toString());
            //Очистка каталога при старте
            try {
                Files.walk(path)
                        .filter(Files::isRegularFile)
                        .map(Path::toFile)
                        .forEach(File::delete);
            } catch (IOException e) {
                log.error("Directory: {} = Could not create upload folder!", path.toString());
                log.error("Print stackTrace:", e);
            }
        }

        log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Created by 12.06.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
        log.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);
        log.info("{}: Modified reason                   : 0.0.10", TG.UsbLogInfo);
        log.info("{}:-----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);

    }
}
