package ru.usb.factorin_files_receiving.service.s3;


import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.TG;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;

@Log4j2
@Service
public class AmazonS3ServiceImpl implements AmazonS3Service {
    private final AmazonS3 s3;

    @Autowired
    public AmazonS3ServiceImpl(AmazonS3 s3) {
        this.s3 = s3;
    }

    @Override
    public boolean uploadFile(String bucketName, String originalFilename, byte[] bytes) throws Exception {
        File file = upload(bucketName, originalFilename, bytes);
        PutObjectResult putObject = s3.putObject(bucketName, originalFilename, file);
        try {
            Files.delete(file.toPath());
        } catch (Exception e) {
            log.error("{}:Error! Temporary file not deleted:{}, error:{}", TG.UsbLogInfo, file.getAbsolutePath(), e.getMessage());
            log.debug("{}:Temporary file not deleted:stackTrace:", TG.UsbLogInfo, e);
            return false;
        }
        if (file.exists()) {
            log.error("{}:Error! Temporary file not deleted:{}", TG.UsbLogInfo, file.getAbsolutePath());
        }
        if (putObject != null && putObject.getETag() != null) {
            log.info("{}:File uploaded:{}", TG.UsbLogInfo, originalFilename);
            log.info("{}:s3 properties:eTag:{},ExpirationDateTime:{},versionId:{}", TG.UsbLogInfo, putObject.getETag(),
                    putObject.getExpirationTime(), putObject.getVersionId());
            return true;
        } else {
            log.info("{}:Error File not uploaded:{}", TG.UsbLogInfo, originalFilename);
            return false;
        }
    }

    @Override
    public byte[] downloadFile(String bucketName, String fileUrl) throws Exception {
        return getFile(bucketName, fileUrl);
    }

    @Override
    public void deleteFile(String bucketName, String fileUrl) throws Exception {
        s3.deleteObject(bucketName, fileUrl);
    }

    @Override
    public List<String> listFiles(String bucketName) throws Exception {
        List<String> list = new LinkedList<>();
        s3.listObjects(bucketName).getObjectSummaries().forEach(itemResult -> {
            list.add(itemResult.getKey());
            log.info("{}:ListFile:{}", TG.UsbLogInfo, itemResult.getKey());
        });
        return list;
    }

    @Override
    public File upload(String bucketName, String name, byte[] content) throws Exception {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()){
            log.debug("{}:file.canWrite()=true", TG.UsbLogInfo);
        }
        if (file.canRead()){
            log.debug("{}:file.canRead()=true", TG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:Error:FileOutputStream(file).write(content):{}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:FileOutputStream.write(content):stackTrace:", TG.UsbLogError, e);
        }

        return file;
    }

    @Override
    public byte[] getFile(String bucketName, String key) throws Exception {
        S3Object obj = s3.getObject(bucketName, key);
        S3ObjectInputStream stream = obj.getObjectContent();
        try {
            byte[] content = IOUtils.toByteArray(stream);
            obj.close();
            return content;
        } catch (IOException e) {
            log.error("{}:Error: {}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:{}", TG.UsbLogError, e);
        }
        return new byte[0];
    }

    @Override
    public String getFileLink(String bucketName, String key) throws Exception {
        boolean found = s3.doesBucketExist(bucketName);
        if (found) {
            log.info("{}:{}  bucket name exists/ Ok", TG.UsbLogInfo, bucketName);
        } else {
            log.info("{}: {} bucket name does not exist", TG.UsbLogInfo, bucketName);
            return bucketName + " bucket name does not exist";
        }
        String s3Url = s3.getUrl(bucketName, key).toExternalForm();
        log.info("{}: objectStat URL := {}", TG.UsbLogInfo, s3Url);
        return s3Url;
    }

}

