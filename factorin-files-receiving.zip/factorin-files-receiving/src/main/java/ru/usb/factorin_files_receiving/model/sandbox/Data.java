package ru.usb.factorin_files_receiving.model.sandbox;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {
    @JsonProperty("file_uri")
    private String fileUri;
    @JsonProperty("ttl")
    private int ttl;
}
