package ru.usb.factorin_files_receiving.service.sandbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.sandboxreq.JsonSandboxCheckReq;
import ru.usb.factorin_files_receiving.model.sandboxreq.Options;
import ru.usb.factorin_files_receiving.model.sandboxreq.Sandbox;
import ru.usb.factorin_files_receiving.model.sandboxresp.SandBoxCheck;

import java.util.List;


/**
 * SandBox
 * fileUri	String	Да	Временный URI файла, полученный в одноименном параметре в ответе на запрос загрузки файла
 * file_name	String	Нет	Название проверяемого файла. Если название не указано, в веб-интерфейсе PT Sandbox будет отображаться <Файл без названия>
 * Необходимо обязательно указывать формат – на этом строится логика работы PT Sandbox
 * async_result	Boolean	Нет	Значение по умолчанию = false. Возвращать только идентификатор задания на проверку.
 * Если = true, то это означает, что микросервис не должен дожидаться ответа и получить ответ отдельным запросом
 * short_result	Boolean	Нет	Значение по умолчанию = true. Возвращать только общий результат проверки.
 * Значение false этого параметра игнорируется, если для параметра async_result используется значение true.
 * options → analysis_depth	Integer	Нет	Глубина проверки. Максимальный уровень декомпозиции объектов с иерархической структурой (например, архивов, электронных писем и ссылок) или уровень декомпрессии сжатых файлов. При значении 0 проверка выполняется без декомпозиции и декомпрессии. Чем больше число, тем дольше может выполняться проверка.
 * <p>
 * Допустимые значения: 0—100. По умолчанию — 0
 * options → passwords_for_unpack	Array of strings	Нет	Список паролей для распаковки зашифрованных архивов
 * options → sandbox → analysisDuration	Integer	Нет	Продолжительность наблюдения за файлом в ходе поведенческого анализа (в секундах).
 * <p>
 * Допустимые значения: 10—600. По умолчанию — 60
 * options → sandbox → analysis_duration_bootkitmon	Integer	Нет	Продолжительность наблюдения за файлом в ходе поведенческого анализа после перезагрузки ОС (в секундах).
 * <p>
 * Допустимые значения: 10—600. По умолчанию — 60
 * options → sandbox → bootkitmon	Integer	Нет	Выполнить поведенческий анализ файла с перезагрузкой ОС.
 * <p>
 * Значение по умолчанию — false
 * options → sandbox → enabled	Boolean	Нет	Выполнить поведенческий анализ.
 * <p>
 * Значение по умолчанию — false
 * options → sandbox → file_types	Array of strings	Нет	Типы и группы типов проверяемых файлов.
 * <p>
 * По умолчанию проверяются все поддерживаемые типы файлов — ["adobe-acrobat/", "executable-files/", "presentations/", "spreadsheets/", "word-processor/"]
 * options → sandbox → image_id	String	Да, если значение options → sandbox → enabled — true	Идентификатор образа виртуальной машины
 * options → sandbox → mitm_enabled	Boolean	Нет	Включить подмену сертификатов ПО сертификатами PT Sandbox при расшифровке и анализе защищенного трафика.
 * <p>
 * Значение по умолчанию — false
 * options → sandbox → save_video	Boolean	Нет	Включить запись видео поведенческого анализа.
 * <p>
 * Значение по умолчанию — true
 * ----------------------
 * Пример запроса:
 * curl --location 'http://10.159.248.21/api/v1/analysis/createScanTask' \
 * --header 'X-API-Key: \
 * --header 'Cookie: utag=3284161e-7dfc-11ee-915e-fef93bdd329d' \
 * --data '{
 * "fileUri": "sfm-files:///2023-11-08-07/1f9ba466-7e09-11ee-9ef6-47ea1432a8c2/185a6df0-dcfb-4b2f-87f0-420cbcaeae93",
 * "file_name": "cca6ee11-436c-4aee-8cc8-602645637a3b_all.zip",
 * "async_result": false,
 * "short_result": false,
 * "options": {
 * "analysis_depth": 5,
 * "sandbox": {
 * "enabled": true,
 * "image_id": "win7-sp1-x64",
 * "analysisDuration": 60,
 * "save_video": false
 * }
 * }
 * }'
 */

@Log4j2
@Service
public class CheckSandBox {

    @Value("${sandbox.url-check}")
    String sandboxUrlCheck;
    @Value("${sandbox.token}")
    String sandboxToken;

    RestTemplate restTemplate = new RestTemplate();

    /**
     * Подготовка запроса на проверку файла
     * @param facFile - файл, который нужно проверить
     * @return - результат проверки
     */
    public FacFile checkSandBox(FacFile facFile) {
        // Запрос на проверку файла
        log.info("{}:CheckSandBox, Запрос на проверку файла в песочнице => file:{}, uri:{}", TG.UsbLogInfo, facFile.getFile().getAbsolutePath(), facFile.getFileUri());
        facFile.setCheckStatus(2); //в процессе проверки
        //Подготовка файла
        JsonSandboxCheckReq jsonSandboxCheckReq = getJsonSandboxCheckReq(facFile);

        try {
            String checkReqStr = new ObjectMapper().writeValueAsString(jsonSandboxCheckReq);
            log.info("{}: Подготовлен запрос на проверку файла в песочнице:{}", TG.UsbLogInfo, checkReqStr);

            HttpHeaders headersCheck = new HttpHeaders();
            headersCheck.setAccept(List.of(MediaType.APPLICATION_JSON));
            headersCheck.add("X-API-Key", sandboxToken);

            HttpEntity<Object> entityCheck = new HttpEntity<>(checkReqStr, headersCheck);
            ResponseEntity<String> responseCheck = restTemplate.postForEntity(sandboxUrlCheck, entityCheck, String.class);
            if (!responseCheck.getStatusCode().is2xxSuccessful()) {
                log.error("{}: Ошибка при запросе на проверку файла - Статус: {} Ответ: {}", TG.UsbLogError, responseCheck.getStatusCode(), responseCheck.getBody());
                facFile.setCheckStatus(3);
                facFile.setCheckMessage("Ошибка при запросе на проверку файла - Статус: " + responseCheck.getStatusCode() + " Ответ: " + responseCheck.getBody());
                return facFile;
            } else {
                SandBoxCheck jsonSandboxCheckResp = new ObjectMapper().readValue(responseCheck.getBody(), SandBoxCheck.class);
                if (!jsonSandboxCheckResp.getErrors().isEmpty()) {
                    log.error("{}: При проверке в песочнице файла:{}, возникла ошибка:{}", TG.UsbLogError, facFile.getFile().getName(), jsonSandboxCheckResp.getErrors().get(0).getMessage());
                    facFile.setCheckStatus(300);
                    facFile.setCheckMessage(jsonSandboxCheckResp.getErrors().get(0).getMessage());
                    return facFile;
                } else {
                    log.info("{}: Файл:{}, статус проверки: verdict={}, ScanState={}, duration={}", TG.UsbLogInfo, facFile.getFile().getName(),
                            jsonSandboxCheckResp.getData().getResult().getVerdict(),
                            jsonSandboxCheckResp.getData().getResult().getScanState(),
                            jsonSandboxCheckResp.getData().getResult().getDuration());
                    facFile.setResult(jsonSandboxCheckResp.getData().getResult());
                    facFile.setCheckStatus(responseCheck.getStatusCode().value()); //д.б. 200
                    return facFile;
                }
            }
        } catch (JsonProcessingException | HttpServerErrorException | HttpClientErrorException |
                 ResourceAccessException e) {
            log.error("{} Ошибка:{} при формировании запроса на проверку файла:{}", TG.UsbLogError, e.getMessage(), facFile.getFile().getName());
            log.debug("{} Ошибка:{} при формировании запроса на проверку файла:{}", TG.UsbLogError, e.getMessage(), facFile.getFile().getName());
            if (e instanceof HttpServerErrorException){
                log.error("{} HttpServerErrorException:{}", TG.UsbLogError, e.getMessage());
                if (((HttpServerErrorException) e).getStatusCode() == HttpStatus.NOT_FOUND){
                    facFile.setCheckStatus(404);
                } else {
                    facFile.setCheckStatus(((HttpServerErrorException) e).getStatusCode().value());
                }
            }
            if (e instanceof HttpClientErrorException){
                log.error("{} HttpClientErrorException:{}", TG.UsbLogError, e.getMessage());
                facFile.setCheckStatus(((HttpClientErrorException) e).getStatusCode().value());
            }
            facFile.setCheckMessage(e.getMessage());
            return facFile;
        }


    }

    @Value("${sandbox.analysis.duration:60}")
    private int sandboxAnalysisDuration;

    /**
     * Получение теля запроса
     *
     * @param facFile - объект FacFile
     * @return - тело запроса
     */
    private JsonSandboxCheckReq getJsonSandboxCheckReq(FacFile facFile) {
        JsonSandboxCheckReq jsonSandboxCheckReq = new JsonSandboxCheckReq();
        jsonSandboxCheckReq.setFileUri(facFile.getFileUri());
        jsonSandboxCheckReq.setFileName(facFile.getName());
        jsonSandboxCheckReq.setAsyncResult(false);
        jsonSandboxCheckReq.setShortResult(false);
        //SandBox
        Sandbox sandbox = new Sandbox();
        sandbox.setEnabled(true);
        sandbox.setImageId("win7-sp1-x64");
        sandbox.setAnalysisDuration(sandboxAnalysisDuration);
        sandbox.setSaveVideo(false);
        //Option
        Options options = new Options();
        options.setSandbox(sandbox);
        options.setAnalysisDepth(5); //Из fsd
        jsonSandboxCheckReq.setOptions(options);
        return jsonSandboxCheckReq;
    }
}
