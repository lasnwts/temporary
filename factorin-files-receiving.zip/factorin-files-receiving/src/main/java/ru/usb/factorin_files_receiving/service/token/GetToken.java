package ru.usb.factorin_files_receiving.service.token;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import ru.usb.factorin_files_receiving.configure.Configure;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.Token;

import java.util.Date;

/**
 * Класс получения токена
 */

@Log4j2
@Service
public class GetToken {

    private final Configure configure;
    ObjectMapper objectMapper = new ObjectMapper();


    @Autowired
    public GetToken(Configure configure) {
        this.configure = configure;
    }

    /**
     * Получение токена, true - успешный вариант, false - возникла ошибка
     *
     * @return - true - успешный вариант, false - возникла ошибка
     */
    public boolean getToken() {

        ResponseEntity<String> response = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(configure.getBasicUserName(), configure.getBasicPassword()); //Базовая авторизация


        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("username", configure.getTokenUserName());
        formData.add("password", configure.getTokenPassword());
        formData.add("grant_type", configure.getTokenGrantType());
        formData.add("scope", configure.getTokenScope());
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(formData, headers);

        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        try {
            response =
                    restTemplate.exchange(configure.getHostURL() + configure.getTokenURL(),
                            HttpMethod.POST,
                            entity,
                            String.class);
            Token token = objectMapper.readValue(response.getBody(), Token.class);
            log.debug("{}:Response::{}", TG.UsbLogInfo, response.getBody());
            configure.setTokenDate(new Date());
            if (response.getStatusCode().is2xxSuccessful()) {
                configure.setTokenSync(token.getAccessToken());
                configure.setStatusCode(200);
                configure.setStatusMessage("");
                return true;
            } else {
                configure.setTokenSync("");
                configure.setStatusCode(response.getStatusCodeValue());
                if (token.getErrorDescription() != null) {
                    configure.setStatusMessage(token.getErrorDescription());
                } else {
                    configure.setStatusMessage(token.getError());
                }
                log.error("{}:Ошибка получения токена. StatusCode:{}, ошибка:{}, тело  сообщения:{}", TG.UsbLogError,
                        response.getStatusCode(), configure.getStatusMessage(), response.getBody());
                return false;
            }
        } catch (Exception e) {
            log.error("{}:!!!!!!!!!!!!!ERROR:Запрос (POST) на получение токена!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            log.error("{}: Error :{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: StackTrace :", TG.UsbLogError, e);
            return false;
        }
    }
}
