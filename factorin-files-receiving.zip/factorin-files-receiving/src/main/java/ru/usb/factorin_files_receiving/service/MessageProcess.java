package ru.usb.factorin_files_receiving.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.Configure;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.FactoringDocument;
import ru.usb.factorin_files_receiving.model.S3Result;
import ru.usb.factorin_files_receiving.service.factoring.GetFile;
import ru.usb.factorin_files_receiving.service.kafka.KafkaProducerService;
import ru.usb.factorin_files_receiving.service.mail.ServiceMailError;
import ru.usb.factorin_files_receiving.service.s3.AmazonS3ServiceImpl;
import ru.usb.factorin_files_receiving.service.sandbox.CheckSandBox;
import ru.usb.factorin_files_receiving.service.sandbox.PutSandBox;
import ru.usb.factorin_files_receiving.utils.MapperData;
import ru.usb.factorin_files_receiving.utils.MapperEvents;
import ru.usb.factorin_files_receiving.utils.Sutils;

import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.Optional;

/**
 * Основной процесс обработки сообщений
 */

@Log4j2
@Service
public class MessageProcess {

    /**
     * host.timeout=60
     * host.delta=20
     */

    @Value("${host.timeout:60}")
    private long hostTimeOut;

    @Value("${host.delta}")
    private long delta;

    //Constant
    String factoring = "Factorin";
    String message = "Message";


    private final MapperEvents mapperEvents;
    private final GetFile getFile;
    private final Sutils su;
    private final KafkaProducerService kafkaProducerService;
    private final Configure configure;
    private final ServiceMailError serviceMailError;
    private final MapperData mapperData;
    private final AmazonS3ServiceImpl amazonS3Service;
    private final CheckSandBox checkSandBox;
    private final PutSandBox putSandBox;
    private final Executors executors;

    @Autowired
    public MessageProcess(MapperEvents mapperEvents, GetFile getFile,
                          Sutils su, KafkaProducerService kafkaProducerService, Configure configure,
                          ServiceMailError serviceMailError, MapperData mapperData,
                          AmazonS3ServiceImpl amazonS3Service, CheckSandBox checkSandBox, PutSandBox putSandBox, Executors executors) {
        this.mapperEvents = mapperEvents;
        this.getFile = getFile;
        this.su = su;
        this.kafkaProducerService = kafkaProducerService;
        this.configure = configure;
        this.serviceMailError = serviceMailError;
        this.mapperData = mapperData;
        this.amazonS3Service = amazonS3Service;
        this.checkSandBox = checkSandBox;
        this.putSandBox = putSandBox;
        this.executors = executors;
    }

    //Количество потоков
    @Value("${service.pool.size:1}")
    private int poolSize;

    /**
     * Выбор режима работы
     *
     * @param body - сообщение из Кафка
     */
    public void processChoice(String body) {
        if (poolSize == 1) {
            processWorker(body);
        } else {
            executors.getTask(body);
        }
    }

    /**
     * Основной процесс
     *
     * @param value - сообщение из Кафка
     */
    public void processWorker(String value) {
        //1 Проверяем, что событие парсится в документ событий
        Optional<FactoringDocument> factoringDocument = mapperEvents.getDocument(value);
        if (factoringDocument.isPresent()) {
            log.debug("{} Получено сообщение для обработки:{}", TG.UsbLogInfo, factoringDocument);
            if (needFile(factoringDocument.get())) {
                //2.1 Если событие существует, то...
                process(factoringDocument.get());
            } else {
                log.info("{} Событие {} не требует создания файла", TG.UsbLogInfo, factoringDocument.get().getEventId());
            }
        } else {
            log.error("{} Error: Сообщение не распарсилось в объект событий:FactoringDocument, поэтому его просто игнорируем. Сообщение с кафка:{}", TG.UsbLogError, value);
        }
    }

    /**
     * Необходимо ли создавать файл для события
     *
     * @param factoringDocument - событие
     * @return - true, если нужен файл
     */
    private boolean needFile(FactoringDocument factoringDocument) {
        return !factoringDocument.getRegisterTemplateCode().equalsIgnoreCase("ReesterApproved")
                || !factoringDocument.getEventName().equalsIgnoreCase("app_signed_factor");
    }

    /**
     * Получаем файл события и обрабатываем его
     *
     * @param factoringDocument - событие
     */
    private void process(FactoringDocument factoringDocument) {
        FacFile facFile = null;
        //2.1 Если событие существует, то пытаемся получить файл
        int i = 1;
        do {
            facFile = getFile.getFile(factoringDocument.getObjectId());
            if (facFile.getStatus() == HttpStatus.OK) {
                log.info("{}: Получен файл:{}", TG.UsbLogInfo, facFile.toString());
                break;
            }
            try {
                log.info("{}:Ждем {} секунд, попытка №{}", TG.UsbLogInfo, hostTimeOut + i * delta, i);
                Thread.sleep((hostTimeOut + i * delta) * 1000);
            } catch (InterruptedException e) {
                log.error("{}: Ошибка при ожидании, InterruptedException:{}", TG.UsbLogError, e.getMessage());
                Thread.currentThread().interrupt();
                i = 11;
            }
            i++; //+ 1 счетчик
        } while (i < 11 && facFile.getStatus() != HttpStatus.OK);

        if (facFile == null || facFile.getStatus() != HttpStatus.OK) {
            log.error("{}:Файл не получен:{}", TG.UsbLogInfo, facFile.toString());
            //Factorin недоступен
            /**
             * Формируем сообщение XML в data топик, при отсутствии новых сообщений
             */
            try {
                sendToDataTopic(su.createDataEvent(mapperData.getXML(message, null, null, new java.util.Date(),
                        null, null, "Factorin недоступен»"), new Date(), factoring, false, null, null, null, null));
            } catch (JsonProcessingException e) {
                log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! [ Factorin недоступен» ] !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
                log.error("{}:Ошибка преобразования объекта [FactoringData] в JSON строку", TG.UsbLogError);
                log.error("{}: Описание ошибки:{}", TG.UsbLogError, e.getMessage());
                log.debug("{}:Описание ошибки:", TG.UsbLogError, e);
                //Здесь сделать отправку почтовой ошибки
                serviceMailError.sendMailErrorSubject("«Factorin недоступен»" + "Сервис получения данных из факторинга:" + configure.getAppName(),
                        "Ошибка преобразования объекта [FactoringData] в JSON строку. Описание ошибки:" + e.getMessage() + "\n\r" +
                                ", message: " + su.getWrapNull(facFile.getMessage()));
            }
        } else {
            processDone(facFile, factoringDocument); //Дальнейшая обработка
        }
    }


    //Отправка сообщений в топик Data
    private void sendToDataTopic(String message) {
        kafkaProducerService.sendMessage(configure.getDataTopic(), "1", message);
    }


    /**
     * Отправка файла в s3
     */
    private S3Result pullFileToS3(S3Result s3Result, String bucket) {
        if (s3Result.getFacFile().getFile() != null) {
            try {
                s3Result.setTag(amazonS3Service.putObject(bucket, s3Result.getFacFile().getFile().getName(), s3Result.getFacFile().getFile()));
                if (s3Result.getTag() != null) {
                    s3Result.setResult(true);
                    log.info("{}: Файл успешно записан в s3. Ссылка:{}", TG.UsbLogInfo, s3Result.getTag());
                } else {
                    s3Result.setResult(false);
                    log.info("{}: Ошибка записи файла:{} в s3. Bucket:{}", TG.UsbLogInfo, s3Result.getFacFile().getFile().getName(), bucket);
                }
            } catch (Exception e) {
                log.error("{}: Ошибка при отправке файла в s3:{}", TG.UsbLogError, e.getMessage());
                log.debug("{}: Ошибка при отправке файла в s3:{}", TG.UsbLogError, e);
                s3Result.setResult(false);
                s3Result.setDescription(e.getMessage());
            }
        } else {
            s3Result.setDescription("file == NULL!");
            s3Result.setResult(false);
        }
        return s3Result;
    }

    /**
     * Попытка отправить файл в s3, если не получается, то пытаемся снова
     *
     * @param facFile - FacFile
     * @return - S3Result
     */
    private S3Result pushS3Repeat(FacFile facFile, String bucket) {
        S3Result s3Result = new S3Result();
        s3Result.setFacFile(facFile);
        s3Result.setResult(false);
        int i = 1;
        do {
            if (pullFileToS3(s3Result, bucket).isResult()) {
                break;
            }
            try {
                log.info("{}:pullFileToS3(s3Result), result={} Ждем {} секунд, попытка №{}", TG.UsbLogInfo, s3Result.isResult(), hostTimeOut + i * delta, i);
                Thread.sleep((hostTimeOut + i * delta) * 1000);
            } catch (InterruptedException e) {
                log.error("{}:pullFileToS3(s3Result) Ошибка при ожидании, InterruptedException:{}", TG.UsbLogError, e.getMessage());
                Thread.currentThread().interrupt();
                i = 11; //выходим
            }
            i++; //+ 1 счетчик
        } while (i < 11 && !s3Result.isResult());
        return s3Result;
    }

    /**
     * Отправка в s3 и запись в Data topic
     *
     * @param facFile           - FacFile
     * @param factoringDocument - FactoringDocument
     * @param bucket            - имя Bucket
     * @param deletedFile       - true файл удалить, false - нет
     */
    private S3Result toS3Bucket(FacFile facFile, FactoringDocument factoringDocument, String bucket, boolean deletedFile) {
        //Отправляем в bucket
        S3Result s3Result = pushS3Repeat(facFile, bucket);
        //Проверяем, если все в порядке, то завершаем.
        if (!s3Result.isResult()) {
            /**
             * При этом количество попыток должно быть не менее 10 и обработка попыток должна выполняться нелинейно,
             * т.е. каждая новая попытка с большим интервалом времени ожидания. Если все попытки завершены,
             * то микросервис по п. 2.1.3 должен сгенерировать и передать сообщение по Email в службу технической
             * поддержки (ServiceDesk), которое должно содержать наименование сервиса, сообщение («Не удалось передать в S3»),
             * значения полей EventId, ObjectId, ShouldUnsubscribeOnSuccess.
             */
            sendToDataTopic2(s3Result, factoringDocument, "Не удалось передать в S3", false);
            log.error("{}:Ошибка при записи файла в s3:{}", TG.UsbLogError, s3Result.getDescription());
            //Не удалось передать в S3
            serviceMailError.sendMailErrorSubject("Не удалось передать в S3",
                    "Не удалось передать в S3: \n\r" +
                            "--\n\r" +
                            "Исходное сообщение: " + factoringDocument + "\n\r" +
                            "EventId: " + factoringDocument.getEventId() + "\n\r" +
                            "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                            "Файл: " + s3Result.getFacFile().getFile().getName());
            deletedFile = true; //Удаляем файл после неудачной попытке записать в s3
        }
        //Удаляем файл с диска
        delFileFromTemp(deletedFile, s3Result);
        return s3Result;
    }


    /**
     * Удаляем файл с диска, если он есть
     *
     * @param deletedFile - true, если файл нужно удалить
     * @param s3Result    - результат операции с S3
     */
    public void delFileFromTemp(boolean deletedFile, S3Result s3Result) {
        //Удаляем файл с диска
        if (deletedFile && s3Result.getFacFile().getFile().exists()) {
            log.info("{} Удаляем более ненужный файл из временной директории:{} ", TG.UsbLogInfo, s3Result.getFacFile().getFile().getAbsolutePath());
            try {
                Files.delete(s3Result.getFacFile().getFile().toPath());
            } catch (IOException e) {
                log.error("{}:Ошибка при удалении файла с диска:{}", TG.UsbLogError, e.getMessage());
            }
        }
    }


    /**
     * Отправка в Data topic
     *
     * @param s3Result          -
     * @param factoringDocument -
     */
    public void sendToDataTopic2(S3Result s3Result, FactoringDocument factoringDocument, String msg, boolean result) {
        if (msg == null) msg = "";
        try {
            if (result) {
                sendToDataTopic(su.createDataEvent(mapperData.getXML(message, s3Result.getFacFile().getFile().getName(), factoringDocument.getEventId(),
                                new Date(), null, null, getMsg(msg, s3Result.getTag())), new Date(), factoring,
                        true, factoringDocument.getRegisterTemplateCode(), factoringDocument.getEventName(), factoringDocument.getEventId(),
                        factoringDocument.getObjectId()));
            } else {
                sendToDataTopic(su.createDataEvent(mapperData.getXML(message, s3Result.getFacFile().getFile().getName(), factoringDocument.getEventId(),
                                new Date(), null, null, getMsg(msg, s3Result.getTag())), new Date(), factoring,
                        false, factoringDocument.getRegisterTemplateCode(), factoringDocument.getEventName(), factoringDocument.getEventId(),
                        factoringDocument.getObjectId()));
            }
        } catch (JsonProcessingException e) {
            log.error("{}:Ошибка при формировании сообщения в топик Data:{}, ошибка:{}, сообщение: {}", TG.UsbLogError, configure.getDataTopic(),
                    e.getMessage(), factoringDocument.toString());
            serviceMailError.sendMailErrorSubject("Ошибка при формировании сообщения в топик Data",
                    "Шаг: Класс MessageProcess:  sendToDataTopic(su.createDataEvent(mapperData.getXML(...\n\r" +
                            "Ошибка:" + e.getMessage() + "\n\r" +
                            "--\n\r" +
                            "Исходное сообщение: " + factoringDocument + "\n\r" +
                            "EventId: " + factoringDocument.getEventId() + "\n\r" +
                            "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                            "--\n\r" +
                            "Исходное сообщение: " + factoringDocument + "\n\r" +
                            "Результат обработки (S3Result): " + s3Result);
        }
    }

    /**
     * Получаем сообщение
     *
     * @param msg1 - сообщение 1
     * @param msg2 - сообщение 2
     * @return - сообщение
     */
    private String getMsg(String msg1, String msg2) {
        if (msg1 == null || msg1.isEmpty()) {
            if (msg2 == null || msg2.isEmpty()) {
                return "";
            } else {
                return msg2;
            }
        } else {
            return msg1;
        }
    }

    /**
     * Загрузка файла в SandBox
     *
     * @param s3Result - S3Result
     * @return - S3Result
     */
    public S3Result uploadFileToSandBox(S3Result s3Result) {
        if (s3Result.isResult()) {
            FacFile facFile = null;
            int i = 1;
            do {
                facFile = putSandBox.putFileToSandBox(s3Result.getFacFile());
                if (facFile.getCheckStatus() == 200) {
                    break;
                }
                try {
                    log.info("{}:utSandBox.putFileToSandBox(s3Result.getFacFile()), result={} Ждем {} секунд, попытка №{}", TG.UsbLogInfo, facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:utSandBox.putFileToSandBox(s3Result.getFacFile()) Ошибка при ожидании, InterruptedException:{}", TG.UsbLogError, e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11; //выходим
                }
                i++; //+ 1 счетчик
            } while (facFile.getCheckStatus() != 200 && i < 11);
            s3Result.setFacFile(facFile);
        } else {
            s3Result.getFacFile().setCheckStatus(-1); //Файл не загружен
            s3Result.getFacFile().setCheckMessage("Файл не загружался для проверки, потому что ранее не удалось загрузить фал в карантинный бакет s3");
        }
        return s3Result;
    }


    /**
     * Проверка SandBox
     *
     * @param s3Result - S3Result
     * @return - S3Result
     */
    public S3Result checkSandBox(S3Result s3Result) {
        if (s3Result.isResult() && s3Result.getFacFile() != null && s3Result.getFacFile().getCheckStatus() == 200
                && s3Result.getFacFile().getFileUri() != null && !s3Result.getFacFile().getFileUri().isEmpty()) {

            FacFile facFile = null;
            int i = 1;
            do {
                facFile = checkSandBox.checkSandBox(s3Result.getFacFile());
                /***
                 * В результате выполнения запроса PT Sandbox направляет сообщение с кодом 200 и текстом сообщения. Если в тексте сообщения указаны значения в полях:
                 * ­	scan_state = FULL;
                 * ­	verdict = CLEAN,
                 * то файл успешно прошел проверку и допускается для передачи в S3-хранилище (NetApp) в бакет постоянного хранения
                 */
                if (facFile != null && facFile.getCheckStatus() == 200 && facFile.getResult().getVerdict().equalsIgnoreCase("CLEAN")
                        && facFile.getResult().getScanState().equalsIgnoreCase("FULL")) {
                    facFile.setCheckStatus(201); //Успешно проверен
                    facFile.setCheckMessage("Файл проверен успешно");
                    break;
                }
                try {
                    log.info("{}:checkSandBox.checkSandBox(s3Result.getFacFile(), result={} Ждем окончания проверки файла {} секунд, попытка №{}", TG.UsbLogInfo, facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                    if (facFile != null && facFile.getCheckStatus() == 200 && facFile.getResult() != null && facFile.getResult().getVerdict() != null
                            && facFile.getResult().getScanState() != null) {
                        log.info("{}:checkSandBox. Промежуточный результат проверки: ScanStat={}, Verdict={}", TG.UsbLogInfo, facFile.getResult().getScanState(), facFile.getResult().getVerdict());
                    }
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:checkSandBox.checkSandBox(s3Result.getFacFile() Ошибка при ожидании, InterruptedException:{}", TG.UsbLogError, e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11; //выходим
                }
                i++; //+ 1 счетчик
            } while (i < 11);
            s3Result.setFacFile(facFile);
        } else {
            s3Result.getFacFile().setCheckStatus(400); //Файл не загружен
            s3Result.getFacFile().setCheckMessage("Возникли проблемы: ошибка в процессе передачи на проверку");
        }
        return s3Result;
    }


    /**
     * Завершение обработки
     *
     * @param facFile           - FacFile
     * @param factoringDocument - FactoringDocument
     */
    public void processDone(FacFile facFile, FactoringDocument factoringDocument) {
        //Проверяем надо передавать в SandBox?
        if (configure.isCheckSandbox()) {
            //1.Помещаем файл в карантинный бакет и не удаляем! = toS3Bucket
            //2.Отправить файл на проверку в SandBox и удалить  = uploadFileToSandBox
            S3Result s3Result = uploadFileToSandBox(toS3Bucket(facFile, factoringDocument, configure.getBucketQuarantine(), false));

            //Запустить процедуру проверки check SandBox 401 и 405 отправить письмо и завершить работу
            if (s3Result.getFacFile().getCheckStatus() != 200) {
                log.error("{} PT Sandbox проблема. processDone.uploadFileToSandBox(toS3Bucket. Ошибка  Описание ошибки:{}", TG.UsbLogError, s3Result.getFacFile().getCheckMessage());
                serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема. Сервис получения новых данных из факторинга:" + configure.getAppName(),
                        "Ошибка при загрузке файла в SandBox для проверки. " + "\n\r" +
                                "Имя файла: " + s3Result.getFacFile().getFile().getName() + "\n\r" +
                                "Исходное сообщение: " + factoringDocument + "\n\r" +
                                "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                "--\n\r"
                                + "\n\r" + "Status: " + s3Result.getFacFile().getCheckStatus() + "\n\r" +
                                "Описание ошибки: " + s3Result.getFacFile().getCheckMessage()
                                + "\n\r" + "Bucket: " + configure.getBucketQuarantine() + "\n\r" + " message: " + su.getWrapNull(facFile.getMessage()));
                if (s3Result.getFacFile().getFile().exists()) {
                    //Удаляем файл с диска
                    delFileFromTemp(true, s3Result);
                }
            } else {
                //Файл успешно загружен в SandBox, идем его проверять
                checkProcedureSandBox(facFile, s3Result, factoringDocument);
            }
        } else {
            //Отправляем в bucket
            toS3Bucket(facFile, factoringDocument, configure.getBucketBase(), true); //удалить файл после помещения в s3
        }
    }


    /**
     * Проверка Procedure SandBox
     *
     * @param facFile           - файл
     * @param s3Result          - S3Result
     * @param factoringDocument - FactoringDocument
     */
    private void checkProcedureSandBox(FacFile facFile, S3Result s3Result, FactoringDocument factoringDocument) {
        //checkSandBox(s3Result) - проверка файла в sandBox.
        S3Result s3ResultNow = checkSandBox(s3Result);
        if (s3ResultNow.getFacFile().getCheckStatus() == 201) {  //Успешно пройдена проверка = 201
            try {
                log.info("{}: Файл:{} успешно проверен. Удаляем его из карантинного бакета:{}", TG.UsbLogInfo,
                        s3ResultNow.getFacFile().getFile().getName(), configure.getBucketQuarantine());
                amazonS3Service.deleteFile(configure.getBucketQuarantine(), s3ResultNow.getFacFile().getFile().getName()); //Удаляем файл из карантина
                //Отправляем в bucket
                if (toS3Bucket(facFile, factoringDocument, configure.getBucketBase(), true).isResult()) {//удалить файл после помещения в s3
                    log.info("{}: Файл:{} успешно передан в бакет:{} ", TG.UsbLogInfo,
                            s3ResultNow.getFacFile().getFile().getName(), configure.getBucketBase());
                    /**
                     * 11.	По результату выполнения п. 10 микросервис по п. 2.1.3 должен
                     * сформировать и записать сообщение в топик Kafka «factorin-to-activefactoring.data.0»
                     * (операция в ОТАР «Записать сообщение в топик Kafka «FactoringDocumentData»,
                     * записать в логи»). Обязательные параметры сообщения приведены в таблице 7.
                     */
                    //Отправляем в топик Data сообщение
                    sendToDataTopic2(s3ResultNow, factoringDocument, "Файл передан в хранилище s3:" + s3ResultNow.getTag(), true);
                }
            } catch (Exception e) {
                log.error("{}: Возникла ошибка при попытке удалить файл:{} из бакета:{}, ссылка:{}", TG.UsbLogError,
                        s3ResultNow.getFacFile().getFile().getName(), configure.getBucketQuarantine(), s3ResultNow.getTag());
                serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема.  Возникла ошибка при попытке удалить файл из s3 бакета:" + su.getWrapNull(s3ResultNow.getTag()),
                        "Ошибка  Описание ошибки: " + e.getMessage()
                                + "\n\r" + "Bucket: " + configure.getBucketQuarantine() + "\n\r" + " message: " + su.getWrapNull(facFile.getMessage()));
                delFileFromTemp(true, s3ResultNow); //подчищаем файл в случае неудачи при копировании
            }
        } else {
            //Если файл потеряла система проверки, надо будет заново все прогнать,
            //Для этого просто отправим сообщение заново в топик event
            if (s3ResultNow.getFacFile().getCheckStatus() == 404) {
                log.info("{}: PT Sandbox проблема. SandBox потерял файл - Ошибка 404. Возвращаю сообщение Factoring event в обработку:{}", TG.UsbLogError, mapperEvents.getJson(factoringDocument));
                kafkaProducerService.sendMessage(configure.getEventTopic(), "404", mapperEvents.getJson(factoringDocument));
            } else {
                log.error("{} PT Sandbox проблема. processDone.checkSandBox(s3Result) Ошибка  Описание ошибки:{}", TG.UsbLogError, s3Result.getFacFile().getCheckMessage());
                if (s3Result.getFacFile().getResult() != null && s3Result.getFacFile().getResult().getVerdict() != null
                        && s3Result.getFacFile().getResult().getScanState() != null) {
                    log.info("{}:checkSandBox. Результат проверки: ScanStat={}, Verdict={}", TG.UsbLogInfo, s3Result.getFacFile().getResult().getScanState(), s3Result.getFacFile().getResult().getVerdict());
                    serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема. " + "Сервис получения файла из факторинга:" + configure.getAppName(),
                            "Ошибка при проверке файла в SandBox" + "\n\r" +
                                    "Имя файла: " + s3ResultNow.getFacFile().getFile().getName() + "\n\r" +
                                    "Исходное сообщение: " + factoringDocument + "\n\r" +
                                    "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                    "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                    "--\n\r"
                                    + "\n\r" + "Status: " + s3ResultNow.getFacFile().getCheckStatus() + "\n\r" +
                                    "--\n\r"
                                    + "\n\r" + "ScanStat: " + s3ResultNow.getFacFile().getResult().getScanState() + "\n\r"
                                    + "\n\r" + "Verdict: " + s3ResultNow.getFacFile().getResult().getVerdict() + "\n\r"
                                    + "--\n\r"
                                    + "Описание ошибки: " + s3ResultNow.getFacFile().getCheckMessage());
                }
                serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема. " + "Сервис получения файла из факторинга:" + configure.getAppName(),
                        "Ошибка при проверке файла в SandBox" + "\n\r" +
                                "Имя файла: " + s3ResultNow.getFacFile().getFile().getName() + "\n\r" +
                                "Исходное сообщение: " + factoringDocument + "\n\r" +
                                "EventId: " + factoringDocument.getEventId() + "\n\r" +
                                "ObjectId: " + factoringDocument.getObjectId() + "\n\r" +
                                "--\n\r"
                                + "\n\r" + "Status: " + s3ResultNow.getFacFile().getCheckStatus() + "\n\r" +
                                 "--\n\r"
                                + "Описание ошибки: " + s3ResultNow.getFacFile().getCheckMessage());
            }
            delFileFromTemp(true, s3ResultNow);
        }
    }
}
