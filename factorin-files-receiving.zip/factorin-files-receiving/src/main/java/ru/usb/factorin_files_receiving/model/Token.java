package ru.usb.factorin_files_receiving.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * Класс токен
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Token {

    @JsonProperty(value = "access_token")
    private String accessToken; //access_token

    @JsonProperty(value = "expires_in")
    private String expiresIn;   //"expires_in": 3600

    @JsonProperty(value = "token_type")
    private String tokenType;   //token_type

    @JsonProperty(value = "scope")
    private String scope;       //scope

    @JsonProperty(value = "error")
    private String error; // ошибка

    @JsonProperty(value = "error_description")
    private String errorDescription;

    private Date timeReceipt; //Время получения Токена

    @Override
    public String toString() {
        return "Token{" +
                ", expiresIn='" + expiresIn + '\'' +
                ", tokenType='" + tokenType + '\'' +
                ", scope='" + scope + '\'' +
                ", error='" + error + '\'' +
                ", errorDescription='" + errorDescription + '\'' +
                ", timeReceipt=" + timeReceipt +
                "accessToken='" + accessToken + '\'' +
                '}';
    }
}
