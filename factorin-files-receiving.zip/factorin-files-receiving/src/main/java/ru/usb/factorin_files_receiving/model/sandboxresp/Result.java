package ru.usb.factorin_files_receiving.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.factorin_files_receiving.model.sandbox.Errors;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Result {
    @JsonProperty("scan_state")
    private String scanState;
    @JsonProperty("verdict")
    private String verdict;
    @JsonProperty("errors")
    private ArrayList<Errors> errors;
    @JsonProperty("duration")
    private double duration;
    @JsonProperty("duration_full")
    private double durationFull;
}
