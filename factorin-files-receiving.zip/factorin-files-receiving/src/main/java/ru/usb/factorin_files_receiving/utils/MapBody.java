package ru.usb.factorin_files_receiving.utils;


import org.springframework.stereotype.Component;
import ru.usb.factorin_files_receiving.model.generated.*;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class MapBody {

    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy 'T'HH:mm:ss");
    SimpleDateFormat sdfYmd = new SimpleDateFormat("yyyy-MM-dd"); //Дата OutgoingPaymentDate, ContractDate,invoiceDate,genContractDate, jourDate
    SimpleDateFormat sdfDmy = new SimpleDateFormat("dd/MM/yyyy"); //16/09/2024


    /**
     * 3. <Body> - создание тела xml сообщения
     *
     * @return - Body - пустой
     */
    public Body mapBody() {
        return new Body();
    }


    /**
     * 4 <Messages>
     *
     * @param sourceId - Код проводки в системе-источнике данных
     * @param branchId - Код филиала проводки (по сч. Дб.) в системе-источнике данных
     * @param msg      - Содержимое сообщения
     * @return - Message
     */
    public Message mapMessages(String sourceId, String branchId, String msg, Date date) {
        Message message = new Message();
        message.setSourceId(sourceId);
        message.setBranchId(branchId);
        message.setMsg(msg);
        message.setMsgDate(sdf.format(date));
        return message;
    }


    //InPayments -> InPayment

    /**
     * 2. <InPayments> -- входящий платеж
     * SourceId	Нет	varchar(60)	-   Код проводки в системе-источнике данных	-
     * BranchId	Нет	Varchar(140)	Код филиала проводки (по сч. Дб.) в системе-источнике данных	-
     * PaymNum	Нет	string	        Номер платежа	-
     * DocDate	Нет	Date	        Дата документа	-
     * DateIn	Нет	Date	        Дата поступления на счет	-
     * PaymINN	Нет	string	        ИНН плательщика	BuyerINN
     * PaymKPP	Нет	string	        КПП плательщика	BuyerKPP
     * PaymName	Нет	string	        Наименование плательщика	BuyerName
     * PaymBankBIC	Нет	string	     БИК банка плательщика	-
     * PaymBankName	Нет	string	        Банк плательщика	-
     * PaymBankCorrAcc	Нет	string	Корр.счет плательщика	-
     * RecipientAccDbt	Нет	string	Счет дебет	-
     * RecipientAccount	Нет	string	Счет клиента	-
     * PaymAccCred	Нет	string	Счет кредита	-
     * PaymAmount	Нет	Decimal	Сумма платежа	-
     * ValCode	Нет	string	Код валюты	RUB по умолчанию
     * PaymNote	Нет	string	Назначение платежа	-
     * 2.1<InPaymLines> -- распределение входящего платежа
     * RecipientINN	Нет	string	ИНН Клиента	ProviderINN
     * RecipientKPP	Нет	string	КПП Клиента	ProviderKPP
     * RecipientName	Нет	string	Наименование клиента	ProviderName
     * ContractNum	Нет	string	Договор поставки	SupplyAgreementNumber
     * ContractDate	Нет	Date	Дата договора поставки	SupplyAgreementDate
     * InvoiceCode	Нет	string	Номер товарной накладной	DocumentNumber
     * Для Code = consignment
     * InvoiceDate	Нет	Date	Дата товарной накладной	DocumentNumber Date
     * Для DocumentCode = consignment
     * PayAmount	Нет	Decimal	Сумма товарной накладной c НДС	Document DocAmountWithVat
     * (сумма с НДС)
     * OutgoingPayment	Нет	string	Номер платежного поручения	DocumentNumber
     * Для Code = OutgoingPayment
     * OutgoingPaymentDate	Нет	Date	Дата платежного поручения	DocumentNumber Date
     * Для Code = OutgoingPayment
     * OutgoingPaymentAmount	Нет	Decimal	Сумма платежного поручения с НДС	DocAmountWithVat для DocumentCode = OutgoingPayment
     */


    public InPayments mapInPayments() {
        return new InPayments();
    }


    /**
     * 2.2 <Docs>-- предоставленный документ
     * DocName	Нет	string	Наименование документа	-
     * FileName	Нет	string	Наименование файла	-
     * Contents	Нет	string	Содержание файла	-
     * Signature	Нет	string	Подпись файла	-
     * File	Нет		Ссылка на файл	-
     */
    public Doc mapDoc(String docName, String fileName, String contents, String signature, String file) {
        Doc doc = new Doc();
        doc.setContents(contents);
        doc.setDocName(docName);
        doc.setFileName(fileName);
        doc.setSignature(signature);
        doc.setFile(file);
        return doc;
    }

    /**
     * Документы
     * @param docOne -- список документов
     * @return -
     */
    public Docs mapDocs(Doc docOne) {
        Docs docs = new Docs();
        docs.setDoc(docOne);
        return new Docs();
    }


    //InPaymLine
    /**
     * RecipientINN	Нет	string	ИНН Клиента	ProviderINN
     * RecipientKPP	Нет	string	КПП Клиента	ProviderKPP
     * RecipientName	Нет	string	Наименование клиента	ProviderName
     * ContractNum	Нет	string	Договор поставки	SupplyAgreementNumber
     * ContractDate	Нет	Date	Дата договора поставки	SupplyAgreementDate
     * InvoiceCode	Нет	string	Номер товарной накладной	DocumentNumber
     * Для Code = consignment
     * InvoiceDate	Нет	Date	Дата товарной накладной	DocumentNumber Date
     * Для DocumentCode = consignment
     * PayAmount	Нет	Decimal	Сумма товарной накладной c НДС	Document DocAmountWithVat
     * (сумма с НДС)
     * OutgoingPayment	Нет	string	Номер платежного поручения	DocumentNumber
     * Для Code = OutgoingPayment
     * OutgoingPaymentDate	Нет	Date	Дата платежного поручения	DocumentNumber Date
     * Для Code = OutgoingPayment
     * OutgoingPaymentAmount	Нет	Decimal	Сумма платежного поручения с НДС	DocAmountWithVat для DocumentCode = OutgoingPayment
     */

    public InPaymLine mapPaymLine(String recipientINN, String recipientKPP,
                                  String recipientName, String contractNum, Date contractDate,
                                  String invoiceCode, Date invoiceDate, String payAmount, String outgoingPayment,
                                  Date outgoingPaymentDate, String outgoingPaymentAmount, Doc doc) {
        InPaymLine inPaymLine = new InPaymLine();
        inPaymLine.setRecipientINN(recipientINN);
        inPaymLine.setRecipientKPP(recipientKPP);
        inPaymLine.setRecipientName(recipientName);
        inPaymLine.setContarctNum(contractNum);
        inPaymLine.setContractDate(sdfYmd.format(contractDate));
        inPaymLine.setInvoiceCode(invoiceCode);
        inPaymLine.setInvoiceDate(sdfYmd.format(invoiceDate));
        inPaymLine.setPayAmount(payAmount);
        inPaymLine.setOutgoingPayment(outgoingPayment);
        inPaymLine.setOutgoingPaymentDate(sdfYmd.format(outgoingPaymentDate));
        inPaymLine.setOutgoingPaymentAmount(outgoingPaymentAmount);
        inPaymLine.setDocs(mapDocs(doc)); //Документы
        return inPaymLine;
    }

    /**
     * InPaymLines. Содержит всего 1 элемент
     * InPaymLine -> InPaymLines
     * @param inPaymLine -- inPaymLine
     * @return - InPaymLines
     */
    public InPaymLines mapInPaymLines(InPaymLine inPaymLine) {
        InPaymLines inPaymLines = new InPaymLines();
        inPaymLines.setInPaymLine(inPaymLine);
        return inPaymLines;
    }


    /**\
     * SourceId	Нет	varchar(60)	Код проводки в системе-источнике данных	-
     * BranchId	Нет	Varchar(140)	Код филиала проводки (по сч. Дб.) в системе-источнике данных	-
     * PaymNum	Нет	string	Номер платежа	-
     * DocDate	Нет	Date	Дата документа	-
     * DateIn	Нет	Date	Дата поступления на счет	-
     * PaymINN	Нет	string	ИНН плательщика	BuyerINN
     * PaymKPP	Нет	string	КПП плательщика	BuyerKPP
     * PaymName	Нет	string	Наименование плательщика	BuyerName
     * PaymBankBIC	Нет	string	БИК банка плательщика	-
     * PaymBankName	Нет	string	Банк плательщика	-
     * PaymBankCorrAcc	Нет	string	Корр.счет плательщика	-
     * RecipientAccDbt	Нет	string	Счет дебет	-
     * RecipientAccount	Нет	string	Счет клиента	-
     * PaymAccCred	Нет	string	Счет кредита	-
     * PaymAmount	Нет	Decimal	Сумма платежа	-
     * ValCode	Нет	string	Код валюты	RUB по умолчанию
     * PaymNote	Нет	string	Назначение платежа	-
     *
     */
    public InPayment mapInPayment(String sourceId, String branchId, String paymNum, Date docDate, Date dateIn,
                                  String paymINN, String paymKPP, String paymName, String paymBankBIC,
                                  String paymBankName, String paymBankCorrAcc, String recipientAccDbt,
                                  String paymAccCred, String paymAmount, String valCode,
                                  String paymNote, InPaymLines inPaymLines) {
        InPayment inPayment = new InPayment();
        inPayment.setSourceId(sourceId);
        inPayment.setBranchId(branchId);
        inPayment.setPaymNum(paymNum);
        inPayment.setDocDate(sdfDmy.format(docDate));
        inPayment.setDateIn(sdfDmy.format(dateIn));
        inPayment.setPaymINN(paymINN);
        inPayment.setPaymKPP(paymKPP);
        inPayment.setPaymName(paymName);
        inPayment.setPaymBankBIC(paymBankBIC);
        inPayment.setPaymBankName(paymBankName);
        inPayment.setPaymBankCorrAcc(paymBankCorrAcc);
        inPayment.setRecipientAccDbt(recipientAccDbt);
        inPayment.setPaymAccCred(paymAccCred);
        inPayment.setPaymAmount(paymAmount);
        inPayment.setValCode(valCode);
        inPayment.setPaymNote(paymNote);
        inPayment.setInPaymLines(inPaymLines); //InPaymLines
        return inPayment;
    }

    /**
     * RecipientINN	Нет	string	ИНН Клиента	ProviderINN
     * RecipientKPP	Нет	string	КПП Клиента	ProviderKPP
     * RecipientName	Нет	string	Наименование клиента	ProviderName
     * ContractNum	Нет	string	Договор поставки	SupplyAgreementNumber
     * ContractDate	Нет	Date	Дата договора поставки	SupplyAgreementDate
     * InvoiceCode	Нет	string	Номер товарной накладной	DocumentNumber
     * Для Code = consignment
     * SupplyDate	Нет	Date	Дата товарной накладной	DocumentNumber Date
     * Для DocumentCode = consignment
     * SuppAmount	Нет	Decimal	Сумма товарной накладной с НДС	AmountWithVat
     * Для DocumentCode = consignment
     * OrigDelayDate	Нет	Date	Дата отсрочки
     */

    public Supply mapSupply(String recipientINN, String recipientKPP, String recipientName, String contractNum,
                            Date contractDate, String invoiceCode, Date supplyDate, String supAmount, Doc doc) {
        Supply supply = new Supply();
        supply.setRecipientINN(recipientINN);
        supply.setRecipientKPP(recipientKPP);
        supply.setRecipientName(recipientName);
        supply.setContarctNum(contractNum);
        supply.setContractDate(sdfYmd.format(contractDate));
        supply.setInvoiceCode(invoiceCode);
        supply.setSupplyDate(sdfYmd.format(supplyDate));
        supply.setSuppAmount(supAmount);
        supply.setDocs(mapDocs(doc)); //Документы
        return supply;
    }

    /**
     * Supplys. Содержит всего 1 элемент
     *
     * @param supply -- supply
     * @return - Supplys
     */
    public Supplies mapSupplies(Supply supply) {
        Supplies supplies = new Supplies();
        supplies.setSupply(supply);
        return supplies;
    }


    /**
     * SuppJournal
     * ---------
     * SourceId	Нет	varchar(60)	Код проводки в системе-источнике данных	ParentRegisterUID
     * Уникальный идентификатор связки реестра на согласование (РнС)и реестра на уступку (РнУ)
     * BranchId	Нет	Varchar(140)	Код филиала проводки (по сч. Дб.) в системе-источнике данных	-
     * JourNum	Нет	string	Номер реестра	Number
     * JourDate	Нет	string	Дата рееста	Date
     * PaymINN	Нет	string	ИНН плательщика	BuyerINN
     * PaymKPP	Нет	string	КПП плательщика	BuyerKPP
     * PaymName	Нет	string	Наименование плательщика	BuyerName
     * GenContractNum	Нет	string	Договор факторинга	FactoringAgreementNumber
     * GenContractDate	Нет	Date	Дата договора факторинга	FactoringAgreementDate
     */
    public SuppJournal mapSuppJournal(String sourceId, String branchId, String jourNum, Date jourDate,
                                      String paymINN, String paymKPP, String paymName, String genContractNum,
                                      Date genContractDate) {
        SuppJournal suppJournal = new SuppJournal();
        suppJournal.setSourceId(sourceId);
        suppJournal.setBranchId(branchId);
        suppJournal.setJourNum(jourNum);
        suppJournal.setJourDate(sdfYmd.format(jourDate));
        suppJournal.setPaymINN(paymINN);
        suppJournal.setPaymKPP(paymKPP);
        suppJournal.setPaymName(paymName);
        suppJournal.setGenContractNum(genContractNum);
        suppJournal.setGenContractDate(sdfYmd.format(genContractDate));
        return suppJournal;
    }

    /**
     * Получаем SuppJornals
     * @param suppJournal - SuppJournal
     * @return - SuppJournals
     */
    public SuppJournals mapSuppJournal(SuppJournal suppJournal){
        SuppJournals suppJournals = new SuppJournals();
        suppJournals.setSuppJournal(suppJournal);
        return suppJournals;
    }

    /**
     * Получаем AllName
     * @param name - готовый xml без nameSpace
     * @return - name - с nameSpace
     */
    public String getAllName(String name) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + name.replace("All", "All xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"C:\\Users\\BeloborodoEV\\Documents\\Задачи\\965454~1\\Маппинг\\XML_АФ.xsd\"");
    }

}


