package ru.usb.factorin_files_receiving.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.service.MessageProcess;
import ru.usb.factorin_files_receiving.service.mail.ServiceMailError;
import ru.usb.factorin_files_receiving.utils.Sutils;


@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;
    private final Sutils aux;
    private final MessageProcess messageProcess;

    @Autowired
    public KafkaListenerService(ServiceMailError serviceMailError, Sutils aux, MessageProcess messageProcess) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.messageProcess = messageProcess;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.attempt:4}")
    private int countAttempt;

    @KafkaListener(topics = "${kafka.event.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {

        ack.acknowledge(); //Сообщение забираем сразу

        if (logDebug) {
            logger.info("{}:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", TG.UsbLogInfo, recordKafka.offset());
            logger.info("{}:KafkaListener(record.partition) == {}", TG.UsbLogInfo, recordKafka.partition());
            logger.info("{}:KafkaListener(record.key)       == {}", TG.UsbLogInfo, recordKafka.key());
            logger.info("{}:KafkaListener (record.value)    == {}", TG.UsbLogInfo, recordKafka.value());
            logger.info("{}:KafkaListener(topic)            == {}", TG.UsbLogInfo, recordKafka.topic());
            logger.info("{}:KafkaListener(Offset)           == {}", TG.UsbLogInfo, recordKafka.offset());
            logger.info("{}:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", TG.UsbLogInfo);
        }


        if (recordKafka.value() == null) {
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            logger.error("{}:: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!", TG.UsbLogError);
            logger.error("{}::+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", TG.UsbLogError, recordKafka.offset());
            logger.error("{}::KafkaListener(record.partition) == {}", TG.UsbLogError, recordKafka.partition());
            logger.error("{}::KafkaListener(record.key)       == {}", TG.UsbLogError, recordKafka.key());
            logger.error("{}::KafkaListener(record.value)     == {}", TG.UsbLogError, recordKafka.value());
            logger.error("{}::KafkaListener(topic)            == {}", TG.UsbLogError, recordKafka.topic());
            logger.error("{}::KafkaListener(Offset)           == {}", TG.UsbLogError, recordKafka.offset());
            logger.error("{}::++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", TG.UsbLogError);
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()) + "\n\r" +
                    "KafkaListener(Offset)" + recordKafka.offset());
        }


        /**
         * Обработка сообщения
         * @param message  - тело сообщения
         */
        messageProcess.processChoice(recordKafka.value());

       // messageProcess.processWorker(recordKafka.value());

    }
}
