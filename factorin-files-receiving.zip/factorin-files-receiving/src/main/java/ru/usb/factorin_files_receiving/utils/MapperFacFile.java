package ru.usb.factorin_files_receiving.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;

import java.util.Optional;

@Log4j2
@Service
public class MapperFacFile {
    ObjectMapper objectMapper = new ObjectMapper();
    public Optional<FacFile> getFacFile(String json) {
        if (json == null) {
            log.error("{}: На маппер MapperFacFile поступил объект, строка [Json] == NULL!", TG.UsbLogError);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, FacFile.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", TG.UsbLogError, e);
            return Optional.empty();        }
    }
}
