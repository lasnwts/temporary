package ru.usb.factorin_files_receiving.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.model.sandboxresp.SandBoxCheck;
import ru.usb.factorin_files_receiving.service.ApiLyaer;
import ru.usb.factorin_files_receiving.service.mail.EmailServiceImpl;
import ru.usb.factorin_files_receiving.utils.Sutils;

import java.io.IOException;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api/check")
@Tag(name = "Контроллер для проверки работоспособности сервиса", description = "Проверка отправки почты, получения токена, файла и т.д.")
public class ApiController {

    private final Logger log = LoggerFactory.getLogger(ApiController.class);
    private final EmailServiceImpl emailService;
    private final Sutils support;
    private final ApiLyaer apiLyaer;

    @Autowired
    public ApiController(EmailServiceImpl emailService, Sutils support, ApiLyaer apiLyaer) {
        this.emailService = emailService;
        this.support = support;
        this.apiLyaer = apiLyaer;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                           @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmailThrow(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            log.error("{}: while sending out email..", TG.UsbLogError, mailException);
            return new ResponseEntity<>("Unable to send email: \n\r " + support.getWrapNull(mailException.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

    @GetMapping(value = "/file/{uid}")
    @Operation(summary = "Получить файл из Factoring с Uid")
    public FacFile getFile(@Parameter(description = "UID файла")
                                     @PathVariable("uid") String uid) {
        log.info("{}: Поступил запрос на получение файла из Factoring с Uid:{}", TG.UsbLogInfo, uid);
        return apiLyaer.getUidFacFile(uid);
    }

    @PostMapping(value = "/uploadScanFile", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Выберите файл ля проверки в SandBox и нажмите Execute. Вы получите ответ в виде Json. Загрузите его в метод:createScanTaskFile.")
    public FacFile upload(@RequestPart(value = "file") MultipartFile files) throws IOException {
        log.info("{}: Поступил запрос на загрузку файла:{}, размером:{} в SandBox", TG.UsbLogInfo, files.getOriginalFilename(), files.getSize());
        return apiLyaer.delFile(apiLyaer.putSandBox(apiLyaer.getFacFile(support.upload(files.getOriginalFilename(), files.getBytes()))));
    }

    @PostMapping(value = "/createScanTaskFile")
    @Operation(summary = "createScanTask в виде File. Метод получения статуса о проверке файла в песочнице SandBox.")
    public FacFile createScanTaskFile(@RequestBody String fac) {
        log.info("{}: Поступил запрос createScanTask в виде File на проверку файла:{} в SandBox", TG.UsbLogInfo, fac);
        FacFile facFile =  apiLyaer.getFacString(fac).orElse(new FacFile());
        log.info("{}: Полученный запрос в виде объекта FacFile:{}", TG.UsbLogInfo, facFile);
        return apiLyaer.checkSandBox(facFile);
    }

    @PostMapping(value = "/validateAnswerScanBox")
    @Operation(summary = "Это метод проверки переданного из SandBox ответа. Загрузите его в виде строки.")
    public SandBoxCheck validateAnswerScanBox(@RequestBody String json) {
        log.info("{}: Поступил запрос validateAnswerScanBox (метод проверки переданного из SandBox ответа.) в виде строки на проверку ответа:{} в SandBox", TG.UsbLogInfo, json);
        SandBoxCheck sandBoxCheck = apiLyaer.getSandBoxCheck(json).orElse(new SandBoxCheck());
        log.info("{}: Полученный запрос в виде объекта SandBoxCheck:{}", TG.UsbLogInfo, sandBoxCheck);
        return sandBoxCheck;
    }


}
