package ru.usb.factorin_files_receiving.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.model.generated.All;
import ru.usb.factorin_files_receiving.model.generated.Messages;
import ru.usb.factorin_files_receiving.service.mail.ServiceMailError;

import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Service
public class MapperData {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    XmlMapper xmlMapper = new XmlMapper();

    private final MapBody mapBody;
    private final MapHead mapHead;
    private final ServiceMailError serviceMailError;

    @Autowired
    public MapperData(MapBody mapBody, MapHead mapHead, ServiceMailError serviceMailError) {
        this.mapBody = mapBody;
        this.mapHead = mapHead;
        this.serviceMailError = serviceMailError;
    }


    /**
     * Получаем XML
     *
     * @param objectType - тип объекта
     * @param requestId  - id запроса
     * @param eventId    - id события
     * @param date       - дата
     * @param sourceId   - источник
     * @param branchId   - филиал
     * @param msg        - сообщение
     * @return - XML
     * @throws JsonProcessingException
     */
    public String getXML(String objectType, String requestId, String eventId, Date date, String sourceId, String branchId, String msg) throws JsonProcessingException {
        All all = new All();
        all.setHead(mapHead.mapHead(objectType, requestId, eventId, date));
        all.setBody(mapBody.mapBody());
        Messages messages = new Messages();
        messages.setMessage(mapBody.mapMessages(sourceId, branchId, msg, date));
        all.getBody().setMessages(messages);
        return  mapBody.getAllName(xmlMapper.writeValueAsString(all));
    }



}
