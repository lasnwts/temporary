package ru.usb.factorin_files_receiving.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.service.token.GetToken;


@Slf4j
@Service
public class MasterScheduler {

    private final GetToken getToken;

    @Autowired
    public MasterScheduler(GetToken getToken) {
        this.getToken = getToken;
    }

    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void masterScheduler() {
        log.debug("{}: Token Scheduler started", TG.UsbLogInfo);
        if (!getToken.getToken()) {
            log.error("{}: Failed to receive token.", TG.UsbLogError);
        }
    }
}
