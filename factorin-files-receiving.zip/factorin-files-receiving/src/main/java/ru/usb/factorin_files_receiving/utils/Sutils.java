package ru.usb.factorin_files_receiving.utils;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class Sutils {

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

}
