package ru.usb.factorin_files_receiving.utils;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FactoringData;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class Sutils {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    private final FactoringDataMapper dataMapper;


    @Autowired
    public Sutils(FactoringDataMapper dataMapper) {
        this.dataMapper = dataMapper;
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Определение отсутствия имени файла
     * @param fileName - имя файла
     * @return - имя файла
     */
    public String getFileName(String fileName) {
        if (fileName != null){
            return fileName.trim();
        } else {
            return "";
        }
    }

    /**
     * Запись файла во временный каталог
     * @param name - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()){
            log.debug("{}:file.canWrite()=true", TG.UsbLogInfo);
        }
        if (file.canRead()){
            log.debug("{}:file.canRead()=true", TG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:Error:FileOutputStream(file).write(content):{}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:FileOutputStream.write(content):stackTrace:", TG.UsbLogError, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Запись файла во временный каталог
     * @param name - имя файла
     * @param content - содержимое файла
     * @param threadNum - номер потока, как часть пути
     * @return - файл
     */
    public File uploadThread(String name, byte[] content, String threadNum) throws IOException {
        File file;
        if (createPath(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + threadNum)){
            file = new File(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + threadNum + FileSystems.getDefault().getSeparator() + name);
        } else {
            log.error("{}:Error:Can't create directory for thread:{}. Воспользуемся общей временной директорией -tmp", TG.UsbLogError, threadNum);
            file = new File(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + name);
        }
        if (file.canWrite()){
            log.debug("{}:T{} file.canWrite() = true", TG.UsbLogInfo, threadNum);
        }
        if (file.canRead()){
            log.debug("{}:{} file.canRead() = true", TG.UsbLogInfo, threadNum);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:{} Error:FileOutputStream(file).write(content):{}", TG.UsbLogError, threadNum, e.getMessage());
            log.debug("{}:{} Error:FileOutputStream.write(content):stackTrace:", TG.UsbLogError, threadNum, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Создание пути для загрузки файлов
     * @param fullPathString - путь
     * @return - успех, true - успешно, false  нет
     */
    public boolean createPath(String fullPathString) {
        Path path = Paths.get(fullPathString);
        if (!Files.exists(path)) {
            try {
                Files.createDirectory(path);
                log.info("{}: Directory thread:{}= created", TG.UsbLogInfo, path.toString());
                return true;
            } catch (IOException e) {
                log.error("{} Возникла ошибка при создании директории:{} для потока:ошибка:{}", TG.UsbLogError, path.toString(), e.getMessage());
                log.debug("{} Возникла ошибка при создании директории:{} для потока:{}", TG.UsbLogError, path.toString(), e);
                return false;
            }

        } else {
            return true;
        }
    }



    //Создание события для отправки в топиках data

    /**
     * Создание события для отправки в топиках data
     * @param xml - Строка в виде xml
     * @param date - дата события
     * @param serviceNameFactoring - имя сервиса
     * @param success - успешность обработки
     * @param registerTemplateCode - код шаблона
     * @param eventName - имя события
     * @param eventId - идентификатор события
     * @param objectId - идентификатор объекта
     * @return - строка в json формате
     */
    public String createDataEvent(String xml, Date date, String serviceNameFactoring, boolean success,
                                  String registerTemplateCode, String eventName, String eventId, String objectId) {
        FactoringData factoringData = new FactoringData();
        factoringData.setDocumentDataXml(xml);
        factoringData.setShouldUnsubscribeOnSuccess(success);
        factoringData.setMicroservice(serviceNameFactoring);
        factoringData.setRegisterTemplateCode(registerTemplateCode);
        factoringData.setEventName(eventName);
        factoringData.setEventDate(getDateTime(date));
        factoringData.setEventId(eventId);
        factoringData.setObjectId(objectId);
        return dataMapper.getJsonToStr(factoringData);
    }


    /**
     * Получаем дату и время в нужном формате для топика Data
     *
     * @param date - дата
     * @return - дата и время в нужном формате
     */
    public String getDateTime(Date date) {
        return sdf.format(date);
    }



}
