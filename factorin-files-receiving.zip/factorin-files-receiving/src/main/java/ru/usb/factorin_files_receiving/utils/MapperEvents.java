package ru.usb.factorin_files_receiving.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FactoringDocument;

import java.util.Optional;

@Log4j2
@Service
public class MapperEvents {
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Получение документа в виде объекта
     * @param json - строка Json
     * @return - FactoringDocument
     */
    public Optional<FactoringDocument> getDocument(String json) {
        if (json == null) {
            log.error("{}: На маппер getDocument поступил объект, строка [Json] == NULL!", TG.UsbLogError);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, FactoringDocument.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", TG.UsbLogError, e);
            return Optional.empty();        }
    }

    /**
     * Получение документа в виде Json строки
     * @param document - FactoringDocument
     * @return - Json строка
     */
    public String getJson(FactoringDocument document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [document] == NULL!", TG.UsbLogError);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа FactoringDocument :{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге FactoringDocument:", TG.UsbLogError, e);
            return null;
        }
    }
}
