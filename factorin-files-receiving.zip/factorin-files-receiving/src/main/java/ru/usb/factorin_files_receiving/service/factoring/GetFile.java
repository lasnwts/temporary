package ru.usb.factorin_files_receiving.service.factoring;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.usb.factorin_files_receiving.configure.Configure;
import ru.usb.factorin_files_receiving.configure.TG;
import ru.usb.factorin_files_receiving.model.FacFile;
import ru.usb.factorin_files_receiving.service.token.GetToken;
import ru.usb.factorin_files_receiving.utils.Sutils;

import java.io.IOException;
import java.util.Objects;

/**
 * Получение файла из факторинга
 */

@Log4j2
@Service
public class GetFile {

    private final Configure configure;
    private final Sutils su;
    private final GetToken getToken;

    @Autowired
    public GetFile(Configure configure, Sutils su, GetToken getToken) {
        this.configure = configure;
        this.su = su;
        this.getToken = getToken;
    }


    /**
     * Получить файл
     * --------------------------------------
     *
     * @param uid - id файла
     * @return - FacFile
     */
    public FacFile getFile(String uid) {
        if ((configure.getTokenSync() == null || configure.getTokenSync().isEmpty()) && !getToken.getToken()) {
                log.error("{}: Не получен токен, выхожу с ошибкой!", TG.UsbLogError);
                return new FacFile("", HttpStatus.INTERNAL_SERVER_ERROR, null, "Не получен токен", null, -1);
            }
        log.info("{}: GetFile from factoring - getFile, uid:{}", TG.UsbLogInfo, uid);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(configure.getTokenSync());
            HttpEntity<Object> entity = new HttpEntity<>(headers);
            RestTemplate restTemplate = new RestTemplate();

            ResponseEntity<byte[]> response = restTemplate.exchange(configure.getDocsUrl() + "/" + uid + "/zip", HttpMethod.GET, entity, byte[].class);
            if (!response.getStatusCode().is2xxSuccessful()) {
                log.error("{}: Ошибка при запросе в факторинг - Статус: {}, Ответ: {}", TG.UsbLogError, response.getStatusCode(), response.getBody());
                return new FacFile(su.getFileName(response.getHeaders().getContentDisposition().getFilename()),
                        response.getStatusCode(), null, response.toString(), null, 0);
            } else {
                log.info("{}: Получен файл:{}, размером:{} из факторинга.", TG.UsbLogInfo,
                        su.getFileName(response.getHeaders().getContentDisposition().getFilename()),
                        Objects.requireNonNull(response.getBody()).length);
                try {
                    return new FacFile(su.getFileName(response.getHeaders().getContentDisposition().getFilename()),
                            response.getStatusCode(), su.upload(response.getHeaders().getContentDisposition().getFilename(),
                            response.getBody()), response.toString(), null, 0);
                } catch (IOException e) {
                    log.error("{}: Ошибка:{} при попытке записи файла из факторинг:{} ", TG.UsbLogError, e.getMessage(),
                            su.getFileName(response.getHeaders().getContentDisposition().getFilename()));
                    log.debug("{}: Ошибка: при попытке записи файла:{} из факторинг, stack:{}", TG.UsbLogError,
                            su.getFileName(response.getHeaders().getContentDisposition().getFilename()), e);
                    return new FacFile(su.getFileName(response.getHeaders().getContentDisposition().getFilename()),
                            response.getStatusCode(), null, "IOException" + e.getMessage(), null, 0);
                }
            }
        } catch (HttpClientErrorException | HttpServerErrorException | ResourceAccessException e) {
            log.error("{}: Ошибка:{} при попытке запроса файла uid={} из факторинга", TG.UsbLogError, e.getMessage(), uid);
            log.debug("{}: Ошибка: при попытке запроса файла uid={} из факторинга, stack:{}", TG.UsbLogError, uid, e);
            return new FacFile("", HttpStatus.INTERNAL_SERVER_ERROR, null, e.getMessage(), null, 0);
        }
    }
}
