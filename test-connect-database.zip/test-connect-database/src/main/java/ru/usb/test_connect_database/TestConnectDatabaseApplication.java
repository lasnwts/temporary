package ru.usb.test_connect_database;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.test_connect_database.dto.ZskCompany;
import ru.usb.test_connect_database.repository.ZskCompanyRepo;

import java.util.function.Consumer;

@Log4j2
@SpringBootApplication
public class TestConnectDatabaseApplication implements CommandLineRunner {

	@Autowired
	ZskCompanyRepo zskCompanyRepo;

	public static void main(String[] args) {
		SpringApplication.run(TestConnectDatabaseApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("Start::::");
		zskCompanyRepo.getListAll().forEach(new Consumer<ZskCompany>() {
			@Override
			public void accept(ZskCompany zskCompany) {
				log.info(zskCompany);
			}
		});
		log.info("Stop::::");
	}
}
