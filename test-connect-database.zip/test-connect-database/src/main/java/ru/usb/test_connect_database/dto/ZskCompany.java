package ru.usb.test_connect_database.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SL_COMPANY_TO_INSERT")
public class ZskCompany {

    @Id
    private String source;
    private String reason;
    private String note;
    private Timestamp validFrom;
    private Timestamp validTill;
    private String exclude;
    private Timestamp lastUpdate;


}
