package ru.usb.eadoccft;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.eadoccft.configure.Configure;

@SpringBootApplication
public class EadocCftApplication implements CommandLineRunner {

	@Autowired
	Configure configure;

	Logger logger = LoggerFactory.getLogger(EadocCftApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(EadocCftApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Показываем версию
		logger.info("25.09.2023г. v.0.0.1");
		logger.info("-----------------------------------------------");
		logger.info("| Service:" + configure.getAppName());
		logger.info("| Version of service:" + configure.getAppVersion());
		logger.info("-----------------------------------------------");
		logger.info("");

	}
}
