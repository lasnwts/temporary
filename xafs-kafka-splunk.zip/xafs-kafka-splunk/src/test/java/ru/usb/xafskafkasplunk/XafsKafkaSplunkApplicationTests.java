package ru.usb.xafskafkasplunk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XafsKafkaSplunkApplicationTests {

	@Test
	void contextLoads() {
	}

}
