package ru.usb.xafskafkasplunk.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import ru.usb.xafskafkasplunk.configure.Configure;
import ru.usb.xafskafkasplunk.model.XafsMessage;
import ru.usb.xafskafkasplunk.service.MessageProcess;
import ru.usb.xafskafkasplunk.service.mail.EmailServiceImpl;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для проверки RestAPI XAFS и почтовой подсистемы", description = "Проверка отправки почты и сообщений в RestAPI")
public class RestController {
    private final Logger logger = LoggerFactory.getLogger(RestController.class);
    private final EmailServiceImpl emailService;
    private final MessageProcess messageProcess;
    private final Configure configure;

    @Autowired
    public RestController(EmailServiceImpl emailService, MessageProcess messageProcess, Configure configure) {
        this.emailService = emailService;
        this.messageProcess = messageProcess;
        this.configure = configure;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                           @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmail(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            logger.error("UsbLog:Error while sending out email:", mailException);
            logger.error("UsbLog:Error while sending out email..", mailException.fillInStackTrace());
            return new ResponseEntity<>("Unable to send email", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

    @PostMapping(value = "")
    @Operation(summary = "Строка для отправки (поле event), пример: {\"operationId\":42629887,\"operationTypeId\":1} ")
    ResponseEntity<String> sendMessageToRestAPI(@Parameter(description = "{\"operationId\":42629887,\"operationTypeId\":1}")
                                                @RequestBody String body) {
        if (body != null) {
            logger.info("UsbLog: Поступил POST запрос через RestController -> sendMessageToRestAPI");
            logger.info("UsbLog:POST, запрос => body:{}", body);
            messageProcess.processed(new XafsMessage(body, configure.getServiceSourceType()));
            logger.info("UsbLog:Отправлено сообщение через RestController, event={}, sourcetype={}", body, configure.getServiceSourceType());
            return new ResponseEntity<>("Отправлено сообщение через RestController, sourcetype="
                    + configure.getServiceSourceType() + " ,event=" + body, HttpStatus.OK);
        } else {
            logger.error("UsbLog:POST, body==NULL!");
            return new ResponseEntity<>("Строка не может быть NULL, String body will be not NULL!", HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping(value = "")
    @Operation(summary = "Строка для отправки (поле service.ack.mode), пример: true или false")
    ResponseEntity<String> changeModeAck(@Parameter(description = "true")
                                                @RequestBody boolean body) {

            logger.info("UsbLog: Поступил POST запрос через RestController -> changeModeAck - serviceAckMode={}, текущее значение :{}", body, configure.isServiceAckMode());
            configure.setServiceAckMode(body);
            return new ResponseEntity<>("Параметр установлен - serviceAckMode=" + configure.isServiceAckMode(), HttpStatus.OK);
    }

    @GetMapping(value = "")
    @Operation(summary = "Строка для просмотра параметра service.ack.mode  (поле service.ack.mode), \n " +
            "Значение м.б.: true (всегда подтверждаем обработку сообщения и сдвигаем Offset) или false (Сдвигаем Offset только в случае успешной передачи на RestAPI Xafs)")
    ResponseEntity<String> пуеModeAck() {
        logger.info("UsbLog: Поступил POST запрос через RestController -> пуеModeAck: показать текущее значение,  текущее значение ServiceModeAck:{}", configure.isServiceAckMode());
        return new ResponseEntity<>("Параметр установлен в serviceAckMode=" + configure.isServiceAckMode(), HttpStatus.OK);
    }


}
