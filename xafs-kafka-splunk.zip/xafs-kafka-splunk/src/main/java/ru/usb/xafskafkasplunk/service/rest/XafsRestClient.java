package ru.usb.xafskafkasplunk.service.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.xafskafkasplunk.configure.Configure;
import ru.usb.xafskafkasplunk.model.XafsResponse;
import ru.usb.xafskafkasplunk.service.mail.ServiceMailError;
import ru.usb.xafskafkasplunk.utils.AuxMethods;
import ru.usb.xafskafkasplunk.utils.MessageMapper;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Класс для запроса ИСЖ
 */

@Service
public class XafsRestClient {
    private final Configure configure;
    private final ServiceMailError serviceMailError;
    private final AuxMethods aux;
    private final MessageMapper messageMapper;

    @Autowired
    public XafsRestClient(Configure configure, ServiceMailError serviceMailError, AuxMethods aux, MessageMapper messageMapper) {
        this.configure = configure;
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.messageMapper = messageMapper;
    }

    RestTemplate restTemplate = new RestTemplate();
    Logger logger = LoggerFactory.getLogger(XafsRestClient.class);

    /**
     * @param messageBody строка
     * @param id - номер потока
     * @return - XafsResponse
     */
    public XafsResponse xafsRequest(String messageBody, long id) {

        if (messageBody == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:class XafsRestClient:(method:xafsRequest): parameters messageBody ==NULL!");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return new XafsResponse(false, "messageBody==NULL");
        }

        logger.info("UsbLog:id={}, Поступил объект для отправки в RestAPI XAFS: class XafsRestClient:method xafsRequest: parameters as String {}", id, messageBody);

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getServiceRestLogin(), configure.getServiceRestPassword());
        headers.setContentType(MediaType.valueOf("text/plain"));

        HttpEntity<String> request = new HttpEntity<>(messageBody, headers);
        logger.info("UsbLog:id={}, Request::{}", id, request);

        try {
            ResponseEntity<String> responseEntity = restTemplate.exchange(
                    configure.getServiceRealUrl(),
                    HttpMethod.POST,
                    request,
                    String.class);

            XafsResponse response = messageMapper.mapApiResponse(responseEntity.getBody());

            HttpStatus statusCode = responseEntity.getStatusCode();
            response.setHttpStatus(statusCode);
            response.setMessageBody(responseEntity.getBody());
            if (statusCode == HttpStatus.OK) {
                response.setErrorCode(true);
                logger.info("UsbLog:id={}, Запрос выполнен успешно:{}", id, statusCode);
            } else {
                response.setErrorCode(false);
                logger.info("UsbLog:id={}, Error => Запрос выполнен неуспешно:{}", id, statusCode);
            }
            logger.info("UsbLog:id={}, Получен response: {}", id, response);
            return response;
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String sStackTrace = sw.toString(); // stack trace as a string
            logger.error("UsbLog:id={}, Error:sStackTrace:{}", id, sStackTrace.trim());
            XafsResponse xafsResponse = new XafsResponse(false, sStackTrace);
            serviceMailError.sendMailErrorSubject(configure.getUrlCircuit() + " сервис:" + configure.getAppName()
                    + " Возникла ошибка при выполнении запроса Rest API в XAFS", "Описание ошибки: \n" +
                    aux.getWrapNull(sStackTrace.trim()));
            return xafsResponse;
        }
    }
}
