package ru.usb.xafskafkasplunk.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xafskafkasplunk.configure.Configure;
import ru.usb.xafskafkasplunk.service.kafka.KafkaProducerService;
import ru.usb.xafskafkasplunk.service.rest.XafsRestClient;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Вы можете увидеть Java-документ ThreadPoolTaskExecutor :
 * Из документации Spring Framework.
 * Конфигурация по умолчанию — это основной пул размером 1 с неограниченным максимальным размером пула и неограниченной емкостью очереди.
 * Это примерно эквивалентно Executors.newSingleThreadExecutor() , использующему один поток для всех задач.
 * Установка для « queueCapacity » значения 0 имитирует Executors.newCachedThreadPool() с немедленным масштабированием потоков в пуле до потенциально очень большого числа.
 * Также рассмотрите возможность установки « maxPoolSize » в этот момент, а также, возможно, более высокого « corePoolSize »
 * (см. также режим масштабирования « allowCoreThreadTimeOut »).
 * *******************************************************************
 * Разница между тремя исполнителями:
 * *******************************************************************
 * newFixedThreadPool :
 * создает пул потоков, который повторно использует фиксированное количество потоков, работающих в общей неограниченной очереди.
 * В любой момент не более потоков nThreads будут активными задачами обработки. Если дополнительные задачи отправляются, когда все потоки активны,
 * они будут ждать в очереди, пока поток не станет доступен. Если какой-либо поток завершается из-за сбоя во время выполнения перед завершением работы,
 * его место займет новый, если это необходимо для выполнения последующих задач. Потоки в пуле будут существовать до тех пор, пока он не будет явно отключен.
 * =====================================================================
 * newSingleThreadExecutor :
 * Создает Executor, который использует один рабочий поток, работающий в неограниченной очереди.
 * (Однако обратите внимание, что если этот единственный поток завершается из-за сбоя во время выполнения до завершения работы,
 * его место займет новый, если это необходимо для выполнения последующих задач.) Задачи гарантированно выполняются последовательно,
 * и не более одной задачи будет активным. в любой момент времени. В отличие от эквивалента newFixedThreadPool(1),
 * возвращаемый исполнитель гарантированно не может быть переконфигурирован для использования дополнительных потоков.
 * =====================================================================
 * newCachedThreadPool :
 * создает пул потоков, который создает новые потоки по мере необходимости, но будет повторно использовать ранее созданные потоки,
 * когда они станут доступны. Эти пулы обычно улучшают производительность программ, выполняющих множество кратковременных асинхронных задач.
 * Вызовы выполнения будут повторно использовать ранее созданные потоки, если они доступны. Если существующий поток недоступен,
 * будет создан новый поток и добавлен в пул. Потоки, которые не использовались в течение шестидесяти секунд, завершаются и удаляются из кэша.
 * Таким образом, пул, который простаивает достаточно долго, не будет потреблять никаких ресурсов. Обратите внимание, что пулы со схожими свойствами,
 * но с разными деталями (например, параметрами тайм-аута) могут быть созданы с помощью конструкторов ThreadPoolExecutor.
 * =====================================================================
 */

@Service
public class Executors {
    private final Configure configure;
    private final XafsRestClient restClient;
    private final KafkaProducerService kafkaProducerService;

    /**
     * Первый вариант инициализации: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    @Autowired
    public Executors(Configure configure, XafsRestClient restClient, KafkaProducerService kafkaProducerService) {
        this.configure = configure;
        this.restClient = restClient;
        this.kafkaProducerService = kafkaProducerService;
    }

    Logger logger = LoggerFactory.getLogger(Executors.class);


    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService executorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody, String messageKafka) {
        configure.setThreads(configure.getThreads() + 1);
        logger.info("UsbLog:Запуск getTask({}) потока...", messageBody);
        logger.info("UsbLog:Длина очереди задач={}", configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody, messageKafka));
        } catch (Exception e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
        logger.info("UsbLog:Поток getTask({}) завершен...", messageBody);
    }

    class MyThread implements Runnable {
        String message;
        String kafkaMessage;
        CountDownLatch latch;


        MyThread(CountDownLatch c, String messageBody, String messageKafka) {
            latch = c;
            message = messageBody;
            kafkaMessage = messageKafka;
            new Thread(this);
        }

        public void run() {
            logger.info("UsbLog:Запуск XafsRestClient потока id={}", Thread.currentThread().getId());

            /**
             * Если не получилось отправить ставим в очередь зановоЮ при условии, что поставлен ack mode = false
             * Старый вариант без учета повторной отправки:
             * XafsResponse xafsResponse = restClient.xafsRequest(message, Thread.currentThread().getId());
             */
            if (!Boolean.TRUE.equals(restClient.xafsRequest(message, Thread.currentThread().getId()).getErrorCode()) && !configure.isServiceAckMode()) {
                kafkaProducerService.sendMessage(configure.getKafkaConsumerTopic(), "error Thread id=" + Thread.currentThread().getId(), kafkaMessage);
                logger.info("UsbLog: Ставим поток {} на ожидание в {}  сек., чтобы не забиваться сообщениями с ошибкой", Thread.currentThread().getId(), configure.getServiceWait());
                try {
                    Thread.sleep(configure.getServiceWait() * 1000);
                } catch (InterruptedException e) {
                    logger.error("Error:[getTask].Executors - [Thread.sleep] Interrupted!", e);
                    /* Clean up whatever needs to be handled before interrupting  */
                    Thread.currentThread().interrupt();
                }
            }
            logger.info("UsbLog:Поток XafsRestClient завершен id={}", Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            logger.info("UsbLog:Длина очереди задач={}", configure.getThreads());
        }
    }


}
