package ru.usb.xafskafkasplunk;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.xafskafkasplunk.configure.Configure;

@SpringBootApplication
public class XafsKafkaSplunkApplication implements CommandLineRunner {
    private final Configure configure;

    @Autowired
    public XafsKafkaSplunkApplication(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(XafsKafkaSplunkApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(XafsKafkaSplunkApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Splunk AFS. Rest API")
                .version(appVersion)
                .description("Обмен между Kafka и Rest API xAFS." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        logger.info("UsbLog:+-----------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Created by 05.02.2024   : Author: Lyapustin A.S.");
        logger.info("UsbLog: Короткое описание: сервис вычитывает сообщения из топика Kafka, полученное сообщение мапируется в Json.");
        logger.info("UsbLog: Json по RestAPI передается в систему Splunk.");
        logger.info("UsbLog:-------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:| Name of service        :{}", configure.getAppName());
        logger.info("UsbLog:| Description of service :{}", configure.getAppDescription());
        logger.info("UsbLog:=------------------------------------------------------------------------------------------------------------=");
        logger.info("UsbLog:| Modified reason               :{}", "0.0.1 Первая версия                                                   ");
        logger.info("UsbLog:--------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:");


        /**
         * Настройка 
         */
        logger.info("UsbLog:+------------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Параметры контура: Выбран режим");
        logger.info("UsbLog:--------------------------------------------------------------------------------------------------------------");

        if (configure.getUrlCircuit().toLowerCase().contains("prod")) {
            logger.info("UsbLog:PROD");
            configure.setServiceRealUrl(configure.getServiceProdUrl());
        } else {
            logger.info("UsbLog:TEST");
            configure.setServiceRealUrl(configure.getServiceTestUrl());
        }
        logger.info("UsbLog:----------------------------------------------------------------------------------------------------------------");

        logger.info("");
        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("UsbLog:+-----------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Параметры URL REST сервера: Выбран режим");
        logger.info("UsbLog:-------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:SOAP URL={}", configure.getServiceRealUrl());
        logger.info("-------------------------------------------------------------------------------------------------------------");
        logger.info("...");
        logger.info("..");
        logger.info(".");
        logger.info("");

    }
}

