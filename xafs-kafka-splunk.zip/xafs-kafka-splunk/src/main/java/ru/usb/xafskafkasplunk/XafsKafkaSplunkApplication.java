package ru.usb.xafskafkasplunk;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.xafskafkasplunk.configure.Configure;

@SpringBootApplication
public class XafsKafkaSplunkApplication implements CommandLineRunner {
    private final Configure configure;

    @Autowired
    public XafsKafkaSplunkApplication(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(XafsKafkaSplunkApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(XafsKafkaSplunkApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Splunk AFS. Rest API")
                .version(appVersion)
                .description("<b>Обмен между Kafka и Rest API xAFS.<br>Короткое описание:</b> Сервис вычитывает сообщения из топика Kafka, полученное сообщение мапируется в Json." +
                        "Далее Json по RestAPI передается в систему Splunk.<br>" +
                        "<b>Swagger use library for OpenAPI 3 with spring boot.</b>")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        logger.info("UsbLog:+-----------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Created by 05.02.2024   : Author: Lyapustin A.S.");
        logger.info("UsbLog: Короткое описание: сервис вычитывает сообщения из топика Kafka, полученное сообщение мапируется в Json.");
        logger.info("UsbLog: Json по RestAPI передается в систему Splunk.");
        logger.info("UsbLog:-------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:| Name of service        :{}", configure.getAppName());
        logger.info("UsbLog:| Description of service :{}", configure.getAppDescription());
        logger.info("UsbLog:=------------------------------------------------------------------------------------------------------------=");
        logger.info("UsbLog:| Modified reason               :{}", "0.0.1 Первая версия                                                    ");
        logger.info("UsbLog:| Modified reason, 08.02.2024   :{}", "0.0.2 Добавлена много поточность                                       ");
        logger.info("UsbLog:---------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:");


        /**
         * Настройка 
         */
        logger.info("UsbLog:+------------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Параметры контура: Выбран контур ");
        logger.info("UsbLog:--------------------------------------------------------------------------------------------------------------");

        if (configure.getUrlCircuit().toLowerCase().contains("prod")) {
            logger.info("UsbLog:PROD");
            configure.setServiceRealUrl(configure.getServiceProdUrl());
        } else {
            logger.info("UsbLog:TEST");
            configure.setServiceRealUrl(configure.getServiceTestUrl());
        }
        logger.info("UsbLog:+------------------------------------------------------------------------------------------------------------++");
        logger.info("UsbLog: Параметры контура: Выбран режим количества потоков ");
        logger.info("UsbLog:--------------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog:Параметр в application.properties: service.mode={}", configure.isServiceMode());
        if (configure.isServiceMode()){
            logger.info("UsbLog:Многопоточный режим. Число потоков={}", configure.getServicePoolSize());
        } else {
            logger.info("UsbLog:Одно поточный режим включен");
        }
        logger.info("UsbLog:+------------------------------------------------------------------------------------------------------------++");
        logger.info("UsbLog: Параметры контура: Выбран режим ack Mode.  ");
        logger.info("UsbLog:--------------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog:Параметр в application.properties: service.ack.mode={}", configure.isServiceAckMode());
        if (!configure.isServiceMode() && !configure.isServiceAckMode()){
            logger.info("UsbLog:Выбран режим с подтверждением передачи сообщения. Если RestAPI вернул ошибку, будет пауза в {} секунд,", configure.getServiceWait());
            logger.info("UsbLog: а потом снова попытка передать сообщение");
        } else {
            logger.info("UsbLog:Выбран режим без подтверждения. Сообщение считается обработанным всегда");
        }

        logger.info("UsbLog:----------------------------------------------------------------------------------------------------------------");

        logger.info("");
        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("UsbLog:+-----------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Параметры URL REST сервера: Выбран");
        logger.info("UsbLog:-------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:RestAPI, Splunk, URL={}", configure.getServiceRealUrl());
        logger.info("-------------------------------------------------------------------------------------------------------------");
        logger.info("...");
        logger.info("..");
        logger.info(".");
        logger.info("");

    }
}

