package ru.usb.xafskafkasplunk.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xafskafkasplunk.model.XafsMessage;
import ru.usb.xafskafkasplunk.model.XafsResponse;
import ru.usb.xafskafkasplunk.service.rest.XafsRestClient;
import ru.usb.xafskafkasplunk.utils.MessageMapper;

/**
 * Основной класс обработки сообщения
 * Здесь производится форматирование полученного сообщения в строку нужного формата и отправка в Rest API XAFS
 */
@Service
public class MessageProcess {
    Logger logger = LoggerFactory.getLogger(MessageProcess.class);
    private final XafsRestClient restClient;
    private final Executers executers;
    private final MessageMapper messageMapper;


    @Autowired
    public MessageProcess(XafsRestClient restClient, Executers executers, MessageMapper messageMapper) {
        this.restClient = restClient;
        this.executers = executers;
        this.messageMapper = messageMapper;
    }

    /**
     * Одно поточный режим
     * @param xafsMessage - объект
     * @return - boolean
     */
    public boolean processOne(XafsMessage xafsMessage){
        if (xafsMessage != null) {
            try {
               XafsResponse response = restClient.xafsRequest(messageMapper.getMessageToXafs(xafsMessage));
               if (Boolean.TRUE.equals(response.getErrorCode())){
                   return true;
               } else {
                   logger.error("UsbLog: Произошла ошибка при попытке передачи сообщения в RestAPI:{}", xafsMessage);
                   return false;
               }
            } catch (Exception exception) {
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
                logger.error("UsbLog:class MessageProcess:(method:MessageProcess):restClient.xafsRequest(xafsMessage)");
                logger.error("UsbLog:class xafsMessage={}", xafsMessage);
                logger.error("UsbLog:", exception);
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!=");
                return false;
            }
        } else {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+-");
            logger.error("UsbLog:class MessageProcess:(method:MessageProcess): parameters xafsMessage ==NULL!");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!--");
            return false;
        }
    }

    /**
     * Многопоточный режим
     * @param xafsMessage - объект XafsMessage
     */
    public void processed(XafsMessage xafsMessage) {
        if (xafsMessage != null) {
            try {
                executers.getTask(messageMapper.getMessageToXafs(xafsMessage));
            } catch (Exception exception) {
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("UsbLog:class MessageProcess:(method:MessageProcess):restClient.xafsRequest(xafsMessage)");
                logger.error("UsbLog:class xafsMessage={}", xafsMessage);
                logger.error("UsbLog:", exception);
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
        } else {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:class MessageProcess:(method:MessageProcess): parameters xafsMessage ==NULL!");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
    }
}
