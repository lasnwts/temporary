package ru.usb.cxd.etlsftp.service;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.cxd.etlsftp.config.Configure;
import ru.usb.cxd.etlsftp.model.RecordString;
import ru.usb.cxd.etlsftp.repository.JpaRepoOutCsv;

import javax.persistence.EntityManager;
import java.io.File;
import java.util.stream.Stream;

@Component
public class ProcessorOutCsv {

    Logger logger = LoggerFactory.getLogger(ProcessorOutCsv.class);

    //Пакет ЦХД
    String pack_id = "";

    @Autowired
    Configure configure;

    String pathFile = System.getProperty("user.dir");

    @Autowired
    private JpaRepoOutCsv jpaRepoOutCsv;
    private EntityManager entityManager;

    public ProcessorOutCsv(JpaRepoOutCsv jpaRepoOutCsv, EntityManager entityManager) {
        this.entityManager = entityManager;
        this.jpaRepoOutCsv = jpaRepoOutCsv;
    }

    //Получаем part_id
    @Transactional
    public String processBase() {
        return jpaRepoOutCsv.callGetPacket();
    }

    //Передаем в ЦХД part_id с ошибкой
    @Transactional
    public String processErrorBase() {
        return jpaRepoOutCsv.callGetPacket();
    }

    //Получаем part_id в ЦХД, что все прошло успешно
    @Transactional
    public String processBaseSuccess() {
        return jpaRepoOutCsv.callGetPacket();
    }

    @Transactional(readOnly = true)
    public int processMainOutCsv() {

        //создание директории
        new File(pathFile + File.separator + configure.getPathfile()).mkdir();

        //Получаем список записей из базы
        Stream<RecordString> fTableStream = null;
        try {
            fTableStream = jpaRepoOutCsv.getAll();
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Произошла ошибка при получении информации из ЦХД  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            processError(pack_id);
        }


        logger.info("###################### < Старт процесса выгрузки данных из таблицы в файл > ##############################");
        logger.info("###################### < pack_id = " + pack_id + " > ##############################");

        try {
            fTableStream.forEach(fTable -> {
                logger.debug(fTable.toCsv());
                logger.info("File = " + pathFile + File.separator + configure.getPathfile() + File.separator + fTable.getFILENAME());
                FileWriter.write(pathFile + File.separator + configure.getPathfile() + File.separator + fTable.getFILENAME(), fTable.toCsv());
                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Произошла ошибка при выгрузке информации в файл  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            processError(pack_id);
        } finally {
            fTableStream.close();
        }

/*
        fTableStream.forEach(fTable -> {
            logger.debug(fTable.toCsv());
            logger.info("File = " + pathFile + File.separator + configure.getPathfile() + File.separator + fTable.getFILENAME());
            FileWriter.write(pathFile + File.separator + configure.getPathfile() + File.separator + fTable.getFILENAME(), fTable.toCsv());
            entityManager.detach(fTable);
        });

        fTableStream.close();
*/

        logger.info("###################### <  Процесс выгрузки данных из таблицы в файл завершен > ##############################");
        logger.info("###################### < Старт процесса отправки файлов на SFTP сервер > ##############################");

        try {
            SftpFileCopy.sftpCopyFiles(pathFile + File.separator + configure.getPathfile(), configure.getSftp_know_host_file(),
                    configure.getSftp_host(), configure.getSftp_user(), configure.getSftp_password(), configure.getSftp_directory());
        } catch (JSchException e) {
            e.printStackTrace();
        } catch (SftpException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Произошла ошибка при работе с сервером SFTP  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            //Откатываем результаты работы
            processError(pack_id);
        }

        logger.info("###################### <  Процесс отправки отправки файлов на SFTP сервер - завершен > ##############################");
        logger.info("###################### < Удаляем, отправленные файлы > ##############################");
        DeleteFile.deletedFiles(pathFile + File.separator + configure.getPathfile());
        logger.info("###################### < Передаем ответ в ЦХД > ##############################");
        return 0;
    }

    @Transactional
    public void processError(String pack_id) {
        logger.info("###################### < Произошла ошибка!!! Удаляем файлы > ##############################");
        DeleteFile.deletedFiles(pathFile + File.separator + configure.getPathfile());
        logger.info("###################### < Произошла ошибка!!! Передаем в базу ЦХД pack_id вызвавший ошибку > ##############################");
        //Передаем в ЦХД part_id с ошибкой
        jpaRepoOutCsv.callSetAnswerPacketError(pack_id);
    }


}
