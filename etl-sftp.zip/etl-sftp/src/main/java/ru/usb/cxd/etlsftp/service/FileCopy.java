package ru.usb.cxd.etlsftp.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileCopy {
    // простой и удобный метод копирования файла в Java 7
    private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
        Files.copy(source.toPath(), dest.toPath());
    }
}
