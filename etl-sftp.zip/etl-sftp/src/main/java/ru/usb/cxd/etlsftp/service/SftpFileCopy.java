package ru.usb.cxd.etlsftp.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;

public class SftpFileCopy {
    public static void sftpCopyFiles(String pathFiles, String known_hosts, String host, String sftp_user, String sftp_password, String sftp_dir) throws JSchException, SftpException {

        Logger logger = LoggerFactory.getLogger(SftpFileCopy.class);

        logger.info( "Подготовка к сессии работы с сервером sftp с параметрами: " +
                "host: " + host + ";\n" +
                "user: " + sftp_user + ";\n" +
                "password: " + sftp_password  + ";\n" +
                "dir on sftp: " + sftp_dir  + ";\n" +
                "know_hosts: " + known_hosts + ";\n");


        JSch jSch = new JSch();
        jSch.setKnownHosts(known_hosts);
        Session session = jSch.getSession(sftp_user, host);
        session.setPassword(sftp_password);
        session.connect();

        logger.debug(session.toString());

        ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
        channel.connect();

        logger.debug(String.valueOf(channel.getExitStatus()));

        if (sftp_dir != null) {
            channel.cd("/"+sftp_dir);
            logger.info("channel cd directory: /" + sftp_dir);
        }

        String[] filesForSFTP;
        File f = new File(pathFiles);
        filesForSFTP = f.list();
        for (String fileTosftp : filesForSFTP) {
            logger.info("File copy to sftp : " + pathFiles + File.separator + fileTosftp);
            channel.put(pathFiles + File.separator + fileTosftp, fileTosftp);
        }
        channel.disconnect();
        logger.info("Channel sftp close");
        //Подавление реакции на новый ключ
//		session.setConfig("StrictHostKeyChecking", "no");
        session.disconnect();
        logger.info("Session close");
    }
}
