package ru.usb.cxd.etlsftp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.cxd.etlsftp.model.RecordString;

import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaRepoOutCsv extends JpaRepository<RecordString, Long> {

    @Query(nativeQuery = true, value = "select function_1 from dual")
    String callGetPacket();

    @Query(nativeQuery = true, value = "select function_1 from dual")
    void callSetAnswerPacketSuccess(String answer);

    @Query(nativeQuery = true, value = "select function_1 from dual")
    void callSetAnswerPacketError(String answer);


    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from CUSTOMERS2",nativeQuery = true)
    Stream<RecordString> getAll();

}
