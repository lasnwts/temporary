package ru.usb.cxd.etlsftp.service;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class FileWriter {
    public static void write(String fileName, String text) {
        //Определяем файл
        File file = new File(fileName);

        try {
            //проверяем, что если файл не существует то создаем его
            if (!file.exists()) {
                file.createNewFile();
            }


            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file.getAbsoluteFile(),true), StandardCharsets.UTF_8));
            bw.write(text + System.lineSeparator());

            try {

                if (bw != null)
                    bw.close();

//                if (fw != null)
//                    fw.close();

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
