package ru.usb.cxd.etlsftp.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RecordString2 {

    @Id
    private String LOYALTY_ID;
    private String PARTNER_NM;
    private String FLAG_NM;
    private String BEGIN_DT;
    private String END_DT;
    private String FLG;
    private String FILE_NAME;
    private String BUSINESS_DT;
    private Long PART_ID;

    public RecordString2() {
    }

    public RecordString2(String LOYALTY_ID, String PARTNER_NM, String FLAG_NM,
                         String BEGIN_DT, String END_DT, String FLG, String FILE_NAME, String BUSINESS_DT, Long PART_ID) {
        this.LOYALTY_ID = LOYALTY_ID;
        this.PARTNER_NM = PARTNER_NM;
        this.FLAG_NM = FLAG_NM;
        this.BEGIN_DT = BEGIN_DT;
        this.END_DT = END_DT;
        this.FLG = FLG;
        this.FILE_NAME = FILE_NAME;
        this.BUSINESS_DT = BUSINESS_DT;
        this.PART_ID = PART_ID;
    }

    public String getLOYALTY_ID() {
        return LOYALTY_ID;
    }

    public void setLOYALTY_ID(String LOYALTY_ID) {
        this.LOYALTY_ID = LOYALTY_ID;
    }

    public String getPARTNER_NM() {
        return PARTNER_NM;
    }

    public void setPARTNER_NM(String PARTNER_NM) {
        this.PARTNER_NM = PARTNER_NM;
    }

    public String getFLAG_NM() {
        return FLAG_NM;
    }

    public void setFLAG_NM(String FLAG_NM) {
        this.FLAG_NM = FLAG_NM;
    }

    public String getBEGIN_DT() {
        return BEGIN_DT;
    }

    public void setBEGIN_DT(String BEGIN_DT) {
        this.BEGIN_DT = BEGIN_DT;
    }

    public String getEND_DT() {
        return END_DT;
    }

    public void setEND_DT(String END_DT) {
        this.END_DT = END_DT;
    }

    public String getFLG() {
        return FLG;
    }

    public void setFLG(String FLG) {
        this.FLG = FLG;
    }

    public String getFILE_NAME() {
        return FILE_NAME;
    }

    public void setFILE_NAME(String FILE_NAME) {
        this.FILE_NAME = FILE_NAME;
    }

    public String getBUSINESS_DT() {
        return BUSINESS_DT;
    }

    public void setBUSINESS_DT(String BUSINESS_DT) {
        this.BUSINESS_DT = BUSINESS_DT;
    }

    public Long getPART_ID() {
        return PART_ID;
    }

    public void setPART_ID(Long PART_ID) {
        this.PART_ID = PART_ID;
    }

    @Override
    public String toString() {
        return "RecordString2{" +
                "LOYALTY_ID='" + LOYALTY_ID + '\'' +
                ", PARTNER_NM='" + PARTNER_NM + '\'' +
                ", FLAG_NM='" + FLAG_NM + '\'' +
                ", BEGIN_DT='" + BEGIN_DT + '\'' +
                ", END_DT='" + END_DT + '\'' +
                ", FLG='" + FLG + '\'' +
                ", FILE_NAME='" + FILE_NAME + '\'' +
                ", BUSINESS_DT='" + BUSINESS_DT + '\'' +
                ", PART_ID=" + PART_ID +
                '}';
    }

    public String toCSV() {
        return
                LOYALTY_ID + ';' +
                        PARTNER_NM + ';' +
                        FLAG_NM + ';' +
                        BEGIN_DT + ';' +
                        END_DT + ';' +
                        FLG + ';' +
                        FILE_NAME + ';' +
                        BUSINESS_DT + ';' +
                        PART_ID;
    }


}

