package ru.usb.cxd.etlsftp;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.cxd.etlsftp.repository.JpaRepoOutCsv;
import ru.usb.cxd.etlsftp.service.ProcessorOutCsv;

import java.io.IOException;
import java.util.Date;

@SpringBootApplication
public class EtlSftpApplication {

	@Autowired
	JpaRepoOutCsv jpaRepoOutCsv;

	@Autowired
	ProcessorOutCsv processorOutCsv;



	public static void main(String[] args) {
		SpringApplication.run(EtlSftpApplication.class, args);
	}

	@Scheduled(initialDelay = 1000L, fixedDelayString = "${scheduler.delay}")
	public void BaseJob() throws InterruptedException, IOException, JSchException, SftpException {
		System.out.println("Now is "+ new Date());
		System.out.println("Get packet =" + processorOutCsv.processBase());
		if (processorOutCsv.processBase()==null){
			return;
		}
		processorOutCsv.processMainOutCsv();

	}

}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration{
}

