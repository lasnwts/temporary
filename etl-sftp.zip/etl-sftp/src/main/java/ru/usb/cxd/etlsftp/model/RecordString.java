package ru.usb.cxd.etlsftp.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RecordString {

    @Id
    private String CUSTOMER_ID;
    private String CUSTOMER_NAME;
    private String ADDRESS;
    private String CITY;
    private String STATE;
    private String ZIP_CODE;
    private String TMSTAMP;
    private String FILENAME;

    @Override
    public String toString() {
        return "RecordString{" +
                "CUSTOMER_ID='" + CUSTOMER_ID + '\'' +
                "; CUSTOMER_NAME='" + CUSTOMER_NAME + '\'' +
                "; ADDRESS='" + ADDRESS + '\'' +
                "; CITY='" + CITY + '\'' +
                "; STATE='" + STATE + '\'' +
                "; ZIP_CODE='" + ZIP_CODE + '\'' +
                "; TMSTAMP='" + TMSTAMP + '\'' +
                "; FILENAME='" + FILENAME + '\'' +
                '}';
    }

    public String toCsv() {
        return   CUSTOMER_ID.trim().replaceAll("\n|\r\n", " ") +
                "; " + CUSTOMER_NAME.trim().replaceAll("\n|\r\n", " ") +
                "; " + ADDRESS.trim().replaceAll("\n|\r\n", " ") +
                "; " + CITY.trim().replaceAll("\n|\r\n", " ") +
                "; " + STATE.trim().replaceAll("\n|\r\n", " ") +
                "; " + ZIP_CODE.trim().replaceAll("\n|\r\n", " ") +
                "; " + TMSTAMP.trim().replaceAll("\n|\r\n", " ") +
                "; " + FILENAME.trim().replaceAll("\n|\r\n", " ");
    }

    public RecordString() {
    }

    public RecordString(String CUSTOMER_ID, String CUSTOMER_NAME, String ADDRESS, String CITY, String STATE, String ZIP_CODE, String TMSTAMP, String FILENAME) {
        this.CUSTOMER_ID = CUSTOMER_ID;
        this.CUSTOMER_NAME = CUSTOMER_NAME;
        this.ADDRESS = ADDRESS;
        this.CITY = CITY;
        this.STATE = STATE;
        this.ZIP_CODE = ZIP_CODE;
        this.TMSTAMP = TMSTAMP;
        this.FILENAME = FILENAME;
    }

    public String getCUSTOMER_ID() {
        return CUSTOMER_ID;
    }

    public void setCUSTOMER_ID(String CUSTOMER_ID) {
        this.CUSTOMER_ID = CUSTOMER_ID;
    }

    public String getCUSTOMER_NAME() {
        return CUSTOMER_NAME;
    }

    public void setCUSTOMER_NAME(String CUSTOMER_NAME) {
        this.CUSTOMER_NAME = CUSTOMER_NAME;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public String getCITY() {
        return CITY;
    }

    public void setCITY(String CITY) {
        this.CITY = CITY;
    }

    public String getSTATE() {
        return STATE;
    }

    public void setSTATE(String STATE) {
        this.STATE = STATE;
    }

    public String getZIP_CODE() {
        return ZIP_CODE;
    }

    public void setZIP_CODE(String ZIP_CODE) {
        this.ZIP_CODE = ZIP_CODE;
    }

    public String getTMSTAMP() {
        return TMSTAMP;
    }

    public void setTMSTAMP(String TMSTAMP) {
        this.TMSTAMP = TMSTAMP;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }
}
