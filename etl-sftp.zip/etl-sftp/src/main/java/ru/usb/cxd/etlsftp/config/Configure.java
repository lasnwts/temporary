package ru.usb.cxd.etlsftp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties()
public class Configure {

    @Value("${logging.level.root}")
    private String logLevel;

    @Value("${file.transfer}")
    private String pathfile;

    @Value("${sftp.host}")
    private String sftp_host;

    @Value("${sftp.user}")
    private String sftp_user;

    @Value("${sftp.password}")
    private String sftp_password;

    @Value("${sftp.know_host_file}")
    private String sftp_know_host_file;

    @Value("${sftp.directory}")
    private String sftp_directory;


    public String getSftp_host() {
        return sftp_host;
    }

    public String getSftp_user() {
        return sftp_user;
    }

    public String getSftp_password() {
        return sftp_password;
    }

    public String getLogLevel() {
        return logLevel;
    }

    public String getPathfile() {
        return pathfile;
    }

    public String getSftp_know_host_file() {
        return sftp_know_host_file;
    }

    public String getSftp_directory() {
        return sftp_directory;
    }
}
