package ru.usb.cxd.etlsftp.service;

import java.io.File;

public class DeleteFile {

    public static void deletedFiles(String pathToFiles){

        String[] filesForDelete;
        File f = new File(pathToFiles);
        filesForDelete = f.list();

        for (String file_Delete : filesForDelete){
            File delFile = new File(pathToFiles,file_Delete);
            delFile.delete();
            System.out.println("File to delete : " + pathToFiles + File.separator+ file_Delete );
        }

    }

}
