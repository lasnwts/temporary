package ru.usb.sbki_protection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbkiProtectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
