package ru.usb.sbki_protection.model;

/**
 * Created by LyapustinAs on 26.03.2016.
 * Класс для передачи данных в БКИ
 */
public class RequestBki {
    /**
     * ClientINN	ИНН Клиента	S12
     * DocType	Тип договора	I
     * где DocType = 1 (кредитный договор), DocType = 2 (гарантия), DocType = 3 (договор поручительства).
     */

    //ClientINN	ИНН Клиента	S12
    private String clientINN;
    //DocType	Тип договора	I
    private int docType;

    public RequestBki() {
        //
    }

    public RequestBki(String clientINN, int docType) {
        this.clientINN = clientINN;
        this.docType = docType;
    }

    public String getClientINN() {
        return clientINN;
    }

    public void setClientINN(String clientINN) {
        this.clientINN = clientINN;
    }

    public int getDocType() {
        return docType;
    }

    public void setDocType(int docType) {
        this.docType = docType;
    }

    @Override
    public String toString() {
        return "RequestBki{" +
                "clientINN='" + clientINN + '\'' +
                ", docType=" + docType +
                '}';
    }
}
