package ru.usb.sbki_protection.service;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;
import ru.usb.sbki_protection.config.LG;
import ru.usb.sbki_protection.model.ResponseBki;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


@Service
public class DbLayer {

    private static final Logger log = LoggerFactory.getLogger(DbLayer.class);

    private static final String SELECT_CHECK_CONNECT = "select 1 from dual";
    private static final String SELECT_GET_BKI_DATA = "select ClientINN, ContractNumber,ContractDate, Uuid from bki";


    @Qualifier("creDataSource")
    private final DataSource creDataSource;

    @Autowired
    public DbLayer(DataSource creDataSource) {
        this.creDataSource = creDataSource;
    }

    public String getDbName() {
        return creDataSource.toString();
    }

    /**
     * Проверка соединения с базой данных
     *
     * @return - true успех, false - ошибка
     */
    public boolean checkConnectToDbase() {
        try (Connection connectionCre = creDataSource.getConnection();
             PreparedStatement preparedStatement = connectionCre.prepareStatement(SELECT_CHECK_CONNECT)) {
            if (preparedStatement.execute()) {
                log.info("{}: Check connection to database successful", LG.USBLOGINFO);
                return true;
            } else {
                log.error("{}: Check connection to database failed", LG.USBLOGERROR);
                return false;
            }
        } catch (SQLException exception) {
            log.error("{}: Exception, when check connection to database", LG.USBLOGERROR, exception);
            return false;
        }
    }


    /**
     * Получение данных из БД
     *
     * @param clientInn - ИНН клиента
     * @param docType   - Тип договора
     * @return - список данных
     */
    public List<ResponseBki> getBkiData(String clientInn, String docType) {
        try (Connection connectionCre = creDataSource.getConnection();
        ) {
            return new JdbcTemplate(new SingleConnectionDataSource(connectionCre, true))
                    .query(SELECT_GET_BKI_DATA, (rs, rowNum) ->
                            new ResponseBki(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public void updateFailedBki() {

        try (var conn = creDataSource.getConnection();
             //var statement = conn.prepareCall("{exec emp_by_job(?,?,?)}");) {
             CallableStatement proc = conn.prepareCall("call emp_by_job(?,?,?)");) {
            proc.setString(1, "1");
            proc.setString(2, "1");
            proc.registerOutParameter(3, OracleTypes.CURSOR);
            proc.setQueryTimeout(300); //Установка времени таймаута
            proc.execute(); //Выполнение
            ResultSet rs = ((OracleCallableStatement) proc).getCursor(3);
            List<ResponseBki> cursorTreatmInfoList = new ArrayList<>();
            if (rs == null) {
             //
            } else {
                while (rs.next()) {
                    log.info("UsbLog from databse:: RS1=" + rs.getString(1) + "; RS2=" + rs.getString(2) + "; RS3=" + rs.getString(3) + "; RS4=" + rs.getString(4));
                }
            }
            rs.close();
            log.info("Процедура завершена");
        } catch (SQLException ex) {
            log.error("[updateFailedBki]Ошибка:{}", ex.getMessage());
            log.error("[updateFailedBki]Ошибка s:", ex);
        }
    }

    //exec emp_by_job('1','2', :rc );


}
