package ru.usb.sbki_protection;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.sbki_protection.config.LG;
import ru.usb.sbki_protection.service.DbLayer;

@SpringBootApplication
public class SbkiProtectionApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(SbkiProtectionApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SbkiProtectionApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.0.1") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r (Service [Микросервис: Sbki-protection] Передача информации о судебных делах ЮЛ в БКИ)")
				.contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
				.version(appVersion)
				.description("API для [Проект 8865] задача № 976931«Судебная защита. Доработка системы»" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Autowired
	DbLayer dbLayer;

	@Override
	public void run(String... args) throws Exception {
		logger.info(".");
		logger.info("..");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : Sbki-protection", LG.USBLOGINFO);
		logger.info("{}:| Version of service           : 0.0.1", LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 06/12/2024 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| tbank.custrisk.csv           : Информация о группе риска клиента", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  20.11.2024  : 0.0.11 Дополнено Web API", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("..");
		logger.info(".");
		dbLayer.updateFailedBki();
	}
}
