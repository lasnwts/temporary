package ru.usb.sbki_protection.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Класс для передачи данных из БКИ
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseBki {

    /**
     * clientINN	ИНН Клиента	S12
     * contractNumber	Номер договора/гарантии	S50
     * contractDate	Дата договора/гарантии	D
     * uuid	УИД	S50
     */

    @JsonProperty("ClientINN")
    private String clientINN;

    @JsonProperty("ContractNumber")
    private String contractNumber;

    @JsonProperty("ContractDate")
    private String contractDate;

    @JsonProperty("Uuid")
    private String uuid;

    public ResponseBki(String clientINN, String contractNumber, String contractDate, String uuid) {
        this.clientINN = clientINN;
        this.contractNumber = contractNumber;
        this.contractDate = contractDate;
        this.uuid = uuid;
    }

    public ResponseBki() {
        //
    }

    public String getClientINN() {
        return clientINN;
    }

    public void setClientINN(String clientINN) {
        this.clientINN = clientINN;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getContractDate() {
        return contractDate;
    }

    public void setContractDate(String contractDate) {
        this.contractDate = contractDate;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public String toString() {
        return "ResponseBki{" +
                "clientINN='" + clientINN + '\'' +
                ", contractNumber='" + contractNumber + '\'' +
                ", contractDate='" + contractDate + '\'' +
                ", uuid='" + uuid + '\'' +
                '}';
    }
}
