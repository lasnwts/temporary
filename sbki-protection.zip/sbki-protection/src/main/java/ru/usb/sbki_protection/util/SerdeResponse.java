package ru.usb.sbki_protection.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.usb.sbki_protection.config.LG;
import ru.usb.sbki_protection.model.ResponseBki;


import java.util.Optional;

@Service
public class SerdeResponse {

    private static final Logger log = LoggerFactory.getLogger(SerdeResponse.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Получение документа в виде объекта
     * @param json - строка Json
     * @return - Pack
     */
    public Optional<ResponseBki> getPack(String json) {
        if (json == null) {
            log.error("{}: На маппер ResponseBki поступил объект, строка [Json] == NULL!", LG.USBLOGERROR);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, ResponseBki.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", LG.USBLOGERROR, e);
            return Optional.empty();        }
    }

    /**
     * Получение документа в виде Json строки
     * @param document - Pack
     * @return - Json строка
     */
    public String getJson(ResponseBki document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [ResponseBki] == NULL!", LG.USBLOGERROR);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа ResponseBki :{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге ResponseBki:", LG.USBLOGERROR, e);
            return null;
        }
    }
}
