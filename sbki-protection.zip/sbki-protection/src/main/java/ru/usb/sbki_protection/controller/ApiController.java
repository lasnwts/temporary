package ru.usb.sbki_protection.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.sbki_protection.config.LG;
import ru.usb.sbki_protection.model.ResponseBki;
import ru.usb.sbki_protection.service.DbLayer;

import java.util.List;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для проверки почтовой подсистемы", description = "Проверка отправки почты")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);

    private final DbLayer dbLayer;

    @Autowired
    public ApiController(DbLayer dbLayer) {
        this.dbLayer = dbLayer;
    }


    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/check")
    @Operation(summary = "Проверка соединения с базой данных")
    public ResponseEntity<String> checkDb() {
        logger.info("{}: WebAPI. Проверка соединения с базой данных", LG.USBLOGINFO);
        if (dbLayer.checkConnectToDbase()) {
            return new ResponseEntity<>("База данных доступна", HttpStatus.OK);

        } else {
            return new ResponseEntity<>("База данных недоступна", HttpStatus.NOT_FOUND);
        }
    }


    /**
     * Наименование поля	Описание	Тип данных
     * ClientINN	ИНН Клиента	S12
     * DocType	Тип договора	I
     */
    @GetMapping(value = "/{clientInn}/{docType}")
    @Operation(summary = "Проверка соединения с базой данных")
    public ResponseEntity<List<ResponseBki>> getBkiDate(@Parameter(description = "ИНН Клиента") @PathVariable("clientInn") String clientInn,
                                                        @Parameter(description = "Тип договора") @PathVariable("docType") String docType) {
        logger.info("{}: WebAPI. Запрос в СБКИ, ClientINN={}, docType={}", LG.USBLOGINFO, clientInn, docType);
        List<ResponseBki> bkiData = dbLayer.getBkiData(clientInn, docType);
        return new ResponseEntity<>(bkiData, HttpStatus.OK);

    }


}
