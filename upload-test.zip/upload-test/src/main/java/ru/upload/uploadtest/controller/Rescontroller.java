package ru.upload.uploadtest.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

@RestController
@RequestMapping("/api/v1/email")
@Api(value = "user", description = "Контроллер по REST API для проверки Email.", tags = "Rest API 3.(Email) для проверки почты.")
public class Rescontroller {

    private Logger LOG = LoggerFactory.getLogger(Rescontroller.class);

    String pathFile = "C:\\AppServer\\Data\\";

    @RequestMapping(value = "/upload", method = RequestMethod.GET)
    @ApiOperation(value = "Проверка сервиса отправки почты",
            notes = "введите электронный адрес для отправки почты на проверку",
            response = String.class)
    public @ResponseBody String provideUploadInfo() {
        return "Вы можете загружать файл с использованием того же URL.";
    }

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    @ApiOperation(value = "Проверка сервиса отправки почты",
            notes = "введите электронный адрес для отправки почты на проверку",
            response = String.class)
    public @ResponseBody String handleFileUpload(@RequestParam("file") MultipartFile file) {

        String fileName = "file";
        fileName = file.getOriginalFilename();

        if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
                BufferedOutputStream stream =
                        new BufferedOutputStream(new FileOutputStream(new File(pathFile + fileName)));
                stream.write(bytes);
                stream.close();
                return "Вы удачно загрузили " + fileName + " в " + pathFile + fileName;
            } catch (Exception e) {
                return "Вам не удалось загрузить " + fileName + " => " + e.getMessage();
            }
        } else {
            return "Вам не удалось загрузить " + fileName + " потому что файл пустой.";
        }
    }

}
