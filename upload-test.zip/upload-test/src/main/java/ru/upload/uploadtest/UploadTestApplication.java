package ru.upload.uploadtest;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication
public class UploadTestApplication {


	Logger logger = LoggerFactory.getLogger(UploadTestApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(UploadTestApplication.class, args);
	}

	@Bean
	public Docket swaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(Predicates.or(
						PathSelectors.ant("/api/v1/**"),
						PathSelectors.ant("/api/v1/tcr/*")
				))
				.apis(RequestHandlerSelectors.basePackage("ru.upload"))
				.build()
				.apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() {
		Contact contact = new Contact("Help page of service zsk94528", "../", "LyapustinAS@spb.uralsib.ru");
		return new ApiInfoBuilder()
				.title("945028 Участие в пилоте БР по Платформе ЗСК. Rest Api Title 15/06/2022")
				.description("Api Definition by @alexander")
				.version("version 1.0")
				.license("Apache 2.0")
				.licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
				.contact(contact)
				.build();
	}


}
