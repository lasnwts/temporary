package ru.usb.citigpg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitigpgApplicationTests {

	@Test
	void contextLoads() {
	}

}
