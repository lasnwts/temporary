package ru.usb.citigpg;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.citigpg.config.Configure;
import ru.usb.citigpg.service.EmailServiceImpl;
import ru.usb.citigpg.utils.WorkWithFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@SpringBootApplication
public class CitigpgApplication implements CommandLineRunner {

    //Параметр (флаг), для проверки существования всех директорий
    boolean controlDirectoryExists;

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    EmailServiceImpl emailService;

    private String commandLine;

    Logger logger = LoggerFactory.getLogger(CitigpgApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitigpgApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        controlDirectoryExists = false; //Инициализация проверки наличия директорий
        logger.info("start {} version {}", configure.getInfoAppName(), configure.getInfoAppVersion());

        //Проверяем и создаем директории
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgArchiveDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgDecryptDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgCryptedDirecory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgOutgoingDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgEncryptedDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgOutgoingDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgOutgoingDirectory());
        controlDirectoryExists = withFiles.createdDirectory(configure.getGpgErrorDirectory());

        if (controlDirectoryExists) {

            /******************************************************************
             * Блок обработки входящих ЗАШИФРОВАННЫХ файлов из СИТИ
             * ****************************************************************
             */
            logger.info("*****************************************************************");
            logger.info("* Блок обработки входящих файлов из СИТИ                        *");
            logger.info("*****************************************************************");
            //Смотрим директорию с файлами для дешифровки
            List<File> fileList = new ArrayList<>();
            fileList = withFiles.getDirList(configure.getGpgCryptedDirecory());
            if (fileList.size() != 0) {
                fileList.forEach(new Consumer<File>() {
                    @Override
                    public void accept(File file) {
                        logger.info("Получен файл: {}", file.getAbsolutePath());
                        if (withFiles.checkFileName(file.getName())) {

                            if (!withFiles.isFilelocked(file)) {
                                commandLine = configure.getGpgProgram() + " --y --output " + configure.getGpgDecryptDirectory() + FileSystems.getDefault().getSeparator() + withFiles.getFileNameWithoutExt(file) + " --decrypt " + file.getAbsolutePath();
                                logger.info(" Командная строка : {}", commandLine);
                                try {
                                    Runtime.getRuntime().exec(commandLine).waitFor();
                                    if (configure.isGpgFileDeleted()) {
                                        logger.info("Удаляем файл : {}", file.getAbsolutePath());
                                        withFiles.delFilesSName(file.getAbsolutePath());
                                    } else {
                                        //Перемещаем файл в каталог архива
                                        if (withFiles.checkPathExists(configure.getGpgArchiveDirectory())) {
                                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgArchiveDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                        } else {
                                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                            logger.error("!!Error:Ошибка! Произошла ошибка переноса файла::{}  -> в архив::{}", file.getAbsolutePath(), configure.getGpgArchiveDirectory());
                                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка! Произошла ошибка переноса файла:" + file.getAbsolutePath() + "  -> в архив::" + configure.getGpgArchiveDirectory());
                                        }
                                    }
                                } catch (Exception e) {
                                    logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    logger.error("!!Error:Ошибка!InterruptedException! Произошла ошибка при обработке файла::{}", file.getAbsolutePath());
                                    logger.error("!!Error:Ошибка!InterruptedException! {}", e.getMessage());
                                    logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                    emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка!InterruptedException! " + e.getMessage());
                                    throw new RuntimeException(e);
                                }
                            } else {
                                logger.info(" Файл: {}", file.getAbsolutePath(), " захвачен другим процессом, обработку пропускаем.");
                                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Файл  захвачен другим процессом, обработку пропускаем::" + file.getAbsolutePath());
                            }
                        } else {
                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            logger.error("!!Error:Ошибка!Имя файла содержит пробелы, такие имена файлов не обрабатываются! Произошла ошибка при обработке файла::{}", file.getAbsolutePath());
                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка!Имя файла содержит пробелы, такие имена файлов не обрабатываются! Произошла ошибка при обработке файла:" + file.getAbsolutePath());
                        }
                    }
                });

            } else {
                logger.info("Файлов для расшифровки нет в директории: {}", configure.getGpgCryptedDirecory());
            }

            /**********************************************************
             * Блок обработки исходящих файлов из УралСиб в СИТИ
             * gpg --encrypt --output file.gpg --recipient alexl1967 file
             * ********************************************************
             */
            logger.info(" ");
            logger.info("*****************************************************************");
            logger.info("* Блок обработки исходящих файлов из Уралсиб в СИТИ             *");
            logger.info("*****************************************************************");

            //Смотрим директорию с файлами для отправки в СИТИ и шифрования
            List<File> files = new ArrayList<>();
            files = withFiles.getDirList(configure.getGpgOutgoingDirectory());
            if (files.size() != 0) {
                files.forEach(new Consumer<File>() {
                    @Override
                    public void accept(File file) {
                        logger.info("Получен файл: {}", file.getAbsolutePath());
                        if (withFiles.checkFileName(file.getName())) {

                            if (!withFiles.isFilelocked(file)) {
                                commandLine = configure.getGpgProgram() + " --y --encrypt --output " + configure.getGpgEncryptedDirectory() + FileSystems.getDefault().getSeparator()
                                        + file.getName() + ".gpg --recipient " + configure.getGpgKeyRecepient() + " " + file.getAbsolutePath();
                                logger.info(" Командная строка : {}", commandLine);
                                try {
                                    Runtime.getRuntime().exec(commandLine).waitFor();
                                    if (configure.isGpgFileDeleted()) {
                                        logger.info("Удаляем файл : {}", file.getAbsolutePath());
                                        withFiles.delFilesSName(file.getAbsolutePath());
                                    } else {
                                        //Перемещаем файл в каталог архива
                                        if (withFiles.checkPathExists(configure.getGpgArchiveOutDirectory())) {
                                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgArchiveOutDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                        } else {
                                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                            logger.error("!!Error:Ошибка! Произошла ошибка переноса файла::{}  -> в архив::{}", file.getAbsolutePath(), configure.getGpgArchiveOutDirectory());
                                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка! Произошла ошибка переноса файла:" + file.getAbsolutePath() + "  -> в архив::" + configure.getGpgArchiveOutDirectory());
                                        }
                                    }
                                } catch (Exception e) {
                                    logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    logger.error("!!Error:Ошибка!InterruptedException! Произошла ошибка при обработке файла::{}", file.getAbsolutePath());
                                    logger.error("!!Error:Ошибка!InterruptedException! {}", e.getMessage());
                                    logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                                    emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка!InterruptedException! " + e.getMessage());
                                    throw new RuntimeException(e);
                                }
                            } else {
                                logger.info(" Файл: {}", file.getAbsolutePath(), " захвачен другим процессом, обработку пропускаем.");
                                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Файл  захвачен другим процессом, обработку пропускаем::" + file.getAbsolutePath());
                            }
                        } else {
                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            logger.error("!!Error:Ошибка!Имя файла содержит пробелы, такие имена файлов не обрабатываются! Произошла ошибка при обработке файла::{}", file.getAbsolutePath());
                            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            withFiles.moveFileSName(file.getAbsolutePath(), configure.getGpgErrorDirectory() + FileSystems.getDefault().getSeparator() + file.getName());
                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error:Ошибка!Имя файла содержит пробелы, такие имена файлов не обрабатываются! Произошла ошибка при обработке файла:" + file.getAbsolutePath());
                        }
                    }
                });
            } else {
                logger.info("Файлов для отправки нет в директории: {}", configure.getGpgOutgoingDirectory());
            }

            /**
             * Обработка файлов завершена
             */
            logger.info("stoped {} version {}", configure.getInfoAppName(), configure.getInfoAppVersion());
        } else {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!Error. Ошибка! Часть каталогов недоступна. Выполнение невозможно! ");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "!!Error. Ошибка! Часть каталогов недоступна. Выполнение невозможно! ");
        }

    }

}
