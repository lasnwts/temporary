package ru.usb.citigpg.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    /**
     * Расшифрованные файлы из ЦБ
     * gpg.program="C:/Program Files (x86)/GnuPG/bin/gpg.exe"
     * gpg.archive.directory=C:/AppServer/Project/Banking/citi/data/encrypted/archive
     * <p>
     * # ************************************
     * # Path Decrypt (decrypted)
     * # ************************************
     * gpg.decrypt.directory=C:/AppServer/Project/Banking/citi/data/decrypt
     * gpg.crypted.direcory"=C:/AppServer/Project/Banking/citi/data/encrypted
     * <p>
     * # ************************************
     * # Path Encrypt (Encrypted)
     * # ************************************
     * gpg.outgoing.directory=C:/AppServer/Project/Banking/citi/data/decrypt
     * gpg.encrypted.directory"=C:/AppServer/Project/Banking/citi/data/encrypted
     * <p>
     * gpg.key.recepient=7E95374291B3A11A8AB1FB43E573571E5CB6FF5B
     */


    @Value("${gpg.program}")
    private String gpgProgram;

    //Директория с расшифрованными входящими файлами из СИТИ
    @Value("${gpg.decrypt.directory}")
    private String gpgDecryptDirectory;

    //Директория с файлами из СИТИ (зашифрованными)
    @Value("${gpg.crypted.direcory}")
    private String gpgCryptedDirecory;

    @Value("${info.app.name}")
    private String infoAppName;

    @Value("${info.app.version}")
    private String infoAppVersion;

    // Архивная директория, содержащая входящие файлы (зашифрованные), отправленные из банка СИТИ в Уралсиб
    // Файлы попадают в архивную директорию если установлен признак удаления (см. gpg.file.deleted) файлов в FALSE
    @Value("${gpg.archive.directory}")
    private String gpgArchiveDirectory;

    // Архивная директория, содержащая исходящие файлы (незашифрованные), отправленные из банка Уралсиб в СИТИ
    // Файлы попадают в архивную директорию если установлен признак удаления (см. gpg.file.deleted) файлов в FALSE
    @Value("${gpg.archive.outdirectory}")
    private String gpgArchiveOutDirectory;

    //Признак удаления файлов после обработки (TRUE), или помещения файлов в архив в случае = FALSE
    @Value("${gpg.file.deleted:true}")
    private boolean gpgFileDeleted;

    //Key ID получателя для команды для кого шифруем файлы
    @Value("${gpg.key.recepient}")
    private String gpgKeyRecepient;


    //Директория для файлов из Уралсиб в СИТИ
    //Файл здесь не зашифрованы
    @Value("${gpg.outgoing.directory}")
    private String gpgOutgoingDirectory;

    //Директория зашифрованных файлов из Уралсиб в СИТИ
    @Value("${gpg.encrypted.directory}")
    private String gpgEncryptedDirectory;

    //Директория с ошибками шифрации и дешифрации
    @Value("${gpg.error.directory}")
    private String gpgErrorDirectory;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:Проверка ЗСК – ошибка передачи данных}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;



    /**
     *
     * Реализация GETTerov
     */
    public String getGpgProgram() {
        return gpgProgram;
    }

    public String getGpgDecryptDirectory() {
        return gpgDecryptDirectory;
    }

    public String getGpgCryptedDirecory() {
        return gpgCryptedDirecory;
    }

    public String getGpgKeyRecepient() {
        return gpgKeyRecepient;
    }

    public String getGpgArchiveDirectory() {
        return gpgArchiveDirectory;
    }

    public boolean isGpgFileDeleted() {
        return gpgFileDeleted;
    }

    public String getInfoAppName() {
        return infoAppName;
    }

    public String getInfoAppVersion() {
        return infoAppVersion;
    }

    public String getGpgOutgoingDirectory() {
        return gpgOutgoingDirectory;
    }

    public String getGpgEncryptedDirectory() {
        return gpgEncryptedDirectory;
    }

    public String getGpgArchiveOutDirectory() {
        return gpgArchiveOutDirectory;
    }

    public String getGpgErrorDirectory() {
        return gpgErrorDirectory;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }
}
