package ru.usb.getDocIBSO952751.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VW_CRIT_USB_IMG_DREF_SIEBEL")
public class VWCritUsbImgDrefSiebels {

    @Id
    private long id;
    private String CLASS_ID;
    private String C_ID;
    private String C_ACCOUNT_REQUEST;
    private String C_MAIN_DOG;
    private String C_ACCOUNT;
    private String C_BRANCH_CODE;
    private String C_CLIENT_NAME;
    private String COLLECTION_ID;
    private String C_COLLECTION_ID;
    private String C_FILE_NAME;
    private String C_FILE_TYPE;

    public VWCritUsbImgDrefSiebels() {
    }

    public VWCritUsbImgDrefSiebels(long id, String CLASS_ID, String c_ID, String c_ACCOUNT_REQUEST, String c_MAIN_DOG, String c_ACCOUNT, String c_BRANCH_CODE, String c_CLIENT_NAME, String COLLECTION_ID, String c_COLLECTION_ID, String c_FILE_NAME, String c_FILE_TYPE) {
        this.id = id;
        this.CLASS_ID = CLASS_ID;
        C_ID = c_ID;
        C_ACCOUNT_REQUEST = c_ACCOUNT_REQUEST;
        C_MAIN_DOG = c_MAIN_DOG;
        C_ACCOUNT = c_ACCOUNT;
        C_BRANCH_CODE = c_BRANCH_CODE;
        C_CLIENT_NAME = c_CLIENT_NAME;
        this.COLLECTION_ID = COLLECTION_ID;
        C_COLLECTION_ID = c_COLLECTION_ID;
        C_FILE_NAME = c_FILE_NAME;
        C_FILE_TYPE = c_FILE_TYPE;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCLASS_ID() {
        return CLASS_ID;
    }

    public void setCLASS_ID(String CLASS_ID) {
        this.CLASS_ID = CLASS_ID;
    }

    public String getC_ID() {
        return C_ID;
    }

    public void setC_ID(String c_ID) {
        C_ID = c_ID;
    }

    public String getC_ACCOUNT_REQUEST() {
        return C_ACCOUNT_REQUEST;
    }

    public void setC_ACCOUNT_REQUEST(String c_ACCOUNT_REQUEST) {
        C_ACCOUNT_REQUEST = c_ACCOUNT_REQUEST;
    }

    public String getC_MAIN_DOG() {
        return C_MAIN_DOG;
    }

    public void setC_MAIN_DOG(String c_MAIN_DOG) {
        C_MAIN_DOG = c_MAIN_DOG;
    }

    public String getC_ACCOUNT() {
        return C_ACCOUNT;
    }

    public void setC_ACCOUNT(String c_ACCOUNT) {
        C_ACCOUNT = c_ACCOUNT;
    }

    public String getC_BRANCH_CODE() {
        return C_BRANCH_CODE;
    }

    public void setC_BRANCH_CODE(String c_BRANCH_CODE) {
        C_BRANCH_CODE = c_BRANCH_CODE;
    }

    public String getC_CLIENT_NAME() {
        return C_CLIENT_NAME;
    }

    public void setC_CLIENT_NAME(String c_CLIENT_NAME) {
        C_CLIENT_NAME = c_CLIENT_NAME;
    }

    public String getCOLLECTION_ID() {
        return COLLECTION_ID;
    }

    public void setCOLLECTION_ID(String COLLECTION_ID) {
        this.COLLECTION_ID = COLLECTION_ID;
    }

    public String getC_COLLECTION_ID() {
        return C_COLLECTION_ID;
    }

    public void setC_COLLECTION_ID(String c_COLLECTION_ID) {
        C_COLLECTION_ID = c_COLLECTION_ID;
    }

    public String getC_FILE_NAME() {
        return C_FILE_NAME;
    }

    public void setC_FILE_NAME(String c_FILE_NAME) {
        C_FILE_NAME = c_FILE_NAME;
    }

    public String getC_FILE_TYPE() {
        return C_FILE_TYPE;
    }

    public void setC_FILE_TYPE(String c_FILE_TYPE) {
        C_FILE_TYPE = c_FILE_TYPE;
    }
}
