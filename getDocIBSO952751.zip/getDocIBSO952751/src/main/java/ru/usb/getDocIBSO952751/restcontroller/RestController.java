package ru.usb.getDocIBSO952751.restcontroller;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.getDocIBSO952751.config.Configure;
import ru.usb.getDocIBSO952751.model.RespJSON;
import ru.usb.getDocIBSO952751.model.ResponseDog;
import ru.usb.getDocIBSO952751.model.ResponseXML;
import ru.usb.getDocIBSO952751.service.GetFile;
import ru.usb.getDocIBSO952751.utils.NewFileInputStream;

import java.io.IOException;
import java.util.Base64;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер получения файлов вложений из Ритейла", tags = "Rest API")
public class RestController {

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @Autowired
    Configure configure;

    @Autowired
    GetFile getFile;


    @GetMapping("/file")
    @ApiOperation(value = "Запрос по файлу договора из Ритейла",
            notes = "Файл Ритейла\n" +
                    " AttachmentID - id договора в Ритейле. Поле C_COLLECTION_ID\n" +
                    "filename - имя файла без расширения, для запроса конкретного файла")
    public ResponseEntity getRetailFile(String AttachmentID, String fileName) {

        logger.info(">>>>>>>>>>>>>>>>>>> Request(from Siebel)/Function:getRetailFile >>>>>>>");
        logger.info("Запрос id::" + AttachmentID);
        logger.info("Имя файла::" + fileName);

        /**
         * Проверки параметров запроса
         */
        try {
            long number = Long.parseLong(AttachmentID);
        } catch (NumberFormatException ex) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id{}, --not a numeric!!!!!!!", AttachmentID);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            ex.printStackTrace();
            logger.error("PrintStackTrace::", ex.getMessage());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! id должен быть цифрой! id=" + AttachmentID);
        }
        if (fileName == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String fileName{},--not a NULL !!!!!!", AttachmentID);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! Имя файла FileName не может быть пустом. FileName={}" + fileName);
        }

        ResponseXML responseXML = new ResponseXML();

        try {
            logger.info("<<<<<<<<<<<<<<<<< Reposnse(from Retail to Siebel)/Function:getRetailFile <<<<<<<<<<<<<<");
            responseXML = getFile.getOneFile(AttachmentID, fileName);

            if (responseXML == null || responseXML.getFileName() == null) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("!!!!!!!!!  An error occurred while njt found record in Retail view             ! !!!!!");
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! В Рителей в представлении VW_RPT_USB_IMG_DREF_SIEBEL нет записи с id="
                                + AttachmentID + " и fileName=" + fileName);
            }

            logger.info("Response:{}", responseXML.toString());
            logger.info("Имя (полное) файла из Ритейла:{}", responseXML.getFileName());
            logger.info("Размер файла из Ритейла:{}", responseXML.getFile().length());

            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(responseXML.getFile()));
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + responseXML.getFileName() + "\"")
                    //.headers(headers)
                    .contentLength(responseXML.getFile().length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id, String fileName)   !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e.getMessage());
            logger.info("Response:{}", responseXML.toString());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка::" + e.getMessage());
        }

    }


    /**
     * Получение файла как Base64
     * https://www.base64decode.org/
     *
     * @param AttachmentID
     * @param fileName
     * @return
     */
    @GetMapping("/getjson")
    @ApiOperation(value = "Запрос по файлу договора из Ритейла",
            notes = "Файл Ритейла\n" +
                    " AttachmentID - id договора в Ритейле. Поле C_COLLECTION_ID\n" +
                    "filename - имя файла без расширения, для запроса конкретного файла")
    public ResponseEntity<?> getRetailJson(String AttachmentID, String fileName) {

        logger.info(">>>>>>>>>>>>>>>>>>> Request(from Siebel)/Function:getRetailFile >>>>>>>");
        logger.info("Запрос id::" + AttachmentID);
        logger.info("Имя файла::" + fileName);

        /**
         * Проверки параметров запроса
         */
        try {
            long number = Long.parseLong(AttachmentID);
        } catch (NumberFormatException ex) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id{}, --not a numeric!!!!!!!", AttachmentID);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            ex.printStackTrace();
            logger.error("PrintStackTrace::", ex.getMessage());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! id должен быть цифрой! id=" + AttachmentID);
        }
        if (fileName == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String fileName{},--not a NULL !!!!!!", AttachmentID);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! Имя файла FileName не может быть пустом. FileName={}" + fileName);
        }

        ResponseXML responseXML = new ResponseXML();

        try {
            logger.info("<<<<<<<<<<<<<<<<< Reposnse(from Retail to Siebel)/Function:getRetailFile <<<<<<<<<<<<<<");
            responseXML = getFile.getOneFile(AttachmentID, fileName);

            if (responseXML == null || responseXML.getFileName() == null) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("!!!!!!!!!  An error occurred while njt found record in Retail view             ! !!!!!");
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! В Рителей в представлении VW_RPT_USB_IMG_DREF_SIEBEL нет записи с id="
                                + AttachmentID + " и fileName=" + fileName);
            }

            logger.info("Response:{}", responseXML.toString());
            logger.info("Имя (полное) файла из Ритейла:{}", responseXML.getFileName());
            logger.info("Размер файла из Ритейла:{}", responseXML.getFile().length());

            byte[] fileContent = new NewFileInputStream(responseXML.getFile()).readAllBytes();
            String encoded = Base64.getEncoder().encodeToString(fileContent);

            //Вариант 2
//             String encoded = getFile.encoder(responseXML.getFile().getAbsolutePath());


            RespJSON respJSON = new RespJSON();
            respJSON.setAttachBody(encoded);
            respJSON.setFilename(responseXML.getShortFileName());
            respJSON.setFileExt(responseXML.getExtension());

            logger.info("<<<<<<<<<<<<<<<<< Response id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.ok()
                    .header("Content-type", "application/json")
                    .body(respJSON);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id, String fileName)   !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e.getMessage());
            logger.info("Response:{}", responseXML.toString());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID, fileName);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Запись не найдена. Возникла ошибка::" + e.getMessage());
        }
    }

    @GetMapping("/dogovor")
    @ApiOperation(value = "Запрос на получение списка файлов по договору из Ритейла",
            notes = "Список файлов Ритейла\n" +
                    " AttachmentID - id договора в Ритейле. Поле C_COLLECTION_ID")
    public ResponseEntity<?> getRetailFile(String AttachmentID) throws JsonProcessingException {

        logger.info(">>>>>>>>>>>>>>>>>>> Request(from Siebel)/Function:getRetailFile >>>>>>>");
        logger.info("Запрос id::" + AttachmentID);

        /**
         * Проверки параметров запроса
         */
        try {
            long number = Long.parseLong(AttachmentID);
        } catch (NumberFormatException ex) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id{}, --not a numeric!!!!!!!", AttachmentID);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            ex.printStackTrace();
            logger.error("PrintStackTrace::", ex.getMessage());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={} ended <<<<<<<<<<<<<<", AttachmentID);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! id должен быть цифрой! id=" + AttachmentID);
        }

        ResponseDog responseDog = new ResponseDog(getFile.getFileDog(AttachmentID));

        if (responseDog == null || responseDog.getVwCritUsbImgDrefSiebelsList() == null || responseDog.getVwCritUsbImgDrefSiebelsList().isEmpty()) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while not found record in Retail view             ! !!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", AttachmentID);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка! В Рителей в представлении VW_RPT_USB_IMG_DREF_SIEBEL нет записей с id=" + AttachmentID);
        }

        return ResponseEntity.ok().header("Content-type", "application/json").body(responseDog);
    }


}
