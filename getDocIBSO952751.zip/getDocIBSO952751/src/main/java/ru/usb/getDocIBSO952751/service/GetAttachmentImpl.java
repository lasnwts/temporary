package ru.usb.getDocIBSO952751.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import ru.usb.getDocIBSO952751.config.Configure;
import ru.usb.getDocIBSO952751.model.RespJSON;
import ru.usb.getDocIBSO952751.model.RespXML;
import ru.usb.getDocIBSO952751.model.ResponseXML;
import ru.usb.getDocIBSO952751.model.VW_CRIT_USB_IMG_DREF_SIEBEL;
import ru.usb.getDocIBSO952751.repository.JpaCritUsbImgDrefSiebelRepo;
import ru.usb.getDocIBSO952751.utils.NewFileInputStream;
import ru.usb.getDocIBSO952751.utils.WorkWithFiles;

import javax.annotation.PostConstruct;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * serviceName = "Hello",
 * portName = "HelloPort",
 * targetNamespace = "http://service.ws.sample/",
 * endpointInterface = "com.example.demows.HelloServiceXML")
 */
@WebService(
        serviceName = "GetFile",
        portName = "GetFilePort",
        targetNamespace = "http://service.ws.fuse/",
        endpointInterface = "ru.usb.getDocIBSO952751.service.GetAttachment"
)
@Component
public class GetAttachmentImpl implements GetAttachment, ApplicationContextAware {

    Logger logger = LoggerFactory.getLogger(GetAttachmentImpl.class);

    private static ApplicationContext applicationContext;



    @Override
    public RespXML getAttachFile(String filename, String uid) {

        logger.info(">>>>>>>>>>>>>>>>>>> SOAP Request(from Siebel)/Function:getAttachFile >>>>>>>");
        logger.info("Запрос id::" + uid);
        logger.info("Имя файла::" + filename);

        GetSoapFile soapFile = (GetSoapFile)  applicationContext.getBean(GetSoapFile.class);

        RespXML respXML = new RespXML();

        /**
         * Проверки параметров запроса
         */
        try {
            long number = Long.parseLong(uid);
        } catch (NumberFormatException ex) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getAttachFile(String id{}, --not a numeric!!!!!!!", uid);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            ex.printStackTrace();
            logger.error("PrintStackTrace::", ex.getMessage());
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", uid, filename);
            respXML.setFilename("Ошибка id должен быть цифровой, но передан=" + uid);
            respXML.setFileExt("");
            respXML.setAttachBody("");
            return respXML;

        }
        if (filename == null || filename.trim().isEmpty()) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getAttachFile(String fileName{},--not a NULL !!!!!!", uid);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.info("<<<<<<<<<<<<<<<<< Reposnse id={}, file={} ended <<<<<<<<<<<<<<", uid, filename);
            respXML.setFilename("Ошибка! Не передано имя файла, в параметре [filename] передано=" + filename);
            respXML.setFileExt("");
            respXML.setAttachBody("");
            return respXML;
        }

        ResponseXML responseXML = new ResponseXML();
        logger.info("Request Soap from Siebel to Retail, id={}, fileName={}", uid, filename);
        responseXML = soapFile.getSoapFileFromRetail(uid,filename);

            if (responseXML == null || responseXML.getFileName() == null) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("!!!!!!!!!  An error occurred while not found record in Retail view             ! !!!!!");
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.info("<<<<<<<<<<<<<<<<< Soap Resposnse id={}, file={} ended <<<<<<<<<<<<<<", uid, filename);
                respXML.setFilename("Ошибка! Файл с параметрами id="+uid+" имя файла="+filename+" не найден в базе Ритейла. Представлении VW_CRIT_USB_IMG_DREF_SIEBEL");
                respXML.setFileExt("");
                respXML.setAttachBody("");
                return respXML;
            }

        logger.info("Response:{}", responseXML.toString());
        logger.info("Имя (полное) файла из Ритейла:{}", responseXML.getFileName());
        logger.info("Размер файла из Ритейла:{}", responseXML.getFile().length());

        byte[] fileContent = new byte[0];
        try {
            fileContent = new NewFileInputStream(responseXML.getFile()).readAllBytes();
        } catch (IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while not found record in Retail view             ! !!!!!");
            logger.error("!!! fileContent = new NewFileInputStream(responseXML.getFile()).readAllBytes();  !!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.info("<<<<<<<<<<<<<<<<< Soap Resposnse id={}, file={} ended <<<<<<<<<<<<<<", uid, filename);

            respXML.setFilename("Ошибка! Файл с параметрами id="+uid+" имя файла="+filename+" не найден в базе Ритейла. Представлении VW_CRIT_USB_IMG_DREF_SIEBEL");
            respXML.setFileExt("");
            respXML.setAttachBody("");
            return respXML;
        }
        String encoded = Base64.getEncoder().encodeToString(fileContent);

        respXML.setFilename(responseXML.getShortFileName());
        respXML.setFileExt(responseXML.getExtension());
        respXML.setAttachBody(encoded);

        return respXML;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
