package ru.usb.getDocIBSO952751.service;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.getDocIBSO952751.config.Configure;
import ru.usb.getDocIBSO952751.model.ResponseXML;
import ru.usb.getDocIBSO952751.model.VW_CRIT_USB_IMG_DREF_SIEBEL;
import ru.usb.getDocIBSO952751.repository.JpaCritUsbImgDrefSiebelRepo;
import ru.usb.getDocIBSO952751.utils.WorkWithFiles;

import javax.persistence.EntityManager;
import java.io.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Component
public class GetSoapFile {

    Logger logger = LoggerFactory.getLogger(GetSoapFile.class);

    @Autowired
    Configure configure;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    JpaCritUsbImgDrefSiebelRepo jpaImg;

    private EntityManager entityManager;

    public GetSoapFile(JpaCritUsbImgDrefSiebelRepo jpaImg, EntityManager entityManager) {
        this.jpaImg = jpaImg;
        this.entityManager = entityManager;
    }


    public ResponseXML getSoapFileFromRetail(String collection_id, String fileName){

        List<VW_CRIT_USB_IMG_DREF_SIEBEL> vwCritUsbImgDrefSiebels = new ArrayList<>();
        ResponseXML responseXML = new ResponseXML();


        try {
            vwCritUsbImgDrefSiebels = jpaImg.getSoapFile(collection_id, fileName);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!! getSoapFile An error occurred while retrieving information from the Reatial  !!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            return null;
        }

        if (vwCritUsbImgDrefSiebels == null || vwCritUsbImgDrefSiebels.size() == 0) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!  getSoapFile :getSoapFile    (String collection_id) == NULL  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        responseXML.setFile(writeFile(vwCritUsbImgDrefSiebels.get(0)));
        responseXML.setFileName(getNullString(vwCritUsbImgDrefSiebels.get(0).getC_FILE_NAME()) + "." + getNullString(vwCritUsbImgDrefSiebels.get(0).getC_FILE_TYPE()));
        responseXML.setExtension(getNullString(vwCritUsbImgDrefSiebels.get(0).getC_FILE_TYPE()));
        responseXML.setShortFileName(getNullString(vwCritUsbImgDrefSiebels.get(0).getC_FILE_NAME()));

        return responseXML;
    }

    /**
     * Функция получения содержимого файла во временной директории
     *
     * @param vwCritUsbImgDrefSiebel
     */
    private File writeFile(VW_CRIT_USB_IMG_DREF_SIEBEL vwCritUsbImgDrefSiebel) {

        InputStream binaryStream;
        try {
            binaryStream = vwCritUsbImgDrefSiebel.getC_IMAGE_DATA().getBinaryStream();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        File targetFile = null;
        if (binaryStream != null) {
            targetFile = withFiles.getTempFile(vwCritUsbImgDrefSiebel.getC_FILE_NAME(), vwCritUsbImgDrefSiebel.getC_FILE_TYPE(), configure.getTmpPath());
            OutputStream outStream = null;
            try {
                outStream = new FileOutputStream(targetFile);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

            byte[] buffer = new byte[8 * 1024];
            int bytesRead;
            while (true) {
                try {
                    if (!((bytesRead = binaryStream.read(buffer)) != -1)) break;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                try {
                    outStream.write(buffer, 0, bytesRead);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            IOUtils.closeQuietly(binaryStream);
            IOUtils.closeQuietly(outStream);
        }
        return targetFile;
    }


    /**
     * Получение расширения и имени файла
     *
     * @param line
     * @return
     */
    private String getNullString(String line) {
        if (line == null) {
            return "";
        }
        return line.trim();
    }

}
