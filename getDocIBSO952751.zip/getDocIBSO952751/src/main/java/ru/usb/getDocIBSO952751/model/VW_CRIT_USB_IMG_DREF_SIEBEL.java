package ru.usb.getDocIBSO952751.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import java.sql.Blob;


/**
 * https://egorzimowski.com/2022/05/27/composite-primary-key-in-jpa/
 */
@Entity
public class VW_CRIT_USB_IMG_DREF_SIEBEL {

    /**
     * Наименование тега/поля	Наименование род. тега/Описание	Возможные значения	Обяз.	Комментарий
     * C_ID	ID			ID записи
     * AccountRequestID, тип
     * VARCHAR2(128)
     *
     * C_ACCOUNT_REQUEST	Уникальный идентификатор между МКК и ИБСО, на основании которого открываются счета в ИБСО-Ритейл. По нему будет однозначно идентифицироваться договор МКК в АБС 	727264b16791478bb9d0ed914994b2fc	Да	Атрибут передается в Siebel CRM из МКК с витрины ЦХД в рамках целевого решения.
     * Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * Номер договора, тип
     * VARCHAR2(22)
     *
     * C_MAIN_DOG	Номер договора МКК в ИБСО-Ритейл	26986340	Да	На стороне интеграционной шины необходимо добавить префикс “У” в начало номера.
     * Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * Счет, тип VARCHAR2(25)
     *
     * C_ACCOUNT	Номер счета клиента в Банке	40817810300109484965	Да	Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * Филиал, тип VARCHAR2(4)
     *
     * C_BRANCH_CODE	Филиал выдачи займа МКК или открытия счета	001	Да	Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * Клиент, тип VARCHAR2(250)
     *
     * C_CLIENT_NAME	Заёмщик МКК	УСМАНОВА РАМЗИЛЯ АЛЬБЕРТОВНА	Нет	Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * COLLECTION_ID, тип NUMBER
     *
     * COLLECTION_ID	Уникальный идентификатор массива данных документов	641169681137	Да	Используется в передаваемом сообщении в качестве дополнительного атрибута для идентификации обмена данными с SiebelCRM. В Stage-таблицу Siebel CRM не записывается.
     * Имя файла, тип VARCHAR2(128)
     *
     * C_FILE_NAME	Имя вложенного файла без указания расширения	42864cf19b214351bb2475e104084ef5FILSIMAGE_42864CF19B214351BB2475E104084EF5_20220702150204100	Да	Передавать значение атрибута без расширения.
     * Расширение файла вложения, тип VARCHAR2(8)
     * C_FILE_TYPE	Расширение вложенного файла	PDF	Да	Расширение вложенного файла (без точки впереди)
     * Файл – вложение, тип blob
     * C_IMAGE_DATA	Сам файл, сконвертированный в blob			Поле типа blob, содержащее сам документ
     */


    @Id
    private String C_ID;
    private String C_ACCOUNT_REQUEST;
    private String C_MAIN_DOG;
    private String C_ACCOUNT;
    private String C_BRANCH_CODE;
    private String C_CLIENT_NAME;
    private String COLLECTION_ID;

    private String C_FILE_NAME;
    private String C_FILE_TYPE;
    @Lob
    private Blob C_IMAGE_DATA;

    public VW_CRIT_USB_IMG_DREF_SIEBEL() {
    }

    public String getC_ID() {
        return C_ID;
    }

    public void setC_ID(String c_ID) {
        C_ID = c_ID;
    }

    public String getC_ACCOUNT_REQUEST() {
        return C_ACCOUNT_REQUEST;
    }

    public void setC_ACCOUNT_REQUEST(String c_ACCOUNT_REQUEST) {
        C_ACCOUNT_REQUEST = c_ACCOUNT_REQUEST;
    }

    public String getC_MAIN_DOG() {
        return C_MAIN_DOG;
    }

    public void setC_MAIN_DOG(String c_MAIN_DOG) {
        C_MAIN_DOG = c_MAIN_DOG;
    }

    public String getC_ACCOUNT() {
        return C_ACCOUNT;
    }

    public void setC_ACCOUNT(String c_ACCOUNT) {
        C_ACCOUNT = c_ACCOUNT;
    }

    public String getC_BRANCH_CODE() {
        return C_BRANCH_CODE;
    }

    public void setC_BRANCH_CODE(String c_BRANCH_CODE) {
        C_BRANCH_CODE = c_BRANCH_CODE;
    }

    public String getC_CLIENT_NAME() {
        return C_CLIENT_NAME;
    }

    public void setC_CLIENT_NAME(String c_CLIENT_NAME) {
        C_CLIENT_NAME = c_CLIENT_NAME;
    }

    public String getCOLLECTION_ID() {
        return COLLECTION_ID;
    }

    public void setCOLLECTION_ID(String COLLECTION_ID) {
        this.COLLECTION_ID = COLLECTION_ID;
    }

    public String getC_FILE_NAME() {
        return C_FILE_NAME;
    }

    public void setC_FILE_NAME(String c_FILE_NAME) {
        C_FILE_NAME = c_FILE_NAME;
    }

    public String getC_FILE_TYPE() {
        return C_FILE_TYPE;
    }

    public void setC_FILE_TYPE(String c_FILE_TYPE) {
        C_FILE_TYPE = c_FILE_TYPE;
    }

    public Blob getC_IMAGE_DATA() {
        return C_IMAGE_DATA;
    }

    public void setC_IMAGE_DATA(Blob c_IMAGE_DATA) {
        C_IMAGE_DATA = c_IMAGE_DATA;
    }

    @Override
    public String toString() {
        return "VW_CRIT_USB_IMG_DREF_SIEBEL{" +
                "C_ID='" + C_ID + '\'' +
                ", C_ACCOUNT_REQUEST='" + C_ACCOUNT_REQUEST + '\'' +
                ", C_MAIN_DOG='" + C_MAIN_DOG + '\'' +
                ", C_ACCOUNT='" + C_ACCOUNT + '\'' +
                ", C_BRANCH_CODE='" + C_BRANCH_CODE + '\'' +
                ", C_CLIENT_NAME='" + C_CLIENT_NAME + '\'' +
                ", COLLECTION_ID='" + COLLECTION_ID + '\'' +
                ", C_FILE_NAME='" + C_FILE_NAME + '\'' +
                ", C_FILE_TYPE='" + C_FILE_TYPE + '\'' +
                ", C_IMAGE_DATA=" + C_IMAGE_DATA +
                '}';
    }
}
