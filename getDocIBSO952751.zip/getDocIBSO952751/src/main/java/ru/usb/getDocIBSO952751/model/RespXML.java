package ru.usb.getDocIBSO952751.model;

import java.util.Date;

public class RespXML {

    private String filename;
    private String FileExt;
    private String AttachBody;

    public RespXML() {
    }

    public RespXML(String filename, String fileExt) {
        this.filename = filename;
        FileExt = fileExt;
    }

    public RespXML(String filename, String fileExt, String attachBody) {
        this.filename = filename;
        FileExt = fileExt;
        AttachBody = attachBody;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFileExt() {
        return FileExt;
    }

    public void setFileExt(String fileExt) {
        FileExt = fileExt;
    }

    public String getAttachBody() {
        return AttachBody;
    }

    public void setAttachBody(String attachBody) {
        AttachBody = attachBody;
    }

    @Override
    public String toString() {
        return "RespXML{" +
                "filename='" + filename + '\'' +
                ", FileExt='" + FileExt + '\'' +
                ", AttachBody size='" + AttachBody.length() + '\'' +
                '}';
    }
}
