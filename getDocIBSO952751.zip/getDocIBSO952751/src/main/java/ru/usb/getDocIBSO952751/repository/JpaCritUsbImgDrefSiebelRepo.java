package ru.usb.getDocIBSO952751.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.getDocIBSO952751.model.VWCritUsbImgDrefSiebels;
import ru.usb.getDocIBSO952751.model.VW_CRIT_USB_IMG_DREF_SIEBEL;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaCritUsbImgDrefSiebelRepo extends JpaRepository<VW_CRIT_USB_IMG_DREF_SIEBEL, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select id, class_id,collection_id,c_id, c_account_request,c_account,c_main_dog,c_branch_code,c_client_name,c_collection_id,c_file_name,c_file_type,c_image_data " +
            "from VW_CRIT_USB_IMG_DREF_SIEBEL where c_collection_id =?1", nativeQuery = true)
    Stream<VW_CRIT_USB_IMG_DREF_SIEBEL> getCollection_id(String collection_id);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select id, class_id,collection_id,c_id, c_account_request,c_account,c_main_dog,c_branch_code,c_client_name,c_collection_id,c_file_name,c_file_type,c_image_data " +
            "from VW_CRIT_USB_IMG_DREF_SIEBEL where c_collection_id =?1 and c_file_name=?2", nativeQuery = true)
    Stream<VW_CRIT_USB_IMG_DREF_SIEBEL> getNameId(String collection_id, String fileName);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select id, class_id,collection_id,c_id, c_account_request,c_account,c_main_dog,c_branch_code,c_client_name,c_collection_id,c_file_name,c_file_type,c_image_data " +
            "from VW_CRIT_USB_IMG_DREF_SIEBEL where c_collection_id =?1 and c_file_name=?2", nativeQuery = true)
    List<VW_CRIT_USB_IMG_DREF_SIEBEL> getSoapFile(String collection_id, String fileName);

}
