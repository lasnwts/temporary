package ru.usb.getDocIBSO952751.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.getDocIBSO952751.model.VW_CRIT_USB_IMG_DREF_SIEBEL;

import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaCritUsbImgDrefSiebelRepo extends JpaRepository<VW_CRIT_USB_IMG_DREF_SIEBEL, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select C_ID,COLLECTION_ID,C_ACCOUNT,C_ACCOUNT_REQUEST,C_BRANCH_CODE,C_CLIENT_NAME,C_FILE_NAME,C_FILE_TYPE,C_IMAGE_DATA,C_MAIN_DOG " +
            "from VW_CRIT_USB_IMG_DREF_SIEBEL where collection_id =?1", nativeQuery = true)
    Stream<VW_CRIT_USB_IMG_DREF_SIEBEL> getCollection_id(String collection_id);
}
