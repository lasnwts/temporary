package ru.usb.getDocIBSO952751.service;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.getDocIBSO952751.config.Configure;
import ru.usb.getDocIBSO952751.model.ResponseXML;
import ru.usb.getDocIBSO952751.model.VWCritUsbImgDrefSiebels;
import ru.usb.getDocIBSO952751.model.VW_CRIT_USB_IMG_DREF_SIEBEL;
import ru.usb.getDocIBSO952751.repository.JpaCritUsbImgDrefSiebelRepo;
import ru.usb.getDocIBSO952751.repository.JpaResponseDogs;
import ru.usb.getDocIBSO952751.utils.WorkWithFiles;

import javax.persistence.EntityManager;
import java.io.*;
import java.nio.file.FileSystems;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Получаем файл из базы Ритейла
 */
@Service
public class GetFile {

    @Autowired
    Configure configure;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    JpaCritUsbImgDrefSiebelRepo jpaImg;

    @Autowired
    JpaResponseDogs jpaResponseDogs;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ServiceMailError serviceMailError;

    Logger logger = LoggerFactory.getLogger(GetFile.class);

    private EntityManager entityManager;

    public GetFile(JpaCritUsbImgDrefSiebelRepo jpaImg, EntityManager entityManager) {
        this.jpaImg = jpaImg;
        this.entityManager = entityManager;
    }


    /**
     * Тестовая функция получения группы файлов
     *
     * @param collection_id
     * @param fileName
     */
    @Transactional(readOnly = true)
    public void getFile(String collection_id, String fileName) {

        logger.info("Request from Siebel to Retail, id={}, fileName={}", collection_id, fileName);

        Stream<VW_CRIT_USB_IMG_DREF_SIEBEL> fTableStream = null;

        try {
            fTableStream = jpaImg.getNameId(collection_id, fileName);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            serviceMailError.sendMailError("Возникла проблема при работе с БД Ритейл:"+e.getMessage());
        }

        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!  fTableStream:getCollection_id(String collection_id) == NULL  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }

        try {
            AtomicInteger rownum = new AtomicInteger();
            logger.info("###################################################################################");
            logger.info("#  Output VW_RPT_HIST_CARD to a file                                              #");
            logger.info("###################################################################################");


            //Инициализируем переменную
            fTableStream.forEach(fTable -> {
                rownum.getAndIncrement();

                logger.info(fTable.toString());

//                withFiles.getTempFile(fTable.getC_FILE_NAME(),fTable.getC_FILE_TYPE(),configure.getTmpPath());

                writeFile(fTable);

                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while write information to a file }!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            serviceMailError.sendMailError("Возникла проблема при работе с БД Ритейл:"+e.getMessage());
        } finally {
            //Закрываем файл
            fTableStream.close();
        }
        logger.info("###### < Ended process write file #####");
    }


    /**
     * Реальная функция для запроса
     *
     * @param collection_id
     * @param fileName
     * @return
     */
    @Transactional(readOnly = true)
    public ResponseXML getOneFile(String collection_id, String fileName) {

        logger.info("Request from Siebel to Retail, id={}, fileName={}", collection_id, fileName);

        Stream<VW_CRIT_USB_IMG_DREF_SIEBEL> fTableStream = null;

        ResponseXML responseXML = new ResponseXML();

        try {
            fTableStream = jpaImg.getNameId(collection_id, fileName);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            serviceMailError.sendMailError("Возникла проблема при работе с БД Ритейл:"+e.getMessage());
            return null;
        }

        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!  fTableStream:getCollection_id(String collection_id) == NULL  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }


        try {
            AtomicInteger rownum = new AtomicInteger();
            logger.info("###################################################################################");
            logger.info("#  Output VW_RPT_HIST_CARD to a file                                              #");
            logger.info("###################################################################################");

            //Инициализируем переменную
            fTableStream.forEach(fTable -> {
                rownum.getAndIncrement();
                logger.info(fTable.toString());
                responseXML.setFile(writeFile(fTable));
                responseXML.setFileName(getNullString(fTable.getC_FILE_NAME()) + "." + getNullString(fTable.getC_FILE_TYPE()));
                responseXML.setNumberFile(rownum.getAndIncrement());
                responseXML.setExtension(getNullString(fTable.getC_FILE_TYPE()));
                responseXML.setShortFileName(getNullString(fTable.getC_FILE_NAME()));
                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while write information to a file }!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            serviceMailError.sendMailError("Возникла проблема при работе с БД Ритейл:"+e.getMessage());
            return null;
        } finally {
            //Закрываем файл
            fTableStream.close();
        }
        logger.info("###### < Ended process write file #####");
        return responseXML;
    }


    /**
     * Функция получения содержимого файла во временной директории
     *
     * @param vwCritUsbImgDrefSiebel
     */
    private File writeFile(VW_CRIT_USB_IMG_DREF_SIEBEL vwCritUsbImgDrefSiebel) {

        InputStream binaryStream;
        try {
            binaryStream = vwCritUsbImgDrefSiebel.getC_IMAGE_DATA().getBinaryStream();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        File targetFile = null;
        if (binaryStream != null) {
            targetFile = withFiles.getTempFile(vwCritUsbImgDrefSiebel.getC_FILE_NAME(), vwCritUsbImgDrefSiebel.getC_FILE_TYPE(), configure.getTmpPath());
            OutputStream outStream = null;
            try {
                outStream = new FileOutputStream(targetFile);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

            byte[] buffer = new byte[8 * 1024];
            int bytesRead;
            while (true) {
                try {
                    if (!((bytesRead = binaryStream.read(buffer)) != -1)) break;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                try {
                    outStream.write(buffer, 0, bytesRead);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            IOUtils.closeQuietly(binaryStream);
            IOUtils.closeQuietly(outStream);
        }
        return targetFile;
    }


    /**
     * Получение расширения и имени файла
     *
     * @param line
     * @return
     */
    private String getNullString(String line) {
        if (line == null) {
            return "";
        }
        return line.trim();
    }

    /**
     * @param filePath
     * @return
     */
    public String encoder(String filePath) {
        String base64File = "";
        File file = new File(filePath);
        try (FileInputStream imageInFile = new FileInputStream(file)) {
            // Reading a file from file system
            byte fileData[] = new byte[(int) file.length()];
            imageInFile.read(fileData);
            base64File = Base64.getEncoder().encodeToString(fileData);
        } catch (FileNotFoundException e) {
            System.out.println("File not found" + e);
        } catch (IOException ioe) {
            System.out.println("Exception while reading the file " + ioe);
        }
        return base64File;
    }


    /**
     * Получаем список
     *
     * @param id
     * @return
     */
    public List<VWCritUsbImgDrefSiebels> getFileDog(String id) {
        return jpaResponseDogs.getFileFromDog(id);
    }

    /**
     * Реальная функция для запроса
     *
     * @param collection_id
     * @param fileName
     * @return
     */

    public ResponseXML getSoapFile(String collection_id, String fileName) {

        logger.info("Request from Siebel to Retail, id={}, fileName={}", collection_id, fileName);

        List<VW_CRIT_USB_IMG_DREF_SIEBEL> vwCritUsbImgDrefSiebels = null;

        ResponseXML responseXML = new ResponseXML();

        try {
            vwCritUsbImgDrefSiebels = jpaImg.getSoapFile(collection_id, fileName);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!! jpaImg.getSoapFile(collection_id, fileName)!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            return null;
        }

        if (vwCritUsbImgDrefSiebels == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the Retail  !!!!!!!");
            logger.error("!!!!!!!!!!!!!  jpaImg.getSoapFile(collection_id, fileName) == NULL          !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        responseXML.setShortFileName(vwCritUsbImgDrefSiebels.get(0).getC_FILE_NAME());
        responseXML.setExtension(vwCritUsbImgDrefSiebels.get(0).getC_FILE_TYPE());


        logger.info("###### < Ended process write file #####");
        return responseXML;
    }

}
