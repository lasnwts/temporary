package ru.usb.getDocIBSO952751.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Component
public class WorkWithFiles {

    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }

    /**
     *  Получаем файцл
     * @param filename
     * @param extension
     * @param tempPath
     * @return
     */
    public File getTempFile(String filename, String extension, String tempPath) {

        File file = null;
        String filName = new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() +
                tempPath + FileSystems.getDefault().getSeparator() + filename + "." + extension;

        try {
            return new File(filName);
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred create file {}", filName);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            return new File(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() +
                    tempPath + FileSystems.getDefault().getSeparator() + UUID.randomUUID().toString());
        }


    }

}