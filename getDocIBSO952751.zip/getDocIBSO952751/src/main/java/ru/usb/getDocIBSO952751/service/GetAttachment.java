package ru.usb.getDocIBSO952751.service;

import ru.usb.getDocIBSO952751.model.RespXML;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(targetNamespace = "http://service.ws.fuse/", name = "GetAttachment")
public interface GetAttachment {

    /**
     *     @WebResult(name = "returnxml", targetNamespace = "")
     *     @RequestWrapper(
     *             localName = "getAttachFile",
     *             targetNamespace = "http://service.ws.fuse/",
     *             className = "fuse.ws.service.RequestGetFile")
     *     @WebMethod(action = "urn:getAttachFile")
     *     @ResponseWrapper(
     *             localName = "getResponseXML",
     *             targetNamespace = "http://service.ws.fuse/",
     *             className = "fuse.ws.service.RequestGetFile")
     *     RespXML getAttachFile(@WebParam(filename = "namexml", targetNamespace = "") String fileName,
     *                      @WebParam(name = "uid", targetNamespace = "") String uid);
     */


    @WebResult(name = "AttachmentXml", targetNamespace = "")
    @RequestWrapper(
            localName = "getAttachFile",
            targetNamespace = "http://service.ws.fuse/",
            className = "fuse.ws.service.RequestGetFile")
    @WebMethod(action = "urn:getAttachFile")
    @ResponseWrapper(
            localName = "getResponseXML",
            targetNamespace = "http://service.ws.fuse/",
            className = "fuse.ws.service.RequestGetFile")
    RespXML getAttachFile(@WebParam(name = "filename", targetNamespace = "") String filename,
                          @WebParam(name = "uid", targetNamespace = "") String uid);



}
