package ru.usb.getDocIBSO952751.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Класс для возвращения файла как JSON  с параметрами
 * Типа
 * И возвращаем в Response такой вот список (см. ниже) полей (AttachBody – сам файл в Base64).
 *                     <xs:sequence>
 *                         <xs:element name="AttachBody" type="xs:base64Binary"/>
 *                         <xs:element name="FileName" type="xs:string"/>
 *                         <xs:element name="FileExt" type="xs:string"/>
 *                     </xs:sequence>
 */
@ApiModel(value = "GetAttachmentBase64", description = "JSON с файлом, Base64")
@JsonIgnoreProperties(ignoreUnknown = true)
public class RespJSON {

    @ApiModelProperty(value = "FileName : имя файла")
    @JsonProperty("filename")
    private String filename;

    @ApiModelProperty(value = "FileExt : расширение файла")
    @JsonProperty("fileExt")
    private String fileExt;

    @ApiModelProperty(value = "AttachBody : тело файла в BASE64")
    @JsonProperty("attachBody")
    private String attachBody;

    public RespJSON() {
    }


    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFileExt() {
        return fileExt;
    }

    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }

    public String getAttachBody() {
        return attachBody;
    }

    public void setAttachBody(String attachBody) {
        this.attachBody = attachBody;
    }


}
