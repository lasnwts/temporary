package ru.usb.getDocIBSO952751.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.getDocIBSO952751.model.VWCritUsbImgDrefSiebels;

import javax.persistence.QueryHint;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaResponseDogs extends JpaRepository<VWCritUsbImgDrefSiebels, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select id, class_id,collection_id,c_id, c_account_request,c_account,c_main_dog,c_branch_code,c_client_name,c_collection_id,c_file_name,c_file_type " +
            "from VW_CRIT_USB_IMG_DREF_SIEBEL where c_collection_id =?1", nativeQuery = true)
    List<VWCritUsbImgDrefSiebels> getFileFromDog(String collection_id);



}
