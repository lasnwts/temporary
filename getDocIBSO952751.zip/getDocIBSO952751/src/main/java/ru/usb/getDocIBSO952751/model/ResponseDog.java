package ru.usb.getDocIBSO952751.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import java.util.List;

@ApiModel(description = "Ответ по договору")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseDog {

    private List<VWCritUsbImgDrefSiebels> vwCritUsbImgDrefSiebelsList;

    public ResponseDog() {
    }

    public ResponseDog(List<VWCritUsbImgDrefSiebels> vwCritUsbImgDrefSiebelsList) {
        this.vwCritUsbImgDrefSiebelsList = vwCritUsbImgDrefSiebelsList;
    }

    public List<VWCritUsbImgDrefSiebels> getVwCritUsbImgDrefSiebelsList() {
        return vwCritUsbImgDrefSiebelsList;
    }

    public void setVwCritUsbImgDrefSiebelsList(List<VWCritUsbImgDrefSiebels> vwCritUsbImgDrefSiebelsList) {
        this.vwCritUsbImgDrefSiebelsList = vwCritUsbImgDrefSiebelsList;
    }
}
