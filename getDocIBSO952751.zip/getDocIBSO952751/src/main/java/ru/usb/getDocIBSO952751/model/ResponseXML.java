package ru.usb.getDocIBSO952751.model;


import java.io.File;

public class ResponseXML {

    private String fileName;
    private String extension;
    private String shortFileName;

    private int numberFile;
    private File file;


    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getShortFileName() {
        return shortFileName;
    }

    public void setShortFileName(String shortFileName) {
        this.shortFileName = shortFileName;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public int getNumberFile() {
        return numberFile;
    }

    public void setNumberFile(int numberFile) {
        this.numberFile = numberFile;
    }

    @Override
    public String toString() {
        return "ResponseXML{" +
                "fileName='" + fileName + '\'' +
                ", extension='" + extension + '\'' +
                ", shortFileName='" + shortFileName + '\'' +
                ", numberFile=" + numberFile +
                ", file=" + file +
                '}';
    }
}
