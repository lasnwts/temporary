package ru.usb.getDocIBSO952751;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetDocIbso952751ApplicationTests {

	@Test
	void contextLoads() {
	}

}
