package ru.usb.csc2187mts;

import com.google.common.base.Predicates;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * REST Client (HTTP Client) полное описание
 * https://terasolunaorg.github.io/guideline/5.3.0.RELEASE/en/ArchitectureInDetail/WebServiceDetail/RestClient.html
 *
 * Downloading a Large File
 * https://devtut.github.io/spring/resttemplate.html#downloading-a-large-file
 *
 * How to use RestTemplate with Basic Auth SSLContext
 * https://stackoverflow.com/questions/23207928/how-to-use-resttemplate-with-basic-auth
 */

@EnableSwagger2
@SpringBootApplication
public class Csc2187mtsApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Csc2187mtsApplication.class, args);
	}

	@Bean
	public Docket swaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(Predicates.or(
						PathSelectors.ant("/api/v1/**"),
						PathSelectors.ant("/api/v1/tcr/*")
				))
				.apis(RequestHandlerSelectors.basePackage("ru.usb"))
				.build()
				.apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() {
		Contact contact = new Contact("Alexander Lyapustin", "../", "LyapustinAS@spb.uralsib.ru");
		return new ApiInfoBuilder()
				.title("Spring boot 2 Api Title 10/01/2022")
				.description("Api Definition by @alexander")
				.version("0.0.1")
				.license("Apache 2.0")
				.licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
				.contact(contact)
				.build();
	}

	@Override
	public void run(String... args) throws Exception {
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			System.out.println("Directory " + path.toString() + " = created");
		} else {
			System.out.println("Directory" + path.toString() + " = already exists");
		}
	}
}
