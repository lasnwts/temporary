package ru.usb.csc2187mts.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@ConfigurationProperties
public class Configure {


    @Value("${mtsurlnumbers}")
    private String mtsNumbersURL;

    @Value("${mtsurlrecs}")
    private String mtsRecsURL;

    @Value("${mtsurlfile}")
    private String mtsUrlFile;

    public String getMtsRecsURL() {
        return mtsRecsURL;
    }

    @Value("${csc2187mts.version}")
    private String version;

    public String getVersion() {
        return version;
    }

    @Value("${mtsLogin}")
    private String mtsLogin;

    @Value("${mtsPassword}")
    private String mtsPassword;

    public String getMtsLogin() {
        return mtsLogin;
    }

    public String getMtsPassword() {
        return mtsPassword;
    }

    public String getMtsNumbersURL() {
        return mtsNumbersURL;
    }

    public String getMtsUrlFile() {
        return mtsUrlFile;
    }


}
