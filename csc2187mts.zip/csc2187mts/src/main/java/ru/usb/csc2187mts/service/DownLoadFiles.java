package ru.usb.csc2187mts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;
import ru.usb.csc2187mts.config.Configure;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

@Service
public class DownLoadFiles {

    //Путь http
    String url;

    @Autowired
    Configure configure;

    @Autowired
    RestTemplate restTemplate;

    public File downLoadBigFile(String phone, String targetPath, String fileName) throws IOException {

        // File address to be downloaded
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getMtsLogin(), configure.getMtsPassword());
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));

        // create request
        HttpEntity request2 = new HttpEntity(headers);

        // create url
        url = configure.getMtsUrlFile() + "/" + phone + "/" + fileName;


        // Определяем тип получения заголовка запроса
        RequestCallback requestCallback = request -> request.getHeaders().putAll(headers);

        //Stream the response instead of loading it all into memory
        File file = restTemplate.execute(url, HttpMethod.GET, requestCallback, clientHttpResponse -> {
            Files.copy(clientHttpResponse.getBody(), Paths.get(targetPath + FileSystems.getDefault().getSeparator() + fileName), StandardCopyOption.REPLACE_EXISTING);
            File f = new File(targetPath + FileSystems.getDefault().getSeparator() + fileName);
            if (f.exists()) {
                return f;
            } else {
                return null;
            }
        });
        return file;
    }
}
