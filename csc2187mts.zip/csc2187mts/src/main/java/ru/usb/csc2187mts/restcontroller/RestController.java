package ru.usb.csc2187mts.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.csc2187mts.config.Configure;
import ru.usb.csc2187mts.model.CallRequest;
import ru.usb.csc2187mts.model.MtsNumber;
import ru.usb.csc2187mts.model.RecordCall;
import ru.usb.csc2187mts.service.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер прокси МТС.[Контроль качества.API]", tags = "Rest API")
public class RestController {

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @Autowired
    RestClient restClient;

    @Autowired
    ParseParameters parseParameters;

    @Autowired
    DownLoadFiles downLoadFiles;

    @Autowired
    DownLoadFile downLoadFile;

    @Autowired
    Configure configure;

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
//        downLoadFiles.downLoadBigFile("https://www.xeroxscanners.com/downloads/Manuals/XMSSD/PDF_Converter_Pro_Quick_Reference_Guide.RU.pdf",
//                "C:\\AppSever\\temp\\", "example.pdf");
//        // https://mrecord.mts.ru/api/v3/file/9133002742/70204998430
////        downLoadFile.downloadBigFileToPath("https://www.xeroxscanners.com/downloads/Manuals/XMSSD/PDF_Converter_Pro_Quick_Reference_Guide.RU.pdf", "C:\\AppSever\\temp\\test0702");
//
//        downLoadFiles.downLoadBigFile("https://mrecord.mts.ru/api/v3/file/9133002742/70204998430", "C:\\AppSever\\temp\\test0702", "f.f");
//        //                .downloadBigFileToPath("https://www.xeroxscanners.com/downloads/Manuals/XMSSD/PDF_Converter_Pro_Quick_Reference_Guide.RU.pdf","C:\\AppSever\\temp\\");
        if (configure.getVersion() == null) {
            return "version not defined";
        }
        return (configure.getVersion());
    }

    @GetMapping("/numbers")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос всех номеров",
            notes = "Получить параметры всех номеров\n" +
                    "Чтобы получить основные параметры необходимо отправить GET запрос по ссылке:\n" +
                    "../numbers\n" +
                    "GET https://mrecord.mts.ru/api/v3/numbers HTTP/1.1",
            response = MtsNumber.class)
    public List<MtsNumber> getAllNubres() {
        return restClient.getAllNumbers();
    }

    @GetMapping("/recs")
    @ApiOperation(value = "Запрос всех записей по номеру телефона, за период",
            notes = "Отчет по записям разговоров\n" +
                    "Чтобы получить отчет по записям разговоров необходимо отправить GET запрос по ссылке:\n" +
                    "../recs/{number}/{beginDateTime}/{endDateTime}",
            response = RecordCall.class)
    public List<RecordCall> getRecords(CallRequest callRequest) {
        logger.info(">>>>>>>>>>>>>>>>>>>/recs/{number}/{beginDateTime}/{endDateTime}>>>>>>>");
        logger.info(" Получен запрос (\"Отчет по записям разговоров) CallRequest :: " + callRequest.toString());
        if (parseParameters.parsePhone(callRequest.getPhoneNumber()) &&
                parseParameters.parseDate(callRequest.getBeginDateTime()) &&
                parseParameters.parseDate(callRequest.getEndDateTime())) {
            return restClient.getREcs(callRequest);
        } else {
            return null;
        }
    }

    @GetMapping("/file")
    @ApiOperation(value = "Запрос по конкретной записи разговора",
            notes = "Файл записи разговоров\n" +
                    " Путь к файлу. Пример::https://mrecord.mts.ru/api/v3/file/9133002742/70204998430"+
                    "phoneNumber - Номер телефона, пнимер :: 9133002742" +
                    "filename - имя файла для сохранения в хранилище, пример :: 70204998430")
    public ResponseEntity getFile(String phone, String fileName) {
        //        downLoadFiles.downLoadBigFile("https://www.xeroxscanners.com/downloads/Manuals/XMSSD/PDF_Converter_Pro_Quick_Reference_Guide.RU.pdf",
        logger.info(">>>>>>>>>>>>>>>>>>>/file>>>>>>>");
        logger.info("Запрос phone::" + phone);
        logger.info("Имя файла::" + fileName);
        try {
            File file = downLoadFiles.downLoadBigFile(phone, new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/", fileName);
            System.out.println("File => " + file.getAbsolutePath());
            System.out.println("File=" + file.getName());
            System.out.println("File size:=" + file.length());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(file));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    //.headers(headers)
                    .contentLength(file.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
