package ru.usb.csc2187mts.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.csc2187mts.config.Configure;
import ru.usb.csc2187mts.model.CallRequest;
import ru.usb.csc2187mts.model.MtsNumber;
import ru.usb.csc2187mts.model.RecordCall;

import java.util.Base64;
import java.util.List;
import java.util.function.Consumer;

@Service
public class RestClient {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(RestClient.class);

    /**
     * https://www.baeldung.com/how-to-use-resttemplate-with-basic-authentication-in-spring
     * https://attacomsian.com/blog/resttemplate-basic-authentication
     * <p>
     * SSL сертификаты
     * https://www.baeldung.com/httpclient-ssl
     * https://stackoverflow.com/questions/17619871/access-https-rest-service-using-spring-resttemplate
     * https://russianblogs.com/article/3849108855/
     * https://progi.pro/ispolzovanie-resttemplate-vmeste-s-ssl-7573749
     */
    public List<MtsNumber> getAllNumbers() {

        // create auth credentials
//        String authStr = "9152300514:R8g+6Zypeg";
        String authStr = configure.getMtsLogin() + ":" + configure.getMtsPassword();
        String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

/*
        // create headers -- тоже рабочий вариант
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Basic " + base64Creds);
*/

        // create headers
        HttpHeaders headers = new HttpHeaders();
//        headers.setBasicAuth("9152300514", "R8g+6Zypeg");
        headers.setBasicAuth(configure.getMtsLogin(), configure.getMtsPassword());

        // create request
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<MtsNumber[]> response = restTemplate.exchange(configure.getMtsNumbersURL(),
                HttpMethod.GET, request,
                MtsNumber[].class);
        //MtsNumber[] mtsNumbers= response.getBody();
        List<MtsNumber> mtsNumbers = List.of(response.getBody());

        mtsNumbers.forEach(new Consumer<MtsNumber>() {
            @Override
            public void accept(MtsNumber mtsNumber) {
                logger.info(" Получена запись :: " + mtsNumber.toString());
            }
        });

        return mtsNumbers;
    }

    /**
     * Отчет по записям разговоров
     * Чтобы получить отчет по записям разговоров необходимо отправить GET запрос по ссылке:
     * …/recs/{number}/{beginDateTime}/{endDateTime}
     *
     * @param callRequest
     * @return List<RecordCall>
     */
    public List<RecordCall> getREcs(CallRequest callRequest) {
        // create headers
        HttpHeaders headers = new HttpHeaders();
//        headers.setBasicAuth("9152300514", "R8g+6Zypeg");
        headers.setBasicAuth(configure.getMtsLogin(), configure.getMtsPassword());

        // create request
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<RecordCall[]> response = restTemplate.exchange(configure.getMtsRecsURL() + callRequest.getPhoneNumber() +
                        "/" + callRequest.getBeginDateTime() + "/" + callRequest.getEndDateTime(),
                HttpMethod.GET, request,
                RecordCall[].class);
        //MtsNumber[] mtsNumbers= response.getBody();
        List<RecordCall> recordCalls = List.of(response.getBody());
        logger.info("<<<<<<<<Ответ от MTS Response");
        recordCalls.forEach(new Consumer<RecordCall>() {
            @Override
            public void accept(RecordCall recordCall) {
                logger.info(" Получена запись :: " + recordCall.toString());
            }
        });
        return recordCalls;
    }

}
