package ru.usb.csc2187mts.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class ParseParameters {

    private String errorAnswer;

    /**
     * формат даты-времени 2022-02-01T00:00:00
     */
    LocalDate date;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ParseParameters.class);

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm:ss
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return false;
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public Date getDate(String sDate) {
        try {
            return simpleDateFormat.parse(sDate);
        } catch (Exception exception) {
            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return null;
        }
    }

    /**
     * Проверка, что phone не пустой
     *
     * @param phoneNumber
     * @return
     */
    public boolean parsePhone(String phoneNumber) {
        if (phoneNumber == null) {
            logger.error("Номер Phone " + phoneNumber + "не может быть пустым, (только цифры) :: 9133002742");
            return false;
        }
        if (phoneNumber.trim().isEmpty()) {
            logger.error("Номер Phone " + phoneNumber + "не может быть пустым, (только цифры) :: 9133002742");
            return false;
        } else {
            return true;
        }
    }

}
