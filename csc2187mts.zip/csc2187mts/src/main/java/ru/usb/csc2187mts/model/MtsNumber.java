package ru.usb.csc2187mts.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Get parameters of all numbers
 * Параметры всех номеров
 *
 параметр  описание
 Phone номер
 Days дни недели (битовое поле: 0000000 - ежедневно, 0000001 — понедельник, 0000010 — вторник и т.д.)
 TZ часовой пояс по Москве (от -1 до 9, 0 — Москва)
 RecordIncomingCalls запись входящих звонков (bool)
 RecordOutboundCalls запись исходящих звонков (bool)
 IncomingCallsChangeLocked возможность изменения записи входящих звонков
 OutboundCallsChangeLocked возможность изменения записи исходящих звонков
 BeginDateTime время начала записи (timespan, 00:00:00)
 EndDateTime время окончания записи (timespan, 00:00:00)
 */
@ApiModel(value = "MtsNumber", description = "Получить параметры всех номеров")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MtsNumber {
    @ApiModelProperty(value = "Phone : номер")
    @JsonProperty("Phone")
    public String phone;

    @ApiModelProperty(value = "Day : дни недели (битовое поле: 0000000 - ежедневно, 0000001 — понедельник, 0000010 — вторник и т.д.)")
    @JsonProperty("Day")
    public int day;

    @ApiModelProperty(value = "RecordIncomingCalls :  запись входящих звонков (bool)")
    @JsonProperty("RecordIncomingCalls")
    public boolean recordIncomingCalls;

    @ApiModelProperty(value = "RecordOutboundCalls : запись исходящих звонков (bool)")
    @JsonProperty("RecordOutboundCalls")
    public boolean recordOutboundCalls;

    @ApiModelProperty(value = "IncomingCallsChangeLocked : возможность изменения записи входящих звонков")
    @JsonProperty("IncomingCallsChangeLocked")
    public boolean incomingCallsChangeLocked;

    @ApiModelProperty(value = "OutboundCallsChangeLocked : возможность изменения записи исходящих звонков")
    @JsonProperty("OutboundCallsChangeLocked")
    public boolean outboundCallsChangeLocked;

    @ApiModelProperty(value = "BeginDateTime : время начала записи (timespan, 00:00:00)")
    @JsonProperty("BeginDateTime")
    public String beginDateTime;

    @ApiModelProperty(value = "EndDateTime : время окончания записи (timespan, 00:00:00)")
    @JsonProperty("EndDateTime")
    public String endDateTime;

    @ApiModelProperty(value = "TimeZone : часовой пояс по Москве (от -1 до 9, 0 — Москва)")
    @JsonProperty("TimeZone")
    public int timeZone;

    public MtsNumber() {
    }

    public MtsNumber(String phone, int day, boolean recordIncomingCalls, boolean recordOutboundCalls, boolean incomingCallsChangeLocked, boolean outboundCallsChangeLocked, String beginDateTime, String endDateTime, int timeZone) {
        this.phone = phone;
        this.day = day;
        this.recordIncomingCalls = recordIncomingCalls;
        this.recordOutboundCalls = recordOutboundCalls;
        this.incomingCallsChangeLocked = incomingCallsChangeLocked;
        this.outboundCallsChangeLocked = outboundCallsChangeLocked;
        this.beginDateTime = beginDateTime;
        this.endDateTime = endDateTime;
        this.timeZone = timeZone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public boolean isRecordIncomingCalls() {
        return recordIncomingCalls;
    }

    public void setRecordIncomingCalls(boolean recordIncomingCalls) {
        this.recordIncomingCalls = recordIncomingCalls;
    }

    public boolean isRecordOutboundCalls() {
        return recordOutboundCalls;
    }

    public void setRecordOutboundCalls(boolean recordOutboundCalls) {
        this.recordOutboundCalls = recordOutboundCalls;
    }

    public boolean isIncomingCallsChangeLocked() {
        return incomingCallsChangeLocked;
    }

    public void setIncomingCallsChangeLocked(boolean incomingCallsChangeLocked) {
        this.incomingCallsChangeLocked = incomingCallsChangeLocked;
    }

    public boolean isOutboundCallsChangeLocked() {
        return outboundCallsChangeLocked;
    }

    public void setOutboundCallsChangeLocked(boolean outboundCallsChangeLocked) {
        this.outboundCallsChangeLocked = outboundCallsChangeLocked;
    }

    public String getBeginDateTime() {
        return beginDateTime;
    }

    public void setBeginDateTime(String beginDateTime) {
        this.beginDateTime = beginDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public int getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(int timeZone) {
        this.timeZone = timeZone;
    }

    @Override
    public String toString() {
        return "MtsNumber{" +
                "phone='" + phone + '\'' +
                ", day=" + day +
                ", recordIncomingCalls=" + recordIncomingCalls +
                ", recordOutboundCalls=" + recordOutboundCalls +
                ", incomingCallsChangeLocked=" + incomingCallsChangeLocked +
                ", outboundCallsChangeLocked=" + outboundCallsChangeLocked +
                ", beginDateTime='" + beginDateTime + '\'' +
                ", endDateTime='" + endDateTime + '\'' +
                ", timeZone=" + timeZone +
                '}';
    }
}
