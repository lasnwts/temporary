package ru.usb.csc2187mts.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Отчет по записям разговоров
 * <p>
 * Чтобы получить отчет по записям разговоров необходимо отправить GET запрос по ссылке:
 * <p>
 * ../recs/{number}/{beginDateTime}/{endDateTime}
 * Входные параметры
 * параметр        описание
 * number          номер
 * beginDateTime    начало звонка после даты
 * endDateTime      начало звонка до даты
 * Получаем
 */
@ApiModel(value = "RecordCall", description = "Получить Отчет по записям разговоров")
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecordCall {

    @ApiModelProperty(value = "Id : идентификатор")
    @JsonProperty("Id")
    private String Id;

    @ApiModelProperty(value = "DateTime : дата начала звонка")
    @JsonProperty("DateTime")
    private String DateTime;

    @ApiModelProperty(value = "Phone : номер")
    @JsonProperty("Phone")
    private String Phone;

    @ApiModelProperty(value = "RecDuration : продолжительность записи")
    @JsonProperty("RecDuration")
    private String RecDuration;

    @ApiModelProperty(value = "CallType : тип звонка")
    @JsonProperty("CallType")
    private String CallType;

    @ApiModelProperty(value = "CallDuration : продолжительность звонка")
    @JsonProperty("CallDuration")
    private String CallDuration;


    @ApiModelProperty(value = "FileName : название файла для скачивания")
    @JsonProperty("FileName")
    private String FileName;


    @ApiModelProperty(value = "Service : видимо наименование сервиса")
    @JsonProperty("Service")
    private String Service;

    @ApiModelProperty(value = "Result : вероятно размер файла")
    @JsonProperty("Result")
    private String Result;

    public RecordCall() {
    }

    public RecordCall(String id, String dateTime, String phone, String recDuration, String callType, String callDuration, String fileName, String service, String result) {
        Id = id;
        DateTime = dateTime;
        Phone = phone;
        RecDuration = recDuration;
        CallType = callType;
        CallDuration = callDuration;
        FileName = fileName;
        Service = service;
        Result = result;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getRecDuration() {
        return RecDuration;
    }

    public void setRecDuration(String recDuration) {
        RecDuration = recDuration;
    }

    public String getCallType() {
        return CallType;
    }

    public void setCallType(String callType) {
        CallType = callType;
    }

    public String getCallDuration() {
        return CallDuration;
    }

    public void setCallDuration(String callDuration) {
        CallDuration = callDuration;
    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public String getService() {
        return Service;
    }

    public void setService(String service) {
        Service = service;
    }

    public String getResult() {
        return Result;
    }

    public void setResult(String result) {
        Result = result;
    }

    @Override
    public String toString() {
        return "RecordCall{" +
                "Id='" + Id + '\'' +
                ", DateTime='" + DateTime + '\'' +
                ", Phone='" + Phone + '\'' +
                ", RecDuration='" + RecDuration + '\'' +
                ", CallType='" + CallType + '\'' +
                ", CallDuration='" + CallDuration + '\'' +
                ", FileName='" + FileName + '\'' +
                ", Service='" + Service + '\'' +
                ", Result='" + Result + '\'' +
                '}';
    }
}
