package ru.usb.csc2187mts.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Alexander Lyapustin
 * Типизированный класс, запроса разговоров
 */
@ApiModel(value = "CallRequest", description = "Входящий Rest запрос : Запрос переговоров по номеру телефона в период")
public class CallRequest {

    /**
     * Номер телефона
     */
    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    private String PhoneNumber;

    /**
     * Дата начала периода в запросе
     */
    @ApiModelProperty(value = "beginDateTime :: Начало звонка после даты (дата начала периода в запросе) :: Пример 2022-02-06T23:59:59")
    private String BeginDateTime;

    /**
     * Дата конца периода в запросе
     */
    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) ::  Пример 2022-02-06T23:59:59")
    private String endDateTime;

    /**
     * Guid запроса для трассировки
     */
    @ApiModelProperty(value = "guid :: идентификатор запроса")
    private String guid;

    public CallRequest() {
    }

    public CallRequest(String phoneNumber, String beginDateTime, String endDateTime, String guid) {
        PhoneNumber = phoneNumber;
        BeginDateTime = beginDateTime;
        this.endDateTime = endDateTime;
        this.guid = guid;
    }


    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    public String getPhoneNumber() {
        return PhoneNumber;
    }

    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) ::  Пример 2022-02-06T23:59:59")

    public String getBeginDateTime() {
        return BeginDateTime;
    }

    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) ::  Пример 2022-02-06T23:59:59")
    public void setBeginDateTime(String beginDateTime) {
        BeginDateTime = beginDateTime;
    }

    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) ::  Пример 2022-02-06T23:59:59")
    public String getEndDateTime() {
        return endDateTime;
    }

    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) ::  Пример 2022-02-06T23:59:59")
    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    @ApiModelProperty(value = "guid :: идентификатор запроса")
    public String getGuid() {
        return guid;
    }

    @ApiModelProperty(value = "guid :: идентификатор запроса")
    public void setGuid(String guid) {
        this.guid = guid;
    }

    @Override
    public String toString() {
        return "CallRequest{" +
                ", PhoneNumber='" + PhoneNumber + '\'' +
                ", BeginDateTime='" + BeginDateTime + '\'' +
                ", endDateTime='" + endDateTime + '\'' +
                ", guid='" + guid + '\'' +
                '}';
    }
}
