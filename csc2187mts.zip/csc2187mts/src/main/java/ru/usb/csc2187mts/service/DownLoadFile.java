package ru.usb.csc2187mts.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.usb.csc2187mts.config.Configure;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Map;

@Service
public class DownLoadFile {

    Logger logger = LoggerFactory.getLogger(DownLoadFile.class);

    /**
     * Используйте собственный httpclient restTemplate
     */
    @Autowired
    private RestTemplate httpClientTemplate;

    @Autowired
    Configure configure;

    /**
     * Скачивайте большие файлы, используйте потоковую передачу для получения
     *
     * @param url
     * @param targetDir
     */
    public void downloadBigFileToPath(String url, String targetDir){
        downloadBigFileToPath(url,targetDir,null);
    }

    /**
     * Склейка параметров запроса на получение
     *
     * @param url
     * @param params
     * @return
     */
    private String addGetQueryParam(String url, Map<String, String> params) {
        UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(url);
        if (!CollectionUtils.isEmpty(params)) {
            for (Map.Entry<String, ?> varEntry : params.entrySet()) {
                uriComponentsBuilder.queryParam(varEntry.getKey(), varEntry.getValue());
            }
        }
        return uriComponentsBuilder.build().encode().toString();
    }

    /**
     * Создать или получить путь к папке загрузки
     *
     * @param url
     * @param targetDir
     * @return
     */
    public String getAndCreateDownloadDir(String url, String targetDir) throws IOException {
        String filename = url.substring(url.lastIndexOf("/") + 1);
        int i = 0;
        if ((i = url.indexOf("?")) != -1) {
            filename = filename.substring(0, i);
        }
        if (!Files.exists(Paths.get(targetDir))) {
            Files.createDirectories(Paths.get(targetDir));
        }
        return targetDir.endsWith("/") ? targetDir + filename : targetDir + "/" + filename;
    }

    /**
     * Скачивайте большие файлы, используйте потоковую передачу для получения
     *
     * @param url
     * @param targetDir
     */
    public void downloadBigFileToPath(String url, String targetDir, Map<String, String> params) {
        Instant now = Instant.now();
        String completeUrl = addGetQueryParam(url, params);
        try {
            String path = getAndCreateDownloadDir(url, targetDir);

            HttpHeaders headers = new HttpHeaders();
//        headers.setBasicAuth("9152300514", "R8g+6Zypeg");
            headers.setBasicAuth(configure.getMtsLogin(), configure.getMtsPassword());
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));

            // create request
            HttpEntity request2 = new HttpEntity(headers);

            // Определяем тип получения заголовка запроса

            RequestCallback requestCallback = request -> request.getHeaders().putAll(headers);

//            RequestCallback requestCallback =  request ->
//                    request.getHeaders()
//                    .setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));


//            requestCallback = request -> request.getHeaders().setBasicAuth(configure.getMtsLogin(),configure.getMtsPassword());

            // getForObject поместит все возвраты прямо в память и использует поток для замены этой операции
            ResponseExtractor<Void> responseExtractor = response -> {
                // Here I write the response to a file but do what you like
                Files.copy(response.getBody(), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);
                return null;
            };
            httpClientTemplate.execute(completeUrl, HttpMethod.GET, requestCallback, responseExtractor);
        } catch (IOException e) {
            logger.error("[Загрузить файл] не удалось записать:", e);
        }
        logger.info("[Загрузка файла] завершена, требует много времени: {}", ChronoUnit.MILLIS.between(now, Instant.now()));
    }

}
