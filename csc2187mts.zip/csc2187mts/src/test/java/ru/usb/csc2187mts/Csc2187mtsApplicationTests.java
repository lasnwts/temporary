package ru.usb.csc2187mts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csc2187mtsApplicationTests {

	@Test
	void contextLoads() {
	}

}
