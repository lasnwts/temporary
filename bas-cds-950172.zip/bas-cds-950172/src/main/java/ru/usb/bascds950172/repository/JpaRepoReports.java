package ru.usb.bascds950172.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.bascds950172.model.Report;

public interface JpaRepoReports extends JpaRepository<Report, Long> {
}
