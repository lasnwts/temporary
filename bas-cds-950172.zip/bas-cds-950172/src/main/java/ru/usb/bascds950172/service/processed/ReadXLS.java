package ru.usb.bascds950172.service.processed;

import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.model.Report;
import ru.usb.bascds950172.repository.JpaRepoReports;
import ru.usb.bascds950172.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Iterator;

@Component
public class ReadXLS {



    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepoReports jpaRepoReports;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadXLS.class);


    //С какой строки адо начать обработку =5
    private int beginNumStrProcessed = 4;

    /**
     * Получаем число
     */
    private BigDecimal getBD(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return new BigDecimal("0");
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return new BigDecimal("0");
                    }
                    return new BigDecimal(cell.getStringCellValue());
                } catch (Exception e) {
                    return new BigDecimal("0");
                }
            case NUMERIC:
                //tPlay.setTOT_LOAN_SUM_STR(String.format("%.2f", cell.getNumericCellValue()));
                return new BigDecimal(cell.getNumericCellValue());
            default:
                return new BigDecimal("0");
        }
    }


    /**
     * Получаем int
     */

    private int getInt(Cell cell){

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return 0;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return 0;
                    }
                    return  Integer.parseInt(cell.getStringCellValue());
                } catch (Exception e) {
                    return 0;
                }
            case NUMERIC:
                //tPlay.setTOT_LOAN_SUM_STR(String.format("%.2f", cell.getNumericCellValue()));
                return (int) cell.getNumericCellValue();
            default:
                return 0;
        }
    }


    /**
     * Возвращает строку
     */
    private String get2String(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return "";
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return "";
                    }
                    if (cell.getStringCellValue().length() > 2) {
                        return cell.getStringCellValue().trim().substring(0, 2);
                    } else {
                        return cell.getStringCellValue().trim();
                    }

                } catch (Exception e) {
                    return "";
                }
            default:
                return "";
        }
    }

    /**
     * Получение строки
     */
    private String getString(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return null;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return "";
                    }
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return null;
                }
            default:
                return null;
        }
    }


    /**
     * Получение даты
     */
    private Date getDate(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return null;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return null;
                    }
                    return null;
                } catch (Exception e) {
                    return null;
                }
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    return null;
                }
            default:
                return null;
        }
    }

    /**
     * Преобразование форматов дат
     */
    private LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        if (dateToConvert == null) {
            return null;
        } else {
            return dateToConvert.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
        }
    }


    /**
     * Основной код чтения и создания объектов из записей XLS файла
     */

    public boolean getFileXLS(File xlsFile) {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(xlsFile);
        } catch (FileNotFoundException e) {
            logger.error("ReadPHoliday:getFileXLS:FileNotFoundException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        }
        // Finds the workbook instance for XLSX file
//        XSSFWorkbook myWorkBook = null;
        Workbook myWorkBook = null;


        try {
//            myWorkBook = new XSSFWorkbook(fis);
            myWorkBook = WorkbookFactory.create(fis);

            /**
             * Основное тело
             */

            // Return first sheet from the XLSX workbook
            //
            Sheet mySheet = myWorkBook.getSheetAt(0);


            // Get iterator to all the rows in current sheet
            Iterator<Row> rowIterator = mySheet.iterator();

            // Traversing over each row of XLSX file
            while (rowIterator.hasNext()) {

                Row row = rowIterator.next();

                while (row.getRowNum()<beginNumStrProcessed){
                    row = rowIterator.next();
                }

                Report report = new Report();

                // For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                int currentCell = 0;

                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    if (currentCell == 0) {
                        report.setNn(getInt(cell));
                    }

                    if (currentCell == 1) {
                        report.setId(getString(cell));
                    }

                    if (currentCell == 2) {
                        report.setDateCreated(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 3) {
                        report.setNumberPolicy(getString(cell));
                    }

                    if (currentCell == 4) {
                        report.setStatus(getString(cell));
                    }

                    if (currentCell == 5) {
                        report.setNameProduct(getString(cell));
                    }

                    if (currentCell == 6) {
                        report.setPremia(getBD(cell));
                    }

                    if (currentCell == 7) {
                        report.setTd(getString(cell));
                    }

                    if (currentCell == 8) {
                        report.setDooo(getString(cell));
                    }

                    if (currentCell == 9) {
                        report.setFioSalesman(getString(cell));
                    }

                    if (currentCell == 10) {
                        report.setPositionSalesman(getString(cell));
                    }

                    if (currentCell == 11) {
                        report.setLoginSalesman(getString(cell));
                    }

                    if (currentCell == 12) {
                        report.setTnSalesman(getString(cell));
                    }

                    if (currentCell == 13) {
                        report.setFioInsurant(getString(cell));
                    }

                    if (currentCell == 14) {
                        report.setAddressInsurant(getString(cell));
                    }

                    if (currentCell == 15) {
                        report.setInnInsurant(getString(cell));
                    }

                    if (currentCell == 16) {
                        report.setTelInsurant(getString(cell));
                    }

                    if (currentCell == 17) {
                        report.setEmailInsurant(getString(cell));
                    }

                    if (currentCell == 18) {
                        report.setCatBankOperation(getString(cell));
                    }

                    if (currentCell == 19) {
                        //dateBithrdayInsurant
                        report.setDateBithrdayInsurant(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 20) {
                        //kodOPF
                        report.setKodOPF(getString(cell));
                    }

                    if (currentCell == 21) {
                        //priznakObject
                        report.setPriznakObject(getString(cell));
                    }

                    if (currentCell == 22) {
                        //dateConclDogovor
                        report.setDateConclDogovor(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 23) {
                        //kodTD
                        report.setKodTD(getString(cell));
                    }

                    if (currentCell == 24) {
                        //kodTP
                        report.setKodTP(getString(cell));
                    }

                    if (currentCell == 25) {
                        //fioInsured
                        report.setFioInsured(getString(cell));
                    }

                    if (currentCell == 26) {
                        //dateBithdayInsured
                        report.setDateBithdayInsured(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 27) {
                        //addressApartment
                        report.setAddressApartment(getString(cell));
                    }

                    if (currentCell == 28) {
                        //addressHome
                        report.setAddressHome(getString(cell));
                    }


                    if (currentCell == 29) {
                        //yearSalary int
                        report.setYearSalary(getInt(cell));
                    }

                    if (currentCell == 30) {
                        //genderInsurance
                        report.setGenderInsurance(getString(cell));
                    }

                    if (currentCell == 31) {
                        //sumInsured
                        report.setSumInsured(getBD(cell));
                    }

                    if (currentCell == 32) {
                        //programInsurance
                        report.setProgramInsurance(getString(cell));
                    }

                    if (currentCell == 33) {
                        //typeClient
                        report.setTypeClient(getString(cell));
                    }

                    if (currentCell == 34) {
                        //dateBegin
                        report.setDateBegin(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 35) {
                        //dateClose
                        report.setDateClose(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    if (currentCell == 36) {
                        //blok
                        report.setBlok(getString(cell));
                    }

                    if (currentCell == 37) {
                        //paymentMethod
                        report.setPaymentMethod(getString(cell));
                    }

                    if (currentCell == 38) {
                        //datePaymentDocument
                        report.setDatePaymentDocument(convertToLocalDateViaInstant(getDate(cell)));
                    }

                    currentCell = currentCell + 1;

                    if (currentCell > 38) {
                        break;
                    }

                }
                /**
                 * Служебные параметры дата и время вставки + имя файла
                 */
                report.setInputDate(new Date());
                report.setFILENAME(xlsFile.getName());
                report.setNumStr(row.getRowNum() + 1);
                jpaRepoReports.save(report);
                if (configure.isFileFlagCSV()) {
                    logger.info(report.toString());
                }
                report = null;
            }


        } catch (IOException e) {
            logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        } finally {
            try {
                myWorkBook.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
            try {
                fis.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
        }

        return true;
    }


}
