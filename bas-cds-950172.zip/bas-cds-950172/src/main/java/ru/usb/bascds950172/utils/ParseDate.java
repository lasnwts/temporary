package ru.usb.bascds950172.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class ParseDate {

    /**
     * формат даты-времени
     */
    LocalDate date;

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    Logger logger = LoggerFactory.getLogger(ParseDate.class);

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return false;
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate(String sDate) {
        try {
            return LocalDate.parse(sDate, formatter);
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return null;
        }
    }

    /**
     *  Конвертирование LocalDate в Date
     * @param dateToConvert - localDate
     * @return              - Date
     */
    public Date convertToDateViaInstant(LocalDate dateToConvert) {
        return java.util.Date.from(dateToConvert.atStartOfDay()
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }

}
