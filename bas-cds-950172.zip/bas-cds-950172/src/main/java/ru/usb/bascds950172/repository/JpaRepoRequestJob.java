package ru.usb.bascds950172.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.bascds950172.model.RequestJob;

import javax.persistence.QueryHint;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaRepoRequestJob extends JpaRepository<RequestJob, Long>{

    /**
     * Получаем записи из Job по статусам
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
    })
    @Query(value ="select uuid,dateend,datestart,dateinitial,datedownload,dateprocessed,filename,filesize,status,statuscode,typereport,typereports from reportsjob where statuscode=?1"
            , nativeQuery = true)
    List<RequestJob> getAllJobStatusCode(int code);

    /**
     * Получаем записи из Job по Дате поставке задачи Jobs
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10000"),
    })
    @Query(value ="select uuid,dateend,datestart,dateinitial,datedownload,dateprocessed,filename,filesize,status,statuscode,typereport,typereports from reportsjob " +
            "where dateinitial>=?1 and  dateinitial<=?2"
            , nativeQuery = true)
    List<RequestJob> getJobPeriodDateInitial(Date dateBeginPeriod, Date dateEndPeriod);

    /**
     * Получаем записи из Job по Дате ,dateend,datestart задачи Jobs
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10000"),
    })
    @Query(value ="select uuid,dateend,datestart,dateinitial,datedownload,dateprocessed,filename,filesize,status,statuscode,typereport,typereports from reportsjob " +
            "where datestart>=?1 and  dateend<=?2"
            , nativeQuery = true)
    List<RequestJob> getJobPeriod(LocalDate dateBeginPeriod, LocalDate dateEndPeriod);

}
