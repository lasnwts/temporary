package ru.usb.bascds950172.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.bascds950172.BasCds950172Application;
import ru.usb.bascds950172.model.RequestJob;
import ru.usb.bascds950172.repository.JpaRepoRequestJob;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class JobUtils {
    Logger logger = LoggerFactory.getLogger(JobUtils.class);

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    FileNameBuilder fileNameBuilder; //Получение начальной и конечной даты месяца

    @Autowired
    JpaRepoRequestJob jpaRepoRequestJob;

    LocalDate beginDatePeriod, endDatePeriod;
    int countJobs; //Количество задач поставленных в очередь

    /**
     * Создание объекта
     *
     * @param fileName
     * @param beginDate
     * @param endDate
     * @return
     */
    public RequestJob setJob(String fileName, LocalDate beginDate, LocalDate endDate) {
        RequestJob requestJob = new RequestJob();
        requestJob.setDatestart(beginDate);
        requestJob.setDateend(endDate);
        requestJob.setFilename(fileName);
        requestJob.setDateinitial(new Date());
        requestJob.setDateprocessed(new Date());
        requestJob.setStatuscode(0);
        requestJob.setStatus("requested");
        requestJob.setTypereport(0);
        requestJob.setTypereports("manual");
        return requestJob;
    }

    /**
     * Генератор запросов на скачивание
     *
     * @param beginDate - начальная дата периода
     * @param endDate   - конечная дата периода
     * @return - количество созданных заданий
     */
    public int JobsGenerator(LocalDate beginDate, LocalDate endDate) {

        logger.info("JobsGenerator:beginDate:{}", fileNameBuilder.getEndDayLocalDate(beginDate).format(formatter));
        logger.info("JobsGenerator:endDate:{}", fileNameBuilder.getEndDayLocalDate(endDate).format(formatter));

        if (fileNameBuilder.getEndDayLocalDate(beginDate).isEqual(fileNameBuilder.getEndDayLocalDate(endDate))) {
            LocalDate firstDay = fileNameBuilder.getStartLocalDate(beginDate);
            LocalDate lastDay = fileNameBuilder.getEndDayLocalDate(endDate);
            String fName = fileNameBuilder.getFileName(LocalDate.now(), fileNameBuilder.getStartLocalDate(beginDate).format(formatter)
                    , fileNameBuilder.getEndDayLocalDate(endDate).format(formatter));
            RequestJob requestJob = jpaRepoRequestJob.save(setJob(fName, firstDay, lastDay));
            logger.info("JobsGenerator:1:{}", requestJob.toString());
            return 1;
        } else {
            beginDatePeriod = fileNameBuilder.getStartLocalDate(beginDate);
            endDatePeriod = fileNameBuilder.getEndDayLocalDate(beginDate);
            logger.info("JobsGenerator:beginDate:{}", beginDatePeriod.format(formatter));
            logger.info("JobsGenerator:endDate:{}", endDatePeriod.format(formatter));
            countJobs = 0;
            /**
             * Пока дата первых дат меньше, чем последняя дата делаем вставку задания
             */
            while (endDatePeriod.isBefore(fileNameBuilder.getEndDayLocalDate(endDate.plusDays(2)))){
                countJobs = countJobs + 1; //Увеличиваем счетчик задач
                String fName = fileNameBuilder.getFileName(LocalDate.now(), fileNameBuilder.getStartLocalDate(beginDatePeriod).format(formatter)
                        , fileNameBuilder.getEndDayLocalDate(endDatePeriod).format(formatter));
                RequestJob requestJob = jpaRepoRequestJob.save(setJob(fName, beginDatePeriod, endDatePeriod));
                logger.info("JobsGenerator:{}:{}", countJobs, requestJob.toString());
                beginDatePeriod = fileNameBuilder.getStartLocalDate(beginDatePeriod.plusMonths(1));
                endDatePeriod = fileNameBuilder.getEndDayLocalDate(endDatePeriod.plusMonths(1));
            }

        }
        return countJobs;
    }
}
