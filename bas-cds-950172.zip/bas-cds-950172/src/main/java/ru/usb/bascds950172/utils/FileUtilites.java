package ru.usb.bascds950172.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.bascds950172.config.Configure;

import java.nio.file.FileSystems;
import java.nio.file.Paths;

@Component
public class FileUtilites {

    @Autowired
    Configure configure;

    /**
     * Получить полный путь к файлу
     * @return - полный путь
     */
    public String getTempPath(){
        return Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() +
                configure.getTmpPath() + FileSystems.getDefault().getSeparator()).toString();
    }
}
