package ru.usb.bascds950172.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.service.processed.BaseJobDownload;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class FileUtilites {

    private Logger logger = LoggerFactory.getLogger(FileUtilites.class);

    @Autowired
    Configure configure;

    /**
     * Получить полный путь к файлу
     *
     * @return - полный путь
     */
    public String getTempPath() {
        return Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() +
                configure.getTmpPath() + FileSystems.getDefault().getSeparator()).toString();
    }

    /**
     * Удаление файла, представленных подготовленными объектами Paths(nio)
     */
    public boolean delFiles(File file) {
        if (file.exists()) {
            try {
                file.delete();
            } catch (Exception e){
                logger.error("FileUtilites:delfile:file not delete::{}", file.getAbsolutePath());
                logger.error("error{}", e.getMessage());
                return false;
            }
        } else {
            logger.error("FileUtilites:delfile:file not exists::{}", file.getAbsolutePath());
            return false;
        }
        return true;
    }
}
