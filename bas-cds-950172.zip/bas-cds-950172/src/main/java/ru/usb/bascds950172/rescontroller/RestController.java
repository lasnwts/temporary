package ru.usb.bascds950172.rescontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.bascds950172.service.EmailServiceImpl;
import ru.usb.bascds950172.service.RestClient;
import ru.usb.bascds950172.utils.FileNameBuilder;
import ru.usb.bascds950172.utils.FileUtilites;
import ru.usb.bascds950172.utils.NewFileInputStream;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер по REST API работа с отчетом.", tags = "Rest API 1.(Reports) Работа с отчетами.")
public class RestController {
    private Logger logger = LoggerFactory.getLogger(RestController.class);
    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    RestClient restClient;

    @Autowired
    FileNameBuilder fileNameBuilder;
    @Autowired
    FileUtilites fileUtilites;

    @GetMapping("/file")
    @ApiOperation(value = "Запрос файла отчета за текущий месяц", notes = "Файл XLS")
    public ResponseEntity getFile() {
        logger.info(">>>>>>>>>>>>>>>>>>> Request(Запрос файла отчета за текущий месяц, без параметров) >>>>>>>");

        try {
            String fName = fileNameBuilder.getFileName(LocalDate.now());
            File f = restClient.downLoadBigFile(fileUtilites.getTempPath() + fName);
            logger.info("<<<<<<<<<<<<<<<<< Reposnse <<<<<<<<<<<<<<");
            logger.info("Prepared file:{}", f.getAbsolutePath());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(f));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fName + "\"")
                    //.headers(headers)
                    .contentLength(f.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (
                IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getRetailFile(String id, String fileName)   !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e.getMessage());

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка::" + e.getMessage());
        }

    }


}
