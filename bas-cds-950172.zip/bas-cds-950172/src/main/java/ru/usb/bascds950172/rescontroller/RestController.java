package ru.usb.bascds950172.rescontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.model.RequestJob;
import ru.usb.bascds950172.repository.JpaRepoRequestJob;
import ru.usb.bascds950172.service.EmailServiceImpl;
import ru.usb.bascds950172.service.RestClient;
import ru.usb.bascds950172.utils.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.time.LocalDate;
import java.util.List;
import java.util.function.Consumer;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер по REST API работа с отчетом.", tags = "Rest API 1.(Reports) Работа с отчетами.")
public class RestController {
    private Logger logger = LoggerFactory.getLogger(RestController.class);
    @Autowired
    EmailServiceImpl emailService;
    @Autowired
    RestClient restClient;
    @Autowired
    FileNameBuilder fileNameBuilder;
    @Autowired
    FileUtilites fileUtilites;
    @Autowired
    Configure configure;

    @Autowired
    ParseDate parseDate;

    @Autowired
    JobUtils jobUtils;

    @Autowired
    JpaRepoRequestJob jpaRepoRequestJob;

    String fName; //Имя файла для отчета
    LocalDate lBeginDate, lEndDate; //Начало и конец дат отчета в LocalDate

    @GetMapping("/file")
    @ApiOperation(value = "Запрос файла отчета за указанный месяц. Задаем начало периода и конец с указанием времени. Формат ниже.",
            notes = "Параметры (формат). Если не указывать параметры отчет формируется за текущий месяц\n"
                    + " Начало периода формат строки: 2022-05-01T00:00:00\n"
                    + " Конец периода формат строки: 2022-05-31T23:59:59")
    public ResponseEntity getFile(String beginDate, String endDate) {
        logger.info(">>>>>>>>>>>>>>>>>>> Request(Запрос файла отчета за месяц) >>>>>>>");


        if (beginDate == null || endDate == null) {
            beginDate = fileNameBuilder.getStartDayReport(LocalDate.now());
            endDate = fileNameBuilder.getLastDayReport(LocalDate.now());
            fName = fileNameBuilder.getFileNameCurrent(LocalDate.now());
        } else {
            fName = fileNameBuilder.getFileName(LocalDate.now(), beginDate, endDate);
        }


        logger.info("Request parameter:Begin Date={} ; End Date={}", beginDate, endDate);
        try {
            File f = restClient.downLoadBigFile(fileUtilites.getTempPath() + FileSystems.getDefault().getSeparator() + fName, beginDate, endDate);
            if (f == null) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("!!!!!!!!!  An error occurred while getFile() - f == null                       !!!!!!!");
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка::Файл не получен от сервера " + configure.getSoapUrl());
            }
            logger.info("<<<<<<<<<<<<<<<<< Reposnse <<<<<<<<<<<<<<");
            logger.info("Prepared file:{}", f.getAbsolutePath());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(f));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fName + "\"")
                    //.headers(headers)
                    .contentLength(f.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while getFile()                                   !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e.getMessage());

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка::" + e.getMessage());
        }

    }


    @GetMapping("/processfile")
    @ApiOperation(value = "Сделать Job загрузки ОДНОГО файла отчета в базу данных за указанный месяц. Задаем начало периода и конец с указанием времени. Формат ниже.",
            notes = "Параметры (формат). Если не указывать параметры отчет формируется за текущий месяц\n"
                    + " Начало периода формат строки: 2022-05-01\n"
                    + " Конец периода формат строки: 2022-05-31")
    public ResponseEntity processFile(String beginDate, String endDate) {

        if (beginDate == null || endDate == null) {
            lBeginDate = fileNameBuilder.getStartLocalDate(LocalDate.now());
            lEndDate = fileNameBuilder.getEndDayLocalDate(LocalDate.now());
            fName = fileNameBuilder.getFileNameCurrent(LocalDate.now());
        } else {
            if (parseDate.parseDate(beginDate) && parseDate.parseDate(endDate)) {
                lBeginDate = parseDate.getDate(beginDate);
                lEndDate = parseDate.getDate(endDate);
                fName = fileNameBuilder.getFileName(LocalDate.now(), beginDate, endDate);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты в формате YYYY-MM-DD!");
            }
        }
        jpaRepoRequestJob.save(jobUtils.setJob(fName, lBeginDate, lEndDate));
        return new ResponseEntity<>("Создан JOB для загрузки отчета", HttpStatus.OK);
    }


    @GetMapping("/generates")
    @ApiOperation(value = "Сделать Job загрузки ГРУППЫ файлов за указанный месяц. Задаем начало периода и конец с указанием времени. Формат ниже.",
            notes = "Параметры (формат)\n"
                    + " Начало периода формат строки: 2020-01-01\n"
                    + " Конец периода формат строки: 2022-05-31")
    public ResponseEntity generateJobs(String beginDate, String endDate) {

        if (beginDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }
        if (endDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(endDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(beginDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }

        /**
         * Получаем начало периода дат и конец
         */
        lBeginDate = parseDate.getDate(beginDate);
        lEndDate = parseDate.getDate(endDate);
        logger.info("generateJobs:jobUtils.setJob(BeginDate:{}, EndDate:{})", beginDate, endDate);
        int counts = jobUtils.JobsGenerator(lBeginDate, lEndDate);


        //       jpaRepoRequestJob.save(jobUtils.setJob(fName, lBeginDate, lEndDate));
        return new ResponseEntity<>("Создан JOB для загрузки отчета в количестве:" + counts, HttpStatus.OK);
    }


    @GetMapping("/reportdateinit")
    @ApiOperation(value = "Получить список задач на загрузку по дате создания. Задаем начало периода и конец с указанием времени. Формат ниже.",
            notes = "Параметры (формат)\n"
                    + " Начало периода формат строки: 2020-01-01\n"
                    + " Конец периода формат строки: 2022-05-31")
    public ResponseEntity getReportDateInitial(String beginDate, String endDate) {
        if (beginDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }
        if (endDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(endDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(beginDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }

        /**
         * Получаем начало периода дат и конец
         */
        lBeginDate = parseDate.getDate(beginDate);
        lEndDate = parseDate.getDate(endDate);
        logger.info("generateJobs:jobUtils.setJob(BeginDate:{}, EndDate:{})", beginDate, endDate);

        List<RequestJob> requestJobList = jpaRepoRequestJob.getJobPeriodDateInitial(parseDate.convertToDateViaInstant(lBeginDate),
                parseDate.convertToDateViaInstant(lEndDate));

        requestJobList.forEach(new Consumer<RequestJob>() {
            @Override
            public void accept(RequestJob requestJob) {
                logger.info("getReportDateInitial:JOB:{}", requestJob.toString());
            }
        });

        return new ResponseEntity<>(requestJobList, HttpStatus.OK);
    }

    @GetMapping("/reportperiod")
    @ApiOperation(value = "Получить список задач на загрузку по дате начала периода и конца. Задаем начало периода и конец с указанием времени. Формат ниже.",
            notes = "Параметры (формат)\n"
                    + " Начало периода формат строки: 2020-01-01\n"
                    + " Конец периода формат строки: 2022-05-31")
    public ResponseEntity getReportDatePeriod(String beginDate, String endDate) {
        if (beginDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }
        if (endDate == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(endDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Конец периода в формате YYYY-MM-DD!");
        }

        if (!parseDate.parseDate(beginDate)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты Начало периода в формате YYYY-MM-DD!");
        }

        /**
         * Получаем начало периода дат и конец
         */
        lBeginDate = parseDate.getDate(beginDate);
        lEndDate = parseDate.getDate(endDate);
        logger.info("generateJobs:jobUtils.setJob(BeginDate:{}, EndDate:{})", beginDate, endDate);

        List<RequestJob> requestJobList = jpaRepoRequestJob.getJobPeriod(lBeginDate, lEndDate);

        requestJobList.forEach(new Consumer<RequestJob>() {
            @Override
            public void accept(RequestJob requestJob) {
                logger.info("getReportDatePeriod:JOB:{}", requestJob.toString());
            }
        });

        return new ResponseEntity<>(requestJobList, HttpStatus.OK);
    }


    @GetMapping("/reportcode")
    @ApiOperation(value = "Получить список задач на загрузку по коду статуса.",
            notes = "Статусы (формат)\n" +
                    " Запрошен (requested) 0\n" +
                    " В процессе загрузки (download) 1\n" +
                    " Файл закачан с сервера (downloaded) 2\n" +
                    " Ошибка скачивания файла (failed download) 3\n" +
                    " В обработке, загрузка в базу идет (process) 4\n" +
                    " Ошибка обработки загрузки в базу (failed process) 5\n" +
                    " Загрузка в базу завершена (success) 6\n" +
                    " Ошибка обработки(failed) 7\n" +
                    " Обработка завершена (completed) 8")
    public ResponseEntity getReportCode(int code) {

        if (code > 8 || code < 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания кода статуса. Код должен быть в диапазоне 0 - 8!");
        }


        List<RequestJob> requestJobList = jpaRepoRequestJob.getAllJobStatusCode(code);

        requestJobList.forEach(new Consumer<RequestJob>() {
            @Override
            public void accept(RequestJob requestJob) {
                logger.info("getReportCode:JOB:{}", requestJob.toString());
            }
        });

        return new ResponseEntity<>(requestJobList, HttpStatus.OK);
    }


}
