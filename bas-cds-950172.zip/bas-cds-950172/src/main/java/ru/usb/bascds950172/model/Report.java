package ru.usb.bascds950172.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

/**
 * Таблица хранения отчетов
 */
@Entity
@Table(name = "reports")
public class Report {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long uuid;
    private int nn; //№ п/п 0
    private String id; //guid 1

    private LocalDate dateCreated; //Дата создания 2
    private String numberPolicy; //Номер полиса 3
    private String status; //Статус 4
    private String nameProduct; //Название продукта 5
    @Column(nullable = true, precision = 18, scale = 2)
    private BigDecimal premia; //Премия 6
    private String td; //ТД 7
    private String dooo; // ДО/ОО 8
    private String fioSalesman; //ФИО Продавца 9
    private String positionSalesman; //Должность продавца  10
    private String loginSalesman; //Логин продавца 11
    private String tnSalesman; //ТН продавца 12
    private String fioInsurant; //ФИО (имя/название) страхователя 13
    private String addressInsurant; //Адрес страхователя 14
    private String innInsurant; //ИНН страхователя 15
    private String telInsurant; //Номер телефона страхователя 16
    private String emailInsurant; //Эл. почта страхователя 17
    private String catBankOperation; //Кат. банк. операции 18
    private LocalDate dateBithrdayInsurant; //Дата рождения страхователя 19
    private String kodOPF; //Код ОПФ (1с) 20
    private String priznakObject; //Признак объекта 21
    private LocalDate dateConclDogovor; //Дата заключения договора 22
    private String kodTD; //Код ТД 23
    private String kodTP; //Код ТП 24
    private String fioInsured; // ФИО Застрахованного 25
    private LocalDate dateBithdayInsured; // Дата рождения застрахованного 26
    private String addressApartment; //Адрес квартиры 27
    private String addressHome; // Адрес дома 28
    private int yearSalary; // Год продажи 29
    private String genderInsurance; // Пол страхователя 30
    @Column(nullable = true, precision = 18, scale = 2)
    private BigDecimal sumInsured; //Страховая сумма 31
    private String programInsurance; //Программа страхования 32
    private String typeClient; //Тип клиента 33
    private LocalDate dateBegin; //Дата начала 34
    private LocalDate dateClose; //Дата окончания 35
    private String blok; //Блок 36
    private String paymentMethod; //Способ оплаты 37
    private LocalDate datePaymentDocument; //Дата платежного документа 38

    /**
     * Поля для контроля вставки
     */
    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int numStr;

    public Report() {
    }

    public Report(long uuid, int nn, String id, LocalDate dateCreated, String numberPolicy,
                  String status, String nameProduct, BigDecimal premia, String td, String dooo,
                  String fioSalesman, String positionSalesman, String loginSalesman, String tnSalesman,
                  String fioInsurant, String addressInsurant, String innInsurant, String telInsurant,
                  String emailInsurant, String catBankOperation, LocalDate dateBithrdayInsurant, String kodOPF,
                  String priznakObject, LocalDate dateConclDogovor, String kodTD, String kodTP, String fioInsured,
                  LocalDate dateBithdayInsured, String addressApartment, String addressHome, int yearSalary,
                  String genderInsurance, BigDecimal sumInsured, String programInsurance, String typeClient,
                  LocalDate dateBegin, LocalDate dateClose, String blok, String paymentMethod, LocalDate datePaymentDocument,
                  Date inputDate, String FILENAME) {
        this.uuid = uuid;
        this.nn = nn;
        this.id = id;
        this.dateCreated = dateCreated;
        this.numberPolicy = numberPolicy;
        this.status = status;
        this.nameProduct = nameProduct;
        this.premia = premia;
        this.td = td;
        this.dooo = dooo;
        this.fioSalesman = fioSalesman;
        this.positionSalesman = positionSalesman;
        this.loginSalesman = loginSalesman;
        this.tnSalesman = tnSalesman;
        this.fioInsurant = fioInsurant;
        this.addressInsurant = addressInsurant;
        this.innInsurant = innInsurant;
        this.telInsurant = telInsurant;
        this.emailInsurant = emailInsurant;
        this.catBankOperation = catBankOperation;
        this.dateBithrdayInsurant = dateBithrdayInsurant;
        this.kodOPF = kodOPF;
        this.priznakObject = priznakObject;
        this.dateConclDogovor = dateConclDogovor;
        this.kodTD = kodTD;
        this.kodTP = kodTP;
        this.fioInsured = fioInsured;
        this.dateBithdayInsured = dateBithdayInsured;
        this.addressApartment = addressApartment;
        this.addressHome = addressHome;
        this.yearSalary = yearSalary;
        this.genderInsurance = genderInsurance;
        this.sumInsured = sumInsured;
        this.programInsurance = programInsurance;
        this.typeClient = typeClient;
        this.dateBegin = dateBegin;
        this.dateClose = dateClose;
        this.blok = blok;
        this.paymentMethod = paymentMethod;
        this.datePaymentDocument = datePaymentDocument;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return numStr;
    }

    public void setNumStr(int numStr) {
        this.numStr = numStr;
    }

    public long getUuid() {
        return uuid;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public int getNn() {
        return nn;
    }

    public void setNn(int nn) {
        this.nn = nn;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getNumberPolicy() {
        return numberPolicy;
    }

    public void setNumberPolicy(String numberPolicy) {
        this.numberPolicy = numberPolicy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public BigDecimal getPremia() {
        return premia;
    }

    public void setPremia(BigDecimal premia) {
        this.premia = premia;
    }

    public String getTd() {
        return td;
    }

    public void setTd(String td) {
        this.td = td;
    }

    public String getDooo() {
        return dooo;
    }

    public void setDooo(String dooo) {
        this.dooo = dooo;
    }

    public String getFioSalesman() {
        return fioSalesman;
    }

    public void setFioSalesman(String fioSalesman) {
        this.fioSalesman = fioSalesman;
    }

    public String getPositionSalesman() {
        return positionSalesman;
    }

    public void setPositionSalesman(String positionSalesman) {
        this.positionSalesman = positionSalesman;
    }

    public String getLoginSalesman() {
        return loginSalesman;
    }

    public void setLoginSalesman(String loginSalesman) {
        this.loginSalesman = loginSalesman;
    }

    public String getTnSalesman() {
        return tnSalesman;
    }

    public void setTnSalesman(String tnSalesman) {
        this.tnSalesman = tnSalesman;
    }

    public String getFioInsurant() {
        return fioInsurant;
    }

    public void setFioInsurant(String fioInsurant) {
        this.fioInsurant = fioInsurant;
    }

    public String getAddressInsurant() {
        return addressInsurant;
    }

    public void setAddressInsurant(String addressInsurant) {
        this.addressInsurant = addressInsurant;
    }

    public String getInnInsurant() {
        return innInsurant;
    }

    public void setInnInsurant(String innInsurant) {
        this.innInsurant = innInsurant;
    }

    public String getTelInsurant() {
        return telInsurant;
    }

    public void setTelInsurant(String telInsurant) {
        this.telInsurant = telInsurant;
    }

    public String getEmailInsurant() {
        return emailInsurant;
    }

    public void setEmailInsurant(String emailInsurant) {
        this.emailInsurant = emailInsurant;
    }

    public String getCatBankOperation() {
        return catBankOperation;
    }

    public void setCatBankOperation(String catBankOperation) {
        this.catBankOperation = catBankOperation;
    }

    public LocalDate getDateBithrdayInsurant() {
        return dateBithrdayInsurant;
    }

    public void setDateBithrdayInsurant(LocalDate dateBithrdayInsurant) {
        this.dateBithrdayInsurant = dateBithrdayInsurant;
    }

    public String getKodOPF() {
        return kodOPF;
    }

    public void setKodOPF(String kodOPF) {
        this.kodOPF = kodOPF;
    }

    public String getPriznakObject() {
        return priznakObject;
    }

    public void setPriznakObject(String priznakObject) {
        this.priznakObject = priznakObject;
    }

    public LocalDate getDateConclDogovor() {
        return dateConclDogovor;
    }

    public void setDateConclDogovor(LocalDate dateConclDogovor) {
        this.dateConclDogovor = dateConclDogovor;
    }

    public String getKodTD() {
        return kodTD;
    }

    public void setKodTD(String kodTD) {
        this.kodTD = kodTD;
    }

    public String getKodTP() {
        return kodTP;
    }

    public void setKodTP(String kodTP) {
        this.kodTP = kodTP;
    }

    public String getFioInsured() {
        return fioInsured;
    }

    public void setFioInsured(String fioInsured) {
        this.fioInsured = fioInsured;
    }

    public LocalDate getDateBithdayInsured() {
        return dateBithdayInsured;
    }

    public void setDateBithdayInsured(LocalDate dateBithdayInsured) {
        this.dateBithdayInsured = dateBithdayInsured;
    }

    public String getAddressApartment() {
        return addressApartment;
    }

    public void setAddressApartment(String addressApartment) {
        this.addressApartment = addressApartment;
    }

    public String getAddressHome() {
        return addressHome;
    }

    public void setAddressHome(String addressHome) {
        this.addressHome = addressHome;
    }

    public int getYearSalary() {
        return yearSalary;
    }

    public void setYearSalary(int yearSalary) {
        this.yearSalary = yearSalary;
    }

    public String getGenderInsurance() {
        return genderInsurance;
    }

    public void setGenderInsurance(String genderInsurance) {
        this.genderInsurance = genderInsurance;
    }

    public BigDecimal getSumInsured() {
        return sumInsured;
    }

    public void setSumInsured(BigDecimal sumInsured) {
        this.sumInsured = sumInsured;
    }

    public String getProgramInsurance() {
        return programInsurance;
    }

    public void setProgramInsurance(String programInsurance) {
        this.programInsurance = programInsurance;
    }

    public String getTypeClient() {
        return typeClient;
    }

    public void setTypeClient(String typeClient) {
        this.typeClient = typeClient;
    }

    public LocalDate getDateBegin() {
        return dateBegin;
    }

    public void setDateBegin(LocalDate dateBegin) {
        this.dateBegin = dateBegin;
    }

    public LocalDate getDateClose() {
        return dateClose;
    }

    public void setDateClose(LocalDate dateClose) {
        this.dateClose = dateClose;
    }

    public String getBlok() {
        return blok;
    }

    public void setBlok(String blok) {
        this.blok = blok;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public LocalDate getDatePaymentDocument() {
        return datePaymentDocument;
    }

    public void setDatePaymentDocument(LocalDate datePaymentDocument) {
        this.datePaymentDocument = datePaymentDocument;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "Report{" +
                "uuid=" + uuid +
                ", nn=" + nn +
                ", id='" + id + '\'' +
                ", dateCreated=" + dateCreated +
                ", numberPolicy='" + numberPolicy + '\'' +
                ", status='" + status + '\'' +
                ", nameProduct='" + nameProduct + '\'' +
                ", premia=" + premia +
                ", td='" + td + '\'' +
                ", dooo='" + dooo + '\'' +
                ", fioSalesman='" + fioSalesman + '\'' +
                ", positionSalesman='" + positionSalesman + '\'' +
                ", loginSalesman='" + loginSalesman + '\'' +
                ", tnSalesman='" + tnSalesman + '\'' +
                ", fioInsurant='" + fioInsurant + '\'' +
                ", addressInsurant='" + addressInsurant + '\'' +
                ", innInsurant='" + innInsurant + '\'' +
                ", telInsurant='" + telInsurant + '\'' +
                ", emailInsurant='" + emailInsurant + '\'' +
                ", catBankOperation='" + catBankOperation + '\'' +
                ", dateBithrdayInsurant=" + dateBithrdayInsurant +
                ", kodOPF='" + kodOPF + '\'' +
                ", priznakObject='" + priznakObject + '\'' +
                ", dateConclDogovor=" + dateConclDogovor +
                ", kodTD='" + kodTD + '\'' +
                ", kodTP='" + kodTP + '\'' +
                ", fioInsured='" + fioInsured + '\'' +
                ", dateBithdayInsured=" + dateBithdayInsured +
                ", addressApartment='" + addressApartment + '\'' +
                ", addressHome='" + addressHome + '\'' +
                ", yearSalary=" + yearSalary +
                ", genderInsurance='" + genderInsurance + '\'' +
                ", sumInsured=" + sumInsured +
                ", programInsurance='" + programInsurance + '\'' +
                ", typeClient='" + typeClient + '\'' +
                ", dateBegin=" + dateBegin +
                ", dateClose=" + dateClose +
                ", blok='" + blok + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", datePaymentDocument=" + datePaymentDocument +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
