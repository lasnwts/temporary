package ru.usb.bascds950172;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.service.RestClient;
import ru.usb.bascds950172.service.processed.BaseJobDownload;
import ru.usb.bascds950172.service.processed.ReadXLS;
import ru.usb.bascds950172.utils.FileNameBuilder;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;

@EnableSwagger2
@SpringBootApplication
public class BasCds950172Application implements CommandLineRunner {

    @Autowired
    Configure configure;

    @Autowired
    ReadXLS readXLS;

    @Autowired
    RestClient restClient;

    @Autowired
    FileNameBuilder fileNameBuilder;

    @Autowired
    BaseJobDownload baseJobDownload;

    Logger logger = LoggerFactory.getLogger(BasCds950172Application.class);

    public static void main(String[] args) {
        SpringApplication.run(BasCds950172Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        // Показываем версию
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Version of service:" + configure.getAppVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getTmpPath());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            System.out.println("Directory " + path.toString() + " = created");
        } else {
            System.out.println("Directory" + path.toString() + " = already exists");
        }

        //Очистка каталога при старте
        try {
            Files.walk(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                            FileSystems.getDefault().getSeparator() + configure.getTmpPath()))
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .forEach(File::delete);
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload folder!");
        }

        /**
         * Тест загрузки объекта
         */
//		File f = new File("C:\\AppServer\\Project\\Banking\\bas\\data\\files\\test.xls ");
//		logger.info("file={}",f.getAbsolutePath() );
//		readXLS.getFileXLS(f);

        /**
         * Тест получения файла
         */
        //restClient.downLoadBigFile("","");

        /**
         * Другие тесты
         */
//        logger.info(fileNameBuilder.getFileNameCurrent(LocalDate.now()));


    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service bas-cds-950172", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Задача №950172 .Rest Api Title 19/01/2023")
                .description("Api Definition by @alexander")
                .version(configure.getAppVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();


    }

    /*
     * Sheduler 1. Первый шедулер
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {
        //Запуск процедура автоматической проверки наличия файла и обработки его

//        baseJobDownload.processJob(0);
    }

}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}

