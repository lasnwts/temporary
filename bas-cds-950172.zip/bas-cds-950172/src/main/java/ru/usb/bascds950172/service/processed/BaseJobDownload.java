package ru.usb.bascds950172.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.model.RequestJob;
import ru.usb.bascds950172.repository.JpaRepoRequestJob;
import ru.usb.bascds950172.service.RestClient;
import ru.usb.bascds950172.utils.FileNameBuilder;
import ru.usb.bascds950172.utils.FileUtilites;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;

/**
 * Основной сервис загрузки
 */
@Service
public class BaseJobDownload {

    private Logger logger = LoggerFactory.getLogger(BaseJobDownload.class);

    @Autowired
    Configure configure;

    @Autowired
    RestClient restClient;

    @Autowired
    JpaRepoRequestJob jpaRepoRequestJob;

    @Autowired
    FileUtilites fileUtilites;

    @Autowired
    FileNameBuilder fileNameBuilder;

    @Autowired
    ReadXLS readXLS;

    /**
     * Скачивание и обработка файлов. По таблице Job
     */
    public void processJob(int code) {

        List<RequestJob> requestJobList = jpaRepoRequestJob.getAllJobStatusCode(code);
        requestJobList.forEach(new Consumer<RequestJob>() {
            @Override
            public void accept(RequestJob requestJob) {
                logger.info("JOB:" + requestJob.toString());
            }
        });
        //Проверяем есть ли задача к загрузке
        if (!requestJobList.isEmpty() && requestJobList.size() > 0) {

            requestJobList.forEach(new Consumer<RequestJob>() {
                @Override
                public void accept(RequestJob requestJob) {

                    if (requestJob.getFilename() == null || requestJob.getFilename().isEmpty()) {
                        logger.error("processJob:requestJobList.forEach:File name=empty!:{}", requestJob.toString());
                    } else {

                        /**
                         * Проставляем статус загрузки файла с сервера
                         */
                        requestJob.setStatus("download");
                        requestJob.setStatuscode(1);
                        requestJob.setDatedownload(new Date());
                        requestJob.setDateprocessed(new Date());
                        logger.info("JOB download:" + requestJob.toString());
                        jpaRepoRequestJob.save(requestJob);
                        File f = downloadFile(requestJob);
                        if (f == null) {
                            /**
                             * Если файл не закачан - нечего загружать шаг пропускаем....
                             */
                            requestJob.setStatus("fail download");
                            requestJob.setStatuscode(3);
                            requestJob.setDateprocessed(new Date());
                            logger.info("JOB download:" + requestJob.toString());
                            jpaRepoRequestJob.save(requestJob);
                        } else {
                            /**
                             * Если файл закачали, продолжаем
                             */
                            requestJob.setStatus("downloaded");
                            requestJob.setStatuscode(2);
                            requestJob.setDateprocessed(new Date());
                            requestJob.setFilesize(f.length());
                            logger.info("JOB download:" + requestJob.toString());
                            jpaRepoRequestJob.save(requestJob);

                            /**
                             * Проставляем статус загрузки файла в базу данных
                             */
                            requestJob.setStatus("process");
                            requestJob.setStatuscode(4);
                            requestJob.setDateprocessed(new Date());
                            logger.info("JOB process:" + requestJob.toString());
                            jpaRepoRequestJob.save(requestJob);
                            if (readXLS.getFileXLS(f)) {
                                /**
                                 * Проставляем статус загрузки файла в базу данных
                                 */
                                requestJob.setStatus("success");
                                requestJob.setStatuscode(6);
                                requestJob.setDateprocessed(new Date());
                                logger.info("JOB success:" + requestJob.toString());
                                jpaRepoRequestJob.save(requestJob);
                            } else {
                                /**
                                 * Проставляем статус загрузки файла в базу данных
                                 */
                                requestJob.setStatus("failed process");
                                requestJob.setStatuscode(5);
                                requestJob.setDateprocessed(new Date());
                                logger.info("JOB failed:" + requestJob.toString());
                                jpaRepoRequestJob.save(requestJob);
                            }

                            /**
                             * Удаляем файл после обработки
                             */
                            if (fileUtilites.delFiles(f)) {
                                /**
                                 * Проставляем статус загрузки файла в базу данных
                                 */
                                requestJob.setStatus("completed");
                                requestJob.setStatuscode(8);
                                requestJob.setDateprocessed(new Date());
                                logger.info("JOB completed:" + requestJob.toString());
                                jpaRepoRequestJob.save(requestJob);
                            } else {
                                /**
                                 * Проставляем статус загрузки файла в базу данных
                                 */
                                requestJob.setStatus("failed");
                                requestJob.setStatuscode(7);
                                requestJob.setDateprocessed(new Date());
                                logger.info("JOB failed:" + requestJob.toString());
                                jpaRepoRequestJob.save(requestJob);
                            }
                        }
                    }
                }
            });
        }
    }


    /**
     * Загрузка файла
     */
    private File downloadFile(RequestJob requestJob) {

        File f = null;

        logger.info("download File:requested: {} : dateStart {} : dateEnd {}", fileUtilites.getTempPath() + requestJob.getFilename(),
                fileNameBuilder.getStartDayReport(requestJob.getDatestart()), fileNameBuilder.getLastDayReport(requestJob.getDateend()));

        try {
            f = restClient.downLoadBigFile(fileUtilites.getTempPath() + FileSystems.getDefault().getSeparator() + requestJob.getFilename(),
                    fileNameBuilder.getStartDayReport(requestJob.getDatestart()), fileNameBuilder.getLastDayReport(requestJob.getDateend()));
        } catch (FileNotFoundException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while downloadFile()                              !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error(e.getMessage());
            return null;
        }
        if (f == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!  An error occurred while downloadFile - f == null                    !!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        logger.info("Successful download file:{}", f.getAbsolutePath());
        logger.info("Successful download filesize:{}", f.length());
        return f;
    }
}
