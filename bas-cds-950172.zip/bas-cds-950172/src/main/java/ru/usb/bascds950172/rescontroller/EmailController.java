package ru.usb.bascds950172.rescontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.bascds950172.service.EmailServiceImpl;

@RestController
@RequestMapping("/api/v1/email")
@Api(value = "user", description = "Контроллер по REST API для проверки Email.", tags = "Rest API 2.(Email) для проверки почты.")
public class EmailController {

    private Logger LOG = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    EmailServiceImpl emailService;

    @GetMapping(value = "/simple-email/{user-email}")
    @ApiOperation(value = "Проверка сервиса отправки почты",
            notes = "введите электронный адрес для отправки почты на проверку",
            response = String.class)
    public @ResponseBody
    ResponseEntity<String> sendSimpleEmail(
            @ApiParam(value = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]",
                    required = true, defaultValue = "user@spb.uralsib.ru")
            @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmail(email, "Test email message from ZSK Service", "This is letter from ZSK service");
        } catch (MailException mailException) {
            LOG.error("Error while sending out email..{}", mailException.getStackTrace());
            LOG.error("Error while sending out email..{}", mailException.fillInStackTrace());
            return new ResponseEntity<>("Unable to send email", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

}
