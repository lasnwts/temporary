package ru.usb.bascds950172.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.bascds950172.config.Configure;
import ru.usb.bascds950172.config.Constant;
import ru.usb.bascds950172.utils.FileNameBuilder;
import ru.usb.bascds950172.utils.FileUtilites;

import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Base64;

@Service
public class RestClient {

    @Autowired
    Configure configure;

    @Autowired
    Constant constant;

    @Autowired
    FileUtilites fileUtilites;

    @Autowired
    FileNameBuilder fileNameBuilder;

    String byteArray;
    String xmlData;
    byte[] decodedBytes;
    File f;
    String jornalResponse;
    RestTemplate restTemplate = new RestTemplate();
    Logger logger = LoggerFactory.getLogger(RestClient.class);

    /**
     * Получаем файл вложений
     *
     * @return - file on disk
     * @throws FileNotFoundException - не найден файл
     */
    public File downLoadBigFile(String fileName, String beginDate, String endDate) throws FileNotFoundException {

        // File address to be downloaded
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf("text/xml"));
        headers.set("SOAPAction", configure.getSoapAction());
        HttpEntity<String> request =
                new HttpEntity<String>(getRequest(constant.getREQUESTSTR(), beginDate, endDate), headers);
        logger.info("Request::{}", request.toString());
        xmlData = "";
        byteArray = "";

        /**
         * Получаем файл (soap запрос)
         */

        try {
            xmlData = restTemplate.postForObject(configure.getSoapUrl(), request, String.class);
        } catch (Exception exception) {
            logger.error("Error::{}", exception);
            return null;
        }

        if (!xmlData.contains("ResultCode>200<")) {
            logger.error("Error:Произошла ошибка в при выполнении запроса:{}", request.toString());
            logger.error("Error:получено:{}", xmlData);
            return null;
        }

        /**
         * Обработка файла
         */
        try {
            if (xmlData.contains("<int:FileByte>")) {
                byteArray = xmlData.substring(xmlData.indexOf("<int:FileByte>") + 14, xmlData.indexOf("</int:FileByte>"));
                jornalResponse = xmlData.substring(0, xmlData.indexOf("<int:FileByte>") + 50);
                jornalResponse = jornalResponse + ".......";
                jornalResponse = jornalResponse + xmlData.substring(xmlData.indexOf("</int:FileByte>"), xmlData.length());
            } else {
                byteArray = xmlData.substring(xmlData.indexOf("<FileByte>") + 10, xmlData.indexOf("</FileByte>"));
                jornalResponse = xmlData.substring(0, xmlData.indexOf("<FileByte>") + 50);
                jornalResponse = jornalResponse + ".......";
                jornalResponse = jornalResponse + xmlData.substring(xmlData.indexOf("</FileByte>"), xmlData.length());
            }

            decodedBytes = Base64.getDecoder().decode(byteArray);
            FileOutputStream fileOuputStream = new FileOutputStream(fileName);
            fileOuputStream.write(decodedBytes);
            fileOuputStream.close();

            f = new File(fileName);
            logger.info("Response:: {}", jornalResponse);
        } catch (Exception exception) {
            logger.error("Error::{}", exception);
            return null;
        }

        if (f.exists()) {
            logger.info("Created temporary file:{}", f.getAbsolutePath());
            logger.info("Size file:{}", f.length());
            return f;
        } else {
            return null;
        }

    }

    /**
     * Подготовка файла
     *
     * @param input - полученная строка из запроса
     * @return
     */
    public static String convertStringToBinary(String input) {

        StringBuilder result = new StringBuilder();
        char[] chars = input.toCharArray();
        for (char aChar : chars) {
            result.append(
                    String.format("%8s", Integer.toBinaryString(aChar))   // char -> int, auto-cast
                            .replaceAll(" ", "0")                         // zero pads
            );
        }
        return result.toString();

    }


    /**
     * Подготовка тела запроса POST
     *
     * @param urlRequest - Константая строка для формирования тела запроса (Constant)
     * @return - Подготовленная строка
     */
    private String getRequest(String urlRequest, String DateStart, String DateEnd) {

        if (urlRequest == null) {
            return "";
        }
        return urlRequest.replaceAll("SOAPUSERID", configure.getSoapUserId()).replaceAll("SOAPPartnersId", configure.getSoapPartnerId()).
                replaceAll("SOAPDateEnd", DateEnd).replaceAll("SOAPDateStart", DateStart);
    }

}
