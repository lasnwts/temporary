package ru.usb.bascds950172.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "reportsjob")
public class RequestJob {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long uuid;

    //Дата конца периода за месяц
    private LocalDate dateend;

    //Дата начала периода за месяц
    private LocalDate datestart;

    //Дата, tmpstamp - постановка задачи в очередь
    private Date dateinitial;

    //Имя файла отчета формат  erport_ddmmyyyyhhmmss_startyyyy-mm-dd_endyyyy-mm-dd.xls
    private String filename;

    //размер файла
    private long filesize;

    /**
     * Запрошен (requested) 0
     * В процессе загрузки (download) 1
     * Файл закачан с сервера (downloaded) 2
     * Ошибка скачивания файла (failed download) 3
     * В обработке, загрузка в базу идет (process) 4
     * Ошибка обработки загрузки в базу (failed process) 5
     * Загрузка в базу завершена (success) 6
     * Ошибка обработки(failed) 7
     * Обработка завершена (completed) 8
     */
    private int statuscode;

    /**
     * Запрошен (requested) 0
     * В процессе загрузки (download) 1
     * Файл закачан с сервера (downloaded) 2
     * Ошибка скачивания файла (failed download) 3
     * В обработке, загрузка в базу идет (process) 4
     * Ошибка обработки загрузки в базу (failed process) 5
     * Загрузка в базу завершена (success) 6
     * Ошибка обработки(failed) 7
     * Обработка завершена (completed) 8
     */
    private String status;

    /**
     * 0 - запуск вручную (manual)
     * 1 - запуск автоматически (auto)
     */
    private int typereport;

    /**
     * Строковое представление (manual) или  (auto)
     */
    private String typereports;

    /**
     * Дата и время обработки файла
     */
    private Date dateprocessed;

    //Дата и время старта загрузки файла, чтобы можно было понять когда процесс обработки начался
    private Date datedownload;

    public RequestJob() {
    }

    public RequestJob(long uuid, LocalDate dateend, LocalDate datestart, Date dateinitial, String filename,
                      long filesize, int statuscode, String status, int typereport,
                      String typereports, Date dateprocessed, Date datedownload) {
        this.uuid = uuid;
        this.dateend = dateend;
        this.datestart = datestart;
        this.dateinitial = dateinitial;
        this.filename = filename;
        this.filesize = filesize;
        this.statuscode = statuscode;
        this.status = status;
        this.typereport = typereport;
        this.typereports = typereports;
        this.dateprocessed = dateprocessed;
        this.datedownload = datedownload;
    }

    public long getUuid() {
        return uuid;
    }

    public Date getDatedownload() {
        return datedownload;
    }

    public void setDatedownload(Date datedownload) {
        this.datedownload = datedownload;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public LocalDate getDateend() {
        return dateend;
    }

    public void setDateend(LocalDate dateend) {
        this.dateend = dateend;
    }

    public LocalDate getDatestart() {
        return datestart;
    }

    public void setDatestart(LocalDate datestart) {
        this.datestart = datestart;
    }

    public Date getDateinitial() {
        return dateinitial;
    }

    public void setDateinitial(Date dateinitial) {
        this.dateinitial = dateinitial;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public long getFilesize() {
        return filesize;
    }

    public void setFilesize(long filesize) {
        this.filesize = filesize;
    }

    public int getStatuscode() {
        return statuscode;
    }

    public void setStatuscode(int statuscode) {
        this.statuscode = statuscode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getTypereport() {
        return typereport;
    }

    public void setTypereport(int typereport) {
        this.typereport = typereport;
    }

    public String getTypereports() {
        return typereports;
    }

    public void setTypereports(String typereports) {
        this.typereports = typereports;
    }

    public Date getDateprocessed() {
        return dateprocessed;
    }

    public void setDateprocessed(Date dateprocessed) {
        this.dateprocessed = dateprocessed;
    }

    @Override
    public String toString() {
        return "RequestJob{" +
                "uuid=" + uuid +
                ", dateend=" + dateend +
                ", datestart=" + datestart +
                ", dateinitial=" + dateinitial +
                ", filename='" + filename + '\'' +
                ", filesize=" + filesize +
                ", statuscode=" + statuscode +
                ", status='" + status + '\'' +
                ", typereport=" + typereport +
                ", typereports='" + typereports + '\'' +
                ", dateprocessed=" + dateprocessed +
                ", datedownload=" + datedownload +
                '}';
    }
}
