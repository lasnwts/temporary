package ru.usb.bascds950172.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "reportsjob")
public class RequestJob {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long uuid;

    //Дата конца периода за месяц
    private LocalDate DateEnd;

    //Дата начала периода за месяц
    private LocalDate DateStart;

    //Дата, tmpstamp
    private Date dateInitial;

    //Имя файла отчета формат  erport_ddmmyyyyhhmmss_startyyyy-mm-dd_endyyyy-mm-dd.xls
    private String fileName;

    //размер файла
    private int fileSize;

    /**
     * Запрошен (requested) 0
     * Файл закачан с сервера (download) 1
     * В обработке (process) 2
     * Обработка завершена (success) 4
     * Ошибка обработки (failed) 3
     */
    private int statusCode;

    /**
     * Запрошен (requested) 0
     * Файл закачан с сервера (download) 1
     * В обработке (process) 2
     * Обработка завершена (success) 4
     * Ошибка обработки (failed) 3
     */
    private String status;

    /**
     * 0 - запуск вручную (manual)
     * 1 - запуск автоматически (auto)
     */
    private int typeReport;

    /**
     * Строковое представление (manual) или  (auto)
     */
    private String typeReports;

    /**
     * Дата и время обработки файла
     */
    private Date dateProcessed;











}
