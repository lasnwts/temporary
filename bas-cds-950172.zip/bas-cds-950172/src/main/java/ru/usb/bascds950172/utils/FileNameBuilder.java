package ru.usb.bascds950172.utils;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * Компонент работы по созданию нужных дат и имени файла.
 */
@Component
public class FileNameBuilder {

    LocalDate initial, firstDay, endDay;

    SimpleDateFormat sDateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * Получение имени файла, формат erport_ddmmyyyyhhmmss_startyyyy-mm-dd_endyyyy-mm-dd.xls
     *
     * @param ldate - дата месяца за который берется отчет
     * @return - имя файла
     */
    public String getFileName(LocalDate ldate) {

        if (ldate == null) {
            initial = LocalDate.now();
        }

        Date date = new Date();
        initial = ldate;
        firstDay = initial.withDayOfMonth(1);
        endDay = initial.withDayOfMonth(initial.lengthOfMonth());

        return "report-" + sDateFormat.format(date) + "-start" + firstDay.format(formatter) + "-end" + endDay.format(formatter) + ".xls";
    }


    /**
     * Получаем строку для запроса стартовой даты в SOAP типа 2022-05-01T00:00:00
     * @param ldate - дата, которую надо привести к нужной строке
     * @return - строка с датой и временем
     */
    public String getStartDayReport(LocalDate ldate){

        if (ldate == null) {
            initial = LocalDate.now();
        } else {
            initial = ldate;
        }
        return initial.format(formatter)+"T00:00:00";
    }

    /**
     * Получаем строку для запроса даты в SOAP типа 2022-05-31T23:59:59
     * @param ldate - дата, которую надо привести к нужной строке
     * @return - строка с датой и временем
     */
    public String getУтвDayReport(LocalDate ldate){

        if (ldate == null) {
            initial = LocalDate.now();
        } else {
            initial = ldate;
        }
        return initial.format(formatter)+"T23:59:59";
    }

    /**
     * Возвращает первый день месяца
     * @param ldate - дата для поиска первой даты месяца
     * @return - первая дата месяца,
     */
    public LocalDate getStartLocalDate(LocalDate ldate){

        if (ldate == null) {
            initial = LocalDate.now();
        } else {
            initial = ldate;
        }
        initial = ldate;
        return initial.withDayOfMonth(1);
    }


    /**
     * Возвращает последний день месяца
     * @param ldate - дата для поиска первой даты месяца
     * @return - последняя дата месяца,
     */
    public LocalDate getEndDayLocalDate(LocalDate ldate){

        if (ldate == null) {
            initial = LocalDate.now();
        } else {
            initial = ldate;
        }
        initial = ldate;
        return initial.withDayOfMonth(initial.lengthOfMonth());
    }


}
