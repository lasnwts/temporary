package ru.usb.bascds950172;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasCds950172ApplicationTests {

	@Test
	void contextLoads() {
	}

}
