package ru.usb.bascds950172.utils;

import static org.junit.jupiter.api.Assertions.*;

class FileNameBuilderTest {

}