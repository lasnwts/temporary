package ru.usb.arcrename.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.NumberUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Component
public class ZipFiles {

    private static final Logger logger = LoggerFactory.getLogger(FileUtils.class);

    public void Zip(String source_dir, String zip_file) throws Exception {
        // Cоздание объекта ZipOutputStream из FileOutputStream
        FileOutputStream fout = new FileOutputStream(zip_file);
        ZipOutputStream zout = new ZipOutputStream(fout, Charset.forName("UTF-8"));// Определение кодировки

        // Создание объекта File object архивируемой директории
        File fileSource = new File(source_dir);

        addDirectory(zout, fileSource);

        // Закрываем ZipOutputStream
        zout.close();

        System.out.println("Zip файл создан!");
    }

    private void addDirectory(ZipOutputStream zout, File fileSource)
            throws Exception {
        File[] files = fileSource.listFiles();
        System.out.println("Добавление директории <" + fileSource.getName() + ">");
        for (int i = 0; i < files.length; i++) {
            // Если file является директорией, то рекурсивно вызываем
            // метод addDirectory
            if (files[i].isDirectory()) {
                addDirectory(zout, files[i]);
                continue;
            }
            System.out.println("Добавление файла <" + files[i].getName() + ">");

            FileInputStream fis = new FileInputStream(files[i]);

            zout.putNextEntry(new ZipEntry(files[i].getPath()));

            byte[] buffer = new byte[4048];
            int length;
            while ((length = fis.read(buffer)) > 0)
                zout.write(buffer, 0, length);
            // Закрываем ZipOutputStream и InputStream
            zout.closeEntry();
            fis.close();
        }
    }


    /**
     * Получение номера кредита
     *
     * @param line - строка
     * @return - номер кредита - первый внутренний каталог в пути
     */
    public Optional<String> getCreditNumber(String line) {
        if (line == null || line.trim().isEmpty()) return Optional.empty();
        String[] subDirs = line.split(Pattern.quote(File.separator));
        return Optional.of(subDirs[subDirs.length - 2]);
    }

    /**
     * Проверка строки на целое число
     *
     * @param line - строка
     * @return - true - строка является целым числом
     */
    private boolean checkCreditNumber(String line) {
        if (line == null || line.trim().isEmpty()) return false;
        try {
            // Если здесь нет ошибок, значит, исходная строка – это целое число. 🎉
            Long.parseLong(line);
            return true;
        } catch (NumberFormatException e) {
            // Эта строка не является целым числом.
            // Необходимо проверить ввод снова! 🤦‍♂️
            return false;
        }
    }

    /**
     * Упаковка директории, ZIP
     *
     * @param fileToZip Имя директории, которую надо упаковать в ZIP
     * @param dirName   - Имя директории, которую надо упаковать в архив
     */
    public void zipFile(File fileToZip, String dirName, ZipOutputStream zipOut) throws IOException {

        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (dirName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(dirName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(dirName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, dirName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(dirName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }

    /**
     * Приведение записи к одному виду
     *
     * @param path - полный путь к каталогу
     * @return - полный путь к каталогу
     */
    public String getUniversePath(String path) {
        String result = "";
        if (path != null) {
            result = path.replace("\\", "/");
        }
        return result;
    }

}
