package ru.usb.arcrename.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.arcrename.config.Configure;
import ru.usb.arcrename.config.LG;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

@Component
public class FileUtils {

    private final Configure configure;

    private static final Logger logger = LoggerFactory.getLogger(FileUtils.class);

    public FileUtils(Configure configure) {
        this.configure = configure;
    }


    /**
     * Возвращает список каталогов
     * List all folders.
     * URL=https://mkyong.com/java/java-how-to-list-all-files-in-a-directory/
     *
     * @param pathRoot - корневой каталог, с которого начинается просмотр
     * @return - список строковых ссылок на катлоги
     */
    public List<String> getDirectory(String pathRoot) {

        if (!checkPathExists(pathRoot)) {
            logger.error("Error! Directory not exists! ::{}", pathRoot);
            return null;
        }
        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(pathRoot))) {

            result = walk.filter(Files::isDirectory)
                    .map(x -> x.toString()).collect(Collectors.toList());

//            result.forEach(System.out::println);

        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }


    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            logger.info("Directory :: [" + targetPath + "] exist.Ok.");
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }

    /**
     * Получение имени файла из полного пути
     *
     * @param path - полный путь к файлу
     * @return - имя файла
     */
    public String getFileName(String path) {
        String result = "";
        if (path != null) {
            result = path.substring(path.lastIndexOf("\\") + 1);
        }
        return result;
    }

    /**
     * Получение имени файла из полного пути
     *
     * @param path - полный путь к файлу
     * @return - имя файла
     */
    public String getFileNameWithExtension(String path) {
        String result = "";
        if (path != null) {
            result = path.substring(path.lastIndexOf("\\") + 1);
        }
        return result;
    }

    public String getExtension(String fileName) {
        String result = "";
        if (fileName != null) {
            result = fileName.substring(fileName.lastIndexOf(".") + 1);
        }
        return result;
    }

    /**
     * Получение списка файлов в каталоге
     *
     * @param pathRoot - корневой каталог, с которого начинается просмотр
     * @return - список строковых ссылок на файлы
     */
    public List<String> getFiles(String pathRoot) {

        if (!checkPathExists(pathRoot)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::{}", pathRoot);
            return Collections.emptyList();
        }
        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(pathRoot))) {

            result = walk.filter(Files::isRegularFile)
                    .map(Path::toString).collect(Collectors.toList());
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return Collections.emptyList();
        }
        return result;
    }


    /**
     * Метод распаковки архива ZIP
     * //        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), Charset.forName("windows-1251"))
     *
     * @param fileZip       - файл который надо распаковать (полный путь с именем)
     * @param directoryName - директории (сетевой каталог) куда будет распакован файл архива
     * @throws IOException - исключение ввода-вывода
     */
    public Optional<List<Path>> unzipFile(String fileZip, String directoryName) throws Exception {
        logger.info("{}: Распаковка архива => ZipApi.UnzipFile file:{} в каталог:{}", LG.USBLOGINFO, fileZip, directoryName);
        File destDir = new File(directoryName);
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), Charset.forName("CP866"));
        FileOutputStream fos = null;
        ZipEntry zipEntry;
        File newFile = null;
        File parent = null;
        try {
            zipEntry = zis.getNextEntry();
            while (zipEntry != null) {
                newFile = newFile(destDir, zipEntry);
                if (zipEntry.isDirectory()) {
                    if (!newFile.isDirectory() && !newFile.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + newFile);
                    }
                } else {
                    // fix for Windows-created archives
                    parent = newFile.getParentFile();
                    if (!parent.isDirectory() && !parent.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + parent);
                    }
                    // write file content
                    fos = new FileOutputStream(newFile);
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.close();
                }
                zipEntry = zis.getNextEntry();
            }
            zis.closeEntry();
            zis.close();
        } catch (Exception e) {
            String error = "Ошибка при распаковке архива:" + fileZip + " в каталог:" + directoryName + "Error:" + e.getMessage();
            try {
                zis.closeEntry();
            } catch (Exception e2) {
                logger.error("{}:Ошибка при закрытии потоков[zis.closeEntry()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            try {
                zis.close();
            } catch (Exception e2) {
                logger.error("{}:Ошибка при закрытии потоков[zis.close()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            logger.error("{}:Ошибка при распаковке архива:{}Error:{}", LG.USBLOGERROR, fileZip, e.getMessage());
            if (zis != null) {
                zis.close();
            }
            if (fos != null) {
                fos.close();
            }
            if (newFile != null) {
                Files.deleteIfExists(newFile.toPath());
            }
            if (parent != null) {
                Files.deleteIfExists(parent.toPath());

            }
            if (destDir != null) {
                Files.deleteIfExists(destDir.toPath());
            }
            throw new Exception(error); //Передаем прерывание
        }
        logger.info("{}: Распаковка архива завершена => ZipApi.UnzipFile file:{} в каталог:{}", LG.USBLOGINFO, fileZip, directoryName);
        Thread.sleep(200);
//        Files.deleteIfExists(Paths.get(fileZip));
        try (Stream<Path> list = Files.find(Paths.get(directoryName), Integer.MAX_VALUE, (filePath, fileAttr) -> fileAttr.isRegularFile() || fileAttr.isDirectory())) {
            return Optional.of(list.collect(Collectors.toList()));
        } catch (IOException e) {
            logger.error("{}:Ошибка при построении списка распакованных файлов в каталоге:{}Error:{}", LG.USBLOGERROR, directoryName, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Вспомогательный класс.
     * Этот метод защищает от записи файлов в файловую систему вне целевой папки. Эта уязвимость называется ZipApi Slip,
     * почитать об этой уязвимости https://snyk.io/research/zip-slip-vulnerability
     *
     * @param destinationDir - Файл архива, с полным именем
     * @param zipEntry       - каталог (сетевая папка) куда будет распакован архив
     * @return - File (путь к файлу)
     * @throws IOException - исключение ввода-вывода
     */
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }
        return destFile;
    }

    /**
     * Упаковка директории, ZIP
     *
     * @param fileToZip Имя директории, которую надо упаковать в ZIP
     * @param dirName - Имя директории, которую надо упаковать в архив

     */
    public void zipFile(File fileToZip, String dirName, ZipOutputStream zipOut) throws IOException {

        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (dirName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(dirName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(dirName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, dirName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(dirName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }

    /**
     * Получение номера кредита
     *
     * @param line - строка
     * @return - номер кредита - первый внутренний каталог в пути
     */
    public Optional<String> getCreditNumber(String line) {
        if (line == null || line.trim().isEmpty()) return Optional.empty();
        String[] subDirs = line.split(Pattern.quote(File.separator));
        return Optional.of(subDirs[subDirs.length - 2]);
    }



}
