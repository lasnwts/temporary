package ru.usb.arcrename;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.arcrename.config.Configure;
import ru.usb.arcrename.config.LG;
import org.apache.commons.io.FileUtils;
import ru.usb.arcrename.utils.Renamer;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class ArcrenameApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(ArcrenameApplication.class);

	private final Configure configure;
	private final Renamer renamer;

    public ArcrenameApplication(Configure configure, Renamer renamer) {
        this.configure = configure;
        this.renamer = renamer;
    }

    public static void main(String[] args) {
		SpringApplication.run(ArcrenameApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// Проверка путей
		Path path = Paths.get(configure.getTargetDirectory());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
		} else {
			logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));

		logger.info(".");
		logger.info("..");
		logger.info("...");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : {}", configure.getApplicationName(), LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по переименованию файла Электронная подпись", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 11/04/2025 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  12.11.2024  : 0.0.10 Базовая версия", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("...");
		logger.info("..");
		logger.info(".");

		try {
			renamer.start();
		} catch (Exception e) {
			logger.error("PrintStackTrace::", e);
		}



	}
}
