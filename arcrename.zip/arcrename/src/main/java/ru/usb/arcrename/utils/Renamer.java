package ru.usb.arcrename.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.arcrename.config.Configure;
import ru.usb.arcrename.config.LG;

import java.io.File;
import java.util.List;

@Component
public class Renamer {

    private final FileUtils fileUtils;
    private final Configure configure;
    private final ZipFiles zipFiles;

    public Renamer(FileUtils fileUtils, Configure configure, ZipFiles zipFiles) {
        this.fileUtils = fileUtils;
        this.configure = configure;
        this.zipFiles = zipFiles;
    }

    private static final Logger logger = LoggerFactory.getLogger(Renamer.class);

    /**
     * Запуск процесса
     */
    public void start() throws Exception {
        logger.info("start");
        List<String> files =fileUtils.getFiles(configure.getSourceDirectory());
        if (files != null) {
            for (String file : files) {
                logger.info("{} Имя файла:{}", LG.USBLOGINFO, file);
                fileUtils.unzipFile(file, configure.getTemporaryDirectory());
 //               zipFiles.Zip(configure.getTemporaryDirectory(), configure.getTargetDirectory() + File.separator + fileUtils.getFileName(file));

//                String fileName = fileUtils.getFileName(file);
//
//                String targetFile = configure.getTargetDirectory() + "\\" + fileName;

            }
        }
    }
}
