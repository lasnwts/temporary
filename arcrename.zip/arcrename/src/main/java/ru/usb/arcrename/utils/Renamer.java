package ru.usb.arcrename.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.arcrename.config.Configure;
import ru.usb.arcrename.config.LG;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.function.Consumer;

@Component
public class Renamer {

    private final FileUtils fileUtils;
    private final Configure configure;
    private final ZipFiles zipFiles;

    public Renamer(FileUtils fileUtils, Configure configure, ZipFiles zipFiles) {
        this.fileUtils = fileUtils;
        this.configure = configure;
        this.zipFiles = zipFiles;
    }

    private static final Logger logger = LoggerFactory.getLogger(Renamer.class);

    /**
     * Запуск процесса
     */
    public void start() throws Exception {
        logger.info("start");
        List<String> files = fileUtils.getFiles(configure.getSourceDirectory());
        if (files != null) {
            for (String file : files) {
                logger.info("===============<Archive>====================");
                logger.info("{} Имя файла:{}", LG.USBLOGINFO, file);
                fileUtils.unzipFile(file, configure.getTemporaryDirectory());
                fileUtils.getFiles(configure.getTemporaryDirectory()).forEach(new Consumer<String>() {
                    @Override
                    public void accept(String file) {
                        logger.info("File:{}", file);
                        File f = new File(file);
                        if (f.exists() && f.getName().equalsIgnoreCase("Электронная подпись.pdf")) {
                            if (f.renameTo(new File(f.getParent() + File.separator + "Электронная подпись_с подпись.pdf"))) {
                                logger.info("File:{} rename Ok!", f.getName());
                                try {
                                    if (Files.deleteIfExists(f.toPath())) {
                                        logger.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, f.getAbsolutePath());
                                    } else {
                                        logger.info("{}: Файл:{} не существует во временной директории!", LG.USBLOGINFO, f.getAbsolutePath());
                                    }
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                        }
                    }
                });

                //               zipFiles.Zip(configure.getTemporaryDirectory(), configure.getTargetDirectory() + File.separator + fileUtils.getFileName(file));
//                String fileName = fileUtils.getFileName(file);//
//                String targetFile = configure.getTargetDirectory() + "\\" + fileName;

            }
        }
    }
}
