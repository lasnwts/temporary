package ru.usb.arcrename.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${source.file}")
    private String sourceDirectory; //Директория с исходными файлами

    @Value("${temporary.file}")
    private String temporaryDirectory; //Директория с временными файлами

    @Value("${target.file}")
    private String targetDirectory; //Директория с файлами архивов

    public String getSourceDirectory() {
        return sourceDirectory;
    }

    public String getTargetDirectory() {
        return targetDirectory;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getTemporaryDirectory() {
        return temporaryDirectory;
    }
}
