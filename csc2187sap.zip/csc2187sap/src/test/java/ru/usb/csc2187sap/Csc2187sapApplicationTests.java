package ru.usb.csc2187sap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csc2187sapApplicationTests {

	@Test
	void contextLoads() {
	}

}
