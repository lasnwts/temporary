/**
 * PHONES_DATA.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ru.usb.csc2187sap.phone;

public class PHONES_DATA  implements java.io.Serializable {
    private java.lang.String USER_SAPID;

    private java.lang.String QUANTITY;

    public PHONES_DATA() {
    }

    public PHONES_DATA(
           java.lang.String USER_SAPID,
           java.lang.String QUANTITY) {
           this.USER_SAPID = USER_SAPID;
           this.QUANTITY = QUANTITY;
    }


    /**
     * Gets the USER_SAPID value for this PHONES_DATA.
     * 
     * @return USER_SAPID
     */
    public java.lang.String getUSER_SAPID() {
        return USER_SAPID;
    }


    /**
     * Sets the USER_SAPID value for this PHONES_DATA.
     * 
     * @param USER_SAPID
     */
    public void setUSER_SAPID(java.lang.String USER_SAPID) {
        this.USER_SAPID = USER_SAPID;
    }


    /**
     * Gets the QUANTITY value for this PHONES_DATA.
     * 
     * @return QUANTITY
     */
    public java.lang.String getQUANTITY() {
        return QUANTITY;
    }


    /**
     * Sets the QUANTITY value for this PHONES_DATA.
     * 
     * @param QUANTITY
     */
    public void setQUANTITY(java.lang.String QUANTITY) {
        this.QUANTITY = QUANTITY;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PHONES_DATA)) return false;
        PHONES_DATA other = (PHONES_DATA) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.USER_SAPID==null && other.getUSER_SAPID()==null) || 
             (this.USER_SAPID!=null &&
              this.USER_SAPID.equals(other.getUSER_SAPID()))) &&
            ((this.QUANTITY==null && other.getQUANTITY()==null) || 
             (this.QUANTITY!=null &&
              this.QUANTITY.equals(other.getQUANTITY())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUSER_SAPID() != null) {
            _hashCode += getUSER_SAPID().hashCode();
        }
        if (getQUANTITY() != null) {
            _hashCode += getQUANTITY().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PHONES_DATA.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:DefaultNamespace", "PHONES_DATA"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USER_SAPID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "USER_SAPID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUANTITY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUANTITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
