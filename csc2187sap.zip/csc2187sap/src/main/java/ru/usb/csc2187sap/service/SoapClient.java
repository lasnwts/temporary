package ru.usb.csc2187sap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.csc2187sap.phone.PhonesServiceLocator;

@Service
public class SoapClient {


    PhonesServiceLocator phonesServiceLocator = new PhonesServiceLocator();
//
//
//
//        System.out.println("Start...");
//        System.out.println("Name = " + phonesServiceLocator.getDominoWSDDServiceName());
//        System.out.println(" getDominoAddress =  " + phonesServiceLocator.getDominoAddress());
//        System.out.println("getServiceName = " + phonesServiceLocator.getServiceName().toString());

}
