/**
 * PHONESINFOARRAY.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ru.usb.csc2187sap.phone;

public class PHONESINFOARRAY  implements java.io.Serializable {
    private ru.usb.csc2187sap.phone.PHONES_DATA[] PHONESARRAY;

    public PHONESINFOARRAY() {
    }

    public PHONESINFOARRAY(
           ru.usb.csc2187sap.phone.PHONES_DATA[] PHONESARRAY) {
           this.PHONESARRAY = PHONESARRAY;
    }


    /**
     * Gets the PHONESARRAY value for this PHONESINFOARRAY.
     * 
     * @return PHONESARRAY
     */
    public ru.usb.csc2187sap.phone.PHONES_DATA[] getPHONESARRAY() {
        return PHONESARRAY;
    }


    /**
     * Sets the PHONESARRAY value for this PHONESINFOARRAY.
     * 
     * @param PHONESARRAY
     */
    public void setPHONESARRAY(ru.usb.csc2187sap.phone.PHONES_DATA[] PHONESARRAY) {
        this.PHONESARRAY = PHONESARRAY;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PHONESINFOARRAY)) return false;
        PHONESINFOARRAY other = (PHONESINFOARRAY) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PHONESARRAY==null && other.getPHONESARRAY()==null) || 
             (this.PHONESARRAY!=null &&
              java.util.Arrays.equals(this.PHONESARRAY, other.getPHONESARRAY())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPHONESARRAY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPHONESARRAY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPHONESARRAY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PHONESINFOARRAY.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:DefaultNamespace", "PHONESINFOARRAY"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PHONESARRAY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PHONESARRAY"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:DefaultNamespace", "PHONES_DATA"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
