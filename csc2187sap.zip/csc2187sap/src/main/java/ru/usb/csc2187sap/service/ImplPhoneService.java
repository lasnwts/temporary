package ru.usb.csc2187sap.service;

import org.springframework.stereotype.Component;
import ru.usb.csc2187sap.phone.Phones;
import ru.usb.csc2187sap.phone.PhonesService;

import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerRegistry;
import java.net.URL;
import java.rmi.Remote;
import java.util.Iterator;

@Component
public class ImplPhoneService implements PhonesService {

    @Override
    public String getDominoAddress() {
        return null;
    }

    @Override
    public Phones getDomino() throws ServiceException {
        return null;
    }

    @Override
    public Phones getDomino(URL portAddress) throws ServiceException {
        return null;
    }

    @Override
    public Remote getPort(QName qName, Class aClass) throws ServiceException {
        return null;
    }

    @Override
    public Remote getPort(Class aClass) throws ServiceException {
        return null;
    }

    @Override
    public Call[] getCalls(QName qName) throws ServiceException {
        return new Call[0];
    }

    @Override
    public Call createCall(QName qName) throws ServiceException {
        return null;
    }

    @Override
    public Call createCall(QName qName, QName qName1) throws ServiceException {
        return null;
    }

    @Override
    public Call createCall(QName qName, String s) throws ServiceException {
        return null;
    }

    @Override
    public Call createCall() throws ServiceException {
        return null;
    }

    @Override
    public QName getServiceName() {
        return null;
    }

    @Override
    public Iterator getPorts() throws ServiceException {
        return null;
    }

    @Override
    public URL getWSDLDocumentLocation() {
        return null;
    }

    @Override
    public TypeMappingRegistry getTypeMappingRegistry() {
        return null;
    }

    @Override
    public HandlerRegistry getHandlerRegistry() {
        return null;
    }
}
