package ru.usb.csc2187sap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.csc2187sap.phone.DominoSoapBindingStub;
import ru.usb.csc2187sap.phone.PHONESINFOARRAY;
import ru.usb.csc2187sap.phone.Phones;
import ru.usb.csc2187sap.phone.PhonesServiceLocator;
import ru.usb.csc2187sap.service.SoapClient;

import java.net.URL;

@SpringBootApplication
public class Csc2187sapApplication implements CommandLineRunner {

    @Autowired
    SoapClient soapClient;

    public static void main(String[] args) {
        SpringApplication.run(Csc2187sapApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {


        String urls = "http://127.0.0.1:8080";
        URL url = new URL(urls);

        PhonesServiceLocator phonesServiceLocator = new PhonesServiceLocator();
        phonesServiceLocator.setDominoEndpointAddress(urls);
        Phones phones = phonesServiceLocator.getDomino();
        PHONESINFOARRAY phonesinfoarray = phones.GETSAPIDBYPHONE("1");
        System.out.println("====");
        System.out.println("Array size = " + phonesinfoarray.getPHONESARRAY().length);
        System.out.println("SAP_ID = "+ phonesinfoarray.getPHONESARRAY()[0].getUSER_SAPID());
        System.out.println("QUANTITY = "+ phonesinfoarray.getPHONESARRAY()[0].getQUANTITY());
        System.out.println("====");


//        DominoSoapBindingStub dominoSoapBindingStub = phonesServiceLocator.getPort();


//
//
//
//        System.out.println("Start...");
//        System.out.println("Name = " + phonesServiceLocator.getDominoWSDDServiceName());
//        System.out.println(" getDominoAddress =  " + phonesServiceLocator.getDominoAddress());
//        System.out.println("getServiceName = " + phonesServiceLocator.getServiceName().toString());


//		DominoSoapBindingStub dominoSoapBindingStub = new DominoSoapBindingStub();
//        phonesServiceLocator.setDominoEndpointAddress("http://127.0.0.1:8080");
//		dominoSoapBindingStub.GETSAPIDBYPHONE("1");


    }
}
