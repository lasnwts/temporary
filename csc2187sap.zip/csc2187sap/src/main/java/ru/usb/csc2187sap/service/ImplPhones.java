package ru.usb.csc2187sap.service;

import org.springframework.stereotype.Component;
import ru.usb.csc2187sap.phone.PHONESINFOARRAY;
import ru.usb.csc2187sap.phone.Phones;

import java.rmi.RemoteException;

@Component
public class ImplPhones implements Phones {

    @Override
    public PHONESINFOARRAY GETSAPIDBYPHONE(String PHONE_NUMBER) throws RemoteException {
        return null;
    }
}
