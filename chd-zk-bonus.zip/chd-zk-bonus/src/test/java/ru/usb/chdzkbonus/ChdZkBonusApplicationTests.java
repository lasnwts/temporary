package ru.usb.chdzkbonus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChdZkBonusApplicationTests {

	@Test
	void contextLoads() {
	}

}
