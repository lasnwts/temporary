package ru.usb.chdzkbonus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChdZkBonusApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChdZkBonusApplication.class, args);
	}

}
