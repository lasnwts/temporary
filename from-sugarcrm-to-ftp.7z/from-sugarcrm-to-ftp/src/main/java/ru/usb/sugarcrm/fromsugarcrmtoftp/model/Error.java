package ru.usb.sugarcrm.fromsugarcrmtoftp.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Ошибки сервиса при передаче файла на FTP сервер")
public class Error {

    @ApiModelProperty(notes = "Код ошибки. Поле возвращается, только в случае ошибочной доставки.\n Код в таком случае равен 1.")
    private int errorCode;

    @ApiModelProperty(notes = "Текст ошибки")
    private String errorText;

    public Error() {
    }

    public Error(int errorCode, String errorText) {
        this.errorCode = errorCode;
        this.errorText = errorText;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }
}
