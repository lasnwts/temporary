package ru.usb.sugarcrm.fromsugarcrmtoftp.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Component
@ConfigurationProperties()
public class ConfigureFTP {
    @Value("${ftpserver.host:0.0.0.0}")
    private String host;
    @Value("${ftpserver.port:21}")
    private int port;
    @Value("${ftpserver.user:none}")
    private String user;
    @Value("${ftpserver.password:none}")
    private String password;
    @Value("${ftpserver.timeout:600}")
    private Integer timeout;
    @Value("${ftpserver.directory:none}")
    private String directory;
    @Value("${ftpserver.datetimeout:10000}")
    private int datetimeout;
    @Value("${ftpserver.connecttiomeout:20000}")
    private int connecttiomeout;
    @Value("${ftpserver.ftpmode:false}")
    private boolean ftpmode;

    public int getDatetimeout() {
        return datetimeout;
    }

    public int getConnecttiomeout() {
        return connecttiomeout;
    }

    public boolean getFtpmode() {
        return ftpmode;
    }

    public String getHost() {
        return host;
    }

    public InetAddress getInetAddr() throws UnknownHostException {
        return InetAddress.getByName(host);
    }

    public int getPort() {
        return port;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public String getDirectory() {
        return directory;
    }

    @Override
    public String toString() {
        return "ConfigureFTP{" +
                "host='" + host + '\'' +
                ", port=" + port +
                ", user='" + user + '\'' +
                ", password='" + password + '\'' +
                ", timeout=" + timeout +
                ", directory='" + directory + '\'' +
                ", datetimeout=" + datetimeout +
                ", connecttiomeout=" + connecttiomeout +
                ", ftpmode=" + ftpmode +
                '}';
    }

}
