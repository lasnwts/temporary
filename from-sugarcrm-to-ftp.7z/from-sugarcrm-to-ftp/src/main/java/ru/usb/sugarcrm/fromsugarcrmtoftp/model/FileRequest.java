package ru.usb.sugarcrm.fromsugarcrmtoftp.model;

import org.springframework.web.multipart.MultipartFile;

public class FileRequest {

    private MultipartFile fileContent;

    private String fileName;

    public MultipartFile getFile() {
        return fileContent;
    }

    public void setFile(MultipartFile file) {
        this.fileContent = file;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public FileRequest(String fileName, MultipartFile fileContent) {
        this.fileContent = fileContent;
        this.fileName = fileName;
    }

    public FileRequest() {
    }

    @Override
    public String toString() {
        return "FileRequest{" +
                "fileSize=" + fileContent.getSize() +
                ", fileName='" + fileName + '\'' +
                '}';
    }
}
