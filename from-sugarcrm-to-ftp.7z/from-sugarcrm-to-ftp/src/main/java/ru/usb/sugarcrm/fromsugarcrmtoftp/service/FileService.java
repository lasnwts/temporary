package ru.usb.sugarcrm.fromsugarcrmtoftp.service;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sugarcrm.fromsugarcrmtoftp.configs.ConfigureFTP;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.Error;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.FileRequest;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.FileResponse;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

@Service
public class FileService {

    @Autowired
    ConfigureFTP configureFTP;

    Logger logger = LoggerFactory.getLogger(FileService.class);
    /**
     * The default buffer size
     */
    public static final int DEFAULT_BUFFER_SIZE = 8192;

    public FileResponse saveAndRename(FileRequest fileRequest) {
        FileResponse fileResponse = new FileResponse();
        fileResponse.setFileName(fileRequest.getFileName());
        Error error = new Error();
        FTPClient ftpClient = new FTPClient();
        try {
            ftpClient.setConnectTimeout(configureFTP.getConnecttiomeout());
            ftpClient.setDataTimeout(configureFTP.getDatetimeout());
            ftpClient.connect(configureFTP.getHost(), configureFTP.getPort());
            ftpClient.login(configureFTP.getUser(), configureFTP.getPassword());
            /*
            Режим FTP сервера
             */
            if (configureFTP.getFtpmode()) {
                ftpClient.enterLocalPassiveMode();
            }
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            if (ftpClient.isConnected()) {
                logger.info("ftpClient:Connected successfully...");
                logger.info("FTP status: " + ftpClient.getStatus());
            } else {
                logger.error("ftpClient: ERROR: not connected!!!!");
                logger.error("FTP status: " + ftpClient.getStatus());
            }

            InputStream inputStream = new BufferedInputStream(fileRequest.getFile().getInputStream());
            boolean done = ftpClient.storeFile(fileRequest.getFileName(), inputStream);
            logger.info("FTP Code: " + ftpClient.getReplyCode());
            logger.info("FTP Status: " + ftpClient.getReplyString());
            inputStream.close();

            if (done) {
                logger.info("The file " + fileRequest.getFileName() + " is uploaded successfully.");
                fileResponse.setStatus("delivered");
            } else {
                logger.error("The file " + fileRequest.getFileName() + " is not uploaded.");
                fileResponse.setStatus("not delivered");
                error.setErrorCode(ftpClient.getReplyCode());
                error.setErrorText(ftpClient.getReplyString());
                fileResponse.setError(error);
            }
        } catch (IOException ex) {
            fileResponse.setStatus("not delivered");
            error.setErrorCode(1);
            if (ftpClient.getReplyString() == null) {
                error.setErrorText(ex.getMessage());
            } else {
                error.setErrorText(ftpClient.getReplyString());
            }
            fileResponse.setError(error);
            logger.error("Ошибка при работе с FTP сервером. Error: " + ex.getMessage());
            logger.error("FTP Code: " + ftpClient.getReplyString());
            logger.error(ex.getMessage());
            logger.error(ex.toString());
            ex.printStackTrace();
            return fileResponse;
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                fileResponse.setStatus("not delivered");
                error.setErrorCode(1);
                if (ftpClient.getReplyString() == null) {
                    error.setErrorText(ex.getMessage());
                } else {
                    error.setErrorText(ftpClient.getReplyString());
                }
                fileResponse.setError(error);
                logger.error(ex.getMessage());
                logger.error(ex.toString());
                ex.printStackTrace();
                return fileResponse;
            }
        }


//        Path path = Paths.get("/" + fileRequest.getFileName());
//        fileRequest.getFile().transferTo(path);
//        fileRequest.getFile().transferTo(new File(fileRequest.getFileName()));


        fileResponse.setFileName(fileRequest.getFileName());
        return fileResponse;
    }
}
