package ru.usb.siebelinsuranceihb.model;

/**
 * Класс содержащий ответ от сервера ИСЖ
 */
public class ResponseInsurance {

    //Поле успеха или ошибки
    //true - успех
    //false - ошибка
    private Boolean errorCode;

    //Тело сообщения
    private String messageBody;

    public ResponseInsurance() {
        //
    }

    public ResponseInsurance(Boolean errorCode, String messageBody) {
        this.errorCode = errorCode;
        this.messageBody = messageBody;
    }

    public Boolean getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Boolean errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessageBody() {
        return messageBody;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    @Override
    public String toString() {
        return "ResponseInsurance{" +
                "errorCode=" + errorCode +
                ", messageBody='" + messageBody + '\'' +
                '}';
    }
}
