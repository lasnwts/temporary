package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Envelope {

    @JsonProperty("Body")
    public Body Body;

    public Envelope() {
        //
    }

    @JsonProperty("Body")
    public ru.usb.siebelinsuranceihb.dto.response.Body getBody() {
        return Body;
    }

    @JsonProperty("Body")
    public void setBody(ru.usb.siebelinsuranceihb.dto.response.Body body) {
        Body = body;
    }

    @Override
    public String toString() {
        return "Envelope{" +
                "Body=" + Body +
                '}';
    }
}
