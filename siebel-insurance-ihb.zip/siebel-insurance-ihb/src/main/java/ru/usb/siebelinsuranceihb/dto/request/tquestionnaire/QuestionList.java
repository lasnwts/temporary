package ru.usb.siebelinsuranceihb.dto.request.tquestionnaire;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuestionList {

    @JsonProperty("Question")
    private List<Question> questionList;

    public QuestionList() {
        //
    }

    public QuestionList(List<Question> questionList) {
        this.questionList = questionList;
    }


    @JsonProperty("Question")
    public List<Question> getQuestionList() {
        return questionList;
    }


    @JsonProperty("Question")
    public void setQuestionList(List<Question> questionList) {
        this.questionList = questionList;
    }

}
