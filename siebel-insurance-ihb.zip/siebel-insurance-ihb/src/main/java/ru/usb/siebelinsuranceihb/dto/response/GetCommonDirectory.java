package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCommonDirectory {

    @JsonProperty("Directory")
    public ArrayList<Directory> directory;

    public GetCommonDirectory() {
        //
    }

    public ArrayList<Directory> getDirectory() {
        return directory;
    }

    public void setDirectory(ArrayList<Directory> directory) {
        this.directory = directory;
    }

    @Override
    public String toString() {
        return "GetCommonDirectory{" +
                "directory=" + directory +
                '}';
    }
}
