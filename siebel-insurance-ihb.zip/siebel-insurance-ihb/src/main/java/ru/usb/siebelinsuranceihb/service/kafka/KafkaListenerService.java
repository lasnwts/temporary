package ru.usb.siebelinsuranceihb.service.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;
import ru.usb.siebelinsuranceihb.service.MessageProcess;
import ru.usb.siebelinsuranceihb.service.mail.ServiceMailError;
import ru.usb.siebelinsuranceihb.utils.AuxMethods;
import ru.usb.siebelinsuranceihb.utils.MessKafkaMapper;


@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;

    private final AuxMethods aux;

    private final MessageProcess messageProcess;

    private final MessKafkaMapper kafkaMapper;

    public KafkaListenerService(ServiceMailError serviceMailError, AuxMethods aux, MessageProcess messageProcess, MessKafkaMapper kafkaMapper) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.messageProcess = messageProcess;
        this.kafkaMapper = kafkaMapper;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {
        if (logDebug) {
            logger.info("UsbLog:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener (record.value)    == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        /**
         * Сообщение забираем по любому
         */
        ack.acknowledge();

        /**
         * Сообщение по Kafka, готовим
         */
        String message;
        message = recordKafka.value();

        if (message == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!");
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()));
        } else {

            /**
             * Сообщение по Kafka, готовим
             */

            MessageFromKafka messageFromKafka = kafkaMapper.mapKafkaMessage(message);

            if (messageFromKafka == null) {
                logger.error("ERROR[MessageFromKafka(message)]]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error(" Сообщение не распарсилось!!:{}", message);
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                serviceMailError.sendMailError("Возникла ошибка при обработке сообщения из Siebel Поток 3.1. Проект 3197 (Siebel->Мобильное приложение)." + "\n\r\"" +
                        "ERROR[(message)]],Сообщение не распарсилось в MessageFromKafka!!" + "\n\r\"" + message.trim());

            } else {

                /**
                 * Вызов BaseProcessJob
                 */
                try {
                    messageProcess.processed(messageFromKafka);
                } catch (Exception exceptionKafkaProcessed) {
                    logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Kafka process catch)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                }
            }
        }
    }
}
