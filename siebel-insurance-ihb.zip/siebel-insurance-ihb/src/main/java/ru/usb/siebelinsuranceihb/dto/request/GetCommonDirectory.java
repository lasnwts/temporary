package ru.usb.siebelinsuranceihb.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCommonDirectory {
    @JsonProperty("PartnerId")
    public String partnerId;
    @JsonProperty("UserPartnerId")
    public String userPartnerId ;
    @JsonProperty("DirectoryID")
    public String directoryID;

    public GetCommonDirectory() {
        //
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getUserPartnerId() {
        return userPartnerId;
    }

    public void setUserPartnerId(String userPartnerId) {
        this.userPartnerId = userPartnerId;
    }

    public String getDirectoryID() {
        return directoryID;
    }

    public void setDirectoryID(String directoryID) {
        this.directoryID = directoryID;
    }

    @Override
    public String toString() {
        return "GetCommonDirectory{" +
                "partnerId='" + partnerId + '\'' +
                ", userPartnerId='" + userPartnerId + '\'' +
                ", directoryID='" + directoryID + '\'' +
                '}';
    }
}
