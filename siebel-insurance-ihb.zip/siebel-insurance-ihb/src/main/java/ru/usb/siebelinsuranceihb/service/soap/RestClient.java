package ru.usb.siebelinsuranceihb.service.soap;

import org.apache.kafka.common.protocol.types.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.usb.siebelinsuranceihb.configure.Configure;
import ru.usb.siebelinsuranceihb.model.ResponseInsurance;
import ru.usb.siebelinsuranceihb.service.mail.ServiceMailError;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;

/**
 * Класс для запроса ИСЖ
 */

@Service
public class RestClient {
    private final Configure configure;
    @Autowired
    public RestClient(Configure configure) {
        this.configure = configure;
    }

    String xmlData;
    RestTemplate restTemplate = new RestTemplate();
    Logger logger = LoggerFactory.getLogger(RestClient.class);


    /**
     * Отправка запроса в страховую
     *
     * @param soapBody
     * @return
     */
    /**
     * Отправка запроса в страховую
     *
     * @param soapBody - текст Запроса (BODY)
     * @param route    - направление 1=GetCommonDirectory, 2=Questionnaire
     * @return
     */
    public ResponseInsurance getRequestInsurance(String soapBody, int route) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf("text/xml;charset=UTF-8"));//Content-Type: text/xml;charset=UTF-8
        headers.add("Login", configure.getSoapLogin());
        headers.add("Password", configure.getSoapPassword());
        if (route == 1) {
            headers.set("SOAPAction", configure.getSoapActionGetCommonDirectory());
        } else {
            if (route == 2) {
                headers.set("SOAPAction", configure.getSoapActionGetQuestionnaire());
            }
        }
        HttpEntity<String> request = new HttpEntity<String>(soapBody, headers);
        logger.info("UsbLog:Request::{}", request.toString());
        xmlData = "";
        //Готовим класс ответа
        ResponseInsurance responseInsurance = new ResponseInsurance();
        try {
            xmlData = restTemplate.postForObject(configure.getSoapUrl(), request, String.class);
            responseInsurance.setErrorCode(true);
            responseInsurance.setMessageBody(xmlData);
            logger.info("UsbLog:Получен response: {}", responseInsurance.toString());
            return responseInsurance;
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String sStackTrace = sw.toString(); // stack trace as a string
            if (sStackTrace.contains("soapenv:Envelope")) {
                String envelopeError = sStackTrace.substring(sStackTrace.indexOf("<soapenv:Envelope xmlns:soapenv"), sStackTrace.indexOf("</soapenv:Envelope>")) + "</soapenv:Envelope>";
                responseInsurance.setMessageBody(envelopeError.replace("<EOL>", "").replace("<eol>", ""));
            } else {
                responseInsurance.setMessageBody(sStackTrace);
            }
            responseInsurance.setErrorCode(false);
            logger.error("UsbLog:Error:sStackTrace:{}", sStackTrace.trim());
            return responseInsurance;
        }
    }
}
