package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "GetCommonDirectoryResponse")
public class GetCommonDirectoryResponse {

    @JsonProperty("Result")
    public Result Result;

    @JsonProperty("Directory")
    @JacksonXmlElementWrapper(useWrapping = false)
    public List<Directory> Directory;
    @JsonProperty("DirectoryID")
    public String DirectoryID;

    public GetCommonDirectoryResponse() {
    //
    }

    @JsonProperty("Result")
    public ru.usb.siebelinsuranceihb.dto.response.Result getResult() {
        return Result;
    }

    @JsonProperty("Result")
    public void setResult(ru.usb.siebelinsuranceihb.dto.response.Result result) {
        Result = result;
    }

    @JsonProperty("Directory")
    @JacksonXmlElementWrapper(useWrapping = false)
    public List<ru.usb.siebelinsuranceihb.dto.response.Directory> getDirectory() {
        return Directory;
    }

    @JsonProperty("Directory")
    @JacksonXmlElementWrapper(useWrapping = false)
    public void setDirectory(List<ru.usb.siebelinsuranceihb.dto.response.Directory> directory) {
        Directory = directory;
    }

    @JsonProperty("DirectoryID")
    public String getDirectoryID() {
        return DirectoryID;
    }

    @JsonProperty("DirectoryID")
    public void setDirectoryID(String directoryID) {
        DirectoryID = directoryID;
    }

    @Override
    public String toString() {
        return "GetCommonDirectoryResponse{" +
                "Result=" + Result +
                '}';
    }
}
