package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetQuestionnaire {

    @JsonProperty("QuestionnaireID")
    public String questionnaireIDl;


    public SetQuestionnaire() {
        //
    }

    public String getQuestionnaireIDl() {
        return questionnaireIDl;
    }

    public void setQuestionnaireIDl(String questionnaireIDl) {
        this.questionnaireIDl = questionnaireIDl;
    }

    @Override
    public String toString() {
        return "SetQuestionnaire{" +
                "questionnaireIDl='" + questionnaireIDl + '\'' +
                '}';
    }
}
