package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.dto.request.commondir.Envelope;


@Component
public class MapperRequestXML {

    Logger logger = LoggerFactory.getLogger(MapperRequestXML.class);
    XmlMapper xmlMapper = new XmlMapper();

    /**
     * Partner XML to POJO
     * @param xmlString
     * @return
     */
    public Envelope getMap(String xmlString) {
        if (xmlString == null) {
            return null;
        } else {
            try {
                xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                return xmlMapper.readValue(xmlString, Envelope.class);
            } catch (JsonProcessingException e) {
                logger.error("UsbLog: ###############################");
                logger.error("UsbLog: Ошибка преобразования строки XML {} в POJO", xmlString);
                logger.error("UsbLog: JsonProcessingException:`", e);
                return null;
            }
        }
    }


    /**
     * Получаем Body для запроса в ИСЖ Partner
     * @param envelope - POJO
     * @return - XML
     */
    public String getPartnerXML(Envelope envelope) {
        if (envelope == null || envelope.getBody() == null || envelope.getBody().getGetCommonDirectoryRequest() == null) {
            logger.error("UsbLog:Метод POJO->XML Partner, передан пустой объект");
            return "";
        } else {
            String xml = null;
            try {
                xml = xmlMapper.writeValueAsString(envelope);
            } catch (JsonProcessingException e) {
                logger.error("UsbLog: ###############################");
                logger.error("UsbLog: Ошибка преобразования строки POJO [Envelope] (cм.:Envelope.getBody().GetCommonDirectoryRequest) {} в XML", envelope.getBody().getGetCommonDirectoryRequest());
                logger.error("UsbLog: JsonProcessingException:`", e);
            }
            return xml;
        }
    }


    /**
     * Получаем Body для запроса в ИСЖ SetQuestionnaire в интеграционном потоке потоке EFS-P-Questionnaire
     * @param envelope - POJO
     * @return - XML
     */
    public String getQuestionnaireXML(ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope envelope) {
        if (envelope == null || envelope.getBody() == null || envelope.getBody().getSetQuestionnaireRequest() == null) {
            logger.error("UsbLog:Метод POJO->XML Partner, передан пустой объект");
            return "";
        } else {
            String xml = null;
            try {
                xml = xmlMapper.writeValueAsString(envelope);
            } catch (JsonProcessingException e) {
                logger.error("UsbLog: ###############################");
                logger.error("UsbLog: Ошибка преобразования строки POJO [Envelope:ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope] (cм.:Envelope.getBody().getSetQuestionnaireRequest() ) {} в XML", envelope.getBody().getSetQuestionnaireRequest());
                logger.error("UsbLog: JsonProcessingException:`", e);
            }
            return xml;
        }
    }

}
