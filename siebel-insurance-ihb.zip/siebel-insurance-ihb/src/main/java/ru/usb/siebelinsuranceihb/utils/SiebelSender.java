package ru.usb.siebelinsuranceihb.utils;

import org.apache.kafka.common.protocol.types.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.configure.Configure;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;
import ru.usb.siebelinsuranceihb.service.kafka.KafkaProducerService;


/**
 * Отправка ответов в Siebel
 * <p>
 * Структура входящего сообщения
 * <p>
 * 1. 	system_from	Система-источник		Константа "MP-Hard"	String
 * +
 * 2.  	system_to	Система-приемник		Константа "SIEBEL"	String
 * +
 * 3.	service	Название сервиса			String
 * +
 * 4.	routeID	Идентификатор топика kafka			String
 * 5. 	mapper	Bдентификатор того, что тело запроса в конверте необходимо передать сервису Маппер		Пусто	String
 * 6.	packID	Уникальный идентификатор запроса		Уникальный идентификатор входящего запроса	String
 * +
 * 7. 	pack	Тело сообщения		Элемент с сообщением	String
 * +
 * 8. 	error	Код ошибки		Код ошибки (пусто  - успех, 1 - ошибка)	String
 * 9. 	errortext	Текст ошибки		Текст ошибки, если error = 1	String
 */

@Component
public class SiebelSender {
    private final Configure configure;
    private final KafkaProducerService kafkaProducerService;
    private final MessageToSiebelMap siebelMap;
    private final Utilites utilites;
    @Autowired
    public SiebelSender(Configure configure, KafkaProducerService kafkaProducerService, MessageToSiebelMap siebelMap, Utilites utilites) {
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.siebelMap = siebelMap;
        this.utilites = utilites;
    }
    Logger logger = LoggerFactory.getLogger(SiebelSender.class);

    /**
     * Отправка сообщения в Зибель
     * @param message - pack
     * @param service - имя сервиса
     * @param packId - packId
     * @param errorCode - false - нет ошибок, true - есть ошибка
     * @param errorText - описание ошибки
     */
    public void sendToSiebel(String message, String service, String packId, Boolean errorCode, String errorText) {

        /**
         * Создаем сообщение в Siebel
         *
         */
        MessageFromKafka messageToSiebel = new MessageFromKafka();
        messageToSiebel.setSystem_from(configure.getSystemFrom());
        messageToSiebel.setSystem_to(configure.getSystemTo());
        messageToSiebel.setService(service);
        messageToSiebel.setPackID(packId);
        messageToSiebel.setPack(message);
        if (!errorCode) {
            messageToSiebel.setError("");
            messageToSiebel.setErrortext("");
        } else {
            messageToSiebel.setError("1");
            messageToSiebel.setErrortext(utilites.get4000(utilites.getWrapNull(errorText)));
        }

        try {
            logger.info("UsbLog:отправлено в топик:{},  (сообщение в Siebel) MessageToSiebel:{}", configure.getSiebelTopic(), siebelMap.getJsonToStr(messageToSiebel));
            kafkaProducerService.sendMessage(configure.getSiebelTopic(), siebelMap.getJsonToStr(messageToSiebel));
        } catch (Exception exception) {
            logger.error("UsbLOg:При подготовке и отправке сообщения в Зибель произошла ошибка");
            logger.error("UsbLOg:Trace:", exception);
        }
    }
}
