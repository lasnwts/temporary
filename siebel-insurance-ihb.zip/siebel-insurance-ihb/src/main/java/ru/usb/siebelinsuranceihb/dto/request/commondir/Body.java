package ru.usb.siebelinsuranceihb.dto.request.commondir;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Body {
    @JsonProperty("GetCommonDirectoryRequest")
    public GetCommonDirectoryRequest GetCommonDirectoryRequest;

    public Body() {
    }

    public Body(ru.usb.siebelinsuranceihb.dto.request.commondir.GetCommonDirectoryRequest getCommonDirectoryRequest) {
        GetCommonDirectoryRequest = getCommonDirectoryRequest;
    }

    @JsonProperty("GetCommonDirectoryRequest")
    public ru.usb.siebelinsuranceihb.dto.request.commondir.GetCommonDirectoryRequest getGetCommonDirectoryRequest() {
        return GetCommonDirectoryRequest;
    }

    @JsonProperty("GetCommonDirectoryRequest")
    public void setGetCommonDirectoryRequest(ru.usb.siebelinsuranceihb.dto.request.commondir.GetCommonDirectoryRequest getCommonDirectoryRequest) {
        GetCommonDirectoryRequest = getCommonDirectoryRequest;
    }
}
