package ru.usb.siebelinsuranceihb.dto.request.tquestionnaire;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Question {

    @JsonProperty("QuestionCode")
    public String questionCode;

    @JsonProperty("Answer")
    public String answer;

    public Question() {
        //
    }

    public Question(String questionCode, String answer) {
        this.questionCode = questionCode;
        this.answer = answer;
    }

    public String getQuestionCode() {
        return questionCode;
    }

    public void setQuestionCode(String questionCode) {
        this.questionCode = questionCode;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Question{" +
                "questionCode='" + questionCode + '\'' +
                ", answer='" + answer + '\'' +
                '}';
    }
}
