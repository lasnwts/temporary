package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.dto.response.Body;
import ru.usb.siebelinsuranceihb.dto.response.Envelope;
import ru.usb.siebelinsuranceihb.dto.response.Fault;
import ru.usb.siebelinsuranceihb.dto.response.Detail;


@Component
public class MapperResponseXML {
    Logger logger = LoggerFactory.getLogger(MapperResponseXML.class);
    XmlMapper xmlMapper = new XmlMapper();

/**
 * CollectionType studentsListType = xmlMapper.getTypeFactory().constructCollectionType(List.class, Student.class);
 * List<Student> students = xmlMapper.readValue(xmlFile, studentsListType);
 */

    //XmlMapper xmlMapper = new XmlMapper(module);

    /**
     * Partner XML to POJO
     *
     * @param xmlString
     * @return
     */
    public Envelope getMap(String xmlString) {
        if (xmlString == null) {
            return null;
        } else {
            try {
                xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                xmlMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
                return xmlMapper.readValue(xmlString, Envelope.class);
            } catch (JsonProcessingException e) {
                logger.error("UsbLog: ####################################################################################################");
                logger.error("UsbLog: Ошибка преобразования строки XML {} в POJO", xmlString);
                logger.error("UsbLog: Описание ошибки^ JsonProcessingException:`", e);
                logger.error("UsbLog: ####################################################################################################");
                Fault fault = new Fault();
                if (xmlString.trim().length() > 255) {
                    fault.setFaultstring(xmlString.trim().substring(0, 253));
                } else {
                    fault.setFaultstring(xmlString.trim());
                }
                fault.setFaultcode("2");
                Body body = new Body();
                body.setFault(fault);
                Envelope envelope = new Envelope();
                envelope.setBody(body);
                return envelope;
            }
        }
    }

}
