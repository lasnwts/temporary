package ru.usb.siebelinsuranceihb.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.siebelinsuranceihb.dto.request.GetCommonDirectory;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;
import ru.usb.siebelinsuranceihb.service.flows.FlowSetQuestionnare;
import ru.usb.siebelinsuranceihb.service.mail.ServiceMailError;
import ru.usb.siebelinsuranceihb.utils.AuxMethods;
import ru.usb.siebelinsuranceihb.utils.MapDtoRequest;

@Service
public class MessageProcess {
    Logger logger = LoggerFactory.getLogger(MessageProcess.class);
    private final AuxMethods aux;
    private final ServiceMailError serviceMailError;

    private FlowSetQuestionnare flowSetQuestionnare;

    private MapDtoRequest mapDtoRequest;

    @Autowired
    public MessageProcess(AuxMethods aux, ServiceMailError serviceMailError, FlowSetQuestionnare flowSetQuestionnare, MapDtoRequest mapDtoRequest) {
        this.aux = aux;
        this.serviceMailError = serviceMailError;
        this.flowSetQuestionnare = flowSetQuestionnare;
        this.mapDtoRequest = mapDtoRequest;
    }




    public void processed(MessageFromKafka message){

        if (message == null){
            return;
        }

        if (message.getService() != null && message.getService().toLowerCase().contains("setquestionnaire")){
            logger.info("Объект содержит SetQuestionnaire");
            flowSetQuestionnare.getSetQuestionnaire(message.getPack());
        }

        if (message.getService() != null && message.getService().toLowerCase().contains("getcommondirectory")){
            logger.info("Объект содержит GetCommonDirectory");
            GetCommonDirectory getCommonDirectory = mapDtoRequest.mapMessageToGetCommonDirectory(message.getPack());
            logger.info("Объект GetCommonDirectory={}", getCommonDirectory);
        }

    }



}
