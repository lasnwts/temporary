package ru.usb.siebelinsuranceihb.service;

import org.apache.kafka.common.protocol.types.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.siebelinsuranceihb.configure.Configure;
import ru.usb.siebelinsuranceihb.dto.request.GetCommonDirectory;
import ru.usb.siebelinsuranceihb.dto.request.SetQuestionnaire;
import ru.usb.siebelinsuranceihb.dto.request.commondir.Envelope;
import ru.usb.siebelinsuranceihb.dto.response.Directory;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;
import ru.usb.siebelinsuranceihb.model.ResponseInsurance;
import ru.usb.siebelinsuranceihb.service.flows.FlowSetQuestionnare;
import ru.usb.siebelinsuranceihb.service.mail.ServiceMailError;
import ru.usb.siebelinsuranceihb.service.soap.RestClient;
import ru.usb.siebelinsuranceihb.utils.*;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;

@Service
public class MessageProcess {
    Logger logger = LoggerFactory.getLogger(MessageProcess.class);
    private final AuxMethods aux;
    private final ServiceMailError serviceMailError;
    private final FlowSetQuestionnare flowSetQuestionnare;
    private final MapDtoRequest mapDtoRequest;
    private final FasadeXML fasadeXML;
    private final MapperRequestXML mapperRequestXML;
    private final Configure configure;

    @Autowired
    RestClient restClient;
    @Autowired
    MapperResponseXML mapperResponseXML;

    @Autowired
    SiebelSender siebelSender;

    @Autowired
    MapDtoResponse mapDtoResponse;

    String xmlResponse = null;
    Boolean insuranceResultCode = false;


    @Autowired
    public MessageProcess(AuxMethods aux, ServiceMailError serviceMailError, FlowSetQuestionnare flowSetQuestionnare,
                          MapDtoRequest mapDtoRequest, FasadeXML fasadeXML, MapperRequestXML mapperRequestXML, Configure configure) {
        this.aux = aux;
        this.serviceMailError = serviceMailError;
        this.flowSetQuestionnare = flowSetQuestionnare;
        this.mapDtoRequest = mapDtoRequest;
        this.fasadeXML = fasadeXML;
        this.mapperRequestXML = mapperRequestXML;
        this.configure = configure;
    }

    /**
     * Процесс ообработки сообщения
     *
     * @param message - сообщение из кафки
     */
    public void processed(MessageFromKafka message) {

        if (message == null) {
            logger.error("UsbLog:MessageFromKafka=NULL!");
            return;
        }

        //Константы для формирования ответов, при возникновении проблем
        String SERVER_PROBLEM = "Сервер страховой компании получил запрос, но по каким то причинам не смог обработать запрос. Ошибка 500 (Internal Server Error) — это внутренняя проблема сервера.";
        String NETWORK_PROBLEM = "Невозможно подключиться к серверу страховой компании, ошибка сети.";

        /*************************************************************************************************************************************
         * Блок SetQuestionnaire
         *************************************************************************************************************************************/
        if (message.getService() != null && message.getService().toLowerCase().contains("setquestionnaire")) {
            logger.info("UsbLog:Объект содержит SetQuestionnaire");
            try {
                SetQuestionnaire setQuestionnaire = flowSetQuestionnare.getSetQuestionnaire(message.getPack());
                ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope envelope = mapDtoRequest.getEnvelopeQuestionnaire(setQuestionnaire);
                logger.info("UsbLog:XML:Questionnaire");
                String xmlString = fasadeXML.getFacadeQuestionnaire(mapperRequestXML.getQuestionnaireXML(envelope));
                logger.info("UsbLog:envlelope[Questionnaire] до кодировки в UTF-8={}", xmlString);
                /**
                 * Перекодирование
                 */
                ResponseInsurance responseInsurance = restClient.getRequestInsurance(xmlString, 2);
                logger.info("UsbLog:SetQuestionnaire-ResponseInsurance:{}", responseInsurance);
                if (responseInsurance != null) {
                    xmlResponse = responseInsurance.getMessageBody().trim();
                    insuranceResultCode = responseInsurance.getErrorCode();
                } else {
                    logger.error("UsbLog:!!!!!!!!!!!!!!-");
                    logger.error("UsbLog:Error, ошибка > ResponseInsurance responseInsurance = restClient.getRequestInsurance(xmlString, 2) == NULL!!");
                    logger.error("UsbLog:Cервер ИСЖ вернул NULL, при запросе:{}", aux.getWrapNull(xmlString));
                    logger.error("UsbLog:!!!!!!!!!!!!!!=");
                }

                /**
                 * Обрабатываем ответ от сервера ИСЖ
                 */
                if (xmlResponse != null) {

                    ru.usb.siebelinsuranceihb.dto.response.Envelope envelopeResponse = mapperResponseXML.getMap(xmlResponse);
                    logger.info("UsbLog:ru.usb.siebelinsuranceihb.dto.response.Envelope envelopeResponse");

                    /**
                     * Определение уровня ошибки
                     */
                    int resultCode = getResultCodeQuestionnaire(envelopeResponse);

                    /**
                     * Просто печать
                     */
                    printResponseQuestionnaire(envelopeResponse, resultCode);

                    /**
                     * Отправка в Зибель
                     */
                    //Все в порядке
                    if (resultCode == 0) {
                        String id = null;
                        id = mapDtoResponse.getStrSetQuestionnaireRequest(new ru.usb.siebelinsuranceihb.dto.response.siebel.SetQuestionnaireRequest(envelopeResponse.getBody().getSetQuestionnaireResponse().getQuestionnaireID()));
                        siebelSender.sendToSiebel(id, "SetQuestionnaire", message.getPackID(), false, "");
                    }
                    //Логическая ошибка
                    if (resultCode == 1) {
                        siebelSender.sendToSiebel("", "SetQuestionnaire", message.getPackID(), true, aux.getWrapNull(envelopeResponse.getBody().getSetQuestionnaireResponse().getResult().getResultMessage()));
                    }
                    //Ошибка 500
                    if (resultCode == 2) {
                        siebelSender.sendToSiebel("", "SetQuestionnaire", message.getPackID(), true, SERVER_PROBLEM);
                    }
                    //Проблема со связью
                    if (resultCode == 3) {
                        siebelSender.sendToSiebel("", "GetCommonDirectory", message.getPackID(), true, NETWORK_PROBLEM);
                    }
                } else {
                    logger.error("UsbLog:!!!!!!!!!!!!!!-");
                    logger.error("UsbLog:Error, ошибка > xmlResponse = responseInsurance.getMessageBody().trim() == NULL!!");
                    logger.error("UsbLog:Cервер ИСЖ вернул пустое тело ответа!, при запросе:{}", aux.getWrapNull(xmlString));
                    logger.error("UsbLog:!!!!!!!!!!!!!!=");
                }
            } catch (Exception e) {
                logger.error("UsbLog:SetQuestionnaire: Error:", e);
            }
        } //конец блока SetqQestionnaire

        /*************************************************************************************************************************************
         * Блок GetCommonDirectory
         *************************************************************************************************************************************/
        if (message.getService() != null && message.getService().toLowerCase().contains("getcommondirectory")) {

            try {
                logger.info("UsbLog:Объект содержит GetCommonDirectory");
                GetCommonDirectory getCommonDirectory = mapDtoRequest.mapMessageToGetCommonDirectory(message.getPack());
                logger.info("UsbLog:Получено от Зибель getCommonDirectory={}", getCommonDirectory);
                Envelope envelope = mapDtoRequest.getEnvelope(getCommonDirectory);
                /**
                 * Присваиваем константу
                 */
                envelope.getBody().getGetCommonDirectoryRequest().setPartnerID(configure.getSoapPartnerId());
                logger.info("UsbLog:XML");
                String xmlString = fasadeXML.getFacadePartner(mapperRequestXML.getPartnerXML(envelope));
                logger.info("UsbLog:envlelope1={}", xmlString);
                /**
                 * Отправляем запрос
                 */
                ResponseInsurance responseInsurance = restClient.getRequestInsurance(xmlString, 1);
                if (responseInsurance != null) {
                    xmlResponse = responseInsurance.getMessageBody().trim();
                    insuranceResultCode = responseInsurance.getErrorCode();
                } else {
                    logger.error("UsbLog:!!!!!!!!!!!!!!-");
                    logger.error("UsbLog:Error, ошибка > ResponseInsurance responseInsurance = restClient.getRequestInsurance(xmlString, 1) == NULL!!");
                    logger.error("UsbLog:Cервер ИСЖ вернул NULL, при запросе:{}", aux.getWrapNull(xmlString));
                    logger.error("UsbLog:!!!!!!!!!!!!!!=");
                }

                /**
                 * Обрабатываем ответ от сервера ИСЖ
                 */
                if (xmlResponse != null) {
                    ru.usb.siebelinsuranceihb.dto.response.Envelope envelopeResponse = mapperResponseXML.getMap(xmlResponse);

                    /**
                     * Определение уровня ошибки
                     */
                    int resultCode = getResultCodeDir(envelopeResponse);

                    /**
                     * Просто печать
                     */
                    printResponseDirectory(envelopeResponse, resultCode);

                    /**
                     * Отправка в Зибель
                     */
                    //Все в порядке
                    if (resultCode == 0) {
                        String di = null;
                        di = mapDtoResponse.getStringFromDirectory(new ru.usb.siebelinsuranceihb.dto.response.siebel.Directory(envelopeResponse.getBody().getGetCommonDirectoryResponse().getDirectory()));
                        siebelSender.sendToSiebel(di, "GetCommonDirectory", message.getPackID(), false, "");
                    }
                    //Логическая ошибка
                    if (resultCode == 1) {
                        siebelSender.sendToSiebel("", "GetCommonDirectory", message.getPackID(), true, aux.getWrapNull(envelopeResponse.getBody().getGetCommonDirectoryResponse().getResult().getResultMessage()));
                    }
                    //Ошибка 500
                    if (resultCode == 2) {
                        siebelSender.sendToSiebel("", "GetCommonDirectory", message.getPackID(), true, SERVER_PROBLEM);
                    }
                    //Проблема со связью
                    if (resultCode == 3) {
                        siebelSender.sendToSiebel("", "GetCommonDirectory", message.getPackID(), true, NETWORK_PROBLEM);
                    }
                } else {
                    logger.error("UsbLog:!!!!!!!!!!!!!!-");
                    logger.error("UsbLog:Error, ошибка > xmlResponse = responseInsurance.getMessageBody().trim() == NULL!!");
                    logger.error("UsbLog:Cервер ИСЖ вернул пустое тело ответа!, при запросе:{}", aux.getWrapNull(xmlString));
                    logger.error("UsbLog:!!!!!!!!!!!!!!=");
                    logger.error("UsbLog:Возможно есть проблема со связью с сервером ИСЖ");
                }
            } catch (Exception e) {
                logger.error("UsbLog: Error:", e);
            }
        } // Конец блока GetCommonDirectory

    }


    /**
     * Проеряем какой ответ вернул сервер
     *
     * @param envelope - сообщение от сервера
     * @return - ResultCode
     */
    private int getResultCodeDir(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope) {

        if (envelope == null || envelope.getBody() == null) {
            logger.error("UsbLog:[getResultCode(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope)] => ru.usb.siebelinsuranceihb.dto.response.Envelope = NULL!");
            logger.error("UsbLog:Возвращаю код 3");
            return 3;
        } else {
            /**
             * Присутствует секция Fault - все плохо
             */
            if (envelope.getBody().getFault() != null) {
                logger.error("UsbLog:[getResultCode(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope)] => Присутствует секция Fault в ответе");
                logger.error("UsbLog:[getResultCode => Присутствует секция Fault в ответе:{}", aux.getWrapNull(envelope.getBody().getFault().toString()));
                logger.error("UsbLog:Возвращаю код 2");
                return 2;
            } else {
                /**
                 * Успешный ответ - есть секция Result? Или нет?
                 */
                if (envelope.getBody().getGetCommonDirectoryResponse() != null && envelope.getBody().getGetCommonDirectoryResponse().getResult() != null) {
                    if (envelope.getBody().getGetCommonDirectoryResponse().getResult().getResultCode() != null) {
                        /**
                         * Проверяем код = ок или error
                         */
                        if (envelope.getBody().getGetCommonDirectoryResponse().getResult().getResultCode().toLowerCase().contains("ok")) {
                            logger.info("UsbLog:Ответ Response GetCommonDirectory успешный, возвращаю после проверки код 0");
                            return 0;
                        } else {
                            /**
                             * Секция содержит информацию об ошибке в Result Code
                             */
                            logger.info("UsbLog:Логическая ошибка, код содержит ERROR в Response GetCommonDirectory, возвращаю после проверки код 1");
                            return 1;
                        }
                    } else {
                        /**
                         * Секция Result есть, но в ней нет ResultCode! Ошибка = 2
                         */
                        /**
                         *  Нет секции Result - тоже ошибка
                         */
                        logger.error("UsbLog:Непонятная ошибка, нет секции Result в ответе");
                        logger.error("UsbLog:Возвращаю код 2");
                        return 2;
                    }
                } else {
                    /**
                     *  Нет секции Result - тоже ошибка
                     */
                    logger.error("UsbLog:Непонятная ошибка, нет секции Result в ответе");
                    logger.error("UsbLog:Возвращаю код 2");
                    return 2;
                }
            }
        }
    }


    /**
     * Проеряем какой ответ вернул сервер
     *
     * @param envelope - сообщение от сервера
     * @return - ResultCode
     */
    private int getResultCodeQuestionnaire(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope) {

        if (envelope == null || envelope.getBody() == null) {
            logger.error("UsbLog:[getResultCode(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope)] => ru.usb.siebelinsuranceihb.dto.response.Envelope = NULL!");
            logger.error("UsbLog:Возвращаю код 3");
            return 3;
        } else {
            /**
             * Присутствует секция Fault - все плохо
             */
            if (envelope.getBody().getFault() != null) {
                logger.error("UsbLog:[getResultCode(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope)] => Присутствует секция Fault в ответе");
                logger.error("UsbLog:[getResultCode => Присутствует секция Fault в ответе:{}", aux.getWrapNull(envelope.getBody().getFault().toString()));
                logger.error("UsbLog:Возвращаю код 2");
                return 2;
            } else {
                /**
                 * Успешный ответ - есть секция Result? Или нет?
                 */
                if (envelope.getBody().getSetQuestionnaireResponse() != null && envelope.getBody().getSetQuestionnaireResponse().getResult() != null) {
                    if (envelope.getBody().getSetQuestionnaireResponse().getResult().getResultCode() != null) {
                        /**
                         * Проверяем код = ок или error
                         */
                        if (envelope.getBody().getSetQuestionnaireResponse().getResult().getResultCode().toLowerCase().contains("ok")) {
                            logger.info("UsbLog:Ответ Response Questionnaire успешный, возвращаю после проверки код 0");
                            return 0;
                        } else {
                            /**
                             * Секция содержит информацию об ошибке в Result Code
                             */
                            logger.info("UsbLog:Логическая ошибка, код содержит ERROR в Response Questionnaire, возвращаю после проверки код 1");
                            return 1;
                        }
                    } else {
                        /**
                         * Секция Result есть, но в ней нет ResultCode! Ошибка = 2
                         */
                        /**
                         *  Нет секции Result - тоже ошибка
                         */
                        logger.error("UsbLog:Непонятная ошибка, нет секции Result в ответе");
                        logger.error("UsbLog:Возвращаю код 2");
                        return 2;
                    }
                } else {
                    /**
                     *  Нет секции Result - тоже ошибка
                     */
                    logger.error("UsbLog:Непонятная ошибка, нет секции Result в ответе");
                    logger.error("UsbLog:Возвращаю код 2");
                    return 2;
                }
            }
        }
    }

    /**
     * Функция печате, ответа по CommonDirectory
     *
     * @param envelope   Object Response from ИСЖ
     * @param resultCode - код успешности
     */
    private void printResponseDirectory(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope, int resultCode) {

        /**
         * Все плохо, Envelope == NULL
         */
        if (resultCode == 3) {
            logger.info("UsbLog:printResponseDirectory: responseErrorPartner Error: По какой то причине не удалось распарсить ответ сервера в Response.Envelope");
        }

        /**
         * Системная ошибка
         */
        if (resultCode == 2) {
            if (envelope.getBody().getFault() != null) {
                logger.info("UsbLog:responseErrorPartner Error:getFault().getFaultcode={}", envelope.getBody().getFault().getFaultcode());
                logger.info("UsbLog:responseErrorPartner Error:getFault().getFaultstring={}", envelope.getBody().getFault().getFaultstring());
            }
            if (envelope.getBody().getFault() != null && envelope.getBody().getFault().getDetail() != null && envelope.getBody().getFault().getDetail().getException() != null) {
                logger.info("UsbLog:responseErrorPartner Error:getFault().detail.getException()={}", envelope.getBody().getFault().getDetail().getException());
            }
        }

        /**
         * Логическая ошибка, видимо не найден договор
         */
        if (resultCode == 1) {
            if (envelope.getBody().getGetCommonDirectoryResponse() != null && envelope.getBody().getGetCommonDirectoryResponse().getResult() != null) {
                logger.info("UsbLog:Result, error, Partner GetResult ={}", envelope.getBody().getGetCommonDirectoryResponse().getResult().toString());
            }
        }

        /**
         * Все успешно, печатаем результат
         */
        if (resultCode == 0) {
            logger.info("UsbLog:Result, success, Result={}", envelope.getBody().getGetCommonDirectoryResponse().getResult().toString());
            logger.info("UsbLog:Result, success, DirectoryID={}", envelope.getBody().getGetCommonDirectoryResponse().getDirectoryID().toString());
            logger.info("UsbLog:Секция Directory[]");
            if (envelope.getBody().getGetCommonDirectoryResponse().getDirectory() != null) {
                envelope.getBody().getGetCommonDirectoryResponse().getDirectory().forEach(new Consumer<Directory>() {
                    @Override
                    public void accept(Directory directory) {
                        logger.info("UsbLog:Code:{}", directory.getCode());
                        logger.info("UsbLog:Value:{}", directory.getValue());
                    }
                });
            }
        }
    }

    /**
     * Функция печате, ответа по CommonDirectory
     *
     * @param envelope   Object Response from ИСЖ
     * @param resultCode - код успешности
     */
    private void printResponseQuestionnaire(ru.usb.siebelinsuranceihb.dto.response.Envelope envelope, int resultCode) {

        /**
         * Все плохо, Envelope == NULL
         */
        if (resultCode == 3) {
            logger.info("UsbLog:printResponseDirectory: responseErrorPartner Error: По какой то причине не удалось распарсить ответ сервера в Response.Envelope");
        }

        /**
         * Системная ошибка
         */
        if (resultCode == 2) {
            if (envelope.getBody().getFault() != null) {
                logger.info("UsbLog:responseErrorPartner Error:getFault().getFaultcode={}", envelope.getBody().getFault().getFaultcode());
                logger.info("UsbLog:responseErrorPartner Error:getFault().getFaultstring={}", envelope.getBody().getFault().getFaultstring());
            }
            if (envelope.getBody().getFault() != null && envelope.getBody().getFault().getDetail() != null && envelope.getBody().getFault().getDetail().getException() != null) {
                logger.info("UsbLog:responseErrorPartner Error:getFault().detail.getException()={}", envelope.getBody().getFault().getDetail().getException());
            }
        }

        /**
         * Логическая ошибка, видимо не найден договор
         */
        if (resultCode == 1) {
            if (envelope.getBody().getSetQuestionnaireResponse() != null && envelope.getBody().getSetQuestionnaireResponse().getResult() != null) {
                logger.info("UsbLog:Result, error, tQuestionnaire GetResult ={}", envelope.getBody().getSetQuestionnaireResponse().getResult().toString());
            }
        }

        /**
         * Все успешно, печатаем результат
         */
        if (resultCode == 0) {
            logger.info("UsbLog:Result, success, Result={}", envelope.getBody().getSetQuestionnaireResponse().getResult().toString());
            logger.info("UsbLog:Result, success, QuestionnaireID={}", envelope.getBody().getSetQuestionnaireResponse().getQuestionnaireID().toString());
        }
    }


}
