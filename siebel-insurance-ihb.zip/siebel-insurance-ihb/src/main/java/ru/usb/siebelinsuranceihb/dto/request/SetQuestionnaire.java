package ru.usb.siebelinsuranceihb.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetQuestionnaire {
    @JsonProperty("PartnerId")
    public String partnerId;
    @JsonProperty("UserPartnerId")
    public String userPartnerId ;
    @JsonProperty("QuestionnaireCode")
    public String questionnaireCode;
    @JsonProperty("QuestionList")
    public ArrayList<QuestionList> questionList;
    public SetQuestionnaire() {
        //
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getUserPartnerId() {
        return userPartnerId;
    }

    public void setUserPartnerId(String userPartnerId) {
        this.userPartnerId = userPartnerId;
    }

    public String getQuestionnaireCode() {
        return questionnaireCode;
    }

    public void setQuestionnaireCode(String questionnaireCode) {
        this.questionnaireCode = questionnaireCode;
    }

    public ArrayList<QuestionList> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(ArrayList<QuestionList> questionList) {
        this.questionList = questionList;
    }

    @Override
    public String toString() {
        return "SetQuestionnaire{" +
                "partnerId='" + partnerId + '\'' +
                ", userPartnerId='" + userPartnerId + '\'' +
                ", questionnaireCode='" + questionnaireCode + '\'' +
                ", questionList=" + questionList +
                '}';
    }
}
