package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.dto.response.siebel.Directory;
import ru.usb.siebelinsuranceihb.dto.response.siebel.SetQuestionnaireRequest;


import java.util.List;


@Component
public class MapDtoResponse {

    Logger logger = LoggerFactory.getLogger(MapDtoResponse.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Преобразование объекта в строку JSON
     *
     * @param directoryList объект
     * @return - строка Json
     */
    public String getStringFromDirectory(Directory directoryList) {

        if (directoryList == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [List<Directory> directoryList] == NULL! Класс [MapDto]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(directoryList);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [List<Directory> directoryList]] в JSON строку! Класс [MapDto] метод [[List<Directory> directoryList]]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

    /**
     * SetQuestionnaire (Response)
     * @param soSendSdTaskIn - объект запроса
     * @return
     */
    public String getStrSetQuestionnaireRequest(SetQuestionnaireRequest soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [SetQuestionnaireRequest.Response] == NULL! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [SetQuestionnaireRequest.Response] в JSON строку! Класс [MapDto] метод [SetQuestionnaireRequest]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }


}

