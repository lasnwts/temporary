package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;


@Component
public class MapperMessSiebel {
    Logger logger = LoggerFactory.getLogger(MapperMessSiebel.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Преобразование объекта в строку JSON
     *
     * @param soSendSdTaskIn объект
     * @return - строка Json
     */
    public String getJsonToStr(MessageFromKafka soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [MessageFromKafka] == NULL! Класс [SiebelMapper] метод [getJsonToStr]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [MessageFromKafka] в JSON строку! Класс [SiebelMapper] метод [getJsonToStr]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

}
