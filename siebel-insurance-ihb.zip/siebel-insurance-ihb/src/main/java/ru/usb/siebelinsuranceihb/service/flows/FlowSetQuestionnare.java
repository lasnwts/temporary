package ru.usb.siebelinsuranceihb.service.flows;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.siebelinsuranceihb.dto.request.SetQuestionnaire;
import ru.usb.siebelinsuranceihb.service.mail.ServiceMailError;
import ru.usb.siebelinsuranceihb.utils.MapDtoRequest;

@Service
public class FlowSetQuestionnare {

    private final MapDtoRequest mapDtoRequest;

    private final ServiceMailError serviceMailError;


    @Autowired
    public FlowSetQuestionnare(MapDtoRequest mapDtoRequest, ServiceMailError serviceMailError) {
        this.mapDtoRequest = mapDtoRequest;
        this.serviceMailError = serviceMailError;
    }

    Logger logger = LoggerFactory.getLogger(FlowSetQuestionnare.class);

    public SetQuestionnaire getSetQuestionnaire(String message){
        /**
         * Сообщение по Kafka, готовим
         */

        SetQuestionnaire setQuestionnaire = mapDtoRequest.mapMessageToSetQuestionnaire(message);

        if (setQuestionnaire == null) {
            logger.error("UsbLog:ERROR[SetQuestionnaire(message)]]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Сообщение не распарсилось!!:{}", message);
            logger.error("UsbLog:ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            serviceMailError.sendMailError("Возникла ошибка при обработке сообщения из Siebel Поток 3.1. Проект 3197 (Siebel->Мобильное приложение)." + "\n\r\"" +
                    "ERROR[(message)]],Сообщение не распарсилось в MessageFromKafka!!" + "\n\r\"" + message.trim());

        } else {

            logger.info("UsbLog:Объект распарсен: {}", setQuestionnaire);
        }
        return setQuestionnaire;
    }

}
