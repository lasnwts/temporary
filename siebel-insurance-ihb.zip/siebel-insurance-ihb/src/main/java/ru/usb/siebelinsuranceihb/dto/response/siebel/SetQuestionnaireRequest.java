package ru.usb.siebelinsuranceihb.dto.response.siebel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetQuestionnaireRequest {

    @JsonProperty("QuestionnaireID")
    public String questionnaireID;

    public SetQuestionnaireRequest() {
        //
    }

    public SetQuestionnaireRequest(String questionnaireID) {
        this.questionnaireID = questionnaireID;
    }

    @JsonProperty("QuestionnaireID")
    public String getQuestionnaireID() {
        return questionnaireID;
    }

    @JsonProperty("QuestionnaireID")
    public void setQuestionnaireID(String questionnaireID) {
        this.questionnaireID = questionnaireID;
    }

    @Override
    public String toString() {
        return "SetQuestionnaireRequest{" +
                "questionnaireID='" + questionnaireID + '\'' +
                '}';
    }
}
