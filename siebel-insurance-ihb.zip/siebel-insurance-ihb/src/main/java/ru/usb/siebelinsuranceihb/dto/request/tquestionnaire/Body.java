package ru.usb.siebelinsuranceihb.dto.request.tquestionnaire;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Body {

    @JsonProperty("SetQuestionnaireRequest")
    private SetQuestionnaireRequest setQuestionnaireRequest;

    public Body() {
        //
    }

    public Body(SetQuestionnaireRequest setQuestionnaireRequest) {
        this.setQuestionnaireRequest = setQuestionnaireRequest;
    }

    @JsonProperty("SetQuestionnaireRequest")
    public SetQuestionnaireRequest getSetQuestionnaireRequest() {
        return setQuestionnaireRequest;
    }

    @JsonProperty("SetQuestionnaireRequest")
    public void setSetQuestionnaireRequest(SetQuestionnaireRequest setQuestionnaireRequest) {
        this.setQuestionnaireRequest = setQuestionnaireRequest;
    }
}
