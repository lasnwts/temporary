package ru.usb.siebelinsuranceihb.dto.request.commondir;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "Envelope")
public class Envelope {
    @JsonProperty("Header")
    public Object Header;

    @JsonProperty("Body")
    @JacksonXmlProperty(localName = "Body")
    public Body Body;

    @JsonProperty("soapenv")
    public String soapenv;

    public Envelope() {
        //
    }

    public Envelope(ru.usb.siebelinsuranceihb.dto.request.commondir.Body body) {
        Body = body;
    }

    @JsonProperty("Header")
    public Object getHeader() {
        return Header;
    }

    @JsonProperty("Header")
    public void setHeader(Object header) {
        Header = header;
    }

    @JsonProperty("Body")
    public ru.usb.siebelinsuranceihb.dto.request.commondir.Body getBody() {
        return Body;
    }

    @JsonProperty("Body")
    public void setBody(ru.usb.siebelinsuranceihb.dto.request.commondir.Body body) {
        Body = body;
    }

    @JsonProperty("soapenv")
    public String getSoapenv() {
        return soapenv;
    }

    @JsonProperty("soapenv")
    public void setSoapenv(String soapenv) {
        this.soapenv = soapenv;
    }


    @Override
    public String toString() {
        return "Envelope{" +
                "Header=" + Header +
                ", Body=" + Body +
                ", soapenv='" + soapenv + '\'' +
                '}';
    }
}
