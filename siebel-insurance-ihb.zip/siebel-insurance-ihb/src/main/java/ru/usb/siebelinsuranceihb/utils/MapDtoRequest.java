package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.dto.request.GetCommonDirectory;
import ru.usb.siebelinsuranceihb.dto.request.SetQuestionnaire;


@Component
public class MapDtoRequest {

    Logger logger = LoggerFactory.getLogger(MapDtoRequest.class);
    ObjectMapper objectMapper = new ObjectMapper();

    private final Utilites utilites;

    @Autowired
    public MapDtoRequest(Utilites utilites) {
        this.utilites = utilites;
    }

    /**
     * Преобразование объекта в строку JSON
     *
     * @param soSendSdTaskIn объект
     * @return - строка Json
     */
    public String getStrSetQuestionnaire(SetQuestionnaire soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [SetQuestionnaire.Request] == NULL! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [SetQuestionnaire.Request] в JSON строку! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

    /**
     *     //GetCommonDirectory (Request)
     * @param soSendSdTaskIn - объект запроса
     * @return
     */
    public String getStrGetCommonDirectory(GetCommonDirectory soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [SetQuestionnaire.Request] == NULL! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [SetQuestionnaire.Request] в JSON строку! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }


    /**
     * Мапинг строки в объект GetCommonDirectory
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public GetCommonDirectory mapMessageToGetCommonDirectory(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            logger.error("На маппер [GetCommonDirectory]:[кугйуые] поступил объект [message] == NULL! Класс [GetCommonDirectory] метод [mapMessageToGetCommonDirectory]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+");
            return null;
        }

        GetCommonDirectory getCommonDirectory = null;

        try {
            getCommonDirectory = objectMapper.readValue(utilites.wrapNullJson(message), GetCommonDirectory.class);
            logger.info("Object [GetCommonDirectory]:{}", getCommonDirectory);
            return getCommonDirectory;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Мапинг строки в объект SetQuestionnaire
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public SetQuestionnaire mapMessageToSetQuestionnaire(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [SetQuestionnaire]:[request] поступил объект [message] == NULL! Класс [SetQuestionnaire] метод [mapMessageToSetQuestionnaire]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        SetQuestionnaire setQuestionnaire = null;

        try {
            setQuestionnaire = objectMapper.readValue(utilites.wrapNullJson(message), SetQuestionnaire.class);
            logger.info("Object [GetCommonDirectory]:{}", setQuestionnaire);
            return setQuestionnaire;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

}
