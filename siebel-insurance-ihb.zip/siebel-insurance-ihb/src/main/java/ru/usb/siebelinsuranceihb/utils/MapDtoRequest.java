package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.configure.Configure;
import ru.usb.siebelinsuranceihb.dto.request.GetCommonDirectory;
import ru.usb.siebelinsuranceihb.dto.request.QuestionList;
import ru.usb.siebelinsuranceihb.dto.request.SetQuestionnaire;
import ru.usb.siebelinsuranceihb.dto.request.commondir.Body;
import ru.usb.siebelinsuranceihb.dto.request.commondir.Envelope;
import ru.usb.siebelinsuranceihb.dto.request.commondir.GetCommonDirectoryRequest;
import ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Question;
import ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.SetQuestionnaireRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;


@Component
public class MapDtoRequest {

    Logger logger = LoggerFactory.getLogger(MapDtoRequest.class);
    ObjectMapper objectMapper = new ObjectMapper();

    private final Utilites utilites;

    private final Configure configure;

    @Autowired
    public MapDtoRequest(Utilites utilites, Configure configure) {
        this.utilites = utilites;
        this.configure = configure;
    }


    /**
     * Преобразование объекта в строку JSON
     *
     * @param soSendSdTaskIn объект
     * @return - строка Json
     */
    public String getStrSetQuestionnaire(SetQuestionnaire soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [SetQuestionnaire.Request] == NULL! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [SetQuestionnaire.Request] в JSON строку! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }

    /**
     * //GetCommonDirectory (Request)
     *
     * @param soSendSdTaskIn - объект запроса
     * @return
     */
    public String getStrGetCommonDirectory(GetCommonDirectory soSendSdTaskIn) {

        if (soSendSdTaskIn == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [SetQuestionnaire.Request] == NULL! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(soSendSdTaskIn);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [SetQuestionnaire.Request] в JSON строку! Класс [MapDto] метод [getStrSetQuestionnaire]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }


    /**
     * Мапинг строки в объект GetCommonDirectory
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public GetCommonDirectory mapMessageToGetCommonDirectory(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            logger.error("На маппер [GetCommonDirectory]:[кугйуые] поступил объект [message] == NULL! Класс [GetCommonDirectory] метод [mapMessageToGetCommonDirectory]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+");
            return null;
        }

        GetCommonDirectory getCommonDirectory = null;

        try {
            getCommonDirectory = objectMapper.readValue(utilites.wrapNullJson(message), GetCommonDirectory.class);
            logger.info("UsbLog:Object [GetCommonDirectory]:{}", getCommonDirectory);
            return getCommonDirectory;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Мапинг строки в объект SetQuestionnaire
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public SetQuestionnaire mapMessageToSetQuestionnaire(String message) {

        if (message == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер [SetQuestionnaire]:[request] поступил объект [message] == NULL! Класс [SetQuestionnaire] метод [mapMessageToSetQuestionnaire]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        SetQuestionnaire setQuestionnaire = null;

        try {
            setQuestionnaire = objectMapper.readValue(utilites.wrapNullJson(message), SetQuestionnaire.class);
            logger.info("UsbLog: Object [GetCommonDirectory]:{}", setQuestionnaire);
            return setQuestionnaire;
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:Warning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLog:Warning : StackTrace:", e);
            return null;
        }
    }


    /**
     * Получаем объект для отправки
     *
     * @param getCommonDirectory - распознанный объект из Зибель
     * @return - готовый объект
     */
    public Envelope getEnvelope(GetCommonDirectory getCommonDirectory) {
        if (getCommonDirectory == null) {
            logger.error("UsbLog: getEnvelope(GetCommonDirectory getCommonDirectory) = NULL!");
            return null;
        } else {
            GetCommonDirectoryRequest getCommonDirectoryRequest = new GetCommonDirectoryRequest(getCommonDirectory.getPartnerId(),
                    getCommonDirectory.getUserPartnerId(), getCommonDirectory.getDirectoryID());
            Body body = new Body(getCommonDirectoryRequest);
            Envelope envelope = new Envelope(body);
            return envelope;
        }
    }


    /**
     * Получаем готовое тело запроса к ИСЖ
     *
     * @param setQuestionnaire - объект из Siebel
     * @return - готовый объект Envelope
     */
    public ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope getEnvelopeQuestionnaire(SetQuestionnaire setQuestionnaire) {
        /**
         * Создаем запрос в ИСЖ
         */
        if (setQuestionnaire == null) {
            logger.error("UsbLog: Ошибка - объект setQuestionnaire - передан NULL!");
            return null;
        } else {

            try {
                /**
                 * Создаем SetQuestionnaireRequest
                 */
                SetQuestionnaireRequest setQuestionnaireRequest = new SetQuestionnaireRequest();
                setQuestionnaireRequest.setExtUserGuid(setQuestionnaire.getUserPartnerId());
                setQuestionnaireRequest.setPartnerID(configure.getSoapPartnerId()); //Присваиваем константу 300
                setQuestionnaireRequest.setQuestionnaireCode(setQuestionnaire.getQuestionnaireCode());
                ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Body body = new ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Body(setQuestionnaireRequest);

                /**
                 * Создаем запрос в ИСЖ
                 */
                if (setQuestionnaire.getQuestionList() != null && setQuestionnaire.getQuestionList().size() > 0) {
                    List<Question> questionListEnv = new ArrayList<>();
                    setQuestionnaire.getQuestionList().forEach(new Consumer<QuestionList>() {
                        @Override
                        public void accept(QuestionList questionList) {
                            Question question = new Question(questionList.getQuestionCode(), questionList.getAnswer());
                            questionListEnv.add(question);
                        }
                    });
                    ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.QuestionList questionList = new ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.QuestionList(questionListEnv);

                    body.getSetQuestionnaireRequest().setQuestionList(questionList);
                }
                ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope envelope = new ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope(body);
                return envelope;
            } catch (Exception exception) {
                logger.error("UsbLog: Ошибка создания объекта [ru.usb.siebelinsuranceihb.dto.request.tquestionnaire.Envelope]");
                logger.error("UsbLog: ", exception);
                return null;
            }
        }
    }
}
