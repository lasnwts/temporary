package ru.usb.siebelinsuranceihb.dto.request.tquestionnaire;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetQuestionnaireRequest {

    @JsonProperty("QuestionList")
    private QuestionList questionList;

//    @JsonProperty("QuestionList")
//    private List<Question> questionList;

    @JsonProperty("PartnerID")
    private String partnerID;

    @JsonProperty("ExtUserGuid")
    private String extUserGuid;

    @JsonProperty("QuestionnaireCode")
    private String questionnaireCode;

    public SetQuestionnaireRequest() {
        //
    }

    public SetQuestionnaireRequest(QuestionList questionList, String partnerID, String extUserGuid, String questionnaireCode) {
        this.questionList = questionList;
        this.partnerID = partnerID;
        this.extUserGuid = extUserGuid;
        this.questionnaireCode = questionnaireCode;
    }

    @JsonProperty("QuestionList")
    public QuestionList getQuestionList() {
        return questionList;
    }

    @JsonProperty("QuestionList")
    public void setQuestionList(QuestionList questionList) {
        this.questionList = questionList;
    }

    @JsonProperty("PartnerID")
    public String getPartnerID() {
        return partnerID;
    }

    @JsonProperty("PartnerID")
    public void setPartnerID(String partnerID) {
        this.partnerID = partnerID;
    }

    @JsonProperty("ExtUserGuid")
    public String getExtUserGuid() {
        return extUserGuid;
    }

    @JsonProperty("ExtUserGuid")
    public void setExtUserGuid(String extUserGuid) {
        this.extUserGuid = extUserGuid;
    }

    @JsonProperty("QuestionnaireCode")
    public String getQuestionnaireCode() {
        return questionnaireCode;
    }

    @JsonProperty("QuestionnaireCode")
    public void setQuestionnaireCode(String questionnaireCode) {
        this.questionnaireCode = questionnaireCode;
    }

    @Override
    public String toString() {
        return "SetQuestionnaireRequest{" +
                "questionList=" + questionList +
                ", partnerID='" + partnerID + '\'' +
                ", extUserGuid='" + extUserGuid + '\'' +
                ", questionnaireCode='" + questionnaireCode + '\'' +
                '}';
    }
}
