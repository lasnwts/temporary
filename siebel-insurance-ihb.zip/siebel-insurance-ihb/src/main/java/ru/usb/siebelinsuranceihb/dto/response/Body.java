package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "Body")
public class Body {
    @JsonProperty("GetCommonDirectoryResponse")
    public GetCommonDirectoryResponse GetCommonDirectoryResponse;

    @JsonProperty("SetQuestionnaireResponse")
    public SetQuestionnaireResponse SetQuestionnaireResponse;

    @JsonProperty("Fault")
    public Fault Fault;

    public Body() {
        //
    }

    @JsonProperty("Fault")
    public Fault getFault() {
        return Fault;
    }

    @JsonProperty("Fault")
    public void setFault(Fault fault) {
        Fault = fault;
    }

    @JsonProperty("GetCommonDirectoryResponse")
    public ru.usb.siebelinsuranceihb.dto.response.GetCommonDirectoryResponse getGetCommonDirectoryResponse() {
        return GetCommonDirectoryResponse;
    }

    @JsonProperty("SetQuestionnaireResponse")
    public ru.usb.siebelinsuranceihb.dto.response.SetQuestionnaireResponse getSetQuestionnaireResponse() {
        return SetQuestionnaireResponse;
    }

    @JsonProperty("SetQuestionnaireResponse")
    public void setSetQuestionnaireResponse(ru.usb.siebelinsuranceihb.dto.response.SetQuestionnaireResponse setQuestionnaireResponse) {
        SetQuestionnaireResponse = setQuestionnaireResponse;
    }

    @Override
    public String toString() {
        return "Body{" +
                "GetCommonDirectoryResponse=" + GetCommonDirectoryResponse +
                ", SetQuestionnaireResponse=" + SetQuestionnaireResponse +
                ", Fault=" + Fault +
                '}';
    }

    @JsonProperty("GetCommonDirectoryResponse")
    public void setGetCommonDirectoryResponse(ru.usb.siebelinsuranceihb.dto.response.GetCommonDirectoryResponse getCommonDirectoryResponse) {
        GetCommonDirectoryResponse = getCommonDirectoryResponse;
    }
}
