package ru.usb.siebelinsuranceihb.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Класс вспомогательных методов
 */
@Component
public class AuxMethods {
    Logger logger = LoggerFactory.getLogger(AuxMethods.class);

    /**
     * Форматы дат
     */
    private final DateFormat siebelTimeFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    private final DateFormat siebelDateFormat = new SimpleDateFormat("MM/dd/yyyy");
    private final DateFormat mpDateFormat = new SimpleDateFormat("yyyy-MM-dd");


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }


    /**
     * Проверка соответствия даты определенному формату MM/dd/yyyy HH:mm:ss
     * @param date - строка с датой
     * @return - true - соответствует. false -нет
     */
    public boolean checkDateTime(String date) {
        if (date != null) {
            try {
                parseDate(date, siebelTimeFormat);
                return true;
            } catch (Exception ex) {
                logger.error("UsbLog: Переданная дата={} - не соответствует формату  MM/dd/yyyy HH:mm:ss", date);
                return false;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL[checkDateTime]");
            return false;
        }
    }

    /**
     * Проверка соответствия даты определенному формату MM/dd/yyyy
     * @param date - строка с датой
     * @return - true - соответствует. false -нет
     */
    public boolean checkDate(String date) {
        if (date != null) {
            try {
                parseDate(date, siebelDateFormat);
                return true;
            } catch (Exception ex) {
                logger.error("UsbLog: Переданная дата={} - не соответствует формату  MM/dd/yyyy", date);
                return false;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL!");
            return false;
        }
    }


    /**
     * Переформатирование даты из формата MM/dd/yyyy -> yyyy-MM-dd
     * @param date
     * @return
     */
    public String getMpDate(String date){
        if (date != null) {
            try {
              return mpDateFormat.format(parseDate(date, siebelDateFormat));
            } catch (Exception ex) {
                logger.error("UsbLog: Переданная дата={} - не соответствует формату  MM/dd/yyyy", date);
                return "";
            }
        } else {
            logger.error("UsbLog: Переданная [getMpDate] дата=NULL");
            return "";
        }
    }

    /**
     * Переформатирование даты из формата MM/dd/yyyy HH:mm:ss -> yyyy-MM-dd
     * @param date
     * @return
     */
    public String getMpDateTime(String date){
        if (date != null) {
            try {
                return mpDateFormat.format(parseDate(date, siebelTimeFormat));
            } catch (Exception ex) {
                logger.error("UsbLog: Переданная дата={} - не соответствует формату  MM/dd/yyyy HH:mm:ss ", date);
                return "";
            }
        } else {
            logger.error("UsbLog: Переданная [getMpDateTime] дата=NULL");
            return "";
        }
    }

    /**
     * Проеобразование даты в Long
     * @param date - дата в форомате date.util
     * @return - long
     */
    public Long unixTimestamp(Date date) {
        return (date.getTime());
    }

    /**
     * Преобразовение даты из строки в Date
     * @param date - строка в виде даты
     * @return - Date
     */
    public Date parseDate(String date, DateFormat df) {
        if (date != null) {
            try {
                return df.parse(date);
            } catch (ParseException e) {
                logger.error("UsbLog: parseDate => Переданная дата={} - не соответствует формату  MM/dd/yyyy HH:mm:ss", date);
                return null;
            }
        } else {
            logger.error("UsbLog: Переданная дата=NULL");
            return null;
        }
    }


    /**
     * Функция получения строки типа Unix date Long из даты
     * @param date - строка в формате MM/dd/yyyy HH:mm:ss
     * @return - строка Long Unix date time
     */
    public String getUnixTime(String date) {
        return unixTimestamp(parseDate(date, siebelTimeFormat)).toString();
    }

}
