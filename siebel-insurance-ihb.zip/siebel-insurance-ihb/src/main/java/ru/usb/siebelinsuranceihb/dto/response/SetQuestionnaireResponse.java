package ru.usb.siebelinsuranceihb.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "SetQuestionnaireResponse")
public class SetQuestionnaireResponse {

    @JsonProperty("Result")
    public Result Result;

    @JsonProperty("QuestionnaireID")
    public String QuestionnaireID;

    public SetQuestionnaireResponse() {
        //
    }

    public SetQuestionnaireResponse(ru.usb.siebelinsuranceihb.dto.response.Result result, String questionnaireID) {
        this.Result = result;
        this.QuestionnaireID = questionnaireID;
    }

    @JsonProperty("Result")
    public ru.usb.siebelinsuranceihb.dto.response.Result getResult() {
        return Result;
    }

    @JsonProperty("Result")
    public void setResult(ru.usb.siebelinsuranceihb.dto.response.Result result) {
        Result = result;
    }

    @JsonProperty("QuestionnaireID")
    public String getQuestionnaireID() {
        return QuestionnaireID;
    }

    @JsonProperty("QuestionnaireID")
    public void setQuestionnaireID(String questionnaireID) {
        QuestionnaireID = questionnaireID;
    }

    @Override
    public String toString() {
        return "SetQuestionnaireResponse{" +
                "Result=" + Result +
                ", QuestionnaireID='" + QuestionnaireID + '\'' +
                '}';
    }
}
