package ru.usb.siebelinsuranceihb.dto.request.commondir;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.kafka.common.protocol.types.Field;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCommonDirectoryRequest {

    @JsonProperty("PartnerID")
    public String PartnerID;

    @JsonProperty("ExtUserGuid")
    public String ExtUserGuid;

    @JsonProperty("DirectoryID")
    public String DirectoryID;

    public GetCommonDirectoryRequest() {
    }

    public GetCommonDirectoryRequest(String partnerID, String extUserGuid, String directoryID) {
        PartnerID = partnerID;
        ExtUserGuid = extUserGuid;
        DirectoryID = directoryID;
    }

    @JsonProperty("PartnerID")
    public String getPartnerID() {
        return PartnerID;
    }

    @JsonProperty("PartnerID")
    public void setPartnerID(String partnerID) {
        PartnerID = partnerID;
    }


    @JsonProperty("ExtUserGuid")
    public String getExtUserGuid() {
        return ExtUserGuid;
    }

    @JsonProperty("ExtUserGuid")
    public void setExtUserGuid(String extUserGuid) {
        ExtUserGuid = extUserGuid;
    }

    @JsonProperty("DirectoryID")
    public String getDirectoryID() {
        return DirectoryID;
    }

    @JsonProperty("DirectoryID")
    public void setDirectoryID(String directoryID) {
        DirectoryID = directoryID;
    }

    @Override
    public String toString() {
        return "GetCommonDirectoryRequest{" +
                "PartnerID=" + PartnerID +
                ", ExtUserGuid='" + ExtUserGuid + '\'' +
                ", DirectoryID='" + DirectoryID + '\'' +
                '}';
    }
}
