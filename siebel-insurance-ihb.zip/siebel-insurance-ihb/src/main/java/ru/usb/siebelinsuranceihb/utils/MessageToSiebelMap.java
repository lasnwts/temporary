package ru.usb.siebelinsuranceihb.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.siebelinsuranceihb.model.MessageFromKafka;


@Component
public class MessageToSiebelMap {
    Logger logger = LoggerFactory.getLogger(MessageToSiebelMap.class);
    ObjectMapper objectMapper = new ObjectMapper();
    /**
     * Преобразование объекта в строку JSON
     *
     * @param message объект
     * @return - строка Json
     */
    public String getJsonToStr(MessageFromKafka message) {

        if (message == null) {
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [MessageFromKafka] == NULL! Класс [message] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [MessageFromKafka] в JSON строку!");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:Описание ошибки:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
