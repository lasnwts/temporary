package ru.usb.siebelinsuranceihb;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.siebelinsuranceihb.configure.Configure;

@SpringBootApplication
public class SiebelInsuranceIhbApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(SiebelInsuranceIhbApplication.class);
    private final Configure configure;

    @Autowired
    public SiebelInsuranceIhbApplication(Configure configure) {
        this.configure = configure;
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Project 3197. Service Mobile-App to Siebel")
                .version(appVersion)
                .description("Проект 3197. Обмен между Мобильным приложением и Siebel." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    public static void main(String[] args) {
        SpringApplication.run(SiebelInsuranceIhbApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("+---------------------------------------------------------------------------------------------------------+");
        logger.info(" Created by 12.01.2024   : Author: LyapustinAS");
        logger.info("-----------------------------------------------------------------------------------------------------------");
        logger.info("| Name of service        :{}", configure.getAppName());
        logger.info("| Description of service :{}", configure.getAppDescription());
        logger.info("=---------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason        :{}", "0.0.1 Первая версия                                                       ");
        logger.info("---------------------------------------------------------------------------------------------------------");
    }
}
