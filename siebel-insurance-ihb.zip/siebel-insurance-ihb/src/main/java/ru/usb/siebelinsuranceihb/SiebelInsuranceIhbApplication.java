package ru.usb.siebelinsuranceihb;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.siebelinsuranceihb.configure.Configure;
import ru.usb.siebelinsuranceihb.service.soap.RestClient;

@SpringBootApplication
public class SiebelInsuranceIhbApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(SiebelInsuranceIhbApplication.class);
    private final Configure configure;

    @Autowired
    public SiebelInsuranceIhbApplication(Configure configure) {
        this.configure = configure;
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Инициатива 4269 СТРАХОВАНИЕ_Оформление ИСЖ с ПЭП.")
                .version(appVersion)
                .description("Обмен между ЕФС(Siebel) и ИСЖ." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    public static void main(String[] args) {
        SpringApplication.run(SiebelInsuranceIhbApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("+-----------------------------------------------------------------------------------------------------------+");
        logger.info(" Created by 12.01.2024   : Author: Lyapustin A.S.");
        logger.info("-------------------------------------------------------------------------------------------------------------");
        logger.info("| Name of service        :{}", configure.getAppName());
        logger.info("| Description of service :{}", configure.getAppDescription());
        logger.info("=------------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason               :{}", "0.0.1 Первая версия                                               ");
        logger.info("| Modified reason               :{}", "0.0.2 Реализован одно поточный режим работы для GetCommonDirectory");
        logger.info("| Modified reason               :{}", "0.0.3 Добавлен параметр DirectoryID в выходной поток GetCommonDirectory");
        logger.info("| Modified reason, 22.01.2024   :{}", "0.0.4 Добавлена обработка потока Questionnaire");
        logger.info("| Modified reason, 23.01.2024   :{}", "0.0.5 Добавлена обработка ошибки типа Refused и TimeOut");
        logger.info("| Modified reason, 25.01.2024   :{}", "0.0.6 Добавлен Spring Security");
        logger.info("| Modified reason, 26.01.2024   :{}", "0.1.6 Изменен алгоритм обработки ошибок про обращении к SOAP сервису ИСЖ");
        logger.info("| Modified reason, 29.01.2024   :{}", "0.1.7 Изменен алгоритма анализа формата дат в классе AuxMethods");
        logger.info("| Modified reason, 09.02.2024   :{}", "0.1.8 На стороне ИСЖ введены 2 новых header (login, password)");
        logger.info("--------------------------------------------------------------------------------------------------------------");

        /**
         * Если поток PROD, то присваиваем параметры с продуктового потока
         */
        if (configure.getServiceCircuit().equalsIgnoreCase("prod")){
            logger.error("UsbLog: Определен продуктовый контур:{}",configure.getServiceCircuit());
            configure.setSoapUrl(configure.getSoapProdUrl());
            configure.setSoapActionGetCommonDirectory(configure.getSoapProdActionGetCommonDirectory());
            configure.setSoapActionGetQuestionnaire(configure.getSoapProdActionGetQuestionnaire());
        }
        logger.info("");
        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("UsbLog:+-----------------------------------------------------------------------------------------------------------+");
        logger.info("UsbLog: Параметры SOAP сервера:");
        logger.info("UsbLog:-------------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:SOAP URL={}", configure.getSoapUrl());
        logger.info("UsbLog:SOAP GetCommonDirectory Action=={}", configure.getSoapActionGetCommonDirectory());
        logger.info("UsbLog:SOAP Questioner Action={}", configure.getSoapActionGetQuestionnaire());
        logger.info("-------------------------------------------------------------------------------------------------------------");
        logger.info("...");
        logger.info("..");
        logger.info(".");
        logger.info("");


    }
}
