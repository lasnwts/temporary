package ru.usb.siebelinsuranceihb.utils;

import org.springframework.stereotype.Component;

@Component
public class FasadeXML {

    /**
     * Получаем готовый SOAP body
     *
     * @param xmlString
     * @return
     */
    public String getFacadePartner(String xmlString) {
        if (xmlString == null) {
            return "";
        } else {
            return getDirectoryID(getPartnerID(getExtUserGuid(getGetCommonDirectoryRequest(getBody(getEnvelope(xmlString))))));
        }
    }

    /**
     * Получаем готовый SOAP body
     *
     * @param xmlString
     * @return
     */
    public String getFacadeQuestionnaire(String xmlString) {
        if (xmlString == null) {
            return "";
        } else {
            return getPartnerID(getExtUserGuid(getSetQuestionCode(getSetAnswer(getQuestionnaireCode(getSetQuestion(getSetQuestionList(getSetQuestionnaireRequest(getBody(getEnvelope(getQuestionList_Question(xmlString)))))))))));
        }
    }


    public String getEnvelope(String xmlString) {
        return xmlString.replace("</Envelope>", "</soapenv:Envelope>")
                .replace("<Envelope>", "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\"><soapenv:Header/>");
    }

    public String getBody(String xmlString) {
        return xmlString.replace("<Body>", "<soapenv:Body>").replace("</Body>", "</soapenv:Body>");
    }

    public String getGetCommonDirectoryRequest(String xmlString) {
        return xmlString.replace("<GetCommonDirectoryRequest>", "<bp:GetCommonDirectoryRequest>").replace("</GetCommonDirectoryRequest>", "</bp:GetCommonDirectoryRequest>");
    }

    public String getPartnerID(String xmlString) {
        return xmlString.replace("<PartnerID>", "<bp:PartnerID>").replace("</PartnerID>", "</bp:PartnerID>");
    }

    public String getExtUserGuid(String xmlString) {
        return xmlString.replace("<ExtUserGuid>", "<bp:ExtUserGuid>").replace("</ExtUserGuid>", "</bp:ExtUserGuid>");
    }

    public String getDirectoryID(String xmlString) {
        return xmlString.replace("<DirectoryID>", "<bp:DirectoryID>").replace("</DirectoryID>", "</bp:DirectoryID>");
    }

    //Тут QuestionnaireCode
    public String getQuestionnaireCode(String xmlString) {
        return xmlString.replace("<QuestionnaireCode>", "<bp:QuestionnaireCode>").replace("</QuestionnaireCode>", "</bp:QuestionnaireCode>");
    }

    public String getSetQuestionnaireRequest(String xmlString) {
        return xmlString.replace("<SetQuestionnaireRequest>", "<bp:SetQuestionnaireRequest>")
                .replace("</SetQuestionnaireRequest>", "</bp:SetQuestionnaireRequest>");
    }

    public String getSetQuestionList(String xmlString) {
        return xmlString.replace("<QuestionList>", "<bp:QuestionList>").replace("</QuestionList>", "</bp:QuestionList>");
    }

    public String getSetQuestion(String xmlString) {
        return xmlString.replace("<Question>", "<bp:Question>").replace("</Question>", "</bp:Question>");
    }

    public String getSetQuestionCode(String xmlString) {
        return xmlString.replace("<QuestionCode>", "<bp:QuestionCode>").replace("</QuestionCode>", "</bp:QuestionCode>");
    }

    //<QuestionList><Question>
    public String getQuestionList_Question(String xmlString) {
        return xmlString.replace("<QuestionList><Question>", "<QuestionList>").replace("</Question></QuestionList>", "</QuestionList>");
    }

    public String getSetAnswer(String xmlString) {
        return xmlString.replace("<Answer>", "<bp:Answer>").replace("</Answer>", "</bp:Answer>");
    }

}
