package ru.usb.siebelinsuranceihb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiebelInsuranceIhbApplicationTests {

	@Test
	void contextLoads() {
	}

}
