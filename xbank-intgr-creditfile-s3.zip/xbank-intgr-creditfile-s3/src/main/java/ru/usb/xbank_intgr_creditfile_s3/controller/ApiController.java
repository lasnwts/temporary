package ru.usb.xbank_intgr_creditfile_s3.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsFile;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsResponse;
import ru.usb.xbank_intgr_creditfile_s3.service.ApiLayer;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер API. Работа с FTPS сервером.")
public class ApiController {

    private final ApiLayer apiLayer;

    @Autowired
    public ApiController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }

    @PostMapping(value = "/upload", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Отправка файла на FTPS. Выберите файл для загрузки на ftps сервер.", description = "Введите логин, пароль и директорию (необязательно) и бинарный файл.")
    public ResponseEntity<Map<String, String>> upload(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        log.info("{}: Поступил запрос на загрузку файла:{}, размером:{} на FTPS сервер.", LG.USBLOGINFO, files.getOriginalFilename(), files.getSize());
        try {
            File file = apiLayer.upload(files.getOriginalFilename(), files.getBytes());
            FtpsResponse ftpsResponse = apiLayer.sendFileToFtps(login, password, directory, new File(file.getAbsolutePath()));
            apiLayer.delFile(file);
            if (ftpsResponse.getHttpStatus().is2xxSuccessful()) {
                result.put("success", ftpsResponse.getMessage());
            } else {
                result.put("error", ftpsResponse.getMessage());
            }
            return ResponseEntity.status(ftpsResponse.getHttpStatus()).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("{}: Произошла ошибка, при отправке файла в FTPS:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack trace, при отправке файла в FTPS:", LG.USBLOGERROR, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @PostMapping(value = "/list")
    @Operation(summary = "Получить список файлов в директории.", description = "Введите логин, пароль и директорию (необязательно).")
    public ResponseEntity<List<FtpsFile>> getlist(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory) {
        log.info("{}: Поступил запрос на список файлов в директории:{} на FTPS сервер.", LG.USBLOGINFO, directory);
        try {
            List<FtpsFile> ftpsFiles = apiLayer.getList(login, password, directory);
            ftpsFiles.forEach(ftpsFile -> log.info("{}: Файл:{} размером:{}.", LG.USBLOGINFO, ftpsFile.getName(), ftpsFile.getSize()));
            return ResponseEntity.status(HttpStatus.OK).body(ftpsFiles);
        } catch (Exception e) {
            log.info("{}:  Возникла ошибка при запроса списка файлов. Ошибка - Не критичная:{}", LG.USBLOGINFO, e.getMessage());
            List<FtpsFile> errList = new ArrayList<>();
            FtpsFile ftpsFile = new FtpsFile("Возникла ошибка при запроса списка файлов." + e.getMessage(), 0l);
            errList.add(ftpsFile);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errList);
        }
    }

    @PostMapping(value = "/delete")
    @Operation(summary = "Удалить файл.", description = "Введите логин, пароль, директорию и имя файла.")
    public ResponseEntity<String> delete(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory,
            @RequestParam(value = "fileName") String fileName) {
        log.info("{}: Поступил запрос на удаление файла:{} в директории:{} на FTPS сервер.", LG.USBLOGINFO, fileName, directory);
        try {
            FtpsResponse result = apiLayer.deleteFtpsFile(login, password, directory, fileName);
            if (result.getCode() == 200) {
                return ResponseEntity.status(HttpStatus.OK).body("Файл " + fileName + " удален.");
            } else {
                return ResponseEntity.badRequest().body("Файл " + fileName + " не удален." + result.getMessage());
            }
        } catch (Exception e) {
            log.info("{}:  Возникла ошибка при запроса удаления файла. Ошибка - Не критичная:{}", LG.USBLOGINFO, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping(value = "/download")
    @Operation(summary = "Получить файл из Factoring с Uid. Download file from server.")
    public ResponseEntity<ByteArrayResource> getFileBinary(
            @RequestParam("login") String login,
            @RequestParam("password") String password,
            @RequestParam(value = "directory", required = false) String directory,
            @RequestParam(value = "fileName") String fileName) {
        log.info("{}: Поступил запрос на получение файла из FTPS с именем:{}", LG.USBLOGINFO, fileName);
        byte[] data = new byte[0];
        try {
            FtpsResponse ftpsResponse = apiLayer.downloadFile(login, password, directory, fileName, apiLayer.getTempPath(), Thread.currentThread().getId());
            data = Files.readAllBytes(ftpsResponse.getFile().toPath());
            ByteArrayResource resource = new ByteArrayResource(data);
            ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                    .filename(ftpsResponse.getFile().getName(), StandardCharsets.UTF_8)
                    .build();
            Files.delete(ftpsResponse.getFile().toPath()); //Удаление файла
            return ResponseEntity
                    .ok()
                    .contentLength(data.length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", contentDisposition.toString())
                    .body(resource);
        } catch (IOException e) {
            log.error("{} Ошибка при попытке скачать файл с сервера Factoring. Описание {}", LG.USBLOGINFO, e.getMessage());
            log.debug("{} Ошибка при попытке скачать файл с сервера Factoring. StackTrace:", LG.USBLOGINFO, e);
            return new ResponseEntity<>(new ByteArrayResource("Error download file from server Factoring. ".getBytes()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
