package ru.usb.xbank_intgr_creditfile_s3.service.ftp;

import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsFile;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsResponse;


import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static it.sauronsoftware.ftp4j.FTPClient.TYPE_BINARY;

@Log4j2
@Service
public class FtpsClient {

    @Value("${ftps.server}")
    private String server;

    @Value("${ftps.port}")
    private int port;

    @Value("${ftps.charset}")
    private String charSet;

    // iterates over the files and prints details for each
    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    private SSLSocketFactory getSSLContext() {
        TrustManager[] trustManager = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
                //
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
                //
            }
        }};
        SSLContext sslContext = null;
        
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustManager, new SecureRandom());
        } catch (NoSuchAlgorithmException e) {
            log.error("{}: Ошибка алгоритма NoSuchAlgorithmException: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Ошибка Stack NoSuchAlgorithmException: {}", LG.USBLOGERROR, e);
        } catch (KeyManagementException e) {
            log.error("{}: Ошибка алгоритма KeyManagementException: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Ошибка Stack KeyManagementException: {}", LG.USBLOGERROR, e);
        }
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
        return sslSocketFactory;
    }

    /**
     * Получение списка файлов в каталоге
     *
     * @param user      - пользователь под который будет отправка
     * @param password  - пароль  под который будет отправка
     * @param directory - директория куда отправить
     * @return - Listб список файлов в каталоге
     * @throws IOException - ошибка
     */
    public Optional<List<FtpsFile>> getListFile(String user, String password, String directory)
            throws FTPIllegalReplyException, IOException, FTPException, FTPAbortedException, FTPDataTransferException, FTPListParseException {
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        client.connect(server, port);
        client.login(user, password);
        client.setCharset(Charset.forName(charSet).toString());
        if (directory != null) {
            log.info("{}: Получен запрос на список файлов в директории:{}, логин={}", LG.USBLOGINFO, directory, user);
            client.changeDirectory(directory);
        } else {
            log.info("{}: Получен запрос на список файлов в основной директории:{}, логин={}", LG.USBLOGINFO, client.currentDirectory(), user);
        }
        FTPFile[] files = client.list();
        log.info("{}: Количество файлов в директории Count= {}", LG.USBLOGINFO, files.length);
        log.info("{}: Подключение к серверу FTPS для получения списка файлов", LG.USBLOGINFO);
        if (files.length > 0) {
            List<FtpsFile> ftpsFiles = new ArrayList<>();
            for (FTPFile file : files) {
                FtpsFile ftpsFile = new FtpsFile();
                ftpsFile.setName(file.getName());
                ftpsFile.setSize(file.getSize());
                ftpsFiles.add(ftpsFile);
            }
            client.disconnect(true);
            return Optional.of(ftpsFiles);
        }
        client.disconnect(true);
        return Optional.empty();
    }

    /**
     * Отправка файл
     *
     * @param user
     * @param password
     * @param directory
     * @param file
     * @return
     */
    public FtpsResponse sendFile(String user, String password, String directory, File file) throws FTPIllegalReplyException, IOException, FTPException {
        File file2 = new File(file.getAbsolutePath());
        FtpsResponse ftpsResponse = new FtpsResponse();
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        try {
            client.connect(server, port);
            client.login(user, password);
            client.setCharset(Charset.forName(charSet).toString());
            client.setType(TYPE_BINARY);
            client.setPassive(true);
            client.setAutoNoopTimeout(3000);
            if (directory != null) {
                log.info("{}: Подключение к серверу FTPS[login={}] для отправки файла:{} в директорию:{}, размером={}", LG.USBLOGINFO, user, file.getAbsolutePath(), directory, file.length());
                client.changeDirectory(directory);
            } else {
                log.info("{}: Подключение к серверу FTPS[login={}] для отправки файла:{} в текущую директорию, размером={}", LG.USBLOGINFO, user, file.getAbsolutePath(), file.length());
            }
            client.upload(file, 0);
            FTPFile[] ftpFile = client.list(file.getName());
            long s1 = Arrays.stream(ftpFile).findFirst().get().getSize();
            long s3 = file.length();
            while (s1 < s3){
                client.upload(file, Arrays.stream(ftpFile).findFirst().get().getSize());
                ftpFile = client.list(file.getName());
                s1 = Arrays.stream(ftpFile).findFirst().get().getSize();
            }
            ftpsResponse.setMessage("Файл " + file.getName() + " записан в директорию.");
            ftpsResponse.setHttpStatus(HttpStatus.OK);
            log.info("{}: Файл:{}, записан в директорию.", LG.USBLOGINFO, file.getName());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        } catch (FTPException e) {
            log.error("{}: Возникла ошибка [FTPException] при передаче файла {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack при передаче файла {}", LG.USBLOGERROR, e);
            ftpsResponse.setHttpStatus(HttpStatus.FORBIDDEN);
            ftpsResponse.setMessage(e.getMessage());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        } catch (FTPIllegalReplyException | IllegalStateException | IOException | FTPAbortedException |
                 FTPDataTransferException | FTPListParseException e) {
            log.error("{}: Возникла ошибка [IllegalStateException | IOException| FTPIllegalReplyException | FTPException | FTPAbortedException | FTPDataTransferException ] при передаче файла {}", LG.USBLOGERROR, e.getMessage());
            log.error("{}: Stack при передаче файла {}", LG.USBLOGERROR, e);
            ftpsResponse.setHttpStatus(HttpStatus.SERVICE_UNAVAILABLE);
            ftpsResponse.setMessage(e.getMessage());
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
        }
        return ftpsResponse;
    }


    /**
     * Удаление файла
     *
     * @param user      - пользователь
     * @param password - пароль
     * @param directory - директория
     * @param fileName - имя файла
     * @return - успех удаления true/false
     */
    public FtpsResponse deleteFtpsFile(String user, String password, String directory, String fileName) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        FtpsResponse ftpsResponse = new FtpsResponse();

        String sStackTrace = sw.toString(); // stack trace as a string
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        try {
            client.connect(server, port);
            client.login(user, password);
            client.setCharset(Charset.forName(charSet).toString());
            client.changeDirectory(directory);
            client.deleteFile(fileName);
            client.disconnect(true);
            ftpsResponse.setHttpStatus(HttpStatus.OK);
            ftpsResponse.setName(fileName);
            ftpsResponse.setMessage("Файл " + fileName + " удален");
            ftpsResponse.setCode(200);
        } catch (Exception e) {
            log.error("{}: Возникла ошибка при удалении файла: {}", LG.USBLOGERROR, e.getMessage());
            log.error("{}: Stack при удалении файла: {}", LG.USBLOGERROR, e);
            e.printStackTrace(pw);
            if (sw.toString() != null && sw.toString().contains("code")){
                ftpsResponse.setCode(Integer.parseInt(sw.toString().split("code=")[1].split(",")[0]));
            }
            ftpsResponse.setHttpStatus(HttpStatus.BAD_REQUEST);
            ftpsResponse.setMessage(sw.toString());
        }
        return ftpsResponse;
    }


    /**
     * Скачивание файла
     *
     * @param user            - пользователь
     * @param password        - пароль
     * @param directory       - директория
     * @param fileName        - имя файла
     * @param pathDestination - путь куда сохранить
     * @return - файл
     */
    public File downloadFile(String user, String password, String directory, String fileName, String pathDestination, long thread) throws FTPIllegalReplyException, IllegalStateException, IOException, FTPException, FTPAbortedException, FTPDataTransferException, FTPListParseException {
        FTPClient client = new FTPClient();
        client.setSSLSocketFactory(getSSLContext());
        client.setSecurity(FTPClient.SECURITY_FTPES);
        try {
            client.connect(server, port);
            client.login(user, password);
            client.setCharset(Charset.forName(charSet).toString());
            client.changeDirectory(directory);
            client.download(fileName, new File(pathDestination + fileName));
            File file = new File(pathDestination + fileName);
            client.disconnect(true);
            return file;
        } catch (Exception e) {
            log.error("{}:T{}: Возникла ошибка при скачивании файла: {}", LG.USBLOGERROR, thread,e.getMessage());
            log.error("{}:T{}: Stack при скачивании файла: {}", LG.USBLOGERROR, thread,e);
            if (client.isConnected()){
                client.disconnect(true);
            }
            if (client.isConnected()){
                client.disconnect(false);
            }
            throw e;
        }

    }
}


