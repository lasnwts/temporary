package ru.usb.xbank_intgr_creditfile_s3.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;

@RestController
@RequestMapping("/api/admin")
@Tag(name = "Контроллер для управления сервисом", description = "Включение.Отключение сервиса")
public class AdminController {

    private final Logger logger = LoggerFactory.getLogger(AdminController.class);
    private final Configure configure;

    @Autowired
    public AdminController(Configure configure) {
        this.configure = configure;
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/set/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        configure.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (configure.isServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }


    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sandbox/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса проверку файлов в песочнице. SandBox.")
    public ResponseEntity<String> setEnableSandBox(@Parameter(description = "true - включить, false - выключить")
                                                       @PathVariable("enabled") boolean enabled) {
        configure.setCheckSandbox(enabled);
        if (enabled) {
            logger.info("{}:[setEnableSandBox] Web API. SandBox enabled, проверка в песочнице включена.", LG.USBLOGINFO);
            return new ResponseEntity<>("SandBox enabled, проверка в песочнице включена.", HttpStatus.OK);
        } else {
            logger.info("{}:[setEnableSandBox] Web API. SandBox disabled, проверка в песочнице ВЫКЛЮЧЕНА!", LG.USBLOGINFO);
            return new ResponseEntity<>("SandBox disabled, проверка в песочнице ВЫКЛЮЧЕНА!", HttpStatus.OK);
        }
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/sandBox")
    @Operation(summary = "Проверить, включен SandBox или нет")
    public ResponseEntity<String> getSandBoxEnabled() {
        if (configure.isCheckSandbox()) {
            logger.info("{}:[getSandBoxEnabled] Web API. SandBox enabled, проверка в песочнице включена.", LG.USBLOGINFO);
            return new ResponseEntity<>("SandBox enabled, проверка в песочнице включена.", HttpStatus.OK);
        } else {
            logger.info("{}:[getSandBoxEnabled] Web API. SandBox disabled, проверка в песочнице ВЫКЛЮЧЕНА!.", LG.USBLOGINFO);
            return new ResponseEntity<>("SandBox disabled, проверка в песочнице ВЫКЛЮЧЕНА!", HttpStatus.OK);
        }
    }


    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/getthread")
    @Operation(summary = "Посмотреть: Количество одновременно работающих потоков")
    public ResponseEntity<String> getThreads() {
        return new ResponseEntity<>("Количество потоков задано в настройках:" + configure.getServicePoolSize()
                + "\n\r<br>" + "На текущий момент работает активно, потоков:" + configure.getThreads(), HttpStatus.OK);
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/set/{threads}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setPollSize(
            @Parameter(description = "1 - минимальное число, 10 - максимальное")
            @PathVariable("threads") int threads) {
        if (threads == 0){
            logger.info("{}:[setPollSize] Web API. Минимальное число thread равно:1", LG.USBLOGINFO);
            configure.setServicePoolSize(1);
            return new ResponseEntity<>("Web API. Минимальное число thread равно:1", HttpStatus.OK);
        }
        if (threads > 10){
            logger.info("{}:[setPollSize] Web API. Максимальное число thread равно:10", LG.USBLOGINFO);
            configure.setServicePoolSize(10);
            return new ResponseEntity<>("Web API. Максимальное число thread равно:10", HttpStatus.OK);
        } else {
            logger.info("{}:[setPollSize] Web API. Установлено новое число потоков:{}", LG.USBLOGINFO, threads);
            configure.setServicePoolSize(threads);
            return new ResponseEntity<>("Web API. Установлено новое число потоков:" + threads, HttpStatus.OK);
        }
    }


    /**
     * Завершение работы сервиса
     */
    @PutMapping(value = "/exit")
    @Operation(summary = "Принудительное завершение работы. Внимание! Использовать только в случае крайней необходимости. Сервис может выполнять работу в момент перезагрузки.")
    public ResponseEntity<String> getThreadsSize() {
        logger.info("{}:[getThreadsSize] Web API. Принудительная перезагрузка сервиса", LG.USBLOGINFO);
        System.exit(0);
        return new ResponseEntity<>("Принудительная перезагрузка", HttpStatus.OK);
    }



}
