package ru.usb.xbank_intgr_creditfile_s3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_creditfile_s3.model.TBankHistoryFiles;

public interface TBankHistoryFilesRepo extends JpaRepository<TBankHistoryFiles, Long>{
}
