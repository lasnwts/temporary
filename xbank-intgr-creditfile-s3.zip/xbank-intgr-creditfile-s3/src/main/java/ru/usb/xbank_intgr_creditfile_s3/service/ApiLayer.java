package ru.usb.xbank_intgr_creditfile_s3.service;

import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;
import ru.usb.xbank_intgr_creditfile_s3.model.CheckFileList;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsFile;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsResponse;
import ru.usb.xbank_intgr_creditfile_s3.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_creditfile_s3.service.ftp.FtpsClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiLayer {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final FtpsClient ftpsClient;
    private final Configure configure;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    @Autowired
    public ApiLayer(FtpsClient ftpsClient, Configure configure, TBankHistoryArchivesRepo tBankHistoryArchivesRepo) {
        this.ftpsClient = ftpsClient;
        this.configure = configure;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
    }

    /**
     * Запись файла во временный каталог
     *
     * @param name    - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()) {
            log.debug("{}:file.canWrite()=true", LG.USBLOGINFO);
        }
        if (file.canRead()) {
            log.debug("{}:file.canRead()=true", LG.USBLOGINFO);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}: Error2: FileOutputStream(file).write(content):", LG.USBLOGERROR, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     * @return - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(1000);
            if (Files.deleteIfExists(facFile.toPath())) {
                log.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, facFile.getAbsolutePath());
            } else {
                log.info("{}: Файл:{} не был удален из временной директории!", LG.USBLOGINFO, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            log.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.USBLOGERROR, facFile.getAbsolutePath(), e.getMessage());
            log.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Отправка файла FTPS
     *
     * @param file      - файл
     * @param user      - login
     * @param password  - пароль
     * @param directory - директория
     * @return - FtpsResponse
     */
    public FtpsResponse sendFileToFtps(String user, String password, String directory, File file) {
        try {
            return ftpsClient.sendFile(user, password, directory, file);
        } catch (FTPIllegalReplyException | IOException | FTPException e) {
            log.error("{}: [ApiLayer] Ошибка при выполнении записи файла на сервер:{}", LG.USBLOGERROR, e.getMessage());
            return new FtpsResponse(403, e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Получение списка файлов в директории
     *
     * @param user      - логин
     * @param password  - пароль
     * @param directory - директория
     * @return - список файлов
     * @throws FTPIllegalReplyException - ошибка
     * @throws FTPAbortedException      - ошибка
     * @throws FTPDataTransferException - ошибка
     * @throws IOException              - ошибка
     * @throws FTPListParseException    - ошибка
     * @throws FTPException             - ошибка
     */
    public List<FtpsFile> getList(String user, String password, String directory)
            throws FTPIllegalReplyException, FTPAbortedException, FTPDataTransferException, IOException, FTPListParseException, FTPException {
        Optional<List<FtpsFile>> listOptional = ftpsClient.getListFile(user, password, directory);
        return listOptional.orElseGet(ArrayList::new);
    }


    /**
     * Удаление файла
     *
     * @param login     - логин
     * @param password  - пароль
     * @param directory - директория
     * @param fileName  - имя файла
     * @return - FtpsResponse
     */
    public FtpsResponse deleteFtpsFile(String login, String password, String directory, String fileName) {
        log.info("{}: [ApiLayer] Попытка на удаление файла с FTPS, login={}, directory={}, fileName={}", LG.USBLOGINFO, login, directory, fileName);
        return ftpsClient.deleteFtpsFile(login, password, directory, fileName);
    }


    /**
     * Скачивание файла с FTPS
     *
     * @param user            - логин
     * @param password        - пароль
     * @param directory       - директория
     * @param fileName        - имя файла
     * @param pathDestination - путь куда сохранить файл
     * @return - FtpsResponse
     */
    public FtpsResponse downloadFile(String user, String password, String directory, String fileName, String pathDestination, long thread) {
        log.info("{}:T{}: [ApiLayer] Постановка на скачивание файла с FTPS, user={}, directory={}, fileName={}, pathDestination={}",
                LG.USBLOGINFO, thread, user, directory, fileName, pathDestination);
        FtpsResponse ftpsResponse = new FtpsResponse();
        try {
            File file = ftpsClient.downloadFile(user, password, directory, fileName, pathDestination , Thread.currentThread().getId());
            if (file == null) {
                ftpsResponse.setHttpStatus(HttpStatus.NOT_FOUND);
                ftpsResponse.setCode(404);
                ftpsResponse.setMessage("Файл не найден");
                return ftpsResponse;
            } else {
                ftpsResponse.setHttpStatus(HttpStatus.OK);
                ftpsResponse.setCode(200);
                ftpsResponse.setMessage("Файл найден");
                ftpsResponse.setFile(file);
                ftpsResponse.setName(file.getName());
            }
        } catch (FTPIllegalReplyException | IllegalStateException | IOException | FTPException | FTPAbortedException |
                 FTPDataTransferException | FTPListParseException e) {
            log.error("{}:T{}: [ApiLayer] Ошибка при выполнении cкачивания файла с сервера:{}", LG.USBLOGERROR, thread, e.getMessage());
            ftpsResponse.setCode(403);
            ftpsResponse.setMessage(e.getMessage());
            ftpsResponse.setHttpStatus(HttpStatus.BAD_REQUEST);
        }
        log.info("{}:T{}: [ApiLayer] Файл:{} закачан с FTPS, в директорию {}", LG.USBLOGINFO, thread, fileName, pathDestination);
        return ftpsResponse;
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getTempPath() {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator();
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getThreadTempPath(long thread) {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator()
                + thread + FileSystems.getDefault().getSeparator();
    }


    /**
     * Получение списка файлов в директории
     *
     * @return - список файлов
     */
    public CheckFileList getListTbank() {
        CheckFileList checkFileList = new CheckFileList();
        checkFileList.setSuccess(false);
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //число попыток получить список
        do {
            i++; //инкремент числа попыток
            try {
                checkFileList.setList(getList(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory()));
                checkFileList.setSuccess(true);
            } catch (FTPIllegalReplyException e) {
                log.error("{}: [ApiLayer][FTPIllegalReplyException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPAbortedException e) {
                log.error("{}: [ApiLayer][FTPAbortedException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPDataTransferException e) {
                log.error("{}: [ApiLayer][FTPDataTransferException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (IOException e) {
                log.error("{}: [ApiLayer][IOException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPListParseException e) {
                log.error("{}: [ApiLayer][FTPListParseException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPException e) {
                log.error("{}: [ApiLayer][FTPException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(401);
            }
            if (!checkFileList.isSuccess()) {
                timeWait = timeWait + deltaTime * 1000;
                log.info("{}: [ApiLayer] Проблема при получении списка файлов на FTPS сервере. Номер попытки:{} .Повторная попытка получить список файлов через {} секунд", LG.USBLOGINFO, i, timeWait / 1000);
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException e) {
                    log.error("{}: Ошибка возникла во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
            }
        } while (!checkFileList.isSuccess() && i < 10);
        return checkFileList;
    }


    /**
     * Проверка наличия файла в базе
     *
     * @param fileName - имя файла
     * @return - true/false
     */
    public boolean checkFileInDataBase(String fileName, long thread) {
        if (tBankHistoryArchivesRepo.getCountFileName(fileName) > 0){
            log.info("{}:T{}:  Файл:{} найден в базе, обработку файла не производим.", LG.USBLOGINFO, thread, fileName);
            return false;
        }
        return false; //берем в обработку
    }

}
