package ru.usb.xbank_intgr_creditfile_s3.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;


/**
 * Реализовать микросервис по передаче данных из S3 в Kafka (далее – микросервис Xbank-intgr-creditfile-Siebel).
 * 1.	Микросервис должен запускаться по заданному расписанию в оговоренные интервалы времени.
 * 1.1.	Должна быть реализована настройка, определяющая период времени и дни недели, в которые интеграционный сервис работает.
 * График работы сервиса по умолчанию: с 08:00 до 20:00 МСК, каждый день кроме субботы и воскресенья.
 * 1.2.	Должна быть реализована настройка интервала опроса каталога в S3 = бакет передачи файлов Tbankfiles. По умолчанию = 5 минут.
 */
@Component
@EnableScheduling
public class FlowScheduler {

    private final Configure configure;
    private final MainStream mainStream;

    @Autowired
    public FlowScheduler(Configure configure, MainStream mainStream) {
        this.configure = configure;
        this.mainStream = mainStream;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);


    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerExcluded() {
        logger.info("{} scheduler-delay. {}.", LG.USBLOGINFO, configure.getSchedulerDelay());
        System.gc();
        if (configure.isSyncWorkTime()){
            logger.info("{} Работа разрешена.", LG.USBLOGINFO);
            if (configure.getThreads() == 0){ //Если все потоки с предыдущего запуска завершены, то стартуем...
                mainStream.run();
            } else {
                logger.info("{}:T{}: Запущенные ранее потоки не завершены. Пропускаем этот запуск. Количество ранее запущенных потоков:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
            }
        } else {
            logger.info("{} Работа запрещена.", LG.USBLOGINFO);
        }
    }

    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerGarbageCollector() {
        System.gc();
    }

    /**
     * Время работы наступило
     * Scheduler flow.startFlow
     */
    @Scheduled(cron = "${hour-allowed-in-cron}")
    public void startTimeScheduler() {
        logger.info("{} cron-start. Время работы наступило.", LG.USBLOGINFO);
        configure.setSyncWorkTime(true);
    }

    /**
     * Время работы закончилось
     * Scheduler flow.stopFlow
     */
    @Scheduled(cron = "${hour-forbidden-in-cron}")
    public void stopTimeScheduler() {
        logger.info("{} cron-start. Время работы закончилось.", LG.USBLOGINFO);
        configure.setSyncWorkTime(false);
    }


}
