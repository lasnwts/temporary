package ru.usb.xbank_intgr_creditfile_s3;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@SpringBootApplication
public class XbankIntgrCreditfileS3Application implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(XbankIntgrCreditfileS3Application.class);

	private final Configure configure;

	@Autowired
	public XbankIntgrCreditfileS3Application(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(XbankIntgrCreditfileS3Application.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.1.10") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r (Service [Микросервис: Xbank-intgr-creditfile-S3] Интеграционный поток интеграционный поток FTPS –> S3 по передаче данных кредитного досье).")
				.contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
				.version(appVersion)
				.description("API для [пункт 2.2. Реализовать микросервис по передаче данных из FTPS в s3 (далее – микросервис Xbank-intgr-creditfile-S3.]" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {
		// Проверка путей
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
				FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
		} else {
			logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));

		logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
		configure.setTempDirUploadFile(path.toString());
		logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);

		//Проверка сколько времени
		if (LocalDateTime.now().getHour() > configure.getHourEnd()) {
			configure.setSyncWorkTime(false);
			logger.info("{} Время работы завершено", LG.USBLOGINFO);
		}
		if (LocalDateTime.now().getHour() < configure.getHourBegin()) {
			configure.setSyncWorkTime(false);
			logger.info("{} Время работы еще не наступило", LG.USBLOGINFO);
		}
		if (configure.isSyncWorkTime()) {
			logger.info("Сейчас установлено, что время рабочее:{} ", configure.isSyncWorkTime());
		} else {
			logger.info("Сейчас установлено, что время  НЕ рабочее:{} ", configure.isSyncWorkTime());
		}

		logger.info(".");
		logger.info("..");
		logger.info("...");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : Xbank-intgr-creditfile-S3", LG.USBLOGINFO);
		logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 24/10/2024 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  07.10.2024  : 0.0.11 ПОКА НЕТ", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("...");
		logger.info("..");
		logger.info(".");

	}
}
