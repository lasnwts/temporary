package ru.usb.xbank_intgr_creditfile_s3.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

/**
 * Конфигурация RestTemplate
 */
@Configuration
public class RestTemplateConfig {

    //Таймаут для чтения
    @Value("${read.timeout:30}")
    private int readTimeOut;

    //Таймаут для соединения
    @Value("${connect.timeout:20}")
    private int connectTimeOut;


    /**
     * Конфигурация RestTemplate
     * @return - RestTemplate
     */
    @Bean
    public RestTemplate restTemplateConnect() {
        return new RestTemplateBuilder()
                .setConnectTimeout(Duration.ofSeconds(connectTimeOut))
                .setReadTimeout(Duration.ofSeconds(readTimeOut))
                .build();
    }
}
