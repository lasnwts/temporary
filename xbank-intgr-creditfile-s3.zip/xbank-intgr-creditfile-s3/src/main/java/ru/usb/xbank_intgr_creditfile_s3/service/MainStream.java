package ru.usb.xbank_intgr_creditfile_s3.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;
import ru.usb.xbank_intgr_creditfile_s3.model.CheckFileList;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsFile;
import ru.usb.xbank_intgr_creditfile_s3.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_creditfile_s3.util.Support;

@Log4j2
@Service
public class MainStream {

    private final ApiLayer apiLayer;
    private final ServiceMailError serviceMailError;
    private final Configure configure;
    private final Support support;
    private final Executor2Service executor2Service;


    @Autowired
    public MainStream(ApiLayer apiLayer, ServiceMailError serviceMailError, Configure configure, Support support, Executor2Service executor2Service) {
        this.apiLayer = apiLayer;
        this.serviceMailError = serviceMailError;
        this.configure = configure;
        this.support = support;
        this.executor2Service = executor2Service;
    }

    /**
     * Основной процесс
     */
    public void run() {
        if (configure.isServiceEnabled()) { //Работаем только если сервис включен
            //Получаем список объектов
            getListFile();
        } else {
            log.info("{}: Сервис не включен. См. переменную service.enabled", LG.USBLOGINFO);
        }
    }

    /**
     * Получение списка файлов
     */
    public void getListFile() {
        log.info("{}: Запрос на получение списка файлов", LG.USBLOGINFO);
        CheckFileList checkFileList = apiLayer.getListTbank();
        if (checkFileList.isSuccess()) {
            if (checkFileList.getList() != null && !checkFileList.getList().isEmpty()) {
                //Обработка файлов
                checkFileList.getList().forEach(ftpsFile -> {
                    if (support.checkFileMask(ftpsFile.getName())) {
                        startFileProcessed(ftpsFile); //старт обработки файла
                    } else {
                        log.info("{}: Файл не подходит под маску для обработки", LG.USBLOGINFO);
                    }
                });
            }
        } else {
            log.info("{}: Ошибка при получении списка файлов. Статус={}, описание:{}", LG.USBLOGINFO, checkFileList.getCode(), checkFileList.getMessage());
            serviceMailError.sendMailErrorSubject(configure.getLetterFtpsSubject(), "Ошибка при получении списка файлов\n\r" + configure.getLetterFtps()
                    + "\n\r Статус =" + checkFileList.getCode() + "\n\r" +
                    "Описание: " + checkFileList.getMessage());
        }
    }

    /**
     * Обработка файла
     *
     * @param ftpsFile имя файла
     */
    public void startFileProcessed(FtpsFile ftpsFile) {
        log.info("{}: Файл взят в обработку:{}, размером:{}", LG.USBLOGINFO, ftpsFile.getName(), ftpsFile.getSize());
        if (apiLayer.checkFileInDataBase(ftpsFile.getName(), Thread.currentThread().getId())) {
            log.info("{}:T{}: Файл:{} найден в базе", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsFile.getName());
        } else {
            executor2Service.getTask(ftpsFile.getName()); //Запускаем скачивание файла
        }
    }


}


