package ru.usb.xbank_intgr_creditfile_s3.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsResponse;
import ru.usb.xbank_intgr_creditfile_s3.model.TBankHistoryArchives;
import ru.usb.xbank_intgr_creditfile_s3.repository.TBankHistoryArchivesRepo;

import java.util.Date;
import java.util.Objects;

@Log4j2
@Service
public class ApiLayerDB {

    private static final String MICRO = "[xbank-intgr-creditfile-s3]";

    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    @Autowired
    public ApiLayerDB(TBankHistoryArchivesRepo tBankHistoryArchivesRepo) {
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchiveBadZip(FtpsResponse ftpsResponse) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setDateStart(new Date());
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setError("1");
        historyArchives.setErrortext(ftpsResponse.getMessage());
        historyArchives.setTbankFiles("0");
        historyArchives.setDateEnd(new Date());
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchive(FtpsResponse ftpsResponse, String tBankFiles) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setDateStart(new Date());
        historyArchives.setTbankFiles(tBankFiles);
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение истории архива
     *
     * @param historyArchives - история архива
     */
    public void saveHistoryArchive(TBankHistoryArchives historyArchives) {
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }


    /**
     * Получение истории архива
     *
     * @param archiveName - имя архива
     * @return - история архива
     */
    public TBankHistoryArchives getHistoryArchive(String archiveName) {
        TBankHistoryArchives tBankHistoryArchives = tBankHistoryArchivesRepo.getByName(archiveName);
        return Objects.requireNonNullElseGet(tBankHistoryArchives, TBankHistoryArchives::new);
    }

}
