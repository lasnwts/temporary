package ru.usb.xbank_intgr_creditfile_s3.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_s3.model.TBankHistoryArchives;
import ru.usb.xbank_intgr_creditfile_s3.repository.TBankHistoryArchivesRepo;

import java.util.Objects;

@Log4j2
@Service
public class ApiLayerDB {

    private static final String MICRO = "[xbank-intgr-creditfile-s3]";

    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    @Autowired
    public ApiLayerDB(TBankHistoryArchivesRepo tBankHistoryArchivesRepo) {
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
    }

    /**
     * Обрезка строки до 2000 символов
     * @param line - строка
     * @return - строка
     */
    private String getStr2000(String line){
        if (line == null) {
            return "";
        }
        if (line.length() > 2000) {
            return line.substring(0, 1999);
        } else {
            return line;
        }
    }


    /**
     * Сохранение истории архива
     *
     * @param historyArchives - история архива
     */
    public void saveHistoryArchive(TBankHistoryArchives historyArchives) {
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }


    /**
     * Получение истории архива
     *
     * @param archiveName - имя архива
     * @return - история архива
     */
    public TBankHistoryArchives getHistoryArchive(String archiveName) {
        TBankHistoryArchives tBankHistoryArchives = tBankHistoryArchivesRepo.getByName(archiveName);
        return Objects.requireNonNullElseGet(tBankHistoryArchives, TBankHistoryArchives::new);
    }

}
