package ru.usb.xbank_intgr_creditfile_s3.model;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class CheckFileList {
    private List<FtpsFile> list;
    private boolean success;
    private String message;
    private int code;

}
