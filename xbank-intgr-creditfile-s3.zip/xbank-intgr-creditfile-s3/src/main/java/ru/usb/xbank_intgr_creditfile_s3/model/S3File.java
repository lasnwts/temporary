package ru.usb.xbank_intgr_creditfile_s3.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class S3File {

    private String name;
    private long size;
    private String bucket;
    private String key;
    private boolean success;

}
