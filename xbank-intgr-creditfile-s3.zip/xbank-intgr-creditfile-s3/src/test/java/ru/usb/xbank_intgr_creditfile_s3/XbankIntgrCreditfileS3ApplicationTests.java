package ru.usb.xbank_intgr_creditfile_s3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XbankIntgrCreditfileS3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
