package ru.usb.xbank_intgr_creditfile_s3.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;

import static org.junit.jupiter.api.Assertions.*;

class SupportTest {


    private Support support;
    private Configure configure;


    @BeforeEach
    void setUp() {
        configure = new Configure();
        support = new Support(configure);
        configure.setS3ExtFile("zip");
        configure.setS3MaskFile("rup_o_dos");
    }

    @Test
    void checkFileMask() {
        String fileName = "rup_o_dos20241010125133.zip";
        assertTrue(support.checkFileMask(fileName));
    }
}