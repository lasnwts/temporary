package ru.usb.multidbjpa.repository.dbser;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.usb.multidbjpa.model.user.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
}
