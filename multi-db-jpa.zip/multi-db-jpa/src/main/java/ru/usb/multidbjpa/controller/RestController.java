package ru.usb.multidbjpa.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.multidbjpa.model.book.Book;
import ru.usb.multidbjpa.model.user.User;
import ru.usb.multidbjpa.repository.dbbook.BookRepository;
import ru.usb.multidbjpa.repository.dbser.UserRepository;

import java.util.List;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Tag(name = "Короткое наименование", description = "длинное наименование контроллера")
public class RestController {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/getUsers")
    @Operation(summary = "Получаем строку + что то еще.")
    public List<User> getUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/getBooks")
    @Operation(summary = "Получаем строку + что то еще.")
    public List<Book> getBooks() {
        return bookRepository.findAll();
    }


}
