package ru.usb.multidbjpa;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.multidbjpa.model.book.Employee;
import ru.usb.multidbjpa.model.book.Book;
import ru.usb.multidbjpa.model.user.User;
import ru.usb.multidbjpa.repository.dbbook.BookRepository;
import ru.usb.multidbjpa.repository.dbbook.EmployeeRepository;
import ru.usb.multidbjpa.repository.dbser.UserRepository;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
public class MultiDbJpaApplication implements CommandLineRunner {

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	public static void main(String[] args) {
		SpringApplication.run(MultiDbJpaApplication.class, args);
	}

	@PostConstruct
	public void addData2DB() {
		userRepository.saveAll(Stream.of(new User(844, "Alexander"), new User(555, "Las")).collect(Collectors.toList()));
		bookRepository.saveAll(
				Stream.of(new Book(10, "Core Java 17"), new Book(21, "Spring Boot 3.0")).collect(Collectors.toList()));
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("Мое описание - API")
				.version(appVersion)
				.description("This is a sample Foobar server created using springdocs - " +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {
		System.out.println("###########################################################");
		System.out.println("Employee="+bookRepository.getCountEmployee());
		System.out.println("###########################################################");
		List<Employee> employeeList = employeeRepository.findAll();
		System.out.println("Печатаем employee::>");
		if (employeeList != null){
			employeeList.forEach(new Consumer<Employee>() {
				@Override
				public void accept(Employee employee) {
					System.out.println(employee.toString());
				}
			});
		}
	}
}
