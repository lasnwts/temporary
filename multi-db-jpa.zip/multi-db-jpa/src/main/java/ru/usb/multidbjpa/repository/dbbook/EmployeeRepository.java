package ru.usb.multidbjpa.repository.dbbook;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.multidbjpa.model.book.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
