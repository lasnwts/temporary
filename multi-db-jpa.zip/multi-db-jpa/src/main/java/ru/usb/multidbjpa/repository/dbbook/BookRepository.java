package ru.usb.multidbjpa.repository.dbbook;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.multidbjpa.model.book.Book;

import javax.persistence.QueryHint;

import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {


    /**
     * Получаем записи из Job по статусам
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
    })
    @Query(value ="select count(*) from employee"
            , nativeQuery = true)
    int getCountEmployee();


}
