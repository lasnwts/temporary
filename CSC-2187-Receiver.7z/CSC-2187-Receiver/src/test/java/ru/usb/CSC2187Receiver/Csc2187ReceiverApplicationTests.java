package ru.usb.CSC2187Receiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csc2187ReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
