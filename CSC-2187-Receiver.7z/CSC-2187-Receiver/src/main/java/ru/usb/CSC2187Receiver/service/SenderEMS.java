package ru.usb.CSC2187Receiver.service;

/**
 * @author Alexander Lyapustin
 * Sender - передача в EMS очередь сообщений
 * Передача сообщений в EMS сервер
 */
public class SenderEMS {
}
