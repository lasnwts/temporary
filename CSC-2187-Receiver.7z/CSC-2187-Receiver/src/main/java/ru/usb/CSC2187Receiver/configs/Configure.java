package ru.usb.CSC2187Receiver.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author Alexander Lyapustin
 * Configuration
 */
@Component
@ConfigurationProperties()
public class Configure {

    /**
     * Версия из файла application.properties
     */
    @Value("${csc2187receiver.version}")
    private String version;

    public String getVersion() {
        return version;
    }
}
