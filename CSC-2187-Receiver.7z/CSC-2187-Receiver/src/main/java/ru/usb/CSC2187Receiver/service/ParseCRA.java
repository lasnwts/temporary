package ru.usb.CSC2187Receiver.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.CSC2187Receiver.configs.SourcePhone;
import ru.usb.CSC2187Receiver.model.CallRequest;
import ru.usb.CSC2187Receiver.model.ParseRequestBell;
import ru.usb.CSC2187Receiver.restcontroller.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.function.Consumer;

/**
 * @author Alexander Lyapustin
 * Сервис парсинга нетипизированного варианта REST запроса
 * Путь к /api/v1
 * model: CallRequest
 * Проверка значений, перед отправкой в EMS
 */
@Service
public class ParseCRA {

    /**
     * формат даты-времени
     */
/*    SimpleDateFormat sdfDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    Date date; //переменная для проверки формата даты*/
// DateTimeFormatter
    LocalDate date;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @Autowired
    private ParseRequestBell parseRequestBell;

    /**
     * @author Alexander Lyapustin
     * <p>
     * enum : МТС / Asterisk
     * </p>
     * Проверка типа источника, что он соответствует enum
     */
    public boolean parseSource(String Source_Type) {
        if (SourcePhone.МТС.name().equals(Source_Type) || SourcePhone.Asterisk.name().equals(Source_Type)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Проверка номера телефона
     *
     * @param Phone - номер телефона
     * @return True (истина) номер соответствует шаблону
     * False (ложь) номер содержит другие символы
     */
    public boolean parseNumericPhone(String Phone) {
        try {
            long l = Long.parseLong(Phone);
            return true;    //Номер соответствует формату Ok!
        } catch (NumberFormatException nfe) {
            logger.error("Номер телефона = " + Phone + " не соответствует заданному. Должны быть только числа.");
            return false;   //Номер не соответствует формату No!
        }
    }


    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yyyy HH:mm:ss
     */
    public boolean parseDate(String sDate) {
        try {
//            date = (LocalDate) formatter.parse(sDate);
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return false;
        }
    }

    public void parseRequest(ArrayList<CallRequest> callRequests) {
        parseRequestBell.setErrorRequest(false);
        parseRequestBell.setErrorResponse("");
        callRequests.forEach(new Consumer<CallRequest>() {
            @Override
            public void accept(CallRequest callRequest) {
                logger.info("***********************************************************************************************************************************************");
                logger.info("Source = " + callRequest.getSource_Type() + "; Number = " + callRequest.getNumber() + "; Begin Date = " + callRequest.getBeginDateTime() + "; End Date = " + callRequest.getEndDateTime());
                logger.info("***********************************************************************************************************************************************");

                //Проверяем источник
                if (!parseSource(callRequest.getSource_Type())) {
                    if (parseRequestBell.isErrorRequest()) {
                        parseRequestBell.setErrorResponse(parseRequestBell.getErrorResponse() + System.lineSeparator() + "Error Source_Type in record = " + callRequest.toString());
                    } else {
                        parseRequestBell.setErrorResponse("Error Source_Type in record = " + callRequest.toString());
                    }
                    parseRequestBell.setErrorRequest(true);
                    logger.error("<ERROR>#########################################################<ERROR>########################################################################");
                    logger.error(" Error (Ошибка источника MTC или Asterisk) Source_Type = " + callRequest.getSource_Type() + " | in record :: " + callRequest.toString());
                    logger.error("################################################################<ERROR>########################################################################");
                }

                //Проверяем номер
                if (!parseNumericPhone(callRequest.getNumber())) {
                    if (parseRequestBell.isErrorRequest()) {
                        parseRequestBell.setErrorResponse(parseRequestBell.getErrorResponse() + System.lineSeparator() + "Error Phone Number in record = " + callRequest.toString());
                    } else {
                        parseRequestBell.setErrorResponse("Error Phone Number in record = " + callRequest.toString());
                    }
                    parseRequestBell.setErrorRequest(true);
                    logger.error("<ERROR>#########################################################<ERROR>########################################################################");
                    logger.error(" Error Phone Number = " + callRequest.getNumber() + " | in record :: " + callRequest.toString());
                    logger.error("################################################################<ERROR>########################################################################");
                }

                //Проверяем дату начала периода BeginDateTime
                if (!parseDate(callRequest.getBeginDateTime())) {
                    if (parseRequestBell.isErrorRequest()) {
                        parseRequestBell.setErrorResponse(parseRequestBell.getErrorResponse() + System.lineSeparator() + "Error BeginDateTime in record = " + callRequest.toString());
                    } else {
                        parseRequestBell.setErrorResponse("Error BeginDateTime in record = " + callRequest.toString());
                    }
                    parseRequestBell.setErrorRequest(true);
                    logger.error("<ERROR>#########################################################<ERROR>########################################################################");
                    logger.error(" Error BeginDateTime = " + callRequest.getBeginDateTime() + " | in record :: " + callRequest.toString());
                    logger.error("################################################################<ERROR>########################################################################");
                }

                //Проверяем дату начала периода endDatetime
                if (!parseDate(callRequest.getEndDateTime())) {
                    if (parseRequestBell.isErrorRequest()) {
                        parseRequestBell.setErrorResponse(parseRequestBell.getErrorResponse() + System.lineSeparator() + "Error BeginDateTime in record = " + callRequest.toString());
                    } else {
                        parseRequestBell.setErrorResponse("Error BeginDateTime in record = " + callRequest.toString());
                    }
                    parseRequestBell.setErrorRequest(true);
                    logger.error("<ERROR>#########################################################<ERROR>########################################################################");
                    logger.error(" Error BeginDateTime = " + callRequest.getEndDateTime() + " | in record :: " + callRequest.toString());
                    logger.error("################################################################<ERROR>########################################################################");
                }

            }
        });
    }

}
