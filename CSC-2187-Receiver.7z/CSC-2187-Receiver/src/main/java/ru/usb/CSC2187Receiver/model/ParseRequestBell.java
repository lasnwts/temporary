package ru.usb.CSC2187Receiver.model;

import org.springframework.stereotype.Component;

/**
 * @author Alexander Lyapustin
 * Парсер для возврата ответа
 */
@Component
public class ParseRequestBell {
    /**
     * errorRequest - (boolean) (true - без ошибок, false - содержит ошибки в запросе)
     */
    private boolean errorRequest;

    /**
     * errorResponse - (String) содержит описание ошибки в текстовом виде
     */
    private String errorResponse;

    public ParseRequestBell(boolean errorRequest, String errorResponse) {
        this.errorRequest = errorRequest;
        this.errorResponse = errorResponse;
    }

    public ParseRequestBell() {
    }

    public boolean isErrorRequest() {
        return errorRequest;
    }

    public void setErrorRequest(boolean errorRequest) {
        this.errorRequest = errorRequest;
    }

    public String getErrorResponse() {
        return errorResponse;
    }

    public void setErrorResponse(String errorResponse) {
        this.errorResponse = errorResponse;
    }

    @Override
    public String toString() {
        return "ParseRequestBell{" +
                "error (request contain Error) = " + errorRequest +
                ", error text Response='" + errorResponse + '\'' +
                '}';
    }
}
