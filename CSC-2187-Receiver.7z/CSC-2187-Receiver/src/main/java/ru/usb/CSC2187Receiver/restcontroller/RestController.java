package ru.usb.CSC2187Receiver.restcontroller;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.CSC2187Receiver.configs.Configure;
import ru.usb.CSC2187Receiver.model.CallRequest;
import ru.usb.CSC2187Receiver.model.CallRequestType;
import ru.usb.CSC2187Receiver.model.ParseRequestBell;
import ru.usb.CSC2187Receiver.model.Response;
import ru.usb.CSC2187Receiver.service.ParseCRA;

import java.util.ArrayList;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер для приема списка телефонов для закачки разговоров.", tags = "Rest API")
public class RestController {

    @Autowired
    Configure configure;

    @Autowired
    ParseCRA parseCRA;

    @Autowired
    private ParseRequestBell parseRequestBell;

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @PostMapping("/")
    //Вставляем API описание
    @ApiOperation(value = "Запрос, по списку номеров",
            notes = "Список телефонов с периодом на обработку",
            response = Response.class)
    public ResponseEntity<Response> postCRAversion(@RequestBody ArrayList<CallRequest> callRequests) {
        parseCRA.parseRequest(callRequests);
        if (parseRequestBell.isErrorRequest()) {
            return new ResponseEntity<>(new Response(parseRequestBell.getErrorResponse()),HttpStatus.BAD_REQUEST);
        } else {
            return new ResponseEntity<>(new Response("Передано " + callRequests.size() + " запросов по звонкам."),HttpStatus.OK);
        }
    }

/*
    @PostMapping("/t")
    //Вставляем API описание
    @ApiOperation(value = "Запрос, по списку номеров, типизированный",
            notes = "Список телефонов с периодом на обработку",
            response = Response.class)
    public Response postCRAType(@RequestBody ArrayList<CallRequestType> callRequestTypes) {
        return new Response("test");

    }
*/

    @PostMapping("/demo_ok")
    //Вставляем API описание
    @ApiOperation(value = "Добавление записи сотрудника",
            notes = "Запись будет добавлена",
            response = Response.class)
    public Response postCRA(@RequestBody ArrayList<CallRequest> callRequests) {
        return new Response("КОл-во = " + callRequests.size());
    }

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() {
        if (configure.getVersion() == null) {
            return "version not defined";
        }
        return (configure.getVersion());
    }


}
