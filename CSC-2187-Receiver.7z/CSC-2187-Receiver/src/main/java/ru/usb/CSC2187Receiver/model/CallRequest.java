package ru.usb.CSC2187Receiver.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import springfox.documentation.builders.PathSelectors;

/**
 * @author Alexander Lyapustin
 * Типизированный класс, запроса разговоров
 */
@ApiModel(value = "CallRequest", description = "Входящий Rest запрос от БД «Архив звонков» содержит от 50 записей следующего вида :: Запрос переговоров по номеру телефона в период")
public class CallRequest {

    /**
     * Тип запроса
     * MTC  -   запрос к МТС
     * AST  -   запрос к Астериск
     */
    @ApiModelProperty(value = "Source_Type :: Тип источника :: МТС - запрос к МТС, Asterisk - запрос к Астериск")
    private String Source_Type;

    /**
     * Номер телефона
     */
    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    private String Number;

    /**
     * Дата начала периода в запросе
     */
    @ApiModelProperty(value = "beginDateTime :: Начало звонка после даты (дата начала периода в запросе) :: Пример 24.02.15 22:03:00")
    private String beginDateTime;

    /**
     * Дата конца периода в запросе
     */
    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) :: 25.02.15 10:00:59")
    private String endDateTime;

    public CallRequest(String source_Type, String number, String beginDateTime, String endDateTime) {
        this.Source_Type = source_Type;
        this.Number = number;
        this.beginDateTime = beginDateTime;
        this.endDateTime = endDateTime;
    }

    @ApiModelProperty(value = "Source_Type :: Тип источника :: МТС - запрос к МТС, Asterisk - запрос к Астериск")
    public String getSource_Type() {
        return Source_Type;
    }

    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    public String getNumber() {
        return Number;
    }

    public String getBeginDateTime() {
        return beginDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    @Override
    public String toString() {
        return
                "Source_Type='" + Source_Type + '\'' +
                        ", Number='" + Number + '\'' +
                        ", beginDateTime='" + beginDateTime + '\'' +
                        ", endDateTime='" + endDateTime + '\'' +
                        '}';
    }
}
