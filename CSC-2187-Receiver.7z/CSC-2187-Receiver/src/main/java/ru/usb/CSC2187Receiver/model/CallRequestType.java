package ru.usb.CSC2187Receiver.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @author Alexander Lyapustin
 * Типизированный класс, запроса разговоров
 */
@ApiModel(value = "CallRequestType", description = "Входящий Rest запрос от БД «Архив звонков» содержит от 50 записей следующего вида :: Запрос переговоров по номеру телефона в период")
public class CallRequestType {

    /**
     * формат даты-времени
     */
    SimpleDateFormat sdfDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    /**
     * Тип запроса
     * MTC  -   запрос к МТС
     * AST  -   запрос к Астериск     *
     */
    @ApiModelProperty(value = "Source_Type :: Тип источника :: МТС - запрос к МТС, Asterisk - запрос к Астериск")
    private String Source_Type;

    /**
     * Номер телефона
     * Тип long
     */
    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    private long Number;

    /**
     * Дата начала периода в запросе
     */
    @ApiModelProperty(value = "beginDateTime :: Начало звонка после даты (дата начала периода в запросе) :: Пример 24.02.15 22:03:00")
    @JsonFormat(pattern = "dd.MM.yyyy HH:mm:ss")
    private String beginDateTime;

    /**
     * Дата конца периода в запросе
     */
    @ApiModelProperty(value = "endDateTime :: Начало звонка до даты (дата конца периода в запросе) :: 25.02.15 10:00:59")
    private String endDateTime;

    @ApiModelProperty(value = "Source_Type :: Тип источника :: МТС - запрос к МТС, Asterisk - запрос к Астериск")
    public String getSource_Type() {
        return Source_Type;
    }

    @ApiModelProperty(value = "Number :: Номер телефона :: Пример = 9171112233 / 8007000079")
    public long getNumber() {
        return Number;
    }

    public CallRequestType(String source_Type, long number, String beginDateTime, String endDateTime) {
        Source_Type = source_Type;
        Number = number;
        this.beginDateTime = beginDateTime;
        this.endDateTime = endDateTime;
    }

    public void setSource_Type(String source_Type) {
        Source_Type = source_Type;
    }

    public void setNumber(long number) {
        Number = number;
    }

    public String getBeginDateTime() {
        return beginDateTime;
    }

    public void setBeginDateTime(String beginDateTime) {
        this.beginDateTime = beginDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }
}
