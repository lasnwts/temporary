package ru.usb.CSC2187Receiver.model;

import java.util.ArrayList;

public class CallRequestArray {
    private String version;
    private boolean demo;
    private ArrayList<CallRequest> CRA = new ArrayList<>(); //CRA - call Request Array

    public CallRequestArray() {
    }

    public CallRequestArray(ArrayList<CallRequest> CRA) {
        this.CRA = CRA;
    }

    public CallRequestArray(String version, boolean demo) {
        this.version = version;
        this.demo = demo;
    }

    public CallRequestArray(String version, boolean demo, ArrayList<CallRequest> CRA) {
        this.version = version;
        this.demo = demo;
        this.CRA = CRA;
    }

    public CallRequestArray(String version, ArrayList<CallRequest> CRA) {
        this.version = version;
        this.CRA = CRA;
    }

    public CallRequestArray(boolean demo, ArrayList<CallRequest> CRA) {
        this.demo = demo;
        this.CRA = CRA;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public boolean isDemo() {
        return demo;
    }

    public void setDemo(boolean demo) {
        this.demo = demo;
    }

    public ArrayList<CallRequest> getCRA() {
        return CRA;
    }

    public void setCRA(ArrayList<CallRequest> CRA) {
        this.CRA = CRA;
    }

    public void addCRA(CallRequest cr){
        this.CRA.add(cr);
    }

}
