package ru.usb.CSC2187Receiver.configs;

/**
 * @author Alexander Lyapustin
 * Тип источника :: МТС / Asterisk
 */
public enum SourcePhone {
    МТС {
        @Override
        public String toString() {
            return "MTC";
        }
    },
    Asterisk {
        @Override
        public String toString() {
            return "Asterisk";
        }
    }
}
