package ru.usb.CSC2187Receiver.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Alexander Lyapustin
 * @return String;
 */
@ApiModel(description = "Ответ на входной запрос")
public class Response {
    /**
     * Возвращаемое значение
     */
    @ApiModelProperty(notes = "Строка ответа. Непустая в случае ошибки входных данных.")
    private String response;

    public Response() {
    }

    public Response(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
