package com.kibersystems.kmservices_archi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * Класс для хранения записи по элементам
 * "ID";"Type";"Name";"Documentation";"Specialization"
 */
@Getter
@Setter
@Entity
@Table(name = "elements")
public class Element {
    //1
    @JsonProperty("ID")
    @Id
    private String id;

    //2
    @JsonProperty("Type")
    private String type;

    //3
    @JsonProperty("Name")
    private String name;

    //4
    @JsonProperty("Documentation")
    private String documentation;

    //5
    @JsonProperty("Specialization")
    private String specialization;

    @JsonProperty("FILENAME")
    private String fileName;//Файл

    @JsonProperty("NUMLINE")
    private int numLine;//номер строки

    public Element(String id, String type, String name, String documentation, String specialization) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.documentation = documentation;
        this.specialization = specialization;
    }

    public Element(String id, String type, String name, String documentation,
                   String specialization, String fileName, int numLine) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.documentation = documentation;
        this.specialization = specialization;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public Element() {
        //
    }

    @Override
    public String toString() {
        return "CsvElement{" +
                "id='" + id + '\'' +
                ", type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", documentation='" + documentation + '\'' +
                ", specialization='" + specialization + '\'' +
                '}';
    }
}
