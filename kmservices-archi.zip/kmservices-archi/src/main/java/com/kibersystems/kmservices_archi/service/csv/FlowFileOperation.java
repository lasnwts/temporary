package com.kibersystems.kmservices_archi.service.csv;


import com.kibersystems.kmservices_archi.config.Config;
import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.model.LoadError;
import com.kibersystems.kmservices_archi.model.csv.CsvElementHeadPosition;
import com.kibersystems.kmservices_archi.model.csv.CsvPropertiesHeadPosition;
import com.kibersystems.kmservices_archi.repository.ElementRepo;
import com.kibersystems.kmservices_archi.service.csv.elements.LoadFileCsvElements;
import com.kibersystems.kmservices_archi.service.csv.elements.LoadHeadCsvElement;
import com.kibersystems.kmservices_archi.service.csv.properties.LoadFileCsvProperties;
import com.kibersystems.kmservices_archi.service.csv.properties.LoadHeadCsvProperties;
import com.kibersystems.kmservices_archi.util.Support;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;


import java.io.File;
import java.util.List;
import java.util.Optional;

@Service
public class FlowFileOperation {

    private final Config config;
    private final LoadHeadCsvElement loadHeadCsvElement;
    private final LoadHeadCsvProperties loadHeadCsvProperties;
    private final LoadFileCsvElements loadFileCsvElements;
    private final LoadFileCsvProperties loadFileCsvProperties;
    private final Support support;

    @Autowired
    public FlowFileOperation(Config config, LoadHeadCsvElement loadHeadCsvElement,
                             LoadHeadCsvProperties loadHeadCsvProperties,
                             LoadFileCsvElements loadFileCsvElements,
                             LoadFileCsvProperties loadFileCsvProperties, Support support) {
        this.config = config;
        this.loadHeadCsvElement = loadHeadCsvElement;
        this.loadHeadCsvProperties = loadHeadCsvProperties;
        this.loadFileCsvElements = loadFileCsvElements;
        this.loadFileCsvProperties = loadFileCsvProperties;
        this.support = support;
    }

    Logger logger = LoggerFactory.getLogger(FlowFileOperation.class);

    /**
     * Старт обработки файлов
     */
    public void start() {
        logger.debug("{}:FileOperation start processed...", LG.USBLOGINFO);
        if (!support.checkDirExists(support.getPaths(config.getFileUrl()))) {
            logger.error("{} Директория с файлами:{} недоступна! ", LG.USBLOGERROR, config.getFileUrl());
            return;
        }
        //Получаем список файлов
        Optional<List<String>> listFiles = support.listFilesController(support.checkTermSymbol(config.getFileUrl()) + "in/");

        try {
            //Обрабатываем файлы
            if (listFiles.isPresent()) {
                logger.debug("listFiles.isPresent() = true");
                logger.debug("listFiles.size() = {}", listFiles.get().size());
                for (String fileName : listFiles.get()) {
                    File file = new File(fileName);
                    if (!file.exists() || !file.isFile() || !getExtensionFromStrFileName(file.getName()).equalsIgnoreCase("csv")) {
                        continue;
                    }
                    Thread.sleep(500); //Притормозим на 500 мс.
                    //!fileName.contains("ELEMENT") ||
                    if (fileName.toUpperCase().contains("ELEMENT") && support.checkFileDone(fileName)) {
                        Optional<CsvElementHeadPosition> csvElementHeadPosition = loadHeadCsvElement.loadFile(file, fileName, 1);
                        if (csvElementHeadPosition.isPresent()) {
                            List<LoadError> loadErrors = loadFileCsvElements.loadFile(file, fileName, csvElementHeadPosition.get(), 1, false);
                            //Если все в порядке, то копируем в папку out
                            if (loadErrors.isEmpty()) {
                                File fileOut = new File(support.checkTermSymbol(config.getFileUrl()) + "out/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                            } else {
                                logger.warn("{}:!!!![ELEMENT] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                                File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                                support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                            }
                        } else {
                            logger.warn("{}:!!!![ELEMENT] csvElementHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                            File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                            support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                        }
                    }
                    processProperties(file);
                }
            } else {
                logger.info("{}: Optional<List<String>> listFiles() = false", LG.USBLOGINFO);
            }
        } catch (InterruptedException e) {
            logger.error("{}", e.getMessage());
            Thread.currentThread().interrupt();
        }
        logger.debug("{}: end processed....", LG.USBLOGINFO);
    }


    /**
     * Возвращает EXT расширение если имя файла представлено строкой
     *
     * @param fileName - строковое имя файла
     * @return - расширение
     */
    public String getExtensionFromStrFileName(String fileName) {
        return StringUtils.getFilenameExtension(new File(fileName).getName());
    }

    private void processElements(File file) throws InterruptedException {
        if (file.exists() || file.isFile() || getExtensionFromStrFileName(file.getName()).equalsIgnoreCase("csv")) {
            Thread.sleep(500); //Притормозим на 500 мс.
            //!fileName.contains("ELEMENT") ||
            if (file.getName().toUpperCase().contains("ELEMENT") && support.checkFileDone(file.getAbsolutePath())) {
                Optional<CsvElementHeadPosition> csvElementHeadPosition = loadHeadCsvElement.loadFile(file, file.getName(), 1);
                if (csvElementHeadPosition.isPresent()) {
                    List<LoadError> loadErrors = loadFileCsvElements.loadFile(file, file.getName(), csvElementHeadPosition.get(), 1, false);
                    //Если все в порядке, то копируем в папку out
                    if (loadErrors.isEmpty()) {
                        File fileOut = new File(support.checkTermSymbol(config.getFileUrl()) + "out/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                    } else {
                        logger.warn("{}:!!!![ELEMENT] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                        File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                    }
                } else {
                    logger.warn("{}:!!!![ELEMENT] csvElementHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                    File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                    support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                }
            }
        }
    }

    private void processProperties(File file) throws InterruptedException {
        if (file.exists() || file.isFile() || getExtensionFromStrFileName(file.getName()).equalsIgnoreCase("csv")) {
            Thread.sleep(500); //Притормозим на 500 мс.
            //!fileName.contains("PROPERTIES") ||
            if (file.getName().toUpperCase().contains("PROPERTIES") && support.checkFileDone(file.getAbsolutePath())) {
                Optional<CsvPropertiesHeadPosition> csvPropertiesHeadPosition = loadHeadCsvProperties.loadFile(file, file.getName(), 1);
                if (csvPropertiesHeadPosition.isPresent()) {
                    List<LoadError> loadErrors = loadFileCsvProperties.loadFile(file, file.getName(), csvPropertiesHeadPosition.get(), 1, false);
                    //Если все в порядке, то копируем в папку out
                    if (loadErrors.isEmpty()) {
                        File fileOut = new File(support.checkTermSymbol(config.getFileUrl()) + "out/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileOut.getAbsolutePath());
                    } else {
                        logger.warn("{}:!!!![PROPERTIES] loadErrors содержит ошибку !!!!", LG.USBLOGWARNING);
                        File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                        support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                    }
                } else {
                    logger.warn("{}:!!!![PROPERTIES] csvElementHeadPosition содержит ошибку !!!! У файла:{} отсутствует заголовок!", LG.USBLOGWARNING, file.getAbsolutePath());
                    File fileErr = new File(config.getFileUrl() + "err/" + file.getName());
                    support.moveFileSName(file.getAbsolutePath(), fileErr.getAbsolutePath());
                }
            }
        }
    }

}
