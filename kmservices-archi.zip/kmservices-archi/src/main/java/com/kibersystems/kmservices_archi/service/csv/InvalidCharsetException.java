package com.kibersystems.kmservices_archi.service.csv;

/**
 * Ошибка кодировки при загрузке файла
 */
public class InvalidCharsetException extends Exception{
    public InvalidCharsetException(String message) {
        super(message);
    }
}
