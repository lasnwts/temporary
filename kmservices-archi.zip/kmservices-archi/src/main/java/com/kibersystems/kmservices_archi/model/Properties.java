package com.kibersystems.kmservices_archi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * Класс для хранения свойств
 * "ID";"Key";"Value"
 */
@Getter
@Setter
@Entity
@Table(name = "properties")
public class Properties {

    @Id
    @JsonProperty("FAKE-ID")
    private String fakeid;

    @JsonProperty("ID")
    private String id;

    @JsonProperty("KEYS")
    private String keys;

    @JsonProperty("VALUE")
    private String value;

    @JsonProperty("FILENAME")
    private String fileName;//Файл

    @JsonProperty("NUMLINE")
    private int numLine;//номер строки

    public Properties() {
        //
    }

    public Properties(String id, String keys, String value) {
        this.id = id;
        this.keys = keys;
        this.value = value;
    }

    public Properties(String id, String keys, String value, String fileName, int numLine) {
        this.id = id;
        this.keys = keys;
        this.value = value;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    public Properties(String fakeid, String id, String keys, String value, String fileName, int numLine) {
        this.fakeid = fakeid;
        this.id = id;
        this.keys = keys;
        this.value = value;
        this.fileName = fileName;
        this.numLine = numLine;
    }

    @Override
    public String toString() {
        return "Properties{" +
                "fakeid='" + fakeid + '\'' +
                ", id='" + id + '\'' +
                ", keys='" + keys + '\'' +
                ", value='" + value + '\'' +
                ", fileName='" + fileName + '\'' +
                ", numLine=" + numLine +
                '}';
    }
}
