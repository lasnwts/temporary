package com.kibersystems.kmservices_archi;

import com.kibersystems.kmservices_archi.config.Config;
import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.service.csv.FlowFileOperation;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.FileSystemResource;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class KmservicesArchiApplication implements CommandLineRunner {

    private final Config config;
    private final FlowFileOperation fileOperation;


    public KmservicesArchiApplication(Config config, FlowFileOperation fileOperation) {
        this.config = config;
        this.fileOperation = fileOperation;
    }

    private static final Logger logger = LoggerFactory.getLogger(KmservicesArchiApplication.class);


    public static void main(String[] args) {
		SpringApplication.run(KmservicesArchiApplication.class, args);
	}

    @Override
    public void run(String... args) throws Exception {
        //Проверка путей
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));
        logger.info("Создана директория для временного хранения файлов: {}", path);
        config.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile: {}", path);

        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : {}", LG.USBLOGINFO, config.getAppDescription());
        logger.info("{}:| Description of service       : Пока нет описания", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 26/09/2025", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                  25.05.2025  : 0.0.10 Базовая версия.", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("..");
        logger.info(".");
        fileOperation.start();


    }
}
