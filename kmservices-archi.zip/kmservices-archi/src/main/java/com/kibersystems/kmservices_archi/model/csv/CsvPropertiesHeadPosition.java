package com.kibersystems.kmservices_archi.model.csv;

import lombok.Getter;
import lombok.Setter;

/**
 * Шапка Properties
 * "ID";"Key";"Value"
 */
@Getter
@Setter
public class CsvPropertiesHeadPosition {
    private int id;
    private int keys;
    private int value;
    //Наличие заголовка
    private boolean titlePresent;

    public CsvPropertiesHeadPosition() {
        //
    }

    public CsvPropertiesHeadPosition(int id, int keys, int value, boolean titlePresent) {
        this.id = id;
        this.keys = keys;
        this.value = value;
        this.titlePresent = titlePresent;
    }

    @Override
    public String toString() {
        return "CsvPropertiesHeadPosition{" +
                "id=" + id +
                ", keys=" + keys +
                ", value=" + value +
                ", titlePresent=" + titlePresent +
                '}';
    }
}
