package com.kibersystems.kmservices_archi.service.csv.elements;

import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.model.LoadError;
import com.kibersystems.kmservices_archi.model.csv.CheckCsvElement;
import com.kibersystems.kmservices_archi.model.Element;
import com.kibersystems.kmservices_archi.model.csv.CsvElementHeadPosition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


import java.util.Date;


@Component
public class CsvElementMapper {

    Logger log = LoggerFactory.getLogger(CsvElementMapper.class);


    public CheckCsvElement map(String line, CsvElementHeadPosition position, String fileName, int lineNumber, String commaDelimiter) {

        String[] values = line.split(commaDelimiter);

        //Пустая срока
        if (values.length < 2) {
            return new CheckCsvElement(new Element(), new LoadError(lineNumber, fileName, line, "Пустая строка, пропускаем.", new Date(), false), false);
        }

        //Не заполненная строка
        if (values.length < 4) {
            return new CheckCsvElement(new Element(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        Element element = new Element();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        element.setFileName(fileName);
        element.setNumLine(lineNumber);


        //1
        try {
            if (position.getId() > -1) {
                element.setId(check(values[position.getId()]));
            } else {
                setLoadError("Не найден обязательный параметр:ID", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ID: ", LG.USBLOGERROR, e);
        }

        //2
        try {
            if (position.getType() > -1) {
                element.setType(check(values[position.getType()]));
            } else {
                setLoadError("Не найден обязательный параметр:Type", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Type" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Type: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, Type: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getName() > -1) {
                element.setName(check(values[position.getName()]));
            } else {
                setLoadError("Не найден обязательный параметр:Name", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Name" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Name: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, Name: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getDocumentation() > -1) {
                element.setDocumentation(check(values[position.getDocumentation()]));
            } else {
                setLoadError("Не найден обязательный параметр:documentation", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:documentation" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:documentation: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, documentation: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getSpecialization() > -1) {
                element.setSpecialization(check(values[position.getSpecialization()]));
            } else {
                setLoadError("Не найден обязательный параметр:Specialization", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Specialization" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Specialization: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, Specialization: ", LG.USBLOGERROR, e);
        }

        //Возврат
        return new CheckCsvElement(element, loadError, true);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote1(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("'", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote2(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("\"", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getFirstQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String firstChar = line.substring(0, 1);
            if (firstChar.equalsIgnoreCase("\"")) {
                return line.substring(1, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка
     *
     * @param line - входная строка
     * @return строка после обертки
     */
    public String getLastQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String lastChar = line.substring(line.length() - 1);
            if (lastChar.equalsIgnoreCase("\"")) {
                return line.substring(0, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка над строкой
     *
     * @param line - строка
     * @return - строка
     */
    public String getLineTrim(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String check(String line) {
        return rQuote1(rQuote2(getLastQuote(getFirstQuote(getLineTrim(line))))).trim();
    }

}
