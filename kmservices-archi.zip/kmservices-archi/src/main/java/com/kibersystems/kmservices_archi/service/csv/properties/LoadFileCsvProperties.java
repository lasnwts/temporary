package com.kibersystems.kmservices_archi.service.csv.properties;

import com.kibersystems.kmservices_archi.config.Config;
import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.model.LoadError;
import com.kibersystems.kmservices_archi.model.csv.CheckCsvProperties;
import com.kibersystems.kmservices_archi.model.csv.CsvPropertiesHeadPosition;
import com.kibersystems.kmservices_archi.repository.PropertiesRepo;
import com.kibersystems.kmservices_archi.service.csv.InvalidCharsetException;
import com.kibersystems.kmservices_archi.util.Support;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
public class LoadFileCsvProperties {

    private final Config config;
    private final Support support;
    private final CsvPropertiesMapper csvPropertiesMapper;
    private final PropertiesRepo propertiesRepo;

    @Autowired
    public LoadFileCsvProperties(Config config, Support support,
                                 CsvPropertiesMapper csvPropertiesMapper,
                                 PropertiesRepo propertiesRepo) {
        this.config = config;
        this.support = support;
        this.csvPropertiesMapper = csvPropertiesMapper;
        this.propertiesRepo = propertiesRepo;
    }

    Logger log = LoggerFactory.getLogger(LoadFileCsvProperties.class);


    /**
     * Загрузка данных из файла
     *
     * @param file            - файл для загрузки
     * @param fileName        - имя файла
     * @param csvHeadPosition - заголовок файла
     * @param thread          - номер потока
     * @return - список ошибок
     */
    public List<LoadError> loadFile(File file, String fileName, CsvPropertiesHeadPosition csvHeadPosition, long thread, boolean smbFlag) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (file == null || !file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadFileCsvProperties, переданный Файл:{} не существует, равен NULL", LG.USBLOGERROR, fileName, thread);
            loadErrorList.add(new LoadError(0, fileName, "Файл  - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        log.info("{}:T{}: Подготовка процесса: Load elements.csv к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUM INSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), support.formatDateTime(new Date()));
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadFileCsvProperties, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));

        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            count.set(0);
            final AtomicInteger countGc = new AtomicInteger();
            lines.forEach(line -> {
                        countGc.incrementAndGet(); //+1 на каждую строку
                        if (countGc.get() > 20000) {
                            log.info("{}:T{}: Обработано в процессе: LoadFileCsvProperties, количество записей={}", LG.USBLOGINFO, thread, count.get());
                            System.gc();
                            countGc.set(0);
                        }
                        try {
                            CheckCsvProperties checkCsvProperties = csvPropertiesMapper.map(line.trim(), csvHeadPosition, file.getName(), count.get(), config.getFileCommaDelimiter());
                            if (checkCsvProperties != null && checkCsvProperties.getProperties() != null && checkCsvProperties.getLoadError() != null
                                    && checkCsvProperties.getProperties().getId() != null
                                    && !checkCsvProperties.getProperties().getId().equalsIgnoreCase("ID")
                                    && checkCsvProperties.isExists() && !checkCsvProperties.getLoadError().isStatus()) {
                                //true - много потоковый вариант
                                log.info("PROPERTIES:{}", checkCsvProperties.getProperties()); //Печать элемента
                                count.incrementAndGet(); //+1 на каждую строку
                                propertiesRepo.saveAndFlush(checkCsvProperties.getProperties()); //Запись в БД
                            }
                            if (checkCsvProperties != null && checkCsvProperties.getLoadError() != null && checkCsvProperties.getLoadError().isStatus()) {
                                loadErrorList.add(checkCsvProperties.getLoadError());
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadFileCsvProperties, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (Exception e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
        }

        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadFileCsvProperties. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        //Удаляем временный файл
        if (smbFlag) {
            delFile(file);
        }
        return loadErrorList;
    }

    /**
     * Удалить файл из временной директории
     *
     * @param facFile - FacFile
     */

    public void delFile(File facFile) {
        try {
            Thread.sleep(10);
            if (Files.deleteIfExists(facFile.toPath())) {
                log.info("{}: Файл:{} удален из временной директории", LG.USBLOGINFO, facFile.getAbsolutePath());
            } else {
                log.info("{}: Файл:{} не был удален из временной директории!", LG.USBLOGINFO, facFile.getAbsolutePath());
            }
        } catch (IOException | InterruptedException e) {
            log.error("{}: Ошибка при удалении файла:{} , описание ошибки:{}", LG.USBLOGERROR, facFile.getAbsolutePath(), e.getMessage());
            log.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            Thread.currentThread().interrupt();
        }
    }
}
