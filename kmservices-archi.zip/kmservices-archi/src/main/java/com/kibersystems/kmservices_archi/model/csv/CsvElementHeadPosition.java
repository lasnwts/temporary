package com.kibersystems.kmservices_archi.model.csv;

import lombok.Getter;
import lombok.Setter;

/**
 * Шапка
 * "ID";"Type";"Name";"Documentation";"Specialization"
 */
@Setter
@Getter
public class CsvElementHeadPosition {
    private int id;
    private int type;
    private int name;
    private int documentation;
    private int specialization;
    //Наличие заголовка
    private boolean titlePresent;

    public CsvElementHeadPosition(int id, int type, int name, int documentation, int specialization) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.documentation = documentation;
        this.specialization = specialization;
    }

    public CsvElementHeadPosition(int id, int type, int name, int documentation, int specialization,
                                  boolean titlePresent) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.documentation = documentation;
        this.specialization = specialization;
        this.titlePresent = titlePresent;
    }

    public CsvElementHeadPosition() {
        //
    }

    @Override
    public String toString() {
        return "LoadFileCsvHeadElement{" +
                "id=" + id +
                ", type=" + type +
                ", name=" + name +
                ", documentation=" + documentation +
                ", specialization=" + specialization +
                '}';
    }
}
