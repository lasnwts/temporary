package com.kibersystems.kmservices_archi.repository;

import com.kibersystems.kmservices_archi.model.Properties;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PropertiesRepo extends JpaRepository<Properties, Long> {
}
