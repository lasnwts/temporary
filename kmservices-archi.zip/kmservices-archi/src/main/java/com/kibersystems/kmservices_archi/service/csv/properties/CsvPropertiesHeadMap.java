package com.kibersystems.kmservices_archi.service.csv.properties;

import com.kibersystems.kmservices_archi.model.csv.CsvPropertiesHeadPosition;
import org.springframework.stereotype.Component;

////"ID";"Key";"Value"
@Component
public class CsvPropertiesHeadMap {
    private static final String COMMA_DELIMITER = ";";

    /**
     * Маппинг строки в объект
     *
     * @param line - строка из файла с заголовками
     * @return - объект CsvAccNtTrgHeadPosition
     */
    public CsvPropertiesHeadPosition map(String line, String commaDelimiter) {
        CsvPropertiesHeadPosition csvPropertiesHeadPosition = new CsvPropertiesHeadPosition();
        String[] values = line.split(commaDelimiter);
        if (values.length == 0) {
            csvPropertiesHeadPosition.setTitlePresent(false);
            return csvPropertiesHeadPosition;
        }
        /**
         * 1,2,3
         * "ID";"Type";"Name";"Documentation";"Specialization"
         */
        //1 Id
        csvPropertiesHeadPosition.setId(getPosition("ID", values));
        //2 Type
        csvPropertiesHeadPosition.setKeys(getPosition("Key", values));
        //3 Name
        csvPropertiesHeadPosition.setValue(getPosition("Value", values));
        csvPropertiesHeadPosition.setTitlePresent(true);
        return csvPropertiesHeadPosition;
    }

    /**
     * Получение позиции
     *
     * @param key    - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values) {

        for (int i = 0; i < values.length; i++) {
            if (values[i].equalsIgnoreCase(key)) {
                return i;
            }
        }
        return -1;
    }


}
