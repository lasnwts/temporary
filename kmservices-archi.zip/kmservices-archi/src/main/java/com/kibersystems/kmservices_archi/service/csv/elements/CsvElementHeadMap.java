package com.kibersystems.kmservices_archi.service.csv.elements;

import com.kibersystems.kmservices_archi.model.csv.CsvElementHeadPosition;
import org.springframework.stereotype.Component;


/**
 * Поля (Filed)
 * "ID";"Type";"Name";"Documentation";"Specialization"
 *
 */
@Component
public class CsvElementHeadMap {

    private static final String COMMA_DELIMITER = ";";

    /**
     * Маппинг строки в объект
     *
     * @param line - строка из файла с заголовками
     * @return - объект CsvAccNtTrgHeadPosition
     */
    public CsvElementHeadPosition map(String line, String commaDelimiter) {
        CsvElementHeadPosition csvElementHeadPosition = new CsvElementHeadPosition();
        String[] values = line.split(commaDelimiter);
        if (values.length == 0) {
            csvElementHeadPosition.setTitlePresent(false);
            return csvElementHeadPosition;
        }
        /**
         * 1,2,3,4,5
         * "ID";"Type";"Name";"Documentation";"Specialization"
         */
        //1 Id
        csvElementHeadPosition.setId(getPosition("ID", values));
        //2 Type
        csvElementHeadPosition.setType(getPosition("Type", values));
        //3 Name
        csvElementHeadPosition.setName(getPosition("Name", values));
        //4 Documentation
        csvElementHeadPosition.setDocumentation(getPosition("Documentation", values));
        //5 Specialization
        csvElementHeadPosition.setSpecialization(getPosition("Specialization", values));
        csvElementHeadPosition.setTitlePresent(true);
        return csvElementHeadPosition;
    }

    /**
     * Получение позиции
     *
     * @param key    - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values) {

        for (int i = 0; i < values.length; i++) {
            if (values[i].equalsIgnoreCase(key)) {
                return i;
            }
        }
        return -1;
    }

}
