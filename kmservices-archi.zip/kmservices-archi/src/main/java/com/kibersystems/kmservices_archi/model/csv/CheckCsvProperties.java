package com.kibersystems.kmservices_archi.model.csv;

import com.kibersystems.kmservices_archi.model.LoadError;
import com.kibersystems.kmservices_archi.model.Properties;
import lombok.Getter;
import lombok.Setter;


/**
 * Класс для свойств
 */
@Getter
@Setter
public class CheckCsvProperties {
    private Properties properties;
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация

    public CheckCsvProperties() {
        //
    }

    public CheckCsvProperties(Properties properties, LoadError loadError, boolean exists) {
        this.properties = properties;
        this.loadError = loadError;
        this.exists = exists;
    }

    @Override
    public String toString() {
        return "CheckCsvProperties{" +
                "properties=" + properties +
                ", loadError=" + loadError +
                ", exists=" + exists +
                '}';
    }
}
