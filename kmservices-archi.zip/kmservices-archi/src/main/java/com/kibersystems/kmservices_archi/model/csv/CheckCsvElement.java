package com.kibersystems.kmservices_archi.model.csv;

import com.kibersystems.kmservices_archi.model.Element;
import com.kibersystems.kmservices_archi.model.LoadError;
import lombok.Getter;
import lombok.Setter;

/**
 * Класс проверки заполнения элементов
 */
@Setter
@Getter
public class CheckCsvElement {
    private Element element;
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация

    public CheckCsvElement(Element element, LoadError loadError, boolean exists) {
        this.element = element;
        this.loadError = loadError;
        this.exists = exists;
    }

    public CheckCsvElement() {
        //
    }


}
