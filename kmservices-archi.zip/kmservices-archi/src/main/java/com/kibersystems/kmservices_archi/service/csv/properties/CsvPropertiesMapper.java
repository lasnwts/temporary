package com.kibersystems.kmservices_archi.service.csv.properties;

import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.model.LoadError;
import com.kibersystems.kmservices_archi.model.Properties;
import com.kibersystems.kmservices_archi.model.csv.CheckCsvProperties;
import com.kibersystems.kmservices_archi.model.csv.CsvPropertiesHeadPosition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Date;

//"ID";"Key";"Value"

@Component
public class CsvPropertiesMapper {

    Logger log = LoggerFactory.getLogger(CsvPropertiesMapper.class);


    public CheckCsvProperties map(String line, CsvPropertiesHeadPosition position, String fileName, int lineNumber, String commaDelimiter) {

        String[] values = line.split(commaDelimiter);

        //Пустая срока
        if (values.length < 2) {
            return new CheckCsvProperties(new Properties(), new LoadError(lineNumber, fileName, line, "Пустая строка, пропускаем.", new Date(), false), false);
        }

        //Не заполненная строка
        if (values.length < 3) {
            return new CheckCsvProperties(new Properties(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        Properties properties = new Properties();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        properties.setFileName(fileName);
        properties.setNumLine(lineNumber);


        //1
        try {
            if (position.getId() > -1) {
                properties.setId(check(values[position.getId()]));
                properties.setFakeid(check(values[position.getId()]) + "_" + lineNumber);
            } else {
                setLoadError("Не найден обязательный параметр:ID", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ID: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, ID: ", LG.USBLOGERROR, e);
        }

        //2
        try {
            if (position.getKeys() > -1) {
                properties.setKeys(check(values[position.getKeys()]));
            } else {
                setLoadError("Не найден обязательный параметр:KEY", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:KEY" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:KEY: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, KEY: ", LG.USBLOGERROR, e);
        }

        try {
            if (position.getValue() > -1) {
                properties.setValue(check(values[position.getValue()]));
            } else {
                setLoadError("Не найден обязательный параметр:Value", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Value" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Value: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace, Value: ", LG.USBLOGERROR, e);
        }

        //Возврат
        return new CheckCsvProperties(properties, loadError, true);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote1(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("'", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String rQuote2(String line) {
        if (line == null) {
            return "";
        } else {
            return line.replace("\"", "*");
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getFirstQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String firstChar = line.substring(0, 1);
            if (firstChar.equalsIgnoreCase("\"")) {
                return line.substring(1, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка
     *
     * @param line - входная строка
     * @return строка после обертки
     */
    public String getLastQuote(String line) {
        if (line == null || line.isEmpty()) {
            return "";
        } else {
            String lastChar = line.substring(line.length() - 1);
            if (lastChar.equalsIgnoreCase("\"")) {
                return line.substring(0, line.length() - 1);
            } else {
                return line;
            }
        }
    }

    /**
     * Обертка над строкой
     *
     * @param line - строка
     * @return - строка
     */
    public String getLineTrim(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обертка: Если внутри значения поля в файле содержится одинарная (кавычка) следует заменять на символ звездочка (*).
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String check(String line) {
        return rQuote1(rQuote2(getLastQuote(getFirstQuote(getLineTrim(line))))).trim();
    }

}
