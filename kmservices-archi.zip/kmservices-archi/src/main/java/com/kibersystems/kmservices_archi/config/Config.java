package com.kibersystems.kmservices_archi.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Component
@ConfigurationProperties
public class Config {

    /**
     * Путь к сетевой папке с файлами
     */
    @Value("${file.url}")
    private String fileUrl;

    //Разделитель значений в CSV файле
    @Value("${file.comma}")
    private String fileCommaDelimiter;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    @Setter
    String tempDirUploadFile;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${app.destination.folder}")
    private String netFileShare;

    // ---- Реализация ----


    public String getAppName() {
        return appName;
    }
}
