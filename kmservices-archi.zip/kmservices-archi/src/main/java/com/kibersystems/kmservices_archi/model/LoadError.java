package com.kibersystems.kmservices_archi.model;


import java.util.Date;


/**
 * Класс для хранения ошибок при загрузке файла
 */
public class LoadError {
    private int lineNumber;  //Номер строки
    private String fileName; //Имя файла
    private String line;    //Строка с ошибкой
    private String errorMessage; //описание ошибки
    private Date date; //дата и время возникновения ошибки
    private boolean status; //false - нет ошибок, true - есть ошибка

    public LoadError() {
        //empty
    }

    public LoadError(int lineNumber, String fileName, String line, String errorMessage, Date date, boolean status) {
        this.lineNumber = lineNumber;
        this.fileName = fileName;
        this.line = line;
        this.errorMessage = errorMessage;
        this.date = date;
        this.status = status;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LoadError{" +
                "Номер строки в файле =" + lineNumber +
                ", Имя файла='" + fileName +
                ", Ошибка='" + errorMessage +
                ", Строка='" + line +
                '}';
    }
}
