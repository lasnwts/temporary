package com.kibersystems.kmservices_archi.repository;

import com.kibersystems.kmservices_archi.model.Element;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ElementRepo extends JpaRepository<Element, Long> {
}
