package com.kibersystems.kmservices_archi.service.csv.elements;

import com.kibersystems.kmservices_archi.config.Config;
import com.kibersystems.kmservices_archi.config.LG;
import com.kibersystems.kmservices_archi.model.csv.CsvElementHeadPosition;
import com.kibersystems.kmservices_archi.service.csv.InvalidCharsetException;
import com.kibersystems.kmservices_archi.util.Support;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Service
public class LoadHeadCsvElement {

    private final CsvElementHeadMap csvElementHeadMap;
    private final Support support;
    private final Config config;

    Logger log = LoggerFactory.getLogger(LoadHeadCsvElement.class);

    @Autowired
    public LoadHeadCsvElement(CsvElementHeadMap csvElementHeadMap, Support support, Config config) {
        this.csvElementHeadMap = csvElementHeadMap;
        this.support = support;
        this.config = config;
    }

    /**
     * Получение заголовка файла CSV
     *
     * @param file     - файл для загрузки
     * @param fileName - имя файла
     * @param thread   - номер потока
     * @return - заголовок файла
     */
    public Optional<CsvElementHeadPosition> loadFile(File file, String fileName, long thread) {

        //Если файла не существует, выходим
        if (file == null || !file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadHeadCsvElement get CsvElementHeadPosition, переданный Файл {} не существует", LG.USBLOGERROR, thread, fileName);
            return Optional.empty();
        }

        log.info("{}:T{}: Подготовка процесса: Load LoadAccNtTrgFile к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), support.formatDateTime(new Date()));
        AtomicReference<CsvElementHeadPosition> elementHeadPositionAtomicReference = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadAccNtTrgFile, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));

        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8).filter(s -> s.contains("\"ID\";\"Type\";\"Name\";\"Documentation\";\"Specialization\""))) {
            lines.forEach(line -> {
                        try {
                            elementHeadPositionAtomicReference.set(csvElementHeadMap.map(support.removeQuote(support.getWrapLine(line.trim())), config.getFileCommaDelimiter())); //разбираем, что где находится в строке
                        } catch (Exception e) {
                            log.error("{}:T{}: Возникла Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}:::Stack_trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            long endTime = System.currentTimeMillis();
            log.info("{}:T{}: Завершение процесса: LoadAccNtTrgFile. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
            return Optional.ofNullable(elementHeadPositionAtomicReference.get());
        } catch (Exception e) {
            log.error("{}:T{}: Возникла Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}:Stack-trace:", LG.USBLOGERROR, thread, e);
            return Optional.empty();
        }
    }
}
