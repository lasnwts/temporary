package com.kibersystems.kmservices_archi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KmservicesArchiApplicationTests {

	@Test
	void contextLoads() {
	}

}
