package ru.usb.sftprowijdbccftbankguarantees.service.sftp;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;

@Service
public class SftpDelFileService {
    private final Configure configure;

    @Autowired
    public SftpDelFileService(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(SftpDelFileService.class);

    /**
     * Удаление файла с sftp
     *
     * @param file   файл который надо удалить
     * @param sftpDirectory - директория на sftp сервере, где надо удалить файл
     * @return - true - файл успешно удален, false - ошибка удаления
     */
    public boolean delFile(String file, String sftpDirectory) {

        //         * Создаем соединение
        JSch jSch = new JSch();
        // Создаем сессию
        Session session = null;
        ChannelSftp channel = null;
        try {
            if (configure.isSftpNeedKey()){
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            //Создаем канал
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            channel.rm(sftpDirectory + "/" + file);
            logger.info("{}: File={} delete to sftp, successfully", Elog.UsbLogInfo, file);
            //Закрываем соединение
            setFinalConnected(session, channel);
            return true; //Файл успешно удален
        } catch (JSchException e) {
            logger.error("{}: SftpService:delFileToSftp(file).Session = Error!!", Elog.UsbLogError);
            logger.error("{}: Session.error::", Elog.UsbLogError, e);
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            if (channel != null && channel.isConnected()) {
                channel.disconnect();
            }
            return false;
        } catch (SftpException e) {
            logger.error("{}:SftpService:delFileToSftp(file).channel.del({})", Elog.UsbLogError, file);
            logger.error("{}:channel.rm.error::", Elog.UsbLogError, e);
            setFinalConnected(session, channel);
            return false;
        }
    }


    /**
     * Закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }

}
