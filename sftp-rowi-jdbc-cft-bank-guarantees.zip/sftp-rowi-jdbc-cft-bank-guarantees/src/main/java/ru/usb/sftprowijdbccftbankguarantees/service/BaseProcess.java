package ru.usb.sftprowijdbccftbankguarantees.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.model.FileMove;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpDelFileService;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpGetFileService;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpListFileService;
import java.util.List;

@Service
public class BaseProcess {
    private final Logger logger = LoggerFactory.getLogger(BaseProcess.class);

    private final SftpListFileService sftpListFileService;
    private final SftpGetFileService sftpGetFileService;
    private final SftpDelFileService sftpDelFileService;
    private final Configure configure;

    @Autowired
    public BaseProcess(SftpListFileService sftpListFileService, SftpGetFileService sftpGetFileService,
                       SftpDelFileService sftpDelFileService, Configure configure) {
        this.sftpListFileService = sftpListFileService;
        this.sftpGetFileService = sftpGetFileService;
        this.sftpDelFileService = sftpDelFileService;
        this.configure = configure;
    }

    public void getBankGarantee() {
        List<String> list = sftpListFileService.getListFileToSftp(configure.getSftpDirectory());
        list.forEach(sftpFile -> {
            logger.info("File:{}", sftpFile);
            if (configure.isBankArchiveXConfirmed() || sftpFile.toLowerCase().contains(".xml")) {
                FileMove fileMove = sftpGetFileService.getFileToSftp(sftpFile, configure.getSftpDirectory(), configure.getSftpDirDownload(), true);
                logger.info("FileMove ={}", fileMove);
                if (configure.isSftpFileDelete() && fileMove.isWorkResult()){
                    sftpDelFileService.delFile(sftpFile, configure.getSftpDirectory());
                }
            }
        });
    }

}
