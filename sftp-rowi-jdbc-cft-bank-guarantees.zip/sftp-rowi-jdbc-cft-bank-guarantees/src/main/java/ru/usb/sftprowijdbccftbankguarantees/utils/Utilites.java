package ru.usb.sftprowijdbccftbankguarantees.utils;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.service.database.GetPrepareClob;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;


/**
 * Вспомогательный класс для работы
 */
@Component
public class Utilites {

    private final Configure configure;

    private final GetPrepareClob getPrepareClob;

    @Autowired
    public Utilites(Configure configure, GetPrepareClob getPrepareClob) {
        this.configure = configure;
        this.getPrepareClob = getPrepareClob;
    }

    Logger logger = LoggerFactory.getLogger(Utilites.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Отправка файлов в ЦФТ процедуру
     * @param f
     * @return
     */
    public String fileProcessed(File f) {
        String content = null;
        File file1251 = null;
        try {
            content = new String(Files.readAllBytes(Paths.get(f.getAbsolutePath())));
            logger.info("{}:Содержимое файла: {}", Elog.UsbLogInfo, f.getAbsolutePath());
            logger.info("{}:{}", Elog.UsbLogInfo, content);
        } catch (IOException e) {
            logger.error("{}: Ошибка чтения из файла {}", Elog.UsbLogError, f.getAbsolutePath());
            logger.error("{}:", Elog.UsbLogError, e);
        }
        try {
            FileUtils.writeStringToFile(new File(configure.getNetFileShare() + File.separator + "1251" +
                    File.separator + f.getName()), partContent(content), Charset.forName("windows-1251"));
            file1251 = new File(configure.getNetFileShare() + File.separator + "1251" + File.separator + f.getName());
            String s = clobPrepare(file1251);
            logger.info("s:{}", s);
            //Удаляем промежуточный файл
            FileUtils.forceDelete(file1251);
        } catch (IOException e) {
            logger.error("{}: Ошибка записи [ FileUtils.writeStringToFile] файла {}", Elog.UsbLogError, f.getAbsolutePath());
            logger.error("{}:", Elog.UsbLogError, e);
        }
        return "done";
    }

    /**
     * Получаем готовое сообщение
     *
     * @param f
     * @return
     * @throws IOException
     */
    private String clobPrepare(File f) throws IOException {
        return getPrepareClob.getBody(f);
    }

    /**
     * Вырезаем часть сообщения без UTF-8
     *
     * @param content - сообщение с tf-8
     * @return - сообщение без utf-8
     */
    private String partContent(String content) {
        if (content == null) {
            return "";
        } else {
            return content.substring(content.indexOf("<orderBgBankExport>"));
        }
    }

}
