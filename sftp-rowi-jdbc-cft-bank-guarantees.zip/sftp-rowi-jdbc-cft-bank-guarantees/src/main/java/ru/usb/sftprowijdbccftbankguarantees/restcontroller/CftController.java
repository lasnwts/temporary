package ru.usb.sftprowijdbccftbankguarantees.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.model.ValidFile;
import ru.usb.sftprowijdbccftbankguarantees.service.UploadService;
import ru.usb.sftprowijdbccftbankguarantees.utils.Utilites;
import ru.usb.sftprowijdbccftbankguarantees.utils.WorkWithFiles;
import ru.usb.sftprowijdbccftbankguarantees.utils.XmlValidator;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с ЦФТ и XML документом", description = "XML для ЦФТ банка")
public class CftController {

    private final UploadService uploadService;
    private final WorkWithFiles withFiles;
    private final Configure configure;
    private final Utilites utilites;

    @Autowired
    public CftController(UploadService uploadService, WorkWithFiles withFiles, Configure configure, Utilites utilites) {
        this.uploadService = uploadService;
        this.withFiles = withFiles;
        this.configure = configure;
        this.utilites = utilites;
    }

    private final Logger logger = LoggerFactory.getLogger(CftController.class);

    @PostMapping(
            path = "/validate",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Передача файла xml для проверки схемы.")
    public ResponseEntity<String> handleUpload(
            @RequestPart("file") MultipartFile file) {

        logger.info("{}: POST запрос (требуется загрузить файл вручную): .api/validate/upload:file", Elog.UsbLogInfo);

        File fileInput = null;
        try {
            fileInput = new File(uploadService.uploadFileToServer(file));
            if (withFiles.checkFileExists(fileInput)) {
                logger.info("{}: Получен файл:{} ", Elog.UsbLogInfo, fileInput.getName());
                logger.info("{}: Путь к файлу ::{}", Elog.UsbLogInfo, fileInput.getPath());
                logger.info("{}: Размер файл ::{}", Elog.UsbLogInfo, fileInput.length());
                ValidFile validFile = xmlValidation(fileInput);
                if (validFile.isValid()) {
                    return ResponseEntity.status(HttpStatus.OK).body("Документ валиден.");
                } else {
                    return new ResponseEntity<>("Документ не валиден." + validFile.getMessage(), HttpStatus.BAD_REQUEST);
                }
            } else {
                logger.error("{}: Возникла ошибка, при сохранении файла, error:{}", Elog.UsbLogError, fileInput);
                return new ResponseEntity<>("Возникла ошибка, при сохранении файла, error:" + withFiles.getWrapNull(fileInput.getAbsolutePath()), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (IOException ex) {
            logger.error("{}: Возникла ошибка, при сохранении файла, error:", Elog.UsbLogError, ex);
            return new ResponseEntity<>("Возникла ошибка, при сохранении файла, error:" + withFiles.getWrapNull(ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping(
            path = "/cft",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Передача файла xml для проверки схемы.")
    public ResponseEntity<String> cftLoadFile(
            @RequestPart("file") MultipartFile file) {
        logger.info("{}: POST запрос (требуется загрузить файл вручную): .api/cft:file", Elog.UsbLogInfo);
        try {
            File fileInput = new File(uploadService.uploadFileToServer(file));
            if (withFiles.checkFileExists(fileInput)) {
                logger.info("{}: Получен файл:{} ", Elog.UsbLogInfo, fileInput.getName());
                logger.info("{}: Путь к файлу ::{}", Elog.UsbLogInfo, fileInput.getPath());
                logger.info("{}: Размер файл ::{}", Elog.UsbLogInfo, fileInput.length());
                return ResponseEntity.status(HttpStatus.OK).body(utilites.fileProcessed(fileInput));
            } else {
                logger.error("{}: Возникла ошибка, при обработке файла, error:{}", Elog.UsbLogError, fileInput);
                return null;
            }
        } catch (IOException e) {
            logger.error("{}: Возникла ошибка, при обработке файла, error:{}", Elog.UsbLogError, file.getName());
            return new ResponseEntity<>("Возникла ошибка, при обработке файла, error:" + withFiles.getWrapNull(file.getOriginalFilename() +
                    withFiles.getWrapNull(e.getMessage())), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Проверка файла на валидность.
     *
     * @param file - файл который надо проверить
     * @return - результат. true - валиден, false - не валиден
     */
    private ValidFile xmlValidation(File file) {
        boolean validXML = false;
        ValidFile validFile = new ValidFile(false, "");
        try {
            validXML = new XmlValidator(configure.getXsdValidationSchema(), file.getAbsolutePath()).isValid();
            validFile.setValid(validXML);
        } catch (IOException | SAXException e) {
            logger.error("{}: Ошибка валидации файла:{}, по схеме xsd:{}", Elog.UsbLogError, file.getName(), configure.getXsdValidationSchema());
            logger.error("{}: excpetion", Elog.UsbLogError, e);
            validFile.setMessage(e.getMessage());
            validFile.setValid(false);
        }
        if (validXML) {
            logger.info("{}: File:{} validation successfully.", Elog.UsbLogInfo, file.getName());
        } else {
            validFile.setMessage("error on validation. Файл не соответствует схеме:" + configure.getXsdValidationSchema());
            logger.info("{}: File:{} error on validation. Файл не соответствует схеме:{}", Elog.UsbLogInfo, file.getName(), validXML);
        }
        return validFile;
    }


}
