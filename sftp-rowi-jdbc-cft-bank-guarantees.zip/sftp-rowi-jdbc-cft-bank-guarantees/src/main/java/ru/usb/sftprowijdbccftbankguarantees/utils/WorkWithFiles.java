package ru.usb.sftprowijdbccftbankguarantees.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Component
public class WorkWithFiles {
    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: Directory :: [{}] Not Exist! Fail!", Elog.UsbLogError, targetPath);
        return false;
    }

    /**
     * Метод проверки и создания директорий при необходимости
     *
     * @param pathDirectory - строка с полным путем для директорий
     * @return - true : директория создана или существует, false : директория не создана
     */
    public boolean createdDirectory(String pathDirectory) {

        if (pathDirectory == null) {
            logger.error("{}Error try created directory, parameters with name [pathDirectory]=NULL!", Elog.UsbLogError);
            return false;
        }

        Path path = Paths.get(pathDirectory);

        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
                logger.info("{}: Directory created::{}", Elog.UsbLogInfo, path);
                return true;
            } catch (IOException e) {
                logger.error("{}: Error try created directory!!!::{} ", Elog.UsbLogError, path);
                logger.error("{}: Stack", Elog.UsbLogError, e);
                return false;
            }
        } else {
            return true;
        }
    }

    /**
     * Удаление файла, представленных  строковым именем
     *
     * @param fromFile - полное имя файла, который надо удалить
     */
    public boolean delFilesSName(String fromFile) {
        Path from = Paths.get(fromFile);
        try {
            logger.info("{}: Try delete file:{}", Elog.UsbLogInfo, fromFile);
            Files.deleteIfExists(from);
            logger.info("{}: File: {} delete successfully.", Elog.UsbLogInfo, fromFile);
            return true;
        } catch (IOException e) {
            logger.error("PrintStackTrace::delete file:{} error::{}", fromFile, e.getMessage());
            return false;
        }
    }

    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param toFile   - куда (полный путь с именем)
     */
    public boolean moveFileSName(String fromFile, String toFile) {
        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile);
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toString())) {
                Files.deleteIfExists(from);
                logger.info("{}: file:: {} moved to:{}", Elog.UsbLogError, from, to);
                return true;
            } else {
                logger.error("{}: Error for operation move:: file::{} moved to:{}", Elog.UsbLogError, from, to);
                return false;
            }
        } catch (IOException e) {
            logger.error("{}:PrintStackTrace::", Elog.UsbLogError, e);
            return false;
        }
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameFull) {
        Path path = Paths.get(fileNameFull);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :: [{}] not Exist.Fail!", Elog.UsbLogWarning, fileNameFull);
        return false;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        if (fileNameFull == null){
            return false;
        }
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :: [{}] not Exist.Fail!", Elog.UsbLogWarning, fileNameFull);
        return false;
    }

    /**
     * Возвращает EXT расширение
     *
     * @param fileName - файл с типом File
     * @return - расширение
     */
    public String getExtensionFromFile(File fileName) {
        String ext = StringUtils.getFilenameExtension(fileName.getName());
        if (ext == null) {
            ext = "";
        }
        return ext;
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Конвретация сообщения
     * @param message  - сообщение
     * @return - в кодировке win-1251
     */
    public String converter(String message) {
        try {
            String utf8String = message;
            return new String(utf8String.getBytes(StandardCharsets.UTF_8), "windows-1251");
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }
}
