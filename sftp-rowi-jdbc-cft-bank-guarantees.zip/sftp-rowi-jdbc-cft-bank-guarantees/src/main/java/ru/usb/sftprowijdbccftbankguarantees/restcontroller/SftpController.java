package ru.usb.sftprowijdbccftbankguarantees.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpDelFileService;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpGetFile;
import ru.usb.sftprowijdbccftbankguarantees.service.sftp.SftpListFileService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

//Валидировать текст, XML
//Бросить текст в ЦФТ.
// Показать настройки


@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с SFTP сервером и XML документом", description = "sftp ROWI, ЦФТ банка")
public class SftpController {
    private final Configure configure;
    private final SftpListFileService sftpListFileService;
    private final SftpGetFile sftpGetFile;

    private final SftpDelFileService sftpDelFileService;

    @Autowired
    public SftpController(Configure configure, SftpListFileService sftpListFileService,
                          SftpGetFile sftpGetFile, SftpDelFileService sftpDelFileService) {
        this.configure = configure;
        this.sftpListFileService = sftpListFileService;
        this.sftpGetFile = sftpGetFile;
        this.sftpDelFileService = sftpDelFileService;
    }

    private final Logger logger = LoggerFactory.getLogger(SftpController.class);

    @GetMapping("/list")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на получение списка файлов из каталога")
    public ResponseEntity<Object> getListFileOut() {
        logger.info("{}:Get запрос - получить список файлов на sftp:{}", Elog.UsbLogInfo, configure.getSftpDirectory());

        List<String> fileList = sftpListFileService.getListFileToSftp(configure.getSftpDirectory());
        if (fileList == null || fileList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Не удалось получить список файлов на SFTP, может быть каталог пустой");
        }
        logger.info("{}:---------------------------------+", Elog.UsbLogInfo);
        logger.info("{}: Каталог: {}", Elog.UsbLogInfo, configure.getSftpDirectory());
        fileList.forEach(sftpFile ->
                logger.info("{}: Содержит файл:{}", Elog.UsbLogInfo, sftpFile)
        );
        logger.info("{}:---------------------------------", Elog.UsbLogInfo);
        return ResponseEntity.status(HttpStatus.OK).body(fileList.toString());
    }

    @GetMapping("/file/{filename}")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на получение файла из каталога")
    public ResponseEntity<Resource> getFile(@Parameter(description = " Введите имя файла")
                                            @PathVariable(required = true) String filename) {
        logger.info("{}:Get File - запрос - получить файл c sftp:{}", Elog.UsbLogInfo, filename);
        File f = sftpGetFile.getFileFromSftp(filename, configure.getSftpDirectory());
        if (f != null) {
            InputStreamResource resource = null;
            try {
                resource = new InputStreamResource(new FileInputStream(f));
                HttpHeaders header = new HttpHeaders();
                header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + f.getName());
                header.add("Cache-Control", "no-cache, no-store, must-revalidate");
                header.add("Pragma", "no-cache");
                header.add("Expires", "0");

                return ResponseEntity.ok()
                        .headers(header)
                        .contentLength(f.length())
                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                        .body(resource);

            } catch (FileNotFoundException e) {
                logger.error("{}: Ошибка при чтении файла: {}", Elog.UsbLogError, f.getAbsolutePath());
                logger.error("{}: Stack:", Elog.UsbLogError, e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } else {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }

    @DeleteMapping("/file/{filename}")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на удаление файла из каталога на SFTP сервере")
    public ResponseEntity<Object> deleteFile(@Parameter(description = " Введите имя файла")
                                             @PathVariable(required = true) String filename) {
        logger.info("{}:Delete File - запрос - удалить файл c sftp:{}", Elog.UsbLogInfo, filename);

        if (sftpDelFileService.delFile(filename, configure.getSftpDirectory())) {
            logger.info("{}: Файл {} удален", Elog.UsbLogInfo, filename);
            return ResponseEntity.status(HttpStatus.OK).body("Файл удален, файл:[" + filename + "]");
        } else {
            logger.error("{}: Ошибка удаления файла:{}", Elog.UsbLogError, filename);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Не удалось удалить файл на SFTP сервере, файл:[" + filename + "]");
        }
    }


}
