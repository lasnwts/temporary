package ru.usb.sftprowijdbccftbankguarantees.service.sftp;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.model.FileMove;
import ru.usb.sftprowijdbccftbankguarantees.utils.WorkWithFiles;

import java.io.File;

@Service
public class SftpGetFile {
    private final Configure configure;
    private final WorkWithFiles withFiles;

    @Autowired
    public SftpGetFile(Configure configure, WorkWithFiles withFiles) {
        this.configure = configure;
        this.withFiles = withFiles;
    }

    Logger logger = LoggerFactory.getLogger(SftpGetFile.class);

    /**
     * Передача файла с сервера sftp
     */
    public File getFileFromSftp(String file, String sftpDir) {

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            if (configure.isSftpNeedKey()) {
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            ChannelSftp channel = null;
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            channel.cd("/" + sftpDir);
            channel.get(file, configure.getNetFileShare() + File.separator + file);
            logger.info("{}:File={} download successfully from sftp, to directory:{}{}{}", Elog.UsbLogInfo, file, configure.getSftpDirDownload(), File.separator, file);
            //Закрываем соединение
            setFinalConnected(session, channel);
        } catch (JSchException e) {
            logger.error("{}:SftpService:GetFileToSftp(file).Session = Error!!", Elog.UsbLogError);
            logger.error("{}: Session.error::", Elog.UsbLogError, e);
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            return null;
        } catch (SftpException e) {
            if (session.isConnected()) {
                session.disconnect();
            }
            logger.error("{}: SftpService:GetFileToSftp(file).channel.cd({})", Elog.UsbLogError, configure.getSftpDirectory());
            logger.error("{}:channel.cd.error::", Elog.UsbLogError, e);
            logger.error("{}:SftpService:GetFileToSftp(file).channel.get({})" , Elog.UsbLogError, sftpDir + "/" + file);
            logger.error("{}: channel.Get.error::", Elog.UsbLogError, e);
            return null;
        }


        File f = new File(configure.getNetFileShare() + File.separator + file);
        if (withFiles.checkFileExists(f)) {
            FileMove fileMove = new FileMove();
            fileMove.setFilename(file);
            fileMove.setFileSize(f.length());
            fileMove.setAbsoluteFilename(f.getAbsolutePath());
            fileMove.setDirectory(configure.getNetFileShare());
            fileMove.setErrorMessage("");
            fileMove.setWorkResult(true);
            logger.info("{}: Загружен файл с сервера SFTP:{}", Elog.UsbLogInfo, fileMove);
            /**
             * Тут логика обработки файла
             */
            return f; //Файл успешно загружен
        } else {
            logger.error("{}: Произошла ошибка загрузки файла, файл с сервера SFTP:{}", Elog.UsbLogError, file);
            return null;
        }
    }

    /**
     * закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }
}
