package ru.usb.sftprowijdbccftbankguarantees.service.database;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.UUID;

@Component
public class GetPrepareClob {
    Logger logger = LoggerFactory.getLogger(GetPrepareClob.class);
    String bodyHeader = "<?xml version=\"1.0\" encoding=\"windows-1251\"?><CIT_REQUEST><SYSTEM><BP_ID Value=\"BG_REQUEST_IN_Z\"/><CIT_Version Value=\"1.0\"/><ERR Value=\"\"/><FORMAT Value=\"XML\"/><INTERFACE_RET Value=\"\"/><MAIN_ID Value=\"\"/><MSG_ID Value=\"MSG_GUID\"/><SYNC Value=\"N\"/><SYS_ID Value=\"ROWI\"/><TAR_ID Value=\"ROWI\"/><Version Value=\"002\"/></SYSTEM><DATA>";
    /**
      //    String bodyHeader = "<?xml version=\"1.0\" encoding=\"windows-1251\"?><CIT_REQUEST><SYSTEM><BP_ID Value=\"BG_REQUEST_IN_Z\"></BP_ID><CIT_Version Value=\"1.0\"></CIT_Version><ERR Value=\"\"></ERR><FORMAT Value=\"JSON\"></FORMAT><INTERFACE_RET Value=\"\"></INTERFACE_RET><MAIN_ID Value=\"\"></MAIN_ID><MSG_ID Value=\"\"></MSG_ID><SYNC Value=\"N\"></SYNC><SYS_ID Value=\"EARCHIVE\"></SYS_ID><TAR_ID Value=\"IBSO_DISTR\"></TAR_ID><Version Value=\"002\"></Version></SYSTEM><DATA><BODY>";
     //FileUtils.readFileToString(f.getAbsoluteFile(), Charset.forName("windows-1251"));
     */
    String bodyFooter = "</DATA></CIT_REQUEST>";
    public String getBody(File f) throws IOException {
        String body = bodyHeader.replace("MSG_GUID", UUID.randomUUID().toString()) +
                FileUtils.readFileToString(f.getAbsoluteFile(), Charset.forName("windows-1251")) +
                bodyFooter;
        logger.info("{}: -- Подготовленное сообщение для ЦФТ --", Elog.UsbLogInfo);
        logger.info("{}: {}", Elog.UsbLogInfo, body);
        return body;
    }
}
