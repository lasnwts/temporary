package ru.usb.sftprowijdbccftbankguarantees.service.sftp;

import com.jcraft.jsch.*;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.model.FileMove;
import ru.usb.sftprowijdbccftbankguarantees.service.database.GetPrepareClob;
import ru.usb.sftprowijdbccftbankguarantees.utils.WorkWithFiles;
import ru.usb.sftprowijdbccftbankguarantees.utils.XmlValidator;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class SftpGetFileService {
    private final Configure configure;
    private final WorkWithFiles withFiles;
    private final GetPrepareClob getPrepareClob;

    @Autowired
    public SftpGetFileService(Configure configure, WorkWithFiles withFiles, GetPrepareClob getPrepareClob) {
        this.configure = configure;
        this.withFiles = withFiles;
        this.getPrepareClob = getPrepareClob;
    }

    Logger logger = LoggerFactory.getLogger(SftpGetFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public FileMove getFileToSftp(String file, String sftpDir, String destDirectory, boolean moveFlag) {

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            if (configure.isSftpNeedKey()) {
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            ChannelSftp channel = null;
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            channel.cd("/" + sftpDir);
            channel.get(file, configure.getNetFileShare() + File.separator + file);
            logger.info("{}:File={} download successfully from sftp, to directory:{}{}{}", Elog.UsbLogInfo, file, configure.getSftpDirDownload(), File.separator, file);
            //Закрываем соединение
            setFinalConnected(session, channel);
        } catch (JSchException e) {
            logger.error("{}:SftpService:GetFileToSftp(file).Session = Error!!", Elog.UsbLogError);
            logger.error("{}: Session.error::", Elog.UsbLogError, e);
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            return null;
        } catch (SftpException e) {
            if (session.isConnected()) {
                session.disconnect();
            }
            logger.error("{}: SftpService:GetFileToSftp(file).channel.cd({})", Elog.UsbLogError, configure.getSftpDirectory());
            logger.error("{}:channel.cd.error::", Elog.UsbLogError, e);
            logger.error("{}: SftpService:GetFileToSftp(file).channel.get({})", Elog.UsbLogError, sftpDir + "/" + file);
            logger.error("{}: channel.Get.error::", Elog.UsbLogError, e);
            return null;
        }


        File f = new File(configure.getNetFileShare() + File.separator + file);
        if (withFiles.checkFileExists(f)) {
            FileMove fileMove = new FileMove();
            fileMove.setFilename(file);
            fileMove.setFileSize(f.length());
            fileMove.setAbsoluteFilename(f.getAbsolutePath());
            fileMove.setDirectory(configure.getNetFileShare());
            fileMove.setErrorMessage("");
            fileMove.setWorkResult(true);
            logger.info("{}: Загружен файл с сервера SFTP:{}", Elog.UsbLogInfo, fileMove);
            /**
             * Тут логика обработки файла
             */
            return fileProcessed(f, moveFlag, destDirectory, fileMove, file); //Файл успешно загружен
        } else {
            logger.error("{}: Произошла ошибка загрузки файла, файл с сервера SFTP:{}", Elog.UsbLogError, file);
            return null;
        }
    }

    /**
     * закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }

    /**
     * Перенос файлов в конечный каталог
     *
     * @param sourceFile - файл полуячаемый с sftp
     * @param destFile   - файл в директории назначения
     * @return - успешность
     */
    private boolean moveFileDest(String sourceFile, String destFile, String destDirectory) {
        if (sourceFile == null) {
            logger.error("{}: Функция moveFileDest получила NULL вместо sourceFile", Elog.UsbLogError);
            return false;
        }
        if (destFile == null) {
            logger.error("{}: Функция moveFileDest получила NULL вместо destFile", Elog.UsbLogError);
            return false;
        }
        if (!withFiles.checkPathExists(destDirectory)) {
            logger.error("{}: Error! Ошибка! Каталог {} - недоступен!", Elog.UsbLogError, destFile);
            return false;
        }
        if (withFiles.checkFileExists(sourceFile)) {
            if (withFiles.moveFileSName(sourceFile, destFile)) {
                return true;
            } else {
                logger.error("{}: Произошла ошибка при переносе файла {} в каталог {}", Elog.UsbLogError, sourceFile, destFile);
                return false;
            }
        } else {
            logger.error("{}:Произошла ошибка при переносе файла {} в каталог {}", Elog.UsbLogError, sourceFile, destFile);
            return false;
        }
    }


    /**
     * Проверка файла на валидность.
     *
     * @param file - файл который надо проверить
     * @return - результат. true - валиден, false - не валиден
     */
    private boolean xmlValidation(File file) {
        boolean validXML = false;
        try {
            validXML = new XmlValidator(configure.getXsdValidationSchema(), file.getAbsolutePath()).isValid();
        } catch (IOException | SAXException e) {
            logger.error("{}: Ошибка валидации файла:{}, по схеме xsd:{}", Elog.UsbLogError, file.getName(), configure.getXsdValidationSchema());
            logger.error("{}: excpetion", Elog.UsbLogError, e);
        }
        if (validXML) {
            logger.info("{}: File:{} validation successfully.", Elog.UsbLogInfo, file.getName());
        } else {
            logger.info("{}: File:{} error on validation. Файл не соответствует схеме:{}", Elog.UsbLogInfo, file.getName(), validXML);
        }
        return validXML;
    }

    /**
     * Процедура переноса Файлов
     *
     * @param f             - Файл для переноса
     * @param moveFlag      - флаг необходимости переноса
     * @param destDirectory - директория куда переносим
     * @param fileMove      - класс FileMove
     * @param file          - строковое наименование файла
     * @return - FileMove
     */
    private FileMove movedFile(File f, boolean moveFlag, String destDirectory, FileMove fileMove, String file) {
        /**
         * Если передан флаг переноса файла
         */
        if (moveFlag) {
            logger.info("{}:Переносим в целевой каталог файл:{}", Elog.UsbLogInfo, f.getName());
            if (moveFileDest(f.getAbsolutePath(), destDirectory + File.separator + f.getName(), destDirectory)) {
                logger.info("{}: Перенос успешно завершен, можно удалить файл на ЗК", Elog.UsbLogInfo);
                fileMove.setAbsoluteFilename(destDirectory + File.separator + f.getName());
                fileMove.setDirectory(destDirectory);
                fileMove.setWorkResult(true);
                logger.info("{}: Загруженный файл с ЗК:{}", Elog.UsbLogInfo, fileMove);
            } else {
                logger.error("{}: Произошла ошибка загрузки файла, файл с сервера SFTP:{}", Elog.UsbLogError, file);
                fileMove.setErrorMessage("Произошла ошибка загрузки файла, файл с сервера SFTP");
                fileMove.setWorkResult(false);
            }
        }
        return fileMove;
    }

    /**
     * Обработка файлов XML
     *
     * @param f                    - файл полученный с sftp
     * @param moveFlag             - Флаг переноса
     * @param destinationDirectory - директория архивов
     * @param fileMove             - объект FileMove
     * @param file                 - имя файла на sftp строковое
     * @return - FileMove
     */
    private FileMove fileProcessed(File f, boolean moveFlag, String destinationDirectory, FileMove fileMove, String file) {
        if (withFiles.checkFileExists(f) && withFiles.getExtensionFromFile(f).equalsIgnoreCase("xml")) {
            if (xmlValidation(f)) {
                String content = null;
                try {
                    content = new String(Files.readAllBytes(Paths.get(f.getAbsolutePath())));
                    logger.info("{}:Содержимое файла: {}", Elog.UsbLogInfo, f.getAbsolutePath());
                    logger.info("{}:{}", Elog.UsbLogInfo, content);
                } catch (IOException e) {
                    fileMove.setErrorMessage(e.getMessage());
                    fileMove.setWorkResult(false);
                    logger.error("{}: Ошибка чтения из файла {}", Elog.UsbLogError, f.getAbsolutePath());
                    logger.error("{}:", Elog.UsbLogError, e);
                }
                try {
                    FileUtils.writeStringToFile(new File(configure.getNetFileShare() + File.separator + "1251" +
                            File.separator + f.getName()), partContent(content), Charset.forName("windows-1251"));
                    fileMove.setFile1251(new File(configure.getNetFileShare() + File.separator + "1251" +
                            File.separator + f.getName()));
                    clobPrepare(fileMove.getFile1251());
                    //Удаляем промежуточный файл
                    withFiles.delFilesSName(fileMove.getFile1251().getAbsolutePath());
                } catch (IOException e) {
                    fileMove.setErrorMessage(e.getMessage());
                    fileMove.setWorkResult(false);
                    logger.error("{}: Ошибка записи [ FileUtils.writeStringToFile] файла {}", Elog.UsbLogError, f.getAbsolutePath());
                    logger.error("{}:", Elog.UsbLogError, e);
                }
                return movedFile(f, true, destinationDirectory, fileMove, file);
            } else {
                fileMove.setWorkResult(false);
                return fileMove;
            }
        } else {
            if (configure.isBankArchiveXConfirmed()) {
                return movedFile(f, moveFlag, destinationDirectory, fileMove, file);
            } else {
                fileMove.setWorkResult(false);
                return fileMove;
            }
        }
    }

    /**
     * Получаем готовое сообщение
     *
     * @param f
     * @return
     * @throws IOException
     */
    private String clobPrepare(File f) throws IOException {
        return getPrepareClob.getBody(f);
    }

    /**
     * Вырезаем часть сообщения без UTF-8
     *
     * @param content - сообщение с tf-8
     * @return - сообщение без utf-8
     */
    private String partContent(String content) {
        if (content == null) {
            return "";
        } else {
            return content.substring(content.indexOf("<orderBgBankExport>"));
        }
    }

}
