package ru.usb.sftprowijdbccftbankguarantees.service.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ru.usb.sftprowijdbccftbankguarantees.configure.Elog;
import ru.usb.sftprowijdbccftbankguarantees.service.mail.ServiceMailError;
import ru.usb.sftprowijdbccftbankguarantees.utils.Utilites;

import java.sql.*;

@Service
public class PutClob {
    private final ServiceMailError serviceMailError;
    private final Utilites strUtils;

    @Autowired
    public PutClob(ServiceMailError serviceMailError, Utilites strUtils) {
        this.serviceMailError = serviceMailError;
        this.strUtils = strUtils;
    }

    private static final Logger logger = LoggerFactory.getLogger(PutClob.class);

    // Переменные для подключения к БД из файла properties
    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String user;

    @Value("${spring.datasource.password}")
    private String pass;

    @Value("${cft.schema}")
    private String cftSchema;

    @Value("${cft.catalog}")
    private String cftCatalog;

    @Value("${cft.timeout}")
    private int cftTimeout;

    @Value("${cft.document}")
    private String cftDocument;

    /**
     * 1 P_SOURCE_CODE	procedureColumnIn string
     * 2 P_MESS_BODY	procedureColumnIn string (clob)
     * 3 P_PRIORITY	procedureColumnIn int
     * 4 P_AQ_OUT	procedureColumnIn int
     * 5 P_CORR_ID	procedureColumnIn  string
     * 6 P_EMMEDIATE_PUT	procedureColumnIn int
     * 7 P_DELAY_TIME	procedureColumnIn int
     */
    public boolean putClob(String body) {

        logger.info("body={}", body);
        try (Connection conn = DriverManager.getConnection(url, user, pass);

             CallableStatement proc = conn.prepareCall("{call " + cftSchema + "." + cftCatalog + "." + "put2clob" + "(?,?,?,?,?,?,?)}")) {

            proc.setString(1, "EA_DOCUM");
            proc.setString(2, body);
            proc.setNull(3, Types.INTEGER);
            proc.setNull(4, Types.INTEGER);
            proc.setNull(5, Types.VARCHAR);
            proc.setNull(6, Types.INTEGER);
            proc.setNull(7, Types.INTEGER);
            proc.setQueryTimeout(cftTimeout);
            ResultSet resultSet = proc.executeQuery();
            logger.info("sql:done");
            return true;

        } catch (SQLException e) {
            logger.error("{}::ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+", Elog.UsbLogError);
            logger.error("{}::BaseProcess:putClob.error.code = {}", Elog.UsbLogError, e.getErrorCode());
            logger.error("{}::BaseProcess:putClob.error. Body(Что передаем в ЦФТ): = {}", Elog.UsbLogError, strUtils.getWrapNull(body));
            logger.error("{}::BaseProcess:putClob.error:stack", Elog.UsbLogError, e);
            logger.error("{}::ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
            serviceMailError.sendMailErrorSubject("Процесс sftp-rowi-jdbc-cft-bank-guarantees. Ошибка при вызове процедуры put2clob",
                    "Ошибка! SQL:" + strUtils.getWrapNull(e.getMessage()) + "\r\n" + "Body(Что передаем в ЦФТ):" + strUtils.getWrapNull(body));
            return false;
        }
    }
}
