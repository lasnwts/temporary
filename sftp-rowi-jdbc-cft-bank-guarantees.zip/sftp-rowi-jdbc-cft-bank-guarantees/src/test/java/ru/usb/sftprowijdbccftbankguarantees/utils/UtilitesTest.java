package ru.usb.sftprowijdbccftbankguarantees.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.sftprowijdbccftbankguarantees.configure.Configure;
import ru.usb.sftprowijdbccftbankguarantees.service.database.GetPrepareClob;
class UtilitesTest {

    private Utilites utilites;
    private Configure configure;
    private GetPrepareClob getPrepareClob;

    @BeforeEach
    void setup() {
        utilites = new Utilites(configure, getPrepareClob);
    }

    @Test
    void testWrapNull() {
        String line_test = "test 123   ";
        String null_line = null;
        Assertions.assertEquals("", utilites.getWrapNull(null_line));
        Assertions.assertEquals("test 123", utilites.getWrapNull(line_test));
        System.out.printf(utilites.getWrapNull(line_test));
    }
}