package ru.usb.sftprowijdbccftbankguarantees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SftpRowiJdbcCftBankGuaranteesApplicationTests {

	@Test
	void contextLoads() {
	}

}
