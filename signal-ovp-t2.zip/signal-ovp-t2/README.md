# signal-ovp-t2

signal-ovp-t2

## Authors

- [@LyapustinAS](lyapustinas@spb.uralsib.ru)

## Наименование МП 982624

982624 Установка сигнала в ОВП онлайн по подгруженным сделкам/ проводкам до Т-2 включительно

## Ссылка на МП 
https://sdportal/mprojects/982624
## Формулировка задачи
Сервис срабатывает 1 раз в день по таймеру Cron. Сервис обращается в базу OVP с запросом. После выполнения запроса, сервис формирует CSV файл, и отправляет его по почте как вложение.

## Список необходимых Доступов и Прав
Получить доступ к базе данных: edbt1.fc.uralsibbank.ru:1523/tbwt01
Получить доступ к таблицам: conversion_operations (право SELECT), SIGNALT2 (INSERT/UPDATE/DELETE/SELECT)
Доступ к серверу электронной почты: mailr5.nikoil.ru
## Описание основных переменных (для всех новых переменных)


### Temporary folder
#****************************************************************
app.destination.folder=temporary  - имя временного каталога, для работы сервиса

 
### Scheduler properties 0 0 12 * * 1,2,3,4,5,6,7
#****************************************************************
cron-scheduler=0 0 1 * * 1,2,3,4,5,6,7  - таймер cron

 
### Query depth from operation_date
#**************************************************************** 
query.depth=2 - глубина дней, на которую устанавливается 
    запрос к CONVERSION_OPERATIONS для поля operation_date. 
   В запросе ставится дата=Текущая дата - query.depth


### ENABLE SERVICE
#****************************************************************
service.enabled=true - переменная, отображающая включен сервис (true) или выключен false). Если сервис выключен, 
    значит сервис не запустится по cron. И не сформирует файл.


## Таблицы / Представления / Процедуры используемые сервисом
Список прав. TBW.
Основной SQL запрос:  

#### select id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated from CONVERSION_OPERATIONS where portfolio in (-2,2,7000,7001) and operation_date < TO_DATE(:queryDepth, 'DD.MM.YYYY HH24:MI:SS') and updated <= TO_DATE(:now, 'DD.MM.YYYY HH24:MI:SS') and updated >= TO_DATE(:last, 'DD.MM.YYYY HH24:MI:SS')
## Системы участвующие в интеграции
ОВП

## Ссылка на сервис
https://signal-ovp-t2.intgr-t.fc.uralsibbank.ru/

## Люди участвующие в тестировании
Шайдуллин Вадим Илдарович <ShajdullinVI@ufa.uralsib.ru>
Анкудимова Ольга Александровна <AnkudimovaOA@ufa.uralsib.ru>
Чердынцева Екатерина Юрьевна <CherdyntseEY@ufa.uralsib.ru>
