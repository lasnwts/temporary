package ru.usb.signal_ovp_t2;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class SignalOvpT2Application implements CommandLineRunner {

    private final Config config;

    @Autowired
    public SignalOvpT2Application(Config config) {
        this.config = config;
    }

    private static final Logger logger = LoggerFactory.getLogger(SignalOvpT2Application.class);

    public static void main(String[] args) {
        SpringApplication.run(SignalOvpT2Application.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${spring.application.name}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r Service [Микросервис: signal-ovp-t2] Интеграционный поток. МП 982624.")
                .contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
                .version(appVersion)
                .description("API для [Интеграционный поток. МП 982624 Установка сигнала в ОВП он-лайн по подгруженным сделкам/ проводкам до Т-2 включительно]" +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        //Проверка путей
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));
        logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
        config.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : signal-ovp-t2", LG.USBLOGINFO);
        logger.info("{}:| Description of service       : Интеграционный поток. МП 982624 Установка сигнала в ОВП он-лайн по подгруженным сделкам/ проводкам до Т-2 включительно.", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 24/02/2025", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                  24.02.2025  : 0.0.10 Базовая версия.", LG.USBLOGINFO);
        logger.info("{}:|                  03.03.2025  : 0.0.12 Добавлен README.", LG.USBLOGINFO);
        logger.info("{}:|                  15.04.2025  : 0.0.14 Доработка.", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("..");
        logger.info(".");

    }
}
