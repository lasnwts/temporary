package ru.usb.signal_ovp_t2.service.mail;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class EmailService {
    private final JavaMailSender emailSender;
    private final Config config;

    @Autowired
    public EmailService(JavaMailSender emailSender, Config config) {
        this.emailSender = emailSender;
        this.config = config;
    }

    Logger logger = LoggerFactory.getLogger(EmailService.class);

    /**
     * Отправка простого письма
     * @param toAddress - список адресов
     * @param subject - тема
     * @param message - сообщение
     */
    public void sendSimpleEmail(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:: Переменные toAddress, subject, message не могут быть NULL!", LG.USBLOGERROR);
            return;
        }

        logger.info("{}:Send email message, toAddress:{} |subject:{} [ |message:{}]", LG.USBLOGINFO, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(config.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:[sendSimpleEmail]Email подготовлен к отправке по адресу =>:{}", LG.USBLOGINFO, mailRecepient);
                    try {
                        emailSender.send(simpleMailMessage);
                        logger.info("{}:[sendSimpleEmail]Email отправлен по адресу=:{}", LG.USBLOGINFO, mailRecepient);
                    } catch (Exception mailEx) {
                        logger.error("{}:[sendSimpleEmail]Возникла ошибка при отправке письма:", LG.USBLOGERROR, mailEx);
                    }
                });
            } else {
                logger.error("{}:ERROR:[sendSimpleEmail]:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!+", LG.USBLOGERROR);
            }
        } else {
            logger.error("{}:ERROR:[sendSimpleEmail]:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую! -", LG.USBLOGERROR);
        }
    }

    /**
     * Отправка почты
     * @param toAddress - куда отправить
     * @param subject - тема объекта
     * @param message - сообщение
     */
    public void sendSimpleEmailThrow(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:Error:: Переменные toAddress, subject, message не могут быть NULL!", LG.USBLOGERROR);
            return;
        }

        logger.info("{}:[sendSimpleEmailThrow] Send email message, toAddress:{} |subject:{} [ |message:{}]", LG.USBLOGINFO, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(config.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:[sendSimpleEmailThrow]:Email подготовлен к отправке по адресу:: {}", LG.USBLOGINFO, mailRecepient);
                    emailSender.send(simpleMailMessage);
                    logger.info("{}:[sendSimpleEmailThrow]:Email отправлен отправке по адресу: {}", LG.USBLOGINFO, mailRecepient);
                });
            } else {
                logger.error("{}:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USBLOGERROR);
            }
        } else {
            logger.error("{}:ERROR:[sendSimpleEmailThrow]: toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USBLOGERROR);
        }
    }


    /**
     * Отправка письма с вложением
     * @param toAddress - адрес получателя
     * @param subject - тема письма
     * @param message - сообщение
     * @param attachment - вложение
     * @throws MessagingException - ошибка при отправке письма
     * @throws FileNotFoundException - ошибка при отправке письма
     */
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment) throws MessagingException, FileNotFoundException {

        if (toAddress == null || subject == null || message == null || attachment == null) {
            logger.error("{}:: Переменные toAddress, subject, message, attachment - не могут быть NULL!", LG.USBLOGERROR);
            return;
        }

        logger.info("{}: Send email [sendEmailWithAttachment] message, toAddress:{} |subject:{}  |message:{} |attachment:{}", LG.USBLOGINFO, toAddress, subject, message, attachment);
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
        messageHelper.setFrom(config.getMailFrom());
        String[] mailRecepients = toAddress.split(",");
        messageHelper.setTo(mailRecepients);
        messageHelper.setSubject(subject);
        messageHelper.setText(message);
        FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
        messageHelper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
        try {
            emailSender.send(mimeMessage);
        } catch (Exception mailEx) {
            logger.error("{}:[sendEmailWithAttachment]:Возникла ошибка при отправке письма:", LG.USBLOGERROR, mailEx);
            try{
                sendSimpleEmail(config.getMailTo(), "Произошла ошибка отправки файла вложения OVP отчета",
                        "Описание ошибки" + getWrapNull(mailEx.getMessage()));
            } catch (Exception e){
                logger.error("{}:[sendSimpleEmail]:Возникла ошибка при отправке письма:", LG.USBLOGERROR, e);
            }
        }
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }
}
