package ru.usb.signal_ovp_t2.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Класс для подавления множества писем в случае ошибки
 */
@Component
public class MessageError {
    /**
     * Дата отправки сообщения
     */
    private Date date;

    /**
     * Кол-во отправленных
     */
    private int count;

    /**
     * тема сообщения
     */
    private String subject;

    /**
     * Тело сообщения
     */
    private String body;

    @Autowired
    public MessageError() {
        //
    }

    public MessageError(Date date, int count, String subject, String body) {
        this.date = date;
        this.count = count;
        this.subject = subject;
        this.body = body;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "MessageError{" +
                "date=" + date +
                ", count=" + count +
                ", subject='" + subject + '\'' +
                ", body='" + body + '\'' +
                '}';
    }
}
