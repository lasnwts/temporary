package ru.usb.signal_ovp_t2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.usb.signal_ovp_t2.dto.SignalT2;

import java.util.Optional;

@Repository
public interface SignalT2Repo extends JpaRepository<SignalT2, Long> {

    Optional<SignalT2> findById(long id);


}
