package ru.usb.signal_ovp_t2.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.repository.ConversationRepo;
import ru.usb.signal_ovp_t2.service.mail.ServiceMailError;
import ru.usb.signal_ovp_t2.utils.Support;

import java.util.Date;
import java.util.stream.Stream;

@Service
public class FlowCurrentTransaction {

    //Количество строк
    int lineCount;

    Logger logger = LoggerFactory.getLogger(FlowCurrentTransaction.class);

    private final EntityManager entityManager;
    private final Config config;
    private final Support support;
    private final ConversationRepo conversationRepo;
    private final ServiceMailError serviceMailError;
    private final ApiLayer apiLayer;

    @Autowired
    public FlowCurrentTransaction(EntityManager entityManager, Config config, Support support,
                                  ConversationRepo conversationRepo, ServiceMailError serviceMailError, ApiLayer apiLayer) {
        this.entityManager = entityManager;
        this.config = config;
        this.support = support;
        this.conversationRepo = conversationRepo;
        this.serviceMailError = serviceMailError;
        this.apiLayer = apiLayer;
    }

    /**
     * Поток переноса текущих проводок, за вчера и сегодня, которых нет во временной таблице HISTORY_CONVERSATION
     */
    @Transactional
    public void flowOperations() {

        //Получаем список записей из базы
        Stream<Conversation> fTableStream;

        logger.info("{}: Запускаем поток переноса текущих проводок, за вчера и сегодня, которых нет во временной таблице HISTORY_CONVERSATION", LG.USBLOGINFO);

        try {
            logger.info("{}:#SQL# select id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated from CONVERSION_OPERATIONS where operation_date > TO_DATE({}, 'DD.MM.YYYY HH24:MI:SS')",
                    LG.USBLOGINFO, support.getDateOperationNow(config.getQueryDepth(), config.getLocalDate()));
            //Старый вариант
            fTableStream = conversationRepo.getListConversations(support.getDateOperationNow(config.getQueryDepth(), config.getLocalDate()));
            if (fTableStream == null) {
                logger.error("{} fTableStream = factRepo.getStreamConversation() - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return;
        }
        lineCount = 0; //Обнулили счетчик записей, строк

        //id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio
        try {
            fTableStream.forEach(fTable -> {
                logger.debug("{}: Запись CONVERSATION для отчета:{}", LG.USBLOGINFO, fTable.toString());
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                apiLayer.saveHistory(fTable, "Текущие транзакции с датой T:-" + config.getQueryDepth() + ", дата вставки записи:" + support.getStrFromDateTime(new Date())); //Добавляем в таблицу историй проводок
                entityManager.detach(fTable);
            });
            logger.info("{}:Перенесено записей={} из CONVERSATION_OPERATION в HISTORY_CONVERSATION - текущих проводок, за вчера и сегодня, которых нет во временной таблице HISTORY_CONVERSATION", LG.USBLOGINFO, lineCount);
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:!PrintStackTrace:", LG.USBLOGERROR, e);
            serviceMailError.sendMailErrorSubject(support.getWrapNull(config.getMailSubjects()) + " Ошибка формирования отчета по МП ", "Ошибка, произошла при попытке переноса из CONVERSATION_OPERATION в HISTORY_CONVERSATION - текущих проводок, за вчера и сегодня, которых нет во временной таблице HISTORY_CONVERSATION \n\r Описание ошибки: \n\r" + support.getWrapNull(e.getMessage()));
        } finally {
            fTableStream.close();
        }
    }
}
