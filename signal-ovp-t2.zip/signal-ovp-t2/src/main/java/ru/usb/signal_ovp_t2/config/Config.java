package ru.usb.signal_ovp_t2.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;


@Component
@ConfigurationProperties
public class Config {

    //Дата старта запросов
    private LocalDate localDate;

    //Последний запрос, дата и время
    private Date lastDateRequest;

    //Текущее дата и время запроса
    private Date nowDateRequest;

    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;


    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * COMMA DELIMITER
     */
    @Value("${csv.delimiter:;}")
    private String csvDelimiter;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${app.destination.folder}")
    private String netFileShare;

    /**
     * Необходимо отобрать id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio всех записей с portfolio = -2, 2, 7000, 7001,
     * Датой платежного документа (operation_date)  раньше 14:00 позавчерашнего дня,
     * query.depth=2 - глубина
     */
    @Value("${query.depth:2}")
    private int queryDepth;

    /**
     * Заказчиком принято решение мониторить сделки глубиной 91 день.
     * С уважением, Вадим Шайдуллин
     * Аналитик управления технологий инвестиционного бизнеса
     */
    @Value("${max.query.depth:91}")
    private int maxQueryDepth;

    public int getMaxQueryDepth() {
        return maxQueryDepth;
    }

    public void setMaxQueryDepth(int maxQueryDepth) {
        this.maxQueryDepth = maxQueryDepth;
    }

    public int getQueryDepth() {
        return queryDepth;
    }

    public void setQueryDepth(int queryDepth) {
        this.queryDepth = queryDepth;
    }

    public String getNetFileShare() {
        return netFileShare;
    }

    public void setNetFileShare(String netFileShare) {
        this.netFileShare = netFileShare;
    }

    public String getTempDirUploadFile() {
        return tempDirUploadFile;
    }

    public void setTempDirUploadFile(String tempDirUploadFile) {
        this.tempDirUploadFile = tempDirUploadFile;
    }

    public boolean isServiceEnabled() {
        return serviceEnabled;
    }

    public void setServiceEnabled(boolean serviceEnabled) {
        this.serviceEnabled = serviceEnabled;
    }

    public String getServiceUser() {
        return serviceUser;
    }

    public void setServiceUser(String serviceUser) {
        this.serviceUser = serviceUser;
    }

    public String getServicePassword() {
        return servicePassword;
    }

    public void setServicePassword(String servicePassword) {
        this.servicePassword = servicePassword;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    public void setMailDelayMinutes(long mailDelayMinutes) {
        this.mailDelayMinutes = mailDelayMinutes;
    }

    public String getCsvDelimiter() {
        return csvDelimiter;
    }

    public void setCsvDelimiter(String csvDelimiter) {
        this.csvDelimiter = csvDelimiter;
    }

    public String getMailHost() {
        return mailHost;
    }

    public void setMailHost(String mailHost) {
        this.mailHost = mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public void setMailPort(String mailPort) {
        this.mailPort = mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public void setMailUsername(String mailUsername) {
        this.mailUsername = mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public void setMailPassword(String mailPassword) {
        this.mailPassword = mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public void setMailAuth(boolean mailAuth) {
        this.mailAuth = mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public void setMailStarttlsEnable(boolean mailStarttlsEnable) {
        this.mailStarttlsEnable = mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public void setMailSubjects(String mailSubjects) {
        this.mailSubjects = mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public void setMailFrom(String mailFrom) {
        this.mailFrom = mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public void setMailTo(String mailTo) {
        this.mailTo = mailTo;
    }

    public String getMailToBusiness() {
        return mailToBusiness;
    }

    public void setMailToBusiness(String mailToBusiness) {
        this.mailToBusiness = mailToBusiness;
    }

    public Date getLastDateRequest() {
        return lastDateRequest;
    }

    public void setLastDateRequest(Date lastDateRequest) {
        this.lastDateRequest = lastDateRequest;
    }

    public Date getNowDateRequest() {
        return nowDateRequest;
    }

    public void setNowDateRequest(Date nowDateRequest) {
        this.nowDateRequest = nowDateRequest;
    }

    public synchronized LocalDate getLocalDate() {
        return localDate;
    }

    public synchronized void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }
}
