package ru.usb.signal_ovp_t2.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.service.ApiLayer;
import ru.usb.signal_ovp_t2.service.FlowOperations;
import ru.usb.signal_ovp_t2.utils.Support;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@Tag(name = "Контроллер ввода данных", description = "Установка даты, получение отчета")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);
    private final Support support;
    private final ApiLayer apiLayer;
    private final FlowOperations flowOperations;

    public ApiController(Support support, ApiLayer apiLayer, FlowOperations flowOperations) {
        this.support = support;
        this.apiLayer = apiLayer;
        this.flowOperations = flowOperations;
    }

    /**
     * Получаем документ из таблицы истории по id
     *
     * @param id -  id документа
     * @return - возврат записи
     */
    @GetMapping(value = "/get/{id}")
    @Operation(summary = "Получаем документ из таблицы истории по id")
    public ResponseEntity<String> getId(@Parameter(description = "Введите id документа") @PathVariable("id") String id) {
        logger.info("{}: Запрос на получение id документа. id={}", LG.USBLOGINFO, id);
        if (!support.checkIfParsableToLong(id)) {
            logger.warn("{}: Ошибка получения id. id={}", LG.USBLOGWARNING, id);
            return new ResponseEntity<>("Ошибка получения id. id=" + id + " - должен быть цифровым", HttpStatus.BAD_REQUEST);
        }
        try {
            Optional<List<History>> historyList = apiLayer.getId(Long.parseLong(id));
            if (historyList.isPresent() && !historyList.get().isEmpty()) {
                logger.info("{}: document={}", LG.USBLOGINFO, historyList.get().get(0));
                String response = support.getHeader() + support.getWrapNull(support.getRecord(historyList.get().get(0))) + support.getFooter();
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                logger.warn("{}: Ошибка получения id.Не удалось найти и получить документ по id={}", LG.USBLOGWARNING, id);
                return new ResponseEntity<>("Ошибка получения id. Не удалось найти и получить документ по id=" + id, HttpStatus.NOT_FOUND);
            }
        } catch (Exception exception) {
            logger.error("{}: Ошибка получения id. Получить id", LG.USBLOGERROR, exception);
            return new ResponseEntity<>("Ошибка получения id. Получить id \r\r" +
                    support.getWrapNull(exception.getMessage()), HttpStatus.NO_CONTENT);
        }
    }


    /**
     * Получение отчета за период
     *
     * @param begin - начало периода
     * @param end   - конец периода
     * @return - отчет
     */
    @GetMapping(value = "/get/{begin}/{end}")
    @Operation(summary = "Получаем список документов из таблицы истории за период по полю OPERATION_DATE")
    public ResponseEntity<String> getPeriod(@Parameter(description = "Введите начала периода в формате dd.mm.yyyy") @PathVariable("begin") String begin
            , @Parameter(description = "Введите конец периода в формате dd.mm.yyyy") @PathVariable("end") String end) {
        logger.info("{}: Запрос на получение списка документов из таблицы истории за период - c {} по {}", LG.USBLOGINFO, begin, end);
        //Проверка дат
        if (support.isValidDateFormat(begin, "dd.mm.yyyy") && support.isValidDateFormat(end, "dd.mm.yyyy")) {
            final String[] response = {""};
            try {
                Optional<List<History>> historyList = apiLayer.getPeriod(begin, end);
                if (historyList.isPresent() && !historyList.get().isEmpty()) {
                    String headResponse = support.getHeader();
                    // + support.getWrapNull(support.getRecord(historyList.get().get(0))) + support.getFooter()
                    historyList.get().forEach(history -> {
                        logger.debug("{}: Список документов за период document={}", LG.USBLOGINFO, history);
                        response[0] = response[0] + support.getRecord(history);
                    });
                    headResponse = headResponse + response[0] + support.getFooter();
                    return new ResponseEntity<>(support.getWrapNull(headResponse), HttpStatus.OK);
                } else {
                    logger.warn("{}: Ошибка получения списка документов.Не удалось найти и получить документы за период - c {} по {}", LG.USBLOGWARNING, begin, end);
                    return new ResponseEntity<>("Ошибка получения списка документов. Не удалось найти и получить документы за период - c " + begin + " по " + end, HttpStatus.NOT_FOUND);
                }
            } catch (Exception exception) {
                logger.error("{}: Ошибка получения списка документов. Получить документы за период - c {} по {}", LG.USBLOGERROR, begin, end, exception);
                return new ResponseEntity<>("Ошибка получения списка документов. Получить документы за период - c " + begin + " по " + end + "\r\r" +
                        support.getWrapNull(exception.getMessage()), HttpStatus.NO_CONTENT);
            }
        } else {
            logger.warn("{}: Ошибка получения списка документов. Неверный формат дат [DD.MM.YYYY]. Дата начала периода:{}, дата конца периода:{}", LG.USBLOGWARNING, begin, end);
            return new ResponseEntity<>("Ошибка получения списка документов. " +
                    "Неверный формат дат [DD.MM.YYYY]. Дата начала периода:" + support.getWrapNull(begin) + ", дата конца периода:" + support.getWrapNull(end), HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        apiLayer.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (apiLayer.getServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }
}
