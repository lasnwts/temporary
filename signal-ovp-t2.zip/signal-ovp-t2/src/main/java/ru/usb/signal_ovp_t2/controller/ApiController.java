package ru.usb.signal_ovp_t2.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.model.ReportOVP;
import ru.usb.signal_ovp_t2.service.ApiLayer;
import ru.usb.signal_ovp_t2.service.FlowOperations;
import ru.usb.signal_ovp_t2.utils.NewFileInputStream;
import ru.usb.signal_ovp_t2.utils.Support;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@Tag(name = "Контроллер ввода данных", description = "Установка даты, получение отчета")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);
    private final Support support;
    private final ApiLayer apiLayer;
    private final FlowOperations flowOperations;

    public ApiController(Support support, ApiLayer apiLayer, FlowOperations flowOperations) {
        this.support = support;
        this.apiLayer = apiLayer;
        this.flowOperations = flowOperations;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/last/{ldate}")
    @Operation(summary = "Установка даты последнего запроса.[Пример:24.02.2025 00:00:00)]")
    public ResponseEntity<String> setLastDateRequest(@Parameter(description = "Введите дату и время в формате dd.mm.yyyy hh:mm:ss")
                                                     @PathVariable("ldate") String ldate) {
        logger.info("{}: Запрос по Web API. Установка даты последнего запроса:{}", LG.USBLOGINFO, ldate);
        try {
            Date date = support.getDateFromString(ldate);
            if (date == null) {
                logger.warn("{}: Ошибка установки даты последнего запроса. Не верный формат даты:{}", LG.USBLOGWARNING, ldate);
                return new ResponseEntity<>("Ошибка установки даты последнего запроса: \n\r Не верный формат даты:  " + support.getWrapNull(ldate), HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                if (!apiLayer.setLastDateRequest(date)) {
                    logger.warn("{}: Ошибка установки даты последнего запроса. Возникла ошибка при записи значения в базу данных. Дата:{}", LG.USBLOGWARNING, ldate);
                    return new ResponseEntity<>("Ошибка установки даты последнего запроса: \n\r Возникла ошибка при записи значения в базу данных. Дата:" + support.getWrapNull(ldate), HttpStatus.INTERNAL_SERVER_ERROR);
                } else {
                    logger.info("{}: Запрос по Web API. Установлена новая дата, последнего запроса. Таблица:[SIGNALT2], поле:[LAST_REQUEST], [ID=1]. Дата:{}", LG.USBLOGINFO, ldate);
                    return new ResponseEntity<>("Установлена новая дата, последнего запроса. Таблица:[SIGNALT2], поле:[LAST_REQUEST], [ID=1]. Дата:" + date, HttpStatus.OK);
                }
            }
        } catch (Exception exception) {
            logger.error("{}: Ошибка установки даты:{} последнего запроса:", LG.USBLOGERROR, ldate, exception);
            return new ResponseEntity<>("Ошибка установки даты последнего запроса: \n\r " + support.getWrapNull(exception.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/dates")
    @Operation(summary = "Получить дату последнего запроса, получить предполагаемую дату запроса OPERATION_DATE")
    public ResponseEntity<String> getDates() {
        logger.info("{}: Запрос на получение дат. Получить дату последнего запроса, получить предполагаемую дату запроса OPERATION_DATE", LG.USBLOGINFO);
        try {
            Optional<String> lastDateRequest = apiLayer.getLastDateRequest();
            String dateOperationDate = apiLayer.getDateOperationDate();

            if (lastDateRequest.isPresent()) {
                logger.info("{}: Дата последнего запроса={}; OPERATION_DATE:{}", LG.USBLOGINFO, lastDateRequest.get(), dateOperationDate);
                return new ResponseEntity<>(" Дата последнего запроса=" + support.getWrapNull(lastDateRequest.get()) + "; \n\r  "
                        + " OPERATION_DATE=" + support.getWrapNull(dateOperationDate), HttpStatus.OK);
            } else {
                logger.warn("{}: Ошибка получения дат.Не удалось получить дату последнего запроса", LG.USBLOGWARNING);
                return new ResponseEntity<>("Ошибка получения дат. Не удалось получить дату последнего запроса", HttpStatus.NOT_FOUND);
            }
        } catch (Exception exception) {
            logger.error("{}: Ошибка получения дат. Получить дату последнего запроса, получить предполагаемую дату запроса OPERATION_DATE", LG.USBLOGERROR, exception);
            return new ResponseEntity<>("Ошибка получения дат. Получить дату последнего запроса, получить предполагаемую дату запроса OPERATION_DATE \r\r" +
                    support.getWrapNull(exception.getMessage()), HttpStatus.NO_CONTENT);
        }
    }

    @GetMapping("/getfile")

    @Operation(summary = "Запрос на получение файла отчета. Внимание переменная LastUpdate не будет изменена.")
    public ResponseEntity getFiles() {
        logger.info("{}: Поступил Запрос на получение файла отчета", LG.USBLOGINFO);
        try {
            Optional<String> lastDate = apiLayer.getLastDateRequest();
            if (lastDate.isEmpty()) {
                logger.warn("{}: Ошибка получения даты последнего запроса. Не удалось получить дату последнего запроса", LG.USBLOGWARNING);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Ошибка получения даты последнего запроса. Не удалось получить дату последнего запроса");
            }
            ReportOVP reportOVP = flowOperations.flowOperations(apiLayer.getFileName(), apiLayer.getNowDateRequest(), lastDate.get());
            logger.info("{}: Controller:download file:{}", LG.USBLOGINFO, reportOVP.getFile().getAbsolutePath());
            logger.info("{}: Controller:file:{}, size:{}", LG.USBLOGINFO, reportOVP.getFile().getName(), reportOVP.getFile().length());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(reportOVP.getFile()));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + reportOVP.getFile().getName() + "\"")
                    .contentLength(reportOVP.getFile().length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (Exception exception) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!! Request to CB return error! !!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::", exception);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.toString());
        }
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        apiLayer.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (apiLayer.getServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @PutMapping(value = "/set/{ldate}")
    @Operation(summary = "Переместить в историю часть данных, глубиной заданной в переданной дате.")
    public ResponseEntity<String> setHistory(@Parameter(description = "Введите дату и время в формате dd.mm.yyyy hh:mm:ss")
                                             @PathVariable("ldate") String ldate) {
        logger.info("{}: Запрос по Web API. Перенос данных из Conversations в History Conversations. Установка даты глубины получения данных:{}", LG.USBLOGINFO, ldate);
        try {
            Date date = support.getDateFromString(ldate);
            if (date == null) {
                logger.warn("{}: Ошибка установки даты глубины запроса данных, не верный формат даты:{}", LG.USBLOGWARNING, ldate);
                return new ResponseEntity<>("Ошибка установки даты глубины запроса данных: \n\r Не верный формат даты:  " + support.getWrapNull(ldate), HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                apiLayer.deleteAllHistory(); //Удаляем все записи из таблицы
                List<Conversation> conversations = apiLayer.getConversationsDepth(ldate);
                conversations.forEach(apiLayer::saveHistory);
                logger.info("{}: Установлена дата глубины запроса данных:{}, в таблицу HISTORY_CONVERSATIONS перенесено:{} записей", LG.USBLOGINFO, ldate, apiLayer.getHistoryCount());
                return new ResponseEntity<>("Установлена дата глубины запроса данных: \n\r " + support.getWrapNull(ldate) +
                        ",\n\r в таблицу HISTORY_CONVERSATIONS перенесено:" +apiLayer.getHistoryCount() + " записей", HttpStatus.OK);
            }
        } catch (Exception exception) {
            logger.error("{}: Ошибка установки даты глубины запроса данных:{}", LG.USBLOGERROR, ldate, exception);
            return new ResponseEntity<>(" Ошибка установки даты глубины запроса данных: \n\r " + support.getWrapNull(exception.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
