package ru.usb.signal_ovp_t2.model;

/**
 * Объект проверки
 */
public class CompareRecord {

    private boolean changed; //true - документ изменился; false - документ не изменился
    private String reason; //Строковая причина

    public CompareRecord(boolean changed, String reason) {
        this.changed = changed;
        this.reason = reason;
    }

    public CompareRecord() {
        //
    }

    public boolean isChanged() {
        return changed;
    }

    public void setChanged(boolean changed) {
        this.changed = changed;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
