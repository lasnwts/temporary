package ru.usb.signal_ovp_t2.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.repository.ConversationRepo;
import ru.usb.signal_ovp_t2.utils.Support;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Stream;

@Service
public class FlowOperations {

    Logger logger = LoggerFactory.getLogger(FlowOperations.class);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    //Количество строк
    int lineCount;
    String fullFileNameCSV; //Полное имя файла

    private final EntityManager entityManager;
    private final Config config;
    private final Support support;
    private final ConversationRepo conversationRepo;

    @Autowired
    public FlowOperations(EntityManager entityManager, Config config, Support support, ConversationRepo conversationRepo) {
        this.entityManager = entityManager;
        this.config = config;
        this.support = support;
        this.conversationRepo = conversationRepo;
    }

    /**
     * Поток выгрузки  в файл
     *
     * @param fileName       - имя файла выгрузки
     * @param nowDateRequest - дата запроса
     * @param lastDateUpdate - дата последнего обновления
     * @return - файл выгрузки
     */
    @Transactional
    public File flowOperations(String fileName, String nowDateRequest, String lastDateUpdate) {

        //Получаем список записей из базы
        Stream<Conversation> fTableStream;

        logger.info("{}: Подготовленный запрос к базе данных. Дата предыдущего запроса:{}, Дата текущего запроса:{}. Дата операций в запросе:{}", LG.USBLOGINFO, lastDateUpdate, nowDateRequest, support.getDateOperation(config.getQueryDepth()));

        try {
            fTableStream = conversationRepo.getStreamConversation(support.getDateOperation(config.getQueryDepth()), support.getNowDate(), lastDateUpdate);
            if (fTableStream == null) {
                logger.error("{} fTableStream = factRepo.getStreamConversation() - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return null;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = FactRepo(depart)", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return null;
        }
        logger.info("{}:## < Starting the process Flow OVP conversation of unloading data from a table to a file > ##", LG.USBLOGINFO);
        lineCount = 0; //Обнулили счетчик записей, строк
        fullFileNameCSV = config.getTempDirUploadFile() + File.separator + fileName; //Создаем файл во временной директории


        //id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio
        try {
            FileWriter.write(fullFileNameCSV, getHeader()); //Шапка Fact
            fTableStream.forEach(fTable -> {
                logger.debug(fTable.toString());
                try {
                    FileWriter.write(fullFileNameCSV,
                            fTable.getId() + ";" + support.getWrapNull(fTable.getStatus()) + ";" + getDate(fTable.getOperationDate()) + ";" +
                                    support.getWrapNull(fTable.getCurrency1()) + ";" + support.getWrapNull(fTable.getCurrency2()) + ";" +
                                    support.getWrapNull(fTable.getPos1()) + ";" + support.getWrapNull(fTable.getPos2()) + ";" +
                                    support.getWrapNull(fTable.getFilial()) + ";" + support.getWrapNull(fTable.getPortfolio()));
                } catch (IOException e) {
                    logger.error("Возникла ошибка при записи файла:{}, error:{}", fullFileNameCSV, e.getMessage());
                }
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено записей:{}", LG.USBLOGINFO, lineCount);
            logger.info("{}:Output data in File ={}", LG.USBLOGINFO, fullFileNameCSV);
            logger.info("{}:##№ < Stopped the process Flow OVP conversation of unloading data from a table to a file > №##", LG.USBLOGINFO);
            return new File(fullFileNameCSV);
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл", LG.USBLOGERROR);
            logger.error("{}:!PrintStackTrace:", LG.USBLOGERROR, e);
            return null;
        } finally {
            fTableStream.close();
        }
    }

    /**
     * *
     * Получение даты в формате dd/MM/yyyy
     *
     * @param date - дата в формате Date
     * @return - дата в формате dd/MM/yyyy
     */
    private String getDate(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }


    /**
     * Шапка файла
     *
     * @return - строка с шапкой файла
     */
    public String getHeader() {
        return "id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio";
    }


}
