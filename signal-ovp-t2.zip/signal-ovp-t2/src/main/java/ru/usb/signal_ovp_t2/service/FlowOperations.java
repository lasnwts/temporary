package ru.usb.signal_ovp_t2.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.model.ReportOVP;
import ru.usb.signal_ovp_t2.repository.ConversationRepo;
import ru.usb.signal_ovp_t2.service.mail.ServiceMailError;
import ru.usb.signal_ovp_t2.utils.MapConvToHist;
import ru.usb.signal_ovp_t2.utils.Support;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Stream;

@Service
public class FlowOperations {

    Logger logger = LoggerFactory.getLogger(FlowOperations.class);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    //Количество строк
    int lineCount;
    String fullFileNameCSV; //Полное имя файла

    private final EntityManager entityManager;
    private final Config config;
    private final Support support;
    private final ConversationRepo conversationRepo;
    private final ServiceMailError serviceMailError;
    private final ApiLayer apiLayer;
    private final MapConvToHist mapConvToHist;


    @Autowired
    public FlowOperations(EntityManager entityManager, Config config, Support support, ConversationRepo conversationRepo,
                          ServiceMailError serviceMailError, ApiLayer apiLayer, MapConvToHist mapConvToHist) {
        this.entityManager = entityManager;
        this.config = config;
        this.support = support;
        this.conversationRepo = conversationRepo;
        this.serviceMailError = serviceMailError;
        this.apiLayer = apiLayer;
        this.mapConvToHist = mapConvToHist;
    }

    /**
     * Поток выгрузки  в файл
     *
     * @param fileName - имя файла выгрузки
     * @return - файл выгрузки
     */
    @Transactional
    public ReportOVP flowOperations(String fileName) {

        //Получаем список записей из базы
        Stream<Conversation> fTableStream;
        ReportOVP reportOVP = new ReportOVP();
        reportOVP.setLineCount(0);
        reportOVP.setFile(fileName);

        try {
            logger.info("{}:#SQL# operation_date < TO_DATE('{}', 'DD.MM.YYYY HH24:MI:SS') and operation_date > TO_DATE('{}', 'DD.MM.YYYY HH24:MI:SS')",
                    LG.USBLOGINFO, support.getDateOperation(config.getQueryDepth(), config.getLocalDate()), support.getMaxQueryDepthDate(config.getMaxQueryDepth()));
            fTableStream = conversationRepo.getStreamConversation2(support.getDateOperation(config.getQueryDepth(), config.getLocalDate()), support.getMaxQueryDepthDate(config.getMaxQueryDepth()));
            if (fTableStream == null) {
                logger.error("{} fTableStream = factRepo.getStreamConversation2() - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return reportOVP;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return reportOVP;
        }
        logger.info("{}:## < Starting the process Flow OVP conversation of unloading data from a table to a file > ##", LG.USBLOGINFO);
        lineCount = 0; //Обнулили счетчик записей, строк
        //id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio
        try {
            fTableStream.forEach(fTable -> {
                logger.debug("{}: Запись CONVERSATION для отчета:{}", LG.USBLOGINFO, fTable.toString());
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                apiLayer.saveHistory(fTable, "Новые транзакции за прошлые даты. Дата вставки записи:" + support.getStrFromDateTime(new Date())); //Добавляем в таблицу историй проводок
                reportOVP.getHistoryList().add(mapConvToHist.mapNew(fTable, "Новые транзакции за прошлые даты"));
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено новых записей в отчет:{}", LG.USBLOGINFO, lineCount);
            logger.info("{}:##№ < Stopped the process Flow OVP conversation of unloading data from a table to a file > №##", LG.USBLOGINFO);
            reportOVP.setLineCount(lineCount);
            return reportOVP;
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл", LG.USBLOGERROR);
            logger.error("{}:!PrintStackTrace:", LG.USBLOGERROR, e);
            serviceMailError.sendMailErrorSubject(support.getWrapNull(config.getMailSubjects()) + " Ошибка формирования отчета по МП ", "Описание ошибки: \n\r" + support.getWrapNull(e.getMessage()));
            return reportOVP;
        } finally {
            fTableStream.close();
        }
    }

    /**
     * *
     * Получение даты в формате dd/MM/yyyy
     *
     * @param date - дата в формате Date
     * @return - дата в формате dd/MM/yyyy
     */
    private String getDate(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }


    /**
     * Шапка файла
     *
     * @return - строка с шапкой файла
     */
    public String getHeader() {
        return "id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio";
    }


}
