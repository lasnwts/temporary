package ru.usb.signal_ovp_t2.repository;

import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.signal_ovp_t2.dto.Conversation;

import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
@Transactional
public interface ConversationRepo extends JpaRepository<Conversation, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated from CONVERSION_OPERATIONS where operation_date > TO_DATE(:queryDepth, 'DD.MM.YYYY HH24:MI:SS')")
    List<Conversation> getListConversations(@Param("queryDepth") String queryDepth);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated from CONVERSION_OPERATIONS where portfolio in (-2,2,7000,7001) and operation_date < TO_DATE(:queryDepth, 'DD.MM.YYYY HH24:MI:SS') and updated <= TO_DATE(:now, 'DD.MM.YYYY HH24:MI:SS')")
    Stream<Conversation> getStreamConversation2(@Param("queryDepth") String queryDepth, @Param("now") String now);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated from CONVERSION_OPERATIONS where portfolio in (-2,2,7000,7001) and operation_date < TO_DATE(:queryDepth, 'DD.MM.YYYY HH24:MI:SS') and updated <= TO_DATE(:now, 'DD.MM.YYYY HH24:MI:SS') and updated >= TO_DATE(:last, 'DD.MM.YYYY HH24:MI:SS')")
    Stream<Conversation> getStreamConversation(@Param("queryDepth") String queryDepth, @Param("now") String now, @Param("last") String last);
}
