package ru.usb.signal_ovp_t2.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Date;

/**
 * Класс для таблицы SIGNALT2
 * date of last request
 */
@Entity
@Table(name = "SIGNALT2")
public class SignalT2 {

    @Id
    @Column(name = "ID")
    private long id;

    @Column(name = "LAST_REQUEST")
    private Date lastRequest;

    public SignalT2(long id, Date lastRequest) {
        this.id = id;
        this.lastRequest = lastRequest;
    }

    public SignalT2() {
        //
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getLastRequest() {
        return lastRequest;
    }

    public void setLastRequest(Date lastRequest) {
        this.lastRequest = lastRequest;
    }

    @Override
    public String toString() {
        return "SignalT2{" +
                "id=" + id +
                ", lastRequest=" + lastRequest +
                '}';
    }
}
