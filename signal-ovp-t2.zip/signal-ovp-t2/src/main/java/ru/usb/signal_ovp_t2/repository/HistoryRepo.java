package ru.usb.signal_ovp_t2.repository;

import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.usb.signal_ovp_t2.dto.History;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface HistoryRepo extends JpaRepository<History, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from HISTORY_CONVERSATIONS where id = :id and status =:status and currency1 =:currency1 and currency2 =:currency2 and pos1 =:pos1 and pos2 = :pos2 and filial =:filial and portfolio =:portfolio and operation_date = TO_DATE(:operationDate, 'DD.MM.YYYY HH24:MI:SS')")
    int getHistory(@Param("id") Long id,
                   @Param("status") String status,
                   @Param("currency1") String currency1,
                   @Param("currency2") String currency2,
                   @Param("pos1") String pos1,
                   @Param("pos2") String pos2,
                   @Param("filial") String filial,
                   @Param("portfolio") String portfolio,
                   @Param("operationDate") String operationDate);

    @QueryHints(value = {
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from HISTORY_CONVERSATIONS")
    int getCountHistory();
}
