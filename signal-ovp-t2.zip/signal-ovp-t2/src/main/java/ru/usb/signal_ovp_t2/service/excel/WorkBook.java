package ru.usb.signal_ovp_t2.service.excel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.model.ReportOVP;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

@Component
public class WorkBook {

    private final Config config;

    @Autowired
    public WorkBook(Config config) {
        this.config = config;
    }

    public void createWB(ReportOVP reportOVP) throws IOException {
        Workbook workbook = new XSSFWorkbook();

        //id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio;reason
        Sheet sheet = workbook.createSheet("ovp-crotchet");
        sheet.setColumnWidth(0, 6000); //id
        sheet.setColumnWidth(1, 4000); //status
        sheet.setColumnWidth(2, 4000); //operation_date
        sheet.setColumnWidth(3, 4000); //currency1
        sheet.setColumnWidth(4, 4000); //currency2
        sheet.setColumnWidth(5, 4000); //pos1
        sheet.setColumnWidth(6, 4000); //pos2
        sheet.setColumnWidth(7, 4000); //filial
        sheet.setColumnWidth(8, 4000); //portfolio
        sheet.setColumnWidth(9, 10000); //reason

        Row header = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        XSSFFont font = ((XSSFWorkbook) workbook).createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        headerStyle.setFont(font);

        //id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio;reason
        Cell headerCell = header.createCell(0);
        headerCell.setCellValue("id");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(1);
        headerCell.setCellValue("status");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(2);
        headerCell.setCellValue("operation_date");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(3);
        headerCell.setCellValue("currency1");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(4);
        headerCell.setCellValue("currency2");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(5);
        headerCell.setCellValue("pos1");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(6);
        headerCell.setCellValue("pos2");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(7);
        headerCell.setCellValue("filial");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(8);
        headerCell.setCellValue("portfolio");
        headerCell.setCellStyle(headerStyle);

        headerCell = header.createCell(9);
        headerCell.setCellValue("reason");
        headerCell.setCellStyle(headerStyle);
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setWrapText(true);

        //Цикл вставки значений
        //id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio;reason
        AtomicInteger count = new AtomicInteger(0);
        reportOVP.getHistoryList().forEach(new Consumer<History>() {
            @Override
            public void accept(History history) {
                count.incrementAndGet(); // Atomically increments the value and returns the new value
                Row row = sheet.createRow(count.get());
                //id
                Cell cell = row.createCell(0);
                CellStyle textStyle = workbook.createCellStyle();
//                textStyle.setDataFormat(format.getFormat("@")); // "@" is the format code for text
                cell.setCellType(CellType.STRING);
                cell.setCellStyle(style);
//                cell.setCellStyle(textStyle);
                cell.setCellValue(String.valueOf(history.getId()));

                //status
                cell = row.createCell(1);
                cell.setCellValue(history.getStatus());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);

                //operation_date
                cell = row.createCell(2);
                cell.setCellStyle(style);
                // Create a CellStyle
                CellStyle dateCellStyle = workbook.createCellStyle();
                // Get a CreationHelper to create data formats
                CreationHelper createHelper = workbook.getCreationHelper();
                // Set the data format to a desired date format (e.g., "dd-MMM-yy")
                dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));
                // Set the cell's value to a Date object
                cell.setCellValue(history.getOperationDate());
                // Apply the date CellStyle to the cell
                cell.setCellStyle(dateCellStyle);

                //currency1;
                cell = row.createCell(3);
                cell.setCellValue(history.getCurrency1());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //currency2;
                cell = row.createCell(4);
                cell.setCellValue(history.getCurrency2());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //pos1;
                cell = row.createCell(5);
                cell.setCellValue(history.getPos1());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //pos2;
                cell = row.createCell(6);
                cell.setCellValue(history.getPos2());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //filial;
                cell = row.createCell(7);
                cell.setCellValue(history.getFilial());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //portfolio;
                cell = row.createCell(8);
                cell.setCellValue(history.getPortfolio());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
                //reason
                cell = row.createCell(9);
                cell.setCellValue(history.getReason());
                cell.setCellStyle(style);
                cell.setCellStyle(textStyle);
            }
        });
        //Проверка путей
        String fileLocation = reportOVP.getFile();
//        String fileLocation = "C:\\AppServer\\Project\\Banking\\2025\\signal-ovp-t2\\temporary\\test.xlsx";

        FileOutputStream outputStream = new FileOutputStream(fileLocation);
        workbook.write(outputStream);
        outputStream.close();
        workbook.close();
    }

    private void CreateHeader(){

    }

}
