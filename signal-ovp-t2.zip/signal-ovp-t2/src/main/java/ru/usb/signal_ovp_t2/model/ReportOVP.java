package ru.usb.signal_ovp_t2.model;

import ru.usb.signal_ovp_t2.dto.History;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Класс для хранения информации о файле отчета
 */
public class ReportOVP {
    private String file; //Файл отчета
    private int lineCount; //Количество записей в файле
    private List<History> historyList;

    public ReportOVP() {
        this.historyList = new ArrayList<>();
    }

    public ReportOVP(String file, int lineCount) {
        this.file = file;
        this.lineCount = lineCount;
        this.historyList = new ArrayList<>();
    }

    public ReportOVP(String file, int lineCount, List<History> historyList) {
        this.file = file;
        this.lineCount = lineCount;
        this.historyList = historyList;
    }

    public List<History> getHistoryList() {
        return historyList;
    }

    public void setHistoryList(List<History> historyList) {
        this.historyList = historyList;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getLineCount() {
        return lineCount;
    }

    public void setLineCount(int lineCount) {
        this.lineCount = lineCount;
    }
}
