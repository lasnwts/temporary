package ru.usb.signal_ovp_t2.model;

import java.io.File;

/**
 * Класс для хранения информации о файле отчета
 */
public class ReportOVP {
    private File file; //Файл отчета
    private int lineCount; //Количество записей в файле

    public ReportOVP() {
        //
    }

    public ReportOVP(File file, int lineCount) {
        this.file = file;
        this.lineCount = lineCount;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public int getLineCount() {
        return lineCount;
    }

    public void setLineCount(int lineCount) {
        this.lineCount = lineCount;
    }
}
