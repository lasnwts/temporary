package ru.usb.signal_ovp_t2.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.model.CompareRecord;
import ru.usb.signal_ovp_t2.model.ReportOVP;
import ru.usb.signal_ovp_t2.repository.HistoryRepo;
import ru.usb.signal_ovp_t2.service.mail.ServiceMailError;
import ru.usb.signal_ovp_t2.utils.MapConvToHist;
import ru.usb.signal_ovp_t2.utils.Support;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class FlowFromHistory {

    Logger logger = LoggerFactory.getLogger(FlowFromHistory.class);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    //Количество строк
    int lineCount;
    String fullFileNameCSV; //Полное имя файла

    private final EntityManager entityManager;
    private final Config config;
    private final Support support;
    private final HistoryRepo historyRepo;
    private final ServiceMailError serviceMailError;
    private final ApiLayer apiLayer;
    private final MapConvToHist mapConvToHist;

    public FlowFromHistory(EntityManager entityManager, Config config, Support support,
                           HistoryRepo historyRepo,
                           ServiceMailError serviceMailError, ApiLayer apiLayer, MapConvToHist mapConvToHist) {
        this.entityManager = entityManager;
        this.config = config;
        this.support = support;
        this.historyRepo = historyRepo;
        this.serviceMailError = serviceMailError;
        this.apiLayer = apiLayer;
        this.mapConvToHist = mapConvToHist;
    }

    @Transactional
    public ReportOVP flowOperations(ReportOVP reportOVP) {
        //Получаем список записей из базы
        Stream<History> fTableStream;
        try {
            fTableStream = historyRepo.getStreamHistory();
            if (fTableStream == null) {
                logger.error("{} fTableStream = historyRepo.getStreamHistory - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return reportOVP;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = historyRepo.getStreamHistory()", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return reportOVP;
        }
        lineCount = 0; //Начальное значение количества записей
        try {
            fTableStream.forEach(fTable -> {
                logger.debug("{} Запись HISTORY:{}", LG.USBLOGINFO, fTable.toString());
                Optional<Conversation> conversation = apiLayer.getOneConversation(fTable.getId());
                if (conversation.isPresent()) {
                    //Сравниваем записи
                    CompareRecord record = apiLayer.checkRecords(conversation.get(), fTable);
                    if (record.isChanged()) {
                        logger.info("{}:Записи не совпадают, требуется обновление в таблице истории:{}", LG.USBLOGINFO, fTable);
                        reportOVP.getHistoryList().add(mapConvToHist.mapChange(conversation.get(), fTable, new Date(), support.getWrapNull(fTable.getReason()) + " # " + support.getWrapNull(record.getReason())));
                        logger.info("{} Запись CONVERSATION_OPERATIONS в которой есть изменения с соответствующая HISTORY c id={}, conversation:{}. Изменения:{}", LG.USBLOGINFO, fTable.getId(), conversation.get(), record.getReason());
                        lineCount = lineCount + 1; //Подсчитываем число записей в файле
                    }
                } else {
                    logger.info("{}:Запись удалена из таблицы CONVERSATION_OPERATIONS, требуется обновление в таблице истории:{}", LG.USBLOGINFO, fTable);
                    reportOVP.getHistoryList().add(mapConvToHist.mapDelete(fTable, new Date(), "запись удалена"));
                    logger.info("{} Запись CONVERSATION_OPERATIONS которая удалена c id={}, History:{}.", LG.USBLOGINFO, fTable.getId(), fTable);
                    lineCount = lineCount + 1; //Подсчитываем число записей в файле? запись удалена
                }
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено измененных записей:{}", LG.USBLOGINFO, lineCount);
            logger.info("{}:##№ < Stopped the process Flow OVP conversation of unloading data from a table to a file > №##", LG.USBLOGINFO);
            reportOVP.setLineCount(reportOVP.getLineCount() + lineCount);
            return reportOVP;
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл", LG.USBLOGERROR);
            logger.error("{}:!PrintStackTrace:", LG.USBLOGERROR, e);
            serviceMailError.sendMailErrorSubject(support.getWrapNull(config.getMailSubjects()) + " Ошибка формирования отчета по МП ", "Описание ошибки: \n\r" + support.getWrapNull(e.getMessage()));
            return reportOVP;
        } finally {
            fTableStream.close();
        }
    }

    /**
     * *
     * Получение даты в формате dd/MM/yyyy
     *
     * @param date - дата в формате Date
     * @return - дата в формате dd/MM/yyyy
     */
    private String getDate(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }


    /**
     * Шапка файла
     *
     * @return - строка с шапкой файла
     */
    public String getHeader() {
        return "id;status;operation_date;currency1;currency2;pos1;pos2;filial;portfolio";
    }


}
