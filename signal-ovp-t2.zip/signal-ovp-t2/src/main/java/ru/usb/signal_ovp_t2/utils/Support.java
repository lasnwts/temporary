package ru.usb.signal_ovp_t2.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.config.LG;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;


@Component
public class Support {

    private final Logger logger = LoggerFactory.getLogger(Support.class);

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Получение даты в формате dd/MM/yyyy
     *
     * @return - дата в формате dd/MM/yyyy
     */
    public Date getDateNow() {
        return new Date();
    }

    /**
     * Получение даты в формате dd/MM/yyyy  14:00:00
     *
     * @return - дата в формате dd/MM/yyyy  14:00:00
     */
    public String getDateOperation(int days) {
        LocalDate localDate = LocalDate.now();
        localDate = localDate.minusDays(days);
        String formattedString = localDate.format(formatter) + " 14:00:00";
        logger.debug("{}:Дата, для поля operation_date таблицы CONVERSION_OPERATIONS < {}", LG.USBLOGINFO, formattedString);
        return formattedString;
    }


    /**
     * Получение даты в формате dd/MM/yyyy  14:00:00
     *
     * @return - дата в формате dd/MM/yyyy  14:00:00
     */
    public String getNowDate() {
        Date date = new Date();
        String formattedString = sdf.format(date);
        logger.debug("{}:Текущая дата, для поля updated таблицы CONVERSION_OPERATIONS < {}", LG.USBLOGINFO, formattedString);
        return formattedString;
    }


    /**
     * Получение даты в формате dd/MM/yyyy HH:MI:SS
     *
     * @return - дата в формате dd/MM/yyyy HH:MI:SS
     */
    public String getStringFromLastRequest(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }

    /**
     * Преоб�ование строки в дату
     * @param date - строка с датой
     * @return - дата
     */
    public Date getDateFromString(String date) {
        try {
            return sdf.parse(date);
        } catch (Exception e) {
            logger.error("{}:Ошибка при преобразовании строки в дату <{}>", LG.USBLOGERROR, date);
            return null;
        }
    }

    /**
     * Получить имя файла с датой
     * @param fileName - имя файла
     * @return - имя файла с датой
     */
    //get file name include date
    public String getFileName(String fileName) {
        Date date = new Date();
        String formattedString = sdf.format(date);
        formattedString = formattedString.replace(" ", "_");
        formattedString = formattedString.replace(":", "_");
        return fileName + "_" + formattedString + ".csv";
    }

}

