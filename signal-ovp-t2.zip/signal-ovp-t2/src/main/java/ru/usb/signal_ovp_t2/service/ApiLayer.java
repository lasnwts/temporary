package ru.usb.signal_ovp_t2.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.dto.SignalT2;
import ru.usb.signal_ovp_t2.repository.ConversationRepo;
import ru.usb.signal_ovp_t2.repository.HistoryRepo;
import ru.usb.signal_ovp_t2.repository.SignalT2Repo;
import ru.usb.signal_ovp_t2.utils.Support;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ApiLayer {

    private final Config config;
    private final SignalT2Repo signalT2Repo;
    private final Support support;
    private final Logger logger = LoggerFactory.getLogger(ApiLayer.class);
    private final ConversationRepo conversationRepo;
    private final HistoryRepo historyRepo;


    @Autowired
    public ApiLayer(Config config, SignalT2Repo signalT2Repo, Support support,
                    ConversationRepo conversationRepo, HistoryRepo historyRepo) {
        this.config = config;
        this.signalT2Repo = signalT2Repo;
        this.support = support;
        this.conversationRepo = conversationRepo;

        this.historyRepo = historyRepo;
    }

    /**
     * Получить последнюю дату запроса
     *
     * @return - последняя дата запроса
     */
    public Optional<String> getLastDateRequest() {
        try {
            Optional<SignalT2> signalT2 = signalT2Repo.findById(1); //Получаем запись
            if (signalT2.isPresent()) {
                config.setLastDateRequest(signalT2.get().getLastRequest());
            } else {
                config.setLastDateRequest(new Date());
                SignalT2 signalT2New = new SignalT2();
                signalT2New.setId(1);
                signalT2New.setLastRequest(config.getLastDateRequest());
                signalT2Repo.saveAndFlush(signalT2New);
            }
            return support.getStringFromLastRequest(config.getLastDateRequest()).describeConstable();
        } catch (Exception e) {
            logger.error("{}: Возникла ошибка при получении даты последнего запроса к базе данных: {}", LG.USBLOGERROR, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Установить новую дату запроса
     *
     * @param date - дата запроса
     */
    public boolean setLastDateRequest(Date date) {
        config.setLastDateRequest(date);
        try {
            Optional<SignalT2> signalT2 = signalT2Repo.findById(1); //Получаем запись
            if (signalT2.isPresent()) {
                signalT2.get().setLastRequest(date);
                signalT2Repo.saveAndFlush(signalT2.get());
            } else {
                SignalT2 signalT2New = new SignalT2();
                signalT2New.setId(1);
                signalT2New.setLastRequest(date);
                signalT2Repo.saveAndFlush(signalT2New);
            }
            return true;
        } catch (Exception e) {
            logger.error("{}: При попытке установить новую дату:[{}] - возникла ошибка при обновлении записи даты последнего запроса к базе данных: {}", LG.USBLOGERROR, support.getStringFromLastRequest(date), e.getMessage());
            logger.error("{}: : {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
    }

    /**
     * Получить текущую дату запроса
     *
     * @return - текущая дата запроса
     */
    public String getNowDateRequest() {
        return support.getStringFromLastRequest(config.getNowDateRequest());
    }

    //получить имя файла из support
    public String getFileName() {
        return support.getFileName("ovp_conv_");
    }


    /**
     * Получить дату операции
     *
     * @return - дата операции
     */
    public String getDateOperationDate() {
        return support.getDateOperation(config.getQueryDepth());
    }

    /**
     * Получить обертку для NULL
     *
     * @param str - строка
     * @return - обертка для NULL
     */
    public String getWNull(String str) {
        return support.getWrapNull(str);
    }

    /**
     * Установка включения сервиса
     *
     * @param enabled - true - сервис включен, false - сервис выключен
     */
    public void setServiceEnabled(boolean enabled) {
        config.setServiceEnabled(enabled);
    }

    /**
     * Включен или выключен сервис
     *
     * @return -  - true - сервис включен, false - сервис выключен
     */
    public boolean getServiceEnabled() {
        return config.isServiceEnabled();
    }

    /**
     * Удалить все записи из таблицы HistoryConversations
     */
    public void deleteAllHistory() {
        signalT2Repo.deleteAll();
    }


    /**
     * Получить список конверсий до определенной даты
     *
     * @return - список конверсий
     */
    public List<Conversation> getConversationsDepth(String date) {
        return conversationRepo.getListConversations(date);
    }


    /**
     * Получить количество записей в таблице HistoryConversations
     *
     * @return - количество записей
     */
    public int getHistoryCount() {
        return historyRepo.getCountHistory();
    }

    /**
     * Сохранить запись в таблицу HistoryConversations
     *
     * @param conversation - запись
     */
    public void saveHistory(Conversation conversation) {
        History history = new History();
        history.setId(conversation.getId());
        history.setOperationDate(conversation.getOperationDate());
        history.setCurrency1(conversation.getCurrency1());
        history.setCurrency2(conversation.getCurrency2());
        history.setPos1(conversation.getPos1());
        history.setPos2(conversation.getPos2());
        history.setFilial(conversation.getFilial());
        history.setPortfolio(conversation.getPortfolio());
        history.setStatus(conversation.getStatus());
        historyRepo.saveAndFlush(history);
    }


    /**
     * Проверка наличия записи в таблице HistoryConversations
     *
     * @param conversation - запись
     * @return - true - запись есть, false - записи нет
     */
    public boolean checkConversations(Conversation conversation) {
        return historyRepo.getHistory(conversation.getId(), conversation.getStatus(), conversation.getCurrency1(), conversation.getCurrency2(), conversation.getPos1(), conversation.getPos2(), conversation.getFilial(), conversation.getPortfolio(), support.getStrFromDateTime(conversation.getOperationDate())) > 0;
    }

}
