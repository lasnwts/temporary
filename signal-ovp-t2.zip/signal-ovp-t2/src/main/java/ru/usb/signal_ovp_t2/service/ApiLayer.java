package ru.usb.signal_ovp_t2.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.SignalT2;
import ru.usb.signal_ovp_t2.repository.SignalT2Repo;
import ru.usb.signal_ovp_t2.utils.Support;

import java.util.Date;
import java.util.Optional;

@Service
public class ApiLayer {

    private final Config config;
    private final SignalT2Repo signalT2Repo;
    private final Support support;
    private final Logger logger = LoggerFactory.getLogger(ApiLayer.class);

    @Autowired
    public ApiLayer(Config config, SignalT2Repo signalT2Repo, Support support) {
        this.config = config;
        this.signalT2Repo = signalT2Repo;
        this.support = support;
    }

    /**
     * Получить последнюю дату запроса
     *
     * @return - последняя дата запроса
     */
    public Optional<String> getLastDateRequest() {
        try {
            Optional<SignalT2> signalT2 = signalT2Repo.findById(1); //Получаем запись
            if (signalT2.isPresent()) {
                config.setLastDateRequest(signalT2.get().getLastRequest());
            } else {
                config.setLastDateRequest(new Date());
                SignalT2 signalT2New = new SignalT2();
                signalT2New.setId(1);
                signalT2New.setLastRequest(config.getLastDateRequest());
                signalT2Repo.saveAndFlush(signalT2New);
            }
            return support.getStringFromLastRequest(config.getLastDateRequest()).describeConstable();
        } catch (Exception e) {
            logger.error("{}: Возникла ошибка при получении даты последнего запроса к базе данных: {}", LG.USBLOGERROR, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Установить новую дату запроса
     * @param date - дата запроса
     */
    public boolean setLastDateRequest(Date date) {
        config.setLastDateRequest(date);
        try {
            Optional<SignalT2> signalT2 = signalT2Repo.findById(1); //Получаем запись
            if (signalT2.isPresent()) {
                signalT2.get().setLastRequest(date);
                signalT2Repo.saveAndFlush(signalT2.get());
            } else {
                SignalT2 signalT2New = new SignalT2();
                signalT2New.setId(1);
                signalT2New.setLastRequest(date);
                signalT2Repo.saveAndFlush(signalT2New);
            }
            return true;
        } catch (Exception e) {
            logger.error("{}: При попытке установить новую дату:[{}] - возникла ошибка при обновлении записи даты последнего запроса к базе данных: {}", LG.USBLOGERROR, support.getStringFromLastRequest(date), e.getMessage());
            logger.error("{}: : {}", LG.USBLOGERROR, e.getMessage());
            return false;
        }
    }

    /**
     * Получить текущую дату запроса
      * @return - текущая дата запроса
     */
    public String getNowDateRequest() {
        return support.getStringFromLastRequest(config.getNowDateRequest());
    }

    //получить имя файла из support
    public String getFileName() {
        return support.getFileName("ovp_conv_");
    }


    /**
     * Получить дату операции
     * @return - дата операции
     */
    public String getDateOperationDate() {
        return support.getDateOperation(config.getQueryDepth());
    }


}
