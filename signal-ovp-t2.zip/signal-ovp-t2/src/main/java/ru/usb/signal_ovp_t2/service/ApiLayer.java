package ru.usb.signal_ovp_t2.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.model.CompareRecord;
import ru.usb.signal_ovp_t2.repository.ConversationRepo;
import ru.usb.signal_ovp_t2.repository.HistoryRepo;
import ru.usb.signal_ovp_t2.utils.Support;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ApiLayer {

    private final Config config;
    private final Support support;
    private final Logger logger = LoggerFactory.getLogger(ApiLayer.class);
    private final ConversationRepo conversationRepo;
    private final HistoryRepo historyRepo;

    @Autowired
    public ApiLayer(Config config, Support support, ConversationRepo conversationRepo, HistoryRepo historyRepo) {
        this.config = config;
        this.support = support;
        this.conversationRepo = conversationRepo;
        this.historyRepo = historyRepo;
    }

    /**
     * Получить текущую дату запроса
     *
     * @return - текущая дата запроса
     */
    public String getNowDateRequest() {
        return support.getStringFromLastRequest(config.getNowDateRequest());
    }

    //получить имя файла из support
    public String getFileName() {
        //Проверка путей
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + config.getNetFileShare());
        return path.toString() +  FileSystems.getDefault().getSeparator() + support.getFileName("ovp_conv");
    }


    /**
     * Получить дату операции
     *
     * @return - дата операции
     */
    public String getDateOperationDate() {
        return support.getDateOperation(config.getQueryDepth(), config.getLocalDate());
    }

    /**
     * Получить обертку для NULL
     *
     * @param str - строка
     * @return - обертка для NULL
     */
    public String getWNull(String str) {
        return support.getWrapNull(str);
    }

    /**
     * Получаем дату для сравнения
     * @param date - дата
     * @return строка в формате dd.mm.yyyy
     */
    private String getWDate(Date date){
        return support.getShortDate(date);
    }

    /**
     * Установка включения сервиса
     *
     * @param enabled - true - сервис включен, false - сервис выключен
     */
    public void setServiceEnabled(boolean enabled) {
        config.setServiceEnabled(enabled);
    }

    /**
     * Включен или выключен сервис
     *
     * @return -  - true - сервис включен, false - сервис выключен
     */
    public boolean getServiceEnabled() {
        return config.isServiceEnabled();
    }

    /**
     * Получить количество записей в таблице HistoryConversations
     *
     * @return - количество записей
     */
    public int getHistoryCount() {
        return historyRepo.getCountHistory();
    }

    /**
     * Сохранить запись в таблицу HistoryConversations
     *
     * @param conversation - запись
     * @param reason       - причина поступления
     */
    public void saveHistory(Conversation conversation, String reason) {
        History history = new History();
        history.setId(conversation.getId());
        history.setOperationDate(conversation.getOperationDate());
        history.setCurrency1(conversation.getCurrency1());
        history.setCurrency2(conversation.getCurrency2());
        history.setPos1(conversation.getPos1());
        history.setPos2(conversation.getPos2());
        history.setFilial(conversation.getFilial());
        history.setPortfolio(conversation.getPortfolio());
        history.setStatus(conversation.getStatus());
        history.setCreateDate(new Date());
        history.setReason(getWNull(reason));
        historyRepo.saveAndFlush(history);
    }


    /**
     * Сравнение объектов
     * @param conversation - исходная запись
     * @param history - запись в таблице истории
     * @return - объект после сравнения
     */
    public CompareRecord checkRecords(Conversation conversation, History history) {
        CompareRecord record = new CompareRecord(false, support.getStrFromDateTime(new Date()));//Пока неизменен

        if (!getWDate(conversation.getOperationDate()).equals(getWDate(history.getOperationDate()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась дата операции. Была: "
                    + support.getStrFromDateTime(history.getOperationDate())
                    + " Стала: " + support.getStrFromDateTime(conversation.getOperationDate()) + ".");
        }

        if (!getWNull(conversation.getCurrency1()).equals(getWNull(history.getCurrency1()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась валюта CURRENCY1. Была: "
                    + support.getWrapNull(history.getCurrency1())
                    + " Стала: " + support.getWrapNull(conversation.getCurrency1()) + ".");
        }

        if (!getWNull(conversation.getCurrency2()).equals(getWNull(history.getCurrency2()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась валюта CURRENCY2. Была: "
                    + support.getWrapNull(history.getCurrency2())
                    + " Стала: " + support.getWrapNull(conversation.getCurrency2()) + ".");
        }

        if (!getWNull(conversation.getPos1()).equals(getWNull(history.getPos1()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась позиция POS1. Была: "
                    + support.getWrapNull(history.getPos1())
                    + " Стала: " + support.getWrapNull(conversation.getPos1()) + ".");
        }

        if (!getWNull(conversation.getPos2()).equals(getWNull(history.getPos2()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась позиция POS2. Была: "
                    + support.getWrapNull(history.getPos2())
                    + " Стала: " + support.getWrapNull(conversation.getPos2()) + ".");
        }


        if (!getWNull(conversation.getFilial()).equals(getWNull(history.getFilial()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась филиал. Был: "
                    + support.getWrapNull(history.getFilial())
                    + " Стал: " + support.getWrapNull(conversation.getFilial()) + ".");
        }

        if (!getWNull(conversation.getPortfolio()).equals(getWNull(history.getPortfolio()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась портфель. Был: "
                    + support.getWrapNull(history.getPortfolio())
                    + " Стал: " + support.getWrapNull(conversation.getPortfolio()) + ".");
        }

        if (!getWNull(conversation.getStatus()).equals(getWNull(history.getStatus()))) {
            record.setChanged(true);
            record.setReason(record.getReason() + "В документе изменилась статус. Был: "
                    + support.getWrapNull(history.getStatus())
                    + " Стал: " + support.getWrapNull(conversation.getStatus()) + ".");
        }

        return record;
    }

    /**
     * Сохранение изменений во временную таблицу
     *
     * @param history - запись в таблице
     */
    public void saveUpdateHistory(History history) {
        historyRepo.saveAndFlush(history);
    }

    /**
     * Удаление записей по id
     * @param id - id записи
     */
    public void deleteHistory(long id) {
        historyRepo.deleteById(id);
    }

    /**
     * Мапирование Conversation в istory
     *
     * @param conversation - проводки из ОВП
     * @param history      - временная таблица, запись
     * @return - объект для записи
     */
    public History mapUpdateHistory(Conversation conversation, History history, String reason) {
        history.setOperationDate(conversation.getOperationDate());
        history.setCurrency1(conversation.getCurrency1());
        history.setCurrency2(conversation.getCurrency2());
        history.setPos1(conversation.getPos1());
        history.setPos2(conversation.getPos2());
        history.setFilial(conversation.getFilial());
        history.setPortfolio(conversation.getPortfolio());
        history.setStatus(conversation.getStatus());
        history.setReason(history.getReason() + " # " + reason); //Причина
        history.setChangeDate(new Date()); //Дата обновления
        return history;
    }


    /**
     * Проверка наличия записи в таблице HistoryConversations
     *
     * @param conversation - запись
     * @return - true - запись есть, false - записи нет
     */
    public boolean checkConversations(Conversation conversation) {
        return historyRepo.getHistory(conversation.getId(), conversation.getStatus(), conversation.getCurrency1(), conversation.getCurrency2(), conversation.getPos1(), conversation.getPos2(), conversation.getFilial(), conversation.getPortfolio(), support.getStrFromDateTime(conversation.getOperationDate())) > 0;
    }

    /**
     * Удаление старых записей из временной таблицы
     *
     * @param days - число дней
     */
    public void deleteHistoryAfterMaxDepth(int days) {
        historyRepo.deleteMaxDepthHistory(support.getMaxQueryDepthDate(days + 1));
    }

    /**
     * Получаем Conversation
     *
     * @param id - id записи
     * @return - Conversation
     */
    public Optional<Conversation> getOneConversation(long id) {
        List<Conversation> conversations = conversationRepo.getConversationFromId(id);
        if (conversations == null || conversations.isEmpty()) {
            return Optional.empty();
        }
        return Optional.ofNullable(conversations.get(0));
    }


    /**
     * Получаем документ по id
     * @param id - id документа
     * @return - документ
     */
    public Optional<List<History>> getId(long id) {
        try {
            return Optional.ofNullable(historyRepo.getId(id));
        } catch (Exception e) {
            logger.error("{}: Ошибка получения документа по id={}", LG.USBLOGWARNING, id, e);
            return Optional.empty();
        }
    }

    /**
     * Получаем список документов за период
     * @param beginPeriod - начало периода
     * @param endPeriod - конец периода
     * @return - список документов
     */
    public Optional<List<History>> getPeriod(String beginPeriod, String endPeriod){
        try {
            return Optional.ofNullable(historyRepo.getPeriod(beginPeriod, endPeriod));
        } catch (Exception e) {
            logger.error("{}: Ошибка получения периода. Получить период с {} по {}", LG.USBLOGWARNING, beginPeriod, endPeriod, e);
            return Optional.empty();
        }
    }
}
