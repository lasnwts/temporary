package ru.usb.signal_ovp_t2.utils;

import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.dto.Conversation;
import ru.usb.signal_ovp_t2.dto.History;

import java.util.Date;

@Component
public class MapConvToHist {
    /**
     * Мапирование Conversation -> history
     *
     * @param conversation - таблица conversation
     * @param reason       - причина
     * @return - history
     */
    public History mapNew(Conversation conversation, String reason) {
        return new History(
                conversation.getId(), conversation.getStatus(), conversation.getOperationDate(),
                conversation.getCurrency1(), conversation.getCurrency2(), conversation.getPos1(), conversation.getPos2(),
                conversation.getFilial(), conversation.getPortfolio(), new Date(), null, reason);
    }

    /**
     * Мапирование Conversation -> history
     *
     * @param conversation - таблица conversation
     * @param changeDate   - дата изменения
     * @param reason       - причина
     * @return - history
     */
    public History mapChange(Conversation conversation, History history, Date changeDate, String reason) {
        return new History(
                conversation.getId(), conversation.getStatus(), conversation.getOperationDate(),
                conversation.getCurrency1(), conversation.getCurrency2(), conversation.getPos1(), conversation.getPos2(),
                conversation.getFilial(), conversation.getPortfolio(), history.getCreateDate(), changeDate, reason);
    }

    /**
     * Мапирование удаленных -> history
     *
     * @param changeDate   - дата изменения
     * @param reason       - причина
     * @return - history
     */
    public History mapDelete(History history, Date changeDate, String reason) {
        return new History(
                history.getId(), history.getStatus(), history.getOperationDate(),
                history.getCurrency1(), history.getCurrency2(), history.getPos1(), history.getPos2(),
                history.getFilial(), history.getPortfolio(), history.getCreateDate(), changeDate, reason);
    }

}
