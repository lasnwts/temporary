package ru.usb.signal_ovp_t2.service;

import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.service.mail.EmailService;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.Optional;

@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final FlowOperations flowOperations;
    private final ApiLayer apiLayer;
    private final EmailService emailService;

    public FlowScheduler(Config config, FlowOperations flowOperations, ApiLayer apiLayer, EmailService emailService) {
        this.config = config;
        this.flowOperations = flowOperations;
        this.apiLayer = apiLayer;
        this.emailService = emailService;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    @Scheduled(cron = "${cron-scheduler}")
    public void startScheduler() {
        logger.info("{} cron-start. Время работы наступило.", LG.USBLOGINFO);
        File file = null;
        config.setNowDateRequest(new Date());
        Optional<String> lastDate = apiLayer.getLastDateRequest();
        if (lastDate.isPresent()) {
            file = flowOperations.flowOperations(apiLayer.getFileName(), apiLayer.getNowDateRequest(), lastDate.get());
            if (file != null) {
                logger.info("{}: Файл выгружен в директорию: {}", LG.USBLOGINFO, file.getAbsolutePath());
                try {
                    emailService.sendEmailWithAttachment("las@mail.ru", "Тема письма", "Текст сообщения", file.getAbsolutePath());
                    if (apiLayer.setLastDateRequest(config.getNowDateRequest())) {
                        logger.info("{}: Дата последнего запроса обновлена в базе данных. Дата запроса:{}", LG.USBLOGINFO, apiLayer.getNowDateRequest());
                    }
                    //Чистим файл
                    Files.deleteIfExists(file.toPath());
                } catch (MessagingException e) {
                    logger.error("{}: Ошибка при попытке отправки файла вложений:{} и сообщений. Ошибка: MessagingException={}", LG.USBLOGERROR, file.getAbsolutePath(), e.getMessage());
                } catch (FileNotFoundException e) {
                    logger.error("{}: Ошибка, не удалось прочитать файла вложений:{}. Ошибка: FileNotFoundException={}", LG.USBLOGERROR, file.getAbsolutePath(), e.getMessage());
                } catch (IOException e) {
                    logger.error("{}: Ошибка при попытке удалить файл вложений:{}. Ошибка: IOException={}", LG.USBLOGERROR, file.getAbsolutePath(), e.getMessage());logger.error("{}: Ошибка при попытке прочитать файла вложений:{}. Ошибка: FileNotFoundException={}", LG.USBLOGERROR, file.getAbsolutePath(), e.getMessage());
                }
            } else {
                logger.error("{}: Ошибка при попытке создания файла, при выполнении операции=[file = flowOperations.flowOperations(apiLayer.getFileName(), apiLayer.getNowDateRequest(), lastDate.get())]", LG.USBLOGERROR);
            }
        }
    }
}



