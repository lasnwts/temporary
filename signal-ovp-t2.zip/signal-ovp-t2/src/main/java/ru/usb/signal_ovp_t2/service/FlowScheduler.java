package ru.usb.signal_ovp_t2.service;

import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.dto.History;
import ru.usb.signal_ovp_t2.model.ReportOVP;
import ru.usb.signal_ovp_t2.service.excel.WorkBook;
import ru.usb.signal_ovp_t2.service.mail.EmailService;
import ru.usb.signal_ovp_t2.utils.Support;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Date;
import java.util.function.Consumer;

@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final Support support;
    private final FlowOperations flowOperations;
    private final FlowFromHistory flowFromHistory;
    private final FlowCurrentTransaction flowCurrentTransaction;
    private final ApiLayer apiLayer;
    private final EmailService emailService;
    private final WorkBook workBook;

    public FlowScheduler(Config config, Support support, FlowOperations flowOperations, FlowFromHistory flowFromHistory,
                         FlowCurrentTransaction flowCurrentTransaction, ApiLayer apiLayer, EmailService emailService, WorkBook workBook) {
        this.config = config;
        this.support = support;
        this.flowOperations = flowOperations;
        this.flowFromHistory = flowFromHistory;
        this.flowCurrentTransaction = flowCurrentTransaction;
        this.apiLayer = apiLayer;
        this.emailService = emailService;
        this.workBook = workBook;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    @Scheduled(cron = "${cron-scheduler}")
    public void startScheduler() {
        boolean workBookExist = true; //Файл WorkBook создан = true
        config.setLocalDate(LocalDate.now()); //Установка даты для запросов в отчете
        logger.info("{} ######################################", LG.USBLOGINFO);
        logger.info("{} cron-start. Время работы наступило.", LG.USBLOGINFO);
        logger.info("{} ###################################### ", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            config.setNowDateRequest(new Date());
            ReportOVP reportOVP = flowOperations.flowOperations(apiLayer.getFileName()); //Получаем список новых записей
            reportOVP = flowFromHistory.flowOperations(reportOVP); //Получаем список измененных записей
            //Блок добавления записей, если список не пустой!
            if (reportOVP.getHistoryList() != null || !reportOVP.getHistoryList().isEmpty()) {
                reportOVP.getHistoryList().forEach(new Consumer<History>() {
                    @Override
                    public void accept(History history) {
                        if (history.getReason().equalsIgnoreCase("запись удалена")) {
                            apiLayer.deleteHistory(history.getId()); //Удаляем запись
                        } else {
                            apiLayer.saveUpdateHistory(history); //Сохраняем изменения
                        }
                    }
                });
            }
            //Формируем файл и отправляем его в Email
            try {
                workBook.createWB(reportOVP);
            } catch (IOException e) {
                logger.error("{}:[workBook.createWB(reportOVP)] Возникла ошибка при попытке создать файл отчета:{}. Описание ошибки:{}", LG.USBLOGERROR, reportOVP.getFile(), e.getMessage());
                logger.debug("{}:[workBook.createWB(reportOVP);] Stack trace:", LG.USBLOGERROR, e);
                workBookExist = false; //Ошибка возникла, отправлять сообщение не будем
            }

            //Переносим в HISTORY_CONVERSATION проводки за вчера и сегодня
            flowCurrentTransaction.flowOperations();
            //Удаление старых проводок, с датой operation_date старше 91 день
            apiLayer.deleteHistoryAfterMaxDepth(config.getMaxQueryDepth()); // Удаляем старые записи из HISTORY_CONVERSATIONS
            logger.info("{}: Файл выгружен в директорию: {}", LG.USBLOGINFO, reportOVP.getFile());

            //Файл WB создан=true, если нет=false
            if (workBookExist) {
                String[] mailRecepients = config.getMailToBusiness().split(",");
                if (mailRecepients.length > 0) {
                    for (String mailRecepient : mailRecepients) {
                        try {
                            emailService.sendEmailWithAttachment(mailRecepient, "МП 982624 Установка сигнала в ОВП он-лайн по подгруженным сделкам/ проводкам до Т-2 включительно. Сервис:" + apiLayer.getWNull(config.getMailSubjects()),
                                    "Отчет по МП 982624.\n\r" + "Дата запроса: " + support.getDateOperation(config.getQueryDepth(), config.getLocalDate()), reportOVP.getFile());
                        } catch (MessagingException e) {
                            logger.error("{}: Ошибка при попытке отправки файла вложений:{} и сообщений. Ошибка: MessagingException={}", LG.USBLOGERROR, reportOVP.getFile(), e.getMessage());
                        } catch (FileNotFoundException e) {
                            logger.error("{}: Ошибка, не удалось прочитать файла вложений:{}. Ошибка: FileNotFoundException={}", LG.USBLOGERROR, reportOVP.getFile(), e.getMessage());
                        }
                    }
                    //Чистим файл
                    try {
                        Files.deleteIfExists(Paths.get(reportOVP.getFile()));
                    } catch (IOException e) {
                        logger.error("{}: Ошибка при попытке удалить файл вложений:{}. Ошибка: IOException={}", LG.USBLOGERROR, reportOVP.getFile(), e.getMessage());
                    }
                } else {
                    logger.error("{}: Не заданы адресаты для отправки отчета по МП", LG.USBLOGERROR);
                }
            }
        }
        logger.info("{}####################################", LG.USBLOGINFO);
        logger.info("{}# Конец отработки/Stop Scheduler   #", LG.USBLOGINFO);
        logger.info("{}####################################", LG.USBLOGINFO);

    }
}



