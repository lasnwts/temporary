package ru.usb.signal_ovp_t2.service;

import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.signal_ovp_t2.config.Config;
import ru.usb.signal_ovp_t2.config.LG;
import ru.usb.signal_ovp_t2.model.ReportOVP;
import ru.usb.signal_ovp_t2.service.mail.EmailService;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.Optional;

@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final FlowOperations flowOperations;
    private final ApiLayer apiLayer;
    private final EmailService emailService;

    public FlowScheduler(Config config, FlowOperations flowOperations, ApiLayer apiLayer, EmailService emailService) {
        this.config = config;
        this.flowOperations = flowOperations;
        this.apiLayer = apiLayer;
        this.emailService = emailService;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    @Scheduled(cron = "${cron-scheduler}")
    public void startScheduler() {
        logger.info("{} cron-start. Время работы наступило.", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            config.setNowDateRequest(new Date());
            Optional<String> lastDate = apiLayer.getLastDateRequest();
            if (lastDate.isPresent()) {
                ReportOVP reportOVP = flowOperations.flowOperations(apiLayer.getFileName(), apiLayer.getNowDateRequest(), lastDate.get());
                if (reportOVP.getLineCount() > 0 && reportOVP.getFile() != null) {
                    logger.info("{}: Файл выгружен в директорию: {}", LG.USBLOGINFO, reportOVP.getFile().getAbsolutePath());

                    String[] mailRecepients = config.getMailToBusiness().split(",");
                    if (mailRecepients.length > 0) {
                        for (String mailRecepient : mailRecepients) {
                            try {
                                emailService.sendEmailWithAttachment(mailRecepient, "МП 982624 Установка сигнала в ОВП он-лайн по подгруженным сделкам/ проводкам до Т-2 включительно. Сервис:" + apiLayer.getWNull(config.getMailSubjects()),
                                        "Отчет по МП 982624.\n\r" + "Дата предыдущего запроса: " + lastDate.get(), reportOVP.getFile().getAbsolutePath());
                            } catch (MessagingException e) {
                                logger.error("{}: Ошибка при попытке отправки файла вложений:{} и сообщений. Ошибка: MessagingException={}", LG.USBLOGERROR, reportOVP.getFile().getAbsolutePath(), e.getMessage());
                            } catch (FileNotFoundException e) {
                                logger.error("{}: Ошибка, не удалось прочитать файла вложений:{}. Ошибка: FileNotFoundException={}", LG.USBLOGERROR, reportOVP.getFile().getAbsolutePath(), e.getMessage());
                            }
                        }
                        if (apiLayer.setLastDateRequest(config.getNowDateRequest())) {
                            logger.info("{}: Дата последнего запроса обновлена в базе данных. Дата запроса:{}", LG.USBLOGINFO, apiLayer.getNowDateRequest());
                        }
                        //Чистим файл
                        try {
                            Files.deleteIfExists(reportOVP.getFile().toPath());
                        } catch (IOException e) {
                            logger.error("{}: Ошибка при попытке удалить файл вложений:{}. Ошибка: IOException={}", LG.USBLOGERROR, reportOVP.getFile().getAbsolutePath(), e.getMessage());
                            logger.error("{}: Ошибка при попытке прочитать файла вложений:{}. Ошибка: FileNotFoundException={}", LG.USBLOGERROR, reportOVP.getFile().getAbsolutePath(), e.getMessage());
                        }
                    } else {
                        logger.error("{}: Не заданы адресаты для отправки отчета по МП", LG.USBLOGERROR);
                    }
                } else {
                    logger.error("{}: Файл отчета сформировался пустой, отправлять нечего.", LG.USBLOGERROR);
                }
            }
        }
    }

}



