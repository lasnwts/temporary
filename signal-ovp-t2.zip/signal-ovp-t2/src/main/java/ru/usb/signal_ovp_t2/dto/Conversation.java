package ru.usb.signal_ovp_t2.dto;

import jakarta.persistence.*;


import java.util.Date;


//id, status, operation_date, currency1, currency2, pos1, pos2, filial, portfolio, updated
@Entity
@Table(name = "CONVERSION_OPERATIONS")
public class Conversation {

    @Id
    @Column(name = "id")
    private Long id;
    @Column(name = "status")
    private String status;

    @Column(name = "operation_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date operationDate;

    @Column(name = "currency1")
    private String currency1;
    @Column(name = "currency2")
    private String currency2;
    @Column(name = "pos1")
    private String pos1;
    @Column(name = "pos2")
    private String pos2;
    @Column(name = "filial")
    private String filial;
    @Column(name = "portfolio")
    private String portfolio;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated")
    private Date updated;

    public Conversation() {
        //
    }

    public Conversation(Long id, String status, Date operationDate, String currency1, String currency2, String pos1, String pos2, String filial, String portfolio, Date updated) {
        this.id = id;
        this.status = status;
        this.operationDate = operationDate;
        this.currency1 = currency1;
        this.currency2 = currency2;
        this.pos1 = pos1;
        this.pos2 = pos2;
        this.filial = filial;
        this.portfolio = portfolio;
        this.updated = updated;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getCurrency1() {
        return currency1;
    }

    public void setCurrency1(String currency1) {
        this.currency1 = currency1;
    }

    public String getCurrency2() {
        return currency2;
    }

    public void setCurrency2(String currency2) {
        this.currency2 = currency2;
    }

    public String getPos1() {
        return pos1;
    }

    public void setPos1(String pos1) {
        this.pos1 = pos1;
    }

    public String getPos2() {
        return pos2;
    }

    public void setPos2(String pos2) {
        this.pos2 = pos2;
    }

    public String getFilial() {
        return filial;
    }

    public void setFilial(String filial) {
        this.filial = filial;
    }

    public String getPortfolio() {
        return portfolio;
    }

    public void setPortfolio(String portfolio) {
        this.portfolio = portfolio;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return "Conversation{" +
                "id=" + id +
                ", status='" + status + '\'' +
                ", operationDate=" + operationDate +
                ", currency1='" + currency1 + '\'' +
                ", currency2='" + currency2 + '\'' +
                ", pos1='" + pos1 + '\'' +
                ", pos2='" + pos2 + '\'' +
                ", filial='" + filial + '\'' +
                ", portfolio='" + portfolio + '\'' +
                ", updated=" + updated +
                '}';
    }
}
