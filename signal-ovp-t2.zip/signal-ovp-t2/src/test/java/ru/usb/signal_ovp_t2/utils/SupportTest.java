package ru.usb.signal_ovp_t2.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.signal_ovp_t2.config.Config;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class SupportTest {

    private Support support;

    @BeforeEach
    void setUp() {

        support = new Support();
    }


    @Test
    void getWrapNull() {
        String result = support.getWrapNull(null);
        assertEquals("", result);
    }

    @Test
    void getDateNow() {
        assertNotNull(support.getDateNow());
    }

    @Test
    void getDateOperation() {
        String result = support.getDateOperation(1, LocalDate.now());
        assertNotNull(result);
    }

    @Test
    void getMaxQueryDate(){
        int maxDay = 91;
        String result = support.getMaxQueryDepthDate(maxDay);
        System.out.print("Max day=");
        System.out.println(result);
        assertEquals(19, result.length());
    }
}