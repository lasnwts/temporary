package ru.usb.signal_ovp_t2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignalOvpT2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
