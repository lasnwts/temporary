package ru.usb.tbank_csv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TbankCsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
