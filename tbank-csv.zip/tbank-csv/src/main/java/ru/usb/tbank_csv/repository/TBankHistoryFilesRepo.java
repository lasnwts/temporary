package ru.usb.tbank_csv.repository;

import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.tbank_csv.model.TBankHistoryFiles;

import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;


public interface TBankHistoryFilesRepo extends JpaRepository<TBankHistoryFiles, Long>{

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select ID,ARCHIVE_NAME,FOLDER_NAME,FILE_NAME,FILE_NAME_GUID,FILE_GUID,FILE_EXT,FILE_SIZE,FILE_LINK,PACKID,KAFKA_IN,ERROR,DATE_START,DATE_END from tbank_history_files order by folder_name, file_name")
    Stream<TBankHistoryFiles> getStreamAll();

}
