package ru.usb.tbank_csv.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.util.Date;

/**
 * TBANK_HISTORY_FILES
 * ----------------
 * Струткура таблицы TBANK_HISTORY_FILES
 * Поле	Название поля	Описание	Тип данных
 * id	id записи		NUMBER
 * archive_name	Название файла - архива от Тбанка		VARCHAR2(255)
 * folder_name	Название каталога, извлеченного из архива.	Соответствует номеру кредитного договора	VARCHAR2(255)
 * file_name	Название файла		VARCHAR2(255)
 * file_name_guid	Название файла, загружаемого в Siebel CRM c добавленным GUID		VARCHAR2(1000)
 * file_guid	GUID файла		VARCHAR2(255)
 * file_ext	Расширение файла, загружаемого в Siebel CRM		VARCHAR2(10)
 * file_size	Размер файла, загружаемого в Siebel CRM		NUMBER
 * file_link	Ссылка на файл в S3		VARCHAR2(1000)
 * packID	Уникальный идентификатор запроса. По packID будет сопоставляться ответ на запрос на стороне системы-инициатора		STRING
 * KafkaIn	Флаг доставки сообщения до Kafka	1 – доставлено  * 0 – не доставлено	VARCHAR2(10)
 * error	Код ошибки		VARCHAR2(10)
 * error_text	Текст ошибки		VARCHAR2(2000)
 * date_start	Дата+время начала загрузки файла		TIMESTAMP(6)
 * date_end	Дата+время завершения загрузки файла		TIMESTAMP(6)
 */

@Entity
@Table(name = "TBANK_HISTORY_FILES")
public class TBankHistoryFiles {

//    @Id
//    @GeneratedValue(generator = "increment")
//    @GenericGenerator(name = "increment", strategy = "increment")
//    @Column(name = "ID")//id записи
//    private long id; //1

    @Id
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "ARCHIVE_NAME")//Название файла - архива от Тбанка
    private String archiveName;

    @Column(name = "FOLDER_NAME")//Название каталога, извлеченного из архива. Соответствует номеру кредитного договора
    private String folderName;

    @Column(name = "FILE_NAME")//Название файла
    private String fileName;

    @Column(name = "FILE_NAME_GUID", length = 1000)//Название файла, загружаемого в Siebel CRM c добавленным GUID
    private String fileNameGuid;

    @Column(name = "FILE_GUID")//GUID файла
    private String fileGuid;

    @Column(name = "FILE_EXT", length = 10)//Расширение файла, загружаемого в Siebel CRM
    private String fileExt;

    @Column(name = "FILE_SIZE")//Размер файла, загружаемого в Siebel CRM
    private long fileSize;

    @Column(name = "FILE_LINK", length = 1000)//Ссылка на файл в S3
    private String fileLink;

    @Column(name = "PACKID")//Уникальный идентификатор запроса. По packID будет сопоставляться ответ на запрос на стороне системы-инициатора
    private String packID;

    @Column(name = "KAFKA_IN", length = 10)//Флаг доставки сообщения до Kafka
    private String kafkaIn;

    @Column(name = "ERROR", length = 10)//Код ошибки
    private String error;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_START")//Дата+время начала загрузки файла
    private Date dateStart;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_END")//Дата+время завершения загрузки файла
    private Date dateEnd;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getArchiveName() {
        return archiveName;
    }

    public void setArchiveName(String archiveName) {
        this.archiveName = archiveName;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileNameGuid() {
        return fileNameGuid;
    }

    public void setFileNameGuid(String fileNameGuid) {
        this.fileNameGuid = fileNameGuid;
    }

    public String getFileGuid() {
        return fileGuid;
    }

    public void setFileGuid(String fileGuid) {
        this.fileGuid = fileGuid;
    }

    public String getFileExt() {
        return fileExt;
    }

    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileLink() {
        return fileLink;
    }

    public void setFileLink(String fileLink) {
        this.fileLink = fileLink;
    }

    public String getPackID() {
        return packID;
    }

    public void setPackID(String packID) {
        this.packID = packID;
    }

    public String getKafkaIn() {
        return kafkaIn;
    }

    public void setKafkaIn(String kafkaIn) {
        this.kafkaIn = kafkaIn;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Date dateEnd) {
        this.dateEnd = dateEnd;
    }

    @Override
    public String toString() {
        return "TBankHistoryFiles{" +
                "id=" + id +
                ", archiveName='" + archiveName + '\'' +
                ", folderName='" + folderName + '\'' +
                ", fileName='" + fileName + '\'' +
                ", fileNameGuid='" + fileNameGuid + '\'' +
                ", fileGuid='" + fileGuid + '\'' +
                ", fileExt='" + fileExt + '\'' +
                ", fileSize=" + fileSize +
                ", fileLink='" + fileLink + '\'' +
                ", packID='" + packID + '\'' +
                ", kafkaIn='" + kafkaIn + '\'' +
                ", error='" + error + '\'' +
                ", dateStart=" + dateStart +
                ", dateEnd=" + dateEnd +
                '}';
    }
}
