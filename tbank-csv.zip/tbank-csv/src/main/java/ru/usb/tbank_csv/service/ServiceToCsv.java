package ru.usb.tbank_csv.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.tbank_csv.config.Configure;
import ru.usb.tbank_csv.model.TBankHistoryFiles;
import ru.usb.tbank_csv.repository.TBankHistoryFilesRepo;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;


@Service
public class ServiceToCsv {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm::ss");

    private static final Logger log = LoggerFactory.getLogger(ServiceToCsv.class);

    //Количество строк
    int lineCount;
    String fullFileNameCSV; //Полное имя файла

    private final EntityManager entityManager;
    private final TBankHistoryFilesRepo tBankHistoryFilesRepo;
    private final Configure configure;

    public ServiceToCsv(EntityManager entityManager, TBankHistoryFilesRepo tBankHistoryFilesRepo, Configure configure) {
        this.entityManager = entityManager;
        this.tBankHistoryFilesRepo = tBankHistoryFilesRepo;
        this.configure = configure;
    }

    @Transactional(readOnly = true)
    public void getStreamAll() {

        fullFileNameCSV = configure.getTempDirUploadFile() + File.separator + "tempo.csv"; //Создаем файл во временной директории
        //Получаем список записей из базы
        Stream<TBankHistoryFiles> fTableStream = null;
        AtomicInteger lineCount = new AtomicInteger(0); // Общее число записей

        fTableStream = tBankHistoryFilesRepo.getStreamAll();

        try {
            FileWriter.write(fullFileNameCSV, getHeader()); //Шапка Fact
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        fTableStream.forEach(fTable -> {
            lineCount.incrementAndGet();
            log.info("id={}", fTable.getId());


            //ID;FILE_NAME;FILE_NAME_GUID;FILE_GUID;FILE_EXT;FILE_SIZE;FILE_LINK;PACKID;KAFKA_IN;ERROR;DATE_START;DATE_END
            //FOLDER_NAME,FILE_NAME,DATE_START,ARCHIVE_NAME

            try {
                FileWriter.write(fullFileNameCSV,

                        fTable.getFolderName() + ";" + fTable.getFileName() + ";" + fTable.getArchiveName() + ";" + getDate(fTable.getDateStart()));



            } catch (IOException e) {
                log.error("Возникла ошибка при записи файла:{}, error:{}", fullFileNameCSV, e.getMessage());
            }
            entityManager.detach(fTable); //Очищаем
        });

        fTableStream.close();
        entityManager.close();
        log.info("Количество обработанных записей = {}", lineCount);
    }


    private String getHeader2() {
        return "ID;FILE_NAME;FILE_NAME_GUID;FILE_GUID;FILE_EXT;FILE_SIZE;FILE_LINK;PACKID;KAFKA_IN;ERROR;DATE_START;DATE_END";
    }

    private String getHeader() {
        return "NOMER_DOGOVOR;FILENAME;ARCHIVE;DATE";
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWNil(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    private String getDate(java.util.Date date) {
        if (date == null) {
            return "";
        } else {
            return sdf.format(date);
        }
    }

}
