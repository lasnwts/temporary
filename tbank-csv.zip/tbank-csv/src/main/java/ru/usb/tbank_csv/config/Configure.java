package ru.usb.tbank_csv.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties
public class Configure {

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${net.file.share}")
    private String netFileShare;

    private String tempDirUploadFile;

    public String getNetFileShare() {
        return netFileShare;
    }

    public void setNetFileShare(String netFileShare) {
        this.netFileShare = netFileShare;
    }

    public String getTempDirUploadFile() {
        return tempDirUploadFile;
    }

    public void setTempDirUploadFile(String tempDirUploadFile) {
        this.tempDirUploadFile = tempDirUploadFile;
    }
}
