package ru.usb.springcloudconfigurationsever.restcontroller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestControllerMF {

    Logger logger = LoggerFactory.getLogger(RestControllerMF.class);

    @RequestMapping("/about")
    public String about(){
        return "Сервис позволяет конфигурировать другие сервисы. Configuration Server – это еще одно Spring Boot приложение. Микросервис, к которому остальные микросервисы обращаются за настройками.";
    }


}
