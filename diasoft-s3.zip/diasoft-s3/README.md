# factorin-s3

factorin-s3. Разделение сервиса factorin-files-receiving. Выделяем отдельно хранилище S3.