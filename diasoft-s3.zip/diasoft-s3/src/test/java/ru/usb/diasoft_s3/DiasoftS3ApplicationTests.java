package ru.usb.diasoft_s3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiasoftS3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
