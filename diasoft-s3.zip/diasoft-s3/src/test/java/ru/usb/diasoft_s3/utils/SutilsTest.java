package ru.usb.diasoft_s3.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.diasoft_s3.configure.Config;

import static org.junit.jupiter.api.Assertions.*;

class SutilsTest {

    private Sutils sutils;

    @BeforeEach
    void setUp() {
        sutils = new Sutils(new Config());
    }

    @Test
    void wrapNull() {
        String result = sutils.getWrapNull(null);
        assertEquals("", result);
    }

    @Test
    void wrapLastSymbol() {
        String result = sutils.wrapLastSymbol("test", "/");
        assertEquals("test/", result);
    }
}