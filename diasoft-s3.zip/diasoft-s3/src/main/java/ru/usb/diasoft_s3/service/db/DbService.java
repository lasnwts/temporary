package ru.usb.diasoft_s3.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.model.S3Result;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Log4j2
@Repository
public class DbService {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public DbService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Проверка наличия записей в таблице записи с именем в поле name
     *
     * @param name - имя файла для проверки
     * @return - целое число записей. 0 - нет записей, >0 есть записи
     */
    public Optional<Integer> checkRecordExist(String name) {
        String sql = "select count(*) from [dbo].[URSB_DFA_tbl_Report] where name = ?";
        // When using parameters, they are passed as a varargs argument after the return type
        return Optional.ofNullable(jdbcTemplate.queryForObject(sql, Integer.class, name));
    }

    /**
     * По итогам обработки файла необходимо делать update записи в таблице URSB_DFA_tbl_Report
     * Поле	Описание	Значение
     * Docid	Идентификатор файла в s3
     * Key	Ключ файла в s3
     * Ref	Ссылка на файл в s3
     * Status	Статус выгрузки	Y или E
     * RetText	Сообщение об ошибке	Текст сообщения
     * Сохранение записи в таблице
     *
     * @param s3Result - объект с данными для сохранения
     */
    public int updateRec(S3Result s3Result) {
        String sql = "UPDATE [dbo].[URSB_DFA_tbl_Report] SET [Docid] =?,[Key] =?,[Ref] =?,[RetText] =?,[Status] =?, [Ref2] =? WHERE  name = ?";
        try {
            // When using parameters, they are passed as a varargs argument after the return type
            return jdbcTemplate.update(sql, s3Result.getDocId(), s3Result.getKey(), s3Result.getShortRef(),
                    s3Result.getRetText(), s3Result.getStatus(), s3Result.getLongRef(), s3Result.getName());
        } catch (Exception e) {
            log.error("{}: Возникла ошибка:{} при операции обновления [UPDATE [dbo].[URSB_DFA_tbl_Report]]: {}", TG.UsbLogError, e.getMessage(), s3Result);
            log.debug("{}: Возникла ошибка при операции обновления [UPDATE [dbo].[URSB_DFA_tbl_Report] ]: с name={}. Stack Trace", TG.UsbLogError, s3Result.getName(), e);
            return 0;
        }
    }

    /**
     * По итогам обработки файла необходимо делать insert записи в таблице URSB_DFA_tbl_Report
     * Поле	Описание	Значение
     * Docid	Идентификатор файла в s3
     * Key	Ключ файла в s3
     * Ref	Ссылка на файл в s3
     * Status	Статус выгрузки	Y или E
     * RetText	Сообщение об ошибке	Текст сообщения
     * Сохранение записи в таблице
     *
     * @param s3Result - объект с данными для сохранения
     */
    public int insertFile(S3Result s3Result) {
        String sql = "INSERT INTO [dbo].[URSB_DFA_tbl_Report] (Docid, [Key], Ref, Status, RetText, [name], Ref2) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            // When using parameters, they are passed as a varargs argument after the return type
            return jdbcTemplate.update(sql, s3Result.getDocId(), s3Result.getKey(), s3Result.getShortRef(),
                    s3Result.getStatus(), s3Result.getRetText(), s3Result.getName(), s3Result.getLongRef());
        } catch (Exception e) {
            log.error("{}: Возникла ошибка:{} при операции вставки [INSERT INTO [dbo].[URSB_DFA_tbl_Report]]: {}", TG.UsbLogError, e.getMessage(), s3Result);
            log.debug("{}: Возникла ошибка при операции вставки [INSERT INTO [dbo].[URSB_DFA_tbl_Report]]: с name={}. Stack Trace", TG.UsbLogError, s3Result.getName(), e);
            return 0;
        }
    }

    /**
     * Проверка наличия записи в таблице записи с именем в поле name
     *
     * @param name - имя файла для проверки
     * @return - true - есть запись, false - нет записи
     */
    public boolean checkRecord(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        if (checkRecordExist(name).isEmpty()) {
            return false;
        } else {
            return checkRecordExist(name).get() > 0;
        }
    }

    /**
     * Проверка наличия записей в таблице
     *
     * @return - целое число записей. 0 - нет записей, >0 есть записи
     */
    public Optional<Integer> getCountRecord() {
        String sql = "select count(*) from [dbo].[URSB_DFA_tbl_Report]";
        // When using parameters, they are passed as a varargs argument after the return type
        return Optional.ofNullable(jdbcTemplate.queryForObject(sql, Integer.class));
    }

    /**
     * Получение количества записей в таблице записи с именем в поле name
     *
     * @param name - имя файла для проверки
     * @return - целое число записей. 0 - нет записей, >0 есть записи
     */
    public Optional<Integer> getCountName(String name) {
        String sql = "select count(*) from [dbo].[URSB_DFA_tbl_Report] where name = ?";
        // When using parameters, they are passed as a varargs argument after the return type
        return Optional.ofNullable(jdbcTemplate.queryForObject(sql, Integer.class, name));
    }

    /**
     * Получение количества записей в таблице записи с именем в поле name
     *
     * @param name - имя файла для проверки
     * @return - целое число записей. 0 - нет записей, >0 есть записи
     */
    public Optional<List<String>> getRecordName(String name) {
        String sql = "select 'name:'+name+', docid:'+Docid+',key:'+[Key]+',Status:'+Status+',Reftext:'+RetText as records from [dbo].[URSB_DFA_tbl_Report] where name =?";
        // When using parameters, they are passed as a varargs argument after the return type
        return Optional.of(Collections.singletonList(jdbcTemplate.queryForObject(sql, String.class, name)));
    }
}

