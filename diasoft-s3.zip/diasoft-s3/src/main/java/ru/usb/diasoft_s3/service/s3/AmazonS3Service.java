package ru.usb.diasoft_s3.service.s3;

import org.springframework.http.HttpStatus;
import ru.usb.diasoft_s3.model.S3Result;

import java.io.File;
import java.util.List;
import java.util.Optional;

public interface AmazonS3Service {

    Optional<S3Result> uploadFile(String bucketName, String originalFilename, byte[] bytes) throws Exception;

    byte[] downloadFile(String bucketName, String fileUrl) throws Exception;

    HttpStatus deleteFile(String bucketName, String fileUrl) throws Exception;

    List<String> listFiles(String bucketName) throws Exception;

    File upload(String bucketName, String name, byte[] content) throws Exception;

    byte[] getFile(String bucketName, String key) throws Exception;

    String getFileLink(String bucketName, String key) throws Exception;

    boolean  checkBucket(String bucket) throws Exception;
}

