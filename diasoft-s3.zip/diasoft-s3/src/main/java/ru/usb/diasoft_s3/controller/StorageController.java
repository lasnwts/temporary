package ru.usb.diasoft_s3.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.diasoft_s3.configure.Config;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.service.s3.MinioService;
import ru.usb.diasoft_s3.service.s3.MinioUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/api/s3")
@Tag(name = "Контроллер S3. Для работы с хранилищем", description = "Управление файлами в хранилище s3")
public class StorageController {

    private static final String STATUS_CODE = "status_code";

    private final MinioUtils minioUtils;
    private final MinioService s3Service;
    private final Config config;

    public StorageController(MinioUtils minioUtils, MinioService s3Service, Config config) {
        this.minioUtils = minioUtils;
        this.s3Service = s3Service;
        this.config = config;
    }

    @PostMapping(value = "/upload/{bucketName}/files", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/{bucketName}/files. Метод : Upload. Метод загрузки файла в хранилище в корзину Bucket.")
    public ResponseEntity<Map<String, String>> upload(
            @PathVariable("bucketName") String bucketName,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        try {
            s3Service.uploadFile(files.getOriginalFilename(), files.getBytes(), bucketName);
            result.put("path", s3Service.getUrl(files.getOriginalFilename(), bucketName, config.getS3LinkExpired()));
            log.info("{} [upload]. Метод загрузки файла в хранилище path:{}", TG.UsbLogInfo, result.get("path"));
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(result);
        }
    }

    @PostMapping(value = "/upload/file", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/upload/file. Метод : Upload. Метод загрузки файла в хранилище в корзину заданную в настройках.")
    public ResponseEntity<Map<String, String>> uploadBucket(
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        try {
            s3Service.uploadFile(files.getOriginalFilename(), files.getBytes(), config.getBucketBase());
            result.put("path", s3Service.getUrl(files.getOriginalFilename(), config.getBucketBase(), config.getS3LinkExpired()));
            log.info("{} [uploadBucket], Метод загрузки файла в хранилище в корзину заданную в настройках, path:{}", TG.UsbLogInfo, result.get("path"));
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(result);
        }
    }

    @GetMapping("/info")
    @Operation(summary = "/info. Метод : получить информацию по объект в бакете (из application.prop).")
    public String getFileStatusInfo(@RequestParam("fileName") String fileName) {
        return minioUtils.getFileStatusInfo(config.getBucketBase(), fileName);
    }

    @GetMapping("/url")
    @Operation(summary = "/url. Метод : получить ссылку на объект в бакете по умолчанию (из application.prop).")
    public String getPresignedObjectUrl(@RequestParam("fileName") String fileName) {
        return minioUtils.getPresignedObjectUrl(config.getBucketBase(), fileName);
    }

    @DeleteMapping("/delete/bucket/file")
    @Operation(summary = "/delete/bucket/file. Метод : Удаление файла:[fileName] из бакета:[bucketName]. Метод удаления файла из хранилища.")
    public HttpStatus deleteFile(String bucketName, String fileName) {
        log.info("{}:Удаляем файл :{} из бакета {}", TG.UsbLogInfo, fileName, bucketName);
        try {
            minioUtils.removeFileLink(config.getBucketBase(), fileName);
            return HttpStatus.OK;
        } catch (Exception e) {
            log.error("{}:Error:deleteFile.Exception:{}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:deleteFile.Exception:stackTrace:", TG.UsbLogError, e);
            return getStatusCode(e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    @Operation(summary = "/delete. Метод : удалить файл из бакета (бакет по умолчанию из application.prop.")
    public void delete(@RequestParam("fileName") String fileName) {
        log.info("{}:delete. Удаляем файл :{} из бакета, заданного в application.properties:{}", TG.UsbLogInfo, fileName, config.getBucketBase());
        minioUtils.removeFile(config.getBucketBase(), fileName);
    }

    @GetMapping("/{bucketName}/files")
    @Operation(summary = "/{bucketName}/files. Метод Get list Objects in buckets. Получить список всех файлов в корзине хранилища")
    public ResponseEntity<List<String>> listObjects(
            @PathVariable("bucketName") String bucketName,
            @RequestParam(value = "prefix", required = false) String prefix) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(s3Service.listFiles(bucketName, prefix));
        } catch (Exception e) {
            List<String> errorList = new ArrayList<>();
            errorList.add(e.getMessage());
            log.error("{}:listObjects: Возникла ошибка: ", TG.UsbLogError, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(errorList);
        }
    }

    @GetMapping("/files")
    @Operation(summary = "/bucket/files. Получить список всех файлов в бакете (корзине) хранилища, заданной в application.prop")
    public ResponseEntity<List<String>> listBucket() {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(s3Service.listFiles(config.getBucketBase(), ""));
        } catch (Exception e) {
            List<String> errorList = new ArrayList<>();
            errorList.add(e.getMessage());
            log.error("{}:listObjects: Возникла ошибка: ", TG.UsbLogError, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(errorList);
        }
    }


    @GetMapping(value = "/download/{bucketName}/{keyName}", consumes = "application/octet-stream")
    @Operation(summary = "/download/{bucketName}/{keyName}. Метод Download file (получить / скачать файл) Метод получения файла из хранилища.")
    public ResponseEntity<ByteArrayResource> downloadFile(
            @PathVariable("bucketName") String bucketName,
            @PathVariable("keyName") String keyName) {
        byte[] data = null;
        try {
            data = s3Service.downloadFile(bucketName, keyName);
            ByteArrayResource resource = new ByteArrayResource(data);
            ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                    .filename(keyName, StandardCharsets.UTF_8)
                    .build();
            return ResponseEntity
                    .ok()
                    .contentLength(data.length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", contentDisposition.toString())
                    .body(resource);
        } catch (Exception e) {
            log.error("{}:downloadFile: Возникла ошибка: ", TG.UsbLogError, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(new ByteArrayResource(e.getMessage().getBytes(StandardCharsets.UTF_8)));
        }
    }

    @GetMapping(value = "/download/{keyName}", consumes = "application/octet-stream")
    @Operation(summary = "/download/{keyName}. Метод Download file (получить / скачать файл) Метод получения файла из хранилища.")
    public ResponseEntity<ByteArrayResource> downloadFileFromBucket(
            @PathVariable("keyName") String keyName) {
        byte[] data = null;
        try {
            data = s3Service.downloadFile(config.getBucketBase(), keyName);
            ByteArrayResource resource = new ByteArrayResource(data);
            ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                    .filename(keyName, StandardCharsets.UTF_8)
                    .build();
            return ResponseEntity
                    .ok()
                    .contentLength(data.length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", contentDisposition.toString())
                    .body(resource);
        } catch (Exception e) {
            log.error("{}:downloadFile: Возникла ошибка: ", TG.UsbLogError, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(new ByteArrayResource(e.getMessage().getBytes(StandardCharsets.UTF_8)));
        }
    }

    @PostMapping(value = "/checkBucket")
    @Operation(summary = "/checkBucket. Метод : check Bucket. Проверка наличия бакета = Bucket.")
    public ResponseEntity<String> checkBucket(@RequestBody String bucketName) {
        try {
            if (s3Service.checkBucket(bucketName)){
                return ResponseEntity.status(HttpStatus.OK).body("bucket exist");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("bucket NOT exist");
            }
        } catch (Exception e) {
            log.error("{}: Ошибка при проверке существования бакета={}", TG.UsbLogError, bucketName, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(e.getMessage());
        }
    }

    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    private HttpStatus getStatusCode(String line) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        if (line == null) {
            return httpStatus;
        }
        if (line.toLowerCase().contains("not exist") || line.toLowerCase().contains("name does not follow")){
            line = line + " STATUS_CODE  404  ";
        }

        if (line != null && line.toLowerCase().contains(STATUS_CODE)) {

            String code = line.toLowerCase().substring(line.toLowerCase().indexOf(STATUS_CODE) + 13,
                    line.toLowerCase().indexOf(STATUS_CODE) + 16);

            switch (code) {
                case "404":
                    httpStatus = HttpStatus.NOT_FOUND;
                    break;
                case "400":
                    httpStatus = HttpStatus.BAD_REQUEST;
                    break;
                case "401":
                    httpStatus = HttpStatus.UNAUTHORIZED;
                    break;
                case "403":
                    httpStatus = HttpStatus.FORBIDDEN;
                    break;
                case "405":
                    httpStatus = HttpStatus.METHOD_NOT_ALLOWED;
                    break;
                case "501":
                    httpStatus = HttpStatus.NOT_IMPLEMENTED;
                    break;
                case "502":
                    httpStatus = HttpStatus.BAD_GATEWAY;
                    break;
                case "503":
                    httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
                    break;
                case "504":
                    httpStatus = HttpStatus.GATEWAY_TIMEOUT;
                    break;
                case "300":
                    httpStatus = HttpStatus.MULTIPLE_CHOICES;
                    break;
                case "301":
                    httpStatus = HttpStatus.MOVED_PERMANENTLY;
                    break;
                default:
                    httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                    break;
            }
        }
        return httpStatus;
    }


}
