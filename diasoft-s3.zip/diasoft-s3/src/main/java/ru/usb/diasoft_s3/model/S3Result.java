package ru.usb.diasoft_s3.model;

import lombok.*;

/**
 * Результат обработки файла из факторинга в S3
 * S3Result =
 * Поле	Описание	Значение
 * Docid	Идентификатор файла в s3
 * Key	Ключ файла в s3
 * Ref	Ссылка на файл в s3
 * Status	Статус выгрузки	Y или E
 * RetText	Сообщение об ошибке	Текст сообщения
 */

@Getter
@Setter
@NoArgsConstructor
@ToString
public class S3Result {

    private String tag; //ссылка на Файл в s3
    private boolean result;  //Успех = true, false - мимо
    private String description; // Описание ошибки
    private String docId; //Имя файла в s3
    private String key;
    private String ref;
    private String status;
    private String retText;
    private String name; //Имя файла

    public S3Result(String tag, boolean result, String description) {
        this.tag = tag;
        this.result = result;
        this.description = description;
    }
}
