package ru.usb.diasoft_s3.configure;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.Properties;

/**
 * Конфигурация SMB
 * CIFSContext cifsContext = new BaseContext(configuration).withCredentials(auth);
 * return cifsContext;
 * throw e;
 */
@Log4j2
@Configuration
public class CIFSConfig {
    @Value("${smb.file.domain}")
    private String domain;
    @Value("${smb.file.username}")
    private String username;
    @Value("${smb.file.password}")
    private String password;

    @Bean
    @Primary
    public CIFSContext doAuth() {
        try {
            NtlmPasswordAuthenticator auth = new NtlmPasswordAuthenticator(domain, username, password);
            Properties properties = new Properties();
            properties.setProperty("jcifs.smb.client.responseTimeout", "20000");
            PropertyConfiguration configuration = new PropertyConfiguration(properties);
            return new BaseContext(configuration).withCredentials(auth);
        } catch (Exception e) {
            log.error("{} Ошибка инициализации smb:{}", TG.UsbLogError, e.getMessage());
            log.error("{} Stack Trace smb:", TG.UsbLogError, e);
            return null;
        }
    }
}
