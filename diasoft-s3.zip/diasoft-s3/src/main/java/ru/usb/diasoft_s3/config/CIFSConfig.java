package ru.usb.diasoft_s3.config;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.Properties;

/**
 * Конфигурация SMB
 * return cifsContext;
 * throw e;
 */
@Configuration
public class CIFSConfig {
    @Value("${smb.file.domain}")
    private String domain;
    @Value("${smb.file.username}")
    private String username;
    @Value("${smb.file.password}")
    private String password;

    Logger log = LoggerFactory.getLogger(CIFSConfig.class);

    @Bean
    @Primary
    public CIFSContext doAuth() {
        try {
            NtlmPasswordAuthenticator auth = new NtlmPasswordAuthenticator(domain, username, password);
            Properties properties = new Properties();
            properties.setProperty("jcifs.smb.client.responseTimeout", "20000");
            PropertyConfiguration configuration = new PropertyConfiguration(properties);
            return new BaseContext(configuration).withCredentials(auth);
        } catch (Exception e) {
            log.error("{} Ошибка инициализации smb:{}", LG.USBLOGERROR, e.getMessage());
            log.error("{} Stack Trace smb:", LG.USBLOGERROR, e);
            return null;
        }
    }
}
