package ru.usb.diasoft_s3.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.configure.Config;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.service.mail.EmailService;
import ru.usb.diasoft_s3.service.smb.SmbService;
import ru.usb.diasoft_s3.utils.Sutils;

import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@Service
public class FlowScheduler {


    private final FlowFileOperation fileOperationMinio;
    private final Config config;
    private final Sutils support;
    private final SmbService smbService;
    private final EmailService emailService;


    public FlowScheduler(FlowFileOperation fileOperationMinio, Config config, Sutils support, SmbService smbService, EmailService emailService) {
        this.fileOperationMinio = fileOperationMinio;
        this.config = config;
        this.support = support;
        this.smbService = smbService;
        this.emailService = emailService;
    }

    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void masterScheduler() {
        if (config.isServiceEnabled()) {
            log.info("{}: <<<<<<<<<<< Scheduler started.>>>>>>>>>>>>", TG.UsbLogInfo);
            //Включим принудительный сбор мусора
            fileOperationMinio.start();
            log.info("{}: <<<<<<<<<<< Scheduler stopped.>>>>>>>>>>>>", TG.UsbLogInfo);
        }
    }

    //Очистка файловых шар от старых файлов
    @Scheduled(cron = "${cron-scheduler}")
    public void startScheduler() {
        log.info("{} cron-start. Стартовал процесс очистки каталогов /out и /err от старых файлов.", TG.UsbLogInfo);
        log.info("{} Файлы  в каталоге /out - старше даты:{} будут удалены.", TG.UsbLogInfo, support.getOldFileDate());
        log.info("{} Файлы  в каталоге /err - старше даты:{} будут удалены.", TG.UsbLogInfo, support.getErrFileDate());
        List<String> errFiles; //Список файлов в каталоге /err
        //Доступ через SMB
        errFiles = smbService.cleanSmbFileService();
        if (!errFiles.isEmpty()) {
            //Отправка почты
            emailService.sendSimpleEmail(config.getMailToBusiness(), "В каталоге Err содержатся файлы", errFiles.stream().map(Object::toString)
                    .collect(Collectors.joining(",\n\r ")));
        }
        log.info("{} cron-stop. Процесс очистки каталогов завершен.", TG.UsbLogInfo);
    }

}


