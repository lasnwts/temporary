package ru.usb.diasoft_s3;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.service.db.DbService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

//https://jxausea.medium.com/springboot-integrated-minio-quick-start-tutorial-8ef1afe3f9e5

@Log4j2
@EnableScheduling
@SpringBootApplication
public class DiasoftS3Application implements CommandLineRunner {

    private final DbService dbService;

    public DiasoftS3Application(DbService dbService) {
        this.dbService = dbService;
    }

    public static void main(String[] args) {
        SpringApplication.run(DiasoftS3Application.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:0.0.28}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API (diasoft-s3)")
                .version(appVersion)
                .description("API Diasoft-s3, a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            log.info("{}: Directory:{}= created", TG.UsbLogInfo, path);
        } else {
            log.info("{}: Directory: {}= already exists", TG.UsbLogInfo, path);
            //Очистка каталога при старте
            List<String> fileList;
            try (Stream<Path> list = Files.list(Paths.get(path.toString()))) {
                fileList =
                        list.filter(Files::isRegularFile).map(Path::toFile).map(File::getAbsolutePath)
                                .toList();
                fileList.forEach(files -> cleanUp(Paths.get(files)));
            } catch (Exception e) {
                log.error("Directory: {} = Could not create upload folder!", path);
                log.error("Print stackTrace:", e);
            }
        }

        log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Created by 21.10.2025             : initial version: 0.0.1  Author@Lyapustin A.S.", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
        log.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Modified reason  24/10/2025       : 0.0.1 Функционал работы с S3 вынесен в отдельный сервис", TG.UsbLogInfo);
        log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);

        log.info("Count:{}", dbService.getCountRecord());
        dbService.getRecordName("application.yml").ifPresent(list -> list.forEach(log::info));


    }

    /**
     * Очистка каталога
     *
     * @param path - путь
     */
    public void cleanUp(Path path) {
        try {
            Files.delete(path);
        } catch (IOException e) {
            log.info("{}: Ошибка при удалении файла: {}", TG.UsbLogInfo, path.toFile().getAbsolutePath());
        }
    }
}
