package ru.usb.diasoft_s3;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.diasoft_s3.configure.TG;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Log4j2
@EnableScheduling
@SpringBootApplication
public class DiasoftS3Application implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(DiasoftS3Application.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:1.0.0}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API (diasoft-s3)")
                .version(appVersion)
                .description("API Diasoft-s3, a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }


    @Override
    public void run(String... args) throws Exception {

        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp");
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            log.info("{}: Directory:{}= created", TG.UsbLogInfo, path);
        } else {
            log.info("{}: Directory: {}= already exists", TG.UsbLogInfo, path);
            //Очистка каталога при старте
            //Очистка директории
            FileUtils.cleanDirectory(new File(path.toString()));
        }

        log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Created by 21.10.2025             : initial version: 0.0.1  Author@Lyapustin A.S.", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
        log.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Modified reason  24/10/2025       : 0.0.1 Функционал работы с S3 вынесен в отдельный сервис", TG.UsbLogInfo);
        log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);

    }


}
