package ru.usb.diasoft_s3.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.diasoft_s3.configure.Configure;
import ru.usb.diasoft_s3.configure.TG;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class Sutils {

    private final Configure config;

    @Autowired
    public Sutils(Configure config) {
        this.config = config;
    }

    private static final Logger log = LoggerFactory.getLogger(Sutils.class);
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    /**
     * Получить дату файла
     *
     * @return - LocalDate
     */
    public String getOldFileDate() {
        return LocalDate.now().minusDays(config.getOutFileOld()).format(formatter); //Текущая дата - 30 дней
    }

    /**
     * Получить дату файла
     *
     * @return - LocalDate
     */
    public String getErrFileDate() {
        return LocalDate.now().minusDays(config.getErrFileOld()).format(formatter); //Текущая дата - 30 дней
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Определение отсутствия имени файла
     * @param fileName - имя файла
     * @return - имя файла
     */
    public String getFileName(String fileName) {
        if (fileName != null){
            return fileName.trim();
        } else {
            return "";
        }
    }

    /**
     * Запись файла во временный каталог
     * @param name - имя файла
     * @param content - содержимое файла
     * @return - файл
     */
    public File upload(String name, byte[] content) throws IOException {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        if (file.canWrite()){

            log.debug("{}:file.canWrite()=true", TG.UsbLogInfo);
        }
        if (file.canRead()){
            log.debug("{}:file.canRead()=true", TG.UsbLogInfo);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}: Error2: FileOutputStream(file).write(content):", TG.UsbLogError, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Запись файла во временный каталог
     * @param name - имя файла
     * @param content - содержимое файла
     * @param threadNum - номер потока, как часть пути
     * @return - файл
     */
    public File uploadThread(String name, byte[] content, String threadNum) throws IOException {
        File file;
        if (createPath(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + threadNum)){
            file = new File(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + threadNum + FileSystems.getDefault().getSeparator() + name);
        } else {
            log.error("{}:Error:Can't create directory for thread:{}. Воспользуемся общей временной директорией -tmp", TG.UsbLogError, threadNum);
            file = new File(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() +"tmp" +  FileSystems.getDefault().getSeparator() + name);
        }
        if (file.canWrite()){
            log.debug("{}:T{} file.canWrite() = true", TG.UsbLogInfo, threadNum);
        }
        if (file.canRead()){
            log.debug("{}:{} file.canRead() = true", TG.UsbLogInfo, threadNum);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:{}  Error: FileOutputStream(file).write(content):", TG.UsbLogError, threadNum, e);
            throw new IOException(e);
        }
        return file;
    }

    /**
     * Создание пути для загрузки файлов
     * @param fullPathString - путь
     * @return - успех, true - успешно, false  нет
     */
    public boolean createPath(String fullPathString) {
        Path path = Paths.get(fullPathString);
        if (!Files.exists(path)) {
            try {
                Files.createDirectory(path);
                log.info("{}: Directory thread:{}= created", TG.UsbLogInfo, path);
                return true;
            } catch (IOException e) {
                log.error("{} Возникла ошибка при создании директории:  {} для потока:ошибка:{}", TG.UsbLogError, path, e.getMessage());
                log.debug("{} Подробнее, возникла ошибка при создании директории: {} для - потока:", TG.UsbLogError, path, e);
                return false;
            }

        } else {
            return true;
        }
    }

    /**
     * Получаем дату и время в нужном формате для топика Data
     *
     * @param date - дата
     * @return - дата и время в нужном формате
     */
    public String getDateTime(Date date) {
        return sdf.format(date);
    }



}
