package ru.usb.diasoft_s3.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties
public class Config {

    /**
     * Путь к сетевой папке с файлами
     */
    @Value("${file.url}")
    private String fileUrl;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${app.destination.folder}")
    private String netFileShare;


    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    //SMB
    @Value("${source.file.url}")
    private String sourceFileUrl; //Сетевая папка, где расположены файлы

    /**
     * Путь к файлу
     */
    //Сетевая папка для файлов из ЦБ
    @Value("${smb.file.url}")
    private String smbFileUrl;

    //Сетевая папка для архивирования входящих файлов
    @Value("${smb.file.arc}")
    private String smbFileArchive;

    //Сетевая папка для файлов в ЦБ
    @Value("${smb.file.out}")
    private String smbFileOut;

    // ---- Реализация ----
    public String getAppName() {
        return appName;
    }

    public String getNetFileShare() {
        return netFileShare;
    }

    public void setNetFileShare(String netFileShare) {
        this.netFileShare = netFileShare;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getMailToBusiness() {
        return mailToBusiness;
    }

    //smb
    public String getSmbFileUrl() {
        return smbFileUrl;
    }
}
