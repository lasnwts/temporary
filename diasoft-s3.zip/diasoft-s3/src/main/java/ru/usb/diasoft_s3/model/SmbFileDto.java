package ru.usb.diasoft_s3.model;

import jcifs.smb.SmbFile;

/**
 * Класс для передачи двух файлов
 */
public class SmbFileDto {

    private SmbFile fileSource;
    private SmbFile fileDestination;

    public SmbFileDto(SmbFile fileSource, SmbFile fileDestination) {
        this.fileSource = fileSource;
        this.fileDestination = fileDestination;
    }

    public SmbFileDto() {
        //empty
    }

    public SmbFile getFileSource() {
        return fileSource;
    }

    public void setFileSource(SmbFile fileSource) {
        this.fileSource = fileSource;
    }

    public SmbFile getFileDestination() {
        return fileDestination;
    }

    public void setFileDestination(SmbFile fileDestination) {
        this.fileDestination = fileDestination;
    }
}
