package ru.usb.diasoft_s3.model;

import jcifs.smb.SmbFile;
import lombok.Getter;
import lombok.Setter;

/**
 * Класс для передачи двух файлов
 */
@Setter
@Getter
public class SmbFileDto {

    private SmbFile fileSource;
    private SmbFile fileDestination;

    public SmbFileDto(SmbFile fileSource, SmbFile fileDestination) {
        this.fileSource = fileSource;
        this.fileDestination = fileDestination;
    }

    public SmbFileDto() {
        //empty
    }

}
