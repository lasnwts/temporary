package ru.usb.diasoft_s3.configure;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties
@Data
public class Config {

    /**
     * Протухание в секундах ссылки
     */
    @Value("${s3.link.expired}")
    private int s3LinkExpired;

    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Путь к файлам с ошибками
     */
    @Value("${smb.file.err}")
    private String smbFileErr;

    /**
     * Путь к архивам файлов
     */
    @Value("${smb.file.arc}")
    private String smbFileArc;

    /**
     * Файлы в каталоге Err будут удалены, если он старше заданного количества дней
     */
    @Value("${err.file.old:30}")
    private int errFileOld;

    /**
     * Файлы в каталоге Out будут удалены, если он старше заданного количества дней
     */
    @Value("${out.file.old:30}")
    private int outFileOld;

    /**
     * Путь к файлу
     */
    @Value("${smb.file.url}")
    private String smbFileUrl;

    /**
     * Наименование бакетов
     * bucket.base
     */
    @Value("${s3.bucket.base}")
    private String bucketBase;

    @Value("${s3.url}")
    private String hostS3;

    /**
     * Секция о программе
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     *  Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

}
