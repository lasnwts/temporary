package ru.usb.diasoft_s3.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.configure.Config;

@Log4j2
@Service
public class ApiLayer {

    private final Config config;


    @Autowired
    public ApiLayer(Config config) {
        this.config = config;
    }


    /**
     * Установка включения сервиса
     *
     * @param enabled - true - сервис включен, false - сервис выключен
     */
    public void setServiceEnabled(boolean enabled) {
        config.setServiceEnabled(enabled);
    }

    /**
     * Включен или выключен сервис
     *
     * @return -  - true - сервис включен, false - сервис выключен
     */
    public boolean getServiceEnabled() {
        return config.isServiceEnabled();
    }

}
