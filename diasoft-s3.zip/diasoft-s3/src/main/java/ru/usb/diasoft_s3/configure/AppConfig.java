package ru.usb.diasoft_s3.configure;

import io.minio.MinioClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Value("${s3.url}")
    private String s3Url;
    @Value("${s3.accessKey}")
    private String accessKey;
    @Value("${s3.secretKey}")
    private String secretKey;

    @Bean
    public MinioClient minoClient() {
        try {
            // Create a MinioClient instance
            return MinioClient.builder()
                    .endpoint(s3Url) // Replace with your MinIO endpoint
                    .credentials(accessKey, secretKey) // Replace with your credentials
                    .build();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

}

