package ru.usb.diasoft_s3.service.s3;

import io.minio.*;
import io.minio.errors.*;
import io.minio.messages.Item;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import io.minio.http.Method;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.utils.Sutils;

import javax.xml.ws.WebServiceException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Log4j2
@Service
public class MinioService {

    private final MinioClient minioClient;
    private final Sutils sutils;
    private final MinioUtils minioUtils;

    public MinioService(MinioClient minioClient, Sutils sutils, MinioUtils minioUtils) {
        this.minioClient = minioClient;
        this.sutils = sutils;
        this.minioUtils = minioUtils;
    }

    @Value("${s3.link.expired:600}")
    private int linkExpired;


    /**
     * Получение файла
     * @param bucketName
     * @param fileUrl
     * @return
     * @throws Exception
     */
    public byte[] downloadFile(String bucketName, String fileUrl) throws Exception {
        return getFile(bucketName, fileUrl);
    }


    /**
     * Получение ссылки на файл
     *
     * @param fileName - имя файла
     * @param bucket   - имя бакета
     * @return - ссылка на файл
     */
    public String getPresignedUrl(String fileName, String bucket) {
        try {
            int expiryTimeSeconds = 60 * linkExpired; // 1 hour expiry

            // Get a presigned URL for GET operation
            String getUrl = minioClient.getPresignedObjectUrl(
                    GetPresignedObjectUrlArgs.builder()
                            .method(Method.GET)
                            .bucket(bucket)
                            .object(fileName)
                            .expiry(expiryTimeSeconds)
                            .build());
            log.info("{}: Presigned GET URL: {}", TG.UsbLogInfo, getUrl);
            return getUrl;
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * Проверка наличия файла в бакете
     *
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     * @return - true - есть файл, false - нет файла
     */
    public ObjectWriteResponse uploadFile(String fileName, byte[] content, String bucketName) throws Exception {
        return minioClient.putObject(PutObjectArgs.builder()
                .bucket(bucketName)
                .object(fileName)
                .stream(new ByteArrayInputStream(content), content.length, -1)
                .build());
    }

    /**
     * Получение ссылки на файл
     *
     * @param fileName   - имя файла
     * @param bucketName - имя бакета
     * @return - ссылка на файл
     */
    public String getUrl(String fileName, String bucketName, int lifetime) throws WebServiceException, ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                .method(Method.GET)
                .bucket(bucketName)
                .object(fileName)
                .expiry(lifetime, TimeUnit.MINUTES)
                .build()
        );
    }

    /**
     * Проверка наличия бакета
     *
     * @param bucketName - имя бакета
     * @return - true - есть бакет, false - нет бакета
     */
    public boolean checkBucket(String bucketName) {
        try {
            return minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
        } catch (ErrorResponseException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Получение ссылки на файл
     *
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     * @param host       - хост
     * @return - ссылка на файл
     */
    public String getFileLink(String bucketName, String fileName, String host) throws Exception {
        boolean found = checkBucket(bucketName);
        if (found) {
            log.debug("{}:{}  bucket name exists/ Ok", TG.UsbLogInfo, bucketName);
        } else {
            log.warn("{}: {} bucket name does not exist", TG.UsbLogInfo, bucketName);
            return bucketName + " bucket name does not exist";
        }
        if (!isObjectExist(bucketName, fileName)) {
            log.warn("{}: {} object name does not exist", TG.UsbLogInfo, fileName);
            return fileName + " object name does not exist";
        }
        String s3Url = sutils.wrapLastSymbol(host, "/") + bucketName + "/" + fileName;
        log.info("{}: objectStat URL := {}", TG.UsbLogInfo, s3Url);
        return s3Url;
    }

    /**
     * Проверка наличия объекта в бакете
     *
     * @param bucketName - имя бакета
     * @param name       - имя объекта
     * @return - true - есть объект, false - нет объекта
     */
    public boolean isObjectExist(String bucketName, String name) {
        try {
            minioClient.statObject(StatObjectArgs.builder()
                    .bucket(bucketName)
                    .object(name).build());
            return true;
        } catch (ErrorResponseException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Получение файла
     * @param bucketName
     * @param key
     * @return
     * @throws Exception
     */
    public byte[] getFile(String bucketName, String key) throws Exception {
        try {
            return IOUtils.toByteArray(minioUtils.getObject(bucketName, key));
        } catch (IOException e) {
            log.error("{}:Error: {}", TG.UsbLogError, e.getMessage());
            log.debug("{}:Error:{}", TG.UsbLogError, e);
        }
        return new byte[0];
    }

    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public List<String> listFiles(String bucketName, String prefix) throws Exception {
        return minioUtils.getAllObjectsByPrefix(bucketName, prefix, true)
                .stream()
                .map(Item::objectName)
                .toList();
    }

}

