package ru.usb.diasoft_s3.service;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.usb.diasoft_s3.configure.TG;


import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

@Log4j2
@Component
public class TestSecuredConnection {

    @Value("${http.client.ssl.trust-store}")
    private String trustStore;
    @Value("${http.client.ssl.trust-store-password}")
    private String trustStorePassword;


    public List<String> testConnectionTo(String aURL) throws Exception {
        List<String> certificationList = new ArrayList<>();
        URL destinationURL = new URL(aURL);
        HttpsURLConnection conn = (HttpsURLConnection) destinationURL
                .openConnection();
        conn.connect();
        Certificate[] certs = conn.getServerCertificates();
        for (Certificate cert : certs) {
            log.info("{}: Certificate is: {}", TG.UsbLogInfo, cert);
            certificationList.add(cert.toString());
            if (cert instanceof X509Certificate) {
                try {
                    ((X509Certificate) cert).checkValidity();
                    log.info("{}: Certificate is active for current date", TG.UsbLogInfo);
                } catch (CertificateExpiredException cee) {
                    log.info("{}: Certificate is expired", TG.UsbLogInfo);
                }
            }
        }
        return certificationList;
    }


    /**
     * Получить список сертификатов
     *
     * @return - список алиасов
     */
    public List<String> getSslCert() {
        List<String> certList = new ArrayList<>();
        File file = new File(trustStore);
        try (InputStream is = new FileInputStream(file)) {
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            String password = trustStorePassword;
            keystore.load(is, password.toCharArray());
            Enumeration<String> enumeration = keystore.aliases();
            while (enumeration.hasMoreElements()) {
                String alias = enumeration.nextElement();
                log.info("{}:alias name: {}", TG.UsbLogInfo, alias);
                certList.add(alias);
                Certificate certificate = keystore.getCertificate(alias);
                log.info("{}:certificate.toString(): {}", TG.UsbLogInfo, certificate.toString());
            }
        } catch (CertificateException e) {
            log.info("{}:Error CertificateException ", TG.UsbLogInfo, e);
        } catch (NoSuchAlgorithmException e) {
            log.info("{}:Error NoSuchAlgorithmException ", TG.UsbLogInfo, e);
        } catch (FileNotFoundException e) {
            log.info("{}:Error FileNotFoundException ", TG.UsbLogInfo, e);
        } catch (KeyStoreException e) {
            log.info("{}:Error KeyStoreException ", TG.UsbLogInfo, e);
        } catch (IOException e) {
            log.info("{}:Error IOException ", TG.UsbLogInfo, e);
        }
        return certList;
    }
}
