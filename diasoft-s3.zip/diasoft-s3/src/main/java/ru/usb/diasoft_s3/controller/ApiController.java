package ru.usb.diasoft_s3.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.service.ApiLayer;
import ru.usb.diasoft_s3.service.TestSecuredConnection;
import ru.usb.diasoft_s3.service.mail.EmailService;
import ru.usb.diasoft_s3.utils.Sutils;


import java.util.ArrayList;
import java.util.List;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@Log4j2
@RestController
@RequestMapping("/api/check")
@Tag(name = "Контроллер с основными функциями сервиса. Версия 0.0.16", description = "Проверка отправки почты, получения токена, файла и т.д.")
public class ApiController {

    
    private final EmailService emailService;
    private final Sutils support;
    private final TestSecuredConnection testSecuredConnection;
    private final ApiLayer apiLayer;

    @Autowired
    public ApiController(EmailService emailService, Sutils support, TestSecuredConnection testSecuredConnection, ApiLayer apiLayer) {
        this.emailService = emailService;
        this.support = support;
        this.testSecuredConnection = testSecuredConnection;
        this.apiLayer = apiLayer;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                                  @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmailThrow(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            log.error("{}: while sending out email..", TG.UsbLogError, mailException);
            return new ResponseEntity<>("Unable to send email: \n\r " + support.getWrapNull(mailException.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }


    @PostMapping(value = "/checkssl")
    @Operation(summary = "Получить цепочку сертификатов. Пример заполнения тела запроса: https://stageidentity1.faktor.in/")
    public List<String> checkSSL(@RequestBody String url) {
        log.info("{}: Получен запрос на цепочку сертификатов, url={}", TG.UsbLogInfo, url);
        List<String> list = new ArrayList<>();
        try {
            list = testSecuredConnection.testConnectionTo(url);
        } catch (Exception e) {
            log.error("{}: Возникла ошибка testConnectionTo {}", TG.UsbLogError, e.getMessage());
            log.debug("{}: Stack Trace:", TG.UsbLogError, e);
            list.add("Возникла ошибка:");
            list.add(e.getMessage());
        }
        return list;
    }

    @GetMapping(value = "/getcert")
    @Operation(summary = "Получить имена сертификатов из файла JKS (см. application.properties")
    public List<String> getJKS() {
        log.info("{}: Получен запрос имена сертификатов из файла JKS ", TG.UsbLogInfo);
        List<String> list = new ArrayList<>();
        try {
            list = testSecuredConnection.getSslCert();
        } catch (Exception e) {
            log.error("{}: Возникла ошибка - getSslCert {}", TG.UsbLogError, e.getMessage());
            log.debug("{}: Stack Trace:", TG.UsbLogError, e);
            list.add("Возникла ошибка:");
            list.add(e.getMessage());
        }
        return list;
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        apiLayer.setServiceEnabled(enabled);
        if (enabled) {
            log.info("{}:[setEnableService] Web API. Service enabled", TG.UsbLogInfo);
        } else {
            log.info("{}:[setEnableService] Web API. Service disabled", TG.UsbLogInfo);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (apiLayer.getServiceEnabled()) {
            log.info("{}:[getEnableService] Web API. Service enabled", TG.UsbLogInfo);
        } else {
            log.info("{}:[getEnableService] Web API. Service disabled", TG.UsbLogInfo);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

}
