package ru.usb.diasoft_s3.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.internal.http.loader.DefaultSdkHttpClientBuilder;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.SdkHttpConfigurationOption;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.utils.AttributeMap;

import java.net.URI;

@Configuration
public class S3Configuration {

    private final S3ConfigurationProperties s3ConfigurationProperties;

    public S3Configuration(S3ConfigurationProperties s3ConfigurationProperties) {
        this.s3ConfigurationProperties = s3ConfigurationProperties;
    }

    @Bean
    public S3Client s3Client() {
        AwsBasicCredentials credentials = AwsBasicCredentials.create(s3ConfigurationProperties.getAccessKey(),
                s3ConfigurationProperties.getSecretKey());

        //System.setProperty(SdkHttpConfigurationOption.TRUST_ALL_CERTIFICATES = true);
        AwsCredentialsProvider credentialsProvider = StaticCredentialsProvider.create(credentials);
        return S3Client.builder()
                .httpClient(getHttpClient())
                .credentialsProvider(credentialsProvider)
                .endpointOverride(URI.create(s3ConfigurationProperties.getUrl()))
                .region(Region.of(s3ConfigurationProperties.getRegion()))
                .build();
    }

    //https://repost.aws/questions/QUGP991x-rTu-Qgf3NitYrEw/bypass-or-disable-ssl-certificate-verification-for-s3
    protected SdkHttpClient getHttpClient() {
        final AttributeMap attributeMap = AttributeMap.builder().put(SdkHttpConfigurationOption.TRUST_ALL_CERTIFICATES, true).build();
        return new DefaultSdkHttpClientBuilder().buildWithDefaults(attributeMap);
    }

}
