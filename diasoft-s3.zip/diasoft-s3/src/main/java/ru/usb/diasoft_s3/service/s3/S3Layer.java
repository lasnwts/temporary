package ru.usb.diasoft_s3.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.config.Config;
import ru.usb.diasoft_s3.config.LG;
import ru.usb.diasoft_s3.config.S3Configuration;
import software.amazon.awssdk.services.s3.model.*;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

@Log4j2
@Service
public class S3Layer {

    private final Config config;
    private final S3Configuration s3;

    public S3Layer(Config config, S3Configuration s3) {
        this.config = config;
        this.s3 = s3;
    }

    //https://www.baeldung.com/java-aws-s3
    //https://www.codejava.net/aws/list-buckets-example

    public void getBucket() {
        List<Bucket> allBuckets = new ArrayList<>();
        String nextToken = null;

        ListBucketsRequest listBucketsRequest = ListBucketsRequest.builder().build();
        ListBucketsResponse listBuckets = s3.s3Client().listBuckets(listBucketsRequest);

        listBuckets.buckets().stream().forEach(
                x -> System.out.println(x.name() + " - " + x.creationDate()));

        List<Bucket> buckets = listBuckets.buckets();
        buckets.forEach(new Consumer<Bucket>() {
            @Override
            public void accept(Bucket bucket) {
                System.out.println("Бакет=" + bucket.name());
            }
        });
    }

    public boolean uploadFile(String bucketName, String originalFilename, byte[] bytes) throws Exception {
        File file = upload(bucketName, originalFilename, bytes);

        /**
         * Можно добавлять мета данные
         * Map<String, String> metadata = new HashMap<>();
         * metadata.put("company", "Baeldung");
         * metadata.put("environment", "development")
         */

        Map<String, String> metadata = new HashMap<>();
        metadata.put("company", "Baeldung");
        metadata.put("environment", "development");

        PutObjectResponse putObject = s3.s3Client().putObject(request ->
                        request
                                .bucket(bucketName)
                                .key(file.getName())
                                .metadata(metadata)
                ,
                file.toPath());

        try {
            Files.delete(file.toPath());
        } catch (Exception e) {
            log.error("{}:Error! Temporary file not deleted:{}, error:{}", LG.USBLOGINFO, file.getAbsolutePath(), e.getMessage());
            log.debug("{}:Temporary file not deleted:stackTrace:", LG.USBLOGINFO, e);
            return false;
        }
        if (file.exists()) {
            log.error("{}:Error! Temporary file not deleted:{}", LG.USBLOGINFO, file.getAbsolutePath());
        }
        if (putObject != null && putObject.eTag() != null) {
            log.info("{}:File uploaded:{}", LG.USBLOGINFO, originalFilename);
            log.info("{}:s3 properties:eTag:{},ExpirationDateTime:{},versionId:{}", LG.USBLOGINFO, putObject.eTag(),
                    putObject.expiration(), putObject.versionId());
            return true;
        } else {
            log.info("{}:Error File not uploaded:{}", LG.USBLOGINFO, originalFilename);
            return false;
        }
    }

    public File upload(String bucketName, String name, byte[] content) throws Exception {

        //File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + name);
        File file = new File( config.getNetFileShare() + FileSystems.getDefault().getSeparator() + name);
        if (file.canWrite()) {
            log.debug("{}:file.canWrite()=true", LG.USBLOGINFO);
        }
        if (file.canRead()) {
            log.debug("{}:file.canRead()=true", LG.USBLOGINFO);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:Error:FileOutputStream(file).write(content):{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:FileOutputStream.write(content):stackTrace:", LG.USBLOGERROR, e);
        }

        return file;
    }

}
