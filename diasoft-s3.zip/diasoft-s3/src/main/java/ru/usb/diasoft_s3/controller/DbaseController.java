package ru.usb.diasoft_s3.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.diasoft_s3.configure.Config;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.service.db.DbService;

import java.util.Collections;
import java.util.List;

@Log4j2
@RestController
@RequestMapping("/api/db")
@Tag(name = "Контроллер Базы Данных. Для работы с таблицей БД Диасофт", description = "Просмотр таблицы.")
public class DbaseController {

    private final Config config;
    private final DbService dbService;

    public DbaseController(Config config, DbService dbService) {
        this.config = config;
        this.dbService = dbService;
    }

    @GetMapping("/get-count")
    @Operation(summary = "/get-count. Метод : получить общее число записей в таблице.")
    public int getAllCount() {
        log.info("{}: Метод : получить общее число записей в таблице.", TG.UsbLogInfo);
        int countAll = dbService.getCountRecord().orElse(0);
        log.info("{}: Общее число записей. Count:{}", TG.UsbLogInfo, countAll);
        return countAll;
    }

    @GetMapping("/get-error-count")
    @Operation(summary = "/get-error. Метод : получить число записей в таблице с ошибками.")
    public int getCountError() {
        log.info("{}: Метод : получить число записей в таблице с ошибками.", TG.UsbLogInfo);
        int countAll = dbService.getCountError().orElse(0);
        log.info("{}: Общее число записей с ошибками. Count:{}", TG.UsbLogInfo, countAll);
        return countAll;
    }

    @GetMapping("/get-count-name")
    @Operation(summary = "/get-count. Метод : получить общее число записей в таблице c определенным именем файла.")
    public int getCountName(@RequestParam(value = "Name") String name) {
        log.info("{}: Метод : получить общее число записей в таблице c определенным именем файла.", TG.UsbLogInfo);
        int countAll = dbService.getCountName(name).orElse(0);
        log.info("{}: Общее число записей c определенным именем файла. Count:{}", TG.UsbLogInfo, countAll);
        return countAll;
    }

    @GetMapping("/get-name")
    @Operation(summary = "/get-count. Метод : получить записи в таблице c определенным именем файла.")
    public ResponseEntity<List<String>> getName(@RequestParam(value = "Name") String name) {
        log.info("{}: Метод : получить записи в таблице c определенным именем файла.", TG.UsbLogInfo);
        try {
            List<String> recordList = dbService.getRecordName(name);
            if (recordList != null && !recordList.isEmpty()) {
                for (String s : recordList) {
                    log.info("{}: Запись в таблице c именем файла:{}", TG.UsbLogInfo, s);
                }
                return ResponseEntity.status(HttpStatus.OK).body(recordList);
            } else {
                log.info("{}: Нет записей в базе с именем файла::{}", TG.UsbLogInfo, name);
                return ResponseEntity.status(HttpStatus.OK).body(Collections.singletonList("Нет записей в базе с именем файла:" + name));
            }
        } catch (Exception e) {
            log.error("{}: Возникла ошибка при получении записей из базы:{}", TG.UsbLogError, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonList("Возникла ошибка при получении записей из базы:" + e.getMessage()));
        }
    }

    @GetMapping("/get-error")
    @Operation(summary = "/get-error. Метод : получить записи в таблице c определенным именем файла.")
    public ResponseEntity<List<String>> getError() {
        log.info("{}: Метод : получить записи в таблице c ошибками в статусе.", TG.UsbLogInfo);
        try {
            List<String> recordList = dbService.getRecordError();
            if (recordList != null && !recordList.isEmpty()) {
                for (String s : recordList) {
                    log.info("{}: Запись в таблице:{}", TG.UsbLogInfo, s);
                }
                return ResponseEntity.status(HttpStatus.OK).body(recordList);
            } else {
                log.info("{}: Нет записей в базе с ошибками в статусе", TG.UsbLogInfo);
                return ResponseEntity.status(HttpStatus.OK).body(Collections.singletonList("Нет записей в базе с ошибками в статусе"));
            }
        } catch (Exception e) {
            log.error("{}: Возникла ошибка при получении записей с ошибками в статусе из базы:{}", TG.UsbLogError, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonList("Возникла ошибка при получении записей из базы:" + e.getMessage()));
        }
    }
}
