package ru.usb.diasoft_s3.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Support {

    private final Logger logger = LoggerFactory.getLogger(Support.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }
}
