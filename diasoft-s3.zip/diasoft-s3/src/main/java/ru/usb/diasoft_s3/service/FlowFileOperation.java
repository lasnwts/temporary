package ru.usb.diasoft_s3.service;

import jcifs.smb.SmbFile;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.configure.Configure;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.model.S3Result;
import ru.usb.diasoft_s3.model.SmbFileDto;
import ru.usb.diasoft_s3.service.db.DbService;
import ru.usb.diasoft_s3.service.mail.ServiceMailError;
import ru.usb.diasoft_s3.service.s3.AmazonS3ServiceImpl;
import ru.usb.diasoft_s3.service.smb.InvalidFileException;
import ru.usb.diasoft_s3.service.smb.SmbService;
import ru.usb.diasoft_s3.utils.Sutils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class FlowFileOperation {

    private final Configure config;
    private final AmazonS3ServiceImpl s3Service;
    private final SmbService smbService;
    private final ServiceMailError serviceMailError;
    private final DbService dbLayer;
    private final Sutils sutils;

    public FlowFileOperation(Configure config, AmazonS3ServiceImpl s3Service, SmbService smbService, ServiceMailError serviceMailError, DbService dbLayer, Sutils sutils) {
        this.config = config;
        this.s3Service = s3Service;
        this.smbService = smbService;
        this.serviceMailError = serviceMailError;
        this.dbLayer = dbLayer;
        this.sutils = sutils;
    }

    public void start() {
        log.debug("{}: start processed...", TG.UsbLogInfo);
        smbService.getCifsConfig(); //Подключаемся...
        Optional<List<SmbFile>> smbFileList; //Готовим переменные
        //Получаем список файлов
        if (smbService.checkSmb()) {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl());
        } else {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl(), smbService.getCifsConfig());
        }
        if (smbFileList.isPresent()) {
            smbFileList.get().forEach(smbFile -> {
                log.info("Обработка файла: {}", smbFile.getName());
                try {
                    File file = smbService.copySmbFileToFile(smbFile, smbFile.getName());
                    log.info("{}: Файл:{} успешно скопирован во временную директорию", TG.UsbLogInfo, smbFile.getName());
                    log.info("{}: Загрузка файла:{} в бакет:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                    if (file != null) {
                        Optional<S3Result> s3Result = s3Service.uploadFile(config.getBucketBase(), smbFile.getName(), Files.readAllBytes(file.toPath()));
                        if (s3Result.isPresent()) {
                            log.info("{}:FileOperation.start().S3Result:{}", TG.UsbLogInfo, s3Result.get().toString());
                            //Заносим информацию в базу
                            if (dbLayer.checkRecord(smbFile.getName())) {
                                if (dbLayer.updateRec(s3Result.get()) > 0) {
                                    log.info("{}: Запись для файла с именем:{} обновлена в базе:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                } else {
                                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ обновлена в базе:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                }
                            } else {
                                if (dbLayer.insertFile(s3Result.get()) > 0) {
                                    log.info("{}: Запись для файла с именем:{} добавлена в базу:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                } else {
                                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ добавлена в базу:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                }
                            }
                            if (s3Result.get().isResult()) {
                                smbFileProcessed(smbFile, file); //
                            } else {
                                log.error("{}: Ошибка при загрузке файла: {} в бакет: {} описание ошибки: {}", TG.UsbLogError, smbFile.getName(), config.getBucketBase(), s3Result.get().getDescription());
                                log.warn("{}: Попытка копирования Файла:{} в директорию ERROR:{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileErr());
                                smbService.writeSmbFile(config.getSmbFileErr() + smbFile.getName(), Files.readAllBytes(file.toPath()), Thread.currentThread().getId());
                                smbService.delFile(file);
                                serviceMailError.sendMailError("Ошибка при загрузке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                                        "\r\n Описание ошибки:" + sutils.getWrapNull(s3Result.get().getRetText()));
                            }
                        }
                    } else {
                        log.error("{}: Файл:{} не был скопирован во временную директорию", TG.UsbLogError, smbFile.getName());
                    }
                } catch (InvalidFileException | IOException e) {
                    log.error("{}: Ошибка:{}", TG.UsbLogWarning, e.getMessage());
                    log.debug("{}: StackTrace:{}", TG.UsbLogWarning, e);
                }
            });
            log.debug("{}: stop processed...", TG.UsbLogInfo);
        }
    }

    /**
     * Обработка файла, помещение в архив
     *
     * @param smbFile - файл который надо поместить в архив
     * @param file    - файл который надо поместить в архив
     * @throws MalformedURLException - ошибка при копировании файла
     */
    private void smbFileProcessed(SmbFile smbFile, File file) throws MalformedURLException {
        SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileArc() + smbFile.getName()));
        if (smbFileDto == null) {
            log.error("{}: Файл:{} не был скопирован в архив:{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileArc() + smbFile.getName());
        } else {
            if (smbService.compareSmbFile(smbFile, smbFileDto.getFileDestination())) {
                smbService.deleteSmbFile(smbFile); //Удаляем файл из источника
            }
        }
        smbService.delFile(file); //Удаляем файл из временной директории
    }
}
