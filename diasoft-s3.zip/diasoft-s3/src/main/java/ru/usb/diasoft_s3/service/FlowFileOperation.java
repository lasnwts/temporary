package ru.usb.diasoft_s3.service;

import io.minio.ObjectWriteResponse;
import jcifs.smb.SmbFile;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.configure.Config;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.model.S3Result;
import ru.usb.diasoft_s3.model.SmbFileDto;
import ru.usb.diasoft_s3.service.db.DbService;
import ru.usb.diasoft_s3.service.mail.ServiceMailError;
import ru.usb.diasoft_s3.service.s3.MinioService;
import ru.usb.diasoft_s3.service.smb.InvalidFileException;
import ru.usb.diasoft_s3.service.smb.SmbService;
import ru.usb.diasoft_s3.utils.Sutils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class FlowFileOperation {

    private final Config config;
    private final SmbService smbService;
    private final ServiceMailError serviceMailError;
    private final DbService dbLayer;
    private final Sutils sutils;
    private final MinioService minioService;

    public FlowFileOperation(Config config, SmbService smbService,
                             ServiceMailError serviceMailError, DbService dbLayer,
                             Sutils sutils, MinioService minioService) {
        this.config = config;
        this.smbService = smbService;
        this.serviceMailError = serviceMailError;
        this.dbLayer = dbLayer;
        this.sutils = sutils;
        this.minioService = minioService;
    }

    public void start() {
        log.debug("{}: start processed...", TG.UsbLogInfo);
        smbService.getCifsConfig(); //Подключаемся...
        Optional<List<SmbFile>> smbFileList; //Готовим переменные
        //Получаем список файлов
        if (smbService.checkSmb()) {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl());
        } else {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl(), smbService.getCifsConfig());
        }
        if (smbFileList.isPresent()) {
            smbFileList.get().forEach(smbFile -> {
                try {
                    if (smbFile.isFile()) {
                        log.info("Обработка файла: {}", smbFile.getName());
                        File file = smbService.copySmbFileToFile(smbFile, smbFile.getName());
                        log.info("{}: Файл:{} успешно скопирован во временную директорию", TG.UsbLogInfo, smbFile.getName());
                        log.info("{}: Подготовка к загрузке файла:{} в бакет:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                        if (file != null) {
                            ObjectWriteResponse objectWriteResponse = minioService.uploadFile(smbFile.getName(), Files.readAllBytes(file.toPath()), config.getBucketBase());
                            if (objectWriteResponse != null && objectWriteResponse.etag() != null) {
                                log.info("{}:FileOperation.start().objectWriteResponse.eTag:{}", TG.UsbLogInfo, objectWriteResponse.etag());
                                S3Result s3Result = new S3Result(objectWriteResponse.etag(), true, "");
                                s3Result.setName(smbFile.getName());
                                s3Result.setShortRef(minioService.getFileLink(config.getBucketBase(), smbFile.getName(), config.getHostS3()));
                                s3Result.setKey(config.getBucketBase() + "/" + smbFile.getName());
                                s3Result.setStatus("");
                                s3Result.setDocId(objectWriteResponse.etag());
                                s3Result.setRetText("");
                                s3Result.setLongRef(minioService.getPresignedUrl(smbFile.getName(), config.getBucketBase()));
                                //Перенос файлов в архив, запись в базу
                                saveToDbase(smbFileProcessed(smbFile, s3Result));
                                if (s3Result.isResult()) {
                                    log.info("{}: Обработка файла завершена", TG.UsbLogInfo);
                                } else {
                                    log.error("{}: Ошибка при обработке файла: {} в бакет: {} описание ошибки: {}", TG.UsbLogError, smbFile.getName(), config.getBucketBase(), s3Result.getDescription());
                                    log.warn("{}: Попытка копирования Файла:{} в директорию ERROR:{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileErr());
                                    smbService.writeSmbFile(config.getSmbFileErr() + smbFile.getName(), Files.readAllBytes(file.toPath()), Thread.currentThread().getId());
                                    if (smbService.checkFileSmbExists(config.getSmbFileArc() + smbFile.getName())) {
                                        smbService.deleteSmbFile(new SmbFile(config.getSmbFileArc() + smbFile.getName(), smbFile.getContext()));
                                    }
                                    serviceMailError.sendMailError("Ошибка при загрузке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                                            "\r\n Описание ошибки:" + sutils.getWrapNull(s3Result.getRetText()));
                                }
                                smbService.delFile(file); //Удаляем файл из временной директории
                            }
                        } else {
                            S3Result s3Result = new S3Result("", false, "Файл не был скопирован во временную директорию и хранилище s3");
                            s3Result.setName(smbFile.getName());
                            s3Result.setStatus("E");
                            s3Result.setResult(false);
                            s3Result.setRetText("Произошла ошибка при попытке копирования файла в S3 и во временную директорию.");
                            //Заносим информацию в базу
                            saveToDbase(s3Result);
                            log.error("{}: Файл:{} не был скопирован во временную директорию", TG.UsbLogError, smbFile.getName());
                            serviceMailError.sendMailError("Ошибка при обработке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                                    "\r\n Описание ошибки:" + sutils.getWrapNull(s3Result.getRetText()));
                        }
                    }
                } catch (InvalidFileException | IOException e) {
                    log.error("{}:[InvalidFileException/IOException]Возникла проблема при обработке файла:{} Ошибка:{}", TG.UsbLogWarning, smbFile.getName(), e.getMessage());
                    log.debug("{}: StackTrace:{}", TG.UsbLogWarning, e);
                    serviceMailError.sendMailError("Ошибка при загрузке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                            "\r\n Описание ошибки [InvalidFileException | IOException] :" + sutils.getWrapNull(e.getMessage()));
                } catch (Exception e) {
                    log.error("{}:[Exception], возникла проблема при обработке файла:{} Ошибка:{}", TG.UsbLogWarning, smbFile.getName(), e.getMessage());
                    log.debug("{}:Exception, StackTrace:{}", TG.UsbLogWarning, e);
                    serviceMailError.sendMailError("Ошибка при загрузке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                            "\r\n Описание ошибки:" + sutils.getWrapNull(e.getMessage()));
                }
                if (Files.exists(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + smbFile.getName()))) {
                    try {
                        Files.delete(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/tmp/" + smbFile.getName()));
                    } catch (IOException e) {
                        log.error("{}: Ошибка при удалении файла:{} из временной директории", TG.UsbLogError, smbFile.getName());
                    }
                }
            });
            log.debug("{}: stop processed...", TG.UsbLogInfo);
        }
    }

    /**
     * Обработка файла, помещение в архив
     *
     * @param smbFile - файл который надо поместить в архив
     * @throws MalformedURLException - ошибка при копировании файла
     */
    private S3Result smbFileProcessed(SmbFile smbFile, S3Result s3Result) throws IOException {
        if (smbFile == null || !s3Result.isResult()) {
            s3Result.setRetText(s3Result.getRetText() + " Файл не был скопирован в архив");
            s3Result.setStatus("E");
            return s3Result;
        }
        SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileArc() + smbFile.getName(), smbService.getCifsConfig()));
        if (smbFileDto == null) {
            log.error("{}: Файл:{} не был скопирован в :{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileArc() + smbFile.getName());
            s3Result.setRetText("Файл:" + smbFile.getName() + " не был скопирован в " + config.getSmbFileArc() + smbFile.getName());
            s3Result.setStatus("E");
        } else {
            if (smbService.compareSmbFile(smbFile, smbFileDto.getFileDestination())) {
                //Удаляем файл из источника
                if (smbService.deleteSmbFile(smbFile)) {
                    s3Result.setRetText("");
                    s3Result.setStatus("Y");
                    s3Result.setResult(true);
                } else {
                    s3Result.setRetText("Возникла ошибка удаления файла " + smbFile.getUncPath());
                    s3Result.setStatus("E");
                    s3Result.setResult(false);
                }
            } else {
                s3Result.setRetText("Возникла ошибка копирования файла " + smbFile.getName() + " в каталог:" + config.getSmbFileArc() + smbFile.getName() + " Не совпадает размер файла!");
                s3Result.setStatus("E");
                s3Result.setResult(false);
            }
        }
        return s3Result;
    }

    /**
     * Сохраняем в базу данных информацию
     *
     * @param s3Result - результат копирования
     */
    private void saveToDbase(S3Result s3Result) {
        if (!s3Result.isResult()) {
            log.error("{}: Возникла ошибка при сохранении информации в базу данных о файле:{}, описание ошибки:{}", TG.UsbLogError, s3Result.getName(), s3Result.getRetText());
            return;
        }
        try {
            if (dbLayer.checkRecord(s3Result.getName())) {
                if (dbLayer.updateRec(s3Result).isResult()) {
                    log.info("{}: Запись для файла с именем:{} обновлена в базе:{}", TG.UsbLogInfo, s3Result.getName(), config.getBucketBase());
                } else {
                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ обновлена в базе:{}", TG.UsbLogInfo, s3Result.getName(), config.getBucketBase());
                }
            } else {
                if (dbLayer.insertFile(s3Result).isResult()) {
                    log.info("{}: Запись для файла с именем:{} добавлена в базу:{}", TG.UsbLogInfo, s3Result.getName(), config.getBucketBase());
                } else {
                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ добавлена в базу:{}", TG.UsbLogInfo, s3Result.getName(), config.getBucketBase());
                }
            }
        } catch (Exception e) {
            log.error("{}: Возникла ошибка при сохранения информации в базу данных о файле:{}, описание ошибки:{}", TG.UsbLogError, s3Result.getName(), e.getMessage());
            log.debug("{}: StackTrace:", TG.UsbLogError, e);
            s3Result.setStatus("E");
            s3Result.setResult(false);
            s3Result.setRetText("Ошибка:" + sutils.getWrapNull(e.getMessage()));
        }
    }

}
