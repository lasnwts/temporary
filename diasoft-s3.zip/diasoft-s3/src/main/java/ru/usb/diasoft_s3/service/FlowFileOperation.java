package ru.usb.diasoft_s3.service;

import io.minio.ObjectWriteResponse;
import jcifs.smb.SmbFile;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.diasoft_s3.configure.Config;
import ru.usb.diasoft_s3.configure.TG;
import ru.usb.diasoft_s3.model.S3Result;
import ru.usb.diasoft_s3.model.SmbFileDto;
import ru.usb.diasoft_s3.service.db.DbService;
import ru.usb.diasoft_s3.service.mail.ServiceMailError;
import ru.usb.diasoft_s3.service.s3.MinioService;
import ru.usb.diasoft_s3.service.smb.InvalidFileException;
import ru.usb.diasoft_s3.service.smb.SmbService;
import ru.usb.diasoft_s3.utils.Sutils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class FlowFileOperation {

    private final Config config;
    private final SmbService smbService;
    private final ServiceMailError serviceMailError;
    private final DbService dbLayer;
    private final Sutils sutils;
    private final MinioService minioService;

    public FlowFileOperation(Config config, SmbService smbService,
                             ServiceMailError serviceMailError, DbService dbLayer,
                             Sutils sutils, MinioService minioService) {
        this.config = config;
        this.smbService = smbService;
        this.serviceMailError = serviceMailError;
        this.dbLayer = dbLayer;
        this.sutils = sutils;
        this.minioService = minioService;
    }

    public void start() {
        log.debug("{}: start processed...", TG.UsbLogInfo);
        smbService.getCifsConfig(); //Подключаемся...
        Optional<List<SmbFile>> smbFileList; //Готовим переменные
        //Получаем список файлов
        if (smbService.checkSmb()) {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl());
        } else {
            smbFileList = smbService.getSmbFileList(config.getSmbFileUrl(), smbService.getCifsConfig());
        }
        if (smbFileList.isPresent()) {
            smbFileList.get().forEach(smbFile -> {
                log.info("Обработка файла: {}", smbFile.getName());
                try {
                    File file = smbService.copySmbFileToFile(smbFile, smbFile.getName());
                    log.info("{}: Файл:{} успешно скопирован во временную директорию", TG.UsbLogInfo, smbFile.getName());
                    log.info("{}: Загрузка файла:{} в бакет:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                    if (file != null) {
                        ObjectWriteResponse objectWriteResponse = minioService.uploadFile(smbFile.getName(), Files.readAllBytes(file.toPath()), config.getBucketBase());
                        if (objectWriteResponse != null && objectWriteResponse.etag() != null) {
                            log.info("{}:FileOperation.start().objectWriteResponse.eTag:{}", TG.UsbLogInfo, objectWriteResponse.etag());
                            S3Result s3Result = new S3Result(objectWriteResponse.etag(), true, "");
                            s3Result.setName(smbFile.getName());
                            s3Result.setShortRef(minioService.getFileLink(config.getBucketBase(), smbFile.getName(), config.getHostS3()));
                            s3Result.setKey(config.getBucketBase() + "/" + smbFile.getName());
                            s3Result.setStatus("Y");
                            s3Result.setDocId(objectWriteResponse.etag());
                            s3Result.setRetText("");
                            s3Result.setLongRef(minioService.getPresignedUrl(smbFile.getName(), config.getBucketBase()));
                            //Заносим информацию в базу
                            if (dbLayer.checkRecord(smbFile.getName())) {
                                if (dbLayer.updateRec(s3Result) > 0) {
                                    log.info("{}: Запись для файла с именем:{} обновлена в базе:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                } else {
                                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ обновлена в базе:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                }
                            } else {
                                if (dbLayer.insertFile(s3Result) > 0) {
                                    log.info("{}: Запись для файла с именем:{} добавлена в базу:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                } else {
                                    log.error("{}: Возникла ошибка! Запись для файла с именем:{} НЕ добавлена в базу:{}", TG.UsbLogInfo, smbFile.getName(), config.getBucketBase());
                                }
                            }
                            if (s3Result.isResult()) {
                                smbFileProcessed(smbFile, file); //
                            } else {
                                log.error("{}: Ошибка при загрузке файла: {} в бакет: {} описание ошибки: {}", TG.UsbLogError, smbFile.getName(), config.getBucketBase(), s3Result.getDescription());
                                log.warn("{}: Попытка копирования Файла:{} в директорию ERROR:{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileErr());
                                smbService.writeSmbFile(config.getSmbFileErr() + smbFile.getName(), Files.readAllBytes(file.toPath()), Thread.currentThread().getId());
                                smbService.delFile(file);
                                serviceMailError.sendMailError("Ошибка при загрузке файла:" + sutils.getWrapNull(smbFile.getName()) + "\n\r" +
                                        "\r\n Описание ошибки:" + sutils.getWrapNull(s3Result.getRetText()));
                            }
                        }
                    } else {
                        log.error("{}: Файл:{} не был скопирован во временную директорию", TG.UsbLogError, smbFile.getName());
                    }
                } catch (InvalidFileException | IOException e) {
                    log.error("{}: Ошибка:{}", TG.UsbLogWarning, e.getMessage());
                    log.debug("{}: StackTrace:{}", TG.UsbLogWarning, e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            log.debug("{}: stop processed...", TG.UsbLogInfo);
        }
    }

    /**
     * Обработка файла, помещение в архив
     *
     * @param smbFile - файл который надо поместить в архив
     * @param file    - файл который надо поместить в архив
     * @throws MalformedURLException - ошибка при копировании файла
     */
    private void smbFileProcessed(SmbFile smbFile, File file) throws MalformedURLException {
        SmbFileDto smbFileDto = smbService.copySmbFile(smbFile, new SmbFile(config.getSmbFileArc() + smbFile.getName()));
        if (smbFileDto == null) {
            log.error("{}: Файл:{} не был скопирован в архив:{}", TG.UsbLogError, smbFile.getName(), config.getSmbFileArc() + smbFile.getName());
        } else {
            if (smbService.compareSmbFile(smbFile, smbFileDto.getFileDestination())) {
                smbService.deleteSmbFile(smbFile); //Удаляем файл из источника
            }
        }
        smbService.delFile(file); //Удаляем файл из временной директории
    }

}
