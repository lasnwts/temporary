package ru.usb.diasoft_s3.configure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

/**
 * @author Petr Vershinin.
 * create on 15.11.2022
 *
 * Класс регистрирует свойства для получения подключения к БД из файла application.properties.
 */
@Configuration
public class DataSourceConfig {

    /**
     * Создает новый экземпляр DataSourceBuilder.
     * Spring автоматически свяжет любое свойство, определенное в вашем файле свойств,которое имеет префикс app.datasource.cft .
     * @return -Возвращает экземпляр источника данных.
     */
    @Bean(name = "datasource")
    @Primary
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource datasource() {
        return DataSourceBuilder.create().build();
    }


}
