package ru.usb.diasoft_s3.service.smb;


/**
 * Ошибка при загрузке файла
 */
public class InvalidFileException extends Exception{
    public InvalidFileException(String message) {
        super(message);
    }
}
