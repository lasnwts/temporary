package ru.usb.zsk945028.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.zsk945028.configs.Configure;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/out")
@Api(value = "user", description = "Контроллер по REST API к сервису ЗСК ЦБ РФ и получить файл с данными по уровню рисков ЮЛ/ИП.", tags = "Rest API (Исходящие файлы)")
public class RestControllerOut {

    @Autowired
    Configure configure;

    Logger logger = LoggerFactory.getLogger(RestControllerOut.class);

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
        if (configure.getVersion() == null) {
            logger.error("get /version :: Request get version, but version not defibed in application.properties");
            return "version not defined";
        }
        logger.error("get /version :: Request get version, " + configure.getVersion());
        return (configure.getVersion());
    }



}
