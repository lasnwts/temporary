package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

@Service
public class GetFiles {
    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetFiles.class);

    String url;


    /**
     * Получение файла с сайта банка ЦБ
     * Поток «KYC» предназначен для передачи электронных сообщений (далее – ЭС)
     *
     * @param messageId - конкретный Id сообщения
     * @param fileId    - Id файла
     * @return - файл с сайта
     */
    public File GetFile(String messageId, String fileId) {
        // File address to be downloaded
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));
        headers.add("user-agent", "Mozilla/5.0 Firefox/26.0");

        //https://portal5.cbr.ru/back/rapi2
        // create request
        HttpEntity request2 = new HttpEntity(headers);

        // create url
        //test url
        //url = "https://portal5.cbr.ru/back/rapi2/messages/df22462d-a599-4018-92a1-ae92010bf27b/files/0faa22a8-b1c4-4e5b-a150-c23b57591f4f/download";
        url = configure.getZskBaseurl() + "/messages/" + messageId + "/files/" + fileId + "/download";

        logger.info("GetFile:Prepared:Url:" + url);

        // Определяем тип получения заголовка запроса
        RequestCallback requestCallback = request -> request.getHeaders().putAll(headers);


        //Stream the response instead of loading it all into memory
        File file = restTemplate.execute(url, HttpMethod.GET, requestCallback, clientHttpResponse -> {
            Files.copy(clientHttpResponse.getBody(), Paths.get(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + clientHttpResponse.getHeaders().getContentDisposition().getFilename()),
                    StandardCopyOption.REPLACE_EXISTING);
            File f = new File(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + clientHttpResponse.getHeaders().getContentDisposition().getFilename());
            if (f.exists()) {
                return f;
            } else {
                return null;
            }
        });
        logger.info("File download from portal:File Name:: " + file.getName() + "; File(size):: " + file.length());
        return file;
    }


}
