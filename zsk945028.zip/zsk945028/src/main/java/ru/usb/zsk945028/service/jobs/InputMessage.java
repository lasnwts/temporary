package ru.usb.zsk945028.service.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Zadacha130;
import ru.usb.zsk945028.model.Zadacha130File;
import ru.usb.zsk945028.service.GetFiles;
import ru.usb.zsk945028.service.GetZadacha130;
import ru.usb.zsk945028.utils.ParseDate;
import ru.usb.zsk945028.utils.WorkWithFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Прием сообщений из ЦБ
 * Job1
 * 1. Запрос в БД ЦБ для получения списка сообщений
 * Запрос (новые или все определяется в application.properties)
 * 2. Получаем List всех сообщений
 * 3. В цикле скачиваем по одному enc и sig во временную папку
 * 4. Переносим эти файлы в папку для расшифрования СКЗИ
 * Job2
 * 1. Сканирует папку расшифрованных и если там, что-то появилось обрабатываем
 * 2. Разархивируем в папку transform enc
 * 3. Переносим разархивированные файл в папку загрузки IN в ЦХД
 * 4. Удаляем файлы из папки расшифровки
 */

@Service
public class InputMessage {

    @Autowired
    Configure configure;

    @Autowired
    GetZadacha130 getZadacha130;

    @Autowired
    WorkWithFiles workWithFiles;

    @Autowired
    GetFiles getFiles;

    @Autowired
    ParseDate parseDate;

    Logger logger = LoggerFactory.getLogger(InputMessage.class);

    private String inputUnzipDirectory = "inputunzip";

    /**
     * Метод получения файлов по Задаче 130
     */
    public void inputMessageService() {

        /**
         * Список задач 130
         */
        List<Zadacha130> zadacha130 = new ArrayList<>();

        /**
         * Получаем список задач
         */
        if (configure.getKycTypeInput().equals("new")) {
            zadacha130 = getZadacha130.getZadacha130new();
        } else {
            if (configure.getKycTypeInput().equals("week")) {
                zadacha130 = getZadacha130.getZadacha130minDate(parseDate.getWeekMinDateToRequest());
            } else {
                if (configure.getKycTypeInput().equals("month")) {
                    zadacha130 = getZadacha130.getZadacha130minDate(parseDate.getMonthMinDateToRequest());
                } else {
                    logger.error("!ERROR!:task list not received! In application.properties point needs to be defined:kyc.type.input=new OR all");
                }
            }
        }
        /**
         * Выведем список задач
         */
        if (zadacha130.size() != 0) {
            logger.info("display a list of tasks Zadacha130.");
            zadacha130.forEach(new Consumer<Zadacha130>() {
                @Override
                public void accept(Zadacha130 zadacha130_1) {
                    logger.info(" " + zadacha130_1.toString());
                    zadacha130_1.getFiles().forEach(new Consumer<Zadacha130File>() {
                        @Override
                        public void accept(Zadacha130File zadacha130File) {
                            logger.info("    " + zadacha130File.toString());
                            downloadFile(zadacha130_1.getId(), zadacha130File.getId());
                        }
                    });
                }
            });
        }


    }

    /**
     * Загрузка файлов
     *
     * @param messageId - Id сообщения
     * @param fileId    - Id файла
     */
    private void downloadFile(String messageId, String fileId) {
        File file = getFiles.GetFile(messageId, fileId);
        workWithFiles.moveFileSName(file.getAbsolutePath(), configure.getCryptoFromCB() + FileSystems.getDefault().getSeparator() + file.getName());
    }


    /**
     * Перенос файлов из каталога с расшифрованными файлами в каталог ПО загрузки
     */
    public void moveFileAfterDecrypt() {
        List<File> files = workWithFiles.getDirList(configure.getDecryptoFromCBb());
        if (files.size() > 0) {
            try {
                if (workWithFiles.checkPathExists(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + inputUnzipDirectory)) {
                    Files.createDirectories(Paths.get(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + inputUnzipDirectory));
                }
                files.forEach(new Consumer<File>() {
                    @Override
                    public void accept(File file) {
                        try {
                            workWithFiles.UnzipFile(file.getAbsolutePath(),
                                    configure.getTmpPath() + FileSystems.getDefault().getSeparator() + inputUnzipDirectory);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });

            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        /**
         * Сканирование каталога распакованных файлов
         * //getKycObmenBRkycIn
         */
        List<String> groupUnzipFiles = workWithFiles.getDirListRecursive(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + inputUnzipDirectory);
        if (groupUnzipFiles.size() > 0) {
            logger.info("groupUnzipFiles:size::" + groupUnzipFiles.size());
            groupUnzipFiles.forEach(new Consumer<String>() {
                @Override
                public void accept(String s) {
                    logger.info("groupUnzipFiles:file::" + s.toString());
                    File unzipFile = new File(s.toString());
                    workWithFiles.moveFileSName(s.toString(), configure.getKycObmenBRkycIn() + FileSystems.getDefault().getSeparator() + unzipFile.getName());
                }
            });
        }
    }

}
