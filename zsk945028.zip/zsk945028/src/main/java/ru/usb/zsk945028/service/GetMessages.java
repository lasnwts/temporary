package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/**
 * Класс получения теля сообщения
 */
@Service
public class GetMessages {
    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetMessages.class);

    String url;

    /**
     *  Получение файла содержащего архив сообщения
     * @param messageId - ID сообщения
     * @return - файл с архивом сообщения
     */
    public File GetMessage(String messageId) {

        //https://portal5.cbr.ru/back/rapi2/messages/df22462d-a599-4018-92a1-ae92010bf27b/download
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));
        headers.add("user-agent", "Mozilla/5.0 Firefox/26.0");

        //https://portal5.cbr.ru/back/rapi2
        HttpEntity request2 = new HttpEntity(headers);
        url = configure.getZskBaseurl() + "/messages/" + messageId + "/download";

        logger.info("GetMessage:Prepared:Url:" + url);

        // Определяем тип получения заголовка запроса
        RequestCallback requestCallback = request -> request.getHeaders().putAll(headers);


        //Stream the response instead of loading it all into memory
        File file = restTemplate.execute(url, HttpMethod.GET, requestCallback, clientHttpResponse -> {
            Files.copy(clientHttpResponse.getBody(), Paths.get(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + clientHttpResponse.getHeaders().getContentDisposition().getFilename()),
                    StandardCopyOption.REPLACE_EXISTING);
            File f = new File(configure.getTmpPath() + FileSystems.getDefault().getSeparator() + clientHttpResponse.getHeaders().getContentDisposition().getFilename());
            if (f.exists()) {
                return f;
            } else {
                return null;
            }
        });
        logger.info("Message download from portal:File Name:: " + file.getName() + "; File(size):: " + file.length());
        return file;
    }
}
