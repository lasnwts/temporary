package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Zadacha130;

@Service
public class GetMetaFromMessage {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetFiles.class);

    String url;

    public Zadacha130 GetMetaFromFile(String messageId) {

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        url = configure.getZskBaseurl() + "/messages/" + messageId;

        logger.info("GetFile:Prepared:Url:" + url);

        ResponseEntity<Zadacha130> response = restTemplate.exchange(url, HttpMethod.GET, request, Zadacha130.class);
        Zadacha130 zadacha130 = response.getBody();

        logger.info("GetMetaFrom Message:GET META from messageID=" + messageId + " ::" + zadacha130.toString());

        return zadacha130;
    }

}
