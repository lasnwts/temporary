package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Zadacha130File;

/**
 *  Класс получения мета информации о файле
 */
@Service
public class GetMetaFromFile {
    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetFiles.class);

    String url;

    /**
     *  Получение информации о файле
     * @param messageId - Id сообщения (Message)
     * @param fileId - Id файла (File)
     * @return - Zadacha130File Класс с описанием
     */
    public Zadacha130File GetMetaFromFile(String messageId, String fileId) {

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        url = configure.getZskBaseurl() + "/messages/" + messageId + "/files/" + fileId;

        logger.info("GetFile:Prepared:Url:" + url);

        ResponseEntity<Zadacha130File> response = restTemplate.exchange(url, HttpMethod.GET, request, Zadacha130File.class);
        Zadacha130File zadacha130Files = response.getBody();

        logger.info("GetMetaFromFile:GET META from File::" + zadacha130Files.toString());

        return zadacha130Files;
    }
}
