package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

@ApiModel(value = "Zadacha77FileSig", description = "Получить параметры всех файлов")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha77FileSig {

    @JsonProperty("Name")
    public String name;

    @JsonProperty("Encrypted")
    public String encrypted;

    @JsonProperty("SignedFile")
    public String signedFile;

    @JsonProperty("RepositoryType")
    public String repositoryType;

    @JsonProperty("Size")
    public long size;

    public Zadacha77FileSig() {
    }

    public Zadacha77FileSig(String name, String encrypted, String signedFile, String repositoryType, long size) {
        this.name = name;
        this.encrypted = encrypted;
        this.signedFile = signedFile;
        this.repositoryType = repositoryType;
        this.size = size;
    }

    @Override
    public String toString() {
        return "Zadacha77FileSig{" +
                "name='" + name + '\'' +
                ", encrypted=" + encrypted +
                ", signedFile=" + signedFile +
                ", repositoryType='" + repositoryType + '\'' +
                ", size=" + size +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEncrypted() {
        return encrypted;
    }

    public void setEncrypted(String encrypted) {
        this.encrypted = encrypted;
    }

    public String getSignedFile() {
        return signedFile;
    }

    public void setSignedFile(String signedFile) {
        this.signedFile = signedFile;
    }

    public String getRepositoryType() {
        return repositoryType;
    }

    public void setRepositoryType(String repositoryType) {
        this.repositoryType = repositoryType;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }
}
