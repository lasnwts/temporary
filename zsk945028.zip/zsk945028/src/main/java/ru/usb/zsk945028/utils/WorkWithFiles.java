package ru.usb.zsk945028.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Вспомогательный класс с файловыми утилитами
 */
@Component
public class WorkWithFiles {

    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * Перенос файлов, представленных подготовленными объектами Paths(nio)
     *
     * @param from откуда
     * @param to   куда
     */
    public void moveFiles(Path from, Path to) {
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toString())) {
                Files.deleteIfExists(from);
                logger.info("file:: " + from + " moved to:" + to);
            } else {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("Error for operation move:: file:: " + from + " moved to:" + to);
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
        }
    }

    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param toFile   - куда (полный путь с именем)
     */
    public void moveFileSName(String fromFile, String toFile) {
        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile);
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toString())) {
                Files.deleteIfExists(from);
                logger.info("file:: " + from + " moved to:" + to);
            } else {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("Error for operation move:: file:: " + from + " moved to:" + to);
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
        }
    }

    /**
     * Получение из строкового имени файла, тип File io
     *
     * @param fileName - строка с именем файла и полным путем
     * @return - объект File
     */
    public File ConvertStringToFiles(String fileName) {
        if (checkFileExists(fileName)) {
            return new File(fileName);

        } else {
            logger.error("Error!ConvertStringToFiles, file: " + fileName + " not exists!!");
            return null;
        }
    }

    /**
     * Метод Возвращает строгку Content-range нужного формата
     * Пример:Content-Range: bytes 0-3207/3208
     *
     * @param file - Файл типа File io
     * @return - строка нужного формата типа range
     */
    public String getRabgeFromFile(File file) {
        logger.info("Range from file:" + file.getAbsolutePath());
        long range = file.length() - 1;
        logger.info("Content-Range: bytes 0-" + range + "/" + file.length());
        return "Content-Range: bytes 0-" + range + "/" + file.length();
    }

    /**
     * Копирование файлов, представленных подготовленными объектами Paths(nio)
     *
     * @param from откуда
     * @param to   куда
     */
    public void copyFiles(Path from, Path to) {
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            logger.info("file:: " + from + " copied to:" + to);
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
        }
    }


    /**
     * Копирование файлов, представленных строковыми именами
     *
     * @param fromFile -    имя файла (полное) откуда копировать
     * @param toFile   -   имя файла куда копировать
     */
    public void copyFilesSName(String fromFile, String toFile) {
        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile);
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            logger.info("file:: " + from + " copied to:" + to);
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
        }
    }


    /**
     * Удаление файла, представленных подготовленными объектами Paths(nio)
     *
     * @param from что удалить
     */
    public void delFiles(Path from) {
        try {
            Files.deleteIfExists(from);
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
        }
    }

    /**
     * Удаление файла, представленных  строковым именем
     *
     * @param fromFile - полное имя файла, который надо удалить
     */
    public boolean delFilesSName(String fromFile) {
        Path from = Paths.get(fromFile);
        try {
            Files.deleteIfExists(from);
            return true;
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return false;
        }
    }


    /**
     * Упаковка единичного файла, ZIP
     *
     * @param fileTozip Имя файла, который надо упаковать в ZIP
     * @param zipFile   Имя файла архива
     * @return Имя файла архива
     * @throws IOException
     */
    public void ZipFile(String fileTozip, String zipFile) throws IOException {
        logger.info("ZipFile :: fileTozip file:" + fileTozip + " zipFile:" + zipFile);
        FileOutputStream fos = new FileOutputStream(zipFile);
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        File fileToZip = new File(fileTozip);
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        zipOut.close();
        fis.close();
        fos.close();
    }


    /**
     * Метод распаковки архива ZIP
     *
     * @param fileZip       - файл который надо распаковать (полный путь с именем)
     * @param directoryName - директории (сетевой каталог) куда будет распакован файл архива
     * @throws IOException
     */
    public void UnzipFile(String fileZip, String directoryName) throws IOException {
        logger.info("UnzipFile :: Zip file:" + fileZip + " directory target:" + directoryName);
        File destDir = new File(directoryName);
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            File newFile = newFile(destDir, zipEntry);
            if (zipEntry.isDirectory()) {
                if (!newFile.isDirectory() && !newFile.mkdirs()) {
                    throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + newFile);
                }
            } else {
                // fix for Windows-created archives
                File parent = newFile.getParentFile();
                if (!parent.isDirectory() && !parent.mkdirs()) {
                    throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + parent);
                }
                // write file content
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }

    /**
     * Вспомогательный класс.
     * Этот метод защищает от записи файлов в файловую систему вне целевой папки. Эта уязвимость называется Zip Slip,
     * почитать об этой уязвимости https://snyk.io/research/zip-slip-vulnerability
     *
     * @param destinationDir - Файл архива, с полным именем
     * @param zipEntry       - каталог (сетевая папка) куда будет распакован архив
     * @return
     * @throws IOException
     */
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }

        return destFile;
    }

    //Проверка наличия файла или каталога

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            logger.info("Directory :: [" + targetPath + "] exist.Ok.");
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameShort - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameShort) {
        Path path = Paths.get(fileNameShort);
        if (Files.exists(path)) {
            // действия, если файл существует
            logger.info("File :: [" + fileNameShort + "] exist.Ok.");
            return true;
        }
        logger.info("File :: [" + fileNameShort + "] not Exist.Fail!");
        return false;
    }

    /**
     * Упаковка шруппы файлов в один
     *
     * @param srcFiles - список файлов на упаковку,
     * @param zipFile  - имя файла zip
     * @throws IOException
     */
    public void ZipMultipleFiles(List<String> srcFiles, String zipFile) throws IOException {
        FileOutputStream fos = new FileOutputStream(zipFile);
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        for (String srcFile : srcFiles) {
            File fileToZip = new File(srcFile);
            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        fos.close();
    }


    /**
     * Получаем список файлов в директории
     *
     * @param directory
     * @return
     */
    public List<File> getDirList(String directory) {

        if (!checkPathExists(directory)) {
            logger.error("WorkWithFiles:GetDirListFiles::Error! Directory not exists! ::" + directory);
            return null;
        }

        // Reading only files in the directory
        try {
            List<File> files = Files.list(Paths.get(directory))
                    .map(Path::toFile)
                    .filter(File::isFile)
                    .collect(Collectors.toList());
            files.forEach(System.out::println);
            return files;
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }

    }

    /**
     * Получение рекурсивно всех файлов в директории
     * URL=https://mkyong.com/java/java-how-to-list-all-files-in-a-directory/
     * List all files.
     *
     * @param path - путь к корневой директории
     * @return - List<String> список файлов
     */
    public List<String> getDirListRecursive(String path) {

        if (!checkPathExists(path)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::" + path);
            return null;
        }

        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(path))) {

            result = walk.filter(Files::isRegularFile)
                    .map(x -> x.toString()).collect(Collectors.toList());

            result.forEach(System.out::println);

        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }

    /**
     * Возвращает список каталогов
     * List all folders.
     * URL=https://mkyong.com/java/java-how-to-list-all-files-in-a-directory/
     *
     * @param pathRoot - корневой каталог, с которого начинается просмотр
     * @return - список строковых ссылок на катлоги
     */
    public List<String> getDirectory(String pathRoot) {

        if (!checkPathExists(pathRoot)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::" + pathRoot);
            return null;
        }

        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(pathRoot))) {

            result = walk.filter(Files::isDirectory)
                    .map(x -> x.toString()).collect(Collectors.toList());

            result.forEach(System.out::println);

        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }


    /**
     * Возвращает список файлов в директории по расширению
     *
     * @param path      - корневая директория
     * @param extension - расширение
     * @return - список файлов
     */
    public List<String> getDirFileWithExt(String path, String extension) {

        if (!checkPathExists(path)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::" + path);
            return null;
        }

        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(path))) {
            result = walk.map(x -> x.toString())
                    .filter(f -> f.endsWith(extension)).collect(Collectors.toList());
            result.forEach(System.out::println);
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }


    /**
     * Поиск списка файлов в директории по части имени файла или целиком по имени
     *
     * @param path         - корневая директория для поиска     *
     * @param partFilename - часть имени файла или файл целиком
     * @return - список файлов
     */
    public List<String> getDirFileForMask(String path, String partFilename) {

        if (!checkPathExists(path)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::" + path);
            return null;
        }

        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(path))) {
            result = walk.map(x -> x.toString())
                    .filter(f -> f.contains(partFilename))
                    .collect(Collectors.toList());
            result.forEach(System.out::println);
        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }


    /**
     * Возвращает EXT расширение если имя файла представлено строкой
     *
     * @param fileName - строковое имя файла
     * @return - расширение
     */
    public String getExtensionFromStrFileName(String fileName) {
        return StringUtils.getFilenameExtension(new File(fileName).getName());
    }

    /**
     * Возвращает EXT расширение
     *
     * @param fileName - файл с типом File
     * @return - расширение
     */
    public String getExtensionFromFile(File fileName) {
        return StringUtils.getFilenameExtension(fileName.getName());
    }

    /**
     * Возвращаем только имя файла без расширения
     *
     * @param filename переменная имя файла типа строка
     * @return - имя файла строка
     */
    public String getFileNameWithoutExt(String filename) {
        return filename.replaceFirst("[.][^.]+$", "");
    }

    /**
     * Возвращаем только имя файла без расширения
     *
     * @param filename - переменная типа File
     * @return - имя файла строка
     */
    public String getFileNameWithoutExt(File filename) {
        return filename.getName().replaceFirst("[.][^.]+$", "");
    }


}



