package ru.usb.zsk945028.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.zsk945028.configs.Configure;

/**
 * Класс для переименования файлов xml : ZSK_CLIENTS_GGGG-MM-DD.xml
 * Наименование ЭС, которое содержит информацию обо всех находящихся на обслуживании в кредитной организации
 * клиентах – юридических лицах (за исключением кредитных организаций, государственных органов и органов местного самоуправления)
 * (далее – юридические лица), индивидуальных предпринимателях (далее – Реестр клиентов кредитной организации), имеет следующую структуру:
 * KYCCL_NNNNNNNNNN_Regn_GGGGMMDD_nnnnnn.xml
 * где:
 * KYCCL – идентификатор ЭС (буквы латинского алфавита);
 * NNNNNNNNNN – индивидуальный номер налогоплательщика (далее – ИНН) кредитной организации (10 знаков);
 * Regn – регистрационный номер кредитной организации в соответствии с Книгой государственной
 * регистрации кредитных организаций (далее – КГРКО) (с лидирующими нулями – 4 знака);
 */

@Component
public class RenamerFile {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    String newFileName;

    Logger logger = LoggerFactory.getLogger(RenamerFile.class);

    /**
     * Получаем новое имя файла целиком в формате
     * KYCCL_NNNNNNNNNN_Regn_GGGGMMDD_nnnnnn.xml
     *
     * @param fileName - строковое имя входной файл в формате ZSK_CLIENTS_GGGG-MM-DD.xml
     * @return - форматированное имя в формате KYCCL_NNNNNNNNNN_Regn_GGGGMMDD_nnnnnn.xml
     */
    public String GetRenameFile(String fileName) {
        logger.info("RenamerFile:input:namefile:" + fileName);
        //KYCCL_NNNNNNNNNN_Regn_GGGGMMDD_nnnnnn
        newFileName = "KYCCL_" + configure.getInn() + "_" + configure.getRegn() + "_" + getYYYY(fileName) +
                getMM(fileName) + getDD(fileName) + "_000001" + "." + workWithFiles.getExtensionFromStrFileName(fileName);
        logger.info("New FileName:" + newFileName);
        return newFileName;
    }

    /**
     * Получаем строку YYYY из имени  файла
     *
     * @param fileName - имя файла
     * @return - YYYY строка
     */
    private String getYYYY(String fileName) {
        if (fileName.length() > 16) {
            return fileName.substring(12, 16);
        }
        logger.error("Filename: " + fileName + " Length::" + fileName.length() + " length this FileName short, above 16 character. ");
        return "";
    }

    /**
     * Получаем MM з имени файла
     *
     * @param fileName - имя файла
     * @return - MM строка
     */
    private String getMM(String fileName) {
        if (fileName.length() > 19) {
            return fileName.substring(17, 19);
        }
        logger.error("Filename: " + fileName + " Length::" + fileName.length() + " length this FileName short, above 16 character. ");
        return "";
    }

    /**
     * Получаем день из имени файла
     *
     * @param fileName - имя файла
     * @return - DD
     */
    private String getDD(String fileName) {
        if (fileName.length() > 22) {
            return fileName.substring(20, 22);
        }
        logger.error("Filename: " + fileName + " Length::" + fileName.length() + " length this FileName short, above 16 character. ");
        return "";
    }


}
