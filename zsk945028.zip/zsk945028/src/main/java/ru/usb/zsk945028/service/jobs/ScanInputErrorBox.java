package ru.usb.zsk945028.service.jobs;

import ch.qos.logback.classic.pattern.ClassNameOnlyAbbreviator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.stereotype.Service;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.service.out.ConfirmSendingMessage;
import ru.usb.zsk945028.utils.WorkWithFiles;

import java.io.File;
import java.io.ObjectInputFilter;
import java.util.List;
import java.util.function.Consumer;

/**
 * Класс следящий за папкой ERROR СКЗИ и отправляющий уведомление, в случае наличия там файлов
 * Затем файлы удаляются или переносятся
 */
@Service
public class ScanInputErrorBox {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    Logger logger = LoggerFactory.getLogger(ScanInputErrorBox.class);


    /**
     * Сканирование каталога ошибке системы СКЗИ при проверке входящих сообщений из ЦБ
     */
    public void ScanErrorBoxCrypto() {

        /**
         * Проверим, что каталог ошибок СКЗИ существует
         */
        if (workWithFiles.checkPathExists(configure.getCryptoError())) {
            //Сканируем директорию
            List<File> fileList = workWithFiles.getDirList(configure.getCryptoError());
            if (fileList.size() > 0) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("! CRYPTO-ERROR!");
                logger.error("! In Directory " + configure.getCryptoError() + " discovered FILE:");
                fileList.forEach(new Consumer<File>() {
                    @Override
                    public void accept(File file) {
                        logger.error("! Discovered File:: " + file.getName() + " size=" + file.length());
                        if (workWithFiles.delFilesSName(file.getAbsolutePath())) {
                            logger.info("File " + file.getAbsolutePath() + " - deleted from directory:" + configure.getCryptoError());
                        } else {
                            logger.error("! ERROR! fail, trying to delete a file " + file.getAbsolutePath() + " was unsuccessful!");
                        }
                    }
                });
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
            logger.info("Directory" + configure.getCryptoError() + "is empty. No errors =) ");
        } else {
            logger.error("!!ERROR!!ScanInputErrorBox:ScanErrorBoxCrypto::Directory: " + configure.getCryptoError() + " not exists!!");
        }


    }

}
