package ru.usb.zsk945028.utils;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Класс для работы с датами
 */
@Component
public class ParseDate {

    /**
     * Формат даты
     */
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * Константа для добавления времени в дату
     */
    private String timeStringConstant = "T12:12:01Z";

    /**
     * Получить дату неделю назад, чтобы скачать все сообщения с этого момента
     *
     * @return - строка с датой
     */
    public String getWeekMinDateToRequest() {
        LocalDate localDate = LocalDate.now();
        return dtf.format(localDate.minusWeeks(1)) + timeStringConstant;
    }


    /**
     * Получить дату неделю назад, чтобы скачать все сообщения с этого момента
     *
     * @return - строка с датой
     */
    public String getMonthMinDateToRequest() {
        LocalDate localDate = LocalDate.now();
        return dtf.format(localDate.minusWeeks(4)) + timeStringConstant;
    }


}
