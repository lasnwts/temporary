package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

@ApiModel(value = "SessionFile", description = "UploadUrl – путь для загрузки файла; tExpirationDateTime – дата и время истечения сессии")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SessionFile {
    //UploadUrl – путь для загрузки файла
    @JsonProperty("UploadUrl")
    private String uploadUrl;

    //ExpirationDateTime - дата и время истечения сессии
    @JsonProperty("ExpirationDateTime")
    private String expirationDateTime;

    public SessionFile() {
    }

    public SessionFile(String uploadUrl, String expirationDateTime) {
        this.uploadUrl = uploadUrl;
        this.expirationDateTime = expirationDateTime;
    }

    public String getUploadUrl() {
        return uploadUrl;
    }

    public void setUploadUrl(String uploadUrl) {
        this.uploadUrl = uploadUrl;
    }

    public String getExpirationDateTime() {
        return expirationDateTime;
    }

    public void setExpirationDateTime(String expirationDateTime) {
        this.expirationDateTime = expirationDateTime;
    }

    @Override
    public String toString() {
        return "SessionFile{" +
                "uploadUrl='" + uploadUrl + '\'' +
                ", expirationDateTime='" + expirationDateTime + '\'' +
                '}';
    }
}
