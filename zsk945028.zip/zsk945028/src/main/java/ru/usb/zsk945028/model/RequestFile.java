package ru.usb.zsk945028.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Класс для подготовки запроса по скачиванию файлов
 */
@ApiModel(value = "RequestFile", description = "Rest запрос для скачивания файла : messageID - Id сообщения, fileId - Id файла")
public class RequestFile {
    @ApiModelProperty(value = "messageId :: пример :: df22462d-a599-4018-92a1-ae92010bf27b")
    private String messageId;
    @ApiModelProperty(value = "fileId :: пример :: 0faa22a8-b1c4-4e5b-a150-c23b57591f4f")
    private String fileId;

    public RequestFile() {
    }

    public RequestFile(String messageId, String fileId) {
        this.messageId = messageId;
        this.fileId = fileId;
    }

    @ApiModelProperty(value = "messageId :: пример :: df22462d-a599-4018-92a1-ae92010bf27b")
    public String getMessageId() {
        return messageId;
    }

    @ApiModelProperty(value = "messageId :: пример :: df22462d-a599-4018-92a1-ae92010bf27b")
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    @ApiModelProperty(value = "fileId :: пример :: 0faa22a8-b1c4-4e5b-a150-c23b57591f4f")
    public String getFileId() {
        return fileId;
    }

    @ApiModelProperty(value = "fileId :: пример :: 0faa22a8-b1c4-4e5b-a150-c23b57591f4f")
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    @Override
    public String toString() {
        return "RequestFile{" +
                "messageId='" + messageId + '\'' +
                ", fileId='" + fileId + '\'' +
                '}';
    }
}
