package ru.usb.zsk945028.service.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.utils.WorkWithFiles;

/**
 * Отправа сообщения в ЦБ *
 * Job 1 - отправка.
 * 1. Сканирование каталога
 * 2. Переименование и перенос файла во временную папку transform
 * 3. Упаковка в ZIP файла и перенос его в каталог для шифрации
 * Job 2. Отправка
 * 1. Сканирование папки готовности файла от СКЗИ
 * 2. Формирование класса где nc и sig присутствуют в одном классе.
 * 3. Шаг 1. SendMessageGetID
 * 4. Шаг 2. SendMessageCreateSession (enc)
 * 5. Шаг 3. PreparedPutFile (enc)
 * 6. Шаг 4. SendMessageCreateSession (sig)
 * 7. Шаг 5. PreparedPutFile (sig)
 * 8. Шаг 6. ConfirmSendingMessage (messageId)
 * 9. Удаление файлов с диска
 */
@Service
public class OutputMessage {


    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    Logger logger = LoggerFactory.getLogger(OutputMessage.class);


    //

}
