package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;

@ApiModel(value = "Zadacha77", description = "Получить параметры всех файлов")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha77 {

    @JsonProperty("Task")
    private String task;

    @JsonProperty("Files")
    public ArrayList<Zadacha77File> files;

    public Zadacha77() {
    }

    public Zadacha77(String task) {
        this.task = task;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public ArrayList<Zadacha77File> getFiles() {
        return files;
    }

    public void setFiles(ArrayList<Zadacha77File> files) {
        this.files = files;
    }

    @Override
    public String toString() {
        return "Zadacha77{" +
                "task='" + task + '\'' +
                '}';
    }
}
