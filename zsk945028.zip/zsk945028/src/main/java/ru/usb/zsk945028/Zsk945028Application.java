package ru.usb.zsk945028;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.utils.WorkWithFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@EnableSwagger2
@SpringBootApplication
public class Zsk945028Application implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(Zsk945028Application.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    public static void main(String[] args) {
        SpringApplication.run(Zsk945028Application.class, args);
    }


    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**"),
                        PathSelectors.ant("/api/v1/tcr/*")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service zsk94528", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Adapter for MTC. Api Title 10/01/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }


    @Override
    public void run(String... args) throws Exception {
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getTmpPath());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            System.out.println("Directory " + path.toString() + " = created");
        } else {
            System.out.println("Directory" + path.toString() + " = already exists");
        }
        //Очистка каталога при старте
        try {
            Files.walk(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                            FileSystems.getDefault().getSeparator() + configure.getTmpPath()))
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .forEach(File::delete);
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload folder!");
        }

        /**
         * Тестовая часть начало
         */
        //Записываем в ZIP одиночный файл
        workWithFiles.ZipFile("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.docx", "C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.zip");

        //Записываем в ZIP множество файлов
        List<String> sFiles = new ArrayList<String>();
        sFiles.add("C:/AppSever/Projects/Banking/ZSK/Хранилище ключей и сертификатов.html");
        sFiles.add("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.docx");
        workWithFiles.ZipMultipleFiles(sFiles, "C:/AppSever/Projects/Banking/ZSK/multiFilesZip.zip");


        workWithFiles.UnzipFile("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.zip",
                "C:/AppSever/Projects/Banking/ZSK/Downloads");
        workWithFiles.UnzipFile("C:/AppSever/Projects/Banking/ZSK/multiFilesZip.zip",
                "C:/AppSever/Projects/Banking/ZSK/Downloads");

        //list files
        List<File> files = workWithFiles.getDirList("C:\\app\\");
        if (files.size()==0){
            logger.info("пустое множество");
        }
        /********************************
         * Тестовая часть конец*********
         */

    }


    @Scheduled(initialDelay = 20000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob(){
        logger.info("*****************************************<Start Scheduler process " + configure.getVersion() + ">*******************************************************");


        logger.info("*****************************************<End Scheduler process " + configure.getVersion() + ">*******************************************************");
        System.gc();
    }
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
}


