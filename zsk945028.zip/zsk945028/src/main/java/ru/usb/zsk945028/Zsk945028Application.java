package ru.usb.zsk945028;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.service.jobs.InputMessage;
import ru.usb.zsk945028.service.jobs.ScanInputErrorBox;
import ru.usb.zsk945028.utils.RenamerFile;
import ru.usb.zsk945028.utils.WorkWithFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@EnableSwagger2
@SpringBootApplication
public class Zsk945028Application implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(Zsk945028Application.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    @Autowired
    RenamerFile renamerFile;

    @Autowired
    ScanInputErrorBox scanInputErrorBox;

    @Autowired
    InputMessage inputMessage;


    public static void main(String[] args) {
        SpringApplication.run(Zsk945028Application.class, args);
    }


    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**"),
                        PathSelectors.ant("/api/v1/tcr/*")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service zsk94528", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("945028 Участие в пилоте БР по Платформе ЗСК. Rest Api Title 15/06/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }


    @Override
    public void run(String... args) throws Exception {
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getTmpPath());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            System.out.println("Directory " + path.toString() + " = created");
        } else {
            System.out.println("Directory" + path.toString() + " = already exists");
        }
        //Очистка каталога при старте
        try {
            Files.walk(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                            FileSystems.getDefault().getSeparator() + configure.getTmpPath()))
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .forEach(File::delete);
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload folder!");
        }

        /**
         * Тестовая часть начало
         */
        //Записываем в ZIP одиночный файл
        workWithFiles.ZipFile("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.docx", "C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.zip");

        //Записываем в ZIP множество файлов
        List<String> sFiles = new ArrayList<String>();
        sFiles.add("C:/AppSever/Projects/Banking/ZSK/Хранилище ключей и сертификатов.html");
        sFiles.add("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.docx");
        workWithFiles.ZipMultipleFiles(sFiles, "C:/AppSever/Projects/Banking/ZSK/multiFilesZip.zip");


        workWithFiles.UnzipFile("C:/AppSever/Projects/Banking/ZSK/Oracle Database container images.zip",
                "C:/AppSever/Projects/Banking/ZSK/Downloads");
        workWithFiles.UnzipFile("C:/AppSever/Projects/Banking/ZSK/multiFilesZip.zip",
                "C:/AppSever/Projects/Banking/ZSK/Downloads");

        //list files
        List<File> files = workWithFiles.getDirList("C:\\AppSever\\Projects\\Banking\\ZSK\\");
        if (files.size()==0){
            logger.info("пустое множество");

        } else {
            logger.info("просматриваем файлы.................");
            files.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {
                    System.out.println(" abs:"+file.getAbsolutePath());
                    System.out.printf(file.getName());
                    System.out.printf(" ext:");
                    System.out.println(StringUtils.getFilenameExtension(file.getName()));
                    System.out.printf(" file name:");
                    System.out.println(StringUtils.getFilename(file.getName()).replaceFirst("[.][^.]+$", ""));
                    System.out.println("W file name:");
                    System.out.println(workWithFiles.getFileNameWithoutExt(file));
                    System.out.println(workWithFiles.getFileNameWithoutExt(file.getName()));

                    System.out.println(" w: File");
                    System.out.println(workWithFiles.getExtensionFromFile(file));
                    System.out.println(" w: sting");
                    System.out.println(workWithFiles.getExtensionFromStrFileName(file.getName()));

                }
            });
        }
        if (workWithFiles.checkFileExists("C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads\\form_fed_rest_api.pdf")){
            logger.info("Файл найден: C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads\\form_fed_rest_api.pdf");
            workWithFiles.moveFileSName("C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads\\form_fed_rest_api.pdf","C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads\\tmp\\form_fed_rest_api.pdf");
        } else {
            logger.info("Файл НЕ ОБНАРУЖЕН!!: C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads\\form_fed_rest_api.pdf ");
        }

//        logger.info("workWithFiles.getDirList");
//        workWithFiles.getDirList("C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads");

//        logger.info("workWithFiles.getDirListRecursive");
//        workWithFiles.getDirListRecursive("C:\\AppSever\\Projects\\Banking\\ZSK\\Downloads");

//        logger.info("workWithFiles.getDirectory");
//        workWithFiles.getDirectory("C:\\AppSever\\Projects\\Banking\\ZSK");

        logger.info("workWithFiles.getDirFileWitMask");
//        workWithFiles.getDirFileWitMask("C:\\AppSever\\Projects\\Banking\\ZSK", ".java");
        workWithFiles.getDirFileWithExt("C:\\AppSever\\Projects\\Banking\\ZSK", ".docx");

        logger.info("workWithFiles.getDirFileForMask");
        workWithFiles.getDirFileForMask("C:\\AppSever\\Projects\\Banking\\ZSK", "response");


        logger.info("ZSK_CLIENTS_GGGG-MM-DD.xml:ZSK_CLIENTS_2022-06-15.xml");
        logger.info(renamerFile.GetRenameFile("ZSK_CLIENTS_2022-06-15.xml"));

        /********************************
         * Тестовая часть конец*********
         */

    }


    @Scheduled(initialDelay = 20000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob(){
        logger.info("*****************************************<Start Scheduler process " + configure.getVersion() + ">*******************************************************");
        logger.info("------------------------------------------------------------------------------------------------------------------------");
        logger.info("* Start: ScanErrorBoxCrypto - scanning the Crypto directory for files with a signature verification error ");
        scanInputErrorBox.ScanErrorBoxCrypto();
        logger.info("* Stop:  ScanErrorBoxCrypto - scanning the Crypto directory for files with a signature verification error ");
        logger.info("------------------------------------------------------------------------------------------------------------------------");
        logger.info("  ");
        logger.info("------------------------------------------------------------------------------------------------------------------------");
        logger.info("* Start: Launching a file download service: InputMessage: inputMessageService>>>>");
        inputMessage.inputMessageService();
        inputMessage.moveFileAfterDecrypt();
        logger.info("* Stop: Launching a file download service: InputMessage: inputMessageService>>>>");
        logger.info("------------------------------------------------------------------------------------------------------------------------");



        logger.info("*****************************************<End Scheduler process " + configure.getVersion() + ">*******************************************************");
        System.gc();
    }
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
}


