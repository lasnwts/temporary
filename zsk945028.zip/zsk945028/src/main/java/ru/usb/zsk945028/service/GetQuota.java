package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Quota;

@Service
public class GetQuota {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetQuota.class);

    public Quota getQuota() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<Quota> response = restTemplate.exchange(configure.getZskUrlQuota(),
                HttpMethod.GET, request,
                Quota.class);
        Quota quota = response.getBody();
        logger.info("Quota::" + quota.toString());
        return quota;
    }

}
