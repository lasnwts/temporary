package ru.usb.zsk945028.model;

import javax.sql.rowset.serial.SerialStruct;

/**
 * Сообщение из 2-х файлов
 * Zadacha137
 */
public class MessageOutputZ137 {

    /**
     * Имя файла основного сообщения
     */
    private String fileNameEnc;

    /**
     * Имя файла открепленной подписи
     */
    private String fileNameSig;

    /**
     * Статус отправки
     * true - успешно отправлен
     * false - не отправлен
     */
    private boolean status;

    /**
     * Сообщения об ошибках, связанное с отправкой сообщения
     */
    private String message;

    public MessageOutputZ137() {
    }

    public MessageOutputZ137(String fileNameEnc, String fileNameSig, boolean status, String message) {
        this.fileNameEnc = fileNameEnc;
        this.fileNameSig = fileNameSig;
        this.status = status;
        this.message = message;
    }

    public String getFileNameEnc() {
        return fileNameEnc;
    }

    public void setFileNameEnc(String fileNameEnc) {
        this.fileNameEnc = fileNameEnc;
    }

    public String getFileNameSig() {
        return fileNameSig;
    }

    public void setFileNameSig(String fileNameSig) {
        this.fileNameSig = fileNameSig;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "MessageOutputZ137{" +
                "fileNameEnc='" + fileNameEnc + '\'' +
                ", fileNameSig='" + fileNameSig + '\'' +
                ", status=" + status +
                ", message='" + message + '\'' +
                '}';
    }
}
