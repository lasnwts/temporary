package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

@ApiModel(value = "Quota", description = "Получить размер квоты")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Quota {

    @JsonProperty("TotalQuota")
    private String totalQuota;

    @JsonProperty("UsedQuota")
    private String usedQuota;

    @JsonProperty("MessageSize")
    private String messageSize;

    @JsonProperty("RestOfQuota")
    private String restOfQuota;

    @JsonProperty("AccountQuota")
    private String accountQuota;

    public Quota() {
    }

    public Quota(String totalQuota, String usedQuota, String messageSize, String restOfQuota, String accountQuota) {
        this.totalQuota = totalQuota;
        this.usedQuota = usedQuota;
        this.messageSize = messageSize;
        this.restOfQuota = restOfQuota;
        this.accountQuota = accountQuota;
    }

    public String getTotalQuota() {
        return totalQuota;
    }

    public void setTotalQuota(String totalQuota) {
        this.totalQuota = totalQuota;
    }

    public String getUsedQuota() {
        return usedQuota;
    }

    public void setUsedQuota(String usedQuota) {
        this.usedQuota = usedQuota;
    }

    public String getMessageSize() {
        return messageSize;
    }

    public void setMessageSize(String messageSize) {
        this.messageSize = messageSize;
    }

    public String getRestOfQuota() {
        return restOfQuota;
    }

    public void setRestOfQuota(String restOfQuota) {
        this.restOfQuota = restOfQuota;
    }

    public String getAccountQuota() {
        return accountQuota;
    }

    public void setAccountQuota(String accountQuota) {
        this.accountQuota = accountQuota;
    }

    @Override
    public String toString() {
        return "Quota{" +
                "totalQuota='" + totalQuota + '\'' +
                ", usedQuota='" + usedQuota + '\'' +
                ", messageSize='" + messageSize + '\'' +
                ", restOfQuota='" + restOfQuota + '\'' +
                ", accountQuota='" + accountQuota + '\'' +
                '}';
    }
}
