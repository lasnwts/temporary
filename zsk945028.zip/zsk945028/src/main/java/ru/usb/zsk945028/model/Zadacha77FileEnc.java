package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

/**
 * Example:
 * "Name": "KYCHR_0274062111_2275_20220614_000001.zip.enc",
 *         "Encrypted": true,
 *         "RepositoryType": "Http",
 *         "Size": "3947"
 */


@ApiModel(value = "Zadacha77FileEnc", description = "Получить параметры всех файлов")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha77FileEnc {

    @JsonProperty("Name")
    public String name;

    @JsonProperty("Encrypted")
    public boolean encrypted;

    @JsonProperty("RepositoryType")
    public String repositoryType;

    @JsonProperty("Size")
    public long size;

    public Zadacha77FileEnc() {
    }

    public Zadacha77FileEnc(String name, boolean encrypted, String repositoryType, long size) {
        this.name = name;
        this.encrypted = encrypted;
        this.repositoryType = repositoryType;
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEncrypted() {
        return encrypted;
    }

    public void setEncrypted(boolean encrypted) {
        this.encrypted = encrypted;
    }

    public String getRepositoryType() {
        return repositoryType;
    }

    public void setRepositoryType(String repositoryType) {
        this.repositoryType = repositoryType;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Zadacha77File{" +
                "name='" + name + '\'' +
                ", encrypted=" + encrypted +
                ", repositoryType='" + repositoryType + '\'' +
                ", size=" + size +
                '}';
    }
}
