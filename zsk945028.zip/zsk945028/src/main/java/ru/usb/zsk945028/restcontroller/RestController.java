package ru.usb.zsk945028.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Zadacha130;
import ru.usb.zsk945028.service.GetZadacha130;

import java.io.IOException;
import java.util.List;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер прокси ЦБ.[...]", tags = "Rest API")
public class RestController {

    @Autowired
    Configure configure;

    @Autowired
    GetZadacha130 getZadacha130;

    Logger logger = LoggerFactory.getLogger(RestController.class);


    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
        if (configure.getVersion() == null) {
            logger.error("get /version :: Request get version, but version not defibed in application.properties");
            return "version not defined";
        }
        logger.error("get /version :: Request get version, " + configure.getVersion());
        return (configure.getVersion());
    }

    @GetMapping("/get_zadacha130")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос всех файлов Zadacha_130",
            notes = "Zadacha_130, в ответ на который будут получены все ЭС по указанной задаче",
            response = String.class)
    public List<Zadacha130> getAll_Zadacha130() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getZadacha130();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

    @GetMapping("/get_new_zadacha130")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос новых файлов Zadacha_130",
            notes = "Zadacha_130=Status=new , в ответ на который будут получены новые ЭС по указанной задаче",
            response = String.class)
    public List<Zadacha130> getNew_Zadacha130() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getZadacha130new();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

    @GetMapping("/get_messages")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос всех файлов",
            notes = "Messages в ответ на который будут получены все сообщения",
            response = String.class)
    public List<Zadacha130> getAll() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getAllMessages();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

}
