package ru.usb.zsk945028.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Quota;
import ru.usb.zsk945028.model.RequestFile;
import ru.usb.zsk945028.model.Zadacha130;
import ru.usb.zsk945028.model.Zadacha130File;
import ru.usb.zsk945028.service.*;
import ru.usb.zsk945028.utils.NewFileInputStream;

import java.io.File;
import java.io.IOException;
import java.util.List;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер по REST API к сервису ЗСК ЦБ РФ и получить файл с данными по уровню рисков ЮЛ/ИП.", tags = "Rest API (Входящие файлы)")
public class RestController {

    @Autowired
    Configure configure;

    @Autowired
    GetZadacha130 getZadacha130;

    @Autowired
    GetFiles getFiles;

    @Autowired
    GetMessages getMessages;

    @Autowired
    GetQuota getQuota;

    @Autowired
    GetMetaFromFile getMetaFromFile;

    @Autowired
    GetMetaFromMessage getMetaFromMessage;

    Logger logger = LoggerFactory.getLogger(RestController.class);


    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
        if (configure.getVersion() == null) {
            logger.error("get /version :: Request get version, but version not defibed in application.properties");
            return "version not defined";
        }
        logger.error("get /version :: Request get version, " + configure.getVersion());
        return (configure.getVersion());
    }

    @GetMapping("/get_zadacha130")
    //Запрашиваем версию сервиса 2022-06-15T16:56:34Z
    @ApiOperation(value = "Запрос первых 100 файлов Zadacha_130",
            notes = "Zadacha_130, в ответ на который будут получены 100 ЭС по указанной задаче",
            response = String.class)
    public List<Zadacha130> getAll_Zadacha130() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getZadacha130();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

    @GetMapping("/getzadacha130/{minDateTime}")
    //Запрашиваем версию сервиса 2022-06-15T16:56:34Z
    @ApiOperation(value = "Запрос файлов Zadacha_130 c определенной даты ",
            notes = "Zadacha_130, в ответ на который будут получены 100 ЭС по указанной задаче, с определенной даты, формат:yyyy-MM-dd’T’HH:mm:ss’Z’" +
                    "MinDateTime – минимально возможная дата создания сообщения (ГОСТ ISO 8601-2001 по маске «yyyy-MM-dd’T’HH:mm:ss’Z’»)" +
                    " (если параметр будет указан, то будут возвращены только сообщения, полученные/отправленные с указанной даты, включая ее)",
            response = String.class)
    public List<Zadacha130> getAll_Zadacha130(@ApiParam(value = "MinDateTime, пример: 2022-06-15T16:56:34Z", required = true)
                                              @PathVariable String minDateTime) throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getZadacha130minDate(minDateTime);
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }


    @GetMapping("/get_new_zadacha130")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос новых файлов Zadacha_130",
            notes = "Zadacha_130=Status=new , в ответ на который будут получены новые ЭС по указанной задаче",
            response = String.class)
    public List<Zadacha130> getNew_Zadacha130() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getZadacha130new();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

    @GetMapping("/get_messages")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос всех файлов",
            notes = "Messages в ответ на который будут получены все сообщения",
            response = String.class)
    public List<Zadacha130> getAll() throws IOException {
        List<Zadacha130> zadacha130s = getZadacha130.getAllMessages();
        if (zadacha130s == null) {
            logger.error("Error список задач не получен!");
        }
        return zadacha130s;
    }

    @GetMapping("/quota")
    //Запрашиваем квоту на сообщения
    @ApiOperation(value = "Запрос квоты",
            notes = "Messages в ответ на который будут получены размеры квоты",
            response = Quota.class)
    public Quota getQuota() {
        logger.info("Request for Quota...");
        Quota quota = getQuota.getQuota();
        return quota;
    }

    @PostMapping("/getfile")
    //Запрашиваем квоту на сообщения
    @ApiOperation(value = "Запрос файла из сообщения",
            notes = "Запрос на получение файла. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b , filesId = 0faa22a8-b1c4-4e5b-a150-c23b57591f4f ")
    public ResponseEntity getFiles(@RequestBody RequestFile requestFile) {
        logger.info("post request getFile:" + requestFile.toString());
        try {
            File file = getFiles.GetFile(requestFile.getMessageId(), requestFile.getFileId());
            logger.info("Rescontroller:download file:" + file.getAbsolutePath());
            logger.info("Rescontroller:size file:" + file.getName() + " Size=" + file.length());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(file));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentLength(file.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (Exception exception) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!! Request to CB return error! !!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::" + exception);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.toString());
        }
    }


    @PostMapping("/getMessage")
    //Запрашиваем квоту на сообщения
    @ApiOperation(value = "Запрос сообщения Zadacha130",
            notes = "Запрос на получение сообщения. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b ")
    public ResponseEntity getMessage(@RequestBody String messageIdnumber) {
        logger.info("post request getFile:" + messageIdnumber);
        try {
            File file = getMessages.GetMessage(messageIdnumber);
            logger.info("Rescontroller:download message:" + file.getAbsolutePath());
            logger.info("Rescontroller:size message:" + file.getName() + " Size=" + file.length());
            InputStreamResource resource = new InputStreamResource(new NewFileInputStream(file));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentLength(file.length())
                    .header("Content-type", "application/octet-stream")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (Exception exception) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!! Request to CB return error! !!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::" + exception);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.toString());
        }
    }

    @PostMapping("/getmeta")
    //Запрашиваем квоту на сообщения
    @ApiOperation(value = "Запрос META информации по файлу из сообщения",
            notes = "Запрос на получение информации по файлу. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b , filesId = 0faa22a8-b1c4-4e5b-a150-c23b57591f4f ")
    public Zadacha130File GetMetaFromFile(@RequestBody RequestFile requestFile) {
        logger.info("Request for Meta from File::" + requestFile.toString());
        Zadacha130File zadacha130File = getMetaFromFile.GetMetaFromFile(requestFile.getMessageId(), requestFile.getFileId());
        logger.info("Response for Meta from File::" + zadacha130File.toString());
        return zadacha130File;
    }

    @GetMapping("/getmessage/{id}")
    //Запрашиваем квоту на сообщения
    @ApiOperation(value = "Запрос META информации из сообщения",
            notes = "Запрос на получение информации по сообщению. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b ")
    public Zadacha130 GetMetaFromMessage(@ApiParam(value = "Передаем id сообщения", required = true)
                                         @PathVariable String id) {
        logger.info("Request for Meta from MessageId::" + id);
        Zadacha130 zadacha130 = getMetaFromMessage.GetMetaFromFile(id);
        logger.info("Response for Meta from MessageId::" + id + " :Response:" + zadacha130.toString());
        return zadacha130;
    }
}
