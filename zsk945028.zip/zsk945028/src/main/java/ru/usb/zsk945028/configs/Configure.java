package ru.usb.zsk945028.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {

    @Value("${crypto.fromcb}")
    private String cryptoFromCB;

    @Value("${crypto.tocb}")
    private String cryptoToCB;

    @Value("${crypto.frombank}")
    private String cryptoFromBank;

    @Value("${crypto.tobank}")
    private String cryptoToBank;

    @Value("${crypto.in}")
    private String cryptoIn;

    @Value("${crypto.error}")
    private String cryptoError;

    @Value("${crypto.out}")
    private String cryptoOut;

    @Value("${service.version}")
    private String version;

    @Value("${service.tmppath}")
    private String tmpPath;

    @Value("${zskLogin}")
    private String zskLogin;

    @Value("${zskPassword}")
    private String zskPassword;

    @Value("${zskUrlZadacha130}")
    private String zskUrlZadacha130;

    @Value("${zskBaseurl}")
    private String zskBaseurl;

    public String getTmpPath() {
        return tmpPath;
    }

    public String getVersion() {
        return version;
    }

    public String getZskLogin() {
        return zskLogin;
    }

    public String getZskPassword() {
        return zskPassword;
    }

    public String getZskUrlZadacha130() {
        return zskUrlZadacha130;
    }

    public String getZskBaseurl() {
        return zskBaseurl;
    }

    public String getCryptoFromCB() {
        return cryptoFromCB;
    }

    public String getCryptoToCB() {
        return cryptoToCB;
    }

    public String getCryptoFromBank() {
        return cryptoFromBank;
    }

    public String getCryptoToBank() {
        return cryptoToBank;
    }

    public String getCryptoIn() {
        return cryptoIn;
    }

    public String getCryptoError() {
        return cryptoError;
    }

    public String getCryptoOut() {
        return cryptoOut;
    }
}
