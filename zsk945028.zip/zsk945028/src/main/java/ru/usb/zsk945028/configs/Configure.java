package ru.usb.zsk945028.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {

    /**
     * Расшифрованные файлы из ЦБ
     */
    @Value("${kyc.forursb}")
    private String decryptoFromCBb;

    /**
     * Файлы с ошибкой  шифрования
     */
    @Value("${kyc.error}")
    private String cryptoError;

    /**
     * Зашифрованные файлы из ЦБ
     */
    @Value("${kyc.frombr}")
    private String cryptoFromCB;

    /**
     * папка с файлами для зашифровки и создания подписи для отправки в ЦБ
     */
    @Value("${kyc.in}")
    private String kycIn;

    /**
     *  В случае когда возвращается значение new - грузим только новые сообщения
     *  В случае all - загружаем все сообщения типа Zadach130
     */
    @Value("${kyc.type.input:new}")
    private String kycTypeInput;

    /**
     * папка с файлами логов
     */
    @Value("${kyc.logs}")
    private String kycLogs;

    /**
     * папка с зашифрованными и подписанными файлами для отправки в ЦБ
     */
    @Value("${kyc.out}")
    private String kycOut;

    /**
     * папка с временными файлами
     */

    /**
     * Файл исходящих сообщений, в сторону ЦБ
     */
    @Value("${kyc.obmen_br_kyc_out}")
    private String kycObmenBRkycOut;

    /**
     * Файл с входящими данными от ЦБ в ЦХД
     */
    @Value("${kyc.obmen_br_kyc_in}")
    private String kycObmenBRkycIn;

    @Value("${kyc.temp}")
    private String kycTemp;

    @Value("${kyc.inn}")
    private String inn;

    @Value("${kyc.regn}")
    private String regn;

    @Value("${kyc.obmen.zadacha:Zadacha_77}")
    private String kycObmenzadacha;

    @Value("${service.version}")
    private String version;

    @Value("${service.tmppath}")
    private String tmpPath;

    @Value("${zskLogin}")
    private String zskLogin;

    @Value("${zskPassword}")
    private String zskPassword;

    @Value("${zskUrlZadacha130}")
    private String zskUrlZadacha130;

    @Value("${zskUrlQuota}")
    private String zskUrlQuota;

    public String getZskUrlQuota() {
        return zskUrlQuota;
    }

    @Value("${zskBaseurl}")
    private String zskBaseurl;

    public String getTmpPath() {
        return tmpPath;
    }

    public String getVersion() {
        return version;
    }

    public String getZskLogin() {
        return zskLogin;
    }

    public String getZskPassword() {
        return zskPassword;
    }

    public String getZskUrlZadacha130() {
        return zskUrlZadacha130;
    }

    public String getZskBaseurl() {
        return zskBaseurl;
    }

    public String getDecryptoFromCBb() {
        return decryptoFromCBb;
    }

    public String getCryptoError() {
        return cryptoError;
    }

    public String getCryptoFromCB() {
        return cryptoFromCB;
    }

    public String getKycIn() {
        return kycIn;
    }

    public String getKycLogs() {
        return kycLogs;
    }

    public String getKycOut() {
        return kycOut;
    }

    public String getKycTemp() {
        return kycTemp;
    }

    public String getKycObmenBRkycOut() {
        return kycObmenBRkycOut;
    }

    public String getKycObmenBRkycIn() {
        return kycObmenBRkycIn;
    }

    public String getKycObmenzadacha() {
        return kycObmenzadacha;
    }

    public String getInn() {
        return inn;
    }

    public String getRegn() {
        return regn;
    }

    public String getKycTypeInput() {
        return kycTypeInput;
    }
}
