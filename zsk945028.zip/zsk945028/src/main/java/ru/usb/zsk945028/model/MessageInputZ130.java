package ru.usb.zsk945028.model;

/**
 * Класс для описания полученного файла сообщения из ЦБ
 * Типа df22462d-a599-4018-92a1-ae92010bf27b.zip
 */
public class MessageInputZ130 {

    /**
     * Имя файла основного сообщения
     * 2ndrR1_20220506_1.xml.zip.enc
     */
    private String fileNameEnc;

    /**
     * Имя файла открепленной подписи
     * 2ndrR1_20220506_1.xml.zip.sig
     */
    private String fileNameSig;

    /**
     * Имя файла Title.txt
     * Title.txt
     */
    private String fileNameTitle;

    /**
     * Каталог в который упакованы файлы архива
     * "Получение информации об уровне риска ... 11-05-2022_16-15-38"
     */
    private String pathZipFile;

    /**
     * Имя полученного основного файла типа
     * df22462d-a599-4018-92a1-ae92010bf27b.zip
     */
    private String baseZipFile;

    /**
     * Статус отправки
     * true - успешно отправлен
     * false - не отправлен
     */
    private boolean status;

    /**
     * Сообщения об ошибках, связанное с отправкой сообщения
     */
    private String message;

    public MessageInputZ130() {
    }

    public MessageInputZ130(String fileNameEnc, String fileNameSig, String fileNameTitle,
                            String pathZipFile, String baseZipFile, boolean status, String message) {
        this.fileNameEnc = fileNameEnc;
        this.fileNameSig = fileNameSig;
        this.fileNameTitle = fileNameTitle;
        this.pathZipFile = pathZipFile;
        this.baseZipFile = baseZipFile;
        this.status = status;
        this.message = message;
    }

    public String getFileNameEnc() {
        return fileNameEnc;
    }

    public void setFileNameEnc(String fileNameEnc) {
        this.fileNameEnc = fileNameEnc;
    }

    public String getFileNameSig() {
        return fileNameSig;
    }

    public void setFileNameSig(String fileNameSig) {
        this.fileNameSig = fileNameSig;
    }

    public String getFileNameTitle() {
        return fileNameTitle;
    }

    public void setFileNameTitle(String fileNameTitle) {
        this.fileNameTitle = fileNameTitle;
    }

    public String getPathZipFile() {
        return pathZipFile;
    }

    public void setPathZipFile(String pathZipFile) {
        this.pathZipFile = pathZipFile;
    }

    public String getBaseZipFile() {
        return baseZipFile;
    }

    public void setBaseZipFile(String baseZipFile) {
        this.baseZipFile = baseZipFile;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "MessageInputZ130{" +
                "fileNameEnc='" + fileNameEnc + '\'' +
                ", fileNameSig='" + fileNameSig + '\'' +
                ", fileNameTitle='" + fileNameTitle + '\'' +
                ", pathZipFile='" + pathZipFile + '\'' +
                ", baseZipFile='" + baseZipFile + '\'' +
                ", status=" + status +
                ", message='" + message + '\'' +
                '}';
    }
}
