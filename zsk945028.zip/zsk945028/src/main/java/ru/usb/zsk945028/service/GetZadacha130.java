package ru.usb.zsk945028.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zsk945028.configs.Configure;
import ru.usb.zsk945028.model.Zadacha130;
import ru.usb.zsk945028.model.Zadacha130File;
import ru.usb.zsk945028.model.Zadacha130Repo;

import java.util.Base64;
import java.util.List;
import java.util.function.Consumer;

/**
 * Класс для получения информации от портала ЦБ ЗСК
 */
@Service
public class GetZadacha130 {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetZadacha130.class);

    /**
     * Функция получения строки авторизации из application.properties
     * @return - строка авторизации Base64
     */
    private String setAuth() {
        String authStr = configure.getZskLogin() + ":" + configure.getZskPassword();
        return Base64.getEncoder().encodeToString(authStr.getBytes());
    }


    /**
     * Получения всех сообщений по Задаче 130
     * @return - List<Zadacha130>
     */
    public List<Zadacha130> getZadacha130() {

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<Zadacha130[]> response = restTemplate.exchange(configure.getZskUrlZadacha130(),
                HttpMethod.GET, request,
                Zadacha130[].class);
        List<Zadacha130> zadacha130s = List.of(response.getBody());

        zadacha130s.forEach(new Consumer<Zadacha130>() {
            @Override
            public void accept(Zadacha130 zadacha130) {
                logger.info("Получена запись:Zadacha130:" + zadacha130.toString());
                zadacha130.getFiles().forEach(new Consumer<Zadacha130File>() {
                    @Override
                    public void accept(Zadacha130File zadacha130File) {
                        logger.info("      Files::" + zadacha130File.toString());
                        zadacha130File.getRepositoryInfo().forEach(new Consumer<Zadacha130Repo>() {
                            @Override
                            public void accept(Zadacha130Repo zadacha130Repo) {
                                logger.info("                Repository::" + zadacha130Repo.toString());
                            }
                        });
                    }
                });


            }
        });
        return zadacha130s;
    }

    /**
     * Список всех новых файлов по задаче 130
     * @return List<Zadacha130>
     */
    public List<Zadacha130> getZadacha130new() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<Zadacha130[]> response = restTemplate.exchange(configure.getZskUrlZadacha130()+"&Status=new",
                HttpMethod.GET, request,
                Zadacha130[].class);
        List<Zadacha130> zadacha130s = List.of(response.getBody());

        zadacha130s.forEach(new Consumer<Zadacha130>() {
            @Override
            public void accept(Zadacha130 zadacha130) {
                logger.info("Получена запись:Zadacha130:" + zadacha130.toString());
                zadacha130.getFiles().forEach(new Consumer<Zadacha130File>() {
                    @Override
                    public void accept(Zadacha130File zadacha130File) {
                        logger.info("       Files::" + zadacha130File.toString());
                        zadacha130File.getRepositoryInfo().forEach(new Consumer<Zadacha130Repo>() {
                            @Override
                            public void accept(Zadacha130Repo zadacha130Repo) {
                                logger.info("                Repository::" + zadacha130Repo.toString());
                            }
                        });
                    }
                });


            }
        });
        return zadacha130s;
    }

    /**
     * Получения всех сообщений с портала (/message)
     * @return List<Zadacha130>
     */
    public List<Zadacha130> getAllMessages(){
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        // make a request
        ResponseEntity<Zadacha130[]> response = restTemplate.exchange(configure.getZskBaseurl()+"/messages",
                HttpMethod.GET, request,
                Zadacha130[].class);
        List<Zadacha130> zadacha130s = List.of(response.getBody());

        zadacha130s.forEach(new Consumer<Zadacha130>() {
            @Override
            public void accept(Zadacha130 zadacha130) {
                logger.info("Получена запись:Zadacha130:" + zadacha130.toString());
                zadacha130.getFiles().forEach(new Consumer<Zadacha130File>() {
                    @Override
                    public void accept(Zadacha130File zadacha130File) {
                        logger.info("      Files::" + zadacha130File.toString());
                        zadacha130File.getRepositoryInfo().forEach(new Consumer<Zadacha130Repo>() {
                            @Override
                            public void accept(Zadacha130Repo zadacha130Repo) {
                                logger.info("             Repository::" + zadacha130Repo.toString());
                            }
                        });
                    }
                });


            }
        });
        return zadacha130s;
    }

}
