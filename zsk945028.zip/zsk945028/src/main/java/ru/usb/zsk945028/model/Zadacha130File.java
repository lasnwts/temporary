package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;

@ApiModel(value = "Zadacha130File", description = "Получить параметры всех файлов")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha130File {

    @JsonProperty("Id")
    public String id;
    @JsonProperty("Name")
    public String name;
    @JsonProperty("Description")
    public String description;
    @JsonProperty("Encrypted")
    public boolean encrypted;
    @JsonProperty("SignedFile")
    public String signedFile;
    @JsonProperty("Size")
    public int size;
    @JsonProperty("RepositoryInfo")
    public ArrayList<Zadacha130Repo> repositoryInfo;

    public Zadacha130File() {
    }

    public Zadacha130File(String id, String name, String description, boolean encrypted,
                          String signedFile, int size, ArrayList<Zadacha130Repo> repositoryInfo) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.encrypted = encrypted;
        this.signedFile = signedFile;
        this.size = size;
        this.repositoryInfo = repositoryInfo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isEncrypted() {
        return encrypted;
    }

    public void setEncrypted(boolean encrypted) {
        this.encrypted = encrypted;
    }

    public String getSignedFile() {
        return signedFile;
    }

    public void setSignedFile(String signedFile) {
        this.signedFile = signedFile;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ArrayList<Zadacha130Repo> getRepositoryInfo() {
        return repositoryInfo;
    }

    public void setRepositoryInfo(ArrayList<Zadacha130Repo> repositoryInfo) {
        this.repositoryInfo = repositoryInfo;
    }

    @Override
    public String toString() {
        return "Zadacha130File{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", encrypted=" + encrypted +
                ", signedFile='" + signedFile + '\'' +
                ", size=" + size +
                '}';
    }
}
