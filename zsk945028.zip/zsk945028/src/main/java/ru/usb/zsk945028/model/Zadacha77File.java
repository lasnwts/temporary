package ru.usb.zsk945028.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@ApiModel(value = "Zadacha77File", description = "Получить параметры всех файлов")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha77File {

    Zadacha77FileEnc zadacha77FileEnc;
    Zadacha77FileSig zadacha77FileSig;

    public Zadacha77File(Zadacha77FileEnc zadacha77FileEnc, Zadacha77FileSig zadacha77FileSig) {
        this.zadacha77FileEnc = zadacha77FileEnc;
        this.zadacha77FileSig = zadacha77FileSig;
    }

    public Zadacha77FileEnc getZadacha77FileEnc() {
        return zadacha77FileEnc;
    }

    public void setZadacha77FileEnc(Zadacha77FileEnc zadacha77FileEnc) {
        this.zadacha77FileEnc = zadacha77FileEnc;
    }

    public Zadacha77FileSig getZadacha77FileSig() {
        return zadacha77FileSig;
    }

    public void setZadacha77FileSig(Zadacha77FileSig zadacha77FileSig) {
        this.zadacha77FileSig = zadacha77FileSig;
    }

    public Zadacha77File() {
    }
}
