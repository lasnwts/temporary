package ru.usb.zsk945028;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zsk945028ApplicationTests {

	@Test
	void contextLoads() {
	}

}
