package ru.usb.soapgenerated.dto.xml;

public class Body {
    public GetCommonDirectoryRequest GetCommonDirectoryRequest;

    public Body() {
    }

    public ru.usb.soapgenerated.dto.xml.GetCommonDirectoryRequest getGetCommonDirectoryRequest() {
        return GetCommonDirectoryRequest;
    }

    public void setGetCommonDirectoryRequest(ru.usb.soapgenerated.dto.xml.GetCommonDirectoryRequest getCommonDirectoryRequest) {
        GetCommonDirectoryRequest = getCommonDirectoryRequest;
    }
}
