package ru.usb.soapgenerated;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.soapgenerated.dto.A1;
import ru.usb.soapgenerated.dto.xml.Envelope;
import ru.usb.soapgenerated.utils.MapperXML;

@SpringBootApplication
public class SoapGeneratedApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(SoapGeneratedApplication.class);

//	@Autowired
//	MapperXML mapperXML;

	public static void main(String[] args) {
		SpringApplication.run(SoapGeneratedApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		A1 a1 = new A1();

		String s1 ="hghgf";

		String s2 = "<Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\">   \n" +
				"   <Body>\n" +
				"      <GetCommonDirectoryRequest>\n" +
				"         <PartnerID>300</PartnerID>\n" +
				"         <ExtUserGuid>acb80275-6ecb-4bef-9f36-ed15de3e8891</ExtUserGuid>\n" +
				"         <DirectoryID>CB_SET_QUESTIONNAIRE</DirectoryID>\n" +
				"      </GetCommonDirectoryRequest>\n" +
				"   </Body>\n" +
				"</Envelope>";

		logger.info("Start");
		logger.info("s1={}", s1);
		logger.info("s2={}", s2);

//		logger.info(a1.getSourceXML());

////		Envelope envelope = mapperXML.getMap(a1.getSourceXML());
//
//		logger.info("Envelope={}", envelope);
//
////		Envelope envelope1 = mapperXML.getMap(a1.getS2());
//
//		logger.info("Envelope1={}", envelope);

		logger.info("Stop");
	}
}
