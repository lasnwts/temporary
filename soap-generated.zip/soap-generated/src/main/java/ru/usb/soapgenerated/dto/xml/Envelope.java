package ru.usb.soapgenerated.dto.xml;

public class Envelope {
    public Object Header;
    public Body Body;
    public String soapenv;
    public String bp;
    public String text;

    public Envelope() {
    }

    public Object getHeader() {
        return Header;
    }

    public void setHeader(Object header) {
        Header = header;
    }

    public ru.usb.soapgenerated.dto.xml.Body getBody() {
        return Body;
    }

    public void setBody(ru.usb.soapgenerated.dto.xml.Body body) {
        Body = body;
    }

    public String getSoapenv() {
        return soapenv;
    }

    public void setSoapenv(String soapenv) {
        this.soapenv = soapenv;
    }

    public String getBp() {
        return bp;
    }

    public void setBp(String bp) {
        this.bp = bp;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "Envelope{" +
                "Header=" + Header +
                ", Body=" + Body +
                ", soapenv='" + soapenv + '\'' +
                ", bp='" + bp + '\'' +
                ", text='" + text + '\'' +
                '}';
    }
}
