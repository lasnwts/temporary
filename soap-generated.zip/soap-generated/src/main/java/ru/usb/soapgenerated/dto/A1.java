package ru.usb.soapgenerated.dto;

import org.springframework.stereotype.Component;

public class A1 {

    public A1() {
    }

    public String sourceXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\">\n" +
            "   <soapenv:Header/>\n" +
            "   <soapenv:Body>\n" +
            "      <bp:GetCommonDirectoryRequest>\n" +
            "         <bp:PartnerID>300</bp:PartnerID>\n" +
            "         <bp:ExtUserGuid>acb80275-6ecb-4bef-9f36-ed15de3e8891</bp:ExtUserGuid>\n" +
            "         <bp:DirectoryID>CB_SET_QUESTIONNAIRE</bp:DirectoryID>\n" +
            "      </bp:GetCommonDirectoryRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    public String getSourceXML() {
        return sourceXML;
    }

    public String s2 = "<Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\">   \n" +
            "   <Body>\n" +
            "      <GetCommonDirectoryRequest>\n" +
            "         <PartnerID>300</PartnerID>\n" +
            "         <ExtUserGuid>acb80275-6ecb-4bef-9f36-ed15de3e8891</ExtUserGuid>\n" +
            "         <DirectoryID>CB_SET_QUESTIONNAIRE</DirectoryID>\n" +
            "      </GetCommonDirectoryRequest>\n" +
            "   </Body>\n" +
            "</Envelope>";

    public String getS2() {
        return s2;
    }
}
