package ru.usb.soapgenerated.utils;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.stereotype.Component;
import ru.usb.soapgenerated.dto.xml.Envelope;

@Component
public class MapperXML {

    XmlMapper xmlMapper = new XmlMapper();
    public Envelope getMap(String xmlString){

        try {
            Envelope value = xmlMapper.readValue(xmlString, Envelope.class);
            return value;

        } catch (JsonProcessingException e) {
            System.out.println("Error xml converting....");
            throw new RuntimeException(e);
        }
    }


}
