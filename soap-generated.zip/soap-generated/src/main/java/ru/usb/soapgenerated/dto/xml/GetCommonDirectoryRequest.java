package ru.usb.soapgenerated.dto.xml;

public class GetCommonDirectoryRequest {

    public int PartnerID;
    public String ExtUserGuid;
    public String DirectoryID;

    public GetCommonDirectoryRequest() {
    }

    public int getPartnerID() {
        return PartnerID;
    }

    public void setPartnerID(int partnerID) {
        PartnerID = partnerID;
    }

    public String getExtUserGuid() {
        return ExtUserGuid;
    }

    public void setExtUserGuid(String extUserGuid) {
        ExtUserGuid = extUserGuid;
    }

    public String getDirectoryID() {
        return DirectoryID;
    }

    public void setDirectoryID(String directoryID) {
        DirectoryID = directoryID;
    }

    @Override
    public String toString() {
        return "GetCommonDirectoryRequest{" +
                "PartnerID=" + PartnerID +
                ", ExtUserGuid='" + ExtUserGuid + '\'' +
                ", DirectoryID='" + DirectoryID + '\'' +
                '}';
    }
}
