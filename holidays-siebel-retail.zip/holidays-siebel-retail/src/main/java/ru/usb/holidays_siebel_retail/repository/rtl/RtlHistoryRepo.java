package ru.usb.holidays_siebel_retail.repository.rtl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.usb.holidays_siebel_retail.model.rtl.RtlHistory;

@Repository
public interface RtlHistoryRepo  extends JpaRepository<RtlHistory, Long> {
}
