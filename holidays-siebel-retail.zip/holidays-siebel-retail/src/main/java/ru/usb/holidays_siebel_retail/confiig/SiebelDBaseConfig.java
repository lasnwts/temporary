package ru.usb.holidays_siebel_retail.confiig;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;

/**
 * Конфигурация Oracle
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "siebelEntityManagerFactory",
        transactionManagerRef = "siebelTransactionManager",
        basePackages = {
                "ru.usb.holidays_siebel_retail.repository.siebel"
        })
public class SiebelDBaseConfig {

    @Value("${siebel.schema}")
    private String defSchema;


    @Primary
    @Bean(name = "siebelDataSource")
    @ConfigurationProperties(prefix = "spring.siebel.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "siebelEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                       @Qualifier("siebelDataSource") DataSource dataSource) {

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");
        properties.put("hibernate.default_schema", defSchema);

        return builder.dataSource(dataSource)
                .properties(properties)
                .packages("ru.usb.holidays_siebel_retail.model.siebel")
                .build();
    }

    @Primary
    @Bean(name = "siebelTransactionManager")
    public PlatformTransactionManager bookTransactionManager(@Qualifier("siebelEntityManagerFactory") EntityManagerFactory cbEntityManagerFactory) {
        return new JpaTransactionManager(cbEntityManagerFactory);
    }


}
