package ru.usb.holidays_siebel_retail.confiig;

import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * Конфигурация SMB
 */
@Configuration
public class CIFSConfig {
    @Value("${retail.file.domain}")
    private String domain;
    @Value("${retail.file.username}")
    private String username;
    @Value("${retail.file.password}")
    private String password;

    @Bean
    public CIFSContext doAuth() throws CIFSException {
        try {
            NtlmPasswordAuthenticator auth = new NtlmPasswordAuthenticator(domain, username, password);

            Properties properties = new Properties();
            properties.setProperty("jcifs.smb.client.responseTimeout", "20000");
            PropertyConfiguration configuration = new PropertyConfiguration(properties);

            CIFSContext cifsContext = new BaseContext(configuration).withCredentials(auth);
            return cifsContext;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
