package ru.usb.holidays_siebel_retail.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Класс для подавления множества писем в случае ошибки
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Component
public class MessageError {
    private Date date; //Дата отправки сообщения

    private int count; //Кол-во отправленных

    private String subject; //тема сообщения

    private String body; //Тело сообщения

    @Override
    public String toString() {
        return "MessageError{" +
                "date=" + date +
                ", count=" + count +
                ", subject='" + subject + '\'' +
                ", body='" + body + '\'' +
                '}';
    }
}
