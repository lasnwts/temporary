package ru.usb.holidays_siebel_retail.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.holidays_siebel_retail.confiig.Configure;
import ru.usb.holidays_siebel_retail.confiig.LG;


import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * ver.1.0 21.05.2024
 * Lyapustin AS
 */


@Service
public class EmailServiceImpl implements EmailService {
    private final JavaMailSender emailSender;
    private final Configure configure;

    @Autowired
    public EmailServiceImpl(JavaMailSender emailSender, Configure configure) {
        this.emailSender = emailSender;
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Override
    public void sendSimpleEmail(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:sendSimpleEmail: Переменные toAddress, subject, message не могут быть NULL!", LG.USB_LOG_ERROR);
            return;
        }

        logger.info("{}:Send [sendSimpleEmail] email message, toAddress:{} |subject:{} [ |message:{}]", LG.USBLOGINFO, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(configure.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:sendSimpleEmail:Email подготовлен к отправке по адресу:  {}", LG.USBLOGINFO, mailRecepient);
                    try {
                        emailSender.send(simpleMailMessage);
                        logger.info("{}:sendSimpleEmail:Email отправлен отправке по адресу:{}  ", LG.USBLOGINFO, mailRecepient);
                    } catch (Exception mailEx) {
                        logger.error("{}:sendSimpleEmail:Возникла ошибка при отправке письма:", LG.USB_LOG_ERROR, mailEx);
                    }
                });
            } else {
                logger.error("{}:sendSimpleEmail:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USB_LOG_ERROR);
            }
        } else {
            logger.error("{}:sendSimpleEmail:ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USB_LOG_ERROR);
        }
    }

    @Override
    public void sendSimpleEmailThrow(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:Error:sendSimpleEmailThrow: Переменные toAddress, subject, message не могут быть NULL.", LG.USB_LOG_ERROR);
            return;
        }

        logger.info("{}:sendSimpleEmailThrow: Send email message, toAddress:{} |subject:{} [ |message:{}]", LG.USBLOGINFO, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(configure.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:sendSimpleEmailThrow:Email подготовлен к отправке по адресу:: {}", LG.USBLOGINFO, mailRecepient);
                    emailSender.send(simpleMailMessage);
                    logger.info("{}:sendSimpleEmailThrow:Email отправлен отправке по адресу::  {}", LG.USBLOGINFO, mailRecepient);
                });
            } else {
                logger.error("{}:sendSimpleEmailThrow:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USB_LOG_ERROR);
            }
        } else {
            logger.error("{}:sendSimpleEmailThrow:ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", LG.USB_LOG_ERROR);
        }
    }


    @Override
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment) {
        logger.info("{}: Send email [sendEmailWithAttachment] message, toAddress:{} |subject:{}  |message:{} |attachment:{}", LG.USBLOGINFO,
                toAddress, subject, message, attachment);
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
            messageHelper.setFrom(configure.getMailFrom());
            String[] mailRecepients = toAddress.split(",");
            messageHelper.setTo(mailRecepients);
            messageHelper.setSubject(subject);
            messageHelper.setText(message);
            FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
            messageHelper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
        } catch (MessagingException | FileNotFoundException e) {
            logger.error("{}:sendEmailWithAttachment:Возникла ошибка при отправке письма, метод sendEmailWithAttachment: [MessagingException | FileNotFoundException]:", LG.USB_LOG_ERROR, e);
        }
        try {
            emailSender.send(mimeMessage);
        } catch (Exception mailEx){
            logger.error("{}:sendEmailWithAttachment:Возникла ошибка при отправке письма, метод sendEmailWithAttachment: [Exception]:", LG.USB_LOG_ERROR, mailEx);
        }
    }
}
