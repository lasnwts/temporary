package ru.usb.holidays_siebel_retail.service.smb;

import jcifs.CIFSContext;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import jcifs.smb.SmbFileInputStream;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;


@Service
@Slf4j
@RequiredArgsConstructor
public class SmbService {
    private final CIFSContext cifsContext;
    @Value("${retail.file.url}")
    private String dirUrl;


    /**
     * Запись файла на шару
     *
     * @param fileName название файла
     * @param file     данные файла
     * @throws Exception ошибка записи
     */
    public void writeSmbFile(String fileName, byte[] file) throws Exception {
        String path = dirUrl + fileName;
        SmbFile smbFile = new SmbFile(path, cifsContext);
        try (SmbFileOutputStream smbfos = new SmbFileOutputStream(smbFile)) {
            smbfos.write(file);
            log.info("Файл {} успешно записан", fileName);
        } catch (IOException e) {
            log.error("Ошибка при записи файла {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Получение файла с шары
     *
     * @param filePath путь к файлу
     */
    public void getFile(String filePath) {
        String sambaURL = "smb://192.168.1.151/public/share/robot.txt";
        File destinationFolder = new File(filePath);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmssSSS_");
        File child = new File(destinationFolder + File.separator + fmt.format(new Date()) + "1b.csv");
        SmbFile fileToGet;

        try {
            fileToGet = new SmbFile(sambaURL);
            fileToGet.connect();
        } catch (Exception e) {
            log.error("err={}", e.getMessage());
            log.debug("Stack", e);
            return;
        }

        try (InputStream in = new BufferedInputStream(new SmbFileInputStream(fileToGet));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(child))) {
            byte[] buffer = new byte[4096];
            int len = 0; //Read length
            while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush(); //The refresh buffer output stream
        } catch (Exception e) {
            String msg = "The error occurred: " + e.getLocalizedMessage();
            log.info(msg);
        }
    }

    /**
     * Удаление файла с шары
     *
     * @param fullFileName название файла
     * @return true если удалось удалить
     */
    public boolean deleteFile(String fullFileName) {
        try (SmbFile smbFile = new SmbFile(fullFileName, cifsContext)){
            smbFile.delete();
            log.info("Файл {} успешно удален", fullFileName);
            return true;
        } catch (IOException e) {
            log.error("Ошибка при удалении файла {}", e.getMessage());
            log.debug("Stack Ошибка при удалении файла:", e);
            return false;
        }
    }
}

