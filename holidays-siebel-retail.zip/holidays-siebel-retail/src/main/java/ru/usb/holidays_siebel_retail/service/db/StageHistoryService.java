package ru.usb.holidays_siebel_retail.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.holidays_siebel_retail.confiig.LG;
import ru.usb.holidays_siebel_retail.model.rtl.RtlHistory;
import ru.usb.holidays_siebel_retail.model.siebel.StageHistory;
import ru.usb.holidays_siebel_retail.model.siebel.StageHistory2;
import ru.usb.holidays_siebel_retail.repository.rtl.RtlHistoryRepo;
import ru.usb.holidays_siebel_retail.repository.siebel.StageHistoryRepo;
import ru.usb.holidays_siebel_retail.repository.siebel.StageHistoryRepo2;
import ru.usb.holidays_siebel_retail.service.mail.ServiceMailError;

import javax.persistence.EntityManager;
import java.util.function.Consumer;

@Log4j2
@Service
public class StageHistoryService {

    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final StageHistoryRepo historyRepo;
    private final RtlHistoryRepo rtlHistoryRepo;
    private final StageHistoryRepo2 historyRepo2;

    @Autowired
    public StageHistoryService(EntityManager entityManager, ServiceMailError sendMailError, StageHistoryRepo historyRepo, RtlHistoryRepo rtlHistoryRepo, StageHistoryRepo2 historyRepo2) {
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.historyRepo = historyRepo;
        this.rtlHistoryRepo = rtlHistoryRepo;
        this.historyRepo2 = historyRepo2;
    }


    public void test(){
        historyRepo.findAll().forEach(new Consumer<StageHistory>() {
            @Override
            public void accept(StageHistory stageHistory) {
                log.info("{}: History:{} ", LG.USBLOGINFO, stageHistory);
                if (stageHistory.getBatch_id()==20){
                    log.info("Найден batch_id={}", stageHistory.getBatch_id());
                    stageHistory.setExp_doc_status("Новый статус");
                    historyRepo.saveAndFlush(stageHistory);
                }
            }
        });

        rtlHistoryRepo.findAll().forEach(new Consumer<RtlHistory>() {
            @Override
            public void accept(RtlHistory rtlHistory) {
                log.info("{}: Rtl History={}", LG.USBLOGINFO, rtlHistory);
            }
        });


        historyRepo2.getBatchId(10).forEach(new Consumer<StageHistory2>() {
            @Override
            public void accept(StageHistory2 stageHistory2) {
                stageHistory2.setExp_blob_status("historyRepo2, batch_id=10");
                historyRepo2.saveAndFlush(stageHistory2);
                log.info("{} historyRepo2 // batch_id=10, {}", LG.USBLOGINFO, stageHistory2);
            }
        });


    }
}
