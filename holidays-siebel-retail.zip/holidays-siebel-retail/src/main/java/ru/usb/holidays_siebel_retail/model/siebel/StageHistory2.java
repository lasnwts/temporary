package ru.usb.holidays_siebel_retail.model.siebel;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "stage_history")
public class StageHistory2 {

    @Id
    @Column(name = "batch_id")
    private int batch_id;

    @Column(name = "export_status")
    private String export_status;

    @Column(name = "import_status")
    private String import_status;

    @Column(name = "exp_doc_status")
    private String exp_doc_status;

    @Column(name = "exp_blob_status")
    private String exp_blob_status;

}