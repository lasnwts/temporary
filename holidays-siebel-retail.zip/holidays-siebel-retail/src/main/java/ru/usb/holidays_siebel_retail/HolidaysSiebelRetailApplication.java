package ru.usb.holidays_siebel_retail;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.holidays_siebel_retail.confiig.Configure;
import ru.usb.holidays_siebel_retail.confiig.LG;
import ru.usb.holidays_siebel_retail.service.db.StageHistoryService;
import ru.usb.holidays_siebel_retail.service.smb.SmbService;

import java.nio.file.Files;
import java.nio.file.Paths;

@Log4j2
@SpringBootApplication
public class HolidaysSiebelRetailApplication implements CommandLineRunner {

	@Autowired
	StageHistoryService historyService;

	@Autowired
	SmbService smbService;

	private final Configure configure;

	@Autowired
	public HolidaysSiebelRetailApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(HolidaysSiebelRetailApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:0.0.10}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (holidays-siebel-retail)")
				.version(appVersion)
				.description("API Transfer of credit holiday schedules from Retail to Siebel.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {

		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		log.info("{}: Created by 07.10.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", LG.USBLOGINFO);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", LG.USBLOGINFO);
		log.info("{}: Описание пакетов                  : ", LG.USBLOGINFO);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		log.info("{}: Name of service                   : {}", LG.USBLOGINFO, configure.getAppName());
		log.info("{}: Description of service            : {}", LG.USBLOGINFO, configure.getAppDescription());
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		log.info("{}: Modified reason                   : 0.0.10", LG.USBLOGINFO);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", LG.USBLOGINFO);

		historyService.test();

		smbService.getFile("C:\\AppServer\\Data\\SMB");

		byte[] array = Files.readAllBytes(Paths.get("C:\\AppServer\\Data\\SMB\\20241010121045568_1b.csv"));
		smbService.writeSmbFile("test-300924.txt", array);
		smbService.deleteFile("smb://192.168.1.151/public/share/test-300924.txt");
	}
}
