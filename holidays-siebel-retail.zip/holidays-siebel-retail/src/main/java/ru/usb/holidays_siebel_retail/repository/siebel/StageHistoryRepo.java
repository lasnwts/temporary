package ru.usb.holidays_siebel_retail.repository.siebel;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.usb.holidays_siebel_retail.model.siebel.StageHistory;

@Repository
public interface StageHistoryRepo extends JpaRepository<StageHistory, Long> {

}
