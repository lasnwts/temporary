package ru.usb.holidays_siebel_retail.utils;

import org.springframework.stereotype.Component;

@Component
public class Sutils {

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }


}
