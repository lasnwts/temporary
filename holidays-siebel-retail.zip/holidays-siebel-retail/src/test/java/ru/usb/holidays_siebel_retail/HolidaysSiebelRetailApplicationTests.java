package ru.usb.holidays_siebel_retail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolidaysSiebelRetailApplicationTests {

	@Test
	void contextLoads() {
	}

}
