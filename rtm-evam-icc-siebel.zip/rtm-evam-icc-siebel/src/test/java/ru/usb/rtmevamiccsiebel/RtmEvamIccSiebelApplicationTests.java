package ru.usb.rtmevamiccsiebel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtmEvamIccSiebelApplicationTests {

	@Test
	void contextLoads() {
	}

}
