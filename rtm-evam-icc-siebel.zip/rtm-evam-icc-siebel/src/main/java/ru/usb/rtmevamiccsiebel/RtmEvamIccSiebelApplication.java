package ru.usb.rtmevamiccsiebel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtmEvamIccSiebelApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtmEvamIccSiebelApplication.class, args);
	}

}
