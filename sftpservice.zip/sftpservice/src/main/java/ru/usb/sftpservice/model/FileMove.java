package ru.usb.sftpservice.model;

/**
 * Класс для передачи информации по файлам
 */
public class FileMove {

    //Короткое имя файла
    private String filename;

    //Длинное имя файла с путем
    private String absoluteFilename;

    //Размер файла в байтах
    private long fileSize;

    //Ошибка при работе с файлом
    private String errorMessage;

    //Директория , где сохранен файл
    private String directory;

    /**
     * Результат работы с файлом
     * true - успешно
     * alse - не успешно
     */
    private boolean workResult;

    public FileMove() {
    }

    public FileMove(String filename, String absoluteFilename, long fileSize, String errorMessage, boolean workResult) {
        this.filename = filename;
        this.absoluteFilename = absoluteFilename;
        this.fileSize = fileSize;
        this.errorMessage = errorMessage;
        this.workResult = workResult;
    }

    public FileMove(String filename, String absoluteFilename, long fileSize, String errorMessage, String directory, boolean workResult) {
        this.filename = filename;
        this.absoluteFilename = absoluteFilename;
        this.fileSize = fileSize;
        this.errorMessage = errorMessage;
        this.directory = directory;
        this.workResult = workResult;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getAbsoluteFilename() {
        return absoluteFilename;
    }

    public void setAbsoluteFilename(String absoluteFilename) {
        this.absoluteFilename = absoluteFilename;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isWorkResult() {
        return workResult;
    }

    public void setWorkResult(boolean workResult) {
        this.workResult = workResult;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    @Override
    public String toString() {
        return "FileMove{" +
                "filename='" + filename + '\'' +
                ", absoluteFilename='" + absoluteFilename + '\'' +
                ", fileSize=" + fileSize +
                ", errorMessage='" + errorMessage + '\'' +
                ", workResult=" + workResult +
                '}';
    }
}
