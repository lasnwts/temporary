package ru.usb.sftpservice.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftpservice.configure.Configure;
import ru.usb.sftpservice.model.FileMove;
import ru.usb.sftpservice.utils.WorkWithFiles;

import java.io.File;

@Service
public class SftpGetFileService {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    Logger logger = LoggerFactory.getLogger(SftpGetFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public FileMove getFileToSftp(String file, String sftpDir) {


        if (file == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getFileToSftp(file)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }


        if (sftpDir == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getFileToSftp(sftpDir)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        //Печатаем параметры соединения
        logStatusSftp();

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();
//        try {
//         //   jSch.setKnownHosts(configure.getSftp_host());
//         //   jSch.addIdentity(configure.getSftp_key_file());
//
//        } catch (JSchException e) {
//            throw new RuntimeException(e);
//        }

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            session = jSch.getSession(configure.getSftp_user(), configure.getSftp_host(), configure.getSftp_port());
            session.setPassword(configure.getSftp_password());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:GetFileToSftp(file).Session = Error!!");
            logger.error("Session.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return null;
        }

        logger.debug(session.toString());

        /**
         * Создаем канал
         */
        ChannelSftp channel = null;
        try {
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:GetFileToSftp(file).ChannelSftp = Error!!");
            logger.error("ChannelSftp.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (channel.isConnected()) {
                channel.disconnect();
            }
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return null;
        }

        /**
         * Переходим в нужный каталог
         */
        if (configure.getSftpDirUpload() != null) {
            try {
                channel.cd("/" + sftpDir);
            } catch (SftpException e) {
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("SftpService:GetFileToSftp(file).channel.cd({})", configure.getSftpDirUpload());
                logger.error("channel.cd.error::{}", e.getMessage());
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                if (channel.isConnected()) {
                    channel.disconnect();
                }
                if (session.isConnected()) {
                    session.disconnect();
                }
                if (jSch != null) {
                    jSch = null;
                }
                return null;
            }
            logger.info("channel cd directory: /" + configure.getSftpDirUpload());
        }

        /**
         * Отправка файла на sftp
         */
        try {
            channel.get(file, configure.getNetFileShare() + File.separator + file);
            logger.info("File={} download successfully from sftp, to directory:{}", file, configure.getSftpDirDownload() + File.separator + file);
        } catch (SftpException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:GetFileToSftp(file).channel.get({})", sftpDir + "/" + file);
            logger.error("channel.Get.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            setFinalConnected(jSch, session, channel);
            return null;
        }

        //Закрываем соединение

        setFinalConnected(jSch, session, channel);

        File f = new File(configure.getNetFileShare() + File.separator + file);
        if (withFiles.checkFileExists(f)) {
            FileMove fileMove = new FileMove();
            fileMove.setFilename(file);
            fileMove.setFileSize(f.length());
            fileMove.setAbsoluteFilename(f.getAbsolutePath());
            fileMove.setDirectory(configure.getNetFileShare());
            fileMove.setWorkResult(true);
            fileMove.setErrorMessage("");
            return fileMove; //Файл успешно загружен
        } else {
            return null;
        }
    }

    /**
     * Печать статуса соединения
     */
    private void logStatusSftp() {

        logger.info("SftpFileCopy :: Preparing for a session with the sftp server with parameters: \n" +
                "host: " + configure.getSftp_host() + ";\n" +
                "port: " + configure.getSftp_port() + ";\n" +
                "user: " + configure.getSftp_user() + ";\n" +
                "key: " + configure.getSftp_key_file() + ";\n" +
                "know_hosts: " + configure.getSftp_know_host_file() + ";\n");
    }

    /**
     * Передача версии сервиса
     *
     * @return
     */
    public String getVersion() {
        return configure.getAppVersion();
    }

    /**
     * Имя сервиса
     *
     * @return
     */
    public String getAppName() {
        return configure.getAppName();
    }


    /**
     * закрытие соединений
     *
     * @param jSch    - настройка соединения
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(JSch jSch, Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
        if (jSch != null) {
            jSch = null;
        }
    }
}
