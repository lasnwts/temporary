package ru.usb.sftpservice.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    /**
     * Нустройка SFTP сервере
     */

    @Value("${sftp.host}")
    private String sftp_host;

    @Value("${sftp.port}")
    private int sftp_port;

    @Value("${sftp.user}")
    private String sftp_user;

    @Value("${sftp.password}")
    private String sftp_password;

    @Value("${sftp.know_host_file}")
    private String sftp_know_host_file;

    @Value("${sftp.key_file}")
    private String sftp_key_file;

    /**
     * Директории на sftp
     */
    @Value("${sftp.directory.upload}")
    private String sftpDirUpload;

    @Value("${sftp.directory.download}")
    private String sftpDirDownload;

    @Value("${sftp.directory.done}")
    private String sftpDirDone;

    @Value("${net.file.share}")
    private String netFileShare;


    /**
     *  Параметры версии Info, description
     */
    @Value("${info.app.name}")
    private String appName;

    @Value("${info.app.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:Проверка ЗСК – ошибка передачи данных}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    /**
     * Реализация
     */
    public String getSftp_host() {
        return sftp_host;
    }

    public int getSftp_port() {
        return sftp_port;
    }

    public String getSftp_user() {
        return sftp_user;
    }

    public String getSftp_password() {
        return sftp_password;
    }

    public String getSftp_know_host_file() {
        return sftp_know_host_file;
    }

    public String getSftp_key_file() {
        return sftp_key_file;
    }

    /**
     * Версия и директория
     */

    public String getSftpDirUpload() {
        return sftpDirUpload;
    }

    public String getSftpDirDownload() {
        return sftpDirDownload;
    }

    public String getSftpDirDone() {
        return sftpDirDone;
    }

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getNetFileShare() {
        return netFileShare;
    }
}
