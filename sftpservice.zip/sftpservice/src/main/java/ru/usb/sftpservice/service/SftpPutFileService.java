package ru.usb.sftpservice.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftpservice.configure.Configure;
import ru.usb.sftpservice.utils.WorkWithFiles;

import java.io.File;

/**
 * Сервис для работы с sftp сервером
 * 1. Загрузка на сервер одного файла
 * 2. Загрузка на сервере группы файлов
 * 3. Скачивание с сервера 1 файла
 * 4. Удаление на сервере одного файла
 * 5. Проверка наличия каталогов на сервере sftp
 */
@Service
public class SftpPutFileService {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    Logger logger = LoggerFactory.getLogger(SftpPutFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public boolean putFileToSftp(File file) {


        if (file == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:putFileToSftp(file)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return false;
        }


        if (!withFiles.checkFileExists(file.getAbsolutePath())) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Файла, не существует {}", file.getAbsolutePath());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return false;
        }

        //Печатаем параметры соединения
        logStatusSftp();

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();
//        try {
//         //   jSch.setKnownHosts(configure.getSftp_host());
//         //   jSch.addIdentity(configure.getSftp_key_file());
//
//        } catch (JSchException e) {
//            throw new RuntimeException(e);
//        }

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            session = jSch.getSession(configure.getSftp_user(), configure.getSftp_host(), configure.getSftp_port());
            session.setPassword(configure.getSftp_password());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:putFileToSftp(file).Session = Error!!");
            logger.error("Session.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return false;
        }

        logger.debug(session.toString());

        /**
         * Создаем канал
         */
        ChannelSftp channel = null;
        try {
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:putFileToSftp(file).ChannelSftp = Error!!");
            logger.error("ChannelSftp.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (channel.isConnected()) {
                channel.disconnect();
            }
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return false;
        }

        /**
         * Переходим в нужный каталог
         */
        if (configure.getSftpDirUpload() != null) {
            try {
                channel.cd("/" + configure.getSftpDirUpload());
            } catch (SftpException e) {
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("SftpService:putFileToSftp(file).channel.cd({})", configure.getSftpDirUpload());
                logger.error("channel.cd.error::{}", e.getMessage());
                logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                if (channel.isConnected()) {
                    channel.disconnect();
                }
                if (session.isConnected()) {
                    session.disconnect();
                }
                if (jSch != null) {
                    jSch = null;
                }
                return false;
            }
            logger.info("channel cd directory: /" + configure.getSftpDirUpload());
        }

        /**
         * Отправка файла на sftp
         */
        try {
            channel.put(file.getAbsolutePath(), file.getName());
            logger.info("File={} upload to sftp, successfully", file.getName());
        } catch (SftpException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:putFileToSftp(file).channel.put({})", file.getAbsolutePath());
            logger.error("channel.put.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            setFinalConnected(jSch, session, channel);
            return false;
        }

        //Закрываем соединение
        setFinalConnected(jSch, session, channel);
        return true; //Файл успешно загружен
    }

    /**
     * Печать статуса соединения
     */
    private void logStatusSftp() {

        logger.info("SftpFileCopy :: Preparing for a session with the sftp server with parameters: \n" +
                "host: " + configure.getSftp_host() + ";\n" +
                "port: " + configure.getSftp_port() + ";\n" +
                "user: " + configure.getSftp_user() + ";\n" +
                "key: " + configure.getSftp_key_file() + ";\n" +
                "know_hosts: " + configure.getSftp_know_host_file() + ";\n");
    }

    /**
     * Передача версии сервиса
     *
     * @return
     */
    public String getVersion() {
        return configure.getAppVersion();
    }

    /**
     * Имя сервиса
     *
     * @return
     */
    public String getAppName() {
        return configure.getAppName();
    }


    /**
     * закрытие соединений
     * @param jSch  - настройка соединения
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(JSch jSch, Session session, ChannelSftp channel){
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
        if (jSch != null) {
            jSch = null;
        }
    }

}
