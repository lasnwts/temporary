package ru.usb.sftpservice.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftpservice.configure.Configure;
import ru.usb.sftpservice.utils.WorkWithFiles;

@Service
public class SftpDelFileService {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    Logger logger = LoggerFactory.getLogger(SftpDelFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public boolean delFile(String file, String sftpDirectory) {


        if (file == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:delFileToSftp(file)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return false;
        }

        if (sftpDirectory == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:delFileToSftp(sftpDirectory)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return false;
        }

        //Печатаем параметры соединения
        logStatusSftp();

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();
//        try {
//         //   jSch.setKnownHosts(configure.getSftp_host());
//         //   jSch.addIdentity(configure.getSftp_key_file());
//
//        } catch (JSchException e) {
//            throw new RuntimeException(e);
//        }

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            session = jSch.getSession(configure.getSftp_user(), configure.getSftp_host(), configure.getSftp_port());
            session.setPassword(configure.getSftp_password());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:delFileToSftp(file).Session = Error!!");
            logger.error("Session.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return false;
        }

        logger.debug(session.toString());

        /**
         * Создаем канал
         */
        ChannelSftp channel = null;
        try {
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:delFileToSftp(file).ChannelSftp = Error!!");
            logger.error("ChannelSftp.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (channel.isConnected()) {
                channel.disconnect();
            }
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return false;
        }


        /**
         * Отправка файла на sftp
         */
        try {
            // use the get method , if you are using android remember to remove "file://" and use only the relative path
            channel.rm(sftpDirectory + "/" + file);

            logger.info("File={} delete to sftp, successfully", file);
        } catch (SftpException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:delFileToSftp(file).channel.del({})", file);
            logger.error("channel.rm.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            setFinalConnected(jSch, session, channel);
            return false;
        }

        //Закрываем соединение
        setFinalConnected(jSch, session, channel);
        return true; //Файл успешно загружен
    }

    /**
     * Печать статуса соединения
     */
    private void logStatusSftp() {

        logger.info("SftpFileCopy :: Preparing for a session with the sftp server with parameters: \n" +
                "host: " + configure.getSftp_host() + ";\n" +
                "port: " + configure.getSftp_port() + ";\n" +
                "user: " + configure.getSftp_user() + ";\n" +
                "key: " + configure.getSftp_key_file() + ";\n" +
                "know_hosts: " + configure.getSftp_know_host_file() + ";\n");
    }

    /**
     * Передача версии сервиса
     *
     * @return
     */
    public String getVersion() {
        return configure.getAppVersion();
    }

    /**
     * Имя сервиса
     *
     * @return
     */
    public String getAppName() {
        return configure.getAppName();
    }


    /**
     * закрытие соединений
     *
     * @param jSch    - настройка соединения
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(JSch jSch, Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
        if (jSch == null) {
        } else {
            jSch = null;
        }
    }

}
