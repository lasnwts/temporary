package ru.usb.sftpservice.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sftpservice.configure.Configure;
import ru.usb.sftpservice.utils.WorkWithFiles;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

@Service
public class SftpListFileService {


    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    Logger logger = LoggerFactory.getLogger(SftpListFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public List<String> getListFileToSftp(String sftpDirectory) {


        if (sftpDirectory == null) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getListFileToSftp(sftpDirectory)=null!!");
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();
//        try {
//         //   jSch.setKnownHosts(configure.getSftp_host());
//         //   jSch.addIdentity(configure.getSftp_key_file());
//
//        } catch (JSchException e) {
//            throw new RuntimeException(e);
//        }

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            session = jSch.getSession(configure.getSftp_user(), configure.getSftp_host(), configure.getSftp_port());
            session.setPassword(configure.getSftp_password());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getListFileToSftp.Session = Error!!");
            logger.error("Session.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return null;
        }

        logger.debug(session.toString());

        /**
         * Создаем канал
         */
        ChannelSftp channel = null;
        try {
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
        } catch (JSchException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getListFileToSftp.ChannelSftp = Error!!");
            logger.error("ChannelSftp.error:{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            if (channel.isConnected()) {
                channel.disconnect();
            }
            if (session.isConnected()) {
                session.disconnect();
            }
            if (jSch != null) {
                jSch = null;
            }
            return null;
        }


        /**
         * Отправка файла на sftp
         */
        List<String> listFiles = new ArrayList<>();
        try {

            Vector<ChannelSftp.LsEntry>  filelist = channel.ls(sftpDirectory);

            for (int i = 0; i < filelist.size(); i++) {
                if (filelist.get(i).getFilename().equals(".") || filelist.get(i).getFilename().equals("..")) {
                    //пропускаем каталоги
                } else {
                    listFiles.add(filelist.get(i).getFilename());
                }
            }

        } catch (SftpException e) {
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("SftpService:getListFileToSftp(file).channel.ls(sftpDirectory)({})", sftpDirectory);
            logger.error("channel.ls.error::{}", e.getMessage());
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            setFinalConnected(jSch, session, channel);
            return null;
        }
        //Закрываем соединение
        setFinalConnected(jSch, session, channel);
        if (listFiles.size() == 0) {
            return null;
        } else {
            return listFiles; //Список файлов
        }
    }

    /**
     * Печать статуса соединения
     */
    private void logStatusSftp() {

        logger.info("SftpFileCopy :: Preparing for a session with the sftp server with parameters: \n" +
                "host: " + configure.getSftp_host() + ";\n" +
                "port: " + configure.getSftp_port() + ";\n" +
                "user: " + configure.getSftp_user() + ";\n" +
                "key: " + configure.getSftp_key_file() + ";\n" +
                "know_hosts: " + configure.getSftp_know_host_file() + ";\n");
    }

    /**
     * Передача версии сервиса
     *
     * @return
     */
    public String getVersion() {
        return configure.getAppVersion();
    }

    /**
     * Имя сервиса
     *
     * @return
     */
    public String getAppName() {
        return configure.getAppName();
    }


    /**
     * закрытие соединений
     *
     * @param jSch    - настройка соединения
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(JSch jSch, Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
        if (jSch != null) {
            jSch = null;
        }
    }

}
