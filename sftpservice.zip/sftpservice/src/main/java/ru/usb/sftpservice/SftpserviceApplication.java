package ru.usb.sftpservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.sftpservice.service.SftpDelFileService;
import ru.usb.sftpservice.service.SftpGetFileService;
import ru.usb.sftpservice.service.SftpListFileService;
import ru.usb.sftpservice.service.SftpPutFileService;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.function.Consumer;

@SpringBootApplication
public class SftpserviceApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(SftpserviceApplication.class);

	@Autowired
	SftpPutFileService sftpService;

	@Autowired
	SftpDelFileService sftpDelFileService;

	@Autowired
	SftpGetFileService sftpGetFileService;

	@Autowired
	SftpListFileService sftpListFileService;


	public static void main(String[] args) {
		SpringApplication.run(SftpserviceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// Показываем версию
		logger.info("18.07.2023г. v.0.0.1");
		logger.info("-----------------------------------------------");
		logger.info("| Service:" + sftpService.getAppName());
		logger.info("| Version of service:" + sftpService.getVersion());
		logger.info("-----------------------------------------------");
		logger.info("");
		Path path = Paths.get("C:\\AppServer\\Data\\ftp\\123-uploaded");
		File file = new File("C:\\AppServer\\Data\\ftp\\123-uploaded");
		sftpService.putFileToSftp(file);
		sftpGetFileService.getFileToSftp("123-uploaded", "upload/upload");
		List<String> fileList = sftpListFileService.getListFileToSftp("upload/upload");
		if (fileList==null){
			logger.info("список файлов пуст....");
		} else {
			fileList.forEach(new Consumer<String>() {
				@Override
				public void accept(String s) {
					logger.info("File={}", s);
				}
			});
		}
		sftpDelFileService.delFile("123-uploaded", "/upload/upload");

	}
}
