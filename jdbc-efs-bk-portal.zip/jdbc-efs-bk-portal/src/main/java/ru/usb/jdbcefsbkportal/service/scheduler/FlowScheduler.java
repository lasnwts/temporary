package ru.usb.jdbcefsbkportal.service.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.model.Efs_Offices;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsOfficeRepoBK;
import ru.usb.jdbcefsbkportal.service.BaseProcess;

import java.util.Date;
import java.util.function.Consumer;

@Component
@EnableScheduling
public class FlowScheduler {

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    private final BaseProcess baseProcess;

    @Autowired
    public FlowScheduler(BaseProcess baseProcess) {
        this.baseProcess = baseProcess;
    }

    /**
     * Scheduler 1.  На 12 часов в будни, с понедельника по пятницу
     */
    @Scheduled(cron = "${interval-in-cron}")
    public void cronScheduler12() {
        logger.info("{} Сработал таймер {} часов дня. ", TG.UsbLogInfo, new Date());
        baseProcess.startFlows();
    }
}
