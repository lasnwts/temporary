package ru.usb.jdbcefsbkportal.configure;

import java.util.HashMap;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Конфигурация Oracle
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "efsTestEntityManagerFactory",
        transactionManagerRef = "efsTestTransactionManager",
        basePackages = {
                "ru.usb.jdbcefsbkportal.dto.efs.cx.repository"
        })
public class ORAConfig {

    @Bean(name = "efsTestDataSource")
    @ConfigurationProperties(prefix = "spring.efs.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "efsTestEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean EntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                       @Qualifier("efsTestDataSource") DataSource dataSource) {

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", "update");
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");

        return builder.dataSource(dataSource)
                .properties(properties)
                .packages("ru.usb.jdbcefsbkportal.dto.efs.cx.model")
//                .persistenceUnit("Test2")
                .build();
    }


    @Bean(name = "efsTestTransactionManager")
    public PlatformTransactionManager bookTransactionManager(@Qualifier("efsTestEntityManagerFactory") EntityManagerFactory efsTestEntityManagerFactory) {
        return new JpaTransactionManager(efsTestEntityManagerFactory);
    }


}
