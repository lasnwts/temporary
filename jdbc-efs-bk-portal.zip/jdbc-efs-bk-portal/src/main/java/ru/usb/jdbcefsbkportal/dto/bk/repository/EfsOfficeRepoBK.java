package ru.usb.jdbcefsbkportal.dto.bk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.bk.model.Efs_Offices;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface EfsOfficeRepoBK extends JpaRepository<Efs_Offices, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM  dbo.EFS_OFFICES")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [ID],[SHORT_TITLE],[ADDRESS],[CHIEF_CP],[TYPE_TP],[REGNUM],[STATE],[STATE_TP],[CODE_FEM],[CODE_CFT],[CODE_IBSO],[CODE_CRIF],[LAST_MODIFIED] FROM [dbo].[EFS_OFFICES]")
    List<Efs_Offices> getListAll();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [ID],[SHORT_TITLE],[ADDRESS],[CHIEF_CP],[TYPE_TP],[REGNUM],[STATE],[STATE_TP],[CODE_FEM],[CODE_CFT],[CODE_IBSO],[CODE_CRIF],[LAST_MODIFIED] FROM [dbo].[EFS_OFFICES]")
    Stream<Efs_Offices> getStreamAll();
}
