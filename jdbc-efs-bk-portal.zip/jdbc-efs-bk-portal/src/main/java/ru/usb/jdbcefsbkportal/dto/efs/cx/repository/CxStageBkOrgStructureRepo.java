package ru.usb.jdbcefsbkportal.dto.efs.cx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkOrgStructure;

import javax.persistence.QueryHint;
import javax.transaction.Transactional;
import java.sql.Date;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface CxStageBkOrgStructureRepo extends JpaRepository<CxStageBkOrgStructure, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM CX_STAGE_BK_ORG_STRUCTURE")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT DEP_ID,DEP_NAME,HIGHER_DEP_ID,DEP_ID_L1,DEP_NAME_L1,DEP_ID_L2,DEP_NAME_L2,DEP_ID_L3,DEP_NAME_L3," +
            "DEP_ID_L4,DEP_NAME_L4,DEP_ID_L5,DEP_NAME_L5,ID,STATE,LAST_MODIFIED FROM CX_STAGE_BK_ORG_STRUCTURE")
    List<CxStageBkOrgStructure> getListAll();


    @Modifying(clearAutomatically = true)
    @Transactional
    @Query(value = "INSERT INTO CX_STAGE_BK_ORG_STRUCTURE (DEP_ID,DEP_NAME,HIGHER_DEP_ID,DEP_ID_L1,DEP_NAME_L1,DEP_ID_L2,DEP_NAME_L2,DEP_ID_L3," +
            "DEP_NAME_L3,DEP_ID_L4,DEP_NAME_L4,DEP_ID_L5,DEP_NAME_L5,ID,STATE,LAST_MODIFIED) "
            + "VALUES (:DEP_ID,:DEP_NAME,:HIGHER_DEP_ID,:DEP_ID_L1,:DEP_NAME_L1,:DEP_ID_L2,:DEP_NAME_L2,:DEP_ID_L3,:DEP_NAME_L3," +
            ":DEP_ID_L4,:DEP_NAME_L4,:DEP_ID_L5,:DEP_NAME_L5,:ID,:STATE,:LAST_MODIFIED)", nativeQuery = true)
    void insert(@Param("DEP_ID") String depId, @Param("DEP_NAME") String depName, @Param("HIGHER_DEP_ID") String higherDepId,
                @Param("DEP_ID_L1") String depIdL1, @Param("DEP_NAME_L1") String depNameL1, @Param("DEP_ID_L2") String depIdL2,
                @Param("DEP_NAME_L2") String depNameL2, @Param("DEP_ID_L3") String depIdL3, @Param("DEP_NAME_L3") String depNameL3,
                @Param("DEP_ID_L4") String depIdL4, @Param("DEP_NAME_L4") String depNameL4, @Param("DEP_ID_L5") String depIdL5,
                @Param("DEP_NAME_L5") String depNameL5, @Param("ID") String id, @Param("STATE") String state,
                 @Param("LAST_MODIFIED") Date lastModified);
}
