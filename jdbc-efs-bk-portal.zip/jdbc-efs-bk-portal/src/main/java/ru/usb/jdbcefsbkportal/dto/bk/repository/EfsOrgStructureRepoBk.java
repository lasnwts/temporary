package ru.usb.jdbcefsbkportal.dto.bk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsOrgStructure;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface EfsOrgStructureRepoBk extends JpaRepository<EfsOrgStructure, Long> {


    @Query(nativeQuery = true, value = "SELECT count(*) FROM  dbo.EFS_ORG_STRUCTURE")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [DEP_ID],[DEP_NAME],[HIGHER_DEP_ID],[DEP_ID_L1],[DEP_NAME_L1],[DEP_ID_L2],[DEP_NAME_L2],[DEP_ID_L3],[DEP_NAME_L3],[DEP_ID_L4],[DEP_NAME_L4],[DEP_ID_L5],[DEP_NAME_L5],[ID],[STATE],[LAST_MODIFIED] FROM [dbo].[EFS_ORG_STRUCTURE]")
    List<EfsOrgStructure> getListAll();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [DEP_ID],[DEP_NAME],[HIGHER_DEP_ID],[DEP_ID_L1],[DEP_NAME_L1],[DEP_ID_L2],[DEP_NAME_L2],[DEP_ID_L3],[DEP_NAME_L3],[DEP_ID_L4],[DEP_NAME_L4],[DEP_ID_L5],[DEP_NAME_L5],[ID],[STATE],[LAST_MODIFIED] FROM [dbo].[EFS_ORG_STRUCTURE]")
    Stream<EfsOrgStructure> getStreamAll();

}
