package ru.usb.jdbcefsbkportal.configure;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@ConfigurationProperties
@Data
public class Configure {

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Управление потоками.
     * Можно стартовать 1 поток. Если поток стартовал, ждем его завершения
     */
    //Имя потока
    private volatile String flowName; //Имя потока
    private Date flowStartDate; //Дата и время запуска потока
    private volatile boolean flowWorkState; //Статус потока. false - не запущен, можно запускать


    public synchronized String getSyncFlowName() {
        return flowName;
    }

    public synchronized Date getSyncFlowStartDate() {
        return flowStartDate;
    }

    public synchronized boolean getSyncFlowWorkState() {
        return flowWorkState;
    }

    public synchronized void setSyncFlowName(String flowName) {
        this.flowName = flowName;
    }

    public synchronized void setSyncFlowStartDate(Date flowStartDate) {
        this.flowStartDate = flowStartDate;
    }

    public synchronized void setSyncFlowWorkState(boolean flowWorkState) {
        this.flowWorkState = flowWorkState;
    }

    /**
     * Кол-во записей в таблицах
     */

    //БК портал
    private int efsOffice;
    private int efsStaff;
    private int efsOrgStructure;

    //ЕФС
    private int cxOffice;
    private int cxOrgStructure;
    private int cxStaff;

    /**
     * Включение или отключение сервиса
     * false - сервис отключен
     * true - включен
     */
    @Value("${service.app.include}")
    private boolean include;

    /**
     * Секция о программе
     */

    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;


    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    /**
     *  Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     *  Уровень логирования
     */
    @Value("${service.log.debug:false}")
    private boolean logDebug;
}
