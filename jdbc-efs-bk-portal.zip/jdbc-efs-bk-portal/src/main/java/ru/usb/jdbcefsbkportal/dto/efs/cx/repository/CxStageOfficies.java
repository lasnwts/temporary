package ru.usb.jdbcefsbkportal.dto.efs.cx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkOfficies;

import javax.persistence.QueryHint;
import javax.transaction.Transactional;
import java.sql.Date;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface CxStageOfficies extends JpaRepository<CxStageBkOfficies, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM CX_STAGE_BK_OFFICES")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT * FROM CX_STAGE_BK_OFFICES")
    List<CxStageBkOfficies> getListAll();

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query(value = "INSERT INTO CX_STAGE_BK_OFFICES (ADDRESS, CHIEF_CP, CODE_CFT, CODE_CRIF, CODE_IBSO, CODE_FEM, LAST_MODIFIED, REGNUM, SHORT_TITLE, STATE, STATE_TP, TYPE_TP, ID) "
            + "VALUES (:ADDRESS, :CHIEF_CP, :CODE_CFT, :CODE_CRIF, :CODE_IBSO, :CODE_FEM, :LAST_MODIFIED, :REGNUM, :SHORT_TITLE, :STATE, :STATE_TP, :TYPE_TP, :ID)", nativeQuery = true)
    void insert(@Param("ADDRESS") String address, @Param("CHIEF_CP") String chiefCp, @Param("CODE_CFT") String codeCft,
                @Param("CODE_CRIF") String codeCrif, @Param("CODE_IBSO") String codeIbso, @Param("CODE_FEM") String codeFem,
                @Param("LAST_MODIFIED") Date lastModified, @Param("REGNUM") String regnum, @Param("SHORT_TITLE") String shortTitle,
                @Param("STATE") String state, @Param("STATE_TP") String stateIp, @Param("TYPE_TP") String typeTp,
                @Param("ID") String id);

}
