package ru.usb.jdbcefsbkportal.service.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.model.Efs_Offices;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsOfficeRepoBK;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkOfficies;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageOfficies;
import ru.usb.jdbcefsbkportal.mapper.MapperEfs;
import ru.usb.jdbcefsbkportal.service.mail.ServiceMailError;

import javax.persistence.EntityManager;
import java.util.stream.Stream;


@Service
public class FlowOffice {

    @Value("${service.app.update-record:false}")
    private boolean mode; // Режим работы, true - обновляем запись, false - insert


    int lineCount;

    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final EfsOfficeRepoBK jpaFlow; //MS SQL источник информации
    private final CxStageOfficies cxStage; //Oracle получатель информации
    private final MapperEfs mapperEfs; //маппер объектов

    @Autowired
    public FlowOffice(EntityManager entityManager, ServiceMailError sendMailError, EfsOfficeRepoBK jpaFlow,
                      CxStageOfficies cxStage, MapperEfs mapperEfs) {
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.jpaFlow = jpaFlow;
        this.cxStage = cxStage;
        this.mapperEfs = mapperEfs;
    }

    private final Logger logger = LoggerFactory.getLogger(FlowOffice.class);

    @Transactional(value = "bkTransactionManager", readOnly = true)
    public boolean startOfficeFlow() {

        //Получаем список записей из базы
        Stream<Efs_Offices> fTableStream = null;

        try {
            int recordCount = jpaFlow.getCount();
            logger.info("{} Число записей в таблице: [dbo].[EFS_OFFICES]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                logger.info("{} Поскольку число записей в таблице:  [dbo].[EFS_OFFICES]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return false;
            }
            fTableStream = jpaFlow.getStreamAll();
            if (!checkStream(fTableStream)) {
                logger.error("{} fTableStream = jpaFlow.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return false;
            }
            fTableStream.forEach(fTable -> {
                logger.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);
                CxStageBkOfficies offices = mapperEfs.mapOffice(fTable);
                if (mode){
                    cxStage.save(offices); //Сохраняем объект
                } else {
                    cxStage.insert(offices.getAddress(), offices.getChiefCp(), offices.getCodeCft(), offices.getCodeCrif(),
                            offices.getCodeIbso(), offices.getCodeFem(), offices.getLastModified(), offices.getRegNum(),
                            offices.getShortTitle(), offices.getState(), offices.getStateIp(), offices.getTypeTp(), offices.getId()); //Сохраняем объект
                }
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                entityManager.detach(fTable); //Очищаем
            });
            logger.info("{}:Выгружено записей:{}", TG.UsbLogInfo, lineCount);
            cxStage.flush(); //сохраняем записи
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[Efs_Offices] и записи в таблицу ORA:[CX_STAGE_BK_OFFICES]", TG.UsbLogError);
            logger.error("{}:!PrintStackTrace:", TG.UsbLogError, e);
            sendMailError.sendMailErrorSubject("jdbc-efs-bk-portal. Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[Efs_Offices] и записи в таблицу ORA:[CX_STAGE_BK_OFFICES]",
                    "Описание ошибки:\n\r" + e.getMessage());
            return false;
        } finally {
            assert fTableStream != null;
            fTableStream.close();
        }
        //Все хорошо, отправляем результат
        return true;
    }


    /**
     * Провекра, что поток не NULL
     *
     * @param fTableStream - поток
     * @return
     */
    public boolean checkStream(Stream<Efs_Offices> fTableStream) {
        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Stream<Efs_Offices>                                !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }

}
