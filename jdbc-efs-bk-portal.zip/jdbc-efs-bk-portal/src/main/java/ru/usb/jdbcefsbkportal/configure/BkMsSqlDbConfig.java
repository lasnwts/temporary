package ru.usb.jdbcefsbkportal.configure;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;

/**
 * Отдельно сделаны источники для каждого класса, это EfsOrgStructure
 */


@Configuration
@EnableTransactionManagement
@ConfigurationProperties
@EnableJpaRepositories(
        entityManagerFactoryRef = "bkManagerFactory",
        transactionManagerRef = "bkTransactionManager",
        basePackages = {
                "ru.usb.jdbcefsbkportal.dto.bk.repository"
        }
)
public class BkMsSqlDbConfig {

    @Primary
    @Bean(name = "bkDataSource")
    @ConfigurationProperties(prefix = "spring.bk.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "bkManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                           @Qualifier("bkDataSource") DataSource dataSource) {

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", "update");

        return builder.dataSource(dataSource)
                .properties(properties)
                .packages("ru.usb.jdbcefsbkportal.dto.bk.model")
//                .persistenceUnit("EfsOrgStructure")
                .build();
    }

    @Bean(name = "bkTransactionManager")
    public PlatformTransactionManager bookTransactionManager(@Qualifier("bkManagerFactory") EntityManagerFactory bkManagerFactory) {
        return new JpaTransactionManager(bkManagerFactory);
    }

}
