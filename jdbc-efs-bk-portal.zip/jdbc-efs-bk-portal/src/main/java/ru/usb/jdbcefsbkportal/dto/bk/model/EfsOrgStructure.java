package ru.usb.jdbcefsbkportal.dto.bk.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "EFS_ORG_STRUCTURE")
public class EfsOrgStructure {

    @Id
    @Column(name = "ID")
    private String  id;

    @Column(name = "DEP_ID")
    private String  depId;

    @Column(name = "DEP_NAME")
    private String  depName;

    @Column(name = "HIGHER_DEP_ID")
    private String  higherDepId;

    @Column(name = "DEP_ID_L1")
    private String  depIdL1;

    @Column(name = "DEP_NAME_L1")
    private String  depNameL1;

    @Column(name = "DEP_ID_L2")
    private String  depIdL2;

    @Column(name = "DEP_NAME_L2")
    private String  depNameL2;

    @Column(name = "DEP_ID_L3")
    private String  depIdL3;

    @Column(name = "DEP_NAME_L3")
    private String  depNameL3;

    @Column(name = "DEP_ID_L4")
    private String  depIdL4;

    @Column(name = "DEP_NAME_L4")
    private String  depNameL4;

    @Column(name = "DEP_ID_L5")
    private String  depIdL5;

    @Column(name = "DEP_NAME_L5")
    private String  depNameL5;

    @Column(name = "STATE")
    private String  state;

    @Column(name = "LAST_MODIFIED")
    private Date lastModified;


}
