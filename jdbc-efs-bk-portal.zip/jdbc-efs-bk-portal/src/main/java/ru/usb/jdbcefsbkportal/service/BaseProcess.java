package ru.usb.jdbcefsbkportal.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.jdbcefsbkportal.configure.Configure;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsOfficeRepoBK;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsOrgStructureRepoBk;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsStaffRepoBK;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageBkOrgStructureRepo;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageBkStaffRepo;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageOfficies;
import ru.usb.jdbcefsbkportal.service.flow.FlowOffice;
import ru.usb.jdbcefsbkportal.service.flow.FlowOrgStructure;
import ru.usb.jdbcefsbkportal.service.flow.FlowStaff;

import java.util.Date;

/**
 * Основной процесс переноса информации
 */
@Service
public class BaseProcess {

    private final Logger logger = LoggerFactory.getLogger(BaseProcess.class);

    //Настройка
    private final Configure configure;

    //Потоки
    private final FlowOrgStructure flowOrgStructure;
    private final FlowStaff flowStaff;
    private final FlowOffice flowOffice;

    //Репозитории
    private final EfsOfficeRepoBK efsOfficeRepoBK;
    private final EfsStaffRepoBK efsStaffRepoBK;
    private final EfsOrgStructureRepoBk efsOrgStructureRepoBk;
    private final CxStageBkStaffRepo cxStageBkStaffRepo;
    private final CxStageBkOrgStructureRepo cxStageBkOrgStructureRepo;
    private final CxStageOfficies cxStageOfficies;

    @Autowired
    public BaseProcess(Configure configure, FlowOrgStructure flowOrgStructure, FlowStaff flowStaff, FlowOffice flowOffice,
                       EfsOfficeRepoBK efsOfficeRepoBK, EfsStaffRepoBK efsStaffRepoBK, EfsOrgStructureRepoBk efsOrgStructureRepoBk,
                       CxStageBkStaffRepo cxStageBkStaffRepo, CxStageBkOrgStructureRepo cxStageBkOrgStructureRepo,
                       CxStageOfficies cxStageOfficies) {
        this.configure = configure;
        this.flowOrgStructure = flowOrgStructure;
        this.flowStaff = flowStaff;
        this.flowOffice = flowOffice;
        this.efsOfficeRepoBK = efsOfficeRepoBK;
        this.efsStaffRepoBK = efsStaffRepoBK;
        this.efsOrgStructureRepoBk = efsOrgStructureRepoBk;
        this.cxStageBkStaffRepo = cxStageBkStaffRepo;
        this.cxStageBkOrgStructureRepo = cxStageBkOrgStructureRepo;
        this.cxStageOfficies = cxStageOfficies;
    }

    /**
     * Запуск перемещения всех потоков
     * OrgStructure, Office, Staff
     */
    public void startFlows(){

        setStateWorkFlow("startFlows[all flows on cron]", true);

        logger.info("{} Запуск startOfficeFlow {} часов дня. ", TG.UsbLogInfo, new Date());
        flowOffice.startOfficeFlow();
        logger.info("{} Завершение startOfficeFlow {} часов дня. ", TG.UsbLogInfo, new Date());

        logger.info("{} Запуск startOrgFlow {} часов дня. ", TG.UsbLogInfo, new Date());
        flowOrgStructure.startOrgFlow();
        logger.info("{} Завершение startOrgFlow {} часов дня. ", TG.UsbLogInfo, new Date());

        logger.info("{} Запуск startStaffFlow {} часов дня. ", TG.UsbLogInfo, new Date());
        flowStaff.startStaffFlow();
        logger.info("{} Завершение startStaffFlow {} часов дня. ", TG.UsbLogInfo, new Date());

        setStateWorkFlow("stop Flows [all flows on cron]", false);
    }

    /**
     * Запуск перемещения Office
     */
    public boolean startFlowOffice(){

        logger.info("{} Запуск from Controller startFlowOffice {} часов дня. ", TG.UsbLogInfo, new Date());
        boolean result = false;
        if (!checkStarted()){
            setStateWorkFlow("startFlowOffice", true);
            result = flowOffice.startOfficeFlow();
            setStateWorkFlow("startFlowOffice", false);
        }
        logger.info("{} Завершение from Controller startFlowOffice {} часов дня. ", TG.UsbLogInfo, new Date());
        return result;
    }

    /**
     * Запуск перемещения Staff
     */
    public boolean startFlowStaff(){

        logger.info("{} Запуск from Controller startFlowStaff {} часов дня. ", TG.UsbLogInfo, new Date());
        boolean result = false;
        if (!checkStarted()){
            setStateWorkFlow("startStaffFlow", true);
            result = flowStaff.startStaffFlow();
            setStateWorkFlow("startStaffFlow", false);
        }
        logger.info("{} Завершение from Controller startFlowStaff {} часов дня. ", TG.UsbLogInfo, new Date());
        return result;
    }

    /**
     * Запуск перемещения OrgStructure
     */
    public boolean startFlowOrg(){

        logger.info("{} Запуск from Controller startFlowOrg {} часов дня. ", TG.UsbLogInfo, new Date());
        boolean result = false;
        if (!checkStarted()){
            setStateWorkFlow("startOrgFlow", true);
            result = flowOrgStructure.startOrgFlow();
            setStateWorkFlow("startOrgFlow", false);
        }
        logger.info("{} Завершение from Controller startFlowOrg {} часов дня. ", TG.UsbLogInfo, new Date());
        return result;
    }

    /**
     * Получить количество записей в таблдицах
     */
    public void getCountTables(){
        //ЕФС
        configure.setCxOrgStructure(cxStageBkOrgStructureRepo.getCount());
        logger.info("{} Количество записей в таблице ЕФС: CX_STAGE_BK_ORG_STRUCTURE={}.", TG.UsbLogInfo, configure.getCxOrgStructure());
        configure.setCxOffice(cxStageOfficies.getCount());
        logger.info("{} Количество записей в таблице ЕФС: CX_STAGE_BK_OFFICES={}.", TG.UsbLogInfo, configure.getCxOffice());
        configure.setCxStaff(cxStageBkStaffRepo.getCount());
        logger.info("{} Количество записей в таблице ЕФС: CX_S9TAGE_BK_STAFF={}.", TG.UsbLogInfo, configure.getCxStaff());

        //БК
        configure.setEfsOffice(efsOfficeRepoBK.getCount());
        logger.info("{} Количество записей в таблице БК>: EFS_OFFICES={}.", TG.UsbLogInfo, configure.getEfsOffice());
        configure.setEfsStaff(efsStaffRepoBK.getCount());
        logger.info("{} Количество записей в таблице БК: EFS_STAFF={}.", TG.UsbLogInfo, configure.getEfsStaff());
        configure.setEfsOrgStructure(efsOrgStructureRepoBk.getCount());
        logger.info("{} Количество записей в таблице БК: EFS_ORG_STRUCTURE={}.", TG.UsbLogInfo, configure.getEfsOrgStructure());
    }

    /**
     * Проверка возможности запуска процессов
     * @return - true - нельзя запускать, работает процесс, false - можно запустить
     */
    private boolean checkStarted(){
        return configure.getSyncFlowWorkState();
    }

    /**
     * Установка запуска процесса
     * @param nameFlow - имя процесса
     * @param state - статус процесса
     */
    private void setStateWorkFlow(String nameFlow, boolean state){
        configure.setSyncFlowWorkState(state);
        configure.setSyncFlowName(nameFlow);
        configure.setSyncFlowStartDate(new Date());
    }

}
