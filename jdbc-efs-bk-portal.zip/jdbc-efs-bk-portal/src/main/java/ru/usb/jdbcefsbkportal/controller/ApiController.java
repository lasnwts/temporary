package ru.usb.jdbcefsbkportal.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.jdbcefsbkportal.configure.Configure;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.service.BaseProcess;

import java.util.Date;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с потоками из БК в ЕФС. ", description = "<Включение, отключение сервиса>")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);

    private static final String CONST = "<br>\n\r";

    private final BaseProcess baseProcess;
    private final Configure configure;

    @Autowired
    public ApiController(BaseProcess baseProcess, Configure configure) {
        this.baseProcess = baseProcess;
        this.configure = configure;
    }

    @PutMapping("/include/{off}")
    @Operation(summary = "Запрос на получение отключение=false или включение=true сервиса. При этом по таймеру сервис также не работает.")
    public ResponseEntity<String> include(@Parameter(description = " Введите true или false")
                                              @PathVariable(required = true) boolean off) {
        configure.setInclude(off);
        if (off){
            logger.info("{}: Получен запрос на включение сервиса. Сервис включен", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис включен]");
        } else {
            logger.info("{}: Получен запрос на выключение сервиса. Сервис отключен. По таймеру, работа остановлена", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис отключен. По таймеру, работа остановлена.]");
        }
    }

    @GetMapping("/state")
    @Operation(summary = "Запрос на получение статуса сервиса.")
    public ResponseEntity<String> getState() {
        if (configure.isInclude()){
            logger.info("{}: Получен запрос на статус сервиса. Статус:[Сервис включен].", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис включен]");
        } else {
            logger.info("{}: Получен запрос на статус сервиса. Статус:[Сервис отключен].", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис отключен. По таймеру, работа остановлена.]");
        }
    }

    @PutMapping("/change/{mode}")
    @Operation(summary = "Запрос на получение изменение режима работы сервиса. true - сервис будет обновлять записи в ЕФС. false - всегда Insert.")
    public ResponseEntity<String> change(@Parameter(description = " Введите true или false")
                                          @PathVariable(required = true) boolean mode) {
        configure.setInclude(mode);
        if (mode){
            logger.info("{}: Получен запрос на изменение режима работы сервиса. Сервис будет работать в режиме обновления записей в ЕФС.", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис будет работать в режиме обновления записей в ЕФС. При совпадении ID тек. записи и в таблице ЕФС.]");
        } else {
            logger.info("{}: Получен запрос на изменение режима работы сервиса. Сервис будет работать в режиме [insert] вставки записи в таблицу.", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис будет работать в режиме [insert] вставки записи в таблицу.]");
        }
    }

    @GetMapping("/mode")
    @Operation(summary = "Запрос на получение режима работы сервиса. Сервис может работать в режиме обновления записей в ЕФС " +
            "(при совпадении ID в таблице и текущего ID) или в режиме обязательного добавления.")
    public ResponseEntity<String> getMode() {
        if (configure.isInclude()){
            logger.info("{}: Получен запрос на режим работы сервиса. Режим: Обновление.[Сервис обновляет записи, если id записи мз таблицы BR и id в таблице ЕФС совпадают].", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис работает в режиме: Обновление.[Сервис обновляет записи, если id записи мз таблицы BR и id в таблице ЕФС совпадают].]");
        } else {
            logger.info("{}: Получен запрос на на режим работы сервиса. Режим:Вставка записи, всегда..", TG.UsbLogInfo);
            return ResponseEntity.status(HttpStatus.OK).body("[Сервис работает в режиме: всегда вставка записи [INSERT].]");
        }
    }


    @GetMapping("/count")
    @Operation(summary = "Запрос на получение количество записей во всех базах данных.")
    public ResponseEntity<String> getCount() {
        logger.info("{}: Получен запрос на получение количество записей во всех базах данных.", TG.UsbLogInfo);
        baseProcess.getCountTables();
        String response = "Количество записей в таблице ЕФС: CX_STAGE_BK_ORG_STRUCTURE=" + configure.getCxOrgStructure() + CONST +
        "Количество записей в таблице ЕФС: CX_STAGE_BK_OFFICES=" + configure.getCxOffice() + CONST +
        "Количество записей в таблице ЕФС: CX_S9TAGE_BK_STAFF=" + configure.getCxStaff() + CONST +
                "Количество записей в таблице БК: EFS_OFFICES=" + configure.getEfsOffice() + CONST +
                "Количество записей в таблице БК: EFS_STAFF=" + configure.getEfsStaff() + CONST +
                "Количество записей в таблице БК: EFS_ORG_STRUCTURE=." + configure.getEfsOrgStructure();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


    /**
     * Запуск потока Office
     * @return
     */
    @GetMapping("/office")
    @Operation(summary = "Запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице Office")
    public ResponseEntity<String> startOffice() {
        logger.info("{}: Получен запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице Office.", TG.UsbLogInfo);
        if (configure.getSyncFlowWorkState()){
            logger.info("{} Поток запускать нельзя. Ранее стартовал поток:{} в - {}.  Ждем его окончания.", TG.UsbLogInfo, configure.getSyncFlowName(), configure.getSyncFlowStartDate());
            return ResponseEntity.status(HttpStatus.OK).body("Поток запускать нельзя. Ранее стартовал поток:" + configure.getSyncFlowName()+ " в -- " + configure.getSyncFlowStartDate() + " Тогда Ждем его окончания.");
        } else {
            baseProcess.startFlowOffice();
            return ResponseEntity.status(HttpStatus.OK).body("Поток стартовал..");
        }
    }

    /**
     * Запуск потока OrgStructure
     * @return
     */
    @GetMapping("/structure")
    @Operation(summary = "Запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице OrgStructure")
    public ResponseEntity<String> startOrgStructure() {
        logger.info("{}: Получен запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице OrgStructure.", TG.UsbLogInfo);
        if (configure.getSyncFlowWorkState()){
            logger.info("{} Поток OrgStructure запускать нельзя. Ранее стартовал поток:{} в - {}.  Ждем его окончания.", TG.UsbLogInfo, configure.getSyncFlowName(), configure.getSyncFlowStartDate());
            return ResponseEntity.status(HttpStatus.OK).body("Поток OrgStructure запускать нельзя. Ранее стартовал поток:" + configure.getSyncFlowName()+ " в = " + configure.getSyncFlowStartDate() + " Ждем его окончания.");
        } else {
            baseProcess.startFlowOrg();
            return ResponseEntity.status(HttpStatus.OK).body("Поток OrgStructure стартовал..");
        }
    }


    /**
     * Запуск потока Staff
     * @return - response
     */
    @GetMapping("/staff")
    @Operation(summary = "Запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице Staff")
    public ResponseEntity<String> startStaff() {
        logger.info("{}: Получен запрос на запуск выгрузки из БК портал в ЕФС, данных по таблице Staff.", TG.UsbLogInfo);
        if (configure.getSyncFlowWorkState()){
            logger.info("{} Поток Staff запускать нельзя. Ранее стартовал поток:{} в - {}.  Ждем его окончания.", TG.UsbLogInfo, configure.getSyncFlowName(), configure.getSyncFlowStartDate());
            return ResponseEntity.status(HttpStatus.OK).body("Поток Staff запускать нельзя. Ранее стартовал поток:" + configure.getSyncFlowName()+ " в - " + configure.getSyncFlowStartDate() + " Ждем его окончания.");
        } else {
            baseProcess.startFlowStaff();
            return ResponseEntity.status(HttpStatus.OK).body("Поток Staff стартовал..");
        }
    }

    /**
     * Получить статус потоков
     * @return - ответ
     */
    @GetMapping("/flows-state")
    @Operation(summary = "Запрос на получение статусов потоков")
    public ResponseEntity<String> getFlowState() {
        logger.info("{}: Получен запрос на получение статусов потоков", TG.UsbLogInfo);
        String response = "Статус потоков: ";
        if (configure.getSyncFlowWorkState()){
            response = response +  "Поток "+ configure.getSyncFlowName() +" запущен на выгрузку в " + configure.getSyncFlowStartDate();
        } else {
            response = response +  "Потоки не запущены. Можно запускать. Последний поток на выгрузку: "+ configure.getSyncFlowName() +" был завершен в " + configure.getSyncFlowStartDate();
        }
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    /**
     * Изменение статуса потоков. Работает только для Rest API.
     * @param state - true - нельзя запускать, false - можно
     * @return - ответ
     */
    @PutMapping("/flows-state/{state}")
    @Operation(summary = "Запрос на изменение статусов потоков. Если вы поставите false - вы отключите текущие потоки. " +
            "Можно будет заново запускать выгрузку. Если вы поставите true - будет считаться, что потоки запущены и через API нельзя будет запускать новые выгрузки. ")
    public ResponseEntity<String> setFlowState(@Parameter(description = "Введите true или false")
                                               @PathVariable(required = true) boolean state){
        if (state){
            logger.info("{} Команда по Rest API включить статус TRUE, указав что идет активная выгрузка.", TG.UsbLogInfo);
            configure.setSyncFlowName("Команда по RestAPI- изменение статуса на TRUE");
            configure.setSyncFlowWorkState(true);
            configure.setSyncFlowStartDate(new Date());
        } else {
            logger.info("{} Команда по Rest API включить статус FALSE, отключив статус наличия выгрузки. Можно снова выгружать данные по Rest API.", TG.UsbLogInfo);
            configure.setSyncFlowName("Команда по RestAPI- изменение статуса на FALSE");
            configure.setSyncFlowWorkState(false);
            configure.setSyncFlowStartDate(new Date());
        }
        String response = "Статус потоков:";
        if (configure.getSyncFlowWorkState()){
            response = response +  "Команда по Rest API выполнена. Потоки запускать по Rest API - нельзя! "+ configure.getSyncFlowName() +". Дата изменения:" + configure.getSyncFlowStartDate();
        } else {
            response = response +  "Потоки не запущены. Можно запускать. Команда выполнена. "+ configure.getSyncFlowName() +" Дата изменения:" + configure.getSyncFlowStartDate();
        }
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
