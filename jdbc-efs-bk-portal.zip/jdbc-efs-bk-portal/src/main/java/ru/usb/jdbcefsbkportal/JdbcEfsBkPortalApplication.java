package ru.usb.jdbcefsbkportal;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.jdbcefsbkportal.configure.Configure;
import ru.usb.jdbcefsbkportal.configure.TG;

import java.util.Date;

@EnableScheduling
@SpringBootApplication
public class JdbcEfsBkPortalApplication implements CommandLineRunner {

	/**
	 * Секция о программе
	 */
	private final Configure configure;


	@Value("${info.application.name}")
	private String appName;

	@Value("${info.application.description}")
	private String appDescription;

	@Value("${info.app.version}")
	private String appVersion;

	@Value("${interval-in-cron}")
	private String cron12;



	@Autowired
	public JdbcEfsBkPortalApplication(Configure configure) {
		this.configure = configure;
	}

	private final Logger logger = LoggerFactory.getLogger(JdbcEfsBkPortalApplication.class);

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (jdbc-efs-bk-portal)")
				.version(appVersion)
				.description("API для канала БК портал - ЕФС." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	public static void main(String[] args) {
		SpringApplication.run(JdbcEfsBkPortalApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		/**
		 * Устанавливаем счетчик в ноль
		 */
		configure.setEfsOffice(0);
		configure.setEfsStaff(0);
		configure.setEfsOrgStructure(0);
		configure.setCxOffice(0);
		configure.setCxStaff(0);
		configure.setCxOrgStructure(0);

		/**
		 * Устанавливаем синхронные переменные
		 */
		configure.setSyncFlowName("Старт сервиса. Потоки не запускались.");
		configure.setSyncFlowWorkState(false);
		configure.setSyncFlowStartDate(new Date());

		logger.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		logger.info("{}: Created by 21.05.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", TG.UsbLogInfo);
		logger.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
		logger.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
		logger.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		logger.info("{}: Name of service                   : {}", TG.UsbLogInfo, configure.getAppName());
		logger.info("{}: Description of service            : {}", TG.UsbLogInfo, configure.getAppDescription());
		logger.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);
		logger.info("{}: Modified reason                   : 0.0.10", TG.UsbLogInfo);
		logger.info("{}:-----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);

	}

}
