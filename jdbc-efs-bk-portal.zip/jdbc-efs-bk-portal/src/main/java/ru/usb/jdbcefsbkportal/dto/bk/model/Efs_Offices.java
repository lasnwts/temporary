package ru.usb.jdbcefsbkportal.dto.bk.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "EFS_OFFICES")
public class Efs_Offices {

    @Id
    @Column(name = "ID")
    private String  id;

    @Column(name = "LAST_MODIFIED")
    private Date lastModified;

    @Column(name = "SHORT_TITLE")
    private String shortTitle;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "CHIEF_CP")
    private String chiefCp;

    @Column(name = "TYPE_TP")
    private String typeTp;

    @Column(name = "REGNUM")
    private String regNum;

    @Column(name = "STATE")
    private String state;

    @Column(name = "STATE_TP")
    private String stateIp;

    @Column(name = "CODE_FEM")
    private String codeFem;


    @Column(name = "CODE_CFT")
    private String codeCft;


    @Column(name = "CODE_IBSO")
    private String codeIbso;

    @Column(name = "CODE_CRIF")
    private String codeCrif;


}
