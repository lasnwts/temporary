package ru.usb.jdbcefsbkportal.service.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsStaff;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsStaffRepoBK;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkStaff;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageBkStaffRepo;
import ru.usb.jdbcefsbkportal.mapper.MapperEfs;
import ru.usb.jdbcefsbkportal.service.mail.ServiceMailError;

import javax.persistence.EntityManager;
import java.util.stream.Stream;

@Service
public class FlowStaff {

    @Value("${service.app.update-record:false}")
    private boolean mode; // Режим работы, true - обновляем запись, false - insert

    int lineCount;

    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final EfsStaffRepoBK jpaFlow; //MS SQL источник информации
    private final CxStageBkStaffRepo cxStage; //Oracle получатель информации
    private final MapperEfs mapperEfs; //маппер объектов

    @Autowired
    public FlowStaff(EntityManager entityManager, ServiceMailError sendMailError,
                     EfsStaffRepoBK jpaFlow, CxStageBkStaffRepo cxStage, MapperEfs mapperEfs) {
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.jpaFlow = jpaFlow;
        this.cxStage = cxStage;
        this.mapperEfs = mapperEfs;
    }

    private final Logger logger = LoggerFactory.getLogger(FlowStaff.class);

    @Transactional(value = "bkTransactionManager", readOnly = true)
    public boolean startStaffFlow() {

        //Получаем список записей из базы
        Stream<EfsStaff> fTableStream = null;

        try {
            int recordCount = jpaFlow.getCount();
            logger.info("{} Число записей в таблице: [dbo].[EFS_STAFF]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                logger.info("{} Поскольку число записей в таблице:  [dbo].[EFS_STAFF]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return false;
            }
            fTableStream = jpaFlow.getStreamAll();
            if (!checkStream(fTableStream)) {
                logger.error("{} fTableStream = jpaFlow.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return false;
            }
            fTableStream.forEach(fTable -> {
                logger.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);
                CxStageBkStaff cxStageBkStaff = mapperEfs.mapStaff(fTable);
                if (mode) {
                    cxStage.save(cxStageBkStaff); //Сохраняем объект
                } else {
                    cxStage.insert(cxStageBkStaff.getFullName(), cxStageBkStaff.getLName(), cxStageBkStaff.getFName(), cxStageBkStaff.getPName(),
                            cxStageBkStaff.getTitle(), cxStageBkStaff.getId(), cxStageBkStaff.getPersonNumber(), cxStageBkStaff.getDepId(),
                            cxStageBkStaff.getId(), cxStageBkStaff.getState(), cxStageBkStaff.getLastModified());
                }
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                entityManager.detach(fTable); //Очищаем
            });
            logger.info("{}:Выгружено записей:{}", TG.UsbLogInfo, lineCount);
            cxStage.flush(); //сохраняем записи
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[EFS_STAFF] и записи в таблицу ORA:[CX_S9TAGE_BK_STAFF]", TG.UsbLogError);
            logger.error("{}:!PrintStackTrace:", TG.UsbLogError, e);
            sendMailError.sendMailErrorSubject("jdbc-efs-bk-portal. Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[EFS_STAFF] и записи в таблицу ORA:[CX_S9TAGE_BK_STAFF]",
                    "Описание ошибки:\n\r" + e.getMessage());
            return false;
        } finally {
            assert fTableStream != null;
            fTableStream.close();
        }
        //Все хорошо, отправляем результат
        return true;
    }

    /**
     * Провекра, что поток не NULL
     *
     * @param fTableStream - поток
     * @return
     */
    public boolean checkStream(Stream<EfsStaff> fTableStream) {
        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Stream<EFS_STAFF  >                                !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }
}
