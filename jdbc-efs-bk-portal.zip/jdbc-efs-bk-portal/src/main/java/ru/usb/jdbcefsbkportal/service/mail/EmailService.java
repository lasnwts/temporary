package ru.usb.jdbcefsbkportal.service.mail;
/**
 * ver.1.0 21.05.2024
 * Lyapustin AS
 */

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import java.io.FileNotFoundException;

public interface EmailService {
    void sendSimpleEmail(final String toAddress, final String subject, final String message) throws AddressException;

    void sendSimpleEmailThrow(final String toAddress, final String subject, final String message) throws AddressException;

    void sendEmailWithAttachment(final String toAddress, final String subject, final String message, final String attachment) throws MessagingException, FileNotFoundException;
}
