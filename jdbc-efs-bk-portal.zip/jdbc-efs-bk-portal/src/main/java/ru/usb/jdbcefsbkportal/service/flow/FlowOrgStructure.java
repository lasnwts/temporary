package ru.usb.jdbcefsbkportal.service.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsOrgStructure;
import ru.usb.jdbcefsbkportal.dto.bk.repository.EfsOrgStructureRepoBk;
import ru.usb.jdbcefsbkportal.dto.efs.cx.repository.CxStageBkOrgStructureRepo;
import ru.usb.jdbcefsbkportal.mapper.MapperEfs;
import ru.usb.jdbcefsbkportal.service.mail.ServiceMailError;

import javax.persistence.EntityManager;
import java.util.stream.Stream;

@Service
public class FlowOrgStructure {

    @Value("${service.app.update-record:false}")
    private boolean mode; // Режим работы, true - обновляем запись, false - insert

    int lineCount;

    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final EfsOrgStructureRepoBk jpaFlow; //MS SQL источник информации
    private final CxStageBkOrgStructureRepo cxStage; //Oracle получатель информации
    private final MapperEfs mapperEfs; //маппер объектов

    @Autowired
    public FlowOrgStructure(EntityManager entityManager, ServiceMailError sendMailError,
                            EfsOrgStructureRepoBk jpaFlow, CxStageBkOrgStructureRepo cxStage, MapperEfs mapperEfs) {
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.jpaFlow = jpaFlow;
        this.cxStage = cxStage;
        this.mapperEfs = mapperEfs;
    }

    private final Logger logger = LoggerFactory.getLogger(FlowOrgStructure.class);

    @Transactional(value = "bkTransactionManager", readOnly = true)
    public boolean startOrgFlow() {

        //Получаем список записей из базы
        Stream<EfsOrgStructure> fTableStream = null;

        try {
            int recordCount = jpaFlow.getCount();
            logger.info("{} Число записей в таблице: [dbo].[EFS_ORG_STRUCTURE]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                logger.info("{} Поскольку число записей в таблице:  [dbo].[EFS_ORG_STRUCTURE]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return false;
            }
            fTableStream = jpaFlow.getStreamAll();
            if (!checkStream(fTableStream)) {
                logger.error("{} fTableStream = jpaFlow.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return false;
            }
            fTableStream.forEach(fTable -> {
                logger.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);
                if (mode){
                    cxStage.save(mapperEfs.mapOrgStructure(fTable)); //Сохраняем объект
                } else {
                    cxStage.insert(fTable.getDepId(), fTable.getDepName(), fTable.getHigherDepId(), fTable.getDepIdL1(), fTable.getDepNameL1(), fTable.getDepIdL2(),
                            fTable.getDepNameL2(), fTable.getDepIdL3(), fTable.getDepNameL3(), fTable.getDepIdL4(), fTable.getDepNameL4(), fTable.getDepIdL5(),
                            fTable.getDepNameL5(), fTable.getId(), fTable.getState(), fTable.getLastModified());
                }
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                entityManager.detach(fTable); //Очищаем
            });
            logger.info("{}:Выгружено записей:{}", TG.UsbLogInfo, lineCount);
            cxStage.flush(); //сохраняем записи
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[EFS_ORG_STRUCTURE] и записи в таблицу ORA:[CX_STAGE_BK_ORG_STRUCTURE]", TG.UsbLogError);
            logger.error("{}:!PrintStackTrace:", TG.UsbLogError, e);
            sendMailError.sendMailErrorSubject("jdbc-efs-bk-portal. Произошла ошибка при работе потока чтения данных из таблицы MSSQL:[EFS_ORG_STRUCTURE] и записи в таблицу ORA:[CX_STAGE_BK_ORG_STRUCTURE]",
                    "Описание ошибки:\n\r" + e.getMessage());
            return false;
        } finally {
            assert fTableStream != null;
            fTableStream.close();
        }
        //Все хорошо, отправляем результат
        return true;
    }


    /**
     * Провекра, что поток не NULL
     *
     * @param fTableStream - поток
     * @return
     */
    public boolean checkStream(Stream<EfsOrgStructure> fTableStream) {
        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  Stream<Efs_Offices>                                !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }
}
