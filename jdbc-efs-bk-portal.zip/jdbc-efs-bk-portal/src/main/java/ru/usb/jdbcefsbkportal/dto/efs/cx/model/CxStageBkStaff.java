package ru.usb.jdbcefsbkportal.dto.efs.cx.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "CX_S9TAGE_BK_STAFF")
public class CxStageBkStaff {

    @Id
    @Column(name = "ID")
    private String  id;

    @Column(name = "FULLNAME")
    private String  fullName;

    @Column(name = "LNAME")
    private String  lName;

    @Column(name = "FNAME")
    private String  fName;

    @Column(name = "PNAME")
    private String  pName;

    @Column(name = "TITLE")
    private String  title;

    @Column(name = "SAP_ID")
    private String  sapId;

    @Column(name = "PERSON_NUMBER")
    private String  personNumber;

    @Column(name = "DEP_ID")
    private String  depId;

    @Column(name = "STATE")
    private String  state;

    @Column(name = "LAST_MODIFIED")
    private Date lastModified;

}
