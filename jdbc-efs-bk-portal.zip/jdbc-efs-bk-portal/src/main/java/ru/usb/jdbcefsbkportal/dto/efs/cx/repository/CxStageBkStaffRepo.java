package ru.usb.jdbcefsbkportal.dto.efs.cx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkStaff;

import javax.persistence.QueryHint;
import javax.transaction.Transactional;
import java.sql.Date;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface CxStageBkStaffRepo extends JpaRepository<CxStageBkStaff, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM CX_S9TAGE_BK_STAFF")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT * FROM CX_S9TAGE_BK_STAFF")
    List<CxStageBkStaff> getListAll();

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query(value = "INSERT INTO CX_S9TAGE_BK_STAFF (FULLNAME,LNAME,FNAME,PNAME,TITLE,SAP_ID,PERSON_NUMBER,DEP_ID,ID,STATE,LAST_MODIFIED) "
            + "VALUES (:FULLNAME,:LNAME,:FNAME,:PNAME,:TITLE,:SAP_ID,:PERSON_NUMBER,:DEP_ID,:ID,:STATE,:LAST_MODIFIED)", nativeQuery = true)
    void insert(@Param("FULLNAME") String fullName, @Param("LNAME") String lName, @Param("FNAME") String fName,
                @Param("PNAME") String pName, @Param("TITLE") String title, @Param("SAP_ID") String sapId,
                @Param("PERSON_NUMBER") String personNumber, @Param("DEP_ID") String depId, @Param("ID") String id,
                @Param("STATE") String state, @Param("LAST_MODIFIED") Date lastModified);

}
