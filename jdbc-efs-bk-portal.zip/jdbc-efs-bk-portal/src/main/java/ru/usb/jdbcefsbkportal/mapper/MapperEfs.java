package ru.usb.jdbcefsbkportal.mapper;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import ru.usb.jdbcefsbkportal.configure.TG;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsOrgStructure;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsStaff;
import ru.usb.jdbcefsbkportal.dto.bk.model.Efs_Offices;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkOfficies;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkOrgStructure;
import ru.usb.jdbcefsbkportal.dto.efs.cx.model.CxStageBkStaff;

@Component
@Log4j2
public class MapperEfs {

    /**
     * Мапирование объекта
     * @param efsOffices - входной объект из БД MS SQL
     * @return - выходной объект для ORAa
     */
    public CxStageBkOfficies mapOffice(Efs_Offices efsOffices){
        log.debug("{} efs_office:{}", TG.UsbLogDebug, efsOffices);
        CxStageBkOfficies cxStageBkOfficies = new CxStageBkOfficies(
                efsOffices.getId(), efsOffices.getShortTitle(), efsOffices.getAddress(), efsOffices.getChiefCp(), efsOffices.getTypeTp(),
                efsOffices.getRegNum(), efsOffices.getState(), efsOffices.getStateIp(), efsOffices.getCodeFem(), efsOffices.getCodeCft(),
                efsOffices.getCodeIbso(), efsOffices.getCodeCrif(), efsOffices.getLastModified());
        log.debug("{} cxStageBkOfficies:{}", TG.UsbLogDebug, cxStageBkOfficies);
        return cxStageBkOfficies;
    }

    /**
     * Мапирование объекта
     * @param efsStaff - входной объект из БД MS SQL
     * @return - выходной объект для ORAa
     */
    public CxStageBkStaff mapStaff(EfsStaff efsStaff){
        log.debug("{} efs_staff:{}", TG.UsbLogDebug, efsStaff);
        CxStageBkStaff cxStageBkStaff = new CxStageBkStaff(efsStaff.getId(), efsStaff.getFullName(), efsStaff.getLName(),
                efsStaff.getFName(), efsStaff.getPName(), efsStaff.getTitle(), efsStaff.getSapId(), efsStaff.getPersonNumber(),
                efsStaff.getDepId(), efsStaff.getState(), efsStaff.getLastModified());
        log.debug("{} cxStageBkStaff:{}", TG.UsbLogDebug, cxStageBkStaff);
        return cxStageBkStaff;
    }

    /**
     * Мапирование объекта
     * @param orgStructure - входной объект из БД MS SQL
     * @return - выходной объект для ORAa
     */
    public CxStageBkOrgStructure mapOrgStructure(EfsOrgStructure orgStructure){
        log.debug("{} EfsOrgStructure:{}", TG.UsbLogDebug, orgStructure);
        CxStageBkOrgStructure cxStageBkOrgStructure = new CxStageBkOrgStructure(orgStructure.getId(),orgStructure.getDepId(),
                orgStructure.getDepName(),orgStructure.getHigherDepId(), orgStructure.getDepIdL1(), orgStructure.getDepNameL1(),
                orgStructure.getDepIdL2(), orgStructure.getDepNameL2(), orgStructure.getDepIdL3(), orgStructure.getDepNameL3(),
                orgStructure.getDepIdL4(), orgStructure.getDepNameL4(), orgStructure.getDepIdL5(), orgStructure.getDepNameL5(),
                orgStructure.getState(),orgStructure.getLastModified());
        log.debug("{} EfsOrgStructure:{}", TG.UsbLogDebug, cxStageBkOrgStructure);
        return cxStageBkOrgStructure;
    }
}
