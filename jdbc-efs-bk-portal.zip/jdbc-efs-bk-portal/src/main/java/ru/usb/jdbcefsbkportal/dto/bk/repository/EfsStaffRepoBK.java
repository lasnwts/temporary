package ru.usb.jdbcefsbkportal.dto.bk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.jdbcefsbkportal.dto.bk.model.EfsStaff;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface EfsStaffRepoBK extends JpaRepository<EfsStaff, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM  dbo.EFS_STAFF")
    int getCount();


    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [FULLNAME],[LNAME],[FNAME],[PNAME],[TITLE],[SAP_ID],[PERSON_NUMBER],[DEP_ID],[ID],[STATE],[LAST_MODIFIED] FROM [dbo].[EFS_STAFF]")
    List<EfsStaff> getListAll();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT [FULLNAME],[LNAME],[FNAME],[PNAME],[TITLE],[SAP_ID],[PERSON_NUMBER],[DEP_ID],[ID],[STATE],[LAST_MODIFIED] FROM [dbo].[EFS_STAFF]")
    Stream<EfsStaff> getStreamAll();

}
