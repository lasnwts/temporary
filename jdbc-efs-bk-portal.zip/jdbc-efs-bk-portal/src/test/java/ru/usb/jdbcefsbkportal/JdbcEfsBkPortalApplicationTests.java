package ru.usb.jdbcefsbkportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcEfsBkPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
