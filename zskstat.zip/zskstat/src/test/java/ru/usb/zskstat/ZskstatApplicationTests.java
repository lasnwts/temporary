package ru.usb.zskstat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZskstatApplicationTests {

	@Test
	void contextLoads() {
	}

}
