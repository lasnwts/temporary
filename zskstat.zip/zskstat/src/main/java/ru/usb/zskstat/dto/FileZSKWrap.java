package ru.usb.zskstat.dto;

import ru.usb.zskstat.model.FileZSK;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FileZSKWrap {

    private List<FileZSK> fileZSKList;
    private boolean code; //Код ошибки: 0 - порядок, 1 - ошибка
    private String message; //Строка с ошибкой

    public FileZSKWrap() {
    }

    public List<FileZSK> getFileZSKList() {
        return fileZSKList;
    }

    public void setFileZSKList(List<FileZSK> fileZSKList) {
        this.fileZSKList = fileZSKList;
    }

    public boolean isCode() {
        return code;
    }

    public void setCode(boolean code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void addFileZSKtoList(FileZSK fileZSK){
        List<FileZSK> fileZSKS = new ArrayList<>();
        fileZSKS.add(fileZSK);
        setFileZSKList(fileZSKS);
    }
}
