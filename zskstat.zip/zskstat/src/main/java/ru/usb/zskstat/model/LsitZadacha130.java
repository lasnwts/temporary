package ru.usb.zskstat.model;

import java.util.List;

public class LsitZadacha130 {

    private java.util.List<Zadacha130> zadacha130List;

    public LsitZadacha130() {
    }

    public LsitZadacha130(List<Zadacha130> zadacha130List) {
        this.zadacha130List = zadacha130List;
    }

    public List<Zadacha130> getZadacha130List() {
        return zadacha130List;
    }

    public void setZadacha130List(List<Zadacha130> zadacha130List) {
        this.zadacha130List = zadacha130List;
    }
}
