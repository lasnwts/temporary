package ru.usb.zskstat.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha130 {
    @JsonProperty("Id")
    public String id;
    @JsonProperty("CorrelationId")
    public String correlationId;
    @JsonProperty("GroupId")
    public String groupId;
    @JsonProperty("Type")
    public String type;
    @JsonProperty("Title")
    public String title;
    @JsonProperty("Text")
    public String ztext;
    @JsonProperty("CreationDate")
    public String creationDate;
    @JsonProperty("UpdatedDate")
    public String updatedDate;
    @JsonProperty("Status")
    public String status;
    @JsonProperty("TaskName")
    public String taskName;
    @JsonProperty("RegNumber")
    public String regNumber;
    @JsonProperty("TotalSize")
    public int totalSize;
    @JsonProperty("Sender")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    public ArrayList<Sender> sender;

    @JsonProperty("Files")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    public ArrayList<Zadacha130File> files;
//    @JsonProperty("Receipts")
//    public ArrayList<String> receipts;

    @JsonProperty("Receipts")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    public ArrayList<Receipts> receipts;

    public Zadacha130() {
    }


    public Zadacha130(String id, String correlationId, String groupId, String type, String title,
                      String ztext, String creationDate, String updatedDate,
                      String status, String taskName, String regNumber,
                      int totalSize, ArrayList<Sender> sender,
                      ArrayList<Zadacha130File> files, ArrayList<Receipts> receipts) {
        this.id = id;
        this.correlationId = correlationId;
        this.groupId = groupId;
        this.type = type;
        this.title = title;
        this.ztext = ztext;
        this.creationDate = creationDate;
        this.updatedDate = updatedDate;
        this.status = status;
        this.taskName = taskName;
        this.regNumber = regNumber;
        this.totalSize = totalSize;
        this.sender = sender;
        this.files = files;
        this.receipts = receipts;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getZtext() {
        return ztext;
    }

    public void setZtext(String ztext) {
        this.ztext = ztext;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getRegNumber() {
        return regNumber;
    }

    public void setRegNumber(String regNumber) {
        this.regNumber = regNumber;
    }

    public int getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(int totalSize) {
        this.totalSize = totalSize;
    }

    public ArrayList<Zadacha130File> getFiles() {
        return files;
    }

    public void setFiles(ArrayList<Zadacha130File> files) {
        this.files = files;
    }

    public ArrayList<Receipts> getReceipts() {
        return receipts;
    }

    public void setReceipts(ArrayList<Receipts> receipts) {
        this.receipts = receipts;
    }

    public ArrayList<Sender> getSender() {
        return sender;
    }

    public void setSender(ArrayList<Sender> sender) {
        this.sender = sender;
    }

    @Override
    public String toString() {
        return "Zadacha130{" +
                "id='" + id + '\'' +
                ", correlationId='" + correlationId + '\'' +
                ", groupId='" + groupId + '\'' +
                ", type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", ztext='" + ztext + '\'' +
                ", creationDate='" + creationDate + '\'' +
                ", updatedDate='" + updatedDate + '\'' +
                ", status='" + status + '\'' +
                ", taskName='" + taskName + '\'' +
                ", regNumber='" + regNumber + '\'' +
                ", totalSize=" + totalSize +
                '}';
    }
}
