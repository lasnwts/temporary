package ru.usb.zskstat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zskstat.configure.Configure;
import ru.usb.zskstat.dto.FileZSKWrap;
import ru.usb.zskstat.model.FileZSK;
import ru.usb.zskstat.repository.JpaRepoFileZSK;
import ru.usb.zskstat.utils.CUtility;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Сервисный слой для БД
 */
@Service
public class DbService {
    Logger logger = LoggerFactory.getLogger(DbService.class);

    @Autowired
    Configure configure;

    @Autowired
    JpaRepoFileZSK jpaRepoFileZSK;

    @Autowired
    CUtility cu;

    /**
     * Количество записей в таблице
     *
     * @return
     */
    public long getCountRecords() {
        long countRecord = jpaRepoFileZSK.count();
        return countRecord;
    }

    /**
     * Получаем запись из БД по messageId
     *
     * @param messageId - Id сообщения
     * @return - запись
     */
    public FileZSKWrap getRecords(String messageId) {

        FileZSKWrap fileZSKWrap = new FileZSKWrap();

        if (messageId == null) {
            fileZSKWrap.setCode(false);
            fileZSKWrap.setMessage("Передан пустой MessageID сообщения==NULL!");
            return fileZSKWrap;
        }

        List<FileZSK> fileZSK = jpaRepoFileZSK.getFromMessageId(messageId);
        if (fileZSK == null) {
            fileZSKWrap.setCode(false);
            fileZSKWrap.setMessage("");
            return fileZSKWrap;
        }
        if (fileZSK.size() == 0) {
            fileZSKWrap.setCode(false);
            fileZSKWrap.setMessage("");
            return fileZSKWrap;
        }

        fileZSKWrap.setFileZSKList(fileZSK);
        fileZSKWrap.setCode(true);
        return fileZSKWrap;
    }

    /**
     * Получение ZSK из id
     *
     * @param id
     * @return
     */
    public FileZSKWrap getWrapRecordById(long id) {
        FileZSKWrap fileZSKWrap = new FileZSKWrap();
        Optional<FileZSK> fileZSK = jpaRepoFileZSK.findById(id);
        if (fileZSK == null) {
            fileZSKWrap.setCode(false);
            fileZSKWrap.setMessage("В таблице нет записи с id=" + id);
        } else {
            if (fileZSK.isPresent()) {
                fileZSKWrap.addFileZSKtoList(fileZSK.get());
                fileZSKWrap.setCode(true);
            } else {
                fileZSKWrap.setCode(false);
                fileZSKWrap.setMessage("В таблице нет записи с id=" + id);
            }
        }
        return fileZSKWrap;
    }


    /**
     * Получение ZSK из id
     *
     * @param id
     * @return
     */
    public FileZSK getRecordById(long id) {

        Optional<FileZSK> fileZSK = jpaRepoFileZSK.findById(id);
        if (fileZSK == null) {
            return null;
        } else {
            if (fileZSK.isPresent()) {
                return fileZSK.get();
            } else {
                return null;
            }
        }
    }

    /**
     * Сохраняем запись в БД
     *
     * @param fileZSK
     */
    public void saveFileZSK(FileZSK fileZSK) {
        if (fileZSK == null) {
            logger.error("UsbLog: Передан пустой (NULL) объект для записи в БД");
            return;
        }
        logger.info("fileZSK.getMessage, размер: {}", fileZSK.getMessage().length());


        try {
            jpaRepoFileZSK.saveAndFlush(fileZSK);
        } catch (Exception exception){
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Возникла ошибка сохранения сообщения в БД");
            logger.error("UsbLog: Сообщение:{}", fileZSK.toString());
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }

    }

    /**
     * Получаем список объектов по статусу
     *
     * @param status
     * @return
     */
    public List<FileZSK> getRecordsStatus(String status) {
        if (status == null) {
            logger.error("UsbLog: Передан пустой  status (NULL) искать нечего");
            return null;
        }
        return jpaRepoFileZSK.getFromStatus(status);
    }

    /**
     * Получаем список объектов по File Name
     *
     * @param fileName
     * @return
     */
    public List<FileZSK> getRecordsFileName(String fileName) {
        if (fileName == null) {
            logger.error("UsbLog: Передан пустой fileName (NULL) искать нечего");
            return null;
        }
        return jpaRepoFileZSK.getFromFileName(fileName);
    }

    /**
     * Получаем список объектов по MessageId
     *
     * @param messageID
     * @return
     */
    public List<FileZSK> getRecordsMessageId(String messageID) {
        if (messageID == null) {
            logger.error("UsbLog: Передан пустой messageID (NULL) искать нечего");
            return null;
        }
        return jpaRepoFileZSK.getFromMessageId(messageID);
    }

    /**
     * Получаем список за определенную дату
     * @param dateInput
     * @return
     */
    public List<FileZSK> getRecordsDate(String dateInput) {
        if (dateInput == null) {
            logger.error("UsbLog: Передан пустой dateInput (NULL) искать нечего");
            return null;
        }
        if (cu.parseDate(dateInput)) {
            return jpaRepoFileZSK.getFromDate(cu.getSqlDate(cu.getDate(dateInput)), cu.getSqlDate(cu.getDate(dateInput).plusDays(1)));
        } else {
            logger.error("UsbLog: Передан dateInput: {} который не распарсился", dateInput);
            return null;
        }
    }

    /**
     * Получаем список за определенную дату и имеющие промежуточные статусы
     * @param dateInput
     * @return
     */
    public List<FileZSK> getRecordsDateStatus(String dateInput) {
        if (dateInput == null) {
            logger.error("UsbLog: Передан пустой dateInput (NULL) искать нечего");
            return null;
        }
        if (cu.parseDate(dateInput)) {
            return jpaRepoFileZSK.getStatus(cu.getSqlDate(cu.getDate(dateInput)), cu.getSqlDate(cu.getDate(dateInput).plusDays(1)));
        } else {
            logger.error("UsbLog: Передан dateInput: {} который не распарсился", dateInput);
            return null;
        }
    }


}
