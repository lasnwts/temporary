package ru.usb.zskstat.model;

/**
 * Класс для хранения Statusa сообщения
 */
public class StatusMessage {

    private String status;
    private String shortDescription;
    private String description;

    public StatusMessage() {
    }

    public StatusMessage(String status, String shortDescription, String description) {
        this.status = status;
        this.shortDescription = shortDescription;
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "StatusMessage{" +
                "status='" + status + '\'' +
                ", shortDescription='" + shortDescription + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
