package ru.usb.zskstat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zskstat.configure.Configure;
import ru.usb.zskstat.dto.QuotaWrapResponse;
import ru.usb.zskstat.model.Quota;

@Service
public class GetQuota {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetQuota.class);

    public QuotaWrapResponse getQuota() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        // make a request
        QuotaWrapResponse quotaWrapResponse = new QuotaWrapResponse();
        try {
            ResponseEntity<Quota> response = restTemplate.exchange(configure.getZskUrlQuota(),
                    HttpMethod.GET, request,
                    Quota.class);
            Quota quota = response.getBody();
            logger.info("Quota:{}", quota.toString());
            quotaWrapResponse.setQuota(quota);
            quotaWrapResponse.setCode(true);
        } catch (Exception e) {
            logger.error("Ошибка запроса квоты на сервере ЦБ:{}", e.getMessage());
            quotaWrapResponse.setCode(false);
            quotaWrapResponse.setMessage(e.getMessage());
        }
        return quotaWrapResponse;
    }

}
