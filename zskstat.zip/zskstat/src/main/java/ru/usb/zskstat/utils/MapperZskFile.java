package ru.usb.zskstat.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.zskstat.model.FileZSK;
import ru.usb.zskstat.model.StatusMessage;
import ru.usb.zskstat.model.Zadacha130;

import java.util.Date;

/**
 * Маппер FileZSK  из Zadacha130
 */
@Component
public class MapperZskFile {

    @Autowired
    CUtility cu;

    @Autowired
    JsonMapper130 jsonMapper130;

    @Autowired
    GetStatusMessage getStatusMessage;


    Logger logger = LoggerFactory.getLogger(MapperZskFile.class);

    /**
     * Мапирование полученного ответа в FileZSK
     *
     * @param zadacha130
     * @param fileZSK
     * @return
     */
    public FileZSK mapFileZSK(Zadacha130 zadacha130, FileZSK fileZSK) {

        if (zadacha130 == null) {
            logger.error("UsbLog: Error: mapFileZSK - передано пустое == NULL значние:Zadacha130");
            return null;
        }

        if (fileZSK == null) {
            logger.error("UsbLog: Error: mapFileZSK - передано пустое == NULL значние:fileZSK");
            return null;
        }

        StatusMessage statusMessage = getStatusMessage.getStatus(zadacha130);

        fileZSK.setStatus(cu.getMaxLength255(cu.getWrapNull(zadacha130.getStatus())));
        fileZSK.setLastupdatedate(new Date());
        fileZSK.setTitle(cu.getMaxLength2048(cu.getWrapNull(zadacha130.getTitle())));
        fileZSK.setTaskName(cu.getMaxLength512(cu.getWrapNull(zadacha130.getTaskName())));
        fileZSK.setTotalSize(getCountTry(fileZSK.getTotalSize()));
        fileZSK.setCreateDateCB(cu.getMaxLength255(cu.getWrapNull(zadacha130.creationDate)));
        fileZSK.setMessage(cu.getMaxLength3998(cu.getWrapNull(jsonMapper130.getJsonToStr(zadacha130))));
        //Это короткое наименование статуса
        fileZSK.setFileEncAbsolutePath(cu.getMaxLength2048(statusMessage.getShortDescription()));
        //Это полное наименование статуса
        fileZSK.setFileSigAbsolutePath(cu.getMaxLength2048(statusMessage.getDescription()));

        return fileZSK;
    }

    /**
     * + 1 еще одна попытка
     *
     * @param tryCount
     * @return
     */
    private long getCountTry(long tryCount) {
        return tryCount + 1;
    }

}
