package ru.usb.zskstat.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Sender {
    @JsonProperty("Inn")
    private String inn;

    @JsonProperty("Ogrn")
    private String ogrn;

    @JsonProperty("Bik")
    private String bik;

    @JsonProperty("RegNum")
    private String regNum;

    @JsonProperty("DivisionCode")
    private String divisionCode;

    public Sender() {
    }

    public Sender(String inn, String ogrn, String bik, String regNum, String divisionCode) {
        this.inn = inn;
        this.ogrn = ogrn;
        this.bik = bik;
        this.regNum = regNum;
        this.divisionCode = divisionCode;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getBik() {
        return bik;
    }

    public void setBik(String bik) {
        this.bik = bik;
    }

    public String getRegNum() {
        return regNum;
    }

    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    @Override
    public String toString() {
        return "Sender{" +
                "inn='" + inn + '\'' +
                ", ogrn='" + ogrn + '\'' +
                ", bik='" + bik + '\'' +
                ", regNum='" + regNum + '\'' +
                ", divisionCode='" + divisionCode + '\'' +
                '}';
    }
}
