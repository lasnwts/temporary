package ru.usb.zskstat.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Zadacha130Repo {

    @JsonProperty("RepositoryType")
    public String repositoryType;
    @JsonProperty("Host")
    public String host;
    @JsonProperty("Port")
    public int port;
    @JsonProperty("Path")
    public String path;

    public Zadacha130Repo() {
    }

    public Zadacha130Repo(String repositoryType, String host, int port, String path) {
        this.repositoryType = repositoryType;
        this.host = host;
        this.port = port;
        this.path = path;
    }

    public String getRepositoryType() {
        return repositoryType;
    }

    public void setRepositoryType(String repositoryType) {
        this.repositoryType = repositoryType;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "Zadacha130File{" +
                "repositoryType='" + repositoryType + '\'' +
                ", host='" + host + '\'' +
                ", port=" + port +
                ", path='" + path + '\'' +
                '}';
    }
}
