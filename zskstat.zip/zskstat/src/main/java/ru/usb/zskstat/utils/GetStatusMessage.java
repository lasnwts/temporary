package ru.usb.zskstat.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.zskstat.model.StatusMessage;
import ru.usb.zskstat.model.Zadacha130;

/**
 * Получаем статус сообщения
 */
@Component
public class GetStatusMessage {

    Logger logger = LoggerFactory.getLogger(GetStatusMessage.class);

    /**
     * Получаем статус сообщения
     *
     * @param zadacha130
     * @return
     */
    public StatusMessage getStatus(Zadacha130 zadacha130) {

        StatusMessage statusMessage = new StatusMessage("", "", "");
        if (zadacha130 == null) {
            logger.error("UsbLog: Error: getStatus - передано пустое == NULL значние:Zadacha130");
            return statusMessage;
        }

        String status130 = zadacha130.getStatus();
        if (status130 == null) {
            logger.error("UsbLog: Error: adacha130.getStatus() - вернул пустое == NULL значние:Zadacha130");
            return statusMessage;
        }

        //success
        if (status130.trim().toLowerCase().contains("success")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Доставлено");
            statusMessage.setDescription("Сообщение успешно размещено в ЛК/Сообщение передано роутером во внутреннюю систему Банка России, от которой не ожидается ответ о регистрации");
        }

        //draft
        if (status130.trim().toLowerCase().contains("draft")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Черновик");
            statusMessage.setDescription("Сообщение с данным статусом создано, но ещё не отправлено.");
        }

        //sent
        if (status130.trim().toLowerCase().contains("sent")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Отправлено");
            statusMessage.setDescription("Сообщение получено сервером");
        }

        //delivered
        if (status130.trim().toLowerCase().contains("delivered")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Загружено");
            statusMessage.setDescription("Сообщение прошло первоначальную проверку");
        }

        //error
        if (status130.trim().toLowerCase().contains("error")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Ошибка");
            statusMessage.setDescription("При обработке сообщения возникла ошибка");
            logger.error("Error: Сообщение с id:{}, получило статус ошибки:{}", zadacha130.getId(), statusMessage.toString());
        }

        //processing
        if (status130.trim().toLowerCase().contains("processing")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Принято в обработку");
            statusMessage.setDescription("Сообщение передано во внутреннюю систему Банка России");
        }

        //registered
        if (status130.trim().toLowerCase().contains("registered")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Зарегистрировано");
            statusMessage.setDescription("Сообщение зарегистрировано");
            logger.info("Success: Сообщение с id:{}, зарегистрировано статус ошибки:{}", zadacha130.getId(), statusMessage.toString());
        }

        //rejected
        if (status130.trim().toLowerCase().contains("rejected")){
            statusMessage.setStatus(status130);
            statusMessage.setShortDescription("Отклонено");
            statusMessage.setDescription("Сообщение успешно дошло до получателя, но было отклонено");
            logger.error("Error: Сообщение с id:{}, получило статус ошибки:{}", zadacha130.getId(), statusMessage.toString());
        }

        return statusMessage;

    }


}
