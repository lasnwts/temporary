package ru.usb.zskstat.rescontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.zskstat.model.FileZSK;
import ru.usb.zskstat.service.DbService;

import java.util.List;

@RestController
@RequestMapping("/api/db")
@Tag(name = "Контроллер для работы с таблицей БД", description = "Проверка")
public class DbController {

    private Logger logger = LoggerFactory.getLogger(DbController.class);

    @Autowired
    DbService dbService;

    /**
     * Получение общего количества записей
     * @return
     */
    @GetMapping(value = "/count")
    @Operation(summary = "Получить количество записей в таблице.")
    public @ResponseBody ResponseEntity<String> getCount() {

        long recordsCount = dbService.getCountRecords();
        if (recordsCount == 0) {
            logger.error("UsbLog:Error - не удалось получить количество записей в таблице");
            return new ResponseEntity<>("не удалось получить количество записей в таблице", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Количество записей в таблице=" + recordsCount, HttpStatus.OK);
    }

    /**
     * Получение конкретной записи по id
     * @param id
     * @return
     */
    @GetMapping(value = "/id/{id}")
    @Operation(summary = "Получить запись из таблицы по id.")
    public @ResponseBody ResponseEntity<?> getRecordById(@Parameter(description = "id:101")
                                                         @PathVariable("id") long id) {

        FileZSK fileZSK = dbService.getRecordById(id);

        if (fileZSK == null) {
            logger.error("UsbLog:Error - не удалось получить запись с номером: {} в таблице", id);
            return new ResponseEntity<>("не удалось получить запись с номером: " + id + " в таблице", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.status(HttpStatus.OK).body(fileZSK);
    }

    /**
     * Получение списка записей по статусу
     * @param lineStatus
     * @return
     */
    @GetMapping(value = "/status/{status}")
    @Operation(summary = "Получить список записей из таблицы по статусу.")
    public @ResponseBody ResponseEntity<?> getRecordsByStatus(@Parameter(description = "status:0")
                                                              @PathVariable("status") String lineStatus) {
        if (lineStatus == null) {
            logger.error("UsbLog:Error - не удалось получить список записей в таблице по статусу. Статус передан = NULL!");
            return new ResponseEntity<>("не удалось получить список записей в таблице по статусу, вы не передали значение статуса", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        List<FileZSK> fileZSKList = dbService.getRecordsStatus(lineStatus);

        if (fileZSKList == null) {
            logger.error("UsbLog:Error - не удалось получить записи со статусом: {} в таблице (возможно что их нет)", lineStatus);
            return new ResponseEntity<>("Ошибка, не удалось получить записи со статусом: " + lineStatus + " в таблице  (возможно что их нет)", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (fileZSKList.size() == 0) {
            logger.error("UsbLog:Error - не удалось получить записи со статусом: {} в таблице (возможно что их нет)", lineStatus);
            return new ResponseEntity<>("не удалось получить записи со статусом: " + lineStatus + " в таблице  (возможно что их нет)", HttpStatus.OK);
        }
        logger.info("Получено {} записей из БД со статусом:{}", fileZSKList.size(), lineStatus);
        return ResponseEntity.status(HttpStatus.OK).body(fileZSKList);
    }

    /**
     * Сохранить запись в БД
     * @param fileZSK
     * @return
     */
    @PostMapping(value = "/save")
    @Operation(summary = "Сохранить сообщение в БД.")
    public @ResponseBody ResponseEntity<?> save(@Parameter(description = "Сохраняет в БД объект, как запись")
                                                @RequestBody FileZSK fileZSK) {
        if (fileZSK == null) {
            logger.error("UsbLog:Error - FileZSK объект не передан == NULL");
            return new ResponseEntity<>("FileZSK объект не передан == NULL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        try {
            dbService.saveFileZSK(fileZSK);
            logger.info("Объект {} сохранен в таблице", fileZSK.toString());
            return ResponseEntity.status(HttpStatus.OK).body("Объект " + fileZSK.toString() + " сохранен в таблице");
        } catch (Exception e) {
            logger.error("UsbLog:Error - не удалось сохранить объект {} в таблице", fileZSK.toString());
            return new ResponseEntity<>("Ошибка, не удалось сохранить объект: " + fileZSK.toString() + " в таблице", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Получение списка записей по MessageId
     * @param messageId
     * @return
     */
    @GetMapping(value = "/message/{messageid}")
    @Operation(summary = "Получить список записей из таблицы по MessageId.")
    public @ResponseBody ResponseEntity<?> getRecordsByMessageId(@Parameter(description = "messageId=0be38c5f-36ca-4505-9838-af90010601e2")
                                                              @PathVariable("messageid") String messageId) {
        if (messageId == null) {
            logger.error("UsbLog:Error - не удалось получить список записей в таблице по messageId. messageId передан = NULL!");
            return new ResponseEntity<>("не удалось получить список записей в таблице по messageId, вы не передали значение messageId", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        List<FileZSK> fileZSKList = dbService.getRecordsMessageId(messageId);

        if (fileZSKList == null) {
            logger.error("UsbLog:Error - не удалось получить записи со messageId: {} в таблице (возможно что их нет)", messageId);
            return new ResponseEntity<>("Ошибка, не удалось получить записи с messageId: " + messageId + " в таблице  (возможно что их нет)", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (fileZSKList.size() == 0) {
            logger.error("UsbLog:Error - не удалось получить записи с messageId: {} в таблице (возможно что их нет)", messageId);
            return new ResponseEntity<>("не удалось получить записи с messageId: " + messageId + " в таблице  (возможно что их нет)", HttpStatus.OK);
        }
        logger.info("Получено {} записей из БД с messageId:{}", fileZSKList.size(), messageId);
        return ResponseEntity.status(HttpStatus.OK).body(fileZSKList);
    }

    /**
     * Получение списка записей по имени файла
     * @param fileName
     * @return
     */
    @GetMapping(value = "/filename/{filename}")
    @Operation(summary = "Получить список записей из таблицы по File name.")
    public @ResponseBody ResponseEntity<?> getRecordsByFileName(@Parameter(description = "FileName=KYCCL_0274062111_2275_20230120_000001")
                                                                 @PathVariable("filename") String fileName) {
        if (fileName == null) {
            logger.error("UsbLog:Error - не удалось получить список записей в таблице по fileName. fileName передан = NULL!");
            return new ResponseEntity<>("не удалось получить список записей в таблице по fileName, вы не передали значение fileName", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        List<FileZSK> fileZSKList = dbService.getRecordsFileName(fileName);

        if (fileZSKList == null) {
            logger.error("UsbLog:Error - не удалось получить записи со fileName: {} в таблице (возможно что их нет)", fileName);
            return new ResponseEntity<>("Ошибка, не удалось получить записи с fileName: " + fileName + " в таблице  (возможно что их нет)", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (fileZSKList.size() == 0) {
            logger.error("UsbLog:Error - не удалось получить записи с fileName: {} в таблице (возможно что их нет)", fileName);
            return new ResponseEntity<>("не удалось получить записи с fileName: " + fileName + " в таблице  (возможно что их нет)", HttpStatus.OK);
        }
        logger.info("Получено {} записей из БД с fileName:{}", fileZSKList.size(), fileName);
        return ResponseEntity.status(HttpStatus.OK).body(fileZSKList);
    }

    /**
     * Получение списка записей по дате
     * @param ldate
     * @return
     */
    @GetMapping(value = "/date/{ldate}")
    @Operation(summary = "Получить список записей из таблицы по дате.")
    public @ResponseBody ResponseEntity<?> getRecordsByDate(@Parameter(description = "Date=dd.mm.yyyy")
                                                                @PathVariable("ldate") String ldate) {
        if (ldate == null) {
            logger.error("UsbLog:Error - не удалось получить список записей в таблице по date. date передан = NULL!");
            return new ResponseEntity<>("не удалось получить список записей в таблице по date, вы не передали значение date", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        List<FileZSK> fileZSKList = dbService.getRecordsDate(ldate);

        if (fileZSKList == null) {
            logger.error("UsbLog:Error - не удалось получить записи со date: {} в таблице (возможно что их нет)", ldate);
            return new ResponseEntity<>("Ошибка, не удалось получить записи с date: " + ldate + " в таблице  (возможно что их нет)", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (fileZSKList.size() == 0) {
            logger.error("UsbLog:Error - не удалось получить записи с ldate: {} в таблице (возможно что их нет)", ldate);
            return new ResponseEntity<>("не удалось получить записи с ldate: " + ldate + " в таблице  (возможно что их нет)", HttpStatus.OK);
        }
        logger.info("Получено {} записей из БД с ldate:{}", fileZSKList.size(), ldate);
        return ResponseEntity.status(HttpStatus.OK).body(fileZSKList);
    }
}
