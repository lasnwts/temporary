package ru.usb.zskstat.model;

import io.swagger.v3.oas.annotations.media.Schema;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * @Entity
 * @Table(name = "citianniversary")
 * public class UUIDAnniversaryW1 {
 *     @Id
 *     @GeneratedValue(generator = "increment")
 *     @GenericGenerator(name = "increment", strategy = "increment")
 *     private long id;
 */

@Entity
@Table(name = "zsk945028")
public class FileZSK {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    @Schema(description = "Дата добавления в таблицу")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputdate;

    @Schema(description = "Дата обновления")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastupdatedate;

    /**
     * Имя файла основного сообщения, имя, абсолютный путь с именем, размер
     */
    @Schema(description = "Имя файла (enc)")
    private String fileNameEnc;
    @Schema(description = "Абсолютный путь к файлу enc")
    private String fileEncAbsolutePath;
    @Schema(description = "Размер файла enc")
    private long fileEncSize;

    /**
     * Имя файла открепленной подписи, имя, абсолютный путь с именем, размер
     */
    @Schema(description = "Имя файла (sig)")
    private String fileNameSig;
    @Schema(description = "Абсолютный путь к файлу sig")
    private String fileSigAbsolutePath;
    @Schema(description = "Размер файла sig")
    private long fileSigSize;

    /**
     * Статус отправки
     * true - успешно отправлен
     * false - не отправлен
     */
    @Schema(description = "Статус")
    private String status;

    /**
     * Сообщения об ошибках, связанное с отправкой сообщения
     */
    @Schema(description = "Сообщение")
    private String message;

    /**
     * MessageId полученное из ЦБ
     */
    @Schema(description = "Уникальный идентификатор из ЦБ MessageId")
    private String messageId;

    /**
     * Строковая дата и время из ЦБ, когда было создано сообщение
     */
    @Schema(description = "Строковая дата и время из ЦБ, когда было создано сообщение")
    private String createDateCB;


    /**
     * Наименование отчета в ЦБ
     */
    @Schema(description = "Наименование отчета в ЦБ")
    private String  title;

    /**
     * Имя задачи Zadacha_137
     */
    @Schema(description = "Имя задачи Zadacha_137")
    private String TaskName;

    /**
     * Общий размер сообщения ENC+SIG
     */
    @Schema(description = "Общий размер сообщения ENC+SIG")
    public long TotalSize;

    public FileZSK() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getInputdate() {
        return inputdate;
    }

    public void setInputdate(Date inputdate) {
        this.inputdate = inputdate;
    }

    public Date getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(Date lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public String getFileNameEnc() {
        return fileNameEnc;
    }

    public void setFileNameEnc(String fileNameEnc) {
        this.fileNameEnc = fileNameEnc;
    }

    public String getFileEncAbsolutePath() {
        return fileEncAbsolutePath;
    }

    public void setFileEncAbsolutePath(String fileEncAbsolutePath) {
        this.fileEncAbsolutePath = fileEncAbsolutePath;
    }

    public long getFileEncSize() {
        return fileEncSize;
    }

    public void setFileEncSize(long fileEncSize) {
        this.fileEncSize = fileEncSize;
    }

    public String getFileNameSig() {
        return fileNameSig;
    }

    public void setFileNameSig(String fileNameSig) {
        this.fileNameSig = fileNameSig;
    }

    public String getFileSigAbsolutePath() {
        return fileSigAbsolutePath;
    }

    public void setFileSigAbsolutePath(String fileSigAbsolutePath) {
        this.fileSigAbsolutePath = fileSigAbsolutePath;
    }

    public long getFileSigSize() {
        return fileSigSize;
    }

    public void setFileSigSize(long fileSigSize) {
        this.fileSigSize = fileSigSize;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getCreateDateCB() {
        return createDateCB;
    }

    public void setCreateDateCB(String createDateCB) {
        this.createDateCB = createDateCB;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTaskName() {
        return TaskName;
    }

    public void setTaskName(String taskName) {
        TaskName = taskName;
    }

    public long getTotalSize() {
        return TotalSize;
    }

    public void setTotalSize(long totalSize) {
        TotalSize = totalSize;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        return "FileZSK{" +
                "id=" + id +
                ", inputdate=" + inputdate +
                ", lastupdatedate=" + lastupdatedate +
                ", fileNameEnc='" + fileNameEnc + '\'' +
                ", fileEncAbsolutePath='" + fileEncAbsolutePath + '\'' +
                ", fileEncSize=" + fileEncSize +
                ", fileNameSig='" + fileNameSig + '\'' +
                ", fileSigAbsolutePath='" + fileSigAbsolutePath + '\'' +
                ", fileSigSize=" + fileSigSize +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", messageId='" + messageId + '\'' +
                ", createDateCB='" + createDateCB + '\'' +
                ", title='" + title + '\'' +
                ", TaskName='" + TaskName + '\'' +
                ", TotalSize=" + TotalSize +
                '}';
    }
}
