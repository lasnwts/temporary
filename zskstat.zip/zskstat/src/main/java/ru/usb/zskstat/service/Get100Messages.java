package ru.usb.zskstat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zskstat.configure.Configure;
import ru.usb.zskstat.model.LsitZadacha130;
import ru.usb.zskstat.model.Zadacha130;

import java.util.List;


@Service
public class Get100Messages {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(Get100Messages.class);

    String url;

    public String Get100Messages() {

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        url = configure.getZskBaseurl() + "/messages";

        logger.info("GetMessages:Prepared:Url:" + url);

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
        String messages = response.getBody();

        if (configure.isLogDebug()) {
            logger.info("Get 100 messages Messages:{}", messages);
        }
        return messages;
    }
}
