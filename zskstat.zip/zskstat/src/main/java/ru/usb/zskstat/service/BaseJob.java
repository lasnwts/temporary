package ru.usb.zskstat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.zskstat.configure.Configure;
import ru.usb.zskstat.model.FileZSK;
import ru.usb.zskstat.model.Zadacha130;
import ru.usb.zskstat.service.email.EmailService;
import ru.usb.zskstat.utils.CUtility;
import ru.usb.zskstat.utils.JsonMapper130;
import ru.usb.zskstat.utils.MapperZskFile;

import javax.mail.internet.AddressException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.function.Consumer;

@Service
public class BaseJob {

    Logger logger = LoggerFactory.getLogger(BaseJob.class);

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    @Autowired
    Configure configure;

    @Autowired
    DbService dbService;

    @Autowired
    CUtility cu;

    @Autowired
    JsonMapper130 mapper;
    @Autowired
    GetMetaFromMessage getMetaFromMessage;

    @Autowired
    MapperZskFile mapperZskFile;

    @Autowired
    EmailService emailService;

    /**
     * Получить количество записей в таблице БД
     *
     * @return
     */
    public long getCountRecords() {
        return dbService.getCountRecords();
    }

    /**
     * Базовый процесс сканирования таблицы
     */
    public void baseProcess() {

        //test
        List<FileZSK> fileZSKList = dbService.getRecordsDateStatus("21.08.2023");


        //List<FileZSK> fileZSKList = dbService.getRecordsDateStatus(sdf.format(new Date()));

        if (fileZSKList == null) {
            return;
        }

        //Отладочное логирование..
        if (configure.isLogDebug()) {
            logger.info("UsbLog: Список записей для формирования запроса в ЦБ");
        }
        //Запрашиваем ЦБ
        fileZSKList.forEach(new Consumer<FileZSK>() {
            @Override
            public void accept(FileZSK fileZSK) {

                //Отладочное логирование..
                if (configure.isLogDebug()) {
                    logger.info("UsbLog:{}", fileZSK.toString());
                }

                Zadacha130 zadacha130 = null;

                try {
                    zadacha130 = getMetaFromMessage.GetMetaFromFile(cu.getWrapNull(fileZSK.getMessageId()));
                } catch (Exception e) {
                    logger.error("UsbLog: Error:getMetaFromMessage.GetMetaFromFileL - ошибка запроса с id:{}", fileZSK.getMessageId());
                }

                if (zadacha130 != null) {
                    if (configure.isLogDebug()) {
                        logger.info(mapper.getJsonToStr(zadacha130));
                    }

                    FileZSK fzsk = mapperZskFile.mapFileZSK(zadacha130, fileZSK);
                    dbService.saveFileZSK(fzsk); //Сохраняем в БД
                    //dbService.saveFileZSK(mapperZskFile.mapFileZSK(zadacha130, fileZSK)); //Сохраняем в БД

                    /**
                     * Блок отправки писем
                     */
                    //Отвергнуто
                    if (zadacha130.getStatus().trim().toLowerCase().contains("rejected")) {
                        logger.error("UsbLog: Отклонено[rejected]:Сообщение:{}", mapper.getJsonToStr(zadacha130));
                        logger.error("UsbLog: Сообщение с id:{} отклонено ЦБ:rejected", fileZSK.getMessageId());
                        //Отправляем почту
                        try {
                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                                    "Сообщение не принято в ЦБ [rejected] : " + mapper.getJsonToStr(zadacha130));
                        } catch (AddressException e) {
                            logger.error("Ошибка отправки письма по адресу:{}", configure.getMailTo());
                        }
                    }

                    //Отвергнуто
                    if (zadacha130.getStatus().trim().toLowerCase().contains("error")) {
                        logger.error("UsbLog: Отклонено[error]:Сообщение:{}", mapper.getJsonToStr(zadacha130));
                        logger.error("UsbLog: Сообщение с id:{} отклонено ЦБ:rejected", fileZSK.getMessageId());
                        //Отправляем почту
                        try {
                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                                    "Сообщение не принято в ЦБ [error] : " + mapper.getJsonToStr(zadacha130));
                        } catch (AddressException e) {
                            logger.error("Ошибка отправки письма по адресу:{}", configure.getMailTo());
                        }
                    }

                    //Принято
//                    if (zadacha130.getStatus().trim().toLowerCase().contains("registered")){
//
//                    }

                    //Количество попыток больше нормы (c
                    if (fileZSK.getTotalSize() == configure.getServiceTryCount()) {
                        logger.error("UsbLog: Кол-во попыток={} достигнут предел, отправим email. Для Сообщения:{}", fileZSK.getTotalSize(), mapper.getJsonToStr(zadacha130));
                        //Отправляем почту
                        try {
                            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                                    "Сообщение ПОКА не принято в ЦБ [количество попыток=" + fileZSK.getTotalSize() + "] : " + mapper.getJsonToStr(zadacha130));
                        } catch (AddressException e) {
                            logger.error("Ошибка отправки письма по адресу:{}", configure.getMailTo());
                        }
                    }

                }
            }
        });
    }


}
