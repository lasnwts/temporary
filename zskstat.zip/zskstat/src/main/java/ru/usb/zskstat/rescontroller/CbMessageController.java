package ru.usb.zskstat.rescontroller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.zskstat.dto.QuotaWrapResponse;
import ru.usb.zskstat.model.Quota;
import ru.usb.zskstat.service.Get100Messages;
import ru.usb.zskstat.service.GetMetaFromMessage;
import ru.usb.zskstat.service.GetQuota;
import ru.usb.zskstat.utils.CUtility;
import ru.usb.zskstat.utils.JsonMapper130;

/**
 * https://habr.com/ru/articles/541592/
 *
 * @Operation - Описывает операцию или обычно метод HTTP для определенного пути. *
 * @Parameter - Представляет один параметр в операции OpenAPI. *
 * @RequestBody - Представляет тело запроса в операции *
 * @ApiResponse - Представляет ответ в операции *
 * @Tag - Представляет теги для операции или определения OpenAPI. *
 * @Server - Представляет серверы для операции или для определения OpenAPI. *
 * @Callback - Описывает набор запросов *
 * @Link - Представляет возможную ссылку времени разработки для ответа. *
 * @Schema - Позволяет определять входные и выходные данные. *
 * @ArraySchema - Позволяет определять входные и выходные данные для типов массивов. *
 * @Content - Предоставляет схему и примеры для определенного типа мультимедиа. *
 * @Hidden - Скрывает ресурс, операцию или свойство
 */


@RestController
@RequestMapping("/api/cb")
@Tag(name = "Контроллер для работы с запросами в ЦБ", description = "Проверка статусов сообщений")
public class CbMessageController {

    private Logger logger = LoggerFactory.getLogger(DbController.class);

    @Autowired
    GetQuota getQuota;

    @Autowired
    CUtility cu;

    @Autowired
    Get100Messages get100Messages;

    @Autowired
    GetMetaFromMessage getMetaFromMessage;

    @Autowired
    JsonMapper130 mapper;

    @GetMapping("/message/{messageid}")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на получение сообщения. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b ")
    public ResponseEntity getMessage(@Parameter(description = "messageId=0be38c5f-36ca-4505-9838-af90010601e2")
                                     @PathVariable("messageid") String messageId) {

        if (messageId == null) {
            logger.error("UsbLog:Error - не удалось получить список записей в таблице по messageId. messageId передан = NULL!");
            return new ResponseEntity<>("не удалось получить список записей в таблице по messageId, вы не передали значение messageId", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        logger.info("post request getFile:" + messageId);

        try {
            String response130 = mapper.getJsonToStr(getMetaFromMessage.GetMetaFromFile(messageId));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, "application/json")
                    .body(response130);
        } catch (Exception exception) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!! Request to CB return error! !!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::{}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.getMessage().toString());
        }
    }

    /**
     * Получение всех 100 сообщений, последних
     *
     * @return
     */
    @GetMapping("/get100message")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на получение 100 последних сообщения. Желательно не запускать на проде, можно сбить автоматическую загрузку файлов Риска.")
    public ResponseEntity get100Message() {

        try {
            String message100 = get100Messages.Get100Messages();
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, "application/json")
                    .body(message100);
        } catch (Exception exception) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!! Request to CB return error! !!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::{}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.getMessage().toString());
        }
    }


    @GetMapping("/quota")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос квоты: Messages в ответ на который будут получены размеры квоты")
    public ResponseEntity<?> getQuota() {
        logger.info("Request for Quota...");
        QuotaWrapResponse quotaWrapResponse = getQuota.getQuota();
        if (quotaWrapResponse.isCode()) {
            Quota quota = quotaWrapResponse.getQuota();
            return ResponseEntity.status(HttpStatus.OK).body(quota);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(cu.getWrapNull(quotaWrapResponse.getMessage()));
        }
    }

}
