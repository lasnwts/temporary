package ru.usb.zskstat.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


import java.util.ArrayList;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Receipts {

    @JsonProperty("ReceiveTime")
    private String ReceiveTime;

    @JsonProperty("StatusTime")
    private String StatusTime;

    @JsonProperty("Status")
    private String Status;

    @JsonProperty("Message")
    private String Message;

    @JsonProperty("Files")
    public ArrayList<Zadacha130File> files;

    public Receipts() {
    }

    public Receipts(String receiveTime, String statusTime, String status,
                    String message, ArrayList<Zadacha130File> files) {
        ReceiveTime = receiveTime;
        StatusTime = statusTime;
        Status = status;
        Message = message;
        this.files = files;
    }

    public String getReceiveTime() {
        return ReceiveTime;
    }

    public void setReceiveTime(String receiveTime) {
        ReceiveTime = receiveTime;
    }

    public String getStatusTime() {
        return StatusTime;
    }

    public void setStatusTime(String statusTime) {
        StatusTime = statusTime;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public ArrayList<Zadacha130File> getFiles() {
        return files;
    }

    public void setFiles(ArrayList<Zadacha130File> files) {
        this.files = files;
    }

    @Override
    public String toString() {
        return "Receipts{" +
                "ReceiveTime='" + ReceiveTime + '\'' +
                ", StatusTime='" + StatusTime + '\'' +
                ", Status='" + Status + '\'' +
                ", Message='" + Message + '\'' +
                '}';
    }
}
