package ru.usb.zskstat.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.sql.Date;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Configuration
public class CUtility {

    /**
     * формат даты-времени
     */
    LocalDate date;
    DateTimeFormatter shortDateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    Logger logger = LoggerFactory.getLogger(CUtility.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yyyy
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, shortDateFormat);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = {}  не соответствует формату ::{}", sDate, shortDateFormat.toString());
            return false;
        }
    }


    /**
     * Преобразование строковой даты типа "dd.MM.yyyy" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate(String sDate) {
        try {
            return LocalDate.parse(sDate, shortDateFormat);
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = {}  не соответствует формату ::{}", sDate, shortDateFormat.toString());
            return null;
        }
    }


    /**
     * Проеобразование между локальной датой LocalDate в Sql.Date
     *
     * @param ldate
     * @return
     */
    public Date getSqlDate(LocalDate ldate) {
        try {
            Date sqlDate = Date.valueOf(ldate);
            return sqlDate;
        } catch (Exception e) {
            logger.error("Дата = {} не соответствует формату ::{}", ldate, shortDateFormat.toString());
            return null;
        }
    }


    /**
     * Возвращаем часть подстроки длиной менее 3997 символов
     *
     * @param line исходная строка
     * @return - обрезанная строка
     */
    public String getMaxLength3998(String line) {
        if (line == null) {
            return "";
        }
        if (line.trim().length() < 3900) {
            return line;
        }
        return line.trim().substring(0, 3900);
    }

    /**
     * Возвращаем часть подстроки длиной менее 2048 символов
     *
     * @param line исходная строка
     * @return - обрезанная строка
     */
    public String getMaxLength2048(String line) {
        if (line == null) {
            return "";
        }
        if (line.trim().length() < 2000) {
            return line;
        }
        return line.trim().substring(0, 1958);
    }

    /**
     * Возвращаем часть подстроки длиной менее 512 символов
     *
     * @param line исходная строка
     * @return - обрезанная строка
     */
    public String getMaxLength512(String line) {
        if (line == null) {
            return "";
        }
        if (line.trim().length() < 500) {
            return line;
        }
        return line.trim().substring(0, 410);
    }

    /**
     * Возвращаем часть подстроки длиной менее 255 символов
     *
     * @param line исходная строка
     * @return - обрезанная строка
     */
    public String getMaxLength255(String line) {
        if (line == null) {
            return "";
        }
        if (line.trim().length() < 200) {
            return line;
        }
        return line.trim().substring(0, 170);
    }
}
