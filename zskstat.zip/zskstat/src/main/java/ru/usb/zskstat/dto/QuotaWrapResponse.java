package ru.usb.zskstat.dto;

import ru.usb.zskstat.model.Quota;

public class QuotaWrapResponse {
    private Quota quota;
    private boolean code; //Код ошибки: 0 - порядок, 1 - ошибка
    private String message; //Строка с ошибкой

    public QuotaWrapResponse() {
    }

    public Quota getQuota() {
        return quota;
    }

    public void setQuota(Quota quota) {
        this.quota = quota;
    }

    public boolean isCode() {
        return code;
    }

    public void setCode(boolean code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
