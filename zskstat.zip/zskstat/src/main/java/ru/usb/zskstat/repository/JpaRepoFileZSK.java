package ru.usb.zskstat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import ru.usb.zskstat.model.FileZSK;

import javax.persistence.QueryHint;
import java.sql.Date;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;


public interface JpaRepoFileZSK extends JpaRepository<FileZSK, Long> {

    /********************************************************************************************************************************************
     * Поиск по messageId
     * @param messageId
     * @return
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from zsk945028 where message_id= :messageId", nativeQuery = true) //тест
    List<FileZSK> getFromMessageId(@Param("messageId") String  messageId);

    /********************************************************************************************************************************************
     * Поиск по Status
     * @param status
     * @return
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from zsk945028 where status like :statusLine", nativeQuery = true) //тест
    List<FileZSK> getFromStatus(@Param("statusLine") String  status);

    /********************************************************************************************************************************************
     * Поиск по FileNameEnc
     * @param filename
     * @return
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from zsk945028 where file_name_enc like %?1%", nativeQuery = true) //тест
    List<FileZSK> getFromFileName(String  filename);

    /********************************************************************************************************************************************
     * Поиск по Дате отправки
     * @param dateStart, dateEnd
     * @return
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from zsk945028 where inputdate >= :datestart and inputdate <= :dateend", nativeQuery = true) //тест
    List<FileZSK> getFromDate(@Param("datestart") Date  dateStart, @Param("dateend") Date  dateEnd);

    /********************************************************************************************************************************************
     * Поиск по Дате отправки, которые не содержат конечные статусы: error, rejected или registered
     * @param dateStart, dateEnd
     * @return
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "2000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select * from zsk945028 where status not in ('registered', 'error', 'rejected') and inputdate >= :datestart and inputdate <= :dateend", nativeQuery = true) //тест
    List<FileZSK> getStatus(@Param("datestart") Date  dateStart, @Param("dateend") Date  dateEnd);

}
