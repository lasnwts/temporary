package ru.usb.zskstat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.usb.zskstat.configure.Configure;
import ru.usb.zskstat.model.Zadacha130;

//e4e31875-bb55-40c0-bd96-aebb01272ab0

/**
 * Сервис для получения статуса сообщения, пример e4e31875-bb55-40c0-bd96-aebb01272ab0
 * ==============================================================================================================================================
 * Статус	    Статус в ЛК   	        Описание
 * draft	    Черновик	         Сообщение с данным статусом создано, но ещё не отправлено.
 * sent	        Отправлено	         Сообщение получено сервером
 * delivered	Загружено	         Сообщение прошло первоначальную проверку
 * error	    Ошибка	            При обработке сообщения возникла ошибка
 * processing	Принято в обработку	Сообщение передано во внутреннюю систему Банка России
 * registered	Зарегистрировано	Сообщение зарегистрировано
 * rejected	    Отклонено	        Сообщение успешно дошло до получателя, но было отклонено
 * new	        Новое	            Только для входящих сообщений. Сообщение в данном статусе ещё не почтено Пользователем УИО.
 * read	        Прочитано	        Только для входящих сообщений. Сообщение в данном статусе почтено Пользователем УИО.
 * replied	    Отправлен ответ	    Только для входящих сообщений. На сообщение в данном статусе направлен ответ.
 * success	    Доставлено	        Сообщение успешно размещено в ЛК/Сообщение передано роутером во внутреннюю систему Банка России,
 *                                  от которой не ожидается ответ о регистрации
 */
@Service
public class GetMetaFromMessage {

    @Autowired
    Configure configure;

    RestTemplate restTemplate = new RestTemplate();

    Logger logger = LoggerFactory.getLogger(GetMetaFromMessage.class);

    String url;

    public Zadacha130 GetMetaFromFile(String messageId) {

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(configure.getZskLogin(), configure.getZskPassword());
        HttpEntity request = new HttpEntity(headers);

        url = configure.getZskBaseurl() + "/messages/" + messageId;

        logger.info("GetFile:Prepared:Url:" + url);

        Zadacha130 zadacha130 = null;

        try {
            ResponseEntity<Zadacha130> response = restTemplate.exchange(url, HttpMethod.GET, request, Zadacha130.class);
            zadacha130 = response.getBody();
        } catch (Exception e){
            logger.error("Ошибка запроса url:{} на сервере ЦБ:{}", url, e.getMessage());
            return null;
        }

        if (configure.isLogDebug()){
            logger.info("GetMetaFrom Message:GET META from messageID=" + messageId + " ::" + zadacha130.toString());
        }

        return zadacha130;
    }
}
