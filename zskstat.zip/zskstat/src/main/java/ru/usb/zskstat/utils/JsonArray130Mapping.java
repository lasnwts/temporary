package ru.usb.zskstat.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.zskstat.model.Zadacha130;

import java.util.List;

@Component
public class JsonArray130Mapping {
    Logger logger = LoggerFactory.getLogger(JsonArray130Mapping.class);

    ObjectMapper objectMapper = new ObjectMapper();


    /**
     * Преобразование объекта в строку JSON
     * @param zadacha130list
     * @return
     */
    public String getJsonToStr(List<Zadacha130> zadacha130list) {

        if (zadacha130list == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [zadacha130list] == NULL! Класс [SiebelMapper] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(zadacha130list);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [zadacha130list] в JSON строку! Класс [SiebelMapper] метод [getJsonToStr]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
