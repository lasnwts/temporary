package ru.usb.jdbcchdsftpgoldencrown.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    /**
     * Header in file
     */
    @Value("${file.header1}")
    private String header1;

    @Value("${file.header2}")
    private String header2;

    @Value("${line.param1}")
    private String lineParam1;

    @Value("${line.param2}")
    private String lineParam2;

    public String getLineParam1() {
        return lineParam1;
    }

    public String getLineParam2() {
        return lineParam2;
    }

    public String getHeader1() {
        return header1;
    }

    public String getHeader2() {
        return header2;
    }

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.application.version}")
    private String appVersion;

    @Value("${service.log.debug}")
    private boolean logDebug;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     * Нустройка SFTP сервере
     */

    @Value("${sftp.host}")
    private String sftpHost;

    @Value("${sftp.port}")
    private int sftpPort;

    @Value("${sftp.user}")
    private String sftpUser;

    @Value("${sftp.password}")
    private String sftpPassword;
    @Value("${sftp.key_file}")
    private String sftpKeyFile;

    @Value("${net.file.share}")
    private String netFileShare;

    @Value("${sftp.need.key:false}")
    private boolean sftpNeedKey;

    /**
     * Директории  на sftp сервере
     */
    //Директория для отправки файлов в Банк
    @Value("${sftp.directory}")
    private String sftpDirectory;
    @Value("${bank.archive.confirmed:false}")
    private boolean bankArchiveXConfirmed; //true - скачиваем все файлы, false - только xml
    @Value("${sftp.directory.to.bank}")
    private String sftpDirectoryToBank;

    /**
     * Директории на сервере локальном
     */
    @Value("${directory.archive}")
    private String directoryArchivedFromSftp;

    public String getSftpDirectoryToBank() {
        return sftpDirectoryToBank;
    }

    /**
     * Реализация
     */

    public String getSftpHost() {
        return sftpHost;
    }

    public int getSftpPort() {
        return sftpPort;
    }

    public String getSftpUser() {
        return sftpUser;
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public String getSftpKeyFile() {
        return sftpKeyFile;
    }

    public String getSftpDirectory() {
        return sftpDirectory;
    }


    public String getServiceUser() {
        return serviceUser;
    }

    public String getServicePassword() {
        return servicePassword;
    }

    /**
     * Реализация
     */
    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public boolean isLogDebug() {
        return logDebug;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getNetFileShare() {
        return netFileShare;
    }

    public boolean isBankArchiveXConfirmed() {
        return bankArchiveXConfirmed;
    }

    /**
     * Установка директории
     * @return
     */
    public String getTempDirUploadFile() {
        return tempDirUploadFile;
    }

    public String getMailToBusiness() {
        return mailToBusiness;
    }

    public void setTempDirUploadFile(String tempDirUploadFile) {
        this.tempDirUploadFile = tempDirUploadFile;
    }

    public boolean isSftpNeedKey() {
        return sftpNeedKey;
    }

    public String getDirectoryArchivedFromSftp() {
        return directoryArchivedFromSftp;
    }
}
