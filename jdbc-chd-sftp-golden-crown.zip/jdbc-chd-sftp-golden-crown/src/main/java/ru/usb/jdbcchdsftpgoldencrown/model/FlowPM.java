package ru.usb.jdbcchdsftpgoldencrown.model;

import javax.persistence.*;


/**
 * CREATE TABLE SEND_PROMOCODE2
 *    (	"FULL_NAME" VARCHAR2(194 CHAR),
 * 	"PHONE" VARCHAR2(64 CHAR),
 * 	"IBSO_CLIENT_ID" NUMBER,
 * 	"CARD_INNER_ID" VARCHAR2(300 BYTE),
 * 	"LOYALTY_ID" VARCHAR2(500 BYTE),
 * 	"MONTH" VARCHAR2(8 BYTE),
 * 	"PROMO" VARCHAR2(44 BYTE),
 * 	"POINTS" NUMBER,
 * 	"SOURCE" CHAR(2 BYTE),
 * 	"DATE_INSERT" VARCHAR2(14 BYTE)
 *    );
 */

@Entity
public class FlowPM {

    @Id
    @Column(name = "IBSO_CLIENT_ID")
    private String ibsoClientId;

    @Column(name = "FULL_NAME")
    private String fullName;

    @Column(name = "PHONE")
    private String phone;

    @Column(name = "CARD_INNER_ID")
    private String cardInnerId;

    @Column(name = "LOYALTY_ID")
    private String loyaltyId;

    @Column(name = "MONTH")
    private String month;

    @Column(name = "PROMO")
    private String promo;

    @Column(name = "POINTS")
    private String points;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "DATE_INSERT")
    private String dateInsert;


    public FlowPM() {
        //
    }

    public FlowPM(String ibsoClientId, String fullName, String phone, String cardInnerId, String loyaltyId,
                  String month, String promo, String points, String source, String dateInsert) {
        this.ibsoClientId = ibsoClientId;
        this.fullName = fullName;
        this.phone = phone;
        this.cardInnerId = cardInnerId;
        this.loyaltyId = loyaltyId;
        this.month = month;
        this.promo = promo;
        this.points = points;
        this.source = source;
        this.dateInsert = dateInsert;
    }

    public String getIbsoClientId() {
        return ibsoClientId;
    }

    public void setIbsoClientId(String ibsoClientId) {
        this.ibsoClientId = ibsoClientId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCardInnerId() {
        return cardInnerId;
    }

    public void setCardInnerId(String cardInnerId) {
        this.cardInnerId = cardInnerId;
    }

    public String getLoyaltyId() {
        return loyaltyId;
    }

    public void setLoyaltyId(String loyaltyId) {
        this.loyaltyId = loyaltyId;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getPromo() {
        return promo;
    }

    public void setPromo(String promo) {
        this.promo = promo;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDateInsert() {
        return dateInsert;
    }

    public void setDateInsert(String dateInsert) {
        this.dateInsert = dateInsert;
    }

    public String toCSV(){
        return "P;T7813;" +  ibsoClientId + ";" + fullName + ";810;" + cardInnerId  + ";";
    }

}
