package ru.usb.jdbcchdsftpgoldencrown.utils;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.model.FlowPM;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.stream.Stream;


/**
 * Вспомогательный класс для работы
 */
@Component
public class Support {

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(Support.class);
    /**
     * формат даты-времени
     */
    LocalDate date;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    SimpleDateFormat sdfHead = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat sdfPartName = new SimpleDateFormat("ddMMyy");
    SimpleDateFormat hourPart = new SimpleDateFormat("HH");
    DateTimeFormatter formatterHeader = DateTimeFormatter.ofPattern("yyyyMMdd");

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Провекра, что поток не NULL
     *
     * @param fTableStream - поток
     * @return
     */
    public boolean checkStreamTable(Stream<FlowPM> fTableStream) {
        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!+++");
            logger.error("!!!!!!!!!!!!! fTableStream==null");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!----");
            return false;
        }
        return true;
    }

    public String getHeader() {

        /**
         * From: Anokhina Olga 1 [mailto:olg.anokhina@korona.net]
         * Sent: Monday, January 29, 2024 12:59 PM
         * To: Дзан Владимир Васильевич <DzanVV@uralsib.ru>
         * Cc: Rybakov Aleksandr <a.rybakov@korona.net>
         * Subject: sca-файлы
         * Владимир, привет!
         * Заметили, что вы передаете некорректно идентификаторы в sca-файлах:
         * H;6097175;6101914;20240127;20240127073444
         * Должно быть наоборот:
         * H:6101914;6097175;20240127;20240127073444
         * Поправьте, пожалуйста.
         * С уважением, Анохина Ольга (+7913 749 99 20).
         */
        return "H;" + configure.getHeader1() + ";" + configure.getHeader2() + ";" + sdfHead.format(new Date()) + ";" + sdf.format(new Date());
    }


    /**
     * Получаем сумму для PM файла.
     * Формат без разделителя - запятой.
     * Пример 164.78 = '16478' или 164.7 = '16470'
     *
     * @param summa - строка суммы
     * @return - готовое значение
     */

    public String getSummaFormatter(String summa) {
        if (summa == null) {
            return "";
        }
        if (summa.contains(".")) {
            String firstPart = summa.trim().substring(0, summa.indexOf("."));
            String secondPart = summa.trim().substring(summa.indexOf(".") + 1, summa.length());
            if (firstPart.equals(".")) {
                firstPart = "";
            }
            if (secondPart.isEmpty()) {
                secondPart = "00";
            }
            if (secondPart.length() == 1) {
                secondPart = secondPart + "0";
            }
            if (secondPart.length() > 2) {
                logger.error("Передана сумма с ошибкой, число после запятой должно быть 2, передано больше! SUMMA={}", summa.trim());
                secondPart = secondPart.substring(0, 1);
            }
            if (configure.isLogDebug()) {
                logger.info("Преобразование суммы [getSummaFormatter], пришло: {} после преобразования: {} ", summa, firstPart + secondPart);
            }
            return firstPart + secondPart;
        } else {
            if (configure.isLogDebug()) {
                logger.info("Преобразование суммы [getSummaFormatter], пришло:  {} после преобразования: {} ", summa, summa.trim() + "00");
            }
            return summa.trim() + "00";
        }
    }

    /**
     * Получаем имя фала
     *
     * @return - готовое имя файла
     */
    public String getFileName() {
        return "PM_URSB." + getDatePartName();
    }

    /**
     * Часть даты + час, пример 10.04.2024 12 часов => 1004242
     *
     * @return - возвращает 1004242
     */
    private String getDatePartName() {
        return sdfPartName.format(new Date()) + getHour();
    }

    /**
     * Получаем час запуска
     *
     * @return - 2 или 6
     */
    private String getHour() {
        return getPartHour(hourPart.format(new Date()));
    }

    /**
     * Получаем часть часа, например 12 часов, получим 2,
     *
     * @param hours - строковое представление часов
     * @return - 2 или 6
     */
    private String getPartHour(String hours) {
        if (hours.length() > 1) {
            return hours.substring(1);
        }
        return hours;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        if (fileNameFull == null){
            return false;
        }
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :: [{}] not Exist.Fail!", Elog.UsbLogWarning, fileNameFull);
        return false;
    }

    /**
     * Экранирование двойных кавычек.
     * @param line
     * @return
     */
    public String getDoubleQuote(String line){
        return "\"" + getWrapNull(line).replace("\"", "\"\"") + "\"";
    }


    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param destinationDirectory   - куда (полный путь с именем)
     */
    public boolean moveFileSName(File fromFile, String destinationDirectory) {
        if (fromFile == null){
            return false;
        }
        Path from = fromFile.toPath();
        Path to = Paths.get(destinationDirectory + FileSystems.getDefault().getSeparator() + fromFile.getName());
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toFile())) {
                FileUtils.forceDelete(from.toFile());
                logger.info("{}: file:: {} moved to:{}", Elog.UsbLogError, from, to);
                return true;
            } else {
                logger.error("{}: Error for operation move:: file::{} moved to:{}", Elog.UsbLogError, from, to);
                return false;
            }
        } catch (IOException e) {
            logger.error("{}:PrintStackTrace::", Elog.UsbLogError, e);
            return false;
        }
    }

}
