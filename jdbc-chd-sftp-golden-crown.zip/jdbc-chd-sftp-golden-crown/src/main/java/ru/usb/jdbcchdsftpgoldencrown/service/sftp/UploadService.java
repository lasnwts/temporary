package ru.usb.jdbcchdsftpgoldencrown.service.sftp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;


import java.io.File;
import java.io.IOException;

@Service
public class UploadService {
    private final Configure configApplication;

    private static final String USER_DIR = "user.dir";  // Compliant

    @Autowired
    public UploadService(Configure configApplication) {
        this.configApplication = configApplication;
    }

    public void uploadFile(MultipartFile file) throws IOException {
        file.transferTo(new File(System.getProperty(USER_DIR) + File.separator + configApplication.getNetFileShare() + File.separator + file.getOriginalFilename()));
    }

    public String uploadFileToServer(MultipartFile file) throws IOException {
        new File(System.getProperty(USER_DIR) + File.separator + configApplication.getNetFileShare()).mkdirs();
        file.transferTo(new File(System.getProperty(USER_DIR) + File.separator + configApplication.getNetFileShare() + File.separator + file.getOriginalFilename()));
        return System.getProperty(USER_DIR) + File.separator + configApplication.getNetFileShare() + File.separator + file.getOriginalFilename();
    }
}
