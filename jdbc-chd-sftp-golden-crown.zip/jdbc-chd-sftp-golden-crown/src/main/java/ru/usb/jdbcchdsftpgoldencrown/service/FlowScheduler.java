package ru.usb.jdbcchdsftpgoldencrown.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.service.dbase.GetFlowPM;
import ru.usb.jdbcchdsftpgoldencrown.service.mail.EmailServiceImpl;
import ru.usb.jdbcchdsftpgoldencrown.service.sftp.DownLoadService;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class FlowScheduler {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    private final GetFlowPM getFlowPM;
    private final EmailServiceImpl emailService;
    private final Configure configure;
    private boolean tryGetPm16hour = true; //Попробовать сформировать файл в 16 часов?
    private final DownLoadService downLoadService;

    @Autowired
    public FlowScheduler(GetFlowPM getFlowPM, EmailServiceImpl emailService, Configure configure,
                         DownLoadService downLoadService) {
        this.getFlowPM = getFlowPM;
        this.emailService = emailService;
        this.configure = configure;
        this.downLoadService = downLoadService;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    /**
     * Scheduler 1.  На 12 часов в будни, с понедельника по пятницу
     */
    @Scheduled(cron = "${interval-in-cron12}")
    public void cronScheduler12() {
        logger.info("{} Сработал таймер на 12 часов дня. ", Elog.UsbLogInfo);
        if (getFlowPM.getFlowPM()) {
            tryGetPm16hour = false; //Передавать не надо, в 12 часов все передано
            logger.info("{} Файл PM сформирован и передан успешно, отработка в 16 часов не нужна. successPmFile12Hour={}", Elog.UsbLogInfo, false);
        } else {
            tryGetPm16hour = true; //требуется попробовать передать файл в 16 часов
            logger.info("{} Возникла проблема при формировании или передаче файла PM в 12 часов. Необходимо повторить попытку в 16 часов.={}", Elog.UsbLogInfo, true);
        }
    }

    /**
     * Scheduler 2.  На 16 часов в будни, с понедельника по пятницу
     */
    @Scheduled(cron = "${interval-in-cron16}")
    public void cronScheduler16() {
        if (tryGetPm16hour){
            logger.info("{} Сработал таймер на 16 часов дня. ", Elog.UsbLogInfo);
           if(getFlowPM.getFlowPM()){
               logger.info("{} Файл PM успешно сформирован и передан в 16 часов. Обработку на сегодня {} завершаем", Elog.UsbLogInfo, new Date());
           } else {
               logger.info("{} Возникла проблема при формировании или передаче файла PM в 16 часов. Будет отправлен alert на email.", Elog.UsbLogWarning);
               //Тут надо отправить письмо
               emailService.sendSimpleEmail(configure.getMailToBusiness(), configure.getMailSubjects()
                       + "Alert! Витрина <Автоматизация процесса начисления бонусов по акциям> [SEND_PROMOCODE2] пуста! Дата=" + sdf.format(new Date()) ,
                       "Повторное обращение к витрине в 16-00. Витрина пуста. Согласно требованиям - отправляем данное письмо. <br> \n\r Требование:<br>\\ Если при штатном обращении ИС к витрине данных обновленных записей не найдено, \n\r <br> то выполнить повторное обращение к витрине в 16:00, если при повторном обращение новых данных не найдено, то создать EMAIL_ALERT");
           }
           tryGetPm16hour = false; //отключаем таймер на 16 часов
        }

    }

    /**
     * Scheduler every 10 - 15 mib.
     */
    @Scheduled(initialDelay = 1000L, fixedDelayString = "${scheduler.delay}")
    public void updatePrices() {
        //Тут обработка входящих файлов
        downLoadService.getFileFromSftp();
    }

}
