package ru.usb.jdbcchdsftpgoldencrown.model;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Класс для получения информации о файле")
public class FileRequest {

    @Schema(description = "fileName - имя файла")
    private String fileName;
    @Schema(description = "directory - путь к файлу, формат: directory/subdirectory")
    private String directory;

    public FileRequest(String fileName, String directory) {
        this.fileName = fileName;
        this.directory = directory;
    }

    public FileRequest() {
        //
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    @Override
    public String toString() {
        return "{" +
                ", file='" + directory + '\'' +
                "/" + fileName + '\'' +
                '}';
    }
}
