package ru.usb.jdbcchdsftpgoldencrown.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.jdbcchdsftpgoldencrown.model.FlowPM;


import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaFlowPM extends JpaRepository<FlowPM, Long> {

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select FULL_NAME,PHONE,IBSO_CLIENT_ID,CARD_INNER_ID,LOYALTY_ID,MONTH,PROMO,POINTS,SOURCE,DATE_INSERT from SEND_PROMOCODE2")
    Stream<FlowPM> getFlowPM();

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select FULL_NAME,PHONE,IBSO_CLIENT_ID,CARD_INNER_ID,LOYALTY_ID,MONTH,PROMO,POINTS,SOURCE,DATE_INSERT from SEND_PROMOCODE2")
    List<FlowPM> getListFlowPM();

    //Функция возвращает количество записей
    @QueryHints(value = {
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from SEND_PROMOCODE2")
    int getCountPM();

}
