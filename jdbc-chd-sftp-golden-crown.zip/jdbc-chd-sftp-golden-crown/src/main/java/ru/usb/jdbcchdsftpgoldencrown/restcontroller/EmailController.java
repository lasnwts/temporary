package ru.usb.jdbcchdsftpgoldencrown.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.service.mail.EmailServiceImpl;
import ru.usb.jdbcchdsftpgoldencrown.utils.Support;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api/mail")
@Tag(name = "Контроллер для проверки почтовой подсистемы", description = "Проверка отправки почты")
public class EmailController {

    private final Logger logger = LoggerFactory.getLogger(EmailController.class);
    private final EmailServiceImpl emailService;
    private final Support support;

    @Autowired
    public EmailController(EmailServiceImpl emailService, Support support) {
        this.emailService = emailService;
        this.support = support;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                           @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmailThrow(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            logger.error("{}: while sending out email..", Elog.UsbLogError, mailException);
            return new ResponseEntity<>("Unable to send email: \n\r " + support.getWrapNull(mailException.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }

}
