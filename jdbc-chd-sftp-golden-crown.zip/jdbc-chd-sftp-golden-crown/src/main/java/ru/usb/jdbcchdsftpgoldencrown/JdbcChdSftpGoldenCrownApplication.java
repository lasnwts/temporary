package ru.usb.jdbcchdsftpgoldencrown;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@EnableScheduling
@SpringBootApplication
public class JdbcChdSftpGoldenCrownApplication implements CommandLineRunner {

    private final Configure configure;

    @Autowired
    public JdbcChdSftpGoldenCrownApplication(Configure configure) {
        this.configure = configure;
    }

    public static void main(String[] args) {
        SpringApplication.run(JdbcChdSftpGoldenCrownApplication.class, args);
    }

    private static final Logger logger = LoggerFactory.getLogger(JdbcChdSftpGoldenCrownApplication.class);

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r (Service [jdbc-chd-sftp-golden-crown] <Автоматизация процесса начисления бонусов по акциям>)")
                .contact(new Contact().email("lyapustinas@smartsoftware.ru"))
                .version(appVersion)
                .description("API для Инициативы #8522 Бонус." +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {
        /***
         * Проверка путей
         */
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", Elog.UsbLogInfo, path);
        } else {
            logger.info("{}:Directory {}  = already exists", Elog.UsbLogInfo, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));

        logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
        configure.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


        logger.info(".");
        logger.info("..");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", Elog.UsbLogInfo);
        logger.info("{}:| Name service           : jdbc-chd-sftp-golden-crown", Elog.UsbLogInfo);
        logger.info("{}:| Version of service     : 0.0.1", Elog.UsbLogInfo);
        logger.info("{}:| Description of service : Generate files PM from the cxd for Golden Crown. File put to sftp.", Elog.UsbLogInfo);
        logger.info("{}:| Date created           : 05/04/2024 ", Elog.UsbLogInfo);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", Elog.UsbLogInfo);
        logger.info("{}:| Reason modified        : --/--/---- ..... ", Elog.UsbLogInfo);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", Elog.UsbLogInfo);
        logger.info("...");
        logger.info("....");
        logger.info(".....");

    }
}
