package ru.usb.jdbcchdsftpgoldencrown.service.sftp;


import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.service.mail.ServiceMailError;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

/**
 * Сервис для работы с sftp сервером
 * 1. Загрузка на сервер одного файла
 * 2. Загрузка на сервере группы файлов
 * 3. Скачивание с сервера 1 файла
 * 4. Удаление на сервере одного файла
 * 5. Проверка наличия каталогов на сервере sftp
 */
@Service
public class SftpPutFileService {

    private final Configure configure;
    private final ServiceMailError serviceMailError;

    @Autowired
    public SftpPutFileService(Configure configure, ServiceMailError serviceMailError) {
        this.configure = configure;
        this.serviceMailError = serviceMailError;
    }

    Logger logger = LoggerFactory.getLogger(SftpPutFileService.class);

    /**
     * Передача файла на сервер sftp
     *
     * @param file         - файл который надо загрузить
     * @param directoryOut - Директория куда надо загрузить файл
     * @param delFile      - если true - файл будет удален
     * @return - true - если загружен, false - нет
     */
    public boolean putFileToSftp(File file, String directoryOut, boolean delFile) {

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();

        /**
         * Создаем сессию, канал
         */
        Session session = null;
        ChannelSftp channel = null;

        try {
            if (configure.isSftpNeedKey()) {
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            channel.cd("/" + directoryOut);
            channel.put(file.getAbsolutePath(), file.getName() + ".tmp");
            logger.info("{}:File={}{} upload to sftp, successfully", Elog.UsbLogInfo, file.getName(), ".tmp");
            //Переименовываем файлы
            channel.rename(file.getName() + ".tmp", file.getName());
            logger.info("{}:File={}{} rename to {}, successfully", Elog.UsbLogInfo, file.getName(), ".tmp", file.getName());
            logger.info("{}:Размер файла {}={}", file.getName(), Elog.UsbLogInfo, file.length());
            /**
             * Если флаг удалять после загрузки
             */
            if (delFile) {
                Files.delete(file.toPath());
                logger.info("{}:File={} - удален, после загрузки", Elog.UsbLogInfo, file.getAbsolutePath());
            }
        } catch (JSchException | SftpException | IOException e) {
            logger.error("{}:SftpService:putFileToSftp(file).Session = Error!!", Elog.UsbLogError);
            logger.error("{}:Session.error::", Elog.UsbLogError, e);
            //Отправляем письмо
            serviceMailError.sendMailErrorSubject("Ошибка при подключении к SFTP.",
                    "Ошибка! SftpService: = Error:\r\n" + e.getMessage());
            if (channel != null && channel.isConnected()) {
                channel.disconnect();
            }
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            return false;
        }

        //Закрываем соединение
        setFinalConnected(session, channel);
        return true; //Файл успешно загружен
    }


    /**
     * закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }

}
