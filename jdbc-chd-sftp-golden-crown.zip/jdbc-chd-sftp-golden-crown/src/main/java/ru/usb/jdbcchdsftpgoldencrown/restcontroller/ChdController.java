package ru.usb.jdbcchdsftpgoldencrown.restcontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.repository.JpaFlowPM;
import ru.usb.jdbcchdsftpgoldencrown.service.dbase.GetFlowPM;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с Базой Данных. ", description = "<Автоматизация процесса начисления бонусов по акциям>")
public class ChdController {

    private final JpaFlowPM jpaFlowPM;
    private final GetFlowPM getFlowPM;

    @Autowired
    public ChdController(JpaFlowPM jpaFlowPM, GetFlowPM getFlowPM) {
        this.jpaFlowPM = jpaFlowPM;
        this.getFlowPM = getFlowPM;
    }

    private final Logger logger = LoggerFactory.getLogger(ChdController.class);

    @GetMapping("/count")
    @Operation(summary = "Запрос на получение количества записей в таблице SEND_PROMOCODE2.")
    public ResponseEntity<String> getCount() {
        logger.info("{}: Запрос количества записей в таблице SEND_PROMOCODE2", Elog.UsbLogInfo);
        try {
            return ResponseEntity.status(HttpStatus.OK).body("Количество записей в таблице:[" + jpaFlowPM.getCountPM() + "]");
        } catch (Exception ex) {
            logger.error("{}: Ошибка получения количества записей в таблице SEND_PROMOCODE2", Elog.UsbLogError, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка получения количества записей в таблице SEND_PROMOCODE2:" + ex.getMessage());
        }
    }

    @GetMapping("/record")
    @Operation(summary = "Запрос на получение записей из SEND_PROMOCODE2.")
    public ResponseEntity<?> getRecord() {
        logger.info("{}: Запрос на получение всех записей в таблице SEND_PROMOCODE2", Elog.UsbLogInfo);
        try {
            return ResponseEntity.status(HttpStatus.OK).body(jpaFlowPM.getListFlowPM());
        } catch (Exception ex) {
            logger.error("{}: Ошибка получения количества записей в таблице SEND_PROMOCODE2", Elog.UsbLogError, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка получения всех записей из таблице SEND_PROMOCODE2:" + ex.getMessage());
        }
    }

    @PutMapping("/start")
    @Operation(summary = "Запуск выгрузки записей из SEND_PROMOCODE2 и отправки на сервер SFTP.")
    public ResponseEntity<String> startUploadPmFile(){
             if(getFlowPM.getFlowPM()){
                 return ResponseEntity.status(HttpStatus.OK).body("Файл успешно сформирован и отправлен на сервере sftp");
             } else {
                 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Произошла ошибка при формировании и отправке файла PM на sftp сервер");
             }
    }

}
