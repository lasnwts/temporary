package ru.usb.jdbcchdsftpgoldencrown.service.dbase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.jdbcchdsftpgoldencrown.configure.Configure;
import ru.usb.jdbcchdsftpgoldencrown.configure.Elog;
import ru.usb.jdbcchdsftpgoldencrown.model.FlowPM;
import ru.usb.jdbcchdsftpgoldencrown.repository.JpaFlowPM;
import ru.usb.jdbcchdsftpgoldencrown.service.FileWriter;
import ru.usb.jdbcchdsftpgoldencrown.service.mail.EmailServiceImpl;
import ru.usb.jdbcchdsftpgoldencrown.service.mail.ServiceMailError;
import ru.usb.jdbcchdsftpgoldencrown.service.sftp.SftpPutFileService;
import ru.usb.jdbcchdsftpgoldencrown.utils.Support;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.util.stream.Stream;


@Service
public class GetFlowPM {

    Logger logger = LoggerFactory.getLogger(GetFlowPM.class);

    private final Configure configure;
    private final Support support;
    private final JpaFlowPM jpaFlowPM;
    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final EmailServiceImpl emailService;
    private final SftpPutFileService sftpPutFileService;


    String fullFileNameCSV;
    //Количество строк
    int lineCount;

    public GetFlowPM(Configure configure, Support support, JpaFlowPM jpaFlowPM, EntityManager entityManager,
                     ServiceMailError sendMailError, EmailServiceImpl emailService,
                     SftpPutFileService sftpPutFileService) {
        this.configure = configure;
        this.support = support;
        this.jpaFlowPM = jpaFlowPM;
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.emailService = emailService;
        this.sftpPutFileService = sftpPutFileService;
    }

    @Transactional(readOnly = true)
    public boolean getFlowPM() {

        String fileName = support.getFileName();

        //Получаем список записей из базы
        Stream<FlowPM> fTableStream = null;

        try {
            int recordCount = jpaFlowPM.getCountPM();
            logger.info("{} Число записей в таблице: SEND_PROMOCODE2={}", Elog.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                logger.info("{} Поскольку число записей в таблице: SEND_PROMOCODE2=0, то обработку завершаем! ->false", Elog.UsbLogInfo);
                return false;
            }
            fTableStream = jpaFlowPM.getFlowPM();
            if (!support.checkStreamTable(fTableStream)) {
                logger.error("{} fTableStream = jpaFlowPM.getFlowPM() - поток вернулся = NULL! Так быть не должно!", Elog.UsbLogError);
                return false;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = jpaFlowPM.getFlowPM()", Elog.UsbLogError);
            logger.error("{}:Print stack:", Elog.UsbLogError, e);
            emailService.sendSimpleEmail(configure.getMailToBusiness(), support.getWrapNull(configure.getMailSubjects())
                            + " Ошибка доступа к витрине данных SEND_PROMOCODES2. <Автоматизация процесса начисления бонусов по акциям>"
                    , " Возникла ошибка при обращении к витрине SEND_PROMOCODES2 \n\r" + "Описание: " + e.getMessage());
            sendMailError.sendMailErrorSubject(support.getWrapNull(configure.getMailSubjects())
                            + " Ошибка доступа к витрине данных SEND_PROMOCODES2. <Автоматизация процесса начисления бонусов по акциям>"
                    , " Возникла ошибка при обращении к витрине SEND_PROMOCODES2 \n\r" + "Описание: " + e.getMessage());
            return false;
        }


        logger.info("{}:###################### < Starting the process Flow PM of unloading data from a table to a file > ##############################", Elog.UsbLogError);
        lineCount = 0; //Обнулили счетчик записей, строк
        fullFileNameCSV = configure.getTempDirUploadFile() + File.separator + fileName; //Создаем файл во временной директории

        try {
            FileWriter.write(fullFileNameCSV, support.getHeader());
            fTableStream.forEach(fTable -> {
                logger.debug(fTable.toString());
                /**
                 * Фильтруем строку Points = 0
                 */
                if (fTable.getPoints() != null || !fTable.getPoints().isEmpty() || !fTable.getPoints().equals("0")) {
                    try {
                        FileWriter.write(fullFileNameCSV,  configure.getLineParam1()+ ";" + support.getWrapNull(fTable.getLoyaltyId()) + ";"
                                + support.getSummaFormatter(support.getWrapNull(fTable.getPoints())) + ";" + ";"
                                //ID оригинальной операции	an..50	O	Поле не заполняем [Id оригинальной операции в ПЦ]  	Не формируется на витрине данных
                                //Дата совершения операции	n14	O	Поле не заполняем [Локальная дата совершения операции в формате yyyymmddhh24miss]	Не формируется на витрине данных
                                + support.getDoubleQuote(fTable.getPromo()) + ";" + configure.getLineParam2());
                    } catch (IOException e) {
                        sendEmail(e.getMessage());
                    }
                    lineCount = lineCount + 1; //Подсчитываем число записей в файле
                }
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено записей:{}", Elog.UsbLogInfo, lineCount);
            logger.info("{}:Output data in File ={}", Elog.UsbLogInfo, fullFileNameCSV);
            FileWriter.write(fullFileNameCSV, "T;" + lineCount);
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", Elog.UsbLogError);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл", Elog.UsbLogError);
            logger.error("{}:!PrintStackTrace:", Elog.UsbLogError, e);
            sendEmail(e.getMessage());
            return false;
        } finally {
            fTableStream.close();
        }
        /**
         * Отправка файла в sftp
         */
        return sftpPutFileService.putFileToSftp(new File(fullFileNameCSV), configure.getSftpDirectory(), true);
    }

    private void sendEmail(String ex){
        try {
            sendMailError.sendMailError("Возникла ошибка Starting the process Flow PM " + "\n\r" + " Сообщение о ошибке:" + ex);
        } catch (Exception exception) {
            logger.error("{}:UsbLog:Возникла ошибка при отправке письма [  serviceMailError.sendMailError] Exception:", Elog.UsbLogError, exception);
        }
    }
}