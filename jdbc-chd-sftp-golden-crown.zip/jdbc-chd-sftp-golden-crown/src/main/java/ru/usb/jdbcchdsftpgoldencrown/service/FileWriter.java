package ru.usb.jdbcchdsftpgoldencrown.service;

import java.io.*;

public class FileWriter {

    private FileWriter() {
        //
    }
    public static void write(String fileName, String text) throws IOException {
        //Определяем файл
        File file = new File(fileName);
        boolean fileExists;
        if (!file.exists()) { //проверяем, что если файл не существует то создаем его
            fileExists = file.createNewFile();
        } else {
            fileExists = true;
        }
        if (fileExists) {
            try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file.getAbsoluteFile(), true), "windows-1251"))){
                bw.write(text + System.lineSeparator());
            } catch (IOException e) {
                throw new IOException(e);
            }
        } else {
            throw new IOException("Ошибка доступа к файлу");
        }
    }
}
