package ru.usb.externalbank_intgr_siebel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExternalbankIntgrSiebelApplicationTests {

	@Test
	void contextLoads() {
	}

}
