package ru.usb.externalbank_intgr_siebel.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ProcessMessage {
    private String packID;
    private String error;
    private String errorText;
    private KafkaMessage kafkaMessage;
    private Pack pack;
    private String filelink;

}
