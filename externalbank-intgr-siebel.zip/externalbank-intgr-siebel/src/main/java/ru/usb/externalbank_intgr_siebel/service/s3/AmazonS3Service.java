package ru.usb.externalbank_intgr_siebel.service.s3;


import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.configure.Configure;
import ru.usb.externalbank_intgr_siebel.configure.LG;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@Service
public class AmazonS3Service {
    private final AmazonS3 s3;
    private final Configure configure;

    private static final String STATUS_CODE = "status code";

    @Autowired
    public AmazonS3Service(AmazonS3 s3, Configure configure) {
        this.s3 = s3;
        this.configure = configure;
    }


    /**
     * Загрузка файла в бакет
     *
     * @param bucketName     - имя бакета
     * @param originalFilename - имя файла
     * @param bytes           - содержимое файла
     * @return - результат загрузки
     */
    public boolean uploadFile(String bucketName, String originalFilename, byte[] bytes) throws Exception {
        File file = upload(originalFilename, bytes);
        PutObjectResult putObject = s3.putObject(bucketName, originalFilename, file);
        try {
            Files.delete(file.toPath());
        } catch (Exception e) {
            log.error("{}:Error! Temporary file not deleted:{}, error:{}", LG.USBLOGINFO, file.getAbsolutePath(), e.getMessage());
            log.debug("{}:Temporary file not deleted:stackTrace:", LG.USBLOGINFO, e);
            return false;
        }
        if (file.exists()) {
            log.error("{}:Error! Temporary file not deleted:{}", LG.USBLOGINFO, file.getAbsolutePath());
        }
        if (putObject != null && putObject.getETag() != null) {
            log.info("{}:File uploaded:{}", LG.USBLOGINFO, originalFilename);
            log.info("{}:s3 properties:eTag:{},ExpirationDateTime:{},versionId:{}", LG.USBLOGINFO, putObject.getETag(),
                    putObject.getExpirationTime(), putObject.getVersionId());
            return true;
        } else {
            log.info("{}:Error File not uploaded:{}", LG.USBLOGINFO, originalFilename);
            return false;
        }
    }


    /**
     * Скачивание файла из бакета
     *
     * @param bucketName - имя бакета
     * @param fileUrl    - имя файла
     * @return - содержимое файла
     */
    public byte[] downloadFile(String bucketName, String fileUrl) throws Exception {
        return getFile(bucketName, fileUrl);
    }


    /**
     * Удаление файла из бакета
     * @param bucketName - имя бакета
     * @param fileUrl - url
     * @return - HTTPStatus
     */
    public HttpStatus deleteFile(String bucketName, String fileUrl) {
        log.info("{}:Удаляем файл :{} из бакета {}", LG.USBLOGINFO, fileUrl, bucketName);
        try {
            s3.deleteObject(bucketName, fileUrl);
            return HttpStatus.OK;
        } catch (AmazonServiceException e) {
            log.error("{}:Error:AmazonServiceException:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:AmazonServiceException:stackTrace:", LG.USBLOGERROR, e);
            return getStatusCode(e.getMessage());
        } catch (SdkClientException e) {
            log.error("{}:Error:SdkClientException:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:SdkClientException:stackTrace:", LG.USBLOGERROR, e);
            return getStatusCode(e.getMessage());
        }
    }


    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @param key - ключ поиска
     * @return - список файлов
     */
    public List<String> listObjects(String bucketName, String key) {
        ObjectListing objectListing = s3.listObjects(bucketName, key);
        return objectListing.getObjectSummaries()
                .stream()
                .map(S3ObjectSummary::getKey)
                .collect(Collectors.toList());
    }

    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public List<String> listFiles(String bucketName) {
        List<String> list = new LinkedList<>();
        s3.listObjects(bucketName).getObjectSummaries().forEach(itemResult -> {
            list.add(itemResult.getKey());
            log.debug("{}:ListFile:{}", LG.USBLOGINFO, itemResult.getKey());
        });
        return list;
    }

    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public List<String> listKeys(String bucketName, String key) {
        ObjectListing objectListing = s3.listObjects(bucketName);
        return objectListing.getObjectSummaries()
                .stream()
                .map(S3ObjectSummary::getKey)
                .filter(itemResultKey -> itemResultKey.contains(key))
                .collect(Collectors.toList());
    }


    /**
     * Загрузка файла во временную директорию
     *
     * @param name    - имя файла
     * @param content - содержимое файла
     * @return - File
     */
    public File upload(String name, byte[] content) throws Exception {
        File file = new File(new FileSystemResource("").getFile().getAbsolutePath() + FileSystems.getDefault().getSeparator() +
                configure.getNetFileShare() + FileSystems.getDefault().getSeparator() + name);
        if (file.canWrite()) {
            log.debug("{}:file.canWrite()=true", LG.USBLOGINFO);
        }
        if (file.canRead()) {
            log.debug("{}:file.canRead()=true", LG.USBLOGINFO);
        }
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        } catch (Exception e) {
            log.error("{}:Error:FileOutputStream(file).write(content):{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:FileOutputStream.write(content):stackTrace:", LG.USBLOGERROR, e);
        }
        return file;
    }


    /**
     * Получение файла из S3
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @return - содержимое файла
     */
    public byte[] getFile(String bucketName, String key) throws Exception {
        S3Object obj = s3.getObject(bucketName, key);
        S3ObjectInputStream stream = obj.getObjectContent();
        try {
            byte[] content = IOUtils.toByteArray(stream);
            obj.close();
            return content;
        } catch (IOException e) {
            log.error("{}:Error: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:{}", LG.USBLOGERROR, e);
        }
        return new byte[0];
    }

    /**
     * Получение ссылки на файл
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @return - ссылка на файл
     */
    public String getFileLink(String bucketName, String key) throws Exception {
        boolean found = s3.doesBucketExist(bucketName);
        if (found) {
            log.info("{}:{}  bucket name exists/ Ok", LG.USBLOGINFO, bucketName);
        } else {
            log.info("{}: {} bucket name does not exist", LG.USBLOGINFO, bucketName);
            return bucketName + " bucket name does not exist";
        }
        String s3Url = s3.getUrl(bucketName, key).toExternalForm();
        log.info("{}: objectStat URL := {}", LG.USBLOGINFO, s3Url);
        return s3Url;
    }

    /**
     * Передача файла в S3
     *
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     * @param file       - файл
     * @return - ETag
     */
    public String putObject(String bucketName, String fileName, File file) throws Exception {
        if (!s3.doesBucketExist(bucketName)) {
            log.info("{}:{}  bucket name does not exist", LG.USBLOGINFO, bucketName);
            throw new AmazonServiceException("Bucket " + bucketName + " does not exist");
        } else {
            try {
                PutObjectResult putObject = s3.putObject(bucketName, fileName, file);
                if (putObject != null) {
                    return getFileLink(bucketName, fileName);
                } else {
                    return "";
                }
            } catch (AmazonServiceException e) {
                log.error("{}:Error:putObject(bucketName, fileName, file):{}", LG.USBLOGERROR, e.getMessage());
                log.debug("{}:Error:putObject(bucketName, fileName, file):stackTrace:", LG.USBLOGERROR, e);
                throw new AmazonServiceException(e.getMessage());
            }
        }
    }


    /**
     * Копирование файла в S3
     *
     * @param sourceBucket      - имя исходного бакета
     * @param sourceKey         - имя исходного файла
     * @param destinationBucket - имя бакета назначения
     * @param destinationKey    - имя файла назначения
     */
    public CopyObjectResult copyFile(String sourceBucket, String sourceKey, String destinationBucket, String destinationKey) {
        try {
            return s3.copyObject(sourceBucket, sourceKey, destinationBucket, destinationKey);
        } catch (AmazonServiceException e) {
            log.error("{}:Error:copyObject(sourceBucket, sourceKey, destinationBucket, destinationKey):{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:copyObject(sourceBucket, sourceKey, destinationBucket, destinationKey):stackTrace:", LG.USBLOGERROR, e);
            throw new AmazonServiceException(e.getMessage());
        }
    }

    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public List<String> listObjects(String bucketName) {
        ObjectListing objectListing = s3.listObjects(bucketName, configure.getS3BucketBase());
        return objectListing.getObjectSummaries()
                .stream()
                .map(S3ObjectSummary::getKey)
                .collect(Collectors.toList());
    }


    /**
     * Проверка существования бакета
     *
     * @param bucket - имя бакета
     * @return - результат
     */
    public boolean checkBucket(String bucket) {
        return bucket != null && s3.doesBucketExist(bucket);
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    public HttpStatus getStatusCode(String line) {

        if (line == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }

        //Проверка на ошибку соединения
        if (line.toLowerCase().contains("connection refused:")) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        //Если иная ошибка
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        if (line.toLowerCase().contains(STATUS_CODE)) {

            String code = line.toLowerCase().substring(line.toLowerCase().indexOf(STATUS_CODE) + 13,
                    line.toLowerCase().indexOf(STATUS_CODE) + 16);

            switch (code) {
                case "404":
                    httpStatus = HttpStatus.NOT_FOUND;
                    break;
                case "400":
                    httpStatus = HttpStatus.BAD_REQUEST;
                    break;
                case "401":
                    httpStatus = HttpStatus.UNAUTHORIZED;
                    break;
                case "403":
                    httpStatus = HttpStatus.FORBIDDEN;
                    break;
                case "405":
                    httpStatus = HttpStatus.METHOD_NOT_ALLOWED;
                    break;
                case "501":
                    httpStatus = HttpStatus.NOT_IMPLEMENTED;
                    break;
                case "502":
                    httpStatus = HttpStatus.BAD_GATEWAY;
                    break;
                case "503":
                    httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
                    break;
                case "504":
                    httpStatus = HttpStatus.GATEWAY_TIMEOUT;
                    break;
                case "300":
                    httpStatus = HttpStatus.MULTIPLE_CHOICES;
                    break;
                case "301":
                    httpStatus = HttpStatus.MOVED_PERMANENTLY;
                    break;
                default:
                    httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                    break;
            }
        }
        return httpStatus;
    }




    /**
     * <a href="https://stackoverflow.com/questions/8027265/how-to-list-all-aws-s3-objects-in-a-bucket-using-java">...</a>
     * Получение списка файлов в бакете
     * Множество более 1000
     * @param bucketName - имя бакета
     * @return - список файлов
     *
     */
    public List<String> listObjectsV2(String bucketName) {
        List<String> list = new LinkedList<>();
        ListObjectsV2Result listObjectsV2Result = s3.listObjectsV2(bucketName);
        listObjectsV2Result.getObjectSummaries().forEach(itemResult -> {
            list.add(itemResult.getKey());
            log.info("{}:ListFile:{}", LG.USBLOGINFO, itemResult.getKey());
        });
        return list;
    }
}

