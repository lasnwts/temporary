package ru.usb.externalbank_intgr_siebel.service.kafka;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.model.KafkaMessage;
import ru.usb.externalbank_intgr_siebel.model.Pack;
import ru.usb.externalbank_intgr_siebel.service.Executor2Service;
import ru.usb.externalbank_intgr_siebel.util.MapperEvents;
import ru.usb.externalbank_intgr_siebel.util.PackMapper;

import java.util.Optional;

@Log4j2
@Service
public class MessageProcess {

    private final MapperEvents mapperEvents;
    private final PackMapper packMapper;
    private final Executor2Service executor2Service;

    public MessageProcess(MapperEvents mapperEvents, PackMapper packMapper, Executor2Service executor2Service) {
        this.mapperEvents = mapperEvents;
        this.packMapper = packMapper;
        this.executor2Service = executor2Service;
    }

    /**
     * Обработка сообщения
     * Планировалась логика обработки сообщения, но пока не реализована
     * @param message - сообщение
     */
    public void process(String message) {

        log.info("MessageProcess: {}", message);
//
//        Optional<KafkaMessage> kafkaMessage = mapperEvents.getDocument(message);
//        kafkaMessage.ifPresent(value -> log.info("kafkaMessage: {}", value));
//
//        log.info("-- pack");
//
//        Optional<Pack> pack = packMapper.getPack(kafkaMessage.get().getPack());
//        pack.ifPresent(value -> log.info("pack: {}", value));

        executor2Service.getTask(message);
    }
}
