package ru.usb.externalbank_intgr_siebel;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.externalbank_intgr_siebel.configure.Configure;
import ru.usb.externalbank_intgr_siebel.configure.LG;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class ExternalbankIntgrSiebelApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(ExternalbankIntgrSiebelApplication.class);

	private final Configure configure;

	@Autowired
	public ExternalbankIntgrSiebelApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(ExternalbankIntgrSiebelApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.1.10") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r (Service [Микросервис: externalbank-intgr-siebel] Интеграционный поток по получению архивов с данными клиентов от Т-банка)")
				.contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
				.version(appVersion)
				.description("API для [Интеграционный поток по получению архивов с данными клиентов от Т-банка]" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {

		// Проверка путей
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
				FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
		} else {
			logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));
		logger.info(".");
		logger.info("..");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : Externalbank-intgr-siebel", LG.USBLOGINFO);
		logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 24/10/2024 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| tbank.custrisk.csv           : Информация о группе риска клиента", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  07.10.2024  : 0.0.11 ПОКА НЕТ", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("...");
		logger.info("....");
		logger.info(".....");

		/****
		 * ---------------------------
		 * Что не сделано
		 * 1. Проверка наличия пустого каталога в хранилище
		 * 2. Запись в таблицу TBANK_ARCHIEVE_FILE - надо поставить END и признак ошибки в случае ошибки
		 */
	}
}
