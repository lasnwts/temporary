package ru.usb.externalbank_intgr_siebel.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.configure.LG;
import ru.usb.externalbank_intgr_siebel.model.KafkaMessage;

import java.util.Optional;

@Service
public class MapperEvents {

    private static final Logger log = LoggerFactory.getLogger(MapperEvents.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Получение документа в виде объекта
     * @param json - строка Json
     * @return - FactoringDocument
     */
    public Optional<KafkaMessage> getDocument(String json) {
        if (json == null) {
            log.error("{}: На маппер KafkaMessage поступил объект, строка [Json] == NULL!", LG.USBLOGERROR);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, KafkaMessage.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", LG.USBLOGERROR, e);
            return Optional.empty();        }
    }

    /**
     * Получение документа в виде Json строки
     * @param document - KafkaMessage
     * @return - Json строка
     */
    public String getJson(KafkaMessage document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [KafkaMessage] == NULL!", LG.USBLOGERROR);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа KafkaMessage :{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге KafkaMessage:", LG.USBLOGERROR, e);
            return null;
        }
    }
}
