package ru.usb.externalbank_intgr_siebel.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.model.TBankHistoryArchives;
import ru.usb.externalbank_intgr_siebel.model.TBankHistoryFiles;
import ru.usb.externalbank_intgr_siebel.repository.TBankHistoryArchivesRepo;
import ru.usb.externalbank_intgr_siebel.repository.TBankHistoryFilesRepo;

import java.util.List;
import java.util.Objects;

@Log4j2
@Service
public class ApiLayerDB {

    private final TBankHistoryFilesRepo tBankHistoryFilesRepo;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    @Autowired
    public ApiLayerDB(TBankHistoryFilesRepo tBankHistoryFilesRepo, TBankHistoryArchivesRepo tBankHistoryArchivesRepo) {
        this.tBankHistoryFilesRepo = tBankHistoryFilesRepo;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
    }

    /**
     * Получить файлы по пакету
     *
     * @param packId - идентификатор пакета
     * @return - список файлов
     */
    public List<TBankHistoryFiles> getTBankFiles(String packId) {
        return tBankHistoryFilesRepo.getPackId(packId);

    }

    /**
     * Проверить запись по идентификатору пакета
     *
     * @param packId - идентификатор пакета
     * @return - запись
     */
    public boolean checkFileExists(String packId) {
        List<TBankHistoryFiles> tBankHistoryFiles = getTBankFiles(packId);
        return !tBankHistoryFiles.isEmpty();
    }

    /**
     * Получить файлы по пакету
     *
     * @param packId - идентификатор пакета
     * @return - список файлов
     */
    public List<TBankHistoryFiles> getTBankFilesByPackId(String packId) {
        return tBankHistoryFilesRepo.getPackId(packId);
    }

    /**
     * Сохранить файл
     *
     * @param tBankHistoryFiles - файл
     */
    public void saveFile(TBankHistoryFiles tBankHistoryFiles) {
        tBankHistoryFilesRepo.save(tBankHistoryFiles);
    }

    /**
     * Получение истории архива
     *
     * @param archiveName - имя архива
     * @return - история архива
     */
    public TBankHistoryArchives getHistoryArchive(String archiveName) {
        TBankHistoryArchives tBankHistoryArchives = tBankHistoryArchivesRepo.getByName(archiveName);
        return Objects.requireNonNullElseGet(tBankHistoryArchives, TBankHistoryArchives::new);
    }


    /**
     * Сохранение истории архива
     *
     * @param historyArchives - история архива
     */
    public void saveHistoryArchive(TBankHistoryArchives historyArchives) {
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

}
