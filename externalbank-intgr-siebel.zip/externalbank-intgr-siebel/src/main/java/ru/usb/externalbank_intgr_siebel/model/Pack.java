package ru.usb.externalbank_intgr_siebel.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * Pack сообщения
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class Pack {

    @JsonProperty("status")
    private String status;

    @JsonProperty("fileid")
    private String fileid;

    @JsonProperty("docattid")
    private String docattid;

    @JsonProperty("assetnumber")
    private String assetnumber;

    @JsonProperty("filecomment")
    private String filecomment;

    @JsonProperty("doctype")
    private String doctype;

    @JsonProperty("filesize")
    private String filesize;

    @JsonProperty("docid")
    private String docid;

    @JsonProperty("filename")
    private String filename;

    @JsonProperty("filelink")
    private String filelink;

    @JsonProperty("archivename")
    private String archivename;

    @JsonProperty("fileext")
    private String fileext;

}
