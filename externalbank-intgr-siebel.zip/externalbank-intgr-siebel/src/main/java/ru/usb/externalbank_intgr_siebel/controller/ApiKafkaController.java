package ru.usb.externalbank_intgr_siebel.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.externalbank_intgr_siebel.configure.Configure;
import ru.usb.externalbank_intgr_siebel.configure.LG;
import ru.usb.externalbank_intgr_siebel.service.kafka.KafkaProducerService;
import ru.usb.externalbank_intgr_siebel.util.Support;

@RestController
@RequestMapping("/api/mail")
@Tag(name = "Контроллер для отправки сообщений в Кафка", description = "Проверка удаления из Бакета")
public class ApiKafkaController {

    String s = "{\n" +
            "  \"SYSTEM_FROM\": \"siebel.test\",\n" +
            "  \"SYSTEM_TO\": \"external_test\",\n" +
            "  \"SERVICE\": \"Asset-Attachment\",\n" +
            "  \"ROUTEID\": null,\n" +
            "  \"MAPPER\": null,\n" +
            "  \"PACKID\": \"cb784379-0448-3e56-a03b-e4f4c80e07e219112024123328\",\n" +
            "  \"ERRORTEXT\": null,\n" +
            "  \"ERROR\": null,\n" +
            "  \"PACK\": \"{\\\"status\\\":\\\"OK\\\", \\\"fileid\\\":\\\"42e0d900-369f-11e5-8c62-783320524153\\\", \\\"docattid\\\":\\\"1-IJE7Y3V\\\", \\\"assetnumber\\\":\\\"00037023956840\\\", \\\"filecomment\\\":\\\"Мигрировано из Т-Банк\\\", \\\"doctype\\\":\\\"Иные докум.\\\", \\\"filesize\\\":\\\"1274150\\\", \\\"docid\\\":\\\"1-IJE6WC1\\\", \\\"filename\\\":\\\"Последний график платежей\\\",  \\\"filelink\\\":\\\"testrup/rup_o_dos20241010125135/00037043813751/2-НДФЛ.pdf.pdf\\\", \\\"archivename\\\":\\\"rup_o_dos20241010125135.zip\\\", \\\"fileext\\\":\\\"pdf\\\"}\",\n" +
            "  \"TS\": 1729755080326\n" +
            "}";

    private final Logger logger = LoggerFactory.getLogger(ApiKafkaController.class);

    private final KafkaProducerService producerService;
    private final Configure configure;
    private final Support support;

    @Autowired
    public ApiKafkaController(KafkaProducerService producerService, Configure configure, Support support) {
        this.producerService = producerService;
        this.configure = configure;
        this.support = support;
    }

    /**
     * Тест отправки сообщения в Кафку
     *
     * @param message - сообщение
     */
    @PostMapping(value = "/send")
    @Operation(summary = "Отправка сообщения для удаления из бакета, пример: {\n\r" +
            "  \"SYSTEM_FROM\": \"siebel.test\",\r\r" +
            "  \"SYSTEM_TO\": \"external_test\",\n\n" +
            "  \"SERVICE\": \"Asset-Attachment\",\n\n" +
            "  \"ROUTEID\": null,\n\n" +
            "  \"MAPPER\": null,\n\n" +
            "  \"PACKID\": \"PACK_ID\",\n\n" +
            "  \"ERRORTEXT\": null,\n\n" +
            "  \"ERROR\": null,\n\n" +
            "  \"PACK\": \"{\\\"status\\\":\\\"OK\\\", \\\"fileid\\\":\\\"42e0d900-369f-11e5-8c62-783320524153\\\", \\\"docattid\\\":\\\"1-IJE7Y3V\\\", \\\"assetnumber\\\":\\\"00037023956840\\\", \\\"filecomment\\\":\\\"Мигрировано из Т-Банк\\\", \\\"doctype\\\":\\\"Иные докум.\\\", \\\"filesize\\\":\\\"1274150\\\", \\\"docid\\\":\\\"1-IJE6WC1\\\", \\\"filename\\\":\\\"Последний график платежей\\\",  \\\"filelink\\\":\\\"PARAMETER_FILE_LINK\\\", \\\"archivename\\\":\\\"rup_o_dos20241010125135.zip\\\", \\\"fileext\\\":\\\"pdf\\\"}\",\n\n" +
            "  \"TS\": 1729755080326\n\n" +
            "} ")
    public ResponseEntity<String> sendKafka(@RequestBody String message) {
        if (producerService.sendMessage(configure.getKafkaEventTopic(), message)) {
            return new ResponseEntity<>("Message sent to topic:" + configure.getKafkaEventTopic(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Message not sent", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/topic")
    @Operation(summary = "Показать топик, используемый в работе сервисом")
    public ResponseEntity<String> getTopicName() {
        return new ResponseEntity<>(configure.getKafkaEventTopic(), HttpStatus.OK);
    }

    @GetMapping(value = "/sends/{packid}/{archive}/{dogovor}/{filename}")
    @Operation(summary = "Отправляем сообщение в топик Кафка. Сообщение будет отправлено вв топик и сервис вернет вам, какое сообщение он отправил.")
    public ResponseEntity<String> sendToTopic(@Parameter(description = "Введите packID, Пример packId: cb784379-0448-3e56-a03b-e4f4c80e07e219112024123328")
                                              @PathVariable("packid") String packid,
                                              @Parameter(description = "Введите имя файл, пример: rup_o_dos20241010125135.zip")
                                              @PathVariable("archive") String archive,
                                              @Parameter(description = "Введите номер договора, пример: 00037043813751")
                                              @PathVariable("dogovor") String dogovor,
                                              @Parameter(description = "Введите имя файла, пример: 2-НДФЛ.pdf.pdf")
                                              @PathVariable("filename") String filename) {
        String message = s.replace("PACK_ID", packid).replace("PARAMETER_FILE_LINK", support.getFileNameWithoutExtension(archive) + "/" + dogovor + "/" + filename);
        logger.info("{}:Web API[sendToTopic]=> message:{}", LG.USBLOGINFO, message);
        if (producerService.sendMessage(configure.getKafkaEventTopic(), message)) {
            return new ResponseEntity<>("Message sent to topic:" + configure.getKafkaEventTopic() + "  \n\r<br>" + s, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Message not sent: " + s, HttpStatus.BAD_REQUEST);
        }
    }

}
