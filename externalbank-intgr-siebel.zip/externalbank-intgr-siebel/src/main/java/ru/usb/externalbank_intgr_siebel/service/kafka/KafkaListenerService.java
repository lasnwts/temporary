package ru.usb.externalbank_intgr_siebel.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.externalbank_intgr_siebel.configure.Configure;
import ru.usb.externalbank_intgr_siebel.configure.LG;
import ru.usb.externalbank_intgr_siebel.service.mail.ServiceMailError;
import ru.usb.externalbank_intgr_siebel.util.Support;


@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;
    private final Support aux;
    private final MessageProcess messageProcess;
    private final Configure configure;

    @Autowired
    public KafkaListenerService(ServiceMailError serviceMailError, Support aux, MessageProcess messageProcess, Configure configure) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.messageProcess = messageProcess;
        this.configure = configure;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.attempt:4}")
    private int countAttempt;

    @Value("${max.size.queue:100}") //Максимальное число записей, принятых в обработку
    private int maxSizeQueue;

    @Value("${ack.nack.duration:10}") //Задержка перед приемом новой порции сообщений
    private int ackDuration;

    @KafkaListener(topics = "${kafka.event.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {

        if (logDebug) {
            logger.info("{}:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", LG.USBLOGINFO, recordKafka.offset());
            logger.info("{}:KafkaListener(record.partition) == {}", LG.USBLOGINFO, recordKafka.partition());
            logger.info("{}:KafkaListener(record.key)       == {}", LG.USBLOGINFO, recordKafka.key());
            logger.info("{}:KafkaListener (record.value)    == {}", LG.USBLOGINFO, recordKafka.value());
            logger.info("{}:KafkaListener(topic)            == {}", LG.USBLOGINFO, recordKafka.topic());
            logger.info("{}:KafkaListener(Offset)           == {}", LG.USBLOGINFO, recordKafka.offset());
            logger.info("{}:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", LG.USBLOGINFO);
        }


        if (recordKafka.value() == null) {
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!", LG.USBLOGERROR);
            logger.error("{}::+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", LG.USBLOGERROR, recordKafka.offset());
            logger.error("{}::KafkaListener(record.partition) == {}", LG.USBLOGERROR, recordKafka.partition());
            logger.error("{}::KafkaListener(record.key)       == {}", LG.USBLOGERROR, recordKafka.key());
            logger.error("{}::KafkaListener(record.value)     == {}", LG.USBLOGERROR, recordKafka.value());
            logger.error("{}::KafkaListener(topic)            == {}", LG.USBLOGERROR, recordKafka.topic());
            logger.error("{}::KafkaListener(Offset)           == {}", LG.USBLOGERROR, recordKafka.offset());
            logger.error("{}::++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", LG.USBLOGERROR);
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR);
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()) + "\n\r" +
                    "KafkaListener(Offset)" + recordKafka.offset());
        }

//        //Если очередь длиннее чем заданная тормозим принятие новых сообщений
//        if (configure.getTokenSync() == null || configure.getTokenSync().length() < 10 ||  configure.getThreads() > maxSizeQueue){
//            logger.info("{} Притормаживаем процесс вычитывания очереди на {} секунд, достигнут заданный порог длины очереди={} или не получен токен!", LG.USBLOGINFO, ackDuration, maxSizeQueue);
//            ack.nack(ackDuration * 1000L);
//        } else {
//            logger.info("{} Возобновляем процесс вычитывания сообщений, длина очереди сейчас={}", LG.USBLOGINFO, configure.getThreads());
//            ack.acknowledge(); //Сообщение забираем сразу
//            /**
//             * Обработка сообщения
//             * @param message  - тело сообщения
//             */
            ack.acknowledge(); //Сообщение забираем сразу
            messageProcess.process(recordKafka.value());
        }


}
