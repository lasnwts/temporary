package ru.usb.externalbank_intgr_siebel.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaMessage {

    @JsonProperty("SYSTEM_FROM")
    private String systemFrom;

    @JsonProperty("system_to")
    private String systemTo;

    @JsonProperty("service")
    private String service;

    @JsonProperty("routeid")
    private String routeID;

    @JsonProperty("mapper")
    private String mapper;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    private String errortext;

}
