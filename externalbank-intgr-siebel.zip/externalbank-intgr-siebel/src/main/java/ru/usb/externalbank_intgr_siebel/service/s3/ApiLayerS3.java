package ru.usb.externalbank_intgr_siebel.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.configure.LG;

import java.io.File;
import java.util.List;


@Log4j2
@Service
public class ApiLayerS3 {


    private final AmazonS3Service amazonS3Service;

    @Autowired
    public ApiLayerS3(AmazonS3Service amazonS3Service) {
        this.amazonS3Service = amazonS3Service;
    }

    /**
     * Скачивание файла из бакета
     *
     * @param fileLink   - имя файла
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     */
    public File downloadFileFromS3(String fileLink, String bucketName, String fileName) throws Exception {
        try {
            File file = amazonS3Service.upload(fileName, amazonS3Service.getFile(bucketName, fileLink));//Скачиваем файл с S3 по бакету и линку
            log.info("{}: Загружен файл:{} размером bytes.length={}", LG.USBLOGINFO, file.getName(), file.length());
            return file;
        } catch (Exception e) {
            log.error("{}:[downloadFileFromS3] Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[downloadFileFromS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Удаление файла из бакета
     *
     * @param bucketName - имя бакета
     * @param fileLink   - имя файла
     */
    public HttpStatus deleteFileFromS3(String bucketName, String fileLink) {
        return amazonS3Service.deleteFile(bucketName, fileLink);
    }

    /**
     * Сохранение файла в бакет
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToS3(String bucketName, String key, File file) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, key, file) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[saveFileToS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Сохранение файла в бакет ERROR
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToErrorS3(String bucketName, String key, File file) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, "error/" + key, file) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]: Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[saveFileToErrorS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }


    /**
     * Получение списка файлов из бакета
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public List<String> listFilesS3(String bucketName) {
        return amazonS3Service.listFiles(bucketName);
    }


    /**
     * Получение списка файлов из бакета
     * @param bucketName - имя бакета
     * @param key - ключ поиска
     * @return - список файлов
     */
    public List<String> listObjectsS3(String bucketName, String key) {
        return amazonS3Service.listObjects(bucketName, key);
    }

    /**
     * Получение списка файлов из бакета
     * @param bucketName - имя бакета
     * @param key - ключ поиска
     * @return - список файлов
     */
    public List<String> listKeys(String bucketName, String key) {
        return amazonS3Service.listKeys(bucketName, key);
    }

    /**
     * Копирование файла в бакет
     *
     * @param sourceBucket      - имя исходного бакета
     * @param sourceKey         - имя исходного файла
     * @param destinationBucket - имя бакета назначения
     * @param destinationKey    - имя файла назначения
     */
    public void copyFileS3(String sourceBucket, String sourceKey, String destinationBucket, String destinationKey){
        try {
            amazonS3Service.copyFile(sourceBucket, sourceKey, destinationBucket, destinationKey);
        } catch (Exception e) {
            log.error("{}:[copyFileS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:stackTrace:", LG.USBLOGERROR, e);
        }
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    public HttpStatus getS3StatusCode(String line) {
        return amazonS3Service.getStatusCode(line);
    }
}
