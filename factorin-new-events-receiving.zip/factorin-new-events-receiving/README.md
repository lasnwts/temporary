# factorin-new-events-receiving

7345 Разработка интеграционного сервиса Factorin - Актив-Факторинг. Сервис получения новых сообщений. 
Ссылка https://devsystem.smartsoftware.ru/initiatives/7345. МП 970570, инициатива ИПР 7345
