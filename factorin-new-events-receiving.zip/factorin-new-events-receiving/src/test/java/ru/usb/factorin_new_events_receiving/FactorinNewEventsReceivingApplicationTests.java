package ru.usb.factorin_new_events_receiving;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactorinNewEventsReceivingApplicationTests {

	@Test
	void contextLoads() {
	}

}
