package ru.usb.factorin_new_events_receiving;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.factorin_new_events_receiving.configure.Configure;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.service.factoring.token.GetToken;
import ru.usb.factorin_new_events_receiving.service.kafka.KafkaProducerService;
import ru.usb.factorin_new_events_receiving.utils.Sutils;

import java.util.Date;

@Log4j2
@EnableScheduling
@SpringBootApplication
public class FactorinNewEventsReceivingApplication implements CommandLineRunner {

	private final Configure configure;

	@Autowired
	public FactorinNewEventsReceivingApplication(Configure configure) {
		this.configure = configure;
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${service.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (factorin-new-events-receiving)")
				.version(appVersion)
				.description("API factorin-new-events-receiving, a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	public static void main(String[] args) {
		SpringApplication.run(FactorinNewEventsReceivingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		log.info("{}: Created by 03.07.2024               : initial version: 0.0.01 Author@Lyapustin A.S.", TG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
		log.info("{}: Описание пакетов                    : ", TG.UsbLogInfo);
		log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
		log.info("{}: Current version reason              : {}", TG.UsbLogInfo, configure.getAppVersion());
		log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);
		log.info("{}: Modified reason                     : 0.0.02", TG.UsbLogInfo);
		log.info("{}:-----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);

	}
}
