package ru.usb.factorin_new_events_receiving.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Document {

    @JsonProperty("Uid")
    public String uid;
    @JsonProperty("ParentUid")
    public String parentUid;
    @JsonProperty("Number")
    public String number;
    @JsonProperty("FileName")
    public String fileName;
    @JsonProperty("DocumentTypeCode")
    public String documentTypeCode;
    @JsonProperty("UnParsedLog")
    public String unParsedLog;
    @JsonProperty("Signs")
    public List<Sign> signs;

}
