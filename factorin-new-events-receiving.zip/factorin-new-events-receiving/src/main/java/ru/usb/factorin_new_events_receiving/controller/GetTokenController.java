package ru.usb.factorin_new_events_receiving.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.service.factoring.ApiLayer;


@RestController
@RequestMapping("/api/token")
@Tag(name = "Контроллер для получения токена", description = "Получение токена")
public class GetTokenController {

    private final Logger log = LoggerFactory.getLogger(GetTokenController.class);

    private final ApiLayer apiLayer;

    @Autowired
    public GetTokenController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }

    @GetMapping(value = "/")
    @Operation(summary = "Получить Access Token, через сервис Events new в Факторинге")
    public String getToken() {
        log.info("{}: Rest API Get token", TG.UsbLogInfo);
        return apiLayer.getToken();
    }

    @GetMapping(value = "/info")
    @Operation(summary = "Получить информацию по токену")
    public String getInfo() {
        log.info("{}: Rest API Get info token", TG.UsbLogInfo);
        return apiLayer.getInfoToken();
    }

    @GetMapping(value = "/check")
    @Operation(summary = "Получить токен, полученный ранее, без прямого запроса токена в Факторинге")
    public String checkToken() {
        log.info("{}: Rest API Check token", TG.UsbLogInfo);
        return apiLayer.checkToken();
    }
}
