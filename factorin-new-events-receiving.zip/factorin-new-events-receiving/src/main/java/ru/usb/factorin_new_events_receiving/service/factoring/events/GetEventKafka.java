package ru.usb.factorin_new_events_receiving.service.factoring.events;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.dto.EventLess;
import ru.usb.factorin_new_events_receiving.dto.Events;
import ru.usb.factorin_new_events_receiving.dto.bank.FactoringDocument;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * Формирование сообщения в топик Kafka
 * -------------------------------------------------------------
 * 5.	Сформировать и записать сообщение в топик Kafka «factorin.active-factoring.event.0» (операция в ОТАР «Записать сообщение в топик Kafka «FactoringEvent», записать в логи»). Обязательные параметры сообщения приведены в таблице 4.
 * Таблица 4 – Обязательные параметры в сообщении топика «factorin.active-factoring.event.0» Kafka
 * Параметр Kafka	Значение	Наименование
 * EventDate	Формируется автоматически (дата, время)	Дата получения
 * EventId	Равен значению UID в Factorin	Идентификатор события
 * EventName	Равен значению EventName в Factorin	Наименование события (например, подписано Фактором или на подписании Фактором)
 * ObjectId	Равен значению ObjectUID в Factorin	Идентификатор объекта (реестра)
 * RegisterTemplateCode	Равен значению RegisterTemplateCode в Factorin	Код документа (реестр уступок (поставок) или реестр платежей)
 * Microservice	При получении от Factorin заполнять «Factorin»	Наименование источника
 * Пример сообщения в топике «factorin.active-factoring.event.0»:
 *
 * {
 * 	"EventDate": "03.11.2023 10:16:40",
 * 	"EventId": "a8a6fcf0-52a0-43d4-afc7-8ee22f32c630",
 * 	"EventName": "closed_stage",
 * 	"ObjectId": "2fc776c0-e98e-4416-b1a6-5d4901a25992"
 * 	"RegisterTemplateCode": "ReesterApproved",
 * 	"Microservice": "Factorin"
 * }
 */

@Log4j2
@Service
public class GetEventKafka {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    /**
     * Формирование сообщения в топик Kafka
     *
     * @param event - событие исходное в формате Факторинг
     * @return - сообщение в топик Kafka
     */
    public FactoringDocument getEventKafka(Events event) {
        FactoringDocument factoringDocument = new FactoringDocument();
        factoringDocument.setEventDate(sdf.format(new Date()));
        factoringDocument.setEventId(event.getUid());
        factoringDocument.setEventName(event.getEventName());
        factoringDocument.setObjectId(event.getObjectUid());
        factoringDocument.setRegisterTemplateCode(event.getRegisterTemplateCode());
        factoringDocument.setMicroservice("Factorin");
        return factoringDocument;
    }

}
