package ru.usb.factorin_new_events_receiving.service.factoring.events;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.Events;
import ru.usb.factorin_new_events_receiving.dto.bank.FactoringDocument;

import java.util.Optional;

/**
 * Класс отбора нужных сообщшений
 * <p>
 * Из списка новых событий от Factorin необходимо получить значение параметра ObjectUid при условиях:
 * - "RegisterTemplateCode" = "ReesterApproved " и "EventName": "app_signed_factor"  и "TimeAttribute" = "Before" (по данному событию необходимо получить только унифицированные данные)
 * - "RegisterTemplateCode" = ReesterApproved и "EventName" = "closed_stage"  (по данному событию необходимо получить унифицированные данные и zip файл)
 * - "RegisterTemplateCode" = "ReesterCeded"  и "EventName" = " ced_signed_client"  (по данному событию необходимо получить только zip файл)
 * - "RegisterTemplateCode" = " ReesterPaymentDistr"  (по данному событию необходимо получить унифицированные данные и zip файл).
 */

@Log4j2
@Service
public class MatchEvents {

    private final GetEventKafka getEventKafka;

    @Autowired
    public MatchEvents(GetEventKafka getEventKafka) {
        this.getEventKafka = getEventKafka;
    }

    /**
     * Получение события
     *
     * @param event - события
     * @return - список событий для отправка в Кафка
     */
    public Optional<FactoringDocument> matchEvents(Events event) {
        if (isNeed(event)) {
            return Optional.of(getEventKafka.getEventKafka(event));
        }
        return Optional.empty();
    }

    /**
     * Определение нужного события
     *
     * @param event - событие
     * @return - нужное событие (true)
     */
    private boolean isNeed(Events event) {
        //По требованию FSD страница 10.4. в лог
        // ----------------------------------------------------------------------------------------------------------------
        // Обработать список новых событий и сформировать перечень параметров ObjectUid
        // (идентификатор объекта в системе Factorin) для дальнейшего процесса по получению данных (операция в ОТАР «Сформировать выборку
        // (список) (UID, ObjectUID) по новым события, записать в логи»).
        log.info("{}: Получено сообщение: UID={}, ObjectUID={}", TG.UsbLogInfo, event.getUid(), event.getObjectUid());

        //Тут продолжаем
        if (event.getRegisterTemplateCode() == null) {
            return false;
        }
        if (event.getRegisterTemplateCode().equals("ReesterPaymentDistr")) {
            return true;
        }
        if (event.getEventName() != null) {
            if (event.getRegisterTemplateCode().equals("ReesterApproved") && event.getEventName().equals("app_signed_factor") &&
                    event.getTimeAttribute() !=null && event.getTimeAttribute().equals("Before")) {
                return true;
            }
            if (event.getRegisterTemplateCode().equals("ReesterApproved") && event.getEventName().equals("closed_stage")) {
                return true;
            }
            return event.getRegisterTemplateCode().equals("ReesterCeded") && event.getEventName().equals("ced_signed_client"); //Для проверки использовал :ced_serialized
        }
        return false;
    }

}
