package ru.usb.factorin_new_events_receiving.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EventLess {

    private HttpStatus statusCode; //Код возврата, 200, 40X, 50X
    private String message; //Расшифровка ошибок
    private List<Events> eventsList;  //список сообщений

}
