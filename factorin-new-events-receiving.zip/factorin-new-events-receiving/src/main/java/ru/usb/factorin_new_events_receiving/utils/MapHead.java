package ru.usb.factorin_new_events_receiving.utils;


import org.springframework.stereotype.Component;
import ru.usb.factorin_new_events_receiving.model.generated.Head;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Имя атрибута в АФ	Обязательность	Тип	Описание	Параметр Factorin
 * 1. <Head
 * Source	Да	string	Имя системы-источника данных	Factorin
 * Target	Да	string	Имя системы-получателя данных	AF
 * DateTime	Да	Date	Дата/время формирования пакета	CreateDate
 * ObjectType	Да	string	Тип объекта (Расшифровка платежа (InPaymLines), реестр уступки (Supply))	RegisterTemplateDltCode = ReesterApproved или
 * ReesterPaymentDistr  * или  * ReesterCeded
 * RequestId	Да	string	Идентификатор запроса	RegisterUid
 * Ans	Да	string	признак необходимости ответа-подтверждения обработки пакета данных	1
 * EventId	Да	string	Идентификатор события	EventId сообщения
 */

@Component
public class MapHead {

    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public Head mapHead(String objectType, String requestId, String eventId, Date date) {
        Head head = new Head();
        //Константы
        head.setSource("Factorin");
        head.setTarget("AF");
        head.setAns(1);
        //Набор
        head.setObjectType(objectType);
        head.setRequestId(requestId);
        head.setEventId(eventId);
        head.setDateTime(sdf.format(date));
        return head;
    }

}
