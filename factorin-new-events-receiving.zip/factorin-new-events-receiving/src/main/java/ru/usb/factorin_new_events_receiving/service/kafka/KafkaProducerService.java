package ru.usb.factorin_new_events_receiving.service.kafka;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.configure.TG;

/**
 * Класс отправки сообщений Кафка
 */
@Log4j2
@Service
public class KafkaProducerService {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Простой вариант отправки сообщений, без проверки
     *
     * @param topic - топик
     * @param msg   - сообщение
     */
    public boolean sendMessage(String topic, String msg) {
        try {
            kafkaTemplate.send(topic, msg);
            log.info("UsbLog:Success send.Topic={}; Send message={}", topic, msg);
            return true;
        } catch (Exception exception) {
            log.error("{}:!!!!!<ERROR send message>[sendMessage(String topic, String msg)]!!!", TG.UsbLogError);
            log.error("{}:send failure:topic:{}, message:{}", TG.UsbLogError, topic, msg);
            log.error("{}:Error message:{}", TG.UsbLogError, exception.getMessage());
            log.debug("{}:Exception::", TG.UsbLogError, exception);

            return false;
        }
    }

    /**
     *  Документ: [ИПР_FSD_965454_Интеграц сервис Факторин_v_0_6.docx]. Страница 11.
     *  Отправляем сообщение в Kafka и записываем в логи.
     *  -----------------
     * 	Сформировать и записать сообщение в топик Kafka «factorin.active-factoring.event.0» (операция в ОТАР «Записать сообщение в топик Kafka «FactoringEvent», записать в логи»). Обязательные параметры сообщения приведены в таблице 4.
     *  Таблица 4 – Обязательные параметры в сообщении топика «factorin.active-factoring.event.0» Kafka
     * ------------------
     * @param topic - топик
     * @param msg   - сообщение
     */
    public boolean sendMessage(String topic, String key, String msg) {
        if (msg != null && !msg.isEmpty()) {
            try {
                kafkaTemplate.send(topic, key, msg);
                log.info("{}:Success send.Topic={}; key={}; Send message={};", TG.UsbLogInfo, topic, key, msg);
                return true;
            } catch (Exception exception) {
                log.error("{}:!!!<ERROR send message>[sendMessage(String topic, String key, String msg)]!!!!!", TG.UsbLogError);
                log.error("{}:send failure:topic:{}, key:{} message:{}", TG.UsbLogError, topic, key, msg);
                log.error("{}: Error message::{}", TG.UsbLogError, exception.getMessage());
                log.debug("{}:Exception::", TG.UsbLogError, exception);
                return false;
            }
        }
        log.error("{}:Error message:прилетело пустое сообщение на отправку!", TG.UsbLogError);
        return false; //прилетело пустое сообщение на отправку
    }

}
