package ru.usb.factorin_new_events_receiving.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.service.factoring.MasterProcess;

@Slf4j
@Service
public class MasterScheduler {

    private final MasterProcess masterProcess;

    @Autowired
    public MasterScheduler(MasterProcess masterProcess) {
        this.masterProcess = masterProcess;
    }

    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void masterScheduler() {
        log.debug("{}: MasterScheduler started", TG.UsbLogInfo);
        masterProcess.run();
    }


}
