package ru.usb.factorin_new_events_receiving.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import ru.usb.factorin_new_events_receiving.dto.bank.FactoringDocument;

@Log4j2
@Component
public class FactoringDocumentMapper {

    ObjectMapper objectMapper = new ObjectMapper();
    /**
     * Преобразование объекта в строку JSON
     *
     * @param message объект
     * @return - строка Json
     */
    public String getJsonToStr(FactoringDocument message) {

        if (message == null) {
            log.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            log.error("UsbLog:На маппер поступил объект [FactoringDocument] == NULL! Класс [message] метод [getJsonToStr]");
            return "";
        }

        try {
            return objectMapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            log.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            log.error("UsbLog:Ошибка преобразования объекта [FactoringDocument] в JSON строку!");
            log.error("UsbLog:Описание ошибки:{}", e.getMessage());
            log.debug("UsbLog:Описание ошибки:", e);
            return "";
        }
    }
}
