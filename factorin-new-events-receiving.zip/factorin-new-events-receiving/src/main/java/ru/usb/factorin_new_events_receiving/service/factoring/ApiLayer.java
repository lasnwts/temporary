package ru.usb.factorin_new_events_receiving.service.factoring;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.configure.Configure;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.EventLess;
import ru.usb.factorin_new_events_receiving.dto.Events;
import ru.usb.factorin_new_events_receiving.service.factoring.events.GetEvents;
import ru.usb.factorin_new_events_receiving.service.factoring.token.GetToken;
import ru.usb.factorin_new_events_receiving.utils.EventsMapper;
import ru.usb.factorin_new_events_receiving.utils.Sutils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Слой API по работе с факторингом
 */

@Service
@Log4j2
public class ApiLayer {

    private final GetToken getToken;
    private final Configure configure;
    private final Sutils support;
    private final EventsMapper mapper;
    private final GetEvents getEvents;


    @Autowired
    public ApiLayer(GetToken getToken, Configure configure, Sutils support, EventsMapper mapper, GetEvents getEvents) {
        this.getToken = getToken;
        this.configure = configure;
        this.support = support;
        this.mapper = mapper;
        this.getEvents = getEvents;
    }


    //Получение токенов
    public String getToken() {
        if (getToken.getToken()) {
            log.info("{}:Token received successfully. Date={}", TG.UsbLogInfo, configure.getTokenDate());
            return configure.getToken();
        } else {
            log.error("{}: Failed to receive token. Error:{}", TG.UsbLogError, configure.getStatusMessage());
            return ""; //Передадим пустую строку--
        }
    }


    //Получение информации токенов
    public String getInfoToken() {
        log.info("{}: statusMessage:{}", TG.UsbLogInfo, configure.getStatusMessage());
        log.info("{}: statusCode:{}", TG.UsbLogInfo, configure.getStatusCode());
        log.info("{}: Date:{}", TG.UsbLogInfo, configure.getTokenDate());
        log.info("{}: Token:{}", TG.UsbLogInfo, configure.getToken());
        return "statusCode:" + configure.getStatusCode() + "\n\r<br>" +
                "Date:" + configure.getTokenDate() + "\n\r<br>" +
                "error:" + support.getWrapNull(configure.getStatusMessage()) + "\n\r<br>" +
                "Token:" + support.getWrapNull(configure.getToken()) + "\n\r<br>";
    }


    //Мапирование объекта
    public List<Events> getEvent(String message) {
        return mapper.mapEvents(message).orElse(new ArrayList<>());
    }

    /**
     * Получение новых событий
     *
     * @return - Список событий
     */
    public EventLess getNewEvent() {

        boolean onlyNew = true;
        int pageNumber = 1;
        int pageSize = 1000;

        return getEvents.getEvents(getToken(),
                support.strEvent(onlyNew), pageNumber, pageSize, null, null, null, null);
    }

    /**
     * Получение старого токена
     * @return - Старый токен
     */
    public String checkToken() {
        return configure.getToken();
    }

}
