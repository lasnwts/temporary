package ru.usb.factorin_new_events_receiving.service.factoring;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.factorin_new_events_receiving.configure.Configure;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.EventLess;
import ru.usb.factorin_new_events_receiving.dto.bank.FactoringData;
import ru.usb.factorin_new_events_receiving.dto.bank.FactoringDocument;
import ru.usb.factorin_new_events_receiving.service.factoring.events.MatchEvents;
import ru.usb.factorin_new_events_receiving.service.kafka.KafkaProducerService;
import ru.usb.factorin_new_events_receiving.service.mail.ServiceMailError;
import ru.usb.factorin_new_events_receiving.utils.FactoringDataMapper;
import ru.usb.factorin_new_events_receiving.utils.FactoringDocumentMapper;
import ru.usb.factorin_new_events_receiving.utils.Sutils;

import java.util.Date;
import java.util.Optional;

/**
 * Класс - организатор процесса.
 * -------------------
 * 1. Получаем список событий.
 * 2. Парсим события.
 * 3. Отбираем нужные события в список
 * 4. Отправляем события в Kafka.
 * --------------------------
 * Получить и cформировать и записать сообщение в топик Kafka «factorin.active-factoring.event.0»
 * (операция в ОТАР «Записать сообщение в топик Kafka «FactoringEvent», записать в логи»).
 * --------------------------
 */

@Log4j2
@Service
public class MasterProcess {

    private final MatchEvents matchEvents;
    private final ApiLayer apiLayer;
    private final KafkaProducerService kafkaProducerService;
    private final Configure configure;
    private final FactoringDocumentMapper mapper;
    private final FactoringDataMapper dataMapper;
    private final Sutils sutils;
    private final ServiceMailError serviceMailError;


    @Autowired
    public MasterProcess(MatchEvents matchEvents, ApiLayer apiLayer, KafkaProducerService kafkaProducerService,
                         Configure configure, FactoringDocumentMapper mapper, FactoringDataMapper dataMapper,
                         Sutils sutils, ServiceMailError serviceMailError) {
        this.matchEvents = matchEvents;
        this.apiLayer = apiLayer;
        this.kafkaProducerService = kafkaProducerService;
        this.configure = configure;
        this.mapper = mapper;
        this.dataMapper = dataMapper;
        this.sutils = sutils;
        this.serviceMailError = serviceMailError;
    }

    public void run() {

        //Constant
        String factoring = "Factorin";
        String message = "Message";

        log.debug("{}:MasterProcess started", TG.UsbLogInfo);

        //Получаем новые события из факторинга
        EventLess eventLess = apiLayer.getNewEvent();

        if (eventLess != null && eventLess.getStatusCode().is2xxSuccessful()) {
            if (eventLess.getEventsList() == null || eventLess.getEventsList().isEmpty()) { //проверяем есть ли вообще сообщения
                log.info("{}: MasterProcess: Новых данных нет", TG.UsbLogInfo);
                /**
                 * Формируем сообщение XML в data топик, при отсутствии новых сообщений
                 */
                try {
                    sendToDataTopic(createDataEvent(sutils.getXML(message, null, null, new java.util.Date(),
                            null, null, "Новых данных нет"), new Date(), factoring));
                } catch (JsonProcessingException e) {
                    log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
                    log.error("{}:Ошибка преобразования объекта [FactoringData] в JSON строку", TG.UsbLogError);
                    log.error("{}: Описание ошибки:{}", TG.UsbLogError, e.getMessage());
                    log.debug("{}:Описание ошибки:", TG.UsbLogError, e);
                    //Здесь сделать отправку почтовой ошибки
                }
            } else {
                //Если сообщения какие, то есть
                log.info("{}: MasterProcess: всего событий: {}", TG.UsbLogInfo, eventLess.getEventsList().size());
                //Парсим события
                eventLess.getEventsList().forEach(event -> sendToKafka(matchEvents.matchEvents(event)));
            }
        } else {
            log.info("{}: MasterProcess: Error get new Events on server Factoring", TG.UsbLogError);
            /**
             * Формируем сообщение XML в data топик
             * Если ошибка связана с «Сервис недоступен» (status = 500), то интеграционный сервис должен:
             * - направить информационное сообщение в «Актив-Факторинг» - «Factorin недоступен» - см. таблицу 6 (файл XML_АФ.xsd – см. страницу 15);
             * - сгенерировать и направить сообщение по Email в службу технической поддержки (ServiceDesk), которое должно содержать наименование сервиса, код и описание ошибки.
             */
            try {
                sendToDataTopic(createDataEvent(sutils.getXML(message, null, null, new java.util.Date(), null, null, "Factorin недоступен." +
                        "status=" + sutils.getWrapNull(eventLess.getStatusCode().toString()) + ", message: " + sutils.getWrapNull(eventLess.getMessage())), new Date(), factoring));
                serviceMailError.sendMailErrorSubject("«Factorin недоступен»" + " Сервис получения новых данных из факторинга:" + configure.getAppName(),
                        createDataEvent(sutils.getXML(message, null, null, new java.util.Date(), null, null, "Factorin недоступен." +
                                "status=" + sutils.getWrapNull(eventLess.getStatusCode().toString()) + ", message :" + sutils.getWrapNull(eventLess.getMessage())), new Date(), factoring));
            } catch (JsonProcessingException e) {
                log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
                log.error("{}:Ошибка преобразования объекта [FactoringData] в JSON строку!", TG.UsbLogError);
                log.error("{}:Описание ошибки:{}", TG.UsbLogError, e.getMessage());
                log.debug("{}:Описание ошибки:", TG.UsbLogError, e);
                serviceMailError.sendMailErrorSubject("«Factorin недоступен»" + "Сервис получения новых данных из факторинга:" + configure.getAppName(),
                        " Описание ошибки:" + e.getMessage() + "\n\r" +
                                "status=" + sutils.getWrapNull(eventLess.getStatusCode().toString()) + ", message: " + sutils.getWrapNull(eventLess.getMessage()));
            }
        }
    }

    //Отправка отобранных сообщений в топик Event
    private void sendToKafka(Optional<FactoringDocument> factoringDocument) {
        factoringDocument.ifPresent(document -> kafkaProducerService.sendMessage(configure.getEventTopic(), document.getObjectId(), mapper.getJsonToStr(document)));
    }

    //Отправка сообщений в топик Data
    private void sendToDataTopic(String message) {
        kafkaProducerService.sendMessage(configure.getDataTopic(), "1", message);
    }

    //Создание события для отправки в топиках data
    private String createDataEvent(String xml, Date date, String serviceNameFactoring) {
        FactoringData factoringData = new FactoringData();
        factoringData.setDocumentDataXml(xml);
        factoringData.setShouldUnsubscribeOnSuccess(false);
        factoringData.setMicroservice(serviceNameFactoring);
        factoringData.setRegisterTemplateCode(null);
        factoringData.setEventName(null);
        factoringData.setEventDate(sutils.getDateTime(date));
        return sutils.getUnescape(dataMapper.getJsonToStr(factoringData));
    }


}
