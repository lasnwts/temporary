package ru.usb.factorin_new_events_receiving.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.model.generated.All;
import ru.usb.factorin_new_events_receiving.model.generated.Messages;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class Sutils {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    private final MapBody mapBody;
    private final MapHead mapHead;

    @Autowired
    public Sutils(MapBody mapBody, MapHead mapHead) {
        this.mapBody = mapBody;
        this.mapHead = mapHead;
    }

    XmlMapper xmlMapper = new XmlMapper();
    public static final String REPLACEMENT = ":\"\",";

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }


    /**
     * Обработка строковых значений null на пустые строки
     *
     * @param message - входящее сообщение строка Json
     * @return - сообщение с обработанными null значениями
     */
    public String wrapNullJson(String message) {

        String messagePrepared = null;

        if (message == null) {
            return "";
        }

        if (message.contains(": ,") || message.contains(":,") || message.contains(":  ,") || message.contains(":   ,")) {
            log.info("{}:Сообщение содержит пустое значение в поле, что делает невозможным его распознавание[: ,]", TG.UsbLogInfo);
            log.info("{}:Сообщение будет модифицировано - значение =[: ,], будет заменено на строковое пустое, знак двойной кавычки", TG.UsbLogInfo);
            log.info("{}:Входящее сообщение, до модификации [message]:{}", TG.UsbLogInfo, message);
            messagePrepared = message.replace(": ,", REPLACEMENT).replace(":,", REPLACEMENT).replace(":  ,", REPLACEMENT).replace(":   ,", REPLACEMENT);
            log.info("{}:Обработанное сообщение [message]:{}", TG.UsbLogInfo, messagePrepared);
            return messagePrepared;
        } else {
            return message;
        }

    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        if (fileNameFull == null) {
            return false;
        }
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        return Files.exists(path);
    }

    //Получаем файл
    public File getFile(String location) {
        return new File(location);
    }

    /**
     * Получаем новое событие
     *
     * @param event - флаг
     * @return - строка "true" или null
     */
    public String strEvent(boolean event) {
        if (event) {
            return "true";
        } else {
            return null;
        }
    }


    /**
     * Получаем XML
     *
     * @param objectType - тип объекта
     * @param requestId  - id запроса
     * @param eventId    - id события
     * @param date       - дата
     * @param sourceId   - источник
     * @param branchId   - филиал
     * @param msg        - сообщение
     * @return - XML
     * @throws JsonProcessingException
     */
    public String getXML(String objectType, String requestId, String eventId, Date date, String sourceId, String branchId, String msg) throws JsonProcessingException {
        All all = new All();
        all.setHead(mapHead.mapHead(objectType, requestId, eventId, date));
        all.setBody(mapBody.mapBody());
        Messages messages = new Messages();
        messages.setMessage(mapBody.mapMessages(sourceId, branchId, msg, date));
        all.getBody().setMessages(messages);
        return  mapBody.getAllName(xmlMapper.writeValueAsString(all));
    }

    /**
     * Получаем дату и время в нужном формате для топика Data
     *
     * @param date - дата
     * @return - дата и время в нужном формате
     */
    public String getDateTime(Date date) {
        return sdf.format(date);
    }


    public String getUnescape(String message) {
        return message.replace("\\u003d", "=").replace("\\u003c", "<").replace("\\u003e", ">");
    }

}
