package ru.usb.factorin_new_events_receiving.configure;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
@ConfigurationProperties
@Data
public class Configure {

    /**
     * Get token
     * ===============================================
     * Свойства для получения токена
     * ===============================================
     */
    @Value("${host.url}")
    private String hostURL;

    @Value("${token.url}")
    private String tokenURL;

    @Value("${event.url}")
    private String eventURL;

    @Value("${token.username}")
    private String tokenUserName;

    @Value("${token.password}")
    private String tokenPassword;

    @Value("${token.type}")
    private String tokenGrantType; // grant type password

    @Value("${token.scope}")
    private String tokenScope; //Scope

    @Value("${basic.username}")
    private String basicUserName;

    @Value("${basic.password}")
    private String basicPassword;

    private String token; //Токен
    private Date tokenDate; //Дата получения токена
    private int statusCode; //Ответ по токену
    private String statusMessage; //Описание ошибки


    /**
     * Топики
     */
    @Value("${kafka.data.topic}")
    private String dataTopic;

    @Value("${kafka.event.topic}")
    private String eventTopic;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Секция о программе
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;


    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    /**
     *  Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

}
