package ru.usb.factorin_new_events_receiving.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.Events;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Log4j2
@Component
public class EventsMapper {

    private final Sutils sutils;

    @Autowired
    public EventsMapper(Sutils sutils) {
        this.sutils = sutils;
    }

    ObjectMapper objectMapper = new ObjectMapper();

    public Optional<List<Events>> mapEvents(String message) {

        if (message == null) {
            log.error("{}: На маппер mapEvents поступил объект, строка [message] == NULL!", TG.UsbLogError);
            return Optional.empty();
        }

     Events[] events = null;

        try {
            events = objectMapper.readValue(sutils.wrapNullJson(message), Events[].class);
            return Optional.of(Arrays.asList(events));
        } catch (JsonProcessingException e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", TG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", TG.UsbLogError, e);
            return Optional.empty();
        }
    }
}
