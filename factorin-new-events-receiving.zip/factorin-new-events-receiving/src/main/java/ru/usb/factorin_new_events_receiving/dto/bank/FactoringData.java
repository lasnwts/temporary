package ru.usb.factorin_new_events_receiving.dto.bank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Таблица 7 – Обязательные параметры в сообщении топика «factorin-to-activefactoring.data.0» Kafka
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Параметр Kafka	            Значение	                                                                Наименование
 * ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
 * EventDate	                Формируется автоматически (дата, время)	                                    Дата загрузки сообщения
 * EventId	                    Равен параметру EventId из топика «factorin.active-factoring.event.0»	    Идентификатор события
 * EventName	                Равен значению EventName из топика «factorin.active-factoring.event.0»	    Наименование события (например, подписано Фактором или на подписании Фактором)
 * ObjectId                 	Равен значению ObjectId из топика «factorin.active-factoring.event.0»	    Идентификатор объекта (реестра)
 * RegisterTemplateCode	        Равен значению RegisterTemplateCode из топика
 *                              «factorin.active-factoring.event.0»	                                        Код документа (реестр уступок (поставок) или реестр платежей)
 * ProviderName	                При получении от Factorin заполнять «Factorin»	                            Наименование поставщика
 * DocumentDataXml	            Содержит унифицированные данные для дальнейшей передачи в АФ	            Содержимое файла .xml для передачи в АФ
 * ShouldUnsubscribeOnSuccess	При получении унифицированных данных должно заполняться значением «false» - не требует отписаться от события.
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------=
 * При получении файла – «true» - требует отписаться об успешной загрузке файла	Флаг необходимости отписаться от события
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------_
 */


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FactoringData {

    @JsonProperty(value = "EventDate")
    private String eventDate;
    @JsonProperty(value = "EventId")
    private String eventId;
    @JsonProperty(value = "EventName")
    private String eventName;
    @JsonProperty(value = "ObjectId")
    private String objectId;
    @JsonProperty(value = "RegisterTemplateCode")
    private String registerTemplateCode;
    @JsonProperty(value = "Microservice")
    private String microservice;
    @JsonProperty(value = "DocumentDataXml")
    private String documentDataXml;
    @JsonProperty(value = "ShouldUnsubscribeOnSuccess")
    private boolean shouldUnsubscribeOnSuccess;

}
