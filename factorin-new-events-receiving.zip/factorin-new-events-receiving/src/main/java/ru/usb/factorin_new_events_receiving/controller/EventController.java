package ru.usb.factorin_new_events_receiving.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.EventLess;
import ru.usb.factorin_new_events_receiving.dto.Events;
import ru.usb.factorin_new_events_receiving.service.factoring.ApiLayer;

import java.util.List;

@RequestMapping("api/v1/event")
@RestController
@Tag(name = "Event Controller", description = "Event API")
public class EventController {

    Logger log = LoggerFactory.getLogger(EventController.class);

    private final ApiLayer apiLayer;

    @Autowired
    public EventController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }

    @PostMapping(value = "/validate")
    public ResponseEntity<List<Events>> getEvents(@RequestBody String json) {
        log.info("{}: Rest API Validate String={}", TG.UsbLogInfo, json);
        List<Events> events = apiLayer.getEvent(json);
        if (events.isEmpty()) {
            log.info("{}: Rest API Validate: Validation failed. Json string badly.", TG.UsbLogInfo);
        } else {
            log.info("{}: Rest API Validate: validate successfully. Count events: {}", TG.UsbLogInfo, events.size());
        }
        return ResponseEntity.ok(events);
    }

    @GetMapping(value = "/new")
    public ResponseEntity<List<Events>> getEvents() {
        log.info("{}: Rest API get New events", TG.UsbLogInfo);
        EventLess eventLess = apiLayer.getNewEvent();
        if (eventLess.getStatusCode().is2xxSuccessful()) {
            log.info("{}: Count events: {}", TG.UsbLogInfo, eventLess.getEventsList().size());
            return ResponseEntity.ok(eventLess.getEventsList());
        } else {
            log.info("{}: Not new events. StatusCode={}, Message={}", TG.UsbLogInfo, eventLess.getStatusCode(), eventLess.getMessage());
            return ResponseEntity.status(eventLess.getStatusCode()).body(null);
        }
    }

}
