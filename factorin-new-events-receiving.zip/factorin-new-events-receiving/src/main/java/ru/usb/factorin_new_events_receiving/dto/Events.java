package ru.usb.factorin_new_events_receiving.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Events {

    @JsonProperty("Id")
    public int id;
    @JsonProperty("Uid")
    public String uid;
    @JsonProperty("Code")
    public String code;
    @JsonProperty("Date")
    public Date date;
    @JsonProperty("ObjectUid")
    public String objectUid;
    @JsonProperty("IsProcessed")
    public boolean isProcessed;
    @JsonProperty("EventName")
    public String eventName;
    @JsonProperty("ProcessCode")
    public String processCode;
    @JsonProperty("ProcessInstance")
    public String processInstance;
    @JsonProperty("Documents")
    public List<Document> documents;
    @JsonProperty("TimeAttribute")
    public String timeAttribute;
    @JsonProperty("RegisterTemplateCode")
    public String registerTemplateCode;
    @JsonProperty("Message")
    private String message;
}
