package ru.usb.factorin_new_events_receiving.service.factoring.events;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.usb.factorin_new_events_receiving.configure.Configure;
import ru.usb.factorin_new_events_receiving.configure.TG;
import ru.usb.factorin_new_events_receiving.dto.EventLess;
import ru.usb.factorin_new_events_receiving.dto.Events;
import ru.usb.factorin_new_events_receiving.utils.EventsMapper;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class GetEvents {

    private final Configure configure;
    private final EventsMapper eventsMapper;


    @Autowired
    public GetEvents(Configure configure, EventsMapper eventsMapper) {
        this.configure = configure;
        this.eventsMapper = eventsMapper;
    }

    /**
     * Получение токена, true - успешный вариант, false - возникла ошибка
     *
     * @return - true - успешный вариант, false - возникла ошибка
     */
    public EventLess getEvents(String bearer, String onlyNew, int pageNumber, int pageSize, Date from, Date to, String id, String uid) {

        ResponseEntity<String> response = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(bearer);  //авторизация с токен

        String urlTemplate = UriComponentsBuilder.fromHttpUrl(configure.getEventURL())
                .queryParamIfPresent("request.onlyNew", Optional.ofNullable(onlyNew))
                .queryParam("request.pageNumber", pageNumber)
                .queryParam("request.pageSize", pageSize)
                .queryParamIfPresent("request.from", Optional.ofNullable(from))
                .queryParamIfPresent("request.to", Optional.ofNullable(to))
                .queryParamIfPresent("request.id", Optional.ofNullable(id))
                .queryParamIfPresent("request.uid", Optional.ofNullable(uid))
                .encode()
                .build()
                .toUriString();
        log.debug("{}: make URL => {}", TG.UsbLogInfo, urlTemplate);

        EventLess eventLess = new EventLess();

        try {
            response = restTemplate.exchange(urlTemplate, HttpMethod.GET, new HttpEntity<>(headers), String.class);
        } catch (HttpClientErrorException | HttpServerErrorException httpClientOrServerExc) {
            log.error("{}:!!!!!!!!!!!!!ERROR:Запрос (GET) на получение событий!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            if (HttpStatus.NOT_FOUND.equals(httpClientOrServerExc.getStatusCode())) {
                eventLess.setStatusCode(HttpStatus.NOT_FOUND);
            } else {
                eventLess.setStatusCode(httpClientOrServerExc.getStatusCode());
            }
            eventLess.setMessage(httpClientOrServerExc.getMessage());
            log.error("{}: Error :{}", TG.UsbLogError, eventLess.getMessage());
            log.error("{}: Status code={}", TG.UsbLogError, eventLess.getStatusCode());
            log.debug("{}: StackTrace :", TG.UsbLogError, httpClientOrServerExc);
            log.error("{}: Получена ошибка на запрос <uri запроса>:{}. Статус ответа: <status:>:{}. Детали ошибки:{}", TG.UsbLogError, urlTemplate, eventLess.getStatusCode(), eventLess.getMessage());
            return eventLess;
        }

        //Если Response не NUll
        if (response.getStatusCode() == HttpStatus.OK) {
            Optional<List<Events>> events = eventsMapper.mapEvents(response.getBody());
            log.debug("{}: Response:(Code:{}:Message:{})", TG.UsbLogInfo, response.getStatusCode(), response.getBody());
            events.ifPresent(eventLess::setEventsList);
        } else {
            log.error("{}: Response:(Code:{}:Message:{})", TG.UsbLogInfo, response.getStatusCode(), response.getBody());
            log.error("{}: Получена ошибка на запрос <uri запроса>:{}. Статус ответа: <status:>:{}. Детали ошибки: <детали>:{}.", TG.UsbLogError, urlTemplate, response.getStatusCode(), response);
            eventLess.setMessage(response.getBody());
        }
        eventLess.setStatusCode(response.getStatusCode());
        return eventLess;
    }

}
