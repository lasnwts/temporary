package ru.usb.factorin_new_events_receiving.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Sign {

    @JsonProperty("Uid")
    public String uid;
    @JsonProperty("FileName")
    public String fileName;
    @JsonProperty("INN")
    public String iNN;
    @JsonProperty("KPP")
    public String kPP;

}
