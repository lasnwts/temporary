package ru.usb.rtmevamebpp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtmEvamEbppApplicationTests {

	@Test
	void contextLoads() {
	}

}
