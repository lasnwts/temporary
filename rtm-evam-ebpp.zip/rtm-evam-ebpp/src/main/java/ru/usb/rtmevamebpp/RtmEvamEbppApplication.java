package ru.usb.rtmevamebpp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtmEvamEbppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtmEvamEbppApplication.class, args);
	}

}
