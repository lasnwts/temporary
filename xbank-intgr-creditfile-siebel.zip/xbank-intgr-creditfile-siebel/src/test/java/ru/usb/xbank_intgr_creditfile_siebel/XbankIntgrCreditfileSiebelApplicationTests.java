package ru.usb.xbank_intgr_creditfile_siebel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XbankIntgrCreditfileSiebelApplicationTests {

	@Test
	void contextLoads() {
	}

}
