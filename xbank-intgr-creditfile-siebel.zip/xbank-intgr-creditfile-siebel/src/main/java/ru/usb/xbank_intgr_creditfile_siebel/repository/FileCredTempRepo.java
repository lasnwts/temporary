package ru.usb.xbank_intgr_creditfile_siebel.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileTemp;

import javax.persistence.QueryHint;
import javax.transaction.Transactional;

import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface FileCredTempRepo extends JpaRepository<FileTemp, Long>{

    /**
     * Удаляем записи  таблице filecredtemp
     */
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="delete from tbank_file_credit_temp where file_guid =:guid and file_name not like :maskFile", nativeQuery = true)
    void deleteByFileGuid(String guid, String maskFile);

    /**
     * Удаляем конкурентный файл из таблицы filecredtemp
     */
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value ="delete from tbank_file_credit_temp where file_guid =:guid and file_name not like :maskFile", nativeQuery = true)
    void deleteByid(String guid, String maskFile);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT * FROM tbank_file_credit_temp where file_guid =:guid order by file_name asc")
    List<FileTemp> getTempFile(String guid);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from tbank_file_credit_temp where file_guid not in :guid and file_name like :fileName and file_busy = 1")
    int getBusy(String guid, String fileName);

}
