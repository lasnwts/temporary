package ru.usb.xbank_intgr_creditfile_siebel.service.kafka;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_creditfile_siebel.model.siebel.PackData;

@Log4j2
@Component
public class ApiKafkaMessage {

    public PackData getPack(String message) {
        PackData packData = new PackData();
        return packData;
    }
}
