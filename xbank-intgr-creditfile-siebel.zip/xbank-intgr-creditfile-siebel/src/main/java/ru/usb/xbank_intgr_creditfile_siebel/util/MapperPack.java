package ru.usb.xbank_intgr_creditfile_siebel.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_creditfile_siebel.config.LG;
import ru.usb.xbank_intgr_creditfile_siebel.model.siebel.PackData;

@Log4j2
@Component
public class MapperPack {

    ObjectMapper objectMapper = new ObjectMapper();
    /**
     * Преобразование объекта в строку JSON
     *
     * @param message объект
     * @return - строка Json
     */
    public String getJsonToStr(PackData message) {

        if (message == null) {
            log.error("{}:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR);
            log.error("{}}:На маппер поступил объект [Pack] == NULL! Класс [message] метод [getJsonToStr]", LG.USBLOGERROR);
            return "";
        }

        try {
            return objectMapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            log.error("{}::Ошибка:{} преобразования объекта [Pack]:[{}] в JSON строку!", LG.USBLOGERROR, e.getMessage(), message);
            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
            return "";
        }
    }

}
