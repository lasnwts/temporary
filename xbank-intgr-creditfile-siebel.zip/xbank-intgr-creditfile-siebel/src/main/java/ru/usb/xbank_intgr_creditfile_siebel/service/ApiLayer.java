package ru.usb.xbank_intgr_creditfile_siebel.service;

import com.sun.xml.bind.v2.runtime.reflect.Lister;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_siebel.config.Configure;
import ru.usb.xbank_intgr_creditfile_siebel.config.LG;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileTemp;
import ru.usb.xbank_intgr_creditfile_siebel.model.TBankHistoryArchives;
import ru.usb.xbank_intgr_creditfile_siebel.model.TBankHistoryFiles;
import ru.usb.xbank_intgr_creditfile_siebel.model.s3.CheckFile;
import ru.usb.xbank_intgr_creditfile_siebel.model.siebel.KafkaMessage;
import ru.usb.xbank_intgr_creditfile_siebel.model.siebel.PackData;
import ru.usb.xbank_intgr_creditfile_siebel.service.db.ApiLayerDb;
import ru.usb.xbank_intgr_creditfile_siebel.service.kafka.KafkaProducerService;
import ru.usb.xbank_intgr_creditfile_siebel.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_creditfile_siebel.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_creditfile_siebel.service.zip.ZipApi;
import ru.usb.xbank_intgr_creditfile_siebel.util.MapperMessageKafka;
import ru.usb.xbank_intgr_creditfile_siebel.util.MapperPack;
import ru.usb.xbank_intgr_creditfile_siebel.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@Log4j2
@Service
public class ApiLayer {


    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final ApiLayerS3 apiLayerS3;
    private final ZipApi zipApi;
    private final Configure configure;
    private final Support support;
    private final ApiLayerDb apiLayerDb;
    private final ServiceMailError serviceMailError;
    private final KafkaProducerService kafkaProducerService;
    private final MapperPack mapperPack;
    private final MapperMessageKafka mapperMessageKafka;

    private static final String ERROR = "ERROR"; //Константа


    @Autowired
    public ApiLayer(ApiLayerS3 apiLayerS3, ZipApi zipApi, Configure configure, Support support, ApiLayerDb apiLayerDb,
                    ServiceMailError serviceMailError, KafkaProducerService kafkaProducerService,
                    MapperPack mapperPack, MapperMessageKafka mapperMessageKafka) {
        this.apiLayerS3 = apiLayerS3;
        this.zipApi = zipApi;
        this.configure = configure;
        this.support = support;
        this.apiLayerDb = apiLayerDb;
        this.serviceMailError = serviceMailError;
        this.kafkaProducerService = kafkaProducerService;
        this.mapperPack = mapperPack;
        this.mapperMessageKafka = mapperMessageKafka;
    }

    /**
     * Обработка файла
     *
     * @param fileTemp - объект файла
     * @param bucket   - бакет
     */
    public Optional<File> processed(FileTemp fileTemp, String bucket) {
        File file;
        boolean resultKafkaSend = false;
        try {
            file = getFileFromS3(fileTemp.getFileLink(), bucket, fileTemp.getFileName());
            log.info("File {} downloaded from S3 bucket {}", fileTemp.getFileName(), bucket);
            Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
            Optional<List<Path>> pathList = unzipFile(file, path, fileTemp, bucket);
            if (pathList.isPresent()) {
                if (!checkArchive(pathList.get())) {
                    unSuccessFull(file, fileTemp, bucket, true, configure.getLetterEmptySubjectError(), configure.getLetterUnzipEmpty()
                            + "\n Имя, файла: " + file.getName() + "\n"
                            + "\n Дата:" + support.formatDateTime(new Date()) + "\n"
                            + "\n Сообщение об ошибке: После распаковки => Каталог пустой!");
                }
                log.info("File {} unzipped to {}", file.getAbsolutePath(), pathList.toString());
                pathList.get().forEach(pathAny -> {
                    File fileProcessed = new File(pathAny.toString());
                    if (fileProcessed.exists()) {
                        if (fileProcessed.isDirectory()) {
                            log.debug("Directory: {}", pathAny.toString());
                        } else {
                            log.info("{}: Поступил в обработку файл досье: {}", LG.USBLOGINFO, pathAny.toString());
                            //Заполнение TbankHistoryFiles
                            TBankHistoryFiles tBankHistoryFiles = getHistoryFiles(fileTemp, pathAny);
                            //Проверка того, что файл обработан ранее
                            if (apiLayerDb.checkFileProcessed(tBankHistoryFiles.getArchiveName(), tBankHistoryFiles.getFolderName(), tBankHistoryFiles.getFileName())) {
                                log.info("{}:Файл:{} уже обработан,в работу берем следующий.[{}]", LG.USBLOGINFO, pathAny, tBankHistoryFiles);
                                try {
                                    Files.deleteIfExists(pathAny);
                                    log.info("{}: Файл:{}, удален с локального ресурса сервиса", LG.USBLOGINFO, pathAny);
                                } catch (IOException e) {
                                    log.error("{}: Возникла ошибка при удалении файла:{}, описание:{} ", LG.USBLOGINFO, pathAny, e.getMessage());
                                }
                            } else {
                                if (!checkNumDog(pathAny.toString())) {
                                    unSuccessFull(file, fileTemp, bucket, false, configure.getLetterNumDogSubjectError(), configure.getLetterNumDogError()
                                            + "\n Имя, файла архива: " + file.getName() + "\n"
                                            + "\n Номер договора: " + tBankHistoryFiles.getFolderName() + "\n"
                                            + "\n Имя, файла: " + tBankHistoryFiles.getFileName() + "\n"
                                            + "\n Дата:" + support.formatDateTime(new Date()) + "\n"
                                            + "\n Сообщение об ошибке: Неверный номер договора!");
                                    try {
                                        saveFileToErrorS3(pathAny, bucket, fileTemp, tBankHistoryFiles);
                                    } catch (Exception e) {
                                        log.error("{}:[saveFileToErrorS3] Ошибка сохранения файла saving file to S3: {}", LG.USBLOGERROR, e.getMessage());
                                    }
                                } else {
                                    try {
                                        saveFileToS3(pathAny, bucket, fileTemp, tBankHistoryFiles);
                                    } catch (Exception e) {
                                        log.error("{}:[saveFileToS3] Ошибка сохранения файла saving file to S3: {}", LG.USBLOGERROR, e.getMessage());
                                    }
                                }
                            }
                            //Записываем TBank_History_Files, Отправляем сообщение
                            sendKafkaMessage(tBankHistoryFiles, fileTemp);
                            apiLayerDb.saveArchive(apiLayerDb.getArchive(fileTemp.getFileName()));
                        }
                    }
                });
            }
            saveTBankArchive(fileTemp.getFileName()); //Сохраняем в архив
            apiLayerDb.deleteFileId(fileTemp.getId()); //Удаляем запись

        } catch (Exception e) {
            log.error("Error processing file: {}", e.getMessage());
            return Optional.empty();
        }
        return Optional.of(file);
    }


    /**
     * Сохраняем TBANK
     *
     * @param fileArchive
     */
    public void saveTBankArchive(String fileArchive) {
        TBankHistoryArchives tBankHistoryArchives = apiLayerDb.getArchive(fileArchive);
        if (tBankHistoryArchives != null) {
            tBankHistoryArchives.setDateEnd(new Date());
            tBankHistoryArchives.setKafkaIn("1");
            //Количество договоров: . Количество файлов: . Количество исключенных файлов:
            tBankHistoryArchives.setTotalResult(getTotalResult());
            apiLayerDb.saveArchive(tBankHistoryArchives);
        }
    }

    private String getTotalResult() {
        //Количество договоров: Количество файлов: Количество исключенных файлов:
        return "Количество договоров:" + configure.getReportFolderCount() + ", Количество файлов: " + configure.getFileCount() + ". Количество исключенных файлов:" + configure;
    }


    /**
     * Отправляем сообщение в кафка
     *
     * @param tBankHistoryFiles - объект TBankHistoryFiles
     * @param fileTemp          - объект FileTemp
     */
    public void sendKafkaMessage(TBankHistoryFiles tBankHistoryFiles, FileTemp fileTemp) {

        //Создаем сообщение PAck
        PackData packData = new PackData();
        packData.setArchivename(tBankHistoryFiles.getArchiveName());
        packData.setAssetnumber(tBankHistoryFiles.getFolderName());
        packData.setFilename(tBankHistoryFiles.getFileName());
        packData.setFileext(tBankHistoryFiles.getFileExt());
        packData.setFileid(tBankHistoryFiles.getFileGuid()); //ID файла
        packData.setFilesize(tBankHistoryFiles.getFileSize());
        packData.setFilelink(tBankHistoryFiles.getFileLink());
        packData.setDoctype("Иные докум.");
        packData.setFilecomment("Мигрировано из Т-Банк");

        //Создаем полное сообщение
        KafkaMessage kafkaMessage = new KafkaMessage();
        kafkaMessage.setError("");
        kafkaMessage.setErrortext("");
        kafkaMessage.setPackID(tBankHistoryFiles.getPackID());
        kafkaMessage.setService(configure.getSystemService());
        kafkaMessage.setSystemFrom(configure.getSystemFrom());
        kafkaMessage.setSystemTo(configure.getSystemTo());
        kafkaMessage.setPack(mapperPack.getJsonToStr(packData));
        //Отправляем сообщение в кафка
        boolean kafkaResult = kafkaProducerService.sendMessage(configure.getSiebelTopic(), mapperMessageKafka.getJsonToStr(kafkaMessage));
        if (kafkaResult){
            tBankHistoryFiles.setKafkaIn("1");
        } else {
            tBankHistoryFiles.setKafkaIn("0");
        }
        tBankHistoryFiles.setDateEnd(new Date());
        //Отправляем сообщение и Сохраняем статус
        try {
            apiLayerDb.saveFileHistory(tBankHistoryFiles);
        } catch (Exception e) {
            log.error("{} Ошибка сохранения информации о файле в БД:{}, запись:[{}]", LG.USBLOGERROR, e.getMessage(), tBankHistoryFiles);
        }
    }


    /**
     * Получаем объект History файлов для записи в БД
     *
     * @param fileTemp -  объект FilTemp
     * @param pathAny  - строка с файлом
     * @return - объект TBankHistoryFiles
     */
    public TBankHistoryFiles getHistoryFiles(FileTemp fileTemp, Path pathAny) {
        TBankHistoryFiles tBankHistoryFiles = new TBankHistoryFiles();
        tBankHistoryFiles.setArchiveName(fileTemp.getFileName()); //Имя архива
        //Номер договора
        Optional<String> numDog = support.getCreditNumber(pathAny.toString());
        if (numDog.isPresent()) {
            tBankHistoryFiles.setFolderName(numDog.get());
        } else {
            tBankHistoryFiles.setFolderName("");
        }
        //Имя файла
        tBankHistoryFiles.setFileName(support.getFileName(pathAny.toString()));
        String guid = support.getUUID(support.getWrapNull(tBankHistoryFiles.getFolderName())
                + support.getWrapNull(tBankHistoryFiles.getFileName()));
        //GUID файла
        tBankHistoryFiles.setFileGuid(guid);
        //Название файла, загружаемого в Siebel CRM c добавленным GUID
        tBankHistoryFiles.setFileNameGuid(tBankHistoryFiles.getFileName() + "-" + guid);
        //Размер файла, загружаемого в Siebel CRM
        try {
            File file = new File(pathAny.toString());
            tBankHistoryFiles.setFileSize(file.length());
        } catch (Exception e) {
            log.error("{}:[TBankHistoryFiles getHistoryFiles(FileTemp fileTemp, Path pathAny)] Ошибка:{} подключения к файлу:{}, для составления данных по TBANK-ARCHIVE-FILES:Размер файла, загружаемого в Siebel CRM", LG.USBLOGERROR, e.getMessage(), pathAny.toString());
        }
        //Расширение файла, загружаемого в Siebel CRM
        tBankHistoryFiles.setFileExt(support.getExtension(pathAny.toString()));
        //Ссылка на файл в S3
        tBankHistoryFiles.setFileLink(support.getKey(pathAny, support.getFileNameWithoutExtension(fileTemp.getFileName())));
        //Уникальный идентификатор запроса. По packID будет сопоставляться ответ на запрос на стороне системы-инициатора
        tBankHistoryFiles.setPackID(guid + support.getSdfStamp());
        //Флаг доставки сообщения до Kafka
        tBankHistoryFiles.setKafkaIn("");
        //Код ошибки
        tBankHistoryFiles.setError("");
        //Текст ошибки
        tBankHistoryFiles.setErrorText("");
        //Дата создания записи
        tBankHistoryFiles.setDateStart(new Date());
        return tBankHistoryFiles;
    }


    /**
     * Проверка, что все каталоги имеют верный номер
     *
     * @param path - путь к каталогу
     * @return - true/false
     */
    public boolean checkNumDog(String path) {
        File fileProcessed = new File(path);
        if (fileProcessed.exists() && !fileProcessed.isDirectory()) {
            return support.checkIntNumDog(support.getCreditNumber(path).orElse("AAA"));
        }
        return true;
    }


    /**
     * Проверка наличия директорий и файлов в архиве
     *
     * @param pathList - пути
     * @return - true/false
     */
    public boolean checkArchive(List<Path> pathList) {
        AtomicBoolean dirExist = new AtomicBoolean(false);
        AtomicBoolean fileExist = new AtomicBoolean(false);
        AtomicInteger countDog = new AtomicInteger();
        AtomicInteger countFile = new AtomicInteger();
        pathList.forEach(path -> {
            if (path.toFile().isDirectory()) {
                dirExist.set(true);
                //Проверяем это договор?
                Optional<String> creditNumber = support.getCreditNumber(path.toString());
                if (creditNumber.isPresent() && support.checkIntNumDog(creditNumber.get())) {
                    countDog.getAndIncrement();
                }
            } else {
                fileExist.set(true);
                countFile.getAndIncrement();
            }
        });
        configure.setReportFolderCount(countDog.get());
        configure.setReportFilesCount(countFile.get());
        //нет файлов или директорий
        return dirExist.get() && fileExist.get(); //все есть
    }


    /**
     * Завершение процесса
     *
     * @param file     - файл
     * @param fileTemp - объект файла
     * @param bucket   - бакет
     * @param subject  - тема письма
     * @param body     - тело письма
     */
    public void unSuccessFull(File file, FileTemp fileTemp, String bucket, boolean deleted, String subject, String body) {
        try {
            serviceMailError.sendMailErrorSubject(subject, body); //Отправить письмо
            if (deleted) {
                apiLayerS3.deleteFileFromS3(bucket, fileTemp.getFileLink()); //Удаляем файл из бакета
                apiLayerDb.deleteFileId(fileTemp.getId()); //Удалить файл из временной директории
                Files.deleteIfExists(file.toPath()); //Удалить файл
                support.cleanTempDirectory(); //Чистка временной директории
            }
        } catch (Exception e) {
            log.error("{}:unSuccessFull: Error processing file: {}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Распаковка файла
     *
     * @param file - файл
     * @param path - путь к файлу
     * @return - список файлов
     */
    public Optional<List<Path>> unzipFile(File file, Path path, FileTemp fileTemp, String bucket) {
        try {
            Optional<List<Path>> pathList = zipApi.unzipFile(file.getAbsolutePath(), path.toString(), file.getName());
            if (pathList.isPresent()) {
                log.info("{}: File {} unzipped to {}", LG.USBLOGINFO, file.getAbsolutePath(), pathList.toString());
            } else {
                log.error("{}: File {} not unzipped. Каталог пустой!", LG.USBLOGERROR, file.getAbsolutePath());
                serviceMailError.sendMailErrorSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                        + "\n Имя файла: " + file.getName() + "\n"
                        + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                        + "\n Сообщение об ошибке: После распаковки => Каталог пустой!");
                apiLayerS3.deleteFileFromS3(bucket, fileTemp.getFileLink()); //Удаляем файл из бакета
                apiLayerDb.deleteFileId(fileTemp.getId());
                Files.deleteIfExists(file.toPath());
                support.cleanTempDirectory();
                return Optional.empty();
            }
            return pathList; //отдаем список
        } catch (Exception e) {
            log.error("{}: Error unzipping file: {}", LG.USBLOGERROR, e.getMessage());
            serviceMailError.sendMailErrorSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                    + "\n Имя файла: " + file.getName() + "\n"
                    + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                    + "\n Сообщение об ошибке: ошибка при разархивации файла");
            try {
                apiLayerS3.copyFileS3(bucket, fileTemp.getFileName(), bucket, ERROR + fileTemp.getFileName());
                log.info("{}:File:{}/{} copied to:{}/{}", LG.USBLOGINFO, bucket, fileTemp.getFileName(), bucket, ERROR + fileTemp.getFileName());
                apiLayerS3.deleteFileFromS3(bucket, fileTemp.getFileLink()); //Удаляем файл из бакета
            } catch (Exception ex) {
                log.error("{}: Error saving file:{} to S3:{}, ERROR: {}", LG.USBLOGERROR, file.getName(), bucket + ERROR, ex.getMessage());
            }
            apiLayerDb.deleteFileId(fileTemp.getId());
            try {
                Files.deleteIfExists(file.toPath());
                support.cleanTempDirectory();
            } catch (IOException ex) {
                log.error("{}: Error deleting file: {}", LG.USBLOGERROR, ex.getMessage());
            }
            return Optional.empty();
        }
    }

    /**
     * Сохранение файла в бакет
     *
     * @param path     - путь к файлу
     * @param bucket   - бакет
     * @param fileTemp - объект файла
     */
    public void saveFileToS3(Path path, String bucket, FileTemp fileTemp, TBankHistoryFiles tBankHistoryFiles) throws Exception {
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        String errorString = null;
        do {
            i++;
            try {
                if (apiLayerS3.saveFileToS3(bucket, support.getKey(path, support.getFileNameWithoutExtension(fileTemp.getFileName())), new File(path.toString()))) {
                    configure.setReportFileSuccess(configure.getReportFileSuccess() + 1); //+ 1 успешный файл
                    apiLayerDb.saveCountRows(new Date()); //Увеличиваем счетчик
                    apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
                    log.info("{}: File {} uploaded to S3 bucket {}", LG.USBLOGINFO, fileTemp.getFileName(), bucket);
                    Files.deleteIfExists(path);
                    success = true;
                } else {
                    log.error("{}: saveFileToS3 - File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, fileTemp.getFileName(), bucket);
                    //Запись в журнал
                    tBankHistoryFiles.setFileLink(ERROR + tBankHistoryFiles.getFileLink()); //Копируем в Error
                    tBankHistoryFiles.setError("1");
                    tBankHistoryFiles.setErrorText("Файл не загружен в ERROR/.Досье по кредиту не передано. возникли непредвиденные ошибки." + support.getWrapNull(errorString));
                    tBankHistoryFiles.setDateEnd(new Date()); //Дата закрытия
                    apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
                }
            } catch (Exception e) {
                log.error("{}: Ошибка возникла при попытке сохранения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд", LG.USBLOGERROR, i, timeWait / 1000);
                exception = e; //Для переноса
                errorString = e.getMessage(); //для базы данных
                log.error("{}: Error saving file to S3: {}", LG.USBLOGERROR, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}: Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        /**
         * S3 (Tbankfiles) недоступен
         * Файл: rup_o_dos20241010125135.zip
         * Кредит: 00037021756592
         * Имя файла: Выписка из ПФР.pdf
         * Микросервис: Xbank-intgr-creditfile-Siebel
         * Статус: 500
         * Описание ошибки: Internal Server Error
         */

        if (!success) {
            //Запись в журнал
            tBankHistoryFiles.setFileLink(ERROR + tBankHistoryFiles.getFileLink()); //Копируем в Error
            tBankHistoryFiles.setError("1");
            tBankHistoryFiles.setErrorText("Файл не загружен в S3.Досье по кредиту не передано. Ошибка: " + support.getWrapNull(errorString));
            tBankHistoryFiles.setDateEnd(new Date()); //Дата закрытия
            apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
            //Отправка писем
            configure.setReportFileError(configure.getReportFileError() + 1); //Файл не передан
            log.error("{}: File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, fileTemp.getFileName(), bucket);
            if (apiLayerS3.getS3StatusCode(exception.getMessage()).is4xxClientError()) {
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(fileTemp.getFileName())
                        + "\n\r" + "Кредит:" + support.getWrapNull(support.getCreditName(path.toString()))
                        + "\n\r" + "Имя файла:" + support.getWrapNull(support.getFileNameWithoutExtension(path.toString()))
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(exception.getMessage()))) +
                        "\n\r" + "Описание:" + support.getWrapNull(exception.getMessage()));
            } else {
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(fileTemp.getFileName())
                        + "\n\r" + "Кредит:" + support.getWrapNull(support.getCreditName(path.toString()))
                        + "\n\r" + "Имя файла:" + support.getWrapNull(support.getFileNameWithoutExtension(path.toString()))
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(exception.getMessage()))) +
                        "\n\r" + "Описание:" + support.getWrapNull(exception.getMessage()));
            }
        }
    }


    /**
     * Получение файла из бакета
     *
     * @param fileLink   - ссылка на файл
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     * @return - файл
     */
    public File getFileFromS3(String fileLink, String bucketName, String fileName) throws Exception {
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        CheckFile checkFile = new CheckFile();
        int i = 0; //Счетчик попыток
        do {
            i++;
            try {
                checkFile.setFile(apiLayerS3.downloadFileFromS3(fileLink, bucketName, fileName));
                checkFile.setErrorCode(HttpStatus.OK);
                checkFile.setMessage("File downloaded successfully");
                checkFile.setSuccess(true);
            } catch (Exception e) {
                log.error("{}: Error downloading file from S3: {}", LG.USBLOGERROR, e.getMessage());
                checkFile.setSuccess(false);
                checkFile.setErrorCode(apiLayerS3.getS3StatusCode(e.getMessage()));
                checkFile.setMessage(e.getMessage());
                checkFile.setFile(null);
                checkFile.setExcept(e);
                log.error("{}: Ошибка получения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд", LG.USBLOGERROR, i, timeWait / 1000);
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}: Ошибка возникла во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!checkFile.isSuccess() && i < 10);

        if (checkFile.isSuccess()) {
            return checkFile.getFile();
        } else {
            if (checkFile.getErrorCode().is4xxClientError()) {
                log.error("{} Ошибка получения файла.[is4xxClientError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            if (checkFile.getErrorCode().is5xxServerError()) {
                log.error("{} Ошибка получения файла.[is5xxServerError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            if (checkFile.getErrorCode().isError()) {
                log.error("{} Ошибка получения файла.[isError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            throw checkFile.getExcept();
        }
    }


    /**
     * Сохранение файла в бакет
     *
     * @param path     - путь к файлу
     * @param bucket   - бакет
     * @param fileTemp - объект файла
     */
    public void saveFileToErrorS3(Path path, String bucket, FileTemp fileTemp, TBankHistoryFiles tBankHistoryFiles) throws Exception {

        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        String errorString = null;
        do {
            i++;
            try {
                if (apiLayerS3.saveFileToErrorS3(bucket, support.getKey(path, support.getFileNameWithoutExtension(fileTemp.getFileName())), new File(path.toString()))) {
                    log.info("{}: File {} uploaded to ERROR S3 bucket {}", LG.USBLOGINFO, fileTemp.getFileName(), bucket);
                    Files.deleteIfExists(path);
                    tBankHistoryFiles.setFileLink(ERROR + tBankHistoryFiles.getFileLink()); //Копируем в Error
                    tBankHistoryFiles.setError("1");
                    tBankHistoryFiles.setErrorText("Номер договора не соответствует маске.Досье по кредиту не передано");
                    tBankHistoryFiles.setDateEnd(new Date()); //Дата закрытия
                    apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
                    success = true;
                } else {
                    log.error("{}: saveFileToS3 - File {} not uploaded to ERROR S3 bucket {}", LG.USBLOGERROR, fileTemp.getFileName(), bucket);
                    tBankHistoryFiles.setFileLink(ERROR + tBankHistoryFiles.getFileLink()); //Копируем в Error
                    tBankHistoryFiles.setError("1");
                    tBankHistoryFiles.setErrorText("Файл не загружен в ERROR/. Возникли ошибки. Досье по кредиту не передано");
                    tBankHistoryFiles.setDateEnd(new Date()); //Дата закрытия
                    apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
                }
            } catch (Exception e) {
                log.error("{}: [ERROR S3 ] Ошибка возникла при попытке сохранения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд", LG.USBLOGERROR, i, timeWait / 1000);
                exception = e; //Для переноса
                errorString = e.getMessage(); //Для базы данных
                log.error("{}:[ERROR S3 ] Error saving file to S3: {}", LG.USBLOGERROR, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}:[ERROR S3 ] Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        configure.setReportFileError(configure.getReportFileError() + 1);
        if (!success) {
            //Запись в журнал
            tBankHistoryFiles.setFileLink("ERROR/" + tBankHistoryFiles.getFileLink()); //Копируем в Error
            tBankHistoryFiles.setError("1");
            tBankHistoryFiles.setErrorText("Файл не загружен в ERROR/.Досье по кредиту не передано.Ошибка:" + support.getWrapNull(errorString));
            tBankHistoryFiles.setDateEnd(new Date()); //Дата закрытия
            apiLayerDb.saveFileHistory(tBankHistoryFiles); //Сохраняем
            //Отправка письма
            log.error("{}: [ERROR S3] File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, fileTemp.getFileName(), bucket);
            if (apiLayerS3.getS3StatusCode(exception.getMessage()).is4xxClientError()) {
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(fileTemp.getFileName())
                        + "\n\r" + "Кредит:" + support.getWrapNull(support.getCreditName(path.toString()))
                        + "\n\r" + "Имя файла:" + support.getWrapNull(support.getFileNameWithoutExtension(path.toString()))
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(exception.getMessage()))) +
                        "\n\r" + "Описание:(передача в ERROR/)" + support.getWrapNull(exception.getMessage()));
            } else {
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(fileTemp.getFileName())
                        + "\n\r" + "Кредит:" + support.getWrapNull(support.getCreditName(path.toString()))
                        + "\n\r" + "Имя файла:" + support.getWrapNull(support.getFileNameWithoutExtension(path.toString()))
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(exception.getMessage()))) +
                        "\n\r" + "Описание:(передача в ERROR/)" + support.getWrapNull(exception.getMessage()));
            }
        }
    }
}
