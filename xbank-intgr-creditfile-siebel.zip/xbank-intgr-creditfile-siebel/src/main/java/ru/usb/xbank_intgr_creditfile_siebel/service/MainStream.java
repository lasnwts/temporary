package ru.usb.xbank_intgr_creditfile_siebel.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import ru.usb.xbank_intgr_creditfile_siebel.config.Configure;
import ru.usb.xbank_intgr_creditfile_siebel.config.LG;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileTemp;
import ru.usb.xbank_intgr_creditfile_siebel.service.db.ApiLayerDb;
import ru.usb.xbank_intgr_creditfile_siebel.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_creditfile_siebel.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Log4j2
@Service
public class MainStream {

    private final ApiLayerS3 apiLayerS3;
    private final ApiLayerDb apiLayerDb;
    private final ApiLayer apiLayer;
    private final Configure configure;
    private final Support support;

    @Autowired
    public MainStream(ApiLayerS3 apiLayerS3, ApiLayerDb apiLayerDb, ApiLayer apiLayer, Configure configure, Support support) {
        this.apiLayerS3 = apiLayerS3;
        this.apiLayerDb = apiLayerDb;
        this.apiLayer = apiLayer;
        this.configure = configure;
        this.support = support;
    }

    /**
     * Запуск основного потока
     */
    public void run() {
        log.info("Start MainStream");
        //Проверяем количество записей по переданным файлам за сегодня

        //Реализовать на уровне микросервиса счетчик количества переданных файлов в день (сообщений в Kafka).
        // Количество переданных файлов в день должно быть настройкой микросервиса. По умолчанию 125 тыс. Файлов в день.
        // При достижении порога количества обработки файлов, обработать до конца архив и завершить работу микросервиса.
        configure.setSyncFileCount(apiLayerDb.getCountRows(new Date())); //Получаем число файлов
        if (configure.getFileCountPerDay() > configure.getSyncFileCount()) {
            Optional<List<String>> linkList = apiLayerS3.getListFiles(configure.getS3BucketBase()); //Получаем список файлов
            if (linkList.isPresent()) {
                linkList.get().forEach(log::info); //для смены на debug
                matchFile(linkList.get());
            }
        } else {
            log.info("{}: Количество обработанных файлов за день:{} больше заданного максимального порога:{}. Обработка прекращена. Если необходимо продолжать обработку, то увеличите лимит в application.properties:[file.count]", LG.USBLOGINFO, configure.getFileCountPerDay(), configure.getFileCountPerDay());
        }
    }

    /**
     * Обработка файлов
     *
     * @param list - список файлов
     */
    public void matchFile(List<String> list) {
        //1 Генерируем GUID и запоминаем, его с ним будем работать
        configure.setGuid(UUID.randomUUID().toString());
        //Внести записи во временную таблицу
        list.forEach(link -> {
            FileTemp fileTemp = new FileTemp(); //Имя файла, Guid, дата, каталог, полная ссылка
            fileTemp.setFileName(support.getFileName(link));//Имя файла
            fileTemp.setFileGuid(configure.getGuid()); //GUID
            fileTemp.setDate(support.convertDateToSqlDate(new Date())); //Дата
            fileTemp.setFileDir(support.getDirFromFileName(link)); //Каталог
            fileTemp.setFileLink(link); //Полная ссылка
            fileTemp.setBusy(0); //Файл свободен
            apiLayerDb.saveFileCredTemp(fileTemp);
        });

        //Очистим таблицу от старых записей
        apiLayerDb.deleteFileCredTemp(configure.getGuid(), configure.getS3MaskFile() + "%");
        log.info("{}:Очистка таблицы от старых записей завершена, GUID:{}", LG.USBLOGINFO, configure.getGuid());
        //Получаем список файлов
        List<FileTemp> listFile = apiLayerDb.getListFile(configure.getGuid());
        listFile.forEach(log::info);
        log.info("{}:Количество файлов в списке:{}", LG.USBLOGINFO, listFile.size());

        //Перебираем файлы архива
        listFile.forEach(fileTemp -> {
            log.info("{}:Обработка файла:{}", LG.USBLOGINFO, fileTemp.getFileName());
            if (apiLayerDb.getCountRows(new Date()) > configure.getFileCountPerDay()) {
                log.info("{}:[matchFile] Количество обработанных файлов за день:{} больше заданного максимального порога:{}. Обработка прекращена. Если необходимо продолжать обработку, то увеличите лимит в application.properties:[file.count]", LG.USBLOGINFO, configure.getFileCountPerDay(), configure.getFileCountPerDay());
                return;
            }

            fileTemp.setBusy(1); //Берем в работу
            //Обнуляем счетчики
            configure.setReportFolderCount(0);
            configure.setReportFilesCount(0);
            configure.setReportFileSuccess(0);
            configure.setReportFileError(0);
            //
            apiLayerDb.saveFileCredTemp(fileTemp); //Сохраняем
            if (apiLayerDb.getBusyFile(fileTemp.getFileGuid(), fileTemp.getFileName())) {
                log.info("{}:Файл:{} уже обработан, GUID:{}, в работу берем следующий", LG.USBLOGINFO, fileTemp.getFileName(), fileTemp.getFileGuid());
                apiLayerDb.deleteFileId(fileTemp.getId()); //Удаляем
            } else {
                if (apiLayerDb.checkArchiveProcessed(fileTemp.getFileName()) > 0) {
                    log.info("{}:Архив:{} уже обработан, в работу берем следующий", LG.USBLOGINFO, fileTemp.getFileName());
                } else {
                    //Обрабатываем файл
                    Optional<File> file = apiLayer.processed(fileTemp, configure.getS3BucketBase()); //Скачиваем файл во внутреннюю директорию
                    if (file.isPresent()) {
                        log.info("{}:Файл:{} обработан", LG.USBLOGINFO, file.get().getAbsolutePath());
                        try {
                            if (FileSystemUtils.deleteRecursively(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                                    FileSystems.getDefault().getSeparator() + configure.getNetFileShare() +
                                    FileSystems.getDefault().getSeparator()
                                    + support.getFileNameWithoutExtension(file.get().getName())))) {
                                log.info("{}:Каталог:{} удален", LG.USBLOGINFO, new FileSystemResource("").getFile().getAbsolutePath() +
                                        FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
                            } else {
                                log.info("{}:Каталог:{} не удален, возникла проблема.", LG.USBLOGINFO, new FileSystemResource("").getFile().getAbsolutePath() +
                                        FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
                            }
                            Files.deleteIfExists(file.get().toPath());
                            log.info("{}:Файл:{} удален", LG.USBLOGINFO, file.get().getAbsolutePath());
                        } catch (IOException e) {
                            log.error("{}:Ошибка удаления файла:{} - {}", LG.USBLOGINFO, file.get().getAbsolutePath(), e.getMessage());
                        }
                    }
                }
            }
            log.info("{}=============================================================++++++++++++++++++++++++++++++++++++++++++++++++======", LG.USBLOGINFO);
            log.info("{}: Файл архива:{}, Количество договоров:{}, Общее количество файлов:{}, Число успешно обработанных:{}, Число файлов с ошибками обработки:{}",
                    LG.USBLOGINFO, fileTemp.getFileName(), configure.getReportFolderCount(), configure.getReportFilesCount(), configure.getReportFileSuccess(), configure.getReportFileError());
            log.info("{}=============================================================------------------------------------------------======", LG.USBLOGINFO);
        });

        log.info("{}###########################################################################################################################", LG.USBLOGINFO);
        log.info("{}:  Обработка файлов в количестве:{} - завершена, GUID:{}", LG.USBLOGINFO, listFile.size(), configure.getGuid());
        log.info("{}###########################################################################################################################.", LG.USBLOGINFO);
    }
}
