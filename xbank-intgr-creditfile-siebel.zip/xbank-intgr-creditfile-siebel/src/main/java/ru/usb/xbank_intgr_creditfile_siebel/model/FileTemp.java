package ru.usb.xbank_intgr_creditfile_siebel.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

/**
 * Таблица для хранения временных файлов
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_FILE_CREDIT_TEMP")
public class FileTemp {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "FILE_NAME")//имя файла, пример: rup_o_dosdddddddddddddd.zip
    private String fileName;

    @Column(name = "FILE_GUID")//ссылка на то, что файл принадлежит к данному потоку
    private String  fileGuid;

    @Column(name = "FILE_DATA")//дата вставки, обновления
    private Date date;

    @Column(name = "FILE_DIR")//Директория файла, пример 000125612560121
    private String fileDir;

    @Column(name = "FILE_LINK")//Полный LINK, пример 000125612560121/rup_o_dosdddddddddddddd.zip
    private String fileLink;

    @Column(name = "FILE_BUSY")//занят ли счетчик
    private int busy;

}
