package ru.usb.xbank_intgr_creditfile_siebel.model.siebel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaMessage {

    @JsonProperty("system_from")
    private String systemFrom;

    @JsonProperty("system_to")
    private String systemTo;

    @JsonProperty("service")
    private String service;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    private String errortext;

}
