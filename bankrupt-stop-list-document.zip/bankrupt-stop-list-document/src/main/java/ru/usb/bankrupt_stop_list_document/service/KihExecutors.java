package ru.usb.bankrupt_stop_list_document.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.bankrupt_stop_list_document.configure.Configure;
import ru.usb.bankrupt_stop_list_document.configure.TG;
import ru.usb.bankrupt_stop_list_document.model.kih.KihView;
import ru.usb.bankrupt_stop_list_document.repository.cb.CreSlCompanyRepo;


import java.text.SimpleDateFormat;
import java.util.concurrent.CopyOnWriteArrayList;

@Log4j2
@Service
public class KihExecutors {

    private final CreSlCompanyRepo slCompanyRepo;
    private final Configure configure;

    @Autowired
    public KihExecutors(CreSlCompanyRepo slCompanyRepo, Configure configure) {
        this.slCompanyRepo = slCompanyRepo;
        this.configure = configure;
    }

    public void getExecutor(KihView kihView, CopyOnWriteArrayList<KihView> kihViewList ){
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        log.debug("{}:Запуск потока id={}", TG.UsbLogInfo, Thread.currentThread().getId());
        try{
            if (slCompanyRepo.getSearch(kihView.getInn(), sdf.format(kihView.getAddDate())).isEmpty()) {
                log.debug("{} Запись:{} отсутствует в БД ЦХД", TG.UsbLogInfo, kihView);
                kihViewList.add(kihView);
                configure.addInRecordSync();
            } else {
                log.debug("{} Запись:{} присутствует в БД ЦХД", TG.UsbLogInfo, kihView);
            }
        } catch (Exception e){
            log.error("{}: Произошла ошибка в потоке (включаемых компаний) getExecutor(KihView kihView, CopyOnWriteArrayList<KihView> kihViewList )", TG.UsbLogError);
            log.error("{}: описание ошибки:{})", TG.UsbLogError, e.getMessage());
            configure.setMistakeSync(true);
        }

        //Подвал завершения потока
        log.debug("{}:Поток завершен id={}", TG.UsbLogInfo, Thread.currentThread().getId());
        //configure.decThreadSync();
        //log.debug("{}:::Длина очереди задач={}", TG.UsbLogInfo, configure.getThreadSync());

    }
}
