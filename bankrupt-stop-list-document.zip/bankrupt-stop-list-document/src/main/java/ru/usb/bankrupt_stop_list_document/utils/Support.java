package ru.usb.bankrupt_stop_list_document.utils;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class Support {
    DateTimeFormatter formatterNumInsert = DateTimeFormatter.ofPattern("yyyyMMdd");


    /**
     * Получаем номер insert
     * @return - строка yyyymmdd
     */
    public int getNumInsert(){
        return Integer.parseInt(formatterNumInsert.format(LocalDateTime.now()));
    }


}
