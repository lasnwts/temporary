package ru.usb.bankrupt_stop_list_document.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.bankrupt_stop_list_document.configure.TG;
import ru.usb.bankrupt_stop_list_document.service.FlowScheduler;
import ru.usb.bankrupt_stop_list_document.utils.ApiLyaer;


@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с потоками из БК в ЕФС. ", description = "<Включение, отключение сервиса>")
public class ApiController {

    private final ApiLyaer apiLyaer;
    private final FlowScheduler flowScheduler;

    @Autowired
    public ApiController(ApiLyaer apiLyaer, FlowScheduler flowScheduler) {
        this.apiLyaer = apiLyaer;
        this.flowScheduler = flowScheduler;
    }

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);


    @GetMapping("/count")
    @Operation(summary = "Запрос на получение количество записей во всех базах данных.")
    public ResponseEntity<String> getCount() {
        logger.info("{}: Получен запрос на получение количество записей во всех базах данных.", TG.UsbLogInfo);
        return ResponseEntity.status(HttpStatus.OK).body(apiLyaer.getCount());
    }

    @DeleteMapping("/delete/{numInsert}")
    @Operation(summary = "Запрос на удаление из CRE записей с определённым numInsert.")
    public ResponseEntity<String> change(@Parameter(description = " Введите numInsert")
                                         @PathVariable(required = true) int numInsert) {
        logger.info("{}: Получен запрос на удаление записей из CRE numInsert={}", TG.UsbLogInfo, numInsert);
        apiLyaer.deleteNumInsert(numInsert);
        return ResponseEntity.status(HttpStatus.OK).body("Получен запрос на удаление записей из CRE");
    }

    @GetMapping("/start")
    @Operation(summary = "Запрос на запуск потоков выгрузки.")
    public ResponseEntity<String> startFlow() {
        logger.info("{}: Запрос на запуск потоков выгрузки.", TG.UsbLogInfo);
        apiLyaer.setWorkTime(true);
        flowScheduler.cronSchedulerExcluded();
        return ResponseEntity.status(HttpStatus.OK).body("Выполняем запуск потоков");
    }

    @GetMapping("/status")
    @Operation(summary = "Запрос на получение состояния потоков выгрузки.")
    public ResponseEntity<String> statusFlow() {
        logger.info("{}: Запрос на получение состояния потоков выгрузки.", TG.UsbLogInfo);
        return ResponseEntity.status(HttpStatus.OK).body(apiLyaer.getStatus());
    }


    @GetMapping("/break")
    @Operation(summary = "Принудительно прервать процесс выгрузки.")
    public ResponseEntity<String> breakFlow() {
        logger.info("{}: Принудительно прервать процесс выгрузки..", TG.UsbLogInfo);
        return ResponseEntity.status(HttpStatus.OK).body(apiLyaer.breakProcess());
    }


}
