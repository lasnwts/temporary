package ru.usb.bankrupt_stop_list_document.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Класс для выполнения процедур в базе CRE
 */
@Service
public class ProcedureService {


    @Autowired
    @Qualifier("creDataSource")
    DataSource creDataSource;

    private static final Logger log = LoggerFactory.getLogger(ProcedureService.class);

    /**
     *  Метод используется для вызова процедуры CRE вставки данных.
     *  В методе устанавливаются параметры процедуры: название схемы, каталог, название функции.
     *  Процедура вызывается с названием таблицы.
     *
     * @param stringInsert название процесса
     */
    public void insertProcedureCre(String stringInsert) {
        try {
            DateTimeFormatter formatterNumInsert = DateTimeFormatter.ofPattern("yyyyMMdd");

            int numInsert = Integer.parseInt(formatterNumInsert.format(LocalDateTime.now()));
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(creDataSource)
                    .withProcedureName("PROC_STOP_LIST");
            SqlParameterSource paramMap = new MapSqlParameterSource().addValue("NUM_INSERT", numInsert, Types.INTEGER)
                    .addValue("PARAM_INSERT", stringInsert, Types.VARCHAR)
                    .addValue("NUM_OUT", Types.INTEGER);

            jdbcCall.execute(paramMap);
            log.info("Insert procedure from CRE finished successfully");
        } catch (Exception exception) {
            log.error("Exception insert procedure from CRE", exception);
            throw exception;
        }
    }

}
