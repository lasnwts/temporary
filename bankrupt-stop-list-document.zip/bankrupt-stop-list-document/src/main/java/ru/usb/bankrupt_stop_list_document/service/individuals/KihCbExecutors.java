package ru.usb.bankrupt_stop_list_document.service.individuals;

public class KihCbExecutors {
}
