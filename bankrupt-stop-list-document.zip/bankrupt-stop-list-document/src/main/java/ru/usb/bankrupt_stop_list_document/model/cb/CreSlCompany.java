package ru.usb.bankrupt_stop_list_document.model.cb;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "cre_sl_company")
public class CreSlCompany {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "INN")
    private String inn;

//    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "VALID_FROM")
    private Timestamp validFrom;

    @Column(name = "TYPE")
    private String type;

    @Column(name ="NAME_FULL")
    private String nameFull;

    @Column(name ="NAME_SHORT")
    private String nameShort;

//    @Column(name ="SOURCE")
//    private String source;
//
//    @Column(name ="REASON")
//    private String reason;
//
//    @Temporal(TemporalType.TIMESTAMP)
//    @Column(name = "VALID_TILL")
//    private Date validTill;

//SELECT distinct ID , INN ,VALID_FROM , TYPE , NAME_FULL , NAME_SHORT FROM cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss') order by INN
}
