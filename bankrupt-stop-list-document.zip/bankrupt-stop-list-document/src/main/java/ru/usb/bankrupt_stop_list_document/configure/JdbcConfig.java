package ru.usb.bankrupt_stop_list_document.configure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.util.Objects;

/**
 * Класс конфигурации для создания DataSource, которые используются для обращения к базе данных.
 * В данном классе устанавливаются параметры для подключения, взятые с application.properties
 */
@Configuration
public class JdbcConfig {

    private Environment env;

    @Autowired
    public JdbcConfig(Environment env) {
        this.env = env;
    }

    @Bean(name = "creDataSource")
    public DataSource creDataSource() {
        DriverManagerDataSource datasource = new DriverManagerDataSource();
        datasource.setDriverClassName(Objects.requireNonNull(env.getProperty("CRE.driverClassName")));
        datasource.setUrl(env.getProperty("CRE.jdbcUrl"));
        datasource.setUsername(env.getProperty("CRE.username"));
        datasource.setPassword(env.getProperty("CRE.password"));
        return datasource;
    }
}
