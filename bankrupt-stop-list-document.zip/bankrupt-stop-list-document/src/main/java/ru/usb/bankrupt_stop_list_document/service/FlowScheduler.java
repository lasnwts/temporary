package ru.usb.bankrupt_stop_list_document.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.bankrupt_stop_list_document.configure.Configure;
import ru.usb.bankrupt_stop_list_document.configure.TG;
import ru.usb.bankrupt_stop_list_document.service.individuals.FlowCbKih;
import ru.usb.bankrupt_stop_list_document.service.individuals.FlowKihCb;
import ru.usb.bankrupt_stop_list_document.utils.ApiLyaer;


import java.util.Date;

@Component
@EnableScheduling
public class FlowScheduler {

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    private final FlowCbKih flowCbKih;
    private final FlowKihCb flowKihCb; ;
    private final Configure configure;
    private final ApiLyaer apiLyaer;

    @Autowired
    public FlowScheduler(FlowCbKih flowCbKih, FlowKihCb flowKihCb, Configure configure, ApiLyaer apiLyaer) {
        this.flowCbKih = flowCbKih;
        this.flowKihCb = flowKihCb;
        this.configure = configure;
        this.apiLyaer = apiLyaer;
    }

    /**
     * Scheduler flow.startFlowCompany
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void cronSchedulerExcluded() {
        //Проверка того, что время наступило
        if (apiLyaer.getWorkTime()) {
            apiLyaer.checkReadyChd(); //Проверяем готовность ЦХД
            if (apiLyaer.getChdReady() && !apiLyaer.getWorkFlow()) {

                apiLyaer.setWorkTime(false); //выгрузили один раз и хватит

                apiLyaer.setWorkFlow(true); //выгрузка началась

                logger.info("{} Сработал таймер на выгрузку потоков {}.", TG.UsbLogInfo, new Date());
                logger.info("{} Выгружаем поток [flowExcludedCompany.startFlowCompany]", TG.UsbLogInfo);
                configure.setMistakeSync(false); //Устанавливаем, что ошибки нет
                configure.setExcludedReadySync(false); //Готовность потока 1 = нет
                configure.setIncludedReadySync(false); //Готовность потока 2 = нет
                flowCbKih.startFlow();
                logger.info("{} Работа flowExcludeCompany.startFlowCompany завершена. {} ", TG.UsbLogInfo, new Date());
                logger.info("---");
                logger.info("{} Выгружаем поток [flowIncludedCompany.startFlowCompany],  {} ", TG.UsbLogInfo, new Date());
                flowKihCb.startFlowCompany();
                logger.info("{} Работа flowIncludedCompany.startFlowCompany завершена. {} ", TG.UsbLogInfo, new Date());

                apiLyaer.setWorkFlow(false); //Выгрузка завершена
                apiLyaer.setChdReady(false); //готовность ставим в false
            }
        }
    }

    @Scheduled(cron = "${cron-start}")
    public void startScheduler() {
        logger.info("{} cron-start. Время работы наступило.", TG.UsbLogInfo);
        apiLyaer.setWorkFlow(false); //Выгрузка не должна вестись!
        apiLyaer.setChdReady(false); //готовность ставим в false
        apiLyaer.setWorkTime(true); //Наступило время работы
    }

    @Scheduled(cron = "${cron-stop}")
    public void stopScheduler() {
        logger.info("{} cron-stop. Время работы завершилось", TG.UsbLogInfo);
        apiLyaer.setWorkTime(false); //Время работы окончилось
        checkProcessed();
    }

    //Проверяем, что все процессы корректно завершены
    private void checkProcessed() {
        if (apiLyaer.getWorkFlow()) {
            logger.error("{} Внимание, процесс должен был уже завершится, - однако стоит признак, что процесс в работе.", TG.UsbLogError);
        }
        apiLyaer.setWorkFlow(false);
    }

}
