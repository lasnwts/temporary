package ru.usb.bankrupt_stop_list_document.service.individuals;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.bankrupt_stop_list_document.configure.Configure;
import ru.usb.bankrupt_stop_list_document.configure.TG;
import ru.usb.bankrupt_stop_list_document.model.cb.CreSlCompany;
import ru.usb.bankrupt_stop_list_document.repository.cb.CreSlCompanyRepo;
import ru.usb.bankrupt_stop_list_document.service.DeleteRecord;
import ru.usb.bankrupt_stop_list_document.service.KihExecutors;
import ru.usb.bankrupt_stop_list_document.service.ProcedureService;
import ru.usb.bankrupt_stop_list_document.service.mail.ServiceMailError;
import ru.usb.bankrupt_stop_list_document.utils.Support;

import javax.persistence.EntityManager;
import java.sql.SQLException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Log4j2
@Service
public class FlowCbKih {

    private final EntityManager entityManager;
    private final CreSlCompanyRepo creSlCompanyRepo;
    private final Support su;
    private final KihExecutors executors;
    private final Configure configure;
    private final SaveIndividualsExcluded saveIndividualsExcluded;
    private final DeleteRecord deleteRecord;
    private final ProcedureService procedureService;

    private final ServiceMailError serviceMailError;

    @Autowired
    public FlowCbKih(EntityManager entityManager, CreSlCompanyRepo creSlCompanyRepo, Support su,
                              KihExecutors executors, Configure configure, SaveIndividualsExcluded saveIndividualsExcluded,
                              DeleteRecord deleteRecord, ProcedureService procedureService,
                              ServiceMailError serviceMailError) {
        this.entityManager = entityManager;
        this.creSlCompanyRepo = creSlCompanyRepo;
        this.su = su;
        this.executors = executors;
        this.configure = configure;
        this.saveIndividualsExcluded = saveIndividualsExcluded;
        this.deleteRecord = deleteRecord;
        this.procedureService = procedureService;
        this.serviceMailError = serviceMailError;
    }

    @Transactional(value = "cbTransactionManager", readOnly = true)
    public void startFlow() {

        //Установка номера Insert
        configure.setNumInsert(su.getNumInsert());

        //Получаем список записей из базы
        Stream<CreSlCompany> fTableStream = null;
        CopyOnWriteArrayList<CreSlCompany> creSlCompanyList = new CopyOnWriteArrayList<>();
        AtomicInteger lineCount = new AtomicInteger(0);

        try {
            System.gc();
            int recordCount = creSlCompanyRepo.getCount();
            log.info("{} Число записей в таблице: [cre_sl_company]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                log.info("{} Поскольку число записей в таблице: [cre_sl_company]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return;
            }
            fTableStream = creSlCompanyRepo.getStreamAll();
            if (!checkStream(fTableStream)) {
                log.error("{} fTableStream = creSlCompanyRepo.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return;
            }

            configure.setLineCounterExcludedSync(0);
            configure.setThreadSync(0);
            configure.setProcessedExRecord(0); //общее число записей обработанных
            configure.setAddExRecord(0); //число добавленных в CRE
            //Проверяем если есть ошибка выходим
            if (configure.getMistakeSync()) {
                log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                return;
            }
            //############################################################################################################################
            log.info("{}: Запускаем процесс обработки исключаемых компаний [FlowExcludeCompany]", TG.UsbLogInfo);
            fTableStream.forEach(fTable -> {

                //Проверяем если есть ошибка выходим
                if (configure.getMistakeSync()) {
                    log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                    throw new RuntimeException("Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.");
                }

                lineCount.getAndIncrement(); //Подсчитываем число записей в файле
                configure.setProcessedExRecord(lineCount.get());
                log.debug("line count={}",lineCount.get());
                log.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);

                executors.getTask(fTable, creSlCompanyList);
                entityManager.detach(fTable); //Очищаем

                if (configure.getThreadSync() >= 2000) {

                    while (configure.getThreadSync() != 0) {
                        try {
                            Thread.sleep(1000);
                            log.debug("wait=Длина  очереди:{}",configure.getThreadSync());
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    if (!creSlCompanyList.isEmpty()) {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        try {
                            saveIndividualsExcluded.save(creSlCompanyList, configure.getNumInsert());
                            creSlCompanyList.clear();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }


            });
            while (configure.getThreadSync() > 0) {
                Thread.sleep(100);
            }
            if (!creSlCompanyList.isEmpty()) {
                saveIndividualsExcluded.save(creSlCompanyList, configure.getNumInsert());
                creSlCompanyList.clear();
            }
            System.gc();
            //############################################################################################################################
            log.info("{}:обработано записей из CreB count={}", TG.UsbLogInfo, lineCount.get());
            log.info("Длина очереди задач:{}", configure.getThreadSync());
            log.info("{}: Останавливаем процесс обработки исключаемых компаний [FlowExcludeCompany]", TG.UsbLogInfo);
            configure.setExcludedReadySync(true);
        } catch (Exception e) {
            configure.setMistakeSync(true); //Устанавливаем, наличие ошибки
            log.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            log.error("{}:Произошла ошибка при работе потока чтения данных из таблицы [cre_sl_company]:{}", TG.UsbLogError, e.getMessage());
            log.error("{}:Удаляем из таблицы CRE =[SL_COMPANY_TO_INSERT] все записи с NUM_INSERT", TG.UsbLogError);
            log.debug("{}:!PrintStackTrace:", TG.UsbLogError, e);
            serviceMailError.sendMailErrorSubject("FSD_стоп_листы_выгрузка",
                    "Возможно возникла какая то проблема:\n\rОписание::"+ e.getMessage());
            //Удаляем записи
            deleteRecord.deleteProcedure(configure.getNumInsert());
        } finally {
            if (fTableStream != null) {
                fTableStream.close();
            }
        }
        log.info("{}:Закончен процесс исключения компаний. Внесено: {}, всего обработано:{} записей.", TG.UsbLogInfo, configure.getAddExRecord(), configure.getProcessedExRecord());
        //Все хорошо, проверяем готовность потоков
        if (!configure.getMistakeSync() && configure.getIncludedReadySync()) {
            //дергаем процедуру
            log.info("{}: Запускаем процедуру.", TG.UsbLogInfo);
            //procedureService.insertProcedureCre("COMPANY");
        }
    }


    /**
     * Проверка, что поток не NULL
     *
     * @param fTableStream - поток
     * @return - if exist = true
     */
    public boolean checkStream(Stream<CreSlCompany> fTableStream) {
        if (fTableStream == null) {
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            log.error("!!!!!!!!!!!!!  Stream<CreSlCompany>                               !!!!!!!!!!");
            log.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }

}
