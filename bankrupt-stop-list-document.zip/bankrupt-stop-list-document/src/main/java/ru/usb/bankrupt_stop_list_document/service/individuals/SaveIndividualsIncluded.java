package ru.usb.bankrupt_stop_list_document.service.individuals;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.bankrupt_stop_list_document.configure.JdbcConfig;
import ru.usb.bankrupt_stop_list_document.model.kih.KihView;


import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Log4j2
@Service
public class SaveIndividualsIncluded {

    DateTimeFormatter ldf = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    @Autowired
    JdbcConfig jdbcConfig;

    private static final String INSERT_TO_CRE = "INSERT INTO SL_COMPANY_TO_INSERT (SOURCE , REASON , VALID_FROM , VALID_TILL ,NOTE, EXCLUDE , LAST_UPDATE , TYPE , INN , KPP , OGRN , NAME_FULL , NAME_SHORT , GD , CA , [ID] , NUM_INSERT)\n" +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?,?)";

    public void save(List<KihView> entities, int numInsert) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_CRE);

            for (KihView currentRecord : entities) {

                insertStatement.setString(1, "ЗСК");
                insertStatement.setString(2, "C_AML");
                insertStatement.setTimestamp(3, (Timestamp) currentRecord.getAddDate()); //valid_from
                if (currentRecord.getNote().equals("ACTIVE")) {
                    insertStatement.setTimestamp(4, Timestamp.valueOf("2200-01-01 00:00:00"));
                } else {
                    insertStatement.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now().minusDays(1L)));
                }
                insertStatement.setString(5, currentRecord.getNote());
                insertStatement.setString(6, "СЛ");
                insertStatement.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
                if (currentRecord.getType() == null || currentRecord.getType().isEmpty()) {
                    insertStatement.setString(8, "Не определено");
                } else {
                    insertStatement.setString(8, currentRecord.getType());
                }
                insertStatement.setString(9, currentRecord.getInn());
                insertStatement.setNull(10, Types.VARCHAR);
                insertStatement.setNull(11, Types.VARCHAR);

                insertStatement.setString(12, currentRecord.getNameFull());
                insertStatement.setString(13, currentRecord.getName());
                insertStatement.setNull(14, Types.VARCHAR);
                insertStatement.setNull(15, Types.VARCHAR);
                insertStatement.setNull(16, Types.NUMERIC);
                insertStatement.setInt(17, numInsert);

                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException ignore) {
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ignore) {
            }
        }
    }

}
