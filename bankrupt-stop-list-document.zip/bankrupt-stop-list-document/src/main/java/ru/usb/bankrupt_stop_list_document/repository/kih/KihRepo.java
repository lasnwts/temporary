package ru.usb.bankrupt_stop_list_document.repository.kih;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.bankrupt_stop_list_document.model.kih.KihView;


import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface KihRepo extends JpaRepository<KihView, Long> {

    //Готовность потока WF_DM_SFM_IP_BLKLST_CML_FT по таблице
    @Query(nativeQuery = true, value = "select count(*) from ctl.ctl_workflows_load where workflow_name = 'WF_DM_SFM_IP_BLKLST_CML_FT' and  trunc(end_run_dttm) = trunc(sysdate)")
    int getReady();


    @Query(nativeQuery = true, value = "SELECT count(*) FROM DM_SFM.DM_SFM_IP_BLKLST_CML_FT WHERE CTG = 1 AND (NAME!='0' OR NAME!='') and IS_ACTIVE_FLG =1 and IS_DELETE_FLG =0")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL FROM (SELECT INN, ADD_DATE, CASE WHEN REGEXP_LIKE(NAME,'( || | )','i') THEN '' WHEN REGEXP_LIKE(NAME, '( |)','i') THEN '' WHEN REGEXP_LIKE(NAME,'( |)','i') THEN '' WHEN REGEXP_LIKE(NAME,'( |)','i') THEN '' WHEN REGEXP_LIKE(NAME,'()','i') THEN '' ELSE NULL END as TYPE, CASE WHEN STATUS IS NULL THEN 'NOT ACTIVE' ELSE 'ACTIVE' END as NOTE, CASE WHEN (LENGTH(INN)<=0 or INN IS NULL) THEN OGRN ELSE NULL END as OGRN, CASE WHEN INSTR(TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'( | | | | | | | | | | )','', 1,0,'i')),CHR(34)) > 0 THEN TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'( | | | | | | | | | | )','',1,0,'i')) ||CHR(34) ELSE TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'( | | | | | | | | | | )','',1,0,'i')) END as NAME, NAME as NAME_FULL FROM DM_SFM.DM_SFM_IP_BLKLST_CML_FT  WHERE CTG = 1 AND (NAME!='0' OR NAME!='') and IS_ACTIVE_FLG =1 and IS_DELETE_FLG =0 order by INN ) GROUP BY INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL")
    Stream<KihView> getStreamAll();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT count(*) FROM DM_SFM.DM_SFM_IP_BLKLST_CML_FT WHERE CTG = 1 AND (NAME!='0' OR NAME!='') and IS_ACTIVE_FLG =1 and IS_DELETE_FLG =0 AND (INN = :inn AND ADD_DATE = to_date(:addDate,'dd.mm.yyyy'))")
    int getExistCbKih(String inn, String addDate);

}
