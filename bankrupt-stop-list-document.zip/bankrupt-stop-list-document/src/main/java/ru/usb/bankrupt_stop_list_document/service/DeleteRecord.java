package ru.usb.bankrupt_stop_list_document.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Log4j2
@Service
public class DeleteRecord {

    private static final String DELETE_RECORDS_CRE = "DELETE FROM SL_COMPANY_TO_INSERT WHERE NUM_INSERT=?";

    @Autowired
    @Qualifier("creDataSource")
    DataSource creDataSource;
    /**
     * Метод используется при ошибке в процессах. Происходит удаление промежуточных таблиц в CRE
     *
     * @param numInsert номер вставки
     */
    public void deleteProcedure(Integer numInsert) {
        try (Connection connectionCre = creDataSource.getConnection();
             PreparedStatement preparedStatement = connectionCre.prepareStatement(DELETE_RECORDS_CRE)) {
            preparedStatement.setInt(1, numInsert);
            preparedStatement.executeUpdate();
            log.info("Delete temp table due to error completed successful");
        } catch (SQLException exception) {
            log.error("Exception delete table", exception);
        }
    }
}
