package ru.usb.bankrupt_stop_list_document;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankruptStopListDocumentApplicationTests {

	@Test
	void contextLoads() {
	}

}
