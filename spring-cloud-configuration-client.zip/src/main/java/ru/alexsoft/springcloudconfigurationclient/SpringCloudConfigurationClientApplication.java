package ru.alexsoft.springcloudconfigurationclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudConfigurationClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudConfigurationClientApplication.class, args);
	}

}
