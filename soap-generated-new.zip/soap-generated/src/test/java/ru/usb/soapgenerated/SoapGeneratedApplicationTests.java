package ru.usb.soapgenerated;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapGeneratedApplicationTests {

	@Test
	void contextLoads() {
	}

}
