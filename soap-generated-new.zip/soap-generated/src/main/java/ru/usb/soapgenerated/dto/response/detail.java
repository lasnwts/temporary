package ru.usb.soapgenerated.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "Body")
public class detail {
    @JsonProperty("Exception")
    private String Exception;
    public detail() {
        //
    }

    @JsonProperty("Exception")
    public String getException() {
        return Exception;
    }

    @JsonProperty("Exception")
    public void setException(String exception) {
        Exception = exception;
    }

    @Override
    public String toString() {
        return "detail{" +
                "Exception='" + Exception + '\'' +
                '}';
    }
}
