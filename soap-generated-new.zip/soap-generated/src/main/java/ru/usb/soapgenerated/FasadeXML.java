package ru.usb.soapgenerated;

import org.springframework.stereotype.Component;

@Component
public class FasadeXML {

    /**
     * Получаем готовый SOAP body
     *
     * @param xmlString
     * @return
     */
    public String getFacadePartner(String xmlString) {
        if (xmlString == null) {
            return "";
        } else {
            return getDirectoryID(getPartnerID(getExtUserGuid(getGetCommonDirectoryRequest(getBody(getEnvelope(xmlString))))));
        }
    }

    public String getEnvelope(String xmlString) {
        return xmlString.replace("</Envelope>", "</soapenv:Envelope>")
                .replace("<Envelope>", "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\"><soapenv:Header/>");
    }

    public String getBody(String xmlString) {
        return xmlString.replace("Body", "soapenv:Body");
    }

    public String getGetCommonDirectoryRequest(String xmlString) {
        return xmlString.replace("GetCommonDirectoryRequest", "bp:GetCommonDirectoryRequest");
    }

    public String getPartnerID(String xmlString) {
        return xmlString.replace("PartnerID", "bp:PartnerID");
    }

    public String getExtUserGuid(String xmlString) {
        return xmlString.replace("ExtUserGuid", "bp:ExtUserGuid");
    }

    public String getDirectoryID(String xmlString) {
        return xmlString.replace("DirectoryID", "bp:DirectoryID");
    }


}
