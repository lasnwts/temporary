package ru.usb.soapgenerated.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JacksonXmlRootElement(localName = "Body")
public class Body {
    @JsonProperty("GetCommonDirectoryResponse")
    public GetCommonDirectoryResponse GetCommonDirectoryResponse;

    @JsonProperty("Fault")
    public Fault Fault;

    public Body() {
        //
    }

    @JsonProperty("Fault")
    public Fault getFault() {
        return Fault;
    }

    @JsonProperty("Fault")
    public void setFault(Fault fault) {
        Fault = fault;
    }

    @JsonProperty("GetCommonDirectoryResponse")
    public ru.usb.soapgenerated.dto.response.GetCommonDirectoryResponse getGetCommonDirectoryResponse() {
        return GetCommonDirectoryResponse;
    }

    @Override
    public String toString() {
        return "Body{" +
                "GetCommonDirectoryResponse=" + GetCommonDirectoryResponse +
                '}';
    }

    @JsonProperty("GetCommonDirectoryResponse")
    public void setGetCommonDirectoryResponse(ru.usb.soapgenerated.dto.response.GetCommonDirectoryResponse getCommonDirectoryResponse) {
        GetCommonDirectoryResponse = getCommonDirectoryResponse;
    }
}
