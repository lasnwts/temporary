package ru.usb.soapgenerated;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.soapgenerated.dto.Envelope;
import ru.usb.soapgenerated.dto.response.Directory;

import java.util.function.Consumer;

@SpringBootApplication
public class SoapGeneratedApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(SoapGeneratedApplication.class);

    @Autowired
    MapperRequestXML mapperRequestXML;

    @Autowired
    MapperResponseXML mapperResponseXML;

    @Autowired
    FasadeXML fasadeXML;

    public static void main(String[] args) {
        SpringApplication.run(SoapGeneratedApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info("Start");

        String s1 = "fjghdfhg";

        String s2 = "<Envelope>\n" +
                "<Header>1</Header>" +
                "   <Body>\n" +
                "      <GetCommonDirectoryRequest>\n" +
                "         <PartnerID>300</PartnerID>\n" +
                "         <ExtUserGuid>acb80275-6ecb-4bef-9f36-ed15de3e8891</ExtUserGuid>\n" +
                "         <DirectoryID>CB_SET_QUESTIONNAIRE</DirectoryID>\n" +
                "      </GetCommonDirectoryRequest>\n" +
                "   </Body>\n" +
                "</Envelope>";

        String sourceXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bp=\"http://bp.ws.fisgroup.ru\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <bp:GetCommonDirectoryRequest>\n" +
                "         <bp:PartnerID>300</bp:PartnerID>\n" +
                "         <bp:ExtUserGuid>acb80275-6ecb-4bef-9f36-ed15de3e8891</bp:ExtUserGuid>\n" +
                "         <bp:DirectoryID>CB_SET_QUESTIONNAIRE</bp:DirectoryID>\n" +
                "      </bp:GetCommonDirectoryRequest>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        String responseErrorPartner = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "   <soapenv:Body>\n" +
                "      <tns:GetCommonDirectoryResponse xmlns:tns=\"http://bp.ws.fisgroup.ru\">\n" +
                "         <tns:Result>\n" +
                "            <tns:ResultCode>ERROR</tns:ResultCode>\n" +
                "            <tns:ResultMessage>Не найден партнер</tns:ResultMessage>\n" +
                "         </tns:Result>\n" +
                "      </tns:GetCommonDirectoryResponse>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        String responsePartnerSuccess = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "   <soapenv:Body>\n" +
                "      <tns:GetCommonDirectoryResponse xmlns:tns=\"http://bp.ws.fisgroup.ru\">\n" +
                "         <tns:Result>\n" +
                "            <tns:ResultCode>OK</tns:ResultCode>\n" +
                "            <tns:ResultMessage>Запрос выполнен успешно</tns:ResultMessage>\n" +
                "         </tns:Result>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>01</tns:Code>\n" +
                "            <tns:Value>ФИО</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>02</tns:Code>\n" +
                "            <tns:Value>Дата рождения</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>10</tns:Code>\n" +
                "            <tns:Value>Мне известно, что Договор страхования не является банковским вкладом и не входит в систему гарантирования Агентства по страхованию вкладов в соответствии с Федеральным законом от 23 декабря 2003 года №177-ФЗ «О страховании вкладов физических лиц в банках Российской Федерации». Я осознаю, что заключение договора страхования с инвестиционной составляющей связано с инвестиционными рисками.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>11</tns:Code>\n" +
                "            <tns:Value>Мне известно, что Договор страхования не является банковским вкладом и не входит в систему гарантирования Агентства по страхованию вкладов в соответствии с Федеральным законом от 23 декабря 2003 года №177-ФЗ «О страховании вкладов физических лиц в банках Российской Федерации». Я осознаю, что заключение договора страхования с инвестиционной составляющей связано с инвестиционными рисками. Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>20</tns:Code>\n" +
                "            <tns:Value>Я имею аттестат и/ или сертификат рынка ценных бумаг (например, квалификационного аттестата специалиста финансового рынка, квалификационного аттестата аудитора, квалификационного аттестата страхового актуария, сертификата Chartered Financial Analyst (CFA), сертификата Certified International Investment Analyst (CIIA), сертификата Financial Risk Manager (FRM).</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>21</tns:Code>\n" +
                "            <tns:Value>Я имею аттестат и/ или сертификат рынка ценных бумаг (например, квалификационного аттестата специалиста финансового рынка, квалификационного аттестата аудитора, квалификационного аттестата страхового актуария, сертификата Chartered Financial Analyst (CFA), сертификата Certified International Investment Analyst (CIIA), сертификата Financial Risk Manager (FRM). Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>30</tns:Code>\n" +
                "            <tns:Value>Я регулярно совершаю сделки с ценными бумагами или заключаю договоры, являющиеся производными финансовыми инструментами (например, за последние четыре квартала в среднем не реже 10 раз в квартал и не реже одного раза в месяц).</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>31</tns:Code>\n" +
                "            <tns:Value>Я регулярно совершаю сделки с ценными бумагами или заключаю договоры, являющиеся производными финансовыми инструментами (например, за последние четыре квартала в среднем не реже 10 раз в квартал и не реже одного раза в месяц). Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>40</tns:Code>\n" +
                "            <tns:Value>Я повторно заключаю договор страхования с инвестиционной составляющей (под повторным понимается наличие уже завершившего свое действие договора страхования с инвестиционной составляющей).</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>41</tns:Code>\n" +
                "            <tns:Value>Я повторно заключаю договор страхования с инвестиционной составляющей (под повторным понимается наличие уже завершившего свое действие договора страхования с инвестиционной составляющей).  Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>50</tns:Code>\n" +
                "            <tns:Value>Я имею опыт работы с финансовыми инструментами: - не менее 2-х лет в организации, являющейся квалифицированным инвестором1, или не менее 3-х лет в организации, которая осуществляла сделки с ценными бумагами и/или иными финансовыми инструментами (в том числе, но не ограничиваясь, страховые компании, НПФ, Банки, УК); или не менее 3-х лет в страховой организации, или не менее 1-го года опыта работы в сфере реализации (в том числе в организациях – агентах страховых организаций), методологии ИСЖ, НСЖ.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>51</tns:Code>\n" +
                "            <tns:Value>Я имею опыт работы с финансовыми инструментами: - не менее 2-х лет в организации, являющейся квалифицированным инвестором1, или не менее 3-х лет в организации, которая осуществляла сделки с ценными бумагами и/или иными финансовыми инструментами (в том числе, но не ограничиваясь, страховые компании, НПФ, Банки, УК); или не менее 3-х лет в страховой организации, или не менее 1-го года опыта работы в сфере реализации (в том числе в организациях – агентах страховых организаций), методологии ИСЖ, НСЖ.  Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>60</tns:Code>\n" +
                "            <tns:Value>Совокупный объем моих активов в финансовых инструментах (включая депозиты, текущие счета, ценные бумаги, доверительное управление, ПИФ, ИИС, денежные средства в том числе в иностранной валюте и т.п.) в настоящее время превышает в сумме 6 000 000 (шесть миллионов) рублей.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>61</tns:Code>\n" +
                "            <tns:Value>Совокупный объем моих активов в финансовых инструментах (включая депозиты, текущие счета, ценные бумаги, доверительное управление, ПИФ, ИИС, денежные средства в том числе в иностранной валюте и т.п.) в настоящее время превышает в сумме 6 000 000 (шесть миллионов) рублей. Подтверждение.</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:Directory>\n" +
                "            <tns:Code>70</tns:Code>\n" +
                "            <tns:Value>Дата и время заполнения</tns:Value>\n" +
                "         </tns:Directory>\n" +
                "         <tns:DirectoryID>CB_SET_QUESTIONNAIRE</tns:DirectoryID>\n" +
                "      </tns:GetCommonDirectoryResponse>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>\n" +
                " ";

		String error1 = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
				"   <soapenv:Body>\n" +
				"      <tns:GetCommonDirectoryResponse xmlns:tns=\"http://bp.ws.fisgroup.ru\">\n" +
				"         <tns:Result>\n" +
				"            <tns:ResultCode>ERROR</tns:ResultCode>\n" +
				"            <tns:ResultMessage>Не найден партнер</tns:ResultMessage>\n" +
				"         </tns:Result>\n" +
				"      </tns:GetCommonDirectoryResponse>\n" +
				"   </soapenv:Body>\n" +
				"</soapenv:Envelope>";

		String error2 = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
				"   <soapenv:Body>\n" +
				"      <soapenv:Fault>\n" +
				"         <faultcode>soapenv:Server</faultcode>\n" +
				"         <faultstring>unknown</faultstring>\n" +
				"         <detail>\n" +
				"            <Exception>org.apache.axis2.AxisFault\n" +
				"        at org.apache.axis2.AxisFault.makeFault(AxisFault.java:430)\n" +
				"        at ru.fisgroup.platform.udm.ws.service.WSExecService.execute(WSExecService.java:234)\n" +
				"        at ru.fisgroup.platform.ws.bp.BusinessProcessServiceImpl$1.exec(BusinessProcessServiceImpl.java:44)\n" +
				"        at ru.fisgroup.platform.core.util.jta.ExecuteInJTAImpl.exec(ExecuteInJTAImpl.java:80)\n" +
				"        at ru.fisgroup.platform.core.util.jta.ExecuteInJTAImpl.exec(ExecuteInJTAImpl.java:42)\n" +
				"        at ru.fisgroup.platform.core.util.jta.ExecuteInJTAImpl.exec(ExecuteInJTAImpl.java:37)\n" +
				"        at ru.fisgroup.platform.ws.utils.WSUtils.executeInJta(WSUtils.java:12)\n" +
				"        at ru.fisgroup.platform.ws.bp.BusinessProcessServiceImpl.execute(BusinessProcessServiceImpl.java:40)\n" +
				"        at ru.fisgroup.platform.ws.receivers.BPInOutMessageReceiverImpl.invokeBusinessLogic(BPInOutMessageReceiverImpl.java:113)\n" +
				"        at org.apache.axis2.receivers.AbstractInOutMessageReceiver.invokeBusinessLogic(AbstractInOutMessageReceiver.java:40)\n" +
				"        at org.apache.axis2.receivers.AbstractMessageReceiver.receive(AbstractMessageReceiver.java:114)\n" +
				"        at org.apache.axis2.engine.AxisEngine.receive(AxisEngine.java:181)\n" +
				"        at org.apache.axis2.transport.http.HTTPTransportUtils.processHTTPPostRequest(HTTPTransportUtils.java:172)\n" +
				"        at org.apache.axis2.transport.http.AxisServlet.doPost(AxisServlet.java:147)\n" +
				"        at javax.servlet.http.HttpServlet.service(HttpServlet.java:665)\n" +
				"        at javax.servlet.http.HttpServlet.service(HttpServlet.java:750)\n" +
				"        at org.apache.catalina.core.StandardWrapper.service(StandardWrapper.java:1628)\n" +
				"        at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:258)\n" +
				"        at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:160)\n" +
				"        at org.apache.catalina.core.StandardPipeline.doInvoke(StandardPipeline.java:755)\n" +
				"        at org.apache.catalina.core.StandardPipeline.invoke(StandardPipeline.java:575)\n" +
				"        at com.sun.enterprise.web.WebPipeline.invoke(WebPipeline.java:99)\n" +
				"        at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:159)\n" +
				"        at org.apache.catalina.connector.CoyoteAdapter.doService(CoyoteAdapter.java:371)\n" +
				"        at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:238)\n" +
				"        at com.sun.enterprise.v3.services.impl.ContainerMapper$HttpHandlerCallable.call(ContainerMapper.java:520)\n" +
				"        at com.sun.enterprise.v3.services.impl.ContainerMapper.service(ContainerMapper.java:217)\n" +
				"        at org.glassfish.grizzly.http.server.HttpHandler.runService(HttpHandler.java:182)\n" +
				"        at org.glassfish.grizzly.http.server.HttpHandler.doHandle(HttpHandler.java:156)\n" +
				"        at org.glassfish.grizzly.http.server.HttpServerFilter.handleRead(HttpServerFilter.java:218)\n" +
				"        at org.glassfish.grizzly.filterchain.ExecutorResolver$9.execute(ExecutorResolver.java:95)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.executeFilter(DefaultFilterChain.java:260)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.executeChainPart(DefaultFilterChain.java:177)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.execute(DefaultFilterChain.java:109)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.process(DefaultFilterChain.java:88)\n" +
				"        at org.glassfish.grizzly.ProcessorExecutor.execute(ProcessorExecutor.java:53)\n" +
				"        at org.glassfish.grizzly.nio.transport.TCPNIOTransport.fireIOEvent(TCPNIOTransport.java:524)\n" +
				"        at org.glassfish.grizzly.strategies.AbstractIOStrategy.fireIOEvent(AbstractIOStrategy.java:89)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy.run0(WorkerThreadIOStrategy.java:94)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy.access$100(WorkerThreadIOStrategy.java:33)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy$WorkerThreadRunnable.run(WorkerThreadIOStrategy.java:114)\n" +
				"        at org.glassfish.grizzly.threadpool.AbstractThreadPool$Worker.doWork(AbstractThreadPool.java:569)\n" +
				"        at org.glassfish.grizzly.threadpool.AbstractThreadPool$Worker.run(AbstractThreadPool.java:549)\n" +
				"        at java.lang.Thread.run(Thread.java:748)\n" +
				"Caused by: java.lang.NullPointerException\n" +
				"        at java.lang.String.&lt;init>(String.java:491)\n" +
				"        at ru.fisgroup.platform.udm.ws.util.conversion.axiom.ExecAxiomUdmConvertor.convertExecResultWithBinaryAttr(ExecAxiomUdmConvertor.java:712)\n" +
				"        at ru.fisgroup.platform.udm.ws.service.WSExecService.executeProcess(WSExecService.java:286)\n" +
				"        at ru.fisgroup.platform.udm.ws.service.WSExecService.execute(WSExecService.java:223)\n" +
				"        ... 42 more</Exception>\n" +
				"         </detail>\n" +
				"      </soapenv:Fault>\n" +
				"   </soapenv:Body>\n" +
				"</soapenv:Envelope>";


		String error3 = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
				"   <soapenv:Body>\n" +
				"      <soapenv:Fault>\n" +
				"         <faultcode>soapenv:Server</faultcode>\n" +
				"         <faultstring>com.ctc.wstx.exc.WstxParsingException: Unexpected close tag &lt;/soapenv:Body>; expected &lt;/bp:GetCommonDirectoryRequest>.\n" +
				" at [row,col {unknown-source}]: [6,17]</faultstring>\n" +
				"         <detail>\n" +
				"            <Exception><![CDATA[org.apache.axis2.AxisFault: com.ctc.wstx.exc.WstxParsingException: Unexpected close tag </soapenv:Body>; expected </bp:GetCommonDirectoryRequest>.\n" +
				" at [row,col {unknown-source}]: [6,17]\n" +
				"        at org.apache.axis2.AxisFault.makeFault(AxisFault.java:430)\n" +
				"        at org.apache.axis2.transport.http.HTTPTransportUtils.processHTTPPostRequest(HTTPTransportUtils.java:180)\n" +
				"        at org.apache.axis2.transport.http.AxisServlet.doPost(AxisServlet.java:147)\n" +
				"        at javax.servlet.http.HttpServlet.service(HttpServlet.java:665)\n" +
				"        at javax.servlet.http.HttpServlet.service(HttpServlet.java:750)\n" +
				"        at org.apache.catalina.core.StandardWrapper.service(StandardWrapper.java:1628)\n" +
				"        at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:258)\n" +
				"        at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:160)\n" +
				"        at org.apache.catalina.core.StandardPipeline.doInvoke(StandardPipeline.java:755)\n" +
				"        at org.apache.catalina.core.StandardPipeline.invoke(StandardPipeline.java:575)\n" +
				"        at com.sun.enterprise.web.WebPipeline.invoke(WebPipeline.java:99)\n" +
				"        at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:159)\n" +
				"        at org.apache.catalina.connector.CoyoteAdapter.doService(CoyoteAdapter.java:371)\n" +
				"        at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:238)\n" +
				"        at com.sun.enterprise.v3.services.impl.ContainerMapper$HttpHandlerCallable.call(ContainerMapper.java:520)\n" +
				"        at com.sun.enterprise.v3.services.impl.ContainerMapper.service(ContainerMapper.java:217)\n" +
				"        at org.glassfish.grizzly.http.server.HttpHandler.runService(HttpHandler.java:182)\n" +
				"        at org.glassfish.grizzly.http.server.HttpHandler.doHandle(HttpHandler.java:156)\n" +
				"        at org.glassfish.grizzly.http.server.HttpServerFilter.handleRead(HttpServerFilter.java:218)\n" +
				"        at org.glassfish.grizzly.filterchain.ExecutorResolver$9.execute(ExecutorResolver.java:95)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.executeFilter(DefaultFilterChain.java:260)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.executeChainPart(DefaultFilterChain.java:177)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.execute(DefaultFilterChain.java:109)\n" +
				"        at org.glassfish.grizzly.filterchain.DefaultFilterChain.process(DefaultFilterChain.java:88)\n" +
				"        at org.glassfish.grizzly.ProcessorExecutor.execute(ProcessorExecutor.java:53)\n" +
				"        at org.glassfish.grizzly.nio.transport.TCPNIOTransport.fireIOEvent(TCPNIOTransport.java:524)\n" +
				"        at org.glassfish.grizzly.strategies.AbstractIOStrategy.fireIOEvent(AbstractIOStrategy.java:89)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy.run0(WorkerThreadIOStrategy.java:94)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy.access$100(WorkerThreadIOStrategy.java:33)\n" +
				"        at org.glassfish.grizzly.strategies.WorkerThreadIOStrategy$WorkerThreadRunnable.run(WorkerThreadIOStrategy.java:114)\n" +
				"        at org.glassfish.grizzly.threadpool.AbstractThreadPool$Worker.doWork(AbstractThreadPool.java:569)\n" +
				"        at org.glassfish.grizzly.threadpool.AbstractThreadPool$Worker.run(AbstractThreadPool.java:549)\n" +
				"        at java.lang.Thread.run(Thread.java:748)\n" +
				"Caused by: org.apache.axiom.om.OMException: com.ctc.wstx.exc.WstxParsingException: Unexpected close tag </soapenv:Body>; expected </bp:GetCommonDirectoryRequest>.\n" +
				" at [row,col {unknown-source}]: [6,17]\n" +
				"        at org.apache.axiom.om.impl.builder.StAXOMBuilder.next(StAXOMBuilder.java:296)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.buildNext(OMElementImpl.java:709)\n" +
				"        at org.apache.axiom.om.impl.llom.OMNodeImpl.getNextOMSibling(OMNodeImpl.java:121)\n" +
				"        at org.apache.axiom.om.impl.traverse.OMChildrenIterator.getNextNode(OMChildrenIterator.java:36)\n" +
				"        at org.apache.axiom.om.impl.traverse.OMAbstractIterator.hasNext(OMAbstractIterator.java:69)\n" +
				"        at org.apache.axiom.om.impl.util.OMSerializerUtil.serializeChildren(OMSerializerUtil.java:555)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.internalSerialize(OMElementImpl.java:846)\n" +
				"        at org.apache.axiom.om.impl.util.OMSerializerUtil.serializeChildren(OMSerializerUtil.java:556)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.internalSerialize(OMElementImpl.java:846)\n" +
				"        at org.apache.axiom.soap.impl.llom.SOAPEnvelopeImpl.internalSerialize(SOAPEnvelopeImpl.java:214)\n" +
				"        at org.apache.axiom.om.impl.llom.OMSerializableImpl.serialize(OMSerializableImpl.java:120)\n" +
				"        at org.apache.axiom.om.impl.llom.OMSerializableImpl.serialize(OMSerializableImpl.java:108)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.toString(OMElementImpl.java:957)\n" +
				"        at ru.fisgroup.platform.ws.receivers.BPInOutMessageReceiverImpl.invokeBusinessLogic(BPInOutMessageReceiverImpl.java:143)\n" +
				"        at org.apache.axis2.receivers.AbstractInOutMessageReceiver.invokeBusinessLogic(AbstractInOutMessageReceiver.java:40)\n" +
				"        at org.apache.axis2.receivers.AbstractMessageReceiver.receive(AbstractMessageReceiver.java:114)\n" +
				"        at org.apache.axis2.engine.AxisEngine.receive(AxisEngine.java:181)\n" +
				"        at org.apache.axis2.transport.http.HTTPTransportUtils.processHTTPPostRequest(HTTPTransportUtils.java:172)\n" +
				"        ... 31 more\n" +
				"Caused by: com.ctc.wstx.exc.WstxParsingException: Unexpected close tag </soapenv:Body>; expected </bp:GetCommonDirectoryRequest>.\n" +
				" at [row,col {unknown-source}]: [6,17]\n" +
				"        at com.ctc.wstx.sr.StreamScanner.constructWfcException(StreamScanner.java:630)\n" +
				"        at com.ctc.wstx.sr.StreamScanner.throwParseError(StreamScanner.java:461)\n" +
				"        at com.ctc.wstx.sr.BasicStreamReader.reportWrongEndPrefix(BasicStreamReader.java:3241)\n" +
				"        at com.ctc.wstx.sr.BasicStreamReader.readEndElem(BasicStreamReader.java:3164)\n" +
				"        at com.ctc.wstx.sr.BasicStreamReader.nextFromTree(BasicStreamReader.java:2832)\n" +
				"        at com.ctc.wstx.sr.BasicStreamReader.next(BasicStreamReader.java:1019)\n" +
				"        at org.apache.axiom.util.stax.wrapper.XMLStreamReaderWrapper.next(XMLStreamReaderWrapper.java:225)\n" +
				"        at org.apache.axiom.util.stax.dialect.DisallowDoctypeDeclStreamReaderWrapper.next(DisallowDoctypeDeclStreamReaderWrapper.java:34)\n" +
				"        at org.apache.axiom.om.impl.builder.StAXOMBuilder.parserNext(StAXOMBuilder.java:668)\n" +
				"        at org.apache.axiom.om.impl.builder.StAXOMBuilder.next(StAXOMBuilder.java:214)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.buildNext(OMElementImpl.java:709)\n" +
				"        at org.apache.axiom.om.impl.llom.OMNodeImpl.getNextOMSibling(OMNodeImpl.java:121)\n" +
				"        at org.apache.axiom.om.impl.traverse.OMChildrenIterator.getNextNode(OMChildrenIterator.java:36)\n" +
				"        at org.apache.axiom.om.impl.traverse.OMAbstractIterator.hasNext(OMAbstractIterator.java:69)\n" +
				"        at org.apache.axiom.om.impl.util.OMSerializerUtil.serializeChildren(OMSerializerUtil.java:555)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.internalSerialize(OMElementImpl.java:846)\n" +
				"        at org.apache.axiom.om.impl.util.OMSerializerUtil.serializeChildren(OMSerializerUtil.java:556)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.internalSerialize(OMElementImpl.java:846)\n" +
				"        at org.apache.axiom.om.impl.llom.OMSerializableImpl.serialize(OMSerializableImpl.java:120)\n" +
				"        at org.apache.axiom.om.impl.llom.OMSerializableImpl.serialize(OMSerializableImpl.java:108)\n" +
				"        at org.apache.axiom.om.impl.llom.OMElementImpl.toString(OMElementImpl.java:957)\n" +
				"        at java.lang.String.valueOf(String.java:2994)\n" +
				"        at java.lang.StringBuilder.append(StringBuilder.java:131)\n" +
				"        at ru.fisgroup.platform.ws.bp.BusinessProcessServiceImpl.execute(BusinessProcessServiceImpl.java:36)\n" +
				"        at ru.fisgroup.platform.ws.receivers.BPInOutMessageReceiverImpl.invokeBusinessLogic(BPInOutMessageReceiverImpl.java:113)\n" +
				"        ... 35 more]]></Exception>\n" +
				"         </detail>\n" +
				"      </soapenv:Fault>\n" +
				"   </soapenv:Body>\n" +
				"</soapenv:Envelope>\n";

        logger.info("s1={}", s1);
        logger.info("s2={}", s2);
        logger.info("sourceXML={}", sourceXML);

        Envelope envelope = mapperRequestXML.getMap(s2);
        logger.info("enveloper={}", envelope);
        logger.info("enveloper.body={}", envelope.getBody().getGetCommonDirectoryRequest());

        Envelope envelope1 = mapperRequestXML.getMap(sourceXML);
        logger.info("enveloper1={}", envelope1);
        logger.info("enveloper.body1={}", envelope1.getBody().getGetCommonDirectoryRequest());

        logger.info("XML");
        String xmlString = fasadeXML.getFacadePartner(mapperRequestXML.getPartnerXML(envelope1));
        logger.info("envlelope1={}", xmlString);

        logger.info("Response Error parse");
        ru.usb.soapgenerated.dto.response.Envelope envelope2 = mapperResponseXML.getMap(responseErrorPartner);
        logger.info("responseErrorPartner={}", envelope2.getBody().getGetCommonDirectoryResponse().getResult().toString());

        logger.info("Response Succes parse");
        ru.usb.soapgenerated.dto.response.Envelope envelope3 = mapperResponseXML.getMap(responsePartnerSuccess);
        logger.info("responseErrorPartner Result={}", envelope3.getBody().getGetCommonDirectoryResponse().getResult().toString());
        logger.info("responseErrorPartner getDirectoryID={}", envelope3.getBody().getGetCommonDirectoryResponse().getDirectoryID().toString());
        if (envelope3.getBody().getGetCommonDirectoryResponse().getDirectory() != null) {
            envelope3.getBody().getGetCommonDirectoryResponse().getDirectory().forEach(new Consumer<Directory>() {
                @Override
                public void accept(Directory directory) {
                    logger.info("Code:{}", directory.getCode());
                    logger.info("Value:{}", directory.getValue());
                }
            });
        }

		logger.info(".");
		logger.info("=======================");
		logger.info(".");
		logger.info("Response Error1:error1 ");
		ru.usb.soapgenerated.dto.response.Envelope envelope4 = mapperResponseXML.getMap(error1);
		logger.info("responseErrorPartner Error1:error1={}", envelope4.getBody().getGetCommonDirectoryResponse().getResult().toString());

		logger.info("Response Error2:error2 ");
		ru.usb.soapgenerated.dto.response.Envelope envelope5 = mapperResponseXML.getMap(error2);
		if (envelope5.getBody().getGetCommonDirectoryResponse() != null && envelope5.getBody().getGetCommonDirectoryResponse().getResult() != null){
			logger.info("responseErrorPartner Error2.getResult ={}", envelope5.getBody().getGetCommonDirectoryResponse().getResult().toString());
		}
		if (envelope5.getBody().getFault() != null && envelope5.getBody().getFault().getDetail() != null && envelope5.getBody().getFault().getDetail().getException() != null
		&& envelope5.getBody().getFault().getDetail().getException().length() > 55) {
			logger.info("responseErrorPartner Error2:getFault().detail.getException()={}", envelope5.getBody().getFault().getDetail().getException().substring(0, 55));
		}
		if (envelope5.getBody().getFault() != null) {
			logger.info("responseErrorPartner Error2:getFault().getFaultcode={}", envelope5.getBody().getFault().getFaultcode());
			logger.info("responseErrorPartner Error2:getFault().getFaultstring={}", envelope5.getBody().getFault().getFaultstring());
		}

		logger.info("Response Error3:error3 ");
		ru.usb.soapgenerated.dto.response.Envelope envelope6 = mapperResponseXML.getMap(error2);
		if (envelope6.getBody().getGetCommonDirectoryResponse() != null && envelope6.getBody().getGetCommonDirectoryResponse().getResult() != null){
			logger.info("responseErrorPartner Error3.getResult ={}", envelope6.getBody().getGetCommonDirectoryResponse().getResult().toString());
		}
		if (envelope6.getBody().getFault() != null && envelope6.getBody().getFault().getDetail() != null && envelope6.getBody().getFault().getDetail().getException() != null
				&& envelope6.getBody().getFault().getDetail().getException().length() > 55) {
			logger.info("responseErrorPartner Error3:getFault().detail.getException()={}", envelope6.getBody().getFault().getDetail().getException().substring(0, 55));
		}
		if (envelope6.getBody().getFault() != null) {
			logger.info("responseErrorPartner Error3:getFault().getFaultcode={}", envelope6.getBody().getFault().getFaultcode());
			logger.info("responseErrorPartner Error3:getFault().getFaultstring={}", envelope6.getBody().getFault().getFaultstring());
		}



	}
}
