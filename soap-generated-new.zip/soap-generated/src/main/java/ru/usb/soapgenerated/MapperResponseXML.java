package ru.usb.soapgenerated;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.soapgenerated.dto.response.Envelope;


@Component
public class MapperResponseXML {
    Logger logger = LoggerFactory.getLogger(MapperResponseXML.class);
    XmlMapper xmlMapper = new XmlMapper();

/**
 * CollectionType studentsListType = xmlMapper.getTypeFactory().constructCollectionType(List.class, Student.class);
 * List<Student> students = xmlMapper.readValue(xmlFile, studentsListType);
 */

    //XmlMapper xmlMapper = new XmlMapper(module);

    /**
     * Partner XML to POJO
     * @param xmlString
     * @return
     */
    public Envelope getMap(String xmlString) {
        if (xmlString == null) {
            return null;
        } else {
            try {
                xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                xmlMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
                return xmlMapper.readValue(xmlString, Envelope.class);
            } catch (JsonProcessingException e) {
                logger.error("UsbLog: ###############################");
                logger.error("UsbLog: Ошибка преобразования строки XML {} в POJO", xmlString);
                logger.error("UsbLog: JsonProcessingException:`", e);
                return null;
            }
        }
    }

}
