package ru.usb.soapgenerated.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Body {
    @JsonProperty("GetCommonDirectoryRequest")
    public GetCommonDirectoryRequest GetCommonDirectoryRequest;

    public Body() {
    }

    @JsonProperty("GetCommonDirectoryRequest")
    public ru.usb.soapgenerated.dto.GetCommonDirectoryRequest getGetCommonDirectoryRequest() {
        return GetCommonDirectoryRequest;
    }

    @JsonProperty("GetCommonDirectoryRequest")
    public void setGetCommonDirectoryRequest(ru.usb.soapgenerated.dto.GetCommonDirectoryRequest getCommonDirectoryRequest) {
        GetCommonDirectoryRequest = getCommonDirectoryRequest;
    }
}
