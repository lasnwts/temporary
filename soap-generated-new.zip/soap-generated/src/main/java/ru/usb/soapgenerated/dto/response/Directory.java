package ru.usb.soapgenerated.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JacksonXmlRootElement(localName = "Directory")
public class Directory {
    @JsonProperty("Code")
    @JacksonXmlProperty(localName = "Code")
    private String Code;
    @JsonProperty("Value")
    private String Value;

    public Directory() {
        //
    }

    public Directory(String code, String value) {
        Code = code;
        Value = value;
    }

    @JsonProperty("Code")
    @JacksonXmlProperty(localName = "Code")
    public String getCode() {
        return Code;
    }

    @JsonProperty("Code")
    @JacksonXmlProperty(localName = "Code")
    public void setCode(String code) {
        Code = code;
    }

    @JsonProperty("Value")
    public String getValue() {
        return Value;
    }

    @JsonProperty("Value")
    public void setValue(String value) {
        Value = value;
    }

    @Override
    public String toString() {
        return "Directory{" +
                "Code=" + Code +
                ", Value='" + Value + '\'' +
                '}';
    }
}
