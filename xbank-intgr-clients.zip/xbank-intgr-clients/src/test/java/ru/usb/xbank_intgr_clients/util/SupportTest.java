package ru.usb.xbank_intgr_clients.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.xbank_intgr_clients.config.Configure;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class SupportTest {

    private Support support;
    private Configure configure;


    @BeforeEach
    void setUp() {
        configure = new Configure();
        support = new Support(configure);
    }

    @Test
    void getFileName() {
        String fileName = "C:/test/tbank.customer.csv";
        System.out.println(support.getFileName(fileName));
        assertEquals("tbank.customer.csv", support.getFileName(fileName));
    }


    @Test
    void getExtension() {
        String fileName = "C:/test/tbank.customer.csv";
        System.out.println(support.getExtension(fileName));
        assertEquals("csv", support.getExtension(fileName));
    }

    @Test
    void getDateM1()  {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = "1";
        System.out.println(support.getDateEndM(main, dateEndM));
        assertNull(support.getDateEndM(main, dateEndM));
    }

    @Test
    void getDateM2() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = "0";
        System.out.println(support.getDateEndM(main, dateEndM));
        assertEquals(dateEndM,support.getDateEndM(main, dateEndM));
    }

    @Test
    void getDateM3() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = "0fjj1";
        System.out.println(support.getDateEndM(main, dateEndM));
        assertEquals(dateEndM,support.getDateEndM(main, dateEndM));

    }

    @Test
    void getDateM4() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = "";
        System.out.println(support.getDateEndM(main, dateEndM));
        assertEquals(dateEndM,support.getDateEndM(main, dateEndM));
    }

    @Test
    void getDateM5() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = null;
        System.out.println(support.getDateEndM(main, dateEndM));
        assertEquals(dateEndM,support.getDateEndM(main, dateEndM));
    }


    @Test
    void getDateM6() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date parsedate = null;
        try {
            parsedate = format.parse("23/11/2024");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        java.sql.Date dateEndM = new java.sql.Date(parsedate.getTime());
        String main = null;
        System.out.println(support.getDateEndM(main, dateEndM));
        assertEquals(dateEndM,support.getDateEndM(main, dateEndM));
    }

    @Test
    void getDateM7() {
        java.sql.Date dateEndM = null;
        String main = "1";
        System.out.println(support.getDateEndM(main, dateEndM));
        assertNull(support.getDateEndM(main, dateEndM));
    }

    @Test
    void getDateM8() {
        java.sql.Date dateEndM = null;
        String main = null;
        System.out.println(support.getDateEndM(main, dateEndM));
        assertNull(support.getDateEndM(main, dateEndM));
    }


}