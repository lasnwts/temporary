package ru.usb.xbank_intgr_clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XbankIntgrClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
