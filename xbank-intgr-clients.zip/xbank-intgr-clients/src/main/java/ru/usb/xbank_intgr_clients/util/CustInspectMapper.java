package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustInspect;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustInspect;
import ru.usb.xbank_intgr_clients.model.CustInspectHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class CustInspectMapper {

    private final Configure configure;

    @Autowired
    public CustInspectMapper(Configure configure) {
        this.configure = configure;
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }
    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    private static final String COMMA_DELIMITER = ";";


    public CheckCustInspect map(String line, CustInspectHeadPosition custInspectHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        CustInspect custInspect = new CustInspect();
        //Константы
        custInspect.setFileName(configure.getArchiveName());
        custInspect.setNumInsert(numInsert);
        custInspect.setInputDate(new Date());

        //INSPECT_CUSR_NMBR;INSPECT_INSPECT_DATE;INSPECT_INSPECTOR;INSPECT_NAME;INSPECT_NOTES
        try {
            //INSPECT_CUST_NMBR
            if (custInspectHeadPosition.getInspectCusrNmb() > -1) {
                custInspect.setInspectCusrNmb(values[custInspectHeadPosition.getInspectCusrNmb()]);
            } else {
                setLoadError("Не найден обязательный параметр:INSPECT_CUST_NMBR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_CUST_NMBR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_CUST_NMBR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //INSPECT_INSPECT_DATE
            if (custInspectHeadPosition.getInspectInspectDate() > -1 && checkDateLine(values[custInspectHeadPosition.getInspectInspectDate()])) {
                custInspect.setInspectInspectDate(convertDateToSqlDate(parseDateLine(values[custInspectHeadPosition.getInspectInspectDate()])));
            } else {
                setLoadError("Ошибка в параметре:INSPECT_INSPECT_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_INSPECT_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_INSPECT_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //INSPECT_INSPECTOR
            if (custInspectHeadPosition.getInspectInspector() > -1) {
                custInspect.setInspectInspector(values[custInspectHeadPosition.getInspectInspector()]);
            } else {
                setLoadError("Не найден обязательный параметр:INSPECT_INSPECTOR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_INSPECTOR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_INSPECTOR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //INSPECT_NAME
            if (custInspectHeadPosition.getInspectName() > -1) {
                custInspect.setInspectName(values[custInspectHeadPosition.getInspectName()]);
            } else {
                setLoadError("Не найден обязательный параметр:INSPECT_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            //INSPECT_NOTES
            if (custInspectHeadPosition.getInspectNotes() > -1) {
                custInspect.setInspectNotes(values[custInspectHeadPosition.getInspectNotes()]);
            } else {
                setLoadError("Не найден обязательный параметр:INSPECT_NOTES", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_NOTES" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_NOTES: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        return new CheckCustInspect(custInspect, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
