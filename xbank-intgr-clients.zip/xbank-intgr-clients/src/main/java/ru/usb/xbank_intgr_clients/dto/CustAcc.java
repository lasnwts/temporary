package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTACC")
public class CustAcc {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "INSPECT_CUST_NMBR")//2
    private String inspectCustNmb;//CLIENT таблицы tbank.customer.csv

    @Column(name = "ACC_BANK_NUMB")//3
    private String accBankNumb;//Номер счета

    @Column(name = "ACC_BANK_OPEN_DATE")//4
    private Date accBankOpenDate;//Дата открытия счета

    @Column(name = "ACC_BANK_BIK")//5
    private String accBankBik;//БИК банка

    @Column(name = "ACC_BANK_CLOSE_DATE")//6
    private Date accBankCloseDate;//Дата закрытия

    @Column(name = "FILENAME")
    private String fileName;//7

    @Temporal(TemporalType.TIMESTAMP)//8
    @Column(name = "INPUT_DATE")
    private java.util.Date inputDate; //Имя файла

    @Column(name = "NUMINSERT")//9
    private long numInsert;//Дата внесения записи

}
