package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustemprHeadPosition {
    private int jobClient; //CLIENT таблицы tbank.customer.csv
    private int jobWorkStartDate;//Дата начала работы
    private int jobWorkPlaceName;//Имя работодателя
    private int jobMainJob;//"Основное место работы
    private int jobWorkPlaceOkved;    //Код ОКВЭД вида деятельности
    private int jobKindDocCode;//Код документа, подтверждающего трудовую деятельность
    private int jobWorkPosition;//Должность
    private int jobWorkPlaceInn;//ИНН места работы
    private int jobServiceLength;//Стаж на данном месте работы, месяцев
    private int jobTelOrg;    //Телефон организации
}
