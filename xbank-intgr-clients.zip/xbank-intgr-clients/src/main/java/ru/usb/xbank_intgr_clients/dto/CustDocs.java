package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTDOCS")
public class CustDocs {

    /**
     * id
     * CLIENT
     * DOC_TYPE
     * DOC_SER
     * DOC_NUM
     * DOC_WHO
     * DOC_PLACE
     * DOC_DATE
     * DOC_DATE_END
     * DOC_DEPART_CODE
     * DOC_MAIN
     * FILENAME
     * INPUT_DATE
     * id записи
     * CLIENT таблицы tbank.customer.csv
     * "ТИП ДОКУМЕНТА КЛИЕНТА
     * Вариатор 10015"
     * СЕРИЯ ДОКУМЕНТА
     * НОМЕР ДОКУМЕНТА
     * Кем выдан
     * МЕСТО ВЫДАЧИ
     * ДАТА ВЫДАЧИ
     * ДЕЙСТВИТЕЛЕН ДО
     * код подразделения
     * Основной индикатор
     * Имя файла
     * Дата внесения записи
     */

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID") //1 id записи
    private long id; //id записи

    @Column(name = "CLIENT")//2
    private String client;//CLIENT таблицы tbank.customer.csv

    @Column(name = "DOC_TYPE")//3
    private String docType;//ТИП ДОКУМЕНТА КЛИЕНТА

    @Column(name = "DOC_SER")//4
    private String docSer;//СЕРИЯ ДОКУМЕНТА

    @Column(name = "DOC_NUM")//5
    private String docNum;//НОМЕР ДОКУМЕНТА

    @Column(name = "DOC_WHO")//6
    private String docWho;//Кем выдан

    @Column(name = "DOC_PLACE")//7
    private String docPlace;//МЕСТО ВЫДАЧИ

    @Column(name = "DOC_DATE")//8
    private java.sql.Date docDate;//ДАТА ВЫДАЧИ

    @Column(name = "DOC_DATE_END")//9 26.11.2024 Изменения DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе  - оставить без изменений
    private java.sql.Date docDateEnd;//ДЕЙСТВИТЕЛЕН ДО

    @Column(name = "DOC_DATE_END_M")//9 26.11.2024 Изменения DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе  - оставить без изменений
    private java.sql.Date docDateEndM;//ДЕЙСТВИТЕЛЕН ДО

    @Column(name = "DOC_DEPART_CODE")//10
    private String docDepartCode;//код подразделения

    @Column(name = "DOC_MAIN")//11
    private String docMain;//Основной индикатор

    @Column(name = "FILENAME")//12
    private String fileName;//Имя файла

    @Temporal(TemporalType.TIMESTAMP)
//     @Column(name = "INPUT_DATE", length = 19)//13
    @Column(name = "INPUT_DATE")//13
    private Date inputDate;//Дата внесения записи

    @Column(name = "NUMINSERT") //14
    private long numInsert; //14 номер вставки, он уникальный для всего набора

}
