package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.Customer;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustomer;
import ru.usb.xbank_intgr_clients.model.CustomerHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.util.Date;

@Log4j2
@Component
public class CustomerMapper {

    private final Support support;

    @Autowired
    public CustomerMapper(Support support) {
        this.support = support;
    }

    private static final String COMMA_DELIMITER = ";";

    //CLIENT;NAME;DATE_PERS;BORN_PLACE;REG_STATUS;AGREE_ADVERT;AGREE_SELL;RESIDENT;COUNTRY_CODE;INN;SEX_CODE;MARIGE_STATUS_CODE;DECL_NAME;DECL_CASE_GR_CODE;LEV_EDUC_CODE;WEL
    public CheckCustomer map(String line, CustomerHeadPosition customerHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        Customer customer = new Customer();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());

        //Константы
        customer.setFileName(fileName);
        customer.setNuminsert(numInsert);
        customer.setInputDate(new Date());

        try {
            if (customerHeadPosition.getClient() > -1) {
                customer.setClient(values[customerHeadPosition.getClient()]);
            } else setLoadError("Не найден обязательный параметр:CLIENT", loadError);
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getName() > -1) {
                customer.setName(values[customerHeadPosition.getName()]);
            } else {
                setLoadError("Не найден обязательный параметр:NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getDatePers() > -1 && support.checkDate(values[customerHeadPosition.getDatePers()])) {
                customer.setDatePers(support.convertDateToSqlDate(support.parseDate(values[customerHeadPosition.getDatePers()])));
            } else {
                setLoadError("Ошибка в параметре:DATE_PERS", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_PERS" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_PERS: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (customerHeadPosition.getBornPlace() > -1) {
                customer.setBornPlace(values[customerHeadPosition.getBornPlace()]);
            } else {
                setLoadError("Не найден обязательный параметр:BORN_PLACE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:BORN_PLACE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:BORN_PLACE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getRegStatus() > -1) {
                customer.setRegStatus(values[customerHeadPosition.getRegStatus()]);
            } else {
                setLoadError("Не найден обязательный параметр:REG_STATUS", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:REG_STATUS" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:REG_STATUS: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getAgreeAdvert() > -1 && support.checkInt(values[customerHeadPosition.getAgreeAdvert()])) {
                customer.setAgreeAdvert(support.parseInt(values[customerHeadPosition.getAgreeAdvert()]));
            } else {
                setLoadError("Ошибка в параметре:AGREE_ADVERT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AGREE_ADVERT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AGREE_ADVERT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (customerHeadPosition.getAgreeSell() > -1 && support.checkInt(values[customerHeadPosition.getAgreeSell()])) {
                customer.setAgreeSell(support.parseInt(values[customerHeadPosition.getAgreeSell()]));
            } else {
                setLoadError("Ошибка в параметре:AGREE_SELL", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AGREE_SELL" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AGREE_SELL: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (customerHeadPosition.getResident() > -1) {
                customer.setResident(values[customerHeadPosition.getResident()]);
            } else {
                setLoadError("Не найден обязательный параметр:RESIDENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:RESIDENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:RESIDENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getCountryCode() > -1 && support.checkInt(values[customerHeadPosition.getCountryCode()])) {
                customer.setCountryCode(support.parseInt(values[customerHeadPosition.getCountryCode()]));
            } else {
                setLoadError("Ошибка в параметре:COUNTRY_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:COUNTRY_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:COUNTRY_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getInn() > -1) {
                customer.setInn(values[customerHeadPosition.getInn()]);
            } else {
                setLoadError("Не найден обязательный параметр:INN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INN" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INN: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (customerHeadPosition.getSexCode() > -1) {
                customer.setSexCode(values[customerHeadPosition.getSexCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:SEX_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SEX_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SEX_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (customerHeadPosition.getMarigeStatusCode() > -1) {
                customer.setMarigeStatusCode(values[customerHeadPosition.getMarigeStatusCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:MARIGE_STATUS_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:MARIGE_STATUS_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:MARIGE_STATUS_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getDeclName() > -1) {
                customer.setDeclName(values[customerHeadPosition.getDeclName()]);
            } else {
                setLoadError("Не найден обязательный параметр:DECL_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DECL_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DECL_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getDeclCaseGrCode() > -1) {
                customer.setDeclCaseGrCode(values[customerHeadPosition.getDeclCaseGrCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:DECL_CASE_GR_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DECL_CASE_GR_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DECL_CASE_GR_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getLevEducCode() > -1) {
                customer.setLevEducCode(values[customerHeadPosition.getLevEducCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:LEV_EDUC_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:LEV_EDUC_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:LEV_EDUC_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (customerHeadPosition.getWel() > -1 && support.checkInt(values[customerHeadPosition.getWel()])) {
                customer.setWell(support.parseInt(values[customerHeadPosition.getWel()]));
            } else {
                setLoadError("Ошибка в параметре:WEL", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:WEL" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:WEL: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        return new CheckCustomer(customer, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }


}

