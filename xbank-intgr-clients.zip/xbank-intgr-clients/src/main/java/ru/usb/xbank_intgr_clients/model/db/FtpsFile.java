package ru.usb.xbank_intgr_clients.model.db;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class FtpsFile {
    private String name;
    private long size;
}
