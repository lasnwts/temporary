package ru.usb.xbank_intgr_clients.dto.check;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_clients.dto.CustSoc;
import ru.usb.xbank_intgr_clients.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckCustSoc {
    private CustSoc custSoc;
    private LoadError loadError; //Ошибки
}
