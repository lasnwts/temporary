package ru.usb.xbank_intgr_clients.dto;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * •	tbank.customer.csv	Информация о клиенте
 * •	tbank.custacc.csv	Информация о счетах
 * •	tbank.custaddrs.csv	Информация об адресе
 * •	tbank.custcont.csv	Информация о телефоне
 * •	tbank.custdocs.csv	Информация о документах клиента
 * •	tbank.custempr.csv	Информация о работе клиенте
 * •	tbank.custsoc.csv	Информация о соц. Фондах клиента
 * •	tbank.custinspect.csv	Информация о налоговых инспекциях
 * •	tbank.custreqs.csv	Информация о дополнительных реквизитах
 * •	tbank.custrisk.csv	Информация о группе риска клиента
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTOMER")
public class Customer {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "CLIENT")
    private String client; //2

    @Column(name = "DATE_PERS")
    private java.sql.Date datePers; //3

    @Column(name = "MARIGE_STATUS_CODE")
    private String marigeStatusCode; //4

    @Column(name = "NAME")
    private String name; //5

    @Column(name = "SEX_CODE")
    private String sexCode; //6

    @Column(name = "INN")
    private String inn; //7

    @Column(name = "RESIDENT")
    private String resident; //8

    @Column(name = "BORN_PLACE")
    private String bornPlace; //9

    @Column(name = "AGREE_ADVERT")
    private int agreeAdvert; //10

    @Column(name = "AGREE_SELL")
    private int agreeSell; //11

    @Column(name = "COUNTRY_CODE")
    private int countryCode; //12

    @Column(name = "WELL")
    private int well; //13

    @Column(name = "REG_STATUS")
    private String regStatus; //14

    @Column(name = "DECL_NAME")
    private String declName; //15

    @Column(name = "DECL_CASE_GR_CODE")
    private String declCaseGrCode; //16

    @Column(name = "LEV_EDUC_CODE")
    private String levEducCode; //17

    @Column(name = "PROCESSED")
    private String processed; //18

    @Column(name = "PROCESSED_TEXT")
    private String processedText; //19

    @Column(name = "FILENAME")
    private String fileName; //20

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INPUT_DATE")
    private Date inputDate; //21

    @Column(name = "NUMINSERT") //22
    private long numinsert; //22 номер вставки, он уникальный для всего набора

}
