package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustSocHeadPosition {
    private int socCusrNmb;
    private int socDateReg;
    private int socFoundCode;
    private int socFound;
    private int socFoundNum;
}
