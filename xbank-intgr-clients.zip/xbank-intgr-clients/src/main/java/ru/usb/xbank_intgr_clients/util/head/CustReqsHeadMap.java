package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustReqsHeadPosition;

@Component
public class CustReqsHeadMap {

    private static final String COMMA_DELIMITER = ";";


    //REQS_CUSTNUMB;DATE_CHNG_NAME;CHILDREN_COUNT;DEPENDANTS_COUNT;FAMILY_MEMBERS;PREV_LAST_NAME;REASON_CHNG_NAME;OCCUPATION_STATE

    /**
     * Маппинг строки
     * @param line - строка
     * @return - объект
     */
    public CustReqsHeadPosition map(String line){
        String[] values = line.split(COMMA_DELIMITER);
        CustReqsHeadPosition custReqsHeadPosition = new CustReqsHeadPosition();
        custReqsHeadPosition.setReqsCustNumb(getPosition("REQS_CUSTNUMB", values));
        custReqsHeadPosition.setDateChngName(getPosition("DATE_CHNG_NAME", values));
        custReqsHeadPosition.setChildrenCount(getPosition("CHILDREN_COUNT", values));
        custReqsHeadPosition.setDependantsCount(getPosition("DEPENDANTS_COUNT", values));
        custReqsHeadPosition.setFamilyMembers(getPosition("FAMILY_MEMBERS", values));
        custReqsHeadPosition.setPrevLastName(getPosition("PREV_LAST_NAME", values));
        custReqsHeadPosition.setReasonChngName(getPosition("REASON_CHNG_NAME", values));
        custReqsHeadPosition.setOccupationState(getPosition("OCCUPATION_STATE", values));
        return custReqsHeadPosition;
    }



    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
