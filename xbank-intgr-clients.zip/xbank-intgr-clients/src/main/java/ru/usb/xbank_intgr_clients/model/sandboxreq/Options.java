package ru.usb.xbank_intgr_clients.model.sandboxreq;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class Options {
    @JsonProperty("analysis_depth")
    private int analysisDepth;
    @JsonProperty("sandbox")
    private Sandbox sandbox;
    @JsonProperty("mark_suspicious_files_options")
    private MarkSuspiciousFilesOptions markSuspiciousFilesOptions;
}
