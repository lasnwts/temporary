package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTSOC")
public class CustSoc {

    /**
     * SOC_CUSR_NMBR	VARCHAR2(255 CHAR)	CLIENT таблицы tbank.customer.csv
     * SOC_DATE_REG	VARCHAR2(255 CHAR)	Дата регистрации в фонде;
     * SOC_FOUND_CODE	VARCHAR2(255 CHAR)	Фонд. Код;
     * SOC_FOUND	VARCHAR2(255 CHAR)	Фонд. Наименование
     * SOC_FOUND_NUM	VARCHAR2(255 CHAR)	Фондовый номер клиента.
     * FILENAME	VARCHAR2(255 CHAR)	Имя файла
     * INPUT_DATE	TIMESTAMP(6)	Дата внесения записи
     */

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    //CLIENT таблицы tbank.customer.csv
    @Column(name = "SOC_CUSR_NMBR")//2
    private String socCusrNmb;

    //Дата регистрации в фонде
    @Column(name = "SOC_DATE_REG")//3
    private Date socDateReg;

    //Фонд. Код
    @Column(name = "SOC_FOUND_CODE")//4
    private String socFoundCode;

    //Фонд. Наименование
    @Column(name = "SOC_FOUND")//5
    private String socFound;

    //Фондовый номер клиента.
    @Column(name = "SOC_FOUND_NUM")//6
    private String socFoundNum;

    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки


}
