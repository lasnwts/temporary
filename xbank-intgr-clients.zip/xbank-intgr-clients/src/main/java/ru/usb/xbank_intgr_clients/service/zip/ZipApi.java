package ru.usb.xbank_intgr_clients.service.zip;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.util.Support;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Класс для сервиса распаковки
 */

@Log4j2
@Service
public class ZipApi {

    private final Support support;

    @Autowired
    public ZipApi(Support support) {
        this.support = support;
    }

    /**
     * Упаковка единичного файла, ZIP
     *
     * @param fileTozip - Имя файла, который надо упаковать в ZIP
     * @param zipFile   - Имя файла архива
     * @throws IOException - исключение ввода-вывода
     */
    public void zipFile(String fileTozip, String zipFile) throws IOException {
        log.info("{}: Упаковка в архив zip=> ZipAPI.ZipFile file:{} -> zipFile:{}", LG.USBLOGINFO, fileTozip, zipFile);
        FileOutputStream fos = new FileOutputStream(zipFile);
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        File fileToZip = new File(fileTozip);
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        zipOut.close();
        fis.close();
        fos.close();
    }


    /**
     * Метод распаковки архива ZIP
     * //        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), Charset.forName("windows-1251"))
     *
     * @param fileZip       - файл который надо распаковать (полный путь с именем)
     * @param directoryName - директории (сетевой каталог) куда будет распакован файл архива
     * @throws IOException - исключение ввода-вывода
     */
    public Optional<List<Path>> unzipFile(String fileZip, String directoryName, String fileName) throws Exception {
        log.info("{}: Распаковка архива => ZipApi.UnzipFile file:{} в каталог:{}", LG.USBLOGINFO, fileZip, directoryName);
        File destDir = new File(directoryName);
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip), Charset.forName("CP866"));
        FileOutputStream fos = null;
        ZipEntry zipEntry;
        File newFile = null;
        File parent = null;
        try {
            zipEntry = zis.getNextEntry();
            while (zipEntry != null) {
                newFile = newFile(destDir, zipEntry);
                if (zipEntry.isDirectory()) {
                    if (!newFile.isDirectory() && !newFile.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + newFile);
                    }
                } else {
                    // fix for Windows-created archives
                    parent = newFile.getParentFile();
                    if (!parent.isDirectory() && !parent.mkdirs()) {
                        throw new IOException("WorkWithFile::UnzipFile::Failed to create directory " + parent);
                    }
                    // write file content
                    fos = new FileOutputStream(newFile);
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.close();
                }
                zipEntry = zis.getNextEntry();
            }
            zis.closeEntry();
            zis.close();
        } catch (Exception e) {
            String error = "Ошибка при распаковке архива:" + fileZip + " в каталог:" + directoryName + "Error:" + e.getMessage();
            try {
                zis.closeEntry();
            } catch (Exception e2) {
                log.error("{}:Ошибка при закрытии потоков[zis.closeEntry()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            try {
                zis.close();
            } catch (Exception e2) {
                log.error("{}:Ошибка при закрытии потоков[zis.close()]:{}Error:{}", LG.USBLOGERROR, fileZip, e2.getMessage());
            }
            log.error("{}:Ошибка при распаковке архива:{}Error:{}", LG.USBLOGERROR, fileZip, e.getMessage());
            if (zis != null) {
                zis.close();
            }
            if (fos != null) {
                fos.close();
            }
            if (newFile != null) {
                Files.deleteIfExists(newFile.toPath());
            }
            if (parent != null) {
                Files.deleteIfExists(parent.toPath());
            }
            if (destDir != null) {
                Files.deleteIfExists(destDir.toPath());
            }
            throw new Exception(error); //Передаем прерывание
        }
        //Удаляем файл архива
        try {
            Files.deleteIfExists(Paths.get(fileZip));
            log.info("{}:Удаление файла архива:{} Ok", LG.USBLOGINFO, fileZip);
        } catch (Exception delEx) {
            log.error("{} Ошибка при попытке удалить файл:{}, ошибка:{}", LG.USBLOGERROR, fileZip, delEx.getMessage());
        }

        //Готовим список файлов
        try (Stream<Path> list = Files.find(Paths.get(directoryName), Integer.MAX_VALUE, (filePath, fileAttr) -> fileAttr.isRegularFile())) {
            return Optional.of(list.collect(Collectors.toList()));
        } catch (IOException e) {
            log.error("{}:Ошибка при построении списка распакованных файлов в каталоге:{}Error:{}", LG.USBLOGERROR, directoryName, e.getMessage());
            return Optional.empty();
        }
    }


    /**
     * Вспомогательный класс.
     * Этот метод защищает от записи файлов в файловую систему вне целевой папки. Эта уязвимость называется ZipApi Slip,
     * почитать об этой уязвимости https://snyk.io/research/zip-slip-vulnerability
     *
     * @param destinationDir - Файл архива, с полным именем
     * @param zipEntry       - каталог (сетевая папка) куда будет распакован архив
     * @return - File (путь к файлу)
     * @throws IOException - исключение ввода-вывода
     */
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }
        return destFile;
    }

}
