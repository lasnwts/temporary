package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

//tbank.custinspect.csv
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTINSPECT")
public class CustInspect {

    //INSPECT_CUSR_NMBR;INSPECT_INSPECT_DATE;INSPECT_INSPECTOR;INSPECT_NAME;INSPECT_NOTES
    //CLIENT таблицы tbank.customer.csv
    //Дата регистрации
    //Инспектор
    //Номер налоговой инспекции
    //Примечания
    //Имя файла
    //Дата внесения записи
    //- в таблице tbank_custinspect поле  INSPECT_CUSR_NMBR  на INSPECT_CUST_NMBR

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "INSPECT_CUST_NMBR")//2 - в таблице tbank_custinspect поле  INSPECT_CUSR_NMBR  на INSPECT_CUST_NMBR
    private String inspectCusrNmb; //CLIENT таблицы tbank.customer.csv

    @Column(name = "INSPECT_INSPECT_DATE")//3
    private java.sql.Date inspectInspectDate;//Дата регистрации

    @Column(name = "INSPECT_INSPECTOR")//4
    private String inspectInspector;//Инспектор

    @Column(name = "INSPECT_NAME")//5
    private String inspectName;//Номер налоговой инспекции

    @Column(name = "INSPECT_NOTES")//6
    private String inspectNotes;//Примечания

    @Column(name = "FILENAME")//7
    private String fileName; //Имя файла

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INPUT_DATE")//8
    private Date inputDate; //Дата внесения записи

    @Column(name = "NUMINSERT") //9
    private long numInsert; //номер вставки, он уникальный для всего набора
}
