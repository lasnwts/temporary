package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustInspectHeadPosition;

@Component
public class CustInspectHeadMap {
    private static final String COMMA_DELIMITER = ";";

    //INSPECT_CUSR_NMBR;INSPECT_INSPECT_DATE;INSPECT_INSPECTOR;INSPECT_NAME;INSPECT_NOTES
    public CustInspectHeadPosition map(String line){
        String[] values = line.split(COMMA_DELIMITER);
        CustInspectHeadPosition  custInspectHeadPosition = new CustInspectHeadPosition();
        custInspectHeadPosition.setInspectCusrNmb(getPosition("INSPECT_CUSR_NMBR", values));
        custInspectHeadPosition.setInspectInspectDate(getPosition("INSPECT_INSPECT_DATE", values));
        custInspectHeadPosition.setInspectInspector(getPosition("INSPECT_INSPECTOR", values));
        custInspectHeadPosition.setInspectName(getPosition("INSPECT_NAME", values));
        custInspectHeadPosition.setInspectNotes(getPosition("INSPECT_NOTES", values));
        return custInspectHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
