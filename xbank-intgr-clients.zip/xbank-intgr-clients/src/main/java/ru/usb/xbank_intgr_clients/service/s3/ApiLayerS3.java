package ru.usb.xbank_intgr_clients.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;


import java.io.File;

@Log4j2
@Component
public class ApiLayerS3 {

    private final AmazonS3Service amazonS3Service;

    @Autowired
    public ApiLayerS3(AmazonS3Service amazonS3Service) {
        this.amazonS3Service = amazonS3Service;
    }

    /**
     * Сохранение файла в бакет
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToS3(String bucketName, String key, File file, long thread) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, key, file, thread) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error[saveFileToS3]: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }


    /**
     * Удаление файла из бакета
     * @param bucketName - имя бакета
     * @param key - имя файла
     * @param thread - номер потока
     * @return - HTTPStatus
     * @throws Exception - исключение
     */
    public HttpStatus deleteFileS3(String bucketName, String key, long thread) throws Exception {
        try {
            return amazonS3Service.deleteFile(bucketName, key, thread);
        } catch (Exception e) {
            log.error("{}:[deleteFileS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error[deleteFileS3]: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Копирование файла в бакет
     *
     * @param sourceBucket      - имя исходного бакета
     * @param sourceKey         - имя исходного файла
     * @param destinationBucket - имя бакета назначения
     * @param destinationKey    - имя файла назначения
     * @return
     */
    public boolean copyFileS3(String sourceBucket, String sourceKey, String destinationBucket, String destinationKey, long thread){
        try {
            amazonS3Service.copyFile(sourceBucket, sourceKey, destinationBucket, destinationKey);
            return true;
        } catch (Exception e) {
            log.error("{}:T{}: [copyFileS3]:Error:{}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}: Error[copyFileS3]: stackTrace:", LG.USBLOGERROR, thread, e);
            return false;
        }
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    public HttpStatus getS3StatusCode(String line) {
        if (line == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return amazonS3Service.getStatusCode(line);
    }

}
