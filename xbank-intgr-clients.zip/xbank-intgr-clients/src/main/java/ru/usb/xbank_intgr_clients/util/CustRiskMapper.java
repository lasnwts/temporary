package ru.usb.xbank_intgr_clients.util;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustRisk;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustRisk;
import ru.usb.xbank_intgr_clients.model.CustRiskHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.util.Date;

@Log4j2
@Component
public class CustRiskMapper {

    private final Support support;

    private static final String COMMA_DELIMITER = ";";

    @Autowired
    public CustRiskMapper(Support support) {
        this.support = support;
    }


    //GR_CLIENT;GR_DATE_START;GR_DATE_END;GR_ACC_FEATURE;GR_GROUP_NUM;GR_CRED_GROUP_NUM;GR_SERVICE_QUAL;GR_PRC_RESERV;GR_FIX;GR_;GR_RESUME
    public CheckCustRisk map(String line, CustRiskHeadPosition custRiskHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        CustRisk custRisk = new CustRisk();
        //Константы
        custRisk.setFileName(fileName);
        custRisk.setNumInsert(numInsert);
        custRisk.setInputDate(new Date());

        try {
            //GR_CLIENT
            if (custRiskHeadPosition.getGrClient() > -1) {
                custRisk.setGrClient(values[custRiskHeadPosition.getGrClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:GR_CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_DATE_START
            if (custRiskHeadPosition.getGrDateStart() > -1 && support.checkDateLine(values[custRiskHeadPosition.getGrDateStart()])) {
                custRisk.setGrDateStart(support.convertDateToSqlDate(support.parseDateLine(values[custRiskHeadPosition.getGrDateStart()])));
            } else {
                setLoadError("Ошибка в параметре:GR_DATE_START", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_DATE_START" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_DATE_START: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_DATE_END
            if (custRiskHeadPosition.getGrDateEnd() > -1 && support.checkDateLine(values[custRiskHeadPosition.getGrDateEnd()])) {
                custRisk.setGrDateEnd(support.convertDateToSqlDate(support.parseDateLine(values[custRiskHeadPosition.getGrDateEnd()])));
            } else {
                setLoadError("Ошибка в параметре:GR_DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_DATE_END" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_DATE_END: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_ACC_FEATURE
            if (custRiskHeadPosition.getGrAccFeature() > -1 && support.checkInt(values[custRiskHeadPosition.getGrAccFeature()])) {
                custRisk.setGrAccFeature(support.parseInt(values[custRiskHeadPosition.getGrAccFeature()]));
            } else {
                setLoadError("Ошибка в параметре:GR_ACC_FEATURE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_ACC_FEATURE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_ACC_FEATURE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_GROUP_NUM
            if (custRiskHeadPosition.getGrGroupNum() > -1 && support.checkInt(values[custRiskHeadPosition.getGrGroupNum()])) {
                custRisk.setGrGroupNum(support.parseInt(values[custRiskHeadPosition.getGrGroupNum()]));
            } else {
                setLoadError("Ошибка в параметре:GR_GROUP_NUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_GROUP_NUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_GROUP_NUM: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_CRED_GROUP_NUM
            if (custRiskHeadPosition.getGrCredGroupNum() > -1 && support.checkInt(values[custRiskHeadPosition.getGrCredGroupNum()])) {
                custRisk.setGrCredGroupNum(support.parseInt(values[custRiskHeadPosition.getGrCredGroupNum()]));
            } else {
                setLoadError("Ошибка в параметре:GR_CRED_GROUP_NUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_CRED_GROUP_NUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_CRED_GROUP_NUM: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_SERVICE_QUAL
            if (custRiskHeadPosition.getGrServiceQual() > -1 && support.checkInt(values[custRiskHeadPosition.getGrServiceQual()])) {
                custRisk.setGrServiceQual(support.parseInt(values[custRiskHeadPosition.getGrServiceQual()]));
            } else {
                setLoadError("Ошибка в параметре:GR_SERVICE_QUAL", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_SERVICE_QUAL" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_SERVICE_QUAL: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_PRC_RESERV
            if (custRiskHeadPosition.getGrPrcReserv() > -1) {
                custRisk.setGrPrcReserv(values[custRiskHeadPosition.getGrPrcReserv()]);
            } else {
                setLoadError("Ошибка в параметре:GR_PRC_RESERV", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_PRC_RESERV" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_PRC_RESERV: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_FIX
            if (custRiskHeadPosition.getGrFix() > -1) {
                custRisk.setGrFix(values[custRiskHeadPosition.getGrFix()]);
            } else {
                setLoadError("Ошибка в параметре:GR_FIX", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_FIX" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_FIX: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_
            if (custRiskHeadPosition.getGr() > -1) {
                custRisk.setGr(values[custRiskHeadPosition.getGr()]);
            } else {
                setLoadError("Ошибка в параметре:GR_PEOPLE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_PEOPLE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_PEOPLE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //GR_RESUME
            if (custRiskHeadPosition.getGrResume() > -1) {
                custRisk.setGrResume(values[custRiskHeadPosition.getGrResume()]);
            } else {
                setLoadError("Ошибка в параметре:GR_RESUME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:GR_RESUME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:GR_RESUME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        return new CheckCustRisk(custRisk, loadError);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
