package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustSocHeadPosition;

@Component
public class CustSocHeadMap {

    private static final String COMMA_DELIMITER = ";";

    //SOC_CUSR_NMBR;SOC_DATE_REG;SOC_FOUND_CODE;SOC_FOUND;SOC_FOUND_NUM

    /**
     * Маппинг строки
     * @param line - строка
     * @return - объект
     */
    public CustSocHeadPosition map(String line) {
        String[] values = line.split(COMMA_DELIMITER);
        CustSocHeadPosition custSocHeadPosition = new CustSocHeadPosition();
        custSocHeadPosition.setSocCusrNmb(getPosition("SOC_CUSR_NMBR", values));
        custSocHeadPosition.setSocDateReg(getPosition("SOC_DATE_REG", values));
        custSocHeadPosition.setSocFoundCode(getPosition("SOC_FOUND_CODE", values));
        custSocHeadPosition.setSocFound(getPosition("SOC_FOUND", values));
        custSocHeadPosition.setSocFoundNum(getPosition("SOC_FOUND_NUM", values));
        return custSocHeadPosition;
    }
    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
