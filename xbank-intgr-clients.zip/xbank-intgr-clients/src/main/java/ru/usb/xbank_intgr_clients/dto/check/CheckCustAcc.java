package ru.usb.xbank_intgr_clients.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_clients.dto.CustAcc;
import ru.usb.xbank_intgr_clients.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckCustAcc {
    private CustAcc custacc;
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация
}
