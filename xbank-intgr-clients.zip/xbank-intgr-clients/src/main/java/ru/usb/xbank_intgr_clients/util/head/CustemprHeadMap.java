package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustemprHeadPosition;

@Component
public class CustemprHeadMap {

    private static final String COMMA_DELIMITER = ";";

    //JOB_CLIENT;JOB_WORK_START_DATE;JOB_WORK_PLACE_NAME;JOB_MAIN_JOB;JOB_WORK_PLACE_OKVED;JOB_KIND_DOC_CODE;JOB_WORK_POSITION;JOB_WORK_PLACE_INN;JOB_SERVICE_LENGTH;JOB_TEL_ORG

    public CustemprHeadPosition map(String line){
        String[] values = line.split(COMMA_DELIMITER);
        CustemprHeadPosition  custemprHeadPosition = new CustemprHeadPosition();
        custemprHeadPosition.setJobClient(getPosition("JOB_CLIENT", values));
        custemprHeadPosition.setJobWorkStartDate(getPosition("JOB_WORK_START_DATE", values));
        custemprHeadPosition.setJobWorkPlaceName(getPosition("JOB_WORK_PLACE_NAME", values));
        custemprHeadPosition.setJobMainJob(getPosition("JOB_MAIN_JOB", values));
        custemprHeadPosition.setJobWorkPlaceOkved(getPosition("JOB_WORK_PLACE_OKVED", values));
        custemprHeadPosition.setJobKindDocCode(getPosition("JOB_KIND_DOC_CODE", values));
        custemprHeadPosition.setJobWorkPosition(getPosition("JOB_WORK_POSITION", values));
        custemprHeadPosition.setJobWorkPlaceInn(getPosition("JOB_WORK_PLACE_INN", values));
        custemprHeadPosition.setJobServiceLength(getPosition("JOB_SERVICE_LENGTH", values));
        custemprHeadPosition.setJobTelOrg(getPosition("JOB_TEL_ORG", values));
        return custemprHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
