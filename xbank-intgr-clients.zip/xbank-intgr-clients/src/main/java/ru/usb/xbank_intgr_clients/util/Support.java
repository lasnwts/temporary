package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;

import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class Support {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    DateTimeFormatter sdfTimeStamp = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss,SSSSSS");

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    /**
     *      Переменные для проверки
     *      --------------------------------------------------------
     * tbank.custacc.csv
     * tbank.custaddrs.csv
     * tbank.custcont.csv
     * tbank.custdocs.csv
     * tbank.custempr.csv
     * tbank.custinspect.csv
     * tbank.customer.csv
     * tbank.custreqs.csv
     * tbank.custrisk.csv
     * tbank.custsoc.csv
     */

    /**
     * Проверка успешности загрузки файлов
     * @return - результат проверки
     */
    public boolean checkSuccessLoadFile(){

        //Проверяем успешномть загрузки
        if (configure.isCustacc() &&
                configure.isCustaddrs() &&
                configure.isCustcont() &&
                configure.isCustdocs() &&
                configure.isCustempr() &&
                configure.isCustinspect() &&
                configure.isCustomer() &&
                configure.isCustreqs() &&
                configure.isCustrisk() &&
                configure.isCustsoc()
        ){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Получение имени файла
     *
     * @param line - строка
     * @return - имя файла
     */
    public String getFileName(String line) {
        return FilenameUtils.getName(line);
    }


    /**
     * Проверка файла
     *
     * @param fileName - имя файла
     * @return - результат проверки
     */
    public boolean checkFileMask(String fileName){
        if (fileName == null || fileName.trim().length() < 12) return false;
        return fileName.substring(0, 9).equalsIgnoreCase(configure.getS3MaskFile()) &&
                getExtension(fileName).equalsIgnoreCase(configure.getS3ExtFile());
    }

    /**
     * Получение расширения файла
     *
     * @param line - строка
     * @return - расширение
     */
    public String getExtension(String line) {
        return FilenameUtils.getExtension(line);
    }


    /**
     * Очистка директории
     */
    public void cleanTempDirectory() {
        try {
            FileUtils.cleanDirectory(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + configure.getNetFileShare()).toFile());
        } catch (Exception e) {
            log.error("{}:Support.cleanTempDirectory:Ошибка при удалении директории {}", LG.USBLOGERROR, e.getMessage());
        }
    }



    /**
     * Получение описания ошибки
     * ----------------------------------
     * tbank.custacc.csv
     * tbank.custaddrs.csv
     * tbank.custcont.csv
     * tbank.custdocs.csv
     * tbank.custempr.csv
     * tbank.custinspect.csv
     * tbank.customer.csv
     * tbank.custreqs.csv
     * tbank.custrisk.csv
     * tbank.custsoc.csv
     * @return - описание ошибки
     */
    public String getDescLoad(){

        String result = "";

        if(configure.isCustacc()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custacc.csv \n";
        }
        if(configure.isCustaddrs()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custaddrs.csv \n";
        }
        if(configure.isCustcont()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custcont.csv \n";
        }
        if(configure.isCustdocs()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custdocs.csv \n";
        }
        if(configure.isCustempr()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custempr.csv \n";
        }
        if(configure.isCustinspect()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custinspect.csv \n";
        }
        if(configure.isCustomer()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.customer.csv \n";
        }
        if(configure.isCustreqs()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custreqs.csv \n";
        }
        if(configure.isCustrisk()){
            result = result + " Отсутствует или возникли проблемы с файлом  tbank.custrisk.csv \n";
        }
        if(configure.isCustsoc()){
            result = result + " Отсутствует или возникли проблемы с файлом tbank.custsoc.csv \n";
        }

        return result;
    }


    public boolean checkDateTimeStamp(String date) {
        try {
            LocalDateTime ldt = LocalDateTime.parse(date, sdfTimeStamp);
            if (ldt == null) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Проверка даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDate(String date) {
        return GenericValidator.isDate(date, "dd.MM.yyyy", true);
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDate(String date) {
        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDate:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Форматирование даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDate(Date date) {
        return sdf.format(date);
    }


    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    SimpleDateFormat numInsert = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    /**
     * Получение номера вставки
     * @return - номер вставки
     */
    public long getNumInsert(){
        return Long.parseLong(numInsert.format(new Date()));
    }


}

