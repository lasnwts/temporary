package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustomerHeadPosition;

@Component
public class CustomerHeadMap {

    //CLIENT;NAME;DATE_PERS;BORN_PLACE;REG_STATUS;AGREE_ADVERT;AGREE_SELL;RESIDENT;COUNTRY_CODE;INN;SEX_CODE;MARIGE_STATUS_CODE;DECL_NAME;DECL_CASE_GR_CODE;LEV_EDUC_CODE;WEL
    private static final String COMMA_DELIMITER = ";";

    public CustomerHeadPosition map(String line) {
        String[] values = line.split(COMMA_DELIMITER);
        CustomerHeadPosition customerHeadPosition = new CustomerHeadPosition();
        customerHeadPosition.setClient(getPosition("CLIENT", values));
        customerHeadPosition.setName(getPosition("NAME", values));
        customerHeadPosition.setDatePers(getPosition("DATE_PERS", values));
        customerHeadPosition.setBornPlace(getPosition("BORN_PLACE", values));
        customerHeadPosition.setRegStatus(getPosition("REG_STATUS", values));
        customerHeadPosition.setAgreeAdvert(getPosition("AGREE_ADVERT", values));
        customerHeadPosition.setAgreeSell(getPosition("AGREE_SELL", values));
        customerHeadPosition.setResident(getPosition("RESIDENT", values));
        customerHeadPosition.setCountryCode(getPosition("COUNTRY_CODE", values));
        customerHeadPosition.setInn(getPosition("INN", values));
        customerHeadPosition.setSexCode(getPosition("SEX_CODE", values));
        customerHeadPosition.setMarigeStatusCode(getPosition("MARIGE_STATUS_CODE", values));
        customerHeadPosition.setDeclName(getPosition("DECL_NAME", values));
        customerHeadPosition.setDeclCaseGrCode(getPosition("DECL_CASE_GR_CODE", values));
        customerHeadPosition.setLevEducCode(getPosition("LEV_EDUC_CODE", values));
        customerHeadPosition.setWel(getPosition("WEL", values));
        return customerHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }

}
