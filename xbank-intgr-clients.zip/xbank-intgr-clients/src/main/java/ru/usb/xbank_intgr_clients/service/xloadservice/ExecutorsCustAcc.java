package ru.usb.xbank_intgr_clients.service.xloadservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.LoadError;
import ru.usb.xbank_intgr_clients.service.loadfile.LoadCustAcc;


import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Executor service
 */
@Service
public class ExecutorsCustAcc {

    /**
     * host.timeout=60
     * host.delta=20
     */
    @Value("${host.timeout:60}")
    private long hostTimeOut;

    @Value("${host.delta:10}")
    private long delta;


    private final Configure configure;
    private final LoadCustAcc loadCustAcc;

    @Autowired
    public ExecutorsCustAcc(Configure configure, LoadCustAcc loadCustAcc) {
        this.configure = configure;
        this.loadCustAcc = loadCustAcc;
    }

    /**
     * инициализация: ExecutorService executorService = ExecutorsCustAcc.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    Logger log = LoggerFactory.getLogger(ExecutorsCustAcc.class);

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(Path path) {
        configure.setThreads(configure.getThreads() + 1);
        File file = path.toFile();
        log.info("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGERROR, Thread.currentThread().getId(), file.getName());
        log.info("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, file));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.info("{}:T{} Поток передан на запуск в executor service. Поток с файлом:{}", LG.USBLOGINFO, Thread.currentThread().getId(), file.getAbsolutePath());
    }

    class MyThread implements Runnable {
        File localFile;
        CountDownLatch latch;

        MyThread(CountDownLatch c, File file) {
            latch = c;
            localFile = file;
            new Thread(this);
        }

        public void run() {
            log.info("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());
            /**-
             * Основной процесс
             * @param value - сообщение из Кафка
             */
            log.info("{}:T{}: Поток запущен для обработки файла={}", LG.USBLOGINFO, Thread.currentThread().getId(), localFile.getAbsolutePath());
            List<LoadError> loadErrors = loadCustAcc.loadFile(localFile, Thread.currentThread().getId());
            if (!loadErrors.isEmpty()) {
                log.error("{}:T{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, Thread.currentThread().getId(), loadErrors.size());
                loadErrors.forEach(loadError -> log.info("{}:T{}:=: {}", LG.USBLOGERROR, Thread.currentThread().getId(), loadError));
            }
            configure.setLoadErrorListcustacc(loadErrors); //Какие возникли ошибки
            latch.countDown();
            //Подвал завершения потока
            log.info("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.info("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }
    }
}
