package ru.usb.xbank_intgr_clients.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustReqs;
import ru.usb.xbank_intgr_clients.model.CustReqsHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;
import ru.usb.xbank_intgr_clients.repository.CustReqsRepo;
import ru.usb.xbank_intgr_clients.util.CustReqsMapper;
import ru.usb.xbank_intgr_clients.util.Support;
import ru.usb.xbank_intgr_clients.util.head.CustReqsHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadCustReqs {

    private final Support support;
    private final CustReqsHeadMap custReqsHeadMap;
    private final CustReqsMapper custReqsMapper;
    private final CustReqsRepo custReqsRepo;

    @Autowired
    public LoadCustReqs(Support support, CustReqsHeadMap custReqsHeadMap, CustReqsMapper custReqsMapper, CustReqsRepo custReqsRepo) {
        this.support = support;
        this.custReqsHeadMap = custReqsHeadMap;
        this.custReqsMapper = custReqsMapper;
        this.custReqsRepo = custReqsRepo;
    }

    public List<LoadError> loadFile(File file, long thread) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadCustReqs, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}:T{}: Подготовка процесса: Load LoadCustReqs к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<CustReqsHeadPosition> custReqsHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadCustReqs, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("UTF-8"))) {
//        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                custReqsHeadPosition.set(custReqsHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckCustReqs checkCustReqs = custReqsMapper.map(line.trim(), custReqsHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}:T{}: CustReqs={}", LG.USBLOGINFO, thread, checkCustReqs.getCustReqs());
                                custReqsRepo.saveAndFlush(checkCustReqs.getCustReqs()); //сохраняем
                                if (checkCustReqs.getLoadError().isStatus()) {
                                    loadErrorList.add(checkCustReqs.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadCustReqs, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
        }
        try {
            if (Files.deleteIfExists(file.toPath())){
                log.info("{}:T{}: Файл {} удален", LG.USBLOGINFO, thread, file.getAbsolutePath());
            } else {
                log.info("{}:T{}: Файл {} не удален, возникла проблема при удалении.", LG.USBLOGINFO, thread, file.getAbsolutePath());
            }
        } catch (IOException e) {
            log.info("{}:T{}: Возникла ошибка при удалении файла:{}, ошибка:{}", LG.USBLOGINFO, thread, file.getAbsolutePath(), e.getMessage());
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadCustReqs. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread,((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

