package ru.usb.xbank_intgr_clients.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_clients.dto.CustInspect;
import ru.usb.xbank_intgr_clients.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckCustInspect {
    private CustInspect custInspect;
    private LoadError loadError; //Ошибки
}
