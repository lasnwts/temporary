package ru.usb.xbank_intgr_clients.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_clients.dto.Custempr;

public interface CustemprRepo extends JpaRepository<Custempr, Long>{
}
