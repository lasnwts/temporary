package ru.usb.xbank_intgr_clients.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import ru.usb.xbank_intgr_clients.model.sandbox.Errors;
import ru.usb.xbank_intgr_clients.model.sandboxresp.Result;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

/**
 * Реазудьтат получения файлов из факторинга
 * FacFile =)
 */
@Getter
@Setter
@NoArgsConstructor
public class FacFile {

    private String name; //имя файла
    private HttpStatus status; //статус загрузки
    private File file; //файл
    private String message; //сообщение по файлу, может и ошибки
    private String checkMessage; //сообщение о статусе проверки SandBox
    private int checkStatus; //статус проверки на SandBox
                        // 0 - еще не проверен
                        // 200 - передан на проверку, успешно
                        // 2 - в процессе проверки
                        // 3 - проблемы в процессе проверки
                        // -1 - файл не загружен
                        // 100 - файл успешно загружен
                        // 201 - проверен успешно
                        // 300 - ошибка в процессе проверки
                        // 400 - ошибка в процессе передачи на проверку
                        // 600 - ошибка сервис содержит вирус
    @JsonProperty("fileUri")
    private String fileUri; //URI SandBox для проверки файла
    private ArrayList<Errors> errors; //Описание ошибки при проверке
    private Date date; //Дата последней операции по файлу
    private Result result; //результат проверки

    public FacFile(String name, HttpStatus status, File file, String message, String checkMessage, int checkStatus) {
        this.name = name;
        this.status = status;
        this.file = file;
        this.message = message;
        this.checkMessage = checkMessage;
        this.checkStatus = checkStatus;
    }

    @Override
    public String toString() {
        return "FacFile{" +
                "name='" + name + '\'' +
                ", status=" + status +
                ", file.size=" + file.length() +
                ", file.path=" + file.getAbsolutePath() +
                ", message='" + message + '\'' +
                ", checkMessage='" + checkMessage + '\'' +
                ", checkStatus=" + checkStatus +
                ", fileUri='" + fileUri + '\'' +
                '}';
    }
}
