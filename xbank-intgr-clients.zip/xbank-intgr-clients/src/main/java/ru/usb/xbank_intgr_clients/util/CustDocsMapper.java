package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustAcc;
import ru.usb.xbank_intgr_clients.dto.CustDocs;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustAcc;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustDocs;
import ru.usb.xbank_intgr_clients.model.CustDocsHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;


@Log4j2
@Component
public class CustDocsMapper {

    private final Configure configure;

    @Autowired
    public CustDocsMapper(Configure configure) {
        this.configure = configure;
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    private static final String COMMA_DELIMITER = ";";

    /**
     * CLIENT	VARCHAR2(255 CHAR)
     * DOC_TYPE	VARCHAR2(255 CHAR)
     * DOC_SER	VARCHAR2(255 CHAR)
     * DOC_NUM	VARCHAR2(255 CHAR)
     * DOC_WHO	VARCHAR2(255 CHAR)
     * DOC_PLACE	VARCHAR2(255 CHAR)
     * DOC_DATE	DATE
     * DOC_DATE_END	DATE
     * DOC_DEPART_CODE	VARCHAR2(255 CHAR)
     * DOC_MAIN	VARCHAR2(255 CHAR)
     * FILENAME	VARCHAR2(255 CHAR)
     * INPUT_DATE	TIMESTAMP(6)
     */

    public CheckCustDocs map(String line, CustDocsHeadPosition custDocsHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);

        //Пустая срока
        if (values.length < 5) {
            return new CheckCustDocs(new CustDocs(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }


        CustDocs custDocs = new CustDocs();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        custDocs.setFileName(configure.getArchiveName());
        custDocs.setNumInsert(numInsert);
        custDocs.setInputDate(new Date());


        //Переменные для 26.11.2024 Изменения DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе  - оставить без изменений
        java.sql.Date dateEndSqlDate = null; //DOC_DATE_END
        String docMain = null; //DOC_MAIN


        try {
            if (custDocsHeadPosition.getClient() > -1) {
                custDocs.setClient(values[custDocsHeadPosition.getClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocType() > -1) {
                custDocs.setDocType(values[custDocsHeadPosition.getDocType()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocSer() > -1) {
                custDocs.setDocSer(values[custDocsHeadPosition.getDocSer()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_SER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_SER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_SER: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocNum() > -1) {
                custDocs.setDocNum(values[custDocsHeadPosition.getDocNum()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_NUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_NUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_NUM: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocWho() > -1) {
                custDocs.setDocWho(values[custDocsHeadPosition.getDocWho()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_WHO", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_WHO" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_WHO: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocPlace() > -1) {
                custDocs.setDocPlace(values[custDocsHeadPosition.getDocPlace()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_PLACE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_PLACE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_PLACE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (custDocsHeadPosition.getDocDate() > -1 && checkDateLine(values[custDocsHeadPosition.getDocDate()])) {
                custDocs.setDocDate(convertDateToSqlDate(parseDateLine(values[custDocsHeadPosition.getDocDate()])));
            } else {
                setLoadError("Ошибка в параметре:DOC_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocDateEnd() > -1 && checkDateLine(values[custDocsHeadPosition.getDocDateEnd()])) {
                dateEndSqlDate = convertDateToSqlDate(parseDateLine(values[custDocsHeadPosition.getDocDateEnd()]));
                custDocs.setDocDateEnd(dateEndSqlDate);
            } else {
                setLoadError("Ошибка в параметре:DOC_DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_DATE_END" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_DATE_END: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocDepartCode() > -1) {
                custDocs.setDocDepartCode(values[custDocsHeadPosition.getDocDepartCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_DEPART_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_DEPART_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_DEPART_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custDocsHeadPosition.getDocMain() > -1) {
                docMain = values[custDocsHeadPosition.getDocMain()];
                custDocs.setDocMain(docMain);
            } else {
                setLoadError("Не найден обязательный параметр:DOC_MAIN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DOC_MAIN" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DOC_MAIN: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        //Новое поле
        //большая просьба на интеграции  или в конвертации добавить проверку (очень просят коллеги Ритейл):
        // Если документ (custdocs) имеет DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе  - оставить без изменений
        //Можно сделать по аналогии с департаментами - при загрузке файла docs есть поле DOC_DATE_END
        //Нам нужно добавить еще один столбец например DOC_DATE_END_M  и в него загонять данные по логике
        //1.  Если в строке custdocs есть DOC_MAIN = 1, то записать в DOC_DATE_END_M  = ‘’ (пусто)
        //2.  Иначе записать в DOC_DATE_END_M = DOC_DATE_END
        //И на конвертации в поле значение поля DOC_DATE_END_M в БД передать в столбец DOC_DATE_END в файл csv
        custDocs.setDocDateEndM(getDateEndM(docMain, dateEndSqlDate)); //Установка

        return new CheckCustDocs(custDocs, loadError, true);
    }


    /**
     * Получение даты окончания документа
     * 26.11.2024 Изменения DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе - оставить без изменений
     *
     * @param docMain    - основание документа
     * @param docDateEnd - дата окончания документа
     * @return - дата окончания документа
     */
    private java.sql.Date getDateEndM(String docMain, java.sql.Date docDateEnd) {
        if (docMain != null && docMain.equals("1")) {
            return null; //Если не 1, то пусто
        } else {
            return docDateEnd;
        }
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        if (date.contains(".")){
            date = date.replace(".", "/");
        }
        if (date.contains("-")){
            date = date.replace("-", "/");
        }

        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            if (date.contains(".")){
                date = date.replace(".", "/");
            }
            if (date.contains("-")){
                date = date.replace("-", "/");
            }

            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
