package ru.usb.xbank_intgr_clients.util;


import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustAcc;
import ru.usb.xbank_intgr_clients.dto.Custempr;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustAcc;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustempr;
import ru.usb.xbank_intgr_clients.model.CustemprHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class CustemprMapper {

    private final Configure configure;

    @Autowired
    public CustemprMapper(Configure configure) {
        this.configure = configure;
    }

    private static final String COMMA_DELIMITER = ";";

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        if (date.contains(".")){
            date = date.replace(".", "/");
        }
        if (date.contains("-")){
            date = date.replace("-", "/");
        }

        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            if (date.contains(".")){
                date = date.replace(".", "/");
            }
            if (date.contains("-")){
                date = date.replace("-", "/");
            }

            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Маппинг строки файла в объект Custempr
     * @param line - строка файла
     * @param custemprHeadPosition - позиция заголовков в файле
     * @param fileName - имя файла
     * @param numInsert - номер записи в файле
     * @param lineNumber - номер строки в файле
     * @return - объект Custempr с ошибками загрузки
     */
    public CheckCustempr map(String line, CustemprHeadPosition custemprHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);

        //Пустая срока
        if (values.length < 5) {
            return new CheckCustempr(new Custempr(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        Custempr custempr = new Custempr();
        //Константы
        custempr.setFilename(configure.getArchiveName());
        custempr.setInputDate(new Date());
        custempr.setNumInsert(numInsert);

        try {
            if (custemprHeadPosition.getJobClient() > -1) {
                custempr.setJobClient(values[custemprHeadPosition.getJobClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobWorkStartDate() > -1 && checkDateLine(values[custemprHeadPosition.getJobWorkStartDate()])) {
                custempr.setJobWorkStartDate(convertDateToSqlDate(parseDateLine(values[custemprHeadPosition.getJobWorkStartDate()])));
            } else {
                setLoadError("Ошибка в параметре:JOB_WORK_START_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_WORK_START_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_WORK_START_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobWorkPlaceName() > -1) {
                custempr.setJobWorkPlaceName(values[custemprHeadPosition.getJobWorkPlaceName()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_WORK_PLACE_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_WORK_PLACE_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_WORK_PLACE_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobMainJob() > -1) {
                custempr.setJobMainJob(values[custemprHeadPosition.getJobMainJob()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_MAIN_JOB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_MAIN_JOB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_MAIN_JOB: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobWorkPlaceOkved() > -1) {
                custempr.setJobWorkPlaceOkved(values[custemprHeadPosition.getJobWorkPlaceOkved()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_WORK_PLACE_OKVED", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_WORK_PLACE_OKVED" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_WORK_PLACE_OKVED: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobKindDocCode() > -1) {
                custempr.setJobKindDocCode(values[custemprHeadPosition.getJobKindDocCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_KIND_DOC_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_KIND_DOC_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_KIND_DOC_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobWorkPosition() > -1) {
                custempr.setJobWorkPosition(values[custemprHeadPosition.getJobWorkPosition()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_WORK_POSITION", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_WORK_POSITION" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_WORK_POSITION: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobWorkPlaceInn() > -1) {
                custempr.setJobWorkPlaceInn(values[custemprHeadPosition.getJobWorkPlaceInn()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_WORK_PLACE_INN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_WORK_PLACE_INN" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_WORK_PLACE_INN: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobServiceLength() > -1) {
                custempr.setJobServiceLength(values[custemprHeadPosition.getJobServiceLength()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_SERVICE_LENGTH", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_SERVICE_LENGTH" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_SERVICE_LENGTH: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custemprHeadPosition.getJobTelOrg() > -1) {
                custempr.setJobTelOrg(values[custemprHeadPosition.getJobTelOrg()]);
            } else {
                setLoadError("Не найден обязательный параметр:JOB_TEL_ORG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:JOB_TEL_ORG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:JOB_TEL_ORG: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

          return new CheckCustempr(custempr, loadError, true);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
