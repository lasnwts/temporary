package ru.usb.xbank_intgr_clients.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.xbank_intgr_clients.model.db.TBankHistoryArchives;


import javax.persistence.QueryHint;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface TBankHistoryArchivesRepo extends JpaRepository<TBankHistoryArchives, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
//    @Query(nativeQuery = true, value = "select count(*) from tbank_history_archives where date_end is not null and tbank_files='1' and archive_name=:name")
    @Query(nativeQuery = true, value = "select count(*) from tbank_history_archives where date_end is not null and archive_name=:name")
    int getCountFileName(String name);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
//    @Query(nativeQuery = true, value = "select * from tbank_history_archives where date_end is null and tbank_files='1' and archive_name =:name and rownum=1")
    @Query(nativeQuery = true, value = "select * from tbank_history_archives where archive_name =:name and rownum=1")
    TBankHistoryArchives getByName(String name);
}
