package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustAddrsHeadPosition;

@Component
public class CustAddrsHeadMap {

    //CLIENT;ADDRESS_TYPE;ADDRESS_DATE_REG;Level_Fias_region;AOGUID_region;Level_Fias_region_area;AOGUID_region_area;Level_Fias_city;AOGUID_city;Level_Fias_set_sity;AOGUID_set_sity;Level_Fias_STREET;AOGUID_street;Level_Fias_house;AOGUID_house;Level_Fias_apartment;AOGUID_apartment;ADDRESS_HOUSE;ADDRESS_HOUSE_KORP;ADDRESS_APARTAMENT;TEMPORARY_REG;DATE_REG_END

    private static final String COMMA_DELIMITER = ";";

    /**
     * Маппинг строки
     * @param line - строка
     * @return - объект
     */
    public CustAddrsHeadPosition map(String line){

        try {
            String[] values = line.split(COMMA_DELIMITER);

        CustAddrsHeadPosition  custAddrsHeadPosition = new CustAddrsHeadPosition();
        custAddrsHeadPosition.setClient(getPosition("CLIENT", values));
        custAddrsHeadPosition.setAddressType(getPosition("ADDRESS_TYPE", values));
        custAddrsHeadPosition.setAddressDateReg(getPosition("ADDRESS_DATE_REG", values));
        custAddrsHeadPosition.setLevelFiasRegion(getPosition("Level_Fias_region", values));
        custAddrsHeadPosition.setAoguidRegion(getPosition("AOGUID_region", values));
        custAddrsHeadPosition.setLevelFiasRegionArea(getPosition("Level_Fias_region_area", values));
        custAddrsHeadPosition.setAoguidRegionArea(getPosition("AOGUID_region_area", values));
        custAddrsHeadPosition.setLevelFiasCity(getPosition("Level_Fias_city", values));
        custAddrsHeadPosition.setAoguidCity(getPosition("AOGUID_city", values));
        custAddrsHeadPosition.setLevelFiasSetCity(getPosition("Level_Fias_set_city", values));
        custAddrsHeadPosition.setAoguidSetCity(getPosition("AOGUID_set_city", values));
        custAddrsHeadPosition.setLevelFiasStreet(getPosition("Level_Fias_STREET", values));
        custAddrsHeadPosition.setAoguidStreet(getPosition("AOGUID_street", values));
        custAddrsHeadPosition.setLevelFiasHouse(getPosition("Level_Fias_house", values));
        custAddrsHeadPosition.setAoguidHouse(getPosition("AOGUID_house", values));
        custAddrsHeadPosition.setLevelFiasApartment(getPosition("Level_Fias_apartment", values));
        custAddrsHeadPosition.setAoguidApartment(getPosition("AOGUID_apartment", values));
        custAddrsHeadPosition.setAddressHouse(getPosition("ADDRESS_HOUSE", values));
        custAddrsHeadPosition.setAddressHouseKorp(getPosition("ADDRESS_HOUSE_KORP", values));
        custAddrsHeadPosition.setAddressApartament(getPosition("ADDRESS_APARTAMENT", values));
        custAddrsHeadPosition.setTemporaryReg(getPosition("TEMPORARY_REG", values));
        custAddrsHeadPosition.setDateRegEnd(getPosition("DATE_REG_END", values));
        return custAddrsHeadPosition;
        } catch (Exception e){
            return null;
        }
    }


    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }

}
