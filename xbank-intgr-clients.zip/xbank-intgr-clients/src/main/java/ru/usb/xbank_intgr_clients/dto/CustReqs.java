package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTREQS")
public class CustReqs {
    // REQS_CUSTNUMB;DATE_CHNG_NAME;CHILDREN_COUNT;DEPENDANTS_COUNT;FAMILY_MEMBERS;PREV_LAST_NAME;REASON_CHNG_NAME;OCCUPATION_STATE
    //Идентификационный номер клиента;Дата изменения ФИО ;Количество детей;Количество иждивенцев; Количество членов семьи;Прежние ФИО;Причина изменения ФИО
    // Тип занятости.наименование;Имя файла;Дата внесения записи
    //файл = tbank.custreqs.csv
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "REQS_CUSTNUMB")//2
    private String reqsCustNumb;//Идентификационный номер клиента

    @Column(name = "DATE_CHNG_NAME")//3
    private Date dateChngName;//Дата изменения ФИО

    @Column(name = "CHILDREN_COUNT")//4
    private int childrenCount;//Количество детей

    @Column(name = "DEPENDANTS_COUNT")//5
    private int dependantsCount;//Количество иждивенцев

    @Column(name = "FAMILY_MEMBERS")//6
    private int familyMembers;//Количество членов семьи

    @Column(name = "PREV_LAST_NAME")//7
    private String prevLastName;//Прежние ФИО

    @Column(name = "REASON_CHNG_NAME")//8
    private String reasonChngName;//Причина изменения ФИО

    @Column(name = "OCCUPATION_STATE")//9
    private String occupationState;//Тип занятости.наименование

    //Имя файла
    @Column(name = "FILENAME")//10
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//11
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//12
    private long numInsert; //Номер вставки

}
