package ru.usb.xbank_intgr_clients.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileInfo {
    @JsonProperty("file_uri")
    private String fileUri;
    @JsonProperty("file_path")
    private String filePath;
    @JsonProperty("mime_type")
    private String mimeType;
    @JsonProperty("md5")
    private String md5;
    @JsonProperty("sha1")
    private String sha1;
    @JsonProperty("sha256")
    private String sha256;
    @JsonProperty("size")
    private int size;
    @JsonProperty("details")
    private Details details;
}
