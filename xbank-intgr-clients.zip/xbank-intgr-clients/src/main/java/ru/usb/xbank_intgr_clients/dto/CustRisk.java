package ru.usb.xbank_intgr_clients.dto;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTRISK")
public class CustRisk {

    //GR_CLIENT;GR_DATE_START;GR_DATE_END;GR_ACC_FEATURE;GR_GROUP_NUM;GR_CRED_GROUP_NUM;GR_SERVICE_QUAL;GR_PRC_RESERV;GR_FIX;GR_;GR_RESUME
    //CLIENT таблицы tbank.customer.csv;Дата начала принадлежности;Дата конца принадлежности;Доходы/расходы относить на себестоимость
    // Номер группы рискf;Номер расчетной группы кредитного риска;Признак качества обслуживания долга;Процент резервирования;Зафиксировано пользователем;
    // Сетевое имя пользователя внесшего изменения;Причина отнесения в группу риска

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "GR_CLIENT")//2
    private String grClient;//CLIENT таблицы tbank.customer.csv

    @Column(name = "GR_DATE_START")//3
    private Date grDateStart;//Дата начала принадлежности

    @Column(name = "GR_DATE_END")//4
    private Date grDateEnd;//Дата конца принадлежности

    @Column(name = "GR_ACC_FEATURE")//5
    private int grAccFeature;//Доходы/расходы относить на себестоимость

    @Column(name = "GR_GROUP_NUM")//6
    private int grGroupNum;//Номер группы риск

    @Column(name = "GR_CRED_GROUP_NUM")//7
    private int grCredGroupNum;//Номер расчетной группы кредитного риска

    @Column(name = "GR_SERVICE_QUAL")//8
    private int grServiceQual;//Признак качества обслуживания долга

    @Column(name = "GR_PRC_RESERV")//9
    private String grPrcReserv;//Процент резервирования

    @Column(name = "GR_FIX")//10
    private String grFix;//Зафиксировано пользователем

    @Column(name = "GR_")//11
    private String gr;//Сетевое имя пользователя внесшего изменения

    @Column(name = "GR_RESUME")//12
    private String grResume;//Причина отнесения в группу риска

    //Имя файла
    @Column(name = "FILENAME")//13
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//14
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//15
    private long numInsert; //Номер вставки
}
