package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustDocsHeadPosition {    
    private int client;
    private int docType;
    private int docSer;
    private int docNum;
    private int docWho;
    private int docPlace;
    private int docDate;
    private int docDateEnd;
    private int docDepartCode;
    private int docMain;
    private int fileName;
    private int inputDate;
}
