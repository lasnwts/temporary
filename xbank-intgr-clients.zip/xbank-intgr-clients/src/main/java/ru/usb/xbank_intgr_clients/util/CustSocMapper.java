package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustSoc;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustSoc;
import ru.usb.xbank_intgr_clients.model.CustSocHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.util.Date;

@Log4j2
@Component
public class CustSocMapper {

    private final Support support;

    private static final String COMMA_DELIMITER = ";";

    @Autowired
    public CustSocMapper(Support support) {
        this.support = support;
    }


    //SOC_CUSR_NMBR;SOC_DATE_REG;SOC_FOUND_CODE;SOC_FOUND;SOC_FOUND_NUM
    public CheckCustSoc map(String line, CustSocHeadPosition custSocHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());

        //Константы
        CustSoc custSoc = new CustSoc();
        custSoc.setNumInsert(numInsert);
        custSoc.setFileName(fileName);
        custSoc.setInputDate(new Date());

        try {
            if (custSocHeadPosition.getSocCusrNmb() > -1) {
                custSoc.setSocCusrNmb(values[custSocHeadPosition.getSocCusrNmb()]);
            } else {
                setLoadError("Не найден обязательный параметр:SOC_CUSR_NMBR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SOC_CUSR_NMBR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SOC_CUSR_NMBR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custSocHeadPosition.getSocDateReg() > -1 && support.checkDateLine(values[custSocHeadPosition.getSocDateReg()])) {
                custSoc.setSocDateReg(support.convertDateToSqlDate(support.parseDateLine(values[custSocHeadPosition.getSocDateReg()])));
            } else {
                setLoadError("Ошибка в параметре:SOC_DATE_REG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SOC_DATE_REG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SOC_DATE_REG: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custSocHeadPosition.getSocFoundCode() > -1) {
                custSoc.setSocFoundCode(values[custSocHeadPosition.getSocFoundCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:SOC_FOUND_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SOC_FOUND_CODE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SOC_FOUND_CODE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        try {
            if (custSocHeadPosition.getSocFound() > -1) {
                custSoc.setSocFound(values[custSocHeadPosition.getSocFound()]);
            } else {
                setLoadError("Не найден обязательный параметр:SOC_FOUND", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SOC_FOUND" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SOC_FOUND: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        try {
            if (custSocHeadPosition.getSocFoundNum() > -1) {
                custSoc.setSocFoundNum(values[custSocHeadPosition.getSocFoundNum()]);
            } else {
                setLoadError("Не найден обязательный параметр:SOC_FOUND_NUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SOC_FOUND_NUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SOC_FOUND_NUM: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        return new CheckCustSoc(custSoc, loadError);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

}
