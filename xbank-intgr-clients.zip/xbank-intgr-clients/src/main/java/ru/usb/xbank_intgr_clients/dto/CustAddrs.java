package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

// tbank.custaddrs.csv
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTADDRS")
public class CustAddrs {

    //файл = tbank.custaddrs.csv
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "CLIENT")
    private String client; //2

    @Column(name = "ADDRESS_TYPE")
    private String addressType;//3

    @Column(name = "ADDRESS_DATE_REG")
    private Date addressDateReg;//4

    @Column(name = "Level_Fias_region")
    private int levelFiasRegion;//5

    @Column(name = "AOGUID_region")
    private String aoguidRegion;//6

    @Column(name = "Level_Fias_region_area")
    private int levelFiasRegionArea;//7

    @Column(name = "AOGUID_region_area")
    private String aoguidRegionArea;//8

    @Column(name = "Level_Fias_city")
    private int levelFiasCity;//9

    @Column(name = "AOGUID_city")
    private String aoguidCity;//10

    @Column(name = "Level_Fias_set_city")
    private int levelFiasSetCity;//11

    @Column(name = "AOGUID_set_city")
    private String aoguidSetCity;//12

    @Column(name = "Level_Fias_STREET")
    private int levelFiasStreet;//13

    @Column(name = "AOGUID_street")
    private String aoguidStreet;//14

    @Column(name = "Level_Fias_house")
    private int levelFiasHouse;//15

    @Column(name = "AOGUID_house")
    private String aoguidHouse;//16

    @Column(name = "Level_Fias_apartment")
    private int levelFiasApartment;//17

    @Column(name = "AOGUID_apartment")
    private String aoguidApartment;//18

    @Column(name = "ADDRESS_HOUSE")
    private String addressHouse;//19

    @Column(name = "ADDRESS_HOUSE_KORP")
    private String addressHouseKorp;//20

    @Column(name = "ADDRESS_APARTAMENT")
    private String addressApartament;//21

    @Column(name = "TEMPORARY_REG")
    private int temporaryReg;//22

    @Column(name = "DATE_REG_END")
    private Date dateRegEnd;//23

    @Column(name = "FILENAME")
    private String fileName;//24

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INPUT_DATE")
    private java.util.Date inputDate; //25

    @Column(name = "NUMINSERT")
    private long numInsert;//26
}
