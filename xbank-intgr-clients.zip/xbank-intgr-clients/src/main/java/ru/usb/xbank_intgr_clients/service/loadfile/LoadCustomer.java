package ru.usb.xbank_intgr_clients.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustomer;
import ru.usb.xbank_intgr_clients.model.CustomerHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;
import ru.usb.xbank_intgr_clients.repository.CustomerRepo;
import ru.usb.xbank_intgr_clients.util.head.CustomerHeadMap;
import ru.usb.xbank_intgr_clients.util.CustomerMapper;
import ru.usb.xbank_intgr_clients.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadCustomer {

    private final CustomerMapper customerMapper;
    private final CustomerHeadMap customerHeadMap;
    private final CustomerRepo customerRepo;
    private final Support support;

    @Autowired
    public LoadCustomer(CustomerMapper customerMapper, CustomerHeadMap customerHeadMap,
                        CustomerRepo customerRepo, Support support) {
        this.customerMapper = customerMapper;
        this.customerHeadMap = customerHeadMap;
        this.customerRepo = customerRepo;
        this.support = support;
    }

    /**
     * Загрузка файла в базу данных
     *
     * @param file - файл для загрузки в базу данных
     */
    public List<LoadError> read(File file) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:Запуск процесса: LoadCustomer, переданный Файл {} не существует", LG.USBLOGERROR, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}: Подготовка процесса: Load Customer к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, file.getAbsolutePath(), numInsert);
        AtomicReference<CustomerHeadPosition> customerHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}: Запуск процесса: LoadCustomer, startTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.parallel().forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                customerHeadPosition.set(customerHeadMap.map(line)); //разбираем, что где находится в строке
                            } else {
                                CheckCustomer checkCustomer = customerMapper.map(line, customerHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}: customer={}", LG.USBLOGINFO, checkCustomer.getCustomer());
                                customerRepo.saveAndFlush(checkCustomer.getCustomer()); //сохраняем
                                if (checkCustomer.getLoadError().isStatus()) {
                                    loadErrorList.add(checkCustomer.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, e.getMessage(), line);
                            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
                        }
                    }
            );
            log.info("{}:Завершение процесса: LoadCustomer, endTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
            log.info("{}:Загружено записей:{}", LG.USBLOGINFO, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:Завершение процесса: LoadCustomer. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO,  ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}
