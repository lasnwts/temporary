package ru.usb.xbank_intgr_clients.service.ftp;

import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.db.FtpsResponse;


import java.io.File;
import java.io.IOException;

@Log4j2
@Component
public class ApiLayerFtps {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final FtpsClient ftpsClient;

    @Autowired
    public ApiLayerFtps(FtpsClient ftpsClient) {
        this.ftpsClient = ftpsClient;
    }

    /**
     * Скачивание файла с FTPS
     *
     * @param user            - логин
     * @param password        - пароль
     * @param directory       - директория
     * @param fileName        - имя файла
     * @param pathDestination - путь куда сохранить файл
     * @return - FtpsResponse
     */
    public FtpsResponse downloadFile(String user, String password, String directory, String fileName, String pathDestination, long thread) {
        log.info("{}:T{}: [ApiLayer] Постановка на скачивание файла с FTPS, user={}, directory={}, fileName={}, pathDestination={}",
                LG.USBLOGINFO, thread, user, directory, fileName, pathDestination);
        FtpsResponse ftpsResponse = new FtpsResponse();
        try {
            File file = ftpsClient.downloadFile(user, password, directory, fileName, pathDestination , Thread.currentThread().getId());
            if (file == null) {
                ftpsResponse.setHttpStatus(HttpStatus.NOT_FOUND);
                ftpsResponse.setCode(404);
                ftpsResponse.setMessage("Файл не найден");
                return ftpsResponse;
            } else {
                ftpsResponse.setHttpStatus(HttpStatus.OK);
                ftpsResponse.setCode(200);
                ftpsResponse.setMessage("Файл найден");
                ftpsResponse.setFile(file);
                ftpsResponse.setName(file.getName());
            }
        } catch (FTPIllegalReplyException | IllegalStateException | IOException | FTPException | FTPAbortedException |
                 FTPDataTransferException | FTPListParseException e) {
            log.error("{}:T{}: [ApiLayer] Ошибка при выполнении cкачивания файла с сервера:{}", LG.USBLOGERROR, thread, e.getMessage());
            ftpsResponse.setCode(403);
            ftpsResponse.setMessage(e.getMessage());
            ftpsResponse.setHttpStatus(HttpStatus.BAD_REQUEST);
        }
        log.info("{}:T{}: [ApiLayer] Файл:{} закачан с FTPS, в директорию {}", LG.USBLOGINFO, thread, fileName, pathDestination);
        return ftpsResponse;
    }


}
