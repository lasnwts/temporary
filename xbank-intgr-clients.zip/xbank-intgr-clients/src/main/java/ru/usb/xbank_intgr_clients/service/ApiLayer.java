package ru.usb.xbank_intgr_clients.service;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.FacFile;
import ru.usb.xbank_intgr_clients.model.s3.CheckFile;
import ru.usb.xbank_intgr_clients.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_clients.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_clients.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_clients.service.sandbox.CheckSandBox;
import ru.usb.xbank_intgr_clients.service.sandbox.PutSandBox;
import ru.usb.xbank_intgr_clients.util.MapperFacFile;
import ru.usb.xbank_intgr_clients.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.Optional;

@Log4j2
@Service
public class ApiLayer {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах


    private final Configure configure;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;
    private final PutSandBox putSandBox;
    private final MapperFacFile mapperFacFile;
    private final CheckSandBox checkSandBox;
    private final ApiLayerS3 apiLayerS3;
    private final ServiceMailError serviceMailError;
    private final Support support;

    @Autowired
    public ApiLayer(Configure configure, TBankHistoryArchivesRepo tBankHistoryArchivesRepo,
                    PutSandBox putSandBox, MapperFacFile mapperFacFile, CheckSandBox checkSandBox,
                    ApiLayerS3 apiLayerS3, ServiceMailError serviceMailError, Support support) {
        this.configure = configure;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
        this.putSandBox = putSandBox;
        this.mapperFacFile = mapperFacFile;
        this.checkSandBox = checkSandBox;
        this.apiLayerS3 = apiLayerS3;
        this.serviceMailError = serviceMailError;
        this.support = support;
    }


    /**
     * Проверка наличия файла в базе
     *
     * @param fileName - имя файла
     * @return - true/false
     */
    public boolean checkFileInDataBase(String fileName, long thread) {
        if (tBankHistoryArchivesRepo.getCountFileName(fileName) > 0){
            log.info("{}:T{}:  Файл:{} найден в базе, обработку файла не производим.", LG.USBLOGINFO, thread, fileName);
            return true;
        }
        return false; //берем в обработку
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getTempPath() {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator();
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getThreadTempPath(long thread) {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator()
                + thread + FileSystems.getDefault().getSeparator();
    }



    /**
     * Получить FacFile из json строки.
     * @param json - json строка
     * @return - FacFile
     */
    public Optional<FacFile> getFacString(String json){
        return mapperFacFile.getFacFile(json);
    }

    /**
     * Отправить файл в SandBox, из Rest API.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile putSandBox(FacFile facFile) {
        return putSandBox.putFileToSandBox(facFile, 1L);
    }



    /**
     * Проверить, что файл загружен и проверяется в SandBox.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile checkSandBox(FacFile facFile) {
        return checkSandBox.checkSandBox(facFile, 1L);
    }

    /**
     * Получить FacFile по File
     *
     * @param file - файл
     * @return - FacFile
     */
    public FacFile getFacFile(File file) {
        FacFile facFile = new FacFile();
        facFile.setFile(file);
        facFile.setName(file.getName());
        return facFile;
    }

    /**
     * Удалить файл из временной директории
     * @param facFile - FacFile
     * @return - FacFile
     * @throws IOException - ошибка
     */
    public FacFile delFile(FacFile facFile) throws IOException {
        if (Files.deleteIfExists(facFile.getFile().toPath())){
            facFile.setMessage("Файл удален из временной директории");
        } else {
            facFile.setMessage("Файл не удален из временной директории!");
        }
        return facFile;
    }

    /**
     * Получение файла из бакета
     *
     * @param fileLink   - ссылка на файл
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     * @return - файл
     */
    public File getFileFromS3(String fileLink, String bucketName, String fileName) throws Exception {
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        CheckFile checkFile = new CheckFile();
        int i = 0; //Счетчик попыток
        do {
            i++;
            try {
                checkFile.setFile(apiLayerS3.downloadFileFromS3(fileLink, bucketName, fileName));
                checkFile.setErrorCode(HttpStatus.OK);
                checkFile.setMessage("File downloaded successfully");
                checkFile.setSuccess(true);
            } catch (Exception e) {
                log.error("{}: Error downloading file from S3: {}", LG.USBLOGERROR, e.getMessage());
                checkFile.setSuccess(false);
                checkFile.setErrorCode(apiLayerS3.getS3StatusCode(e.getMessage()));
                checkFile.setMessage(e.getMessage());
                checkFile.setFile(null);
                checkFile.setExcept(e);
                log.error("{}: Ошибка получения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд", LG.USBLOGERROR, i, timeWait / 1000);
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}: Ошибка возникла во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!checkFile.isSuccess() && i < 10);

        if (checkFile.isSuccess()) {
            return checkFile.getFile();
        } else {
            if (checkFile.getErrorCode().is4xxClientError()) {
                log.error("{} Ошибка получения файла.[is4xxClientError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            if (checkFile.getErrorCode().is5xxServerError()) {
                log.error("{} Ошибка получения файла.[is5xxServerError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            if (checkFile.getErrorCode().isError()) {
                log.error("{} Ошибка получения файла.[isError] Подробности:{} ", LG.USBLOGERROR, checkFile);
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x() + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkFile.getErrorCode())) +
                        "\n\r" + "Описание:" + support.getWrapNull(checkFile.getMessage()));
            }
            throw checkFile.getExcept();
        }
    }

}
