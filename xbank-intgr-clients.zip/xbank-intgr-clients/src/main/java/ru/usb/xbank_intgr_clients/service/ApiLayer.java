package ru.usb.xbank_intgr_clients.service;


import it.sauronsoftware.ftp4j.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.FacFile;
import ru.usb.xbank_intgr_clients.model.db.CheckFileList;
import ru.usb.xbank_intgr_clients.model.db.FtpsFile;
import ru.usb.xbank_intgr_clients.model.db.FtpsResponse;
import ru.usb.xbank_intgr_clients.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_clients.service.ftp.FtpsClient;
import ru.usb.xbank_intgr_clients.service.sandbox.CheckSandBox;
import ru.usb.xbank_intgr_clients.service.sandbox.PutSandBox;
import ru.usb.xbank_intgr_clients.util.MapperFacFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class ApiLayer {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final FtpsClient ftpsClient;
    private final Configure configure;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;
    private final PutSandBox putSandBox;
    private final MapperFacFile mapperFacFile;
    private final CheckSandBox checkSandBox;


    @Autowired
    public ApiLayer(FtpsClient ftpsClient, Configure configure, TBankHistoryArchivesRepo tBankHistoryArchivesRepo,
                    PutSandBox putSandBox, MapperFacFile mapperFacFile, CheckSandBox checkSandBox) {
        this.ftpsClient = ftpsClient;
        this.configure = configure;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
        this.putSandBox = putSandBox;
        this.mapperFacFile = mapperFacFile;
        this.checkSandBox = checkSandBox;
    }


    /**
     * Получение списка файлов в директории
     *
     * @param user      - логин
     * @param password  - пароль
     * @param directory - директория
     * @return - список файлов
     * @throws FTPIllegalReplyException - ошибка
     * @throws FTPAbortedException      - ошибка
     * @throws FTPDataTransferException - ошибка
     * @throws IOException              - ошибка
     * @throws FTPListParseException    - ошибка
     * @throws FTPException             - ошибка
     */
    public List<FtpsFile> getList(String user, String password, String directory)
            throws FTPIllegalReplyException, FTPAbortedException, FTPDataTransferException, IOException, FTPListParseException, FTPException {
        Optional<List<FtpsFile>> listOptional = ftpsClient.getListFile(user, password, directory);
        return listOptional.orElseGet(ArrayList::new);
    }


    /**
     * Получение списка файлов в директории
     *
     * @return - список файлов
     */
    public CheckFileList getListTbank() {
        CheckFileList checkFileList = new CheckFileList();
        checkFileList.setSuccess(false);
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //число попыток получить список
        do {
            i++; //инкремент числа попыток
            try {
                checkFileList.setList(getList(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory()));
                checkFileList.setSuccess(true);
            } catch (FTPIllegalReplyException e) {
                log.error("{}: [ApiLayer][FTPIllegalReplyException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPAbortedException e) {
                log.error("{}: [ApiLayer][FTPAbortedException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPDataTransferException e) {
                log.error("{}: [ApiLayer][FTPDataTransferException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (IOException e) {
                log.error("{}: [ApiLayer][IOException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPListParseException e) {
                log.error("{}: [ApiLayer][FTPListParseException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(503);
            } catch (FTPException e) {
                log.error("{}: [ApiLayer][FTPException] Ошибка при выполнении getListTbank():{}", LG.USBLOGERROR, e.getMessage());
                checkFileList.setMessage(e.getMessage());
                checkFileList.setCode(401);
            }
            if (!checkFileList.isSuccess()) {
                timeWait = timeWait + deltaTime * 1000;
                log.info("{}: [ApiLayer] Проблема при получении списка файлов на FTPS сервере. Номер попытки:{} .Повторная попытка получить список файлов через {} секунд", LG.USBLOGINFO, i, timeWait / 1000);
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException e) {
                    log.error("{}: Ошибка возникла во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
            }
        } while (!checkFileList.isSuccess() && i < 10);
        return checkFileList;
    }

    /**
     * Проверка наличия файла в базе
     *
     * @param fileName - имя файла
     * @return - true/false
     */
    public boolean checkFileInDataBase(String fileName, long thread) {
        if (tBankHistoryArchivesRepo.getCountFileName(fileName) > 0){
            log.info("{}:T{}:  Файл:{} найден в базе, обработку файла не производим.", LG.USBLOGINFO, thread, fileName);
            return true;
        }
        return false; //берем в обработку
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getTempPath() {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator();
    }

    /**
     * Получение пути к временной директории
     *
     * @return - путь к временной директории
     */
    public String getThreadTempPath(long thread) {
        return new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare() + FileSystems.getDefault().getSeparator()
                + thread + FileSystems.getDefault().getSeparator();
    }


    /**
     * Удаление файла
     *
     * @param login     - логин
     * @param password  - пароль
     * @param directory - директория
     * @param fileName  - имя файла
     * @return - FtpsResponse
     */
    public FtpsResponse deleteFtpsFile(String login, String password, String directory, String fileName) {
        log.info("{}: [ApiLayer] Попытка на удаление файла с FTPS, login={}, directory={}, fileName={}", LG.USBLOGINFO, login, directory, fileName);
        return ftpsClient.deleteFtpsFile(login, password, directory, fileName);
    }


    /**
     * Получить FacFile из json строки.
     * @param json - json строка
     * @return - FacFile
     */
    public Optional<FacFile> getFacString(String json){
        return mapperFacFile.getFacFile(json);
    }

    /**
     * Отправить файл в SandBox, из Rest API.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile putSandBox(FacFile facFile) {
        return putSandBox.putFileToSandBox(facFile, 1L);
    }



    /**
     * Проверить, что файл загружен и проверяется в SandBox.
     * @param facFile - FacFile
     * @return - FacFile
     */
    public FacFile checkSandBox(FacFile facFile) {
        return checkSandBox.checkSandBox(facFile, 1L);
    }

    /**
     * Получить FacFile по File
     *
     * @param file - файл
     * @return - FacFile
     */
    public FacFile getFacFile(File file) {
        FacFile facFile = new FacFile();
        facFile.setFile(file);
        facFile.setName(file.getName());
        return facFile;
    }

    /**
     * Удалить файл из временной директории
     * @param facFile - FacFile
     * @return - FacFile
     * @throws IOException - ошибка
     */
    public FacFile delFile(FacFile facFile) throws IOException {
        if (Files.deleteIfExists(facFile.getFile().toPath())){
            facFile.setMessage("Файл удален из временной директории");
        } else {
            facFile.setMessage("Файл не удален из временной директории!");
        }
        return facFile;
    }
}
