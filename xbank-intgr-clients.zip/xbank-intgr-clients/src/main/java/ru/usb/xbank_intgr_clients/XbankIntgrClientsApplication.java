package ru.usb.xbank_intgr_clients;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@SpringBootApplication
public class XbankIntgrClientsApplication implements CommandLineRunner {


    private static final Logger logger = LoggerFactory.getLogger(XbankIntgrClientsApplication.class);

    private final Configure configure;

    @Autowired
    public XbankIntgrClientsApplication(Configure configure) {
        this.configure = configure;
    }


    public static void main(String[] args) {
        SpringApplication.run(XbankIntgrClientsApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.1.20") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r (Service [Микросервис: Xbank-intgr-clients] Интеграционный поток по получению архивов с данными клиентов от Т-банка)")
                .contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
                .version(appVersion)
                .description("API для [Интеграционный поток по получению архивов с данными клиентов от Т-банка]" +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {
        // Проверка путей
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));

        logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
        configure.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


        //Проверка сколько времени
        if (LocalDateTime.now().getHour() > configure.getHourEnd()) {
            configure.setSyncWorkTime(false);
            logger.info("{} Время работы завершено", LG.USBLOGINFO);
        }
        if (LocalDateTime.now().getHour() < configure.getHourBegin()) {
            configure.setSyncWorkTime(false);
            logger.info("{} Время работы еще не наступило", LG.USBLOGINFO);
        }
        if (configure.isSyncWorkTime()) {
            logger.info("Сейчас установлено, что время рабочее:{} ", configure.isSyncWorkTime());
        } else {
            logger.info("Сейчас установлено, что время  НЕ рабочее:{} ", configure.isSyncWorkTime());
        }


        logger.info(".");
        logger.info("..");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : Xbank-intgr-clients", LG.USBLOGINFO);
        logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
        logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 24/10/2024 ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:| tbank.customer.csv           : Информация о клиенте", LG.USBLOGINFO);
        logger.info("{}:| tbank.custacc.csv            : Информация о счетах", LG.USBLOGINFO);
        logger.info("{}:| tbank.custaddrs.csv          : Информация об адресе", LG.USBLOGINFO);
        logger.info("{}:| tbank.custcont.csv           : Информация о телефоне", LG.USBLOGINFO);
        logger.info("{}:| tbank.custdocs.csv           : Информация о документах клиента", LG.USBLOGINFO);
        logger.info("{}:| tbank.custempr.csv           : Информация о работе клиенте", LG.USBLOGINFO);
        logger.info("{}:| tbank.custsoc.csv            : Информация о соц. Фондах клиента", LG.USBLOGINFO);
        logger.info("{}:| tbank.custinspect.csv        : Информация о налоговых инспекциях", LG.USBLOGINFO);
        logger.info("{}:| tbank.custreqs.csv           : Информация о дополнительных реквизитах", LG.USBLOGINFO);
        logger.info("{}:| tbank.custrisk.csv           : Информация о группе риска клиента", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  10.11.2024  : 0.0.11 Изменено наименования обрабатываемых файлов", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  19.11.2024  : 0.0.12 Обнаружено влияние потоков друг на друга. Внесены коррективы", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  21.11.2024  : 0.0.13 Смена кодировки", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  21.11.2024  : 0.0.14 WebAPI", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  21.11.2024  : 0.1.15 Изменение алгоритма, FTPS убран. Файлы берутся из S3", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  25.11.2024  : 0.1.17 Внесение изменений в формат столбцов файлов", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  26.11.2024  : 0.1.18 Если документ (custdocs) имеет DOC_MAIN = 1, то в DOC_DATE_END записать пусто. Иначе  - оставить без изменений", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  28.11.2024  : 0.1.19 Пустые строки не загружаем. ", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  30.11.2024  : 0.1.20 Добавлена проверка что поле CLIENT заполнено, в файлах customer,custdocs,costcont,custaddr ", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("....");
        logger.info(".....");
    }
}
