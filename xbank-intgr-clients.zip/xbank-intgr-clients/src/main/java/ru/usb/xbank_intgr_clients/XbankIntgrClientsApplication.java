package ru.usb.xbank_intgr_clients;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springdoc.api.ErrorMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.LoadError;
import ru.usb.xbank_intgr_clients.service.loadfile.*;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.function.Consumer;

@SpringBootApplication
public class XbankIntgrClientsApplication implements CommandLineRunner {

    @Autowired
    LoadCustomer loadCustomer;
    @Autowired
    LoadCustDocs loadCustDocs;
    @Autowired
    LoadCustAddrs loadCustAddrs;
    @Autowired
    LoadCustCont loadCustCont;
    @Autowired
    LoadCustSoc loadCustSoc;
    @Autowired
    LoadCustAcc loadCustAcc;
    @Autowired
    LoadCustInspect loadCustInspect;
    @Autowired
    LoadCustempr loadCustempr;
    @Autowired
    LoadCustReqs loadCustReqs;
    @Autowired
    LoadCustRisk loadCustRisk;


    private static final Logger logger = LoggerFactory.getLogger(XbankIntgrClientsApplication.class);

    private final Configure configure;

    @Autowired
    public XbankIntgrClientsApplication(Configure configure) {
        this.configure = configure;
    }


    public static void main(String[] args) {
        SpringApplication.run(XbankIntgrClientsApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.1.10") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r (Service [Микросервис: Xbank-intgr-clients] Интеграционный поток по получению архивов с данными клиентов от Т-банка)")
                .contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
                .version(appVersion)
                .description("API для [Интеграционный поток по получению архивов с данными клиентов от Т-банка]" +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {
        // Проверка путей
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));

        logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
        configure.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


        logger.info(".");
        logger.info("..");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : Xbank-intgr-clients", LG.USBLOGINFO);
        logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
        logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 24/10/2024 ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:| tbank.customer.csv           : Информация о клиенте", LG.USBLOGINFO);
        logger.info("{}:| tbank.custacc.csv            : Информация о счетах", LG.USBLOGINFO);
        logger.info("{}:| tbank.custaddrs.csv          : Информация об адресе", LG.USBLOGINFO);
        logger.info("{}:| tbank.custcont.csv           : Информация о телефоне", LG.USBLOGINFO);
        logger.info("{}:| tbank.custdocs.csv           : Информация о документах клиента", LG.USBLOGINFO);
        logger.info("{}:| tbank.custempr.csv           : Информация о работе клиенте", LG.USBLOGINFO);
        logger.info("{}:| tbank.custsoc.csv            : Информация о соц. Фондах клиента", LG.USBLOGINFO);
        logger.info("{}:| tbank.custinspect.csv        : Информация о налоговых инспекциях", LG.USBLOGINFO);
        logger.info("{}:| tbank.custreqs.csv           : Информация о дополнительных реквизитах", LG.USBLOGINFO);
        logger.info("{}:| tbank.custrisk.csv           : Информация о группе риска клиента", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:| Reason modified  07.10.2024  : 0.0.11 ПОКА НЕТ", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("....");
        logger.info(".....");


        String pathFile = "C:/AppServer/Data/TBANK/CLIENT";

//        String filePath = pathFile + "/" + "customer.csv";
//        File file = new File(filePath);
//
//
//        List<LoadError> loadErrors = loadCustomer.read(file);
//        if (!loadErrors.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//            loadErrors.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//        String fileCustDoc = pathFile + "/" + "tbank_custdocs.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustDocs.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }


//        tbank_custaddrs.csv
//
//        String fileCustDoc = pathFile + "/" + "tbank_custaddrs.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustAddrs.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//        //tbank_custcont.csv tbank_custcont.csv
//                String fileCustDoc = pathFile + "/" + "tbank_custcont.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustCont.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//        //tbank_custsoc.csv
//        String fileCustDoc = pathFile + "/" + "tbank_custsoc.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustSoc.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

        //tbank_custacc.csv
//        String fileCustDoc = pathFile + "/" + "tbank_custacc.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustAcc.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//        String fileCustDoc = pathFile + "/" + "tbank_custinspect.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustInspect.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//        String fileCustDoc = pathFile + "/" + "tbank_custempr.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustempr.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }


//        //tbank_custreqs.csv
//        String fileCustDoc = pathFile + "/" + "tbank_custreqs.csv";
//        File fileCustDocs = new File(fileCustDoc);
//
//
//        List<LoadError> loadErrors1 = loadCustReqs.loadFile(fileCustDocs);
//        if (!loadErrors1.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
//            loadErrors1.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }


        //tbank_custrisk.csv
        String fileCustDoc = pathFile + "/" + "tbank_custrisk.csv";
        File fileCustDocs = new File(fileCustDoc);


        List<LoadError> loadErrors1 = loadCustRisk.loadFile(fileCustDocs);
        if (!loadErrors1.isEmpty()) {
            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors1.size());
            loadErrors1.forEach(loadError -> {
                logger.info("{}:{}", LG.USBLOGERROR, loadError);
            });
        }



    }
}
