package ru.usb.xbank_intgr_clients.dto;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTEMPR")
public class Custempr {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "JOB_CLIENT")//2
    private String jobClient; //CLIENT таблицы tbank.customer.csv

    @Column(name = "JOB_WORK_START_DATE")//3
    private Date jobWorkStartDate;//Дата начала работы

    @Column(name = "JOB_WORK_PLACE_NAME")//4
    private String jobWorkPlaceName;//Имя работодателя

    @Column(name = "JOB_MAIN_JOB")//5
    private String jobMainJob;//"Основное место работы

    @Column(name = "JOB_WORK_PLACE_OKVED")//6
    private String jobWorkPlaceOkved;    //Код ОКВЭД вида деятельности

    @Column(name = "JOB_KIND_DOC_CODE")//7
    private String jobKindDocCode;//Код документа, подтверждающего трудовую деятельность

    @Column(name = "JOB_WORK_POSITION")//8
    private String jobWorkPosition;//Должность

    @Column(name = "JOB_WORK_PLACE_INN")//9
    private String jobWorkPlaceInn;//ИНН места работы

    @Column(name = "JOB_SERVICE_LENGTH")//10
    private String jobServiceLength;//Стаж на данном месте работы, месяцев

    @Column(name = "JOB_TEL_ORG")//11
    private String jobTelOrg;    //Телефон организации

    @Column(name = "FILENAME")//12
    private String filename;//Имя файла

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INPUT_DATE")//13
    private java.util.Date inputDate;//Дата внесения записи

    @Column(name = "NUMINSERT")//14
    private long numInsert; //Номер вставки

}
