package ru.usb.xbank_intgr_clients.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_clients.dto.CustCont;
import ru.usb.xbank_intgr_clients.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckCustCont {
    private CustCont custCont; //адреса
    private LoadError loadError; //Ошибки

}
