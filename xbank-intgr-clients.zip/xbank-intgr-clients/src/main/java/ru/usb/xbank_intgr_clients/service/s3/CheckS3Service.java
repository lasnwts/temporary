package ru.usb.xbank_intgr_clients.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.s3.CheckS3;
import ru.usb.xbank_intgr_clients.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_clients.util.Support;

import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class CheckS3Service {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    /**
     * 1.1.	Если по результату запроса получен ответ с ошибками:
     * •	500, 502, 503, 504, то повторить попытку запроса. Количество попыток = 10, обработка попыток = нелинейно,
     * общее время = 10 минут. Если попытки завершены, и ошибка не изменилась,
     * то сгенерировать и направить сообщение Email в службу технической поддержки - Пример 4
     */
    private String letter5xxSubject = "S3 = Tbankfiles недоступен Микросервис: Xbank-intgr-creditfile-Siebel Статус: 5xx";

    private String letter5x = "S3 = Tbankfiles недоступен\n" +
            "Микросервис: Xbank-intgr-creditfile-Siebel\n" +
            "Статус: 500\n" +
            "Описание ошибки : Internal Server Error\n";

    private String letter4xxSubject = "S3 = Tbankfiles недоступен Микросервис: Xbank-intgr-creditfile-Siebel Статус: 4xx";

    private String letter4x = "S3 = Tbankfiles проблемы см авторизацией\n" +
            "Микросервис: Xbank-intgr-creditfile-Siebel\n" +
            "Статус: 4xx\n" +
            "Описание ошибки : \n";

    private final AmazonS3Service amazonS3Service;
    private final ServiceMailError serviceMailError;
    private final Support support;

    @Autowired
    public CheckS3Service(AmazonS3Service amazonS3Service, ServiceMailError serviceMailError, Support support) {
        this.amazonS3Service = amazonS3Service;
        this.serviceMailError = serviceMailError;
        this.support = support;
    }

    /**
     * Проверка соединения с S3
     *
     * @return - результат проверки
     */
    public CheckS3 checkConnection(String bucketName) {

        CheckS3 checkS3 = new CheckS3();
        try {
            List<String> bucketList = amazonS3Service.listObjects(bucketName);
            if (bucketList == null) {
                log.error("{} Не удалось подключиться к S3. Проверьте настройки.", LG.USBLOGERROR);
                checkS3.setSuccess(false);
                checkS3.setMessage("Не удалось подключиться к S3.");
                checkS3.setErrorCode(HttpStatus.SERVICE_UNAVAILABLE);
            } else {
                checkS3.setSuccess(true);
                checkS3.setMessage("Подключение успешно");
                checkS3.setData(bucketList);
                checkS3.setErrorCode(HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("{} Возникла ошибка при проверке соединения с S3. Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Stack trace:", LG.USBLOGERROR, e);
            checkS3.setSuccess(false);
            checkS3.setMessage("Не удалось подключиться к S3.Function=[amazonS3Service.listRoot()]");
            checkS3.setErrorCode(amazonS3Service.getStatusCode(e.getMessage()));
        }
        return checkS3;
    }

    /**
     * Получение списка файлов в бакете
     *
     * @param bucketName - имя бакета
     * @return - список файлов
     */
    public CheckS3 checkListBuckets(String bucketName) {
        CheckS3 checkS3 = new CheckS3();
        try {
            List<String> bucketList = amazonS3Service.listObjects(bucketName);
            if (bucketList == null) {
                log.error("{}: Возникла ошибка при получении списка бакетов в бакете:{}. Проверьте настройки.", LG.USBLOGERROR, bucketList);
                checkS3.setSuccess(false);
                checkS3.setMessage("Не удалось подключиться к S3. Проверьте настройки.");
                checkS3.setErrorCode(HttpStatus.SERVICE_UNAVAILABLE);
            } else {
                checkS3.setSuccess(true);
                checkS3.setMessage("Подключение успешно");
                checkS3.setBuckets(bucketList);
                checkS3.setErrorCode(HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("{}: Возникла ошибка при получении списка бакетов в бакете:{} Error:{}", LG.USBLOGERROR, bucketName, e.getMessage());
            log.debug("{}:getListObjects Stack trace:", LG.USBLOGERROR, e);
            checkS3.setSuccess(false);
            checkS3.setMessage("Не удалось подключиться к S3. Проверьте настройки.");
            checkS3.setErrorCode(amazonS3Service.getStatusCode(e.getMessage()));
        }
        return checkS3;
    }

    /**
     * Получение списка бакетов
     *
     * @param bucketName - имя бакета
     * @return - список бакетов
     */
    private CheckS3 getListBuckets(String bucketName) {
        CheckS3 checkS3 = checkConnection(bucketName);
        if (checkS3.isSuccess()) {
            checkS3 = checkListBuckets(bucketName);
        }
        return checkS3;
    }

    /**
     * Получение списка бакетов с повторением
     *
     * @param bucketName - имя бакета
     * @return - список бакетов
     */
    public CheckS3 getReadListObjects(String bucketName) {
        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        CheckS3 checkS3; //объект со списком бакетов
        int i = 0; //число попыток получить список
        do {
            checkS3 = getListBuckets(bucketName); //Получаем список
            i++; //декремент числа попыток
            if (checkS3.isSuccess()) {
                checkS3 = checkListBuckets(bucketName);
            } else {
                log.error("{}: Ошибка возникла во время получения списка бакетов! Номер попытки:{}, время ожидания до следующей попытки={} секунд", LG.USBLOGERROR, i, timeWait/1000);
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException e) {
                    log.error("{}: Ошибка возникла во время ожидания Thread.sleep!", LG.USBLOGERROR);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!checkS3.isSuccess() && i < 10);
        return checkS3;
    }

    /**
     * Получение списка файлов в бакете
     * Отправка писем в кадры поддержки
     *
     * @param checkS3 - объект со списком бакетов
     * @return - список файлов
     */
    public Optional<List<String>> getListFiles(CheckS3 checkS3) {
        if (checkS3.getErrorCode().is4xxClientError()){
            log.error("{} Ошибка получения списка файлов.[is4xxClientError] Подробности:{} ", LG.USBLOGERROR, checkS3);
            serviceMailError.sendMailErrorSubject(letter4xxSubject, letter4x + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkS3.getErrorCode())) +
            "\n\r" + "Описание:" + support.getWrapNull(checkS3.getMessage()));
        }
        if (checkS3.getErrorCode().is5xxServerError()){
            log.error("{} Ошибка получения списка файлов.[is5xxServerError] Подробности:{} ", LG.USBLOGERROR, checkS3);
            serviceMailError.sendMailErrorSubject(letter5xxSubject, letter5x + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(checkS3.getErrorCode())) +
                    "\n\r" + "Описание:" + support.getWrapNull(checkS3.getMessage()));
        }
        if (checkS3.getErrorCode().isError()){
            log.error("{} Ошибка получения списка файлов.[isError] Подробности:{} ", LG.USBLOGERROR, checkS3);
            serviceMailError.sendMailErrorSubject(letter5xxSubject, letter5x + "\n\r" + "Status=" +  support.getWrapNull(String.valueOf(checkS3.getErrorCode())) +
                    "\n\r" + "Описание:" + support.getWrapNull(checkS3.getMessage()));
        }
            return Optional.ofNullable(checkS3.getBuckets());
    }
}
