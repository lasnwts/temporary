package ru.usb.xbank_intgr_clients.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.model.db.FtpsResponse;
import ru.usb.xbank_intgr_clients.model.db.TBankHistoryArchives;
import ru.usb.xbank_intgr_clients.model.db.TBankRunHistory;
import ru.usb.xbank_intgr_clients.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_clients.repository.TBankRunHistoryRepo;


import java.util.Date;
import java.util.Objects;

@Log4j2
@Service
public class ApiLayerDB {

    private static final String MICRO = "[xbank-intgr-clients]";

    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;
    private final TBankRunHistoryRepo tBankRunHistoryRepo;

    @Autowired
    public ApiLayerDB(TBankHistoryArchivesRepo tBankHistoryArchivesRepo, TBankRunHistoryRepo tBankRunHistoryRepo) {
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
        this.tBankRunHistoryRepo = tBankRunHistoryRepo;
    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchiveBadZip(FtpsResponse ftpsResponse) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setDateStart(new Date());
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setError("1");
        historyArchives.setErrortext(ftpsResponse.getMessage());
        historyArchives.setTbankFiles("0");
        historyArchives.setDateEnd(new Date());
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchive(FtpsResponse ftpsResponse, String tBankFiles) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setDateStart(new Date());
        historyArchives.setTbankFiles(tBankFiles);
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение истории архива
     *
     * @param historyArchives - история архива
     */
    public void saveHistoryArchive(TBankHistoryArchives historyArchives) {
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }


    /**
     * Получение истории архива
     *
     * @param archiveName - имя архива
     * @return - история архива
     */
    public TBankHistoryArchives getHistoryArchive(String archiveName) {
        TBankHistoryArchives tBankHistoryArchives = tBankHistoryArchivesRepo.getByName(archiveName);
        return Objects.requireNonNullElseGet(tBankHistoryArchives, TBankHistoryArchives::new);
    }

    /**
     * Сохранение истории запуска
     *
     */
    public void saveStartRun() {
        TBankRunHistory tBankRunHistory = new TBankRunHistory();
        tBankRunHistory.setStartTime(new Date());
        tBankRunHistory.setMicroservice(MICRO);
        tBankRunHistory.setStatus("START");
        tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
    }

    /**
     * Сохранение истории остановки
     *
     */
    public void saveEndRun(TBankRunHistory tBankRunHistory) {
        tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
    }

    /**
     * Сохранение истории остановки
     *
     */
    public void saveProcessEndRun() {
        TBankRunHistory tBankRunHistory = tBankRunHistoryRepo.getByMName(MICRO);
        if (tBankRunHistory != null){
            tBankRunHistory.setEndTime(new Date());
            tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
        }
    }


    /**
     * Получение истории запуска
     *
     * @return - история запуска
     */
    public TBankRunHistory getByMicroservice() {
        return tBankRunHistoryRepo.getByMName(MICRO);
    }

}
