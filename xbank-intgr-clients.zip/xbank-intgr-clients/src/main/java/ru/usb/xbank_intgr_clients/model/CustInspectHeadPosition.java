package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustInspectHeadPosition {
    private int inspectCusrNmb; //CLIENT таблицы tbank.customer.csv
    private int inspectInspectDate;//Дата регистрации
    private int inspectInspector;//Инспектор
    private int inspectName;//Номер налоговой инспекции
    private int inspectNotes;//Примечания
}
