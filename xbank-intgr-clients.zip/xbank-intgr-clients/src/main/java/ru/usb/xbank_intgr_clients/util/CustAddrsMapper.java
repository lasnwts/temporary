package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustAddrs;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustAddrs;
import ru.usb.xbank_intgr_clients.model.CustAddrsHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class CustAddrsMapper {

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    private static final String COMMA_DELIMITER = ";";

    public CheckCustAddrs map(String line, CustAddrsHeadPosition custAddrsHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        CustAddrs  custAddrs = new CustAddrs();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        custAddrs.setFileName(fileName);
        custAddrs.setNumInsert(numInsert);
        custAddrs.setInputDate(new Date());

        try{
            if (custAddrsHeadPosition.getClient() > -1) {
                custAddrs.setClient(values[custAddrsHeadPosition.getClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (custAddrsHeadPosition.getAddressType() > -1) {
                custAddrs.setAddressType(values[custAddrsHeadPosition.getAddressType()]);
            } else {
                setLoadError("Не найден обязательный параметр:ADDRESS_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ADDRESS_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ADDRESS_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (custAddrsHeadPosition.getAddressDateReg() > -1 && checkDateLine(values[custAddrsHeadPosition.getAddressDateReg()])){
                custAddrs.setAddressDateReg(convertDateToSqlDate(parseDateLine(values[custAddrsHeadPosition.getAddressDateReg()])));
            }else {
                setLoadError("Ошибка в параметре:ADDRESS_DATE_REG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ADDRESS_DATE_REG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ADDRESS_DATE_REG: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try{
            if (custAddrsHeadPosition.getLevelFiasRegion() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasRegion()])) {
                custAddrs.setLevelFiasRegion(parseInt( values[custAddrsHeadPosition.getLevelFiasRegion()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_region", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_region" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_region: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try{
            if (custAddrsHeadPosition.getAoguidRegion() > -1) {
                custAddrs.setAoguidRegion(values[custAddrsHeadPosition.getAoguidRegion()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_region", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_region" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_region: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try{
            if (custAddrsHeadPosition.getLevelFiasRegionArea() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasRegionArea()])) {
                custAddrs.setLevelFiasRegionArea(parseInt(values[custAddrsHeadPosition.getLevelFiasRegionArea()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_region_area", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_region_area" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_region_area: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (custAddrsHeadPosition.getAoguidRegionArea() > -1) {
                custAddrs.setAoguidRegionArea(values[custAddrsHeadPosition.getAoguidRegionArea()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_region_area", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_region_area" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_region_area: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getLevelFiasCity() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasCity()])) {
                custAddrs.setLevelFiasCity(parseInt(values[custAddrsHeadPosition.getLevelFiasCity()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_city", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_city" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_city: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAoguidCity() > -1) {
                custAddrs.setAoguidCity(values[custAddrsHeadPosition.getAoguidCity()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_city", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_city" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_city: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (custAddrsHeadPosition.getLevelFiasSetCity() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasSetCity()])) {
                custAddrs.setLevelFiasSetCity(parseInt(values[custAddrsHeadPosition.getLevelFiasSetCity()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_set_city", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_set_city" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_set_sity: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAoguidSetCity() > -1) {
                custAddrs.setAoguidSetCity(values[custAddrsHeadPosition.getAoguidSetCity()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_set_city", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_set_city" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_set_city: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getLevelFiasStreet() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasStreet()])) {
                custAddrs.setLevelFiasStreet(parseInt(values[custAddrsHeadPosition.getLevelFiasStreet()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_STREET", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_STREET" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_STREET: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAoguidStreet() > -1) {
                custAddrs.setAoguidStreet(values[custAddrsHeadPosition.getAoguidStreet()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_STREET", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_STREET" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_STREET: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getLevelFiasHouse() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasHouse()])) {
                custAddrs.setLevelFiasHouse(parseInt(values[custAddrsHeadPosition.getLevelFiasHouse()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_house", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_house" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_house: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAoguidHouse() > -1) {
                custAddrs.setAoguidHouse(values[custAddrsHeadPosition.getAoguidHouse()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_house", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_house" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_house: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try{
            if (custAddrsHeadPosition.getLevelFiasApartment() > -1 && checkInt(values[custAddrsHeadPosition.getLevelFiasApartment()])) {
                custAddrs.setLevelFiasApartment(parseInt(values[custAddrsHeadPosition.getLevelFiasApartment()]));
            } else {
                setLoadError("Ошибка в параметре:Level_Fias_apartment", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:Level_Fias_apartment" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:Level_Fias_apartment: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }


        try {
            if (custAddrsHeadPosition.getAoguidApartment() > -1) {
                custAddrs.setAoguidApartment(values[custAddrsHeadPosition.getAoguidApartment()]);
            } else {
                setLoadError("Не найден обязательный параметр:AOGUID_apartment", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:AOGUID_apartment" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:AOGUID_apartment: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAddressHouse() > -1) {
                custAddrs.setAddressHouse(values[custAddrsHeadPosition.getAddressHouse()]);
            } else {
                setLoadError("Не найден обязательный параметр:ADDRESS_HOUSE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ADDRESS_HOUSE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ADDRESS_HOUSE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAddressHouseKorp() > -1) {
                custAddrs.setAddressHouseKorp(values[custAddrsHeadPosition.getAddressHouseKorp()]);
            } else {
                setLoadError("Не найден обязательный параметр:ADDRESS_HOUSE_KORP", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ADDRESS_HOUSE_KORP" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ADDRESS_HOUSE_KORP: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custAddrsHeadPosition.getAddressApartament() > -1) {
                custAddrs.setAddressApartament(values[custAddrsHeadPosition.getAddressApartament()]);
            } else {
                setLoadError("Не найден обязательный параметр:ADDRESS_APARTAMENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ADDRESS_APARTAMENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ADDRESS_APARTAMENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            // TEMPORARY_REG
            if (custAddrsHeadPosition.getTemporaryReg() > -1 && checkInt(values[custAddrsHeadPosition.getTemporaryReg()])) {
                custAddrs.setTemporaryReg(parseInt(values[custAddrsHeadPosition.getTemporaryReg()]));
            } else {
                setLoadError("НОшибка в параметре:TEMPORARY_REG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TEMPORARY_REG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:TEMPORARY_REG: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //DATE_REG_END
            if (custAddrsHeadPosition.getDateRegEnd() > -1 && checkDateLine(values[custAddrsHeadPosition.getDateRegEnd()])){
                custAddrs.setDateRegEnd(convertDateToSqlDate(parseDateLine(values[custAddrsHeadPosition.getDateRegEnd()])));
            }else {
                setLoadError("Ошибка в параметре:DATE_REG_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_REG_END" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_REG_END: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        return new CheckCustAddrs(custAddrs, loadError);
    }

    /**
     * Установка ошибки
     * @param errorMessage - сообщение об ошибке
     * @param loadError - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()){
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }
    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
