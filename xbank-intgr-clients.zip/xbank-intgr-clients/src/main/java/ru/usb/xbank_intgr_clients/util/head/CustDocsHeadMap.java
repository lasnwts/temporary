package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustDocsHeadPosition;

@Component
public class CustDocsHeadMap {

    private static final String COMMA_DELIMITER = ";";

    public CustDocsHeadPosition map(String line) {
        String[] values = line.split(COMMA_DELIMITER);
        CustDocsHeadPosition custDocsHeadPosition = new CustDocsHeadPosition();
        custDocsHeadPosition.setClient(getPosition("CLIENT", values));
        custDocsHeadPosition.setDocType(getPosition("DOC_TYPE", values));
        custDocsHeadPosition.setDocSer(getPosition("DOC_SER", values));
        custDocsHeadPosition.setDocNum(getPosition("DOC_NUM", values));
        custDocsHeadPosition.setDocWho(getPosition("DOC_WHO", values));
        custDocsHeadPosition.setDocPlace(getPosition("DOC_PLACE", values));
        custDocsHeadPosition.setDocDate(getPosition("DOC_DATE", values));
        custDocsHeadPosition.setDocDateEnd(getPosition("DOC_DATE_END", values));
        custDocsHeadPosition.setDocDepartCode(getPosition("DOC_DEPART_CODE", values));
        custDocsHeadPosition.setDocMain(getPosition("DOC_MAIN", values));
        custDocsHeadPosition.setFileName(getPosition("FILENAME", values));
        custDocsHeadPosition.setInputDate(getPosition("INPUT_DATE", values));
        return custDocsHeadPosition;
    }
    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
