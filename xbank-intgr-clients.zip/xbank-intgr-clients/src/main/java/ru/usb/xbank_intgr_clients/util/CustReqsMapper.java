package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustReqs;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustReqs;
import ru.usb.xbank_intgr_clients.model.CustReqsHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.util.Date;

@Log4j2
@Component
public class CustReqsMapper {

    private final Support support;

    private static final String COMMA_DELIMITER = ";";

    @Autowired
    public CustReqsMapper(Support support) {
        this.support = support;
    }

    //REQS_CUSTNUMB;DATE_CHNG_NAME;CHILDREN_COUNT;DEPENDANTS_COUNT;FAMILY_MEMBERS;PREV_LAST_NAME;REASON_CHNG_NAME;OCCUPATION_STATE
    public CheckCustReqs map(String line, CustReqsHeadPosition custReqsHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        CustReqs custReqs = new CustReqs();
        custReqs.setFileName(fileName);
        custReqs.setNumInsert(numInsert);
        custReqs.setInputDate(new Date());

        try {
            if (custReqsHeadPosition.getReqsCustNumb() > -1) {
                custReqs.setReqsCustNumb(values[custReqsHeadPosition.getReqsCustNumb()]);
            } else {
                setLoadError("Не найден обязательный параметр:REQ_CUSTNUMB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:REQ_CUSTNUMB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:REQ_CUSTNUMB: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getDateChngName() > -1 && support.checkDateLine(values[custReqsHeadPosition.getDateChngName()])) {
                custReqs.setDateChngName(support.convertDateToSqlDate(support.parseDateLine(values[custReqsHeadPosition.getDateChngName()])));
            } else {
                setLoadError("Ошибка в параметре:DATE_CHNG_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_CHNG_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_CHNG_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getChildrenCount() > -1 && support.checkInt(values[custReqsHeadPosition.getChildrenCount()])) {
                custReqs.setChildrenCount(support.parseInt(values[custReqsHeadPosition.getChildrenCount()]));
            } else {
                setLoadError("Ошибка в параметре:CHILDREN_COUNT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CHILDREN_COUNT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CHILDREN_COUNT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getDependantsCount() > -1 && support.checkInt(values[custReqsHeadPosition.getDependantsCount()])) {
                custReqs.setDependantsCount(support.parseInt(values[custReqsHeadPosition.getDependantsCount()]));
            } else {
                setLoadError("Ошибка в параметре:DEPENDANTS_COUNT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DEPENDANTS_COUNT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DEPENDANTS_COUNT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getFamilyMembers() > -1 && support.checkInt(values[custReqsHeadPosition.getFamilyMembers()])) {
                custReqs.setFamilyMembers(support.parseInt(values[custReqsHeadPosition.getFamilyMembers()]));
            } else {
                setLoadError("Ошибка в параметре:FAMILY_MEMBERS", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:FAMILY_MEMBERS" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:FAMILY_MEMBERS: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getPrevLastName() > -1) {
                custReqs.setPrevLastName(values[custReqsHeadPosition.getPrevLastName()]);
            } else {
                setLoadError("Не найден обязательный параметр:PREV_LAST_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PREV_LAST_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PREV_LAST_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getReasonChngName() > -1) {
                custReqs.setReasonChngName(values[custReqsHeadPosition.getReasonChngName()]);
            } else {
                setLoadError("Не найден обязательный параметр:REASON_CHNG_NAME", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:REASON_CHNG_NAME" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:REASON_CHNG_NAME: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custReqsHeadPosition.getOccupationState() > -1) {
                custReqs.setOccupationState(values[custReqsHeadPosition.getOccupationState()]);
            } else {
                setLoadError("Не найден обязательный параметр:OCCUPATION_STATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OCCUPATION_STATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:OCCUPATION_STATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        return new CheckCustReqs(custReqs, loadError);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
