package ru.usb.xbank_intgr_clients.model.db;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Структура таблицы приведена в таблице 2.
 * Таблица 2 – Струткура таблицы TBANK_HISTORY_ARCHIVES
 * Поле	Название поля	Описание	Тип данных
 * id	id записи		NUMBER
 * archive_name	Название файла - архива от Тбанка		VARCHAR2(255)
 * date_start	Дата и время начала обработки архива		TIMESTAMP(6)
 * date_end	Дата и время завершения обработки архива		TIMESTAMP(6)
 * TbankFiles	Флаг доставки сообщения в бакет S3	1 – доставлено
 * 0-  не доставлено	VARCHAR2(10)
 * KafkaIn	Флаг доставки сообщения в Kafka	1 – доставлено
 * 0 – не доставлено	VARCHAR2(10)
 * error	Результат обработки	0 - успех
 * 1 - ошибка	VARCHAR2(10)
 * errortext	Текст ошибки		VARCHAR2(2000)
 * total_result	Результат обработки - количество файлов	Предлагается заполнять статистикой работы процесса:
 * Количество договоров:
 * успешно - ХХ
 * с ошибкой - ХХ
 *
 * Количество файлов:
 * успешно - ХХ
 * с ошибкой - ХХ	VARCHAR2(2000)
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_HISTORY_ARCHIVES")
public class TBankHistoryArchives {

    @Id
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "ARCHIVE_NAME")//
    private String archiveName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_START")
    private Date dateStart;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_END")
    private Date dateEnd;

    @Column(name = "TBANK_FILES",  length = 10)
    private String tbankFiles;

    @Column(name = "KAFKA_IN",length = 10)
    private String kafkaIn;

    @Column(name = "ERROR",  length = 10)
    private String error;

    @Column(name = "ERRORTEXT",  length = 2000)
    private String errortext;

    @Column(name = "TOTAL_RESULT", length = 2000) //количество файлов	Предлагается заполнять статистикой работы процесса
    private String totalResult;

}
