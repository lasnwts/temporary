package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustCont;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustCont;
import ru.usb.xbank_intgr_clients.model.CustContHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class CustContMapper {

    private static final String COMMA_DELIMITER = ";";

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    public CheckCustCont map(String line, CustContHeadPosition custContHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        CustCont custCont = new CustCont();
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        custCont.setNumInsert(numInsert);
        custCont.setFileName(fileName);
        custCont.setInputDate(new Date());


        try {
            if (custContHeadPosition.getClient() > -1) {
                custCont.setClient(values[custContHeadPosition.getClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:CLIENT", loadError);
            }
        }catch (Exception e) {
            setLoadError("Ошибка в параметре:CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custContHeadPosition.getContactsPrivate() > -1) {
                custCont.setContactsPrivate(values[custContHeadPosition.getContactsPrivate()]);
            } else {
                setLoadError("Не найден обязательный параметр:CONTACTS_PRIVATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CONTACTS_PRIVATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CONTACTS_PRIVATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custContHeadPosition.getContactsActiv() > -1 && checkInt(values[custContHeadPosition.getContactsActiv()])) {
                custCont.setContactsActiv(parseInt(values[custContHeadPosition.getContactsActiv()]));
            } else {
                setLoadError("Ошибка в параметре:CONTACTS_ACTIV", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CONTACTS_ACTIV" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CONTACTS_ACTIV: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custContHeadPosition.getContactsNumb() > -1) {
                custCont.setContactsNumb(values[custContHeadPosition.getContactsNumb()]);
            } else {
                setLoadError("Не найден обязательный параметр:CONTACTS_NUMB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CONTACTS_NUMB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CONTACTS_NUMB: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            if (custContHeadPosition.getContactsType() > -1) {
                custCont.setContactsType(values[custContHeadPosition.getContactsType()]);
            } else {
                setLoadError("Не найден обязательный параметр:CONTACTS_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CONTACTS_TYPE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CONTACTS_TYPE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        return new CheckCustCont(custCont, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
