package ru.usb.externalbank_intgr_siebel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.externalbank_intgr_siebel.configure.Configure;
import ru.usb.externalbank_intgr_siebel.configure.LG;
import ru.usb.externalbank_intgr_siebel.model.*;
import ru.usb.externalbank_intgr_siebel.service.db.ApiLayerDB;
import ru.usb.externalbank_intgr_siebel.service.mail.ServiceMailError;
import ru.usb.externalbank_intgr_siebel.service.s3.ApiLayerS3;
import ru.usb.externalbank_intgr_siebel.util.MapperEvents;
import ru.usb.externalbank_intgr_siebel.util.PackMapper;
import ru.usb.externalbank_intgr_siebel.util.Support;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

@Service
public class Executor2Service {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    Logger log = LoggerFactory.getLogger(Executor2Service.class);

    private final Configure configure;
    private final ServiceMailError serviceMailError;
    private final Support support;
    private final ApiLayerS3 apiLayerS3;
    private final ApiLayerDB apiLayerDB;
    private final MapperEvents mapperEvents;
    private final PackMapper packMapper;


    private static ExecutorService executorService;

    @Autowired
    public Executor2Service(Configure configure, ServiceMailError serviceMailError, Support support,
                            ApiLayerS3 apiLayerS3, ApiLayerDB apiLayerDB,
                            MapperEvents mapperEvents, PackMapper packMapper) {
        this.configure = configure;
        this.serviceMailError = serviceMailError;
        this.support = support;
        this.apiLayerS3 = apiLayerS3;
        this.apiLayerDB = apiLayerDB;
        this.mapperEvents = mapperEvents;
        this.packMapper = packMapper;
    }

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = Executors.newFixedThreadPool(poolSize);
    }

    public synchronized ExecutorService getThreadPool() {
        return executorService;
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        log.info("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
        log.info("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.info("{}:T{} Поток передан на запуск в executor service. Поток с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
    }

    class MyThread implements Runnable {
        String message;
        CountDownLatch latch;

        MyThread(CountDownLatch c, String messageBody) {
            latch = c;
            message = messageBody;
            new Thread(this);
        }

        public void run() {
            //Старт потока
            log.info("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());
            //Обработка сообщения
            Optional<KafkaMessage> kafkaMessage = mapperEvents.getDocument(message);
            ProcessMessage processMessage = new ProcessMessage();
            kafkaMessage.ifPresent(value -> {
                log.debug("kafkaMessage: {}", value);
                processMessage.setKafkaMessage(value);
            });
            if (kafkaMessage.isPresent()) {
                Optional<Pack> pack = packMapper.getPack(kafkaMessage.get().getPack());
                pack.ifPresent(value -> {
                    log.debug("pack: {}", value);
                    processMessage.setPack(pack.get());
                    //Получаем переменные
                    processMessage.setFilelink(pack.get().getFilelink());
                    processMessage.setError(kafkaMessage.get().getError());
                    processMessage.setErrorText(kafkaMessage.get().getErrortext());
                    processMessage.setPackID(kafkaMessage.get().getPackID());
                });
            }

            //Проверяем наличие нужных данных
            if (processMessage.getKafkaMessage() != null &&
                    processMessage.getPack() != null &&
                    processMessage.getPackID() != null &&
                    processMessage.getFilelink() != null) {
                log.info("{}:T{}: :Переменные назначены корректно", LG.USBLOGINFO, Thread.currentThread().getId());
                doWork(processMessage);
            }

            //Подвал завершения потока
            log.info("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.info("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }


        /**
         * Процесс обработки
         *
         * @param processMessage - сообщение
         */
        private void doWork(ProcessMessage processMessage) {
            if (processMessage.getError() == null || processMessage.getError().isEmpty()) {
                try {
                    //Проверяем наличие записи в БД
                    List<TBankHistoryFiles> tBankHistoryFiles = apiLayerDB.getTBankFiles(processMessage.getPackID());
                    if (tBankHistoryFiles.isEmpty()) { //Запись не найдена в базе
                        // Отправляем сообщение
                        serviceMailError.sendMailBusinessSubject("Микросервис: Externalbank-intgr-siebel. Ошибка удаления файла",
                                " Файл с packID=" + support.getWrapNull(processMessage.getPackID()) + " не удален из БД.\n\r " +
                                        " Не найден в базе!" + "\n\r" +
                                        "Сообщение:Pack " + processMessage.getPack());
                        log.error("{}:T{}:[doWork] Файл не удален из хранилища s3, запись с PackID={} не найдена в базе", LG.USBLOGERROR, Thread.currentThread().getId(),
                                processMessage.getPackID());
                        log.error("{}:T{}: Сообщение с ошибкой:{} ", LG.USBLOGERROR, Thread.currentThread().getId(), processMessage.getKafkaMessage());
                    } else {
                        //Запись найдена в базе, проставляем в записи дату окончания
                        tBankHistoryFiles.get(0).setDateEnd(new Date());
                        apiLayerDB.saveFile(tBankHistoryFiles.get(0));
                        //Удаляем файл из хранилища
                        HttpStatus httpStatus = apiLayerS3.deleteFileFromS3(configure.getS3BucketBase(), processMessage.getFilelink());
                        if (httpStatus.is2xxSuccessful()) {
                            log.info("{}:T{}: :Файл удален из S3", LG.USBLOGINFO, Thread.currentThread().getId());
                            deleteNumDog(tBankHistoryFiles.get(0)); //Удаляем ссылку с номером договора, если пустой номер договора, без файлов
                            deleteArchiveDirectory(tBankHistoryFiles.get(0)); //Удаляем если пустой архив
                            saveStatusArchive(tBankHistoryFiles.get(0).getArchiveName()); //Записываем в таблицу TBANK_HISTORY_ARCHIVES
                        } else {
                            log.info("{}:T{}: :Файл НЕ удален из S3", LG.USBLOGINFO, Thread.currentThread().getId());
                        }
                    }
                } catch (Exception e) {
                    log.error("{}:T{}: Возникла ошибка при обработке сообщения:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
                    log.error("{}:T{}: Сообщение вызвавшее ошибку:{}", LG.USBLOGERROR, Thread.currentThread().getId(), processMessage.getKafkaMessage());
                    serviceMailError.sendMailBusinessSubject("Микросервис: Externalbank-intgr-siebel. Возникла ошибка в процессе обработки сообщения",
                            "Сообщение:Pack " + processMessage.getPack() + "\n\r" +
                                    "Описание ошибки:" + e.getMessage() + "\n\r");
                }
            } else {
                //Если сообщение содержит ошибку
                doErrorWork(processMessage);
            }
        }

        /**
         * Процедура удаления номера договора из s3
         * @param tBankHistoryFiles - запись в БД
         * @return - true - удален, false - не удален
         */
        private boolean deleteNumDog(TBankHistoryFiles tBankHistoryFiles) {
            //Поиск folder
            CheckEmptyLinkS3 checkEmptyLinkS3 = checkEmptyDirectory(tBankHistoryFiles.getFolderName());
            if (checkEmptyLinkS3.isEmptyLinkS3() && checkEmptyLinkS3.getCounts() == 1) {
                //Удаляем файл из хранилища
                HttpStatus httpStatus = apiLayerS3.deleteFileFromS3(configure.getS3BucketBase(), tBankHistoryFiles.getFolderName() + "/"); //Удаляем пустой номер договора
                if (httpStatus.is2xxSuccessful()) {
                    log.info("{}:T{}: :Номер договора:{} без файлов удален из S3,  бакет:{}", LG.USBLOGINFO, Thread.currentThread().getId(), tBankHistoryFiles.getFolderName() + "/", configure.getS3BucketBase());
                    return true;
                } else {
                    log.info("{}:T{}: Номер договора:{} был НЕ удален из S3", LG.USBLOGINFO, Thread.currentThread().getId(), tBankHistoryFiles.getFolderName() + "/");
                    return false;
                }
            }
            return false;
        }


        /**
         * Процедура удаления ссылки с именем архива, когда ссылка пустая
         * @param tBankHistoryFiles  - запись в БД
         * @return - true - удален, false - не удален
         */
        private void deleteArchiveDirectory(TBankHistoryFiles tBankHistoryFiles) {
            //Поиск Archive name - получаем имя архива для поиска и удаления
            CheckEmptyLinkS3 checkEmptyLinkS3 = checkEmptyDirectory(support.getFileNameWithoutExtension(tBankHistoryFiles.getArchiveName()));
            if (checkEmptyLinkS3.isEmptyLinkS3() && checkEmptyLinkS3.getCounts() == 1) {
                //Удаляем файл из хранилища
                HttpStatus httpStatus = apiLayerS3.deleteFileFromS3(configure.getS3BucketBase(), support.getFileNameWithoutExtension(tBankHistoryFiles.getArchiveName()) + "/"); //Удаляем пустой номер договора
                if (httpStatus.is2xxSuccessful()) {
                    log.info("{}:T{}: Имя архива:{} - без файлов удален из S3,  бакет:{}", LG.USBLOGINFO, Thread.currentThread().getId(), support.getFileNameWithoutExtension(tBankHistoryFiles.getArchiveName()) + "/", configure.getS3BucketBase());
                } else {
                    log.info("{}:T{}: Имя архива::{} был НЕ удален из S3", LG.USBLOGINFO, Thread.currentThread().getId(), support.getFileNameWithoutExtension(tBankHistoryFiles.getArchiveName()) + "/");
                }
            }
        }

        /**
         * Процедура сохранения статуса архива
         * @param fileNameArchive - имя архива
         */
        private void saveStatusArchive(String fileNameArchive){
            //Поиск Archive name - получаем имя архива для поиска и удаления
            CheckEmptyLinkS3 checkEmptyLinkS3 = checkEmptyDirectory(support.getFileNameWithoutExtension(fileNameArchive));
            if (checkEmptyLinkS3.getCounts() == 0){
                //Поиск нужной записи в списке загруженных файлов
                TBankHistoryArchives tBankHistoryArchives = apiLayerDB.getHistoryArchive(fileNameArchive);
                tBankHistoryArchives.setError("0");
                tBankHistoryArchives.setErrortext("");
                tBankHistoryArchives.setDateEnd(new Date());
                apiLayerDB.saveHistoryArchive(tBankHistoryArchives); //сохраняем, это конец обработки
            }
        }


        /**
         * ---
         * 2.2.	Если error = 1 (сообщение с ошибкой), то:
         * •	внести информацию в БД TBANK_HISTORY_FILES (см. таблицу 3) в поля:
         * o	error = 1;
         * o	error_text = errortext из топика externalbank-test.siebel.clients_dossier
         * o	KafkaIn = 0
         * •	сгенерировать и направить сообщение Email в службу технической поддержки, которое должно содержать: «Сообщение с ошибкой в Siebel», микросервис, error = 1 (сообщение с ошибкой), packID, error_text = errortext из топика externalbank-test.siebel.clients_dossier
         * Пример 11
         * Сообщение с ошибкой в Siebel
         * Микросервис: Tbank-intgr-Siebel
         * packID: 1-E67SPON
         * error = 1 (сообщение с ошибкой)
         * error_text = «Тест ошибки»
         * ---
         * Обработка ошибки
         *
         * @param processMessage - сообщение
         */
        private void doErrorWork(ProcessMessage processMessage) {
            List<TBankHistoryFiles> tBankHistoryFiles = apiLayerDB.getTBankFiles(processMessage.getPackID());
            if (tBankHistoryFiles.isEmpty()) {
                log.error("{}:T{}:[doErrorWork] Файл не удален из хранилища s3, запись с PackID={} не найдена в базе", LG.USBLOGERROR, Thread.currentThread().getId(),
                        processMessage.getPackID());
            } else {
                try {
                    tBankHistoryFiles.forEach(tBankHistoryFile -> {
                        tBankHistoryFile.setKafkaIn("0");
                        tBankHistoryFile.setErrorText(processMessage.getErrorText());
                        tBankHistoryFile.setError("1");
                        serviceMailError.sendMailBusinessSubject("Микросервис: Externalbank-intgr-siebel. Сообщение с ошибкой в Siebel",
                                "Микросервис: Externalbank-intgr-siebel. " +
                                        "PackID=" + processMessage.getPackID() + "\n\r" +
                                        "Описание ошибки:" + processMessage.getErrorText() + "\n\r");
                    });
                } catch (Exception e) {
                    log.error("{}:T{}:[doErrorWork] Возникла ошибка при обработке сообщения:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
                    log.error("{}:T{}:[doErrorWork] Сообщение вызвавшее ошибку:{}", LG.USBLOGERROR, Thread.currentThread().getId(), processMessage.getKafkaMessage());
                    serviceMailError.sendMailBusinessSubject("Микросервис: Externalbank-intgr-siebel. Возникла ошибка в процессе обработки сообщения",
                            "Сообщение:Pack " + processMessage.getPack() + "\n\r" +
                                    "Описание ошибки:" + e.getMessage() + "\n\r");
                }
            }
        }

        /**
         * Передаем номер договора и проверяем на пустоту
         *
         * @param linkSearch - номер договора или архива
         */
        private CheckEmptyLinkS3 checkEmptyDirectory(String linkSearch) {
            List<String> listFiles = apiLayerS3.listFilesS3(configure.getS3BucketBase());
            CheckEmptyLinkS3 checkEmptyLinkS3 = new CheckEmptyLinkS3();
            checkEmptyLinkS3.setEmptyLinkS3(false);
            checkEmptyLinkS3.setCounts(0);
            //ищем, суть такая ием по всему списку, если есть более одного включения то значит в бакете есть еще файлы
            if (listFiles == null || listFiles.isEmpty()) {
                log.info("{}:T{}: :Список файлов бакете:{} пуст", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getS3BucketBase());
            } else {
                listFiles.forEach(numDog -> {
                    if (numDog.contains(linkSearch)) {
                        checkEmptyLinkS3.setEmptyLinkS3(true);
                        checkEmptyLinkS3.setCounts(checkEmptyLinkS3.getCounts() + 1);
                        log.debug("{}:T{}: :Cписок файлов бакет:{}, содержит номер договора {}", LG.USBLOGINFO, Thread.currentThread().getId(), numDog, linkSearch);
                    }
                });
            }
            return checkEmptyLinkS3;
        }


    }
}
