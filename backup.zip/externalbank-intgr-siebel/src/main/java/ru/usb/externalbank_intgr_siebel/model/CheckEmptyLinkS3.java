package ru.usb.externalbank_intgr_siebel.model;

import lombok.*;

/**
 * Используем для проверки наличия пустой ссылки в S3
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CheckEmptyLinkS3 {
    private boolean emptyLinkS3; //есть ссылка или нет
    private String linkS3; // ссылка в хранилище s3
    private int counts; //Количество повторений строки (номера договора или архива)
}
