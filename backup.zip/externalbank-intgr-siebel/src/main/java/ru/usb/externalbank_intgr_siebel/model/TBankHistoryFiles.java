package ru.usb.externalbank_intgr_siebel.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * TBANK_HISTORY_FILES
 * ----------------
 * Струткура таблицы TBANK_HISTORY_FILES
 * Поле	Название поля	Описание	Тип данных
 * id	id записи		NUMBER
 * archive_name	Название файла - архива от Тбанка		VARCHAR2(255)
 * folder_name	Название каталога, извлеченного из архива.	Соответствует номеру кредитного договора	VARCHAR2(255)
 * file_name	Название файла		VARCHAR2(255)
 * file_name_guid	Название файла, загружаемого в Siebel CRM c добавленным GUID		VARCHAR2(1000)
 * file_guid	GUID файла		VARCHAR2(255)
 * file_ext	Расширение файла, загружаемого в Siebel CRM		VARCHAR2(10)
 * file_size	Размер файла, загружаемого в Siebel CRM		NUMBER
 * file_link	Ссылка на файл в S3		VARCHAR2(1000)
 * packID	Уникальный идентификатор запроса. По packID будет сопоставляться ответ на запрос на стороне системы-инициатора		STRING
 * KafkaIn	Флаг доставки сообщения до Kafka	1 – доставлено  * 0 – не доставлено	VARCHAR2(10)
 * error	Код ошибки		VARCHAR2(10)
 * error_text	Текст ошибки		VARCHAR2(2000)
 * date_start	Дата+время начала загрузки файла		TIMESTAMP(6)
 * date_end	Дата+время завершения загрузки файла		TIMESTAMP(6)
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_HISTORY_FILES")
public class TBankHistoryFiles {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "ARCHIVE_NAME")//Название файла - архива от Тбанка
    private String archiveName;

    @Column(name = "FOLDER_NAME")//Название каталога, извлеченного из архива. Соответствует номеру кредитного договора
    private String folderName;

    @Column(name = "FILE_NAME")//Название файла
    private String fileName;

    @Column(name = "FILE_NAME_GUID", length = 1000)//Название файла, загружаемого в Siebel CRM c добавленным GUID
    private String fileNameGuid;

    @Column(name = "FILE_GUID")//GUID файла
    private String fileGuid;

    @Column(name = "FILE_EXT", length = 10)//Расширение файла, загружаемого в Siebel CRM
    private String fileExt;

    @Column(name = "FILE_SIZE")//Размер файла, загружаемого в Siebel CRM
    private long fileSize;

    @Column(name = "FILE_LINK", length = 1000)//Ссылка на файл в S3
    private String fileLink;

    @Column(name = "PACKID")//Уникальный идентификатор запроса. По packID будет сопоставляться ответ на запрос на стороне системы-инициатора
    private String packID;

    @Column(name = "KAFKA_IN", length = 10)//Флаг доставки сообщения до Kafka
    private String kafkaIn;

    @Column(name = "ERROR", length = 10)//Код ошибки
    private String error;

    @Column(name = "ERROR_TEXT", length = 2000)//Текст ошибки
    private String errorText;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_START")//Дата+время начала загрузки файла
    private Date dateStart;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_END")//Дата+время завершения загрузки файла
    private Date dateEnd;

}
