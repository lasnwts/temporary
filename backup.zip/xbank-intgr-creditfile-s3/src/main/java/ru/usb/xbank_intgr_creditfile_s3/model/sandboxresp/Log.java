package ru.usb.xbank_intgr_creditfile_s3.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Log {
    @JsonProperty("type")
    private String type;
    @JsonProperty("file_name")
    private String fileName;
    @JsonProperty("file_uri")
    private String fileUri;
}
