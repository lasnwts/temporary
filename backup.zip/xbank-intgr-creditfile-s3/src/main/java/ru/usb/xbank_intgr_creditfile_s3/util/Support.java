package ru.usb.xbank_intgr_creditfile_s3.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;


import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

@Log4j2
@Component
public class Support {

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    SimpleDateFormat sdfCode = new SimpleDateFormat("yyyyMMdd");
    DateTimeFormatter sdfTimeStamp = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss,SSSSSS");


    /**
     * Получение кода даты
     *
     * @param date - дата
     * @return - код даты
     */
    public int getCode(Date date) {
        return Integer.parseInt(sdfCode.format(date));
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Обрезка строки до 2000 символов
     * @param line - строка
     * @return - строка
     */
    public String getStr2000(String line){
        if (line == null) {
            return "";
        }
        if (line.length() > 2000) {
            return line.substring(0, 1999);
        } else {
            return line;
        }
    }


    /**
     * Проверка даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDate(String date) {
        return GenericValidator.isDate(date, "dd.MM.yyyy", true);
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDate(String date) {
        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDate:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Форматирование даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDate(Date date) {
        return sdf.format(date);
    }


    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Очистка директории
     */
    public void cleanTempDirectory() {
        try {
            FileUtils.cleanDirectory(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + configure.getNetFileShare()).toFile());
        } catch (Exception e) {
            log.error("{}:Support.cleanTempDirectory:Ошибка при удалении директории {}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    SimpleDateFormat numInsert = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    /**
     * Получение номера вставки
     *
     * @return - номер вставки
     */
    public long getNumInsert() {
        return Long.parseLong(numInsert.format(new Date()));
    }


    /**
     * Разбиение строки на массив
     *
     * @param line - строка
     * @return - массив
     */
    public String[] splitFile(String line) {
        return line.split(Pattern.quote(File.separator));
    }

    /**
     * Получение расширения файла
     *
     * @param line - строка
     * @return - расширение
     */
    public String getExtension(String line) {
        return FilenameUtils.getExtension(line);
    }

    /**
     * Получение имени файла без расширения
     *
     * @param line - строка
     * @return - имя файла
     */
    public String getFileNameWithoutExtension(String line) {
        return FilenameUtils.removeExtension(line);
    }

    /**
     * Получение ключа
     *
     * @param path           - путь
     * @param parentFileName - имя родительского файла
     * @return - ключ
     */
    public String getKey(Path path, String parentFileName) {
        /**
         *  Определяем 00037021756592, и отрезаем все вплоть до значения 00037021756592/
         *  Остается: Cвидетельство о регистрации авто.pdf - это и будет ключом.
         *  Заменяем знак \ на знак /
         *  ----
         *          int i1 =path.toString().indexOf(parentFileName) + parentFileName.length() + 1;
         *         int i2 = path.toString().length();
         *         int i3 = path.toString().length();
         *         String s =  path.toString().substring(i1, i2);
         *         //String key = path.toString().substring(path.toString().indexOf(parentFileName) + 1,  parentFileName.length()).replace("\\", "/");
         *         String s1 = path.toString().substring(path.toString().indexOf(parentFileName) + parentFileName.length() + 1,  path.toString().length());
         *         String s = path.toString().substring(path.toString().indexOf(parentFileName) + parentFileName.length() + 1,  path.toString().length()).replace("\\", "/");
         */
        return parentFileName + "/" + path.toString().substring(path.toString().indexOf(parentFileName) + parentFileName.length() + 1, path.toString().length()).replace("\\", "/");
    }

    /**
     * Получение имени кредита
     *
     * @param line - строка
     * @return - имя кредита
     */
    public String getCreditName(String line) {
        return FilenameUtils.getName(line);
    }

    /**
     * Получение номера кредита
     *
     * @param line - строка
     * @return - номер кредита - первый внутренний каталог в пути
     */
    public Optional<String> getCreditNumber(String line) {
        if (line == null || line.trim().isEmpty()) return Optional.empty();
        String[] subDirs = line.split(Pattern.quote(File.separator));
        return Optional.of(subDirs[subDirs.length - 2]);
    }

    /**
     * Получение номера кредита
     *
     * @param line - строка
     * @return - номер кредита - первый внутренний каталог в пути
     */
    public Optional<String> getCreditNumberFromDirectory(String line) {
        if (line == null || line.trim().isEmpty()) return Optional.empty();
        String[] subDirs = line.split(Pattern.quote(File.separator));
        return Optional.of(subDirs[subDirs.length - 1]);
    }

    /**
     * Получение GUID
     *
     * @param line - строка
     * @return - GUID
     */
    public String getUUID(String line) {
        return UUID.nameUUIDFromBytes(line.getBytes()).toString();
    }

    /**
     * Проверка числа, что тут одни числа
     *
     * @param line - строка
     * @return - результат проверки
     */
    public boolean checkIntNumDog(String line) {
        if (line == null || line.trim().isEmpty()) return false;
        try {
            Long.parseLong(line);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка файла
     *
     * @param fileName - имя файла
     * @return - результат проверки
     */
    public boolean checkFileMask(String fileName){
        if (fileName == null || fileName.trim().length() < 12) return false;
        return fileName.substring(0, 6).equalsIgnoreCase(configure.getS3MaskFile()) &&
                getExtension(fileName).equalsIgnoreCase(configure.getS3ExtFile());
    }

}

