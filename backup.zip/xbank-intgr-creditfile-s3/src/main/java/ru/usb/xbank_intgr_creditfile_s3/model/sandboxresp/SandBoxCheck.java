package ru.usb.xbank_intgr_creditfile_s3.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_creditfile_s3.model.sandbox.Errors;

import java.util.ArrayList;

/**
 * Пример:
 * {
 *   "name": "ApplicationPropertiesFactoringGetEvents11072024.xlsx",
 *   "status": null,
 *   "file": "C:\\Projects\\FUSE\\MP\\factorin-files-receiving\\tmp\\ApplicationPropertiesFactoringGetEvents11072024.xlsx",
 *   "message": "Файл удален из временной директории",
 *   "checkMessage": "Файл передан в песочницу для проверки",
 *   "checkStatus": 200,
 *   "errors": [],
 *   "date": "2024-07-22T09:38:14.665+00:00",
 *   "result": {
 *     "scan_state": "FULL",
 *     "verdict": "CLEAN",
 *     "errors": [],
 *     "duration": 73.69095313176513,
 *     "duration_full": 73.69095313176513
 *   },
 *   "fileUri": "sfm-files:///2024-07-22-09/1e2d0b20-480e-11ef-bb70-173b0d9cf36e/fd6e8425-f4ad-42bc-93ec-848f3cd046c9"
 * }
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SandBoxCheck {
    @JsonProperty("errors")
    private ArrayList<Errors> errors;
    @JsonProperty("data")
    private Data data;
//    @JsonProperty("name")
//    private String name;
//    @JsonProperty("status")
//    private Object status;
//    @JsonProperty("file")
//    private String file;
//    @JsonProperty("message")
//    private String message;
//    @JsonProperty("checkMessage")
//    private String checkMessage;
//    @JsonProperty("checkStatus")
//    private int checkStatus;
//    @JsonProperty("date")
//    private Date date;
//    @JsonProperty("result")
//    private Result result;
//    @JsonProperty("fileUri")
//    private String fileUri;
}
