package ru.usb.xbank_intgr_creditfile_s3.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_s3.configure.Configure;
import ru.usb.xbank_intgr_creditfile_s3.configure.LG;
import ru.usb.xbank_intgr_creditfile_s3.model.FtpsResponse;
import ru.usb.xbank_intgr_creditfile_s3.model.S3File;
import ru.usb.xbank_intgr_creditfile_s3.model.TBankHistoryArchives;
import ru.usb.xbank_intgr_creditfile_s3.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_creditfile_s3.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_creditfile_s3.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_creditfile_s3.service.zip.ZipCheck;
import ru.usb.xbank_intgr_creditfile_s3.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@Service
public class Executor2Service {


    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final Configure configure;
    private final ServiceMailError serviceMailError;
    private final ApiLayer apiLayer;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    private final ZipCheck zipCheck;
    private final Support support;
    private final ApiLayerS3 apiLayerS3;


    @Autowired
    public Executor2Service(Configure configure, ServiceMailError serviceMailError, ApiLayer apiLayer,
                            TBankHistoryArchivesRepo tBankHistoryArchivesRepo, ZipCheck zipCheck, Support support, ApiLayerS3 apiLayerS3) {
        this.configure = configure;
        this.serviceMailError = serviceMailError;
        this.apiLayer = apiLayer;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
        this.zipCheck = zipCheck;
        this.support = support;
        this.apiLayerS3 = apiLayerS3;
    }

    Logger log = LoggerFactory.getLogger(Executor2Service.class);
    /**
     * инициализация: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = Executors.newFixedThreadPool(poolSize);
    }

    public synchronized ExecutorService getThreadPool() {
        return executorService;
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        log.info("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
        log.info("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.info("{}:T{} Поток передан на запуск в executor service. Поток с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
    }

    class MyThread implements Runnable {
        String message;
        CountDownLatch latch;


        MyThread(CountDownLatch c, String messageBody) {
            latch = c;
            message = messageBody;
            new Thread(this);
        }

        public void run() {
            //Старт потока
            log.info("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());

            FtpsResponse ftpsResponse = apiLayer.downloadFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), message, apiLayer.getTempPath(), Thread.currentThread().getId());
            log.info("{}:T{}: Файл:{} получен с сервера FTPS. Статус:{}", LG.USBLOGINFO, Thread.currentThread().getId(), message, ftpsResponse.getCode());
            ftpsResponse = checkZip(ftpsResponse); //Проверяем на битость архив
            S3File s3File = null;
            if (ftpsResponse.getCode() == 200) {
                try {
                    s3File = saveFileToS3(configure.getS3BucketQuarantine(), ftpsResponse.getFile(), Thread.currentThread().getId());
                    saveHistoryArchive(ftpsResponse, "0");
                } catch (Exception e) {
                    log.error("{}:T{}: Ошибка при попытке сохранения файла в S3 бакет. Ошибка:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
                }
                //Продолжаем работу
                // Проверка в SandBox
//                    if (configure.isCheckSandbox()){
//                        //вызываем SandBox
//                    }
                // Перевод из бакета карантин в бакет окончательный
                if (s3File != null) {
                    try {
                        copyFileToS3(configure.getS3BucketBase(), s3File, Thread.currentThread().getId());
                        //Удаляем файл из бакета карантин
                        HttpStatus httpStatus = apiLayerS3.deleteFileS3(s3File.getBucket(), s3File.getName(), Thread.currentThread().getId());
                        if (httpStatus == HttpStatus.OK) {
                            log.info("{}:T{}: Файл:{} удален из S3 бакета карантин", LG.USBLOGINFO, Thread.currentThread().getId(), s3File.getName());
                            saveHistoryArchiveLast(s3File.getName(), null, null, "1");
                        } else {
                            log.info("{}:T{}: Файл:{} НЕ удален из S3 бакета карантин", LG.USBLOGINFO, Thread.currentThread().getId(), s3File.getName());
                            saveHistoryArchiveLast(s3File.getName(), "1", "Файл не удален из S3 бакета карантин", "0");
                        }
                        try{
                            deleteFileFromFTPS(ftpsResponse); //Удаляем файл на FTPS
                        } catch (Exception exception){
                            log.error("{}:T{}: Ошибка при попытке удаления файла:{} на FTPS сервере. Ошибка:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getFile().getName(), exception.getMessage());
                        }
                    } catch (Exception e) {
                        log.error("{}:T{}: Ошибка при попытке переноса файла в S3 бакет. Ошибка:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
                        saveHistoryArchiveLast(s3File.getName(), "1", "Ошибка при попытке переноса файла в S3 баке" + e.getMessage(), "0");
                    }
                } else { //s3File - exist
                    if (ftpsResponse.getFile() != null) {
                        log.error("{}:T{}: Возникла неизвестная Ошибка при попытке сохранения файла:{} в S3 бакет карантина:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getFile().getName(), configure.getS3BucketQuarantine());
                        saveHistoryArchiveLast(ftpsResponse.getFile().getName(), "1","Возникла неизвестная Ошибка при попытке сохранения файла в бакет карантина." + support.getWrapNull(ftpsResponse.getMessage()), "0");
                    } else {
                        log.error("{}:T{}: Возникла неизвестная Ошибка при попытке сохранения файла в S3 бакет карантина:{}", LG.USBLOGERROR, Thread.currentThread().getId(), configure.getS3BucketQuarantine());
                        saveHistoryArchiveLast("null", "1", "Возникла неизвестная Ошибка при попытке сохранения файла в бакет карантина." + support.getWrapNull(ftpsResponse.getMessage()), "0");
                    }
                }
            } else {
                log.error("{}:T{}: Возникли проблемы, при обработке файла:{}, описание проблемы:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getName(), ftpsResponse.getMessage());
                saveHistoryArchiveLast(ftpsResponse.getFile().getName(), "1", support.getWrapNull(ftpsResponse.getMessage()), "0");
            }

            //Подвал завершения потока
            log.info("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.info("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }
    }


    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchive(FtpsResponse ftpsResponse, String tBankFiles) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setDateStart(new Date());
        historyArchives.setTbankFiles(tBankFiles);
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение изменений
     *
     */

    /**
     * Сохранение изменений
     * @param error - код ошибки
     * @param errorText - описание ошибки
     * @param tBankFiles - файлы
     */
    public void saveHistoryArchiveLast(String name, String error, String errorText, String tBankFiles) {
        TBankHistoryArchives historyArchives = tBankHistoryArchivesRepo.getByName(name);
        if (historyArchives == null) {
           log.error("{}:T{}: Возникли проблемы, при обработке файла:{}, не найдена запись в базе данных об этом файле! Таблица:[TBANK_HISTORY_ARCHIVES]", LG.USBLOGERROR, Thread.currentThread().getId(), name);
           return;
        }
        if (error != null && !error.isEmpty()) {
            historyArchives.setError(error);
            historyArchives.setErrortext(errorText);
        }
        if (tBankFiles != null && !tBankFiles.isEmpty()) {
            historyArchives.setTbankFiles(tBankFiles);
        }
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }

    /**
     * Сохранение файла в бакет Карантина
     *
     * @param bucket - бакет
     * @param file   - объект файла
     */
    public S3File saveFileToS3(String bucket, File file, long thread) throws Exception {
        //TEST TEST TEST
        Thread.sleep(500);

        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        //Создаем описание
        S3File s3File = new S3File();
        s3File.setBucket(bucket);
        s3File.setName(file.getName());
        s3File.setKey(file.getName());
        s3File.setSize(file.length());
        s3File.setSuccess(false); //пока нет окончательного успеха или провала
        do {
            i++;
            try {
                if (apiLayerS3.saveFileToS3(bucket, file.getName(), file, Thread.currentThread().getId())) {
                    log.info("{}:T{} File {} uploaded to S3 bucket {}", LG.USBLOGINFO, thread, file.getName(), bucket);
                    Files.deleteIfExists(file.toPath());
                    success = true;
                    s3File.setSuccess(true);
                } else {
                    log.error("{}:T{}: saveFileToS3 - File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
                }
            } catch (Exception e) {
                log.error("{}:T{}: Ошибка возникла при попытке сохранения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд",
                        LG.USBLOGERROR, thread, i, timeWait / 1000);
                exception = e; //Для переноса
                log.error("{}:T{}: Error saving file to S3: {}", LG.USBLOGERROR, thread, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}:T{} Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR, thread);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        if (!success) {
            log.error("{}:T{}: File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
            String errorMess = null;
            if (exception != null && exception.getMessage() != null) {
                errorMess = exception.getMessage();
            } else {
                errorMess = "Неизвестная ошибка";
            }
            if (apiLayerS3.getS3StatusCode(errorMess).is4xxClientError()) {
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            } else {
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            }
        }
        return s3File;
    }

    /**
     * Сохранение файла в бакет Карантина
     *
     * @param bucket - бакет
     * @param file   - объект файла
     */
    public S3File saveFileToS3Storage(String bucket, File file, long thread) throws Exception {
        //TEST TEST TEST
        Thread.sleep(500);

        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        //Создаем описание
        S3File s3File = new S3File();
        s3File.setBucket(bucket);
        s3File.setName(file.getName());
        s3File.setKey(file.getName());
        s3File.setSize(file.length());
        s3File.setSuccess(false); //пока нет окончательного успеха или провала
        do {
            i++;
            try {
                if (apiLayerS3.saveFileToS3(bucket, file.getName(), file, Thread.currentThread().getId())) {
                    log.info("{}:T{} File {} uploaded to S3 bucket {}", LG.USBLOGINFO, thread, file.getName(), bucket);
                    Files.deleteIfExists(file.toPath());
                    success = true;
                    s3File.setSuccess(true);
                } else {
                    log.error("{}:T{}: saveFileToS3 - File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
                }
            } catch (Exception e) {
                log.error("{}:T{}: Ошибка возникла при попытке сохранения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд",
                        LG.USBLOGERROR, thread, i, timeWait / 1000);
                exception = e; //Для переноса
                log.error("{}:T{}: Error saving file to S3: {}", LG.USBLOGERROR, thread, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}:T{} Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR, thread);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        if (!success) {
            log.error("{}:T{}: File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
            String errorMess = null;
            if (exception != null && exception.getMessage() != null) {
                errorMess = exception.getMessage();
            } else {
                errorMess = "Неизвестная ошибка";
            }
            if (apiLayerS3.getS3StatusCode(errorMess).is4xxClientError()) {
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            } else {
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            }
        }
        return s3File;
    }


    /**
     * Сохранение файла из бакета в бакет
     *
     * @param bucket - бакет
     * @param s3File - объект файла
     */
    public void copyFileToS3(String bucket, S3File s3File, long thread) throws Exception {

        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        do {
            i++;
            try {
                if (apiLayerS3.copyFileS3(s3File.getBucket(), s3File.getKey(), bucket, configure.getS3DirInput() + "/" + s3File.getKey(), thread)) {
                    log.info("{}:T{} Файл {} скопирован мз bucket:{} в другой бакет -> S3 bucket:{}{} ", LG.USBLOGINFO, thread, s3File.getBucket(),
                            s3File.getKey(), bucket, configure.getS3DirInput() + "/" + s3File.getKey());
                    success = true;
                } else {
                    log.error("{}:T{}: Копирование файла из бакета в бакет, завершилось неудачно! File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, s3File.getName(), bucket);
                }
            } catch (Exception e) {
                log.error("{}:T{}: Ошибка возникла при попытке копирования файла:{}  из бакета:{} в бакет:{}! Номер попытки:{}, время ожидания до следующей попытки={} секунд",
                        LG.USBLOGERROR, thread, s3File.getName(), s3File.getBucket(), bucket, i, timeWait / 1000);
                exception = e; //Для переноса
                log.error("{}:T{}: Ошибка копирования файла из бакета в бакет S3: {}", LG.USBLOGERROR, thread, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}:T{} [copyFileS3] Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR, thread);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        if (!success) {
            log.error("{}:T{}: Файл {} не скопирован! Из бакета: S3 bucket {} в бакет -> S3 bucket {}", LG.USBLOGERROR, thread, s3File.getName(), s3File.getBucket(), bucket);
            String errorMess = null;
            if (exception != null && exception.getMessage() != null) {
                errorMess = exception.getMessage();
            } else {
                errorMess = "Неизвестная ошибка";
            }
            if (apiLayerS3.getS3StatusCode(errorMess).is4xxClientError()) {
                serviceMailError.sendMailErrorSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(s3File.getName()) + " не перемещен из бакета:" + support.getWrapNull(s3File.getBucket()) +
                        " в бакет:" + support.getWrapNull(bucket)
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            } else {
                serviceMailError.sendMailErrorSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(s3File.getName()) + " не перемещен из бакета:" + support.getWrapNull(s3File.getBucket()) +
                        " в бакет:" + support.getWrapNull(bucket)
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            }
        }
    }


    /**
     * Проверка zip-архива
     *
     * @param ftpsResponse - объект ответа
     */
    public FtpsResponse checkZip(FtpsResponse ftpsResponse) {
        if (zipCheck.isValidZipFile(ftpsResponse, apiLayer.getThreadTempPath(Thread.currentThread().getId()), Thread.currentThread().getId())) {
            ftpsResponse.setCode(200);
            log.info("{}:T{}: Файл:{} успешно прошел проверку zip-архива", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getName());
            return ftpsResponse;
        } else {
            ftpsResponse.setCode(415);
            ftpsResponse.setMessage("zip-архив поврежден");
            saveHistoryArchiveBadZip(ftpsResponse); //Записываем, что архив битый
            serviceMailError.sendMailSubject(configure.getLetterBadZzipSubject(), configure.getLetterBadZzip()
                    + "\n\r" + "Файл:" + support.getWrapNull(ftpsResponse.getFile().getName()) +
                    "\n\r" + "Описание:" + support.getWrapNull(ftpsResponse.getMessage()));
            log.error("{}:T{}: Файл:{} НЕ прошел проверку zip-архива", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getName());
            try {
                Files.deleteIfExists(ftpsResponse.getFile().toPath());
                log.info("{}:T{}: Файл:{} удален", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getAbsolutePath());
              ftpsResponse = apiLayer.deleteFtpsFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), ftpsResponse.getFile().getName());
              if (ftpsResponse.getHttpStatus().isError()){
                  log.error("{}:T{}: Произошла ошибка на FTPS:{} при удалении файла:{}, попробуем удалить файл еще раз", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getMessage(), ftpsResponse.getName());
                  deleteFileFromFTPS(ftpsResponse); //Удаляем файл на FTPS
              } else {
                  log.info("{}:T{}: Файл:{} удален. На FTPS сервере", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
              }

            } catch (IOException e) {
                log.error("{}:T{}: Ошибка:{} при удалении файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage(), ftpsResponse.getFile().getAbsolutePath());
            }
            return ftpsResponse;
        }

    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchiveBadZip(FtpsResponse ftpsResponse) {
        TBankHistoryArchives historyArchives = new TBankHistoryArchives();
        historyArchives.setDateStart(new Date());
        historyArchives.setArchiveName(ftpsResponse.getFile().getName());
        historyArchives.setError("1");
        historyArchives.setErrortext(ftpsResponse.getMessage());
        historyArchives.setTbankFiles("0");
        historyArchives.setDateEnd(new Date());
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }


    /**
     * Удаление файла
     *
     * @param ftpsResponse - объект ответа
     */
    public void deleteFileFromFTPS(FtpsResponse ftpsResponse){

        ftpsResponse = apiLayer.deleteFtpsFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), ftpsResponse.getName());
        if (ftpsResponse.getHttpStatus().isError()){
            log.error("{}:T{}: Произошла ошибка на FTPS:{} при удалении файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getMessage(), ftpsResponse.getName());
        } else {
            log.info("{}:T{}: Файл:{} удален на FTPS", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
        }

    }

}