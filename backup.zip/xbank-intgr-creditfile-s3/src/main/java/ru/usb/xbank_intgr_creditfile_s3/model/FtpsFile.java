package ru.usb.xbank_intgr_creditfile_s3.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class FtpsFile {
    private String name;
    private long size;
}
