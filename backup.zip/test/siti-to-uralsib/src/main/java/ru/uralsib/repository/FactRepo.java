package ru.uralsib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import ru.uralsib.dto.FactDto;

import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface FactRepo extends JpaRepository<FactDto, Long> {
    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select d.id, d.S,d.dateo,d.OPER,d.SUM,d.VALUTA from TEST_FACT d where d.S in (select s from test_dogov where s is not null and processed is null and depart like :depart)")
    Stream<FactDto> getFlowFact(@Param("depart") String depart);
}
