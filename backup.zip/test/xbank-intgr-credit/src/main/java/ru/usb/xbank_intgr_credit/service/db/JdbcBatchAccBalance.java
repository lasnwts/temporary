package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.AccBalance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchAccBalance {

    /**
     * "ID" NUMBER(19,0) NOT NULL ENABLE,
     * 	"ACC" VARCHAR2(255 CHAR),
     * 	"FILENAME" VARCHAR2(255 CHAR),
     * 	"INPUT_DATE" TIMESTAMP (6),
     * 	"NUMINSERT" NUMBER(19,0),
     * 	"S" VARCHAR2(255 CHAR),
     * 	"SUM" NUMBER(19,2),
     */

    Logger log = LoggerFactory.getLogger(JdbcBatchAccBalance.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchAccBalance(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    private static final String INSERT_TO_ACCBALANCE = "INSERT INTO TEST_ACCBALANCE (ACC,FILENAME,INPUT_DATE,NUMINSERT,S,SUM,ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? )";


    public void save(List<AccBalance> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_ACCBALANCE);

            for (AccBalance currentRecord : entities) {
                insertStatement.setString(1, currentRecord.getAcc()); //ACC
                insertStatement.setString(2, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(4, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setString(5, currentRecord.getS());//S
                insertStatement.setBigDecimal(6, currentRecord.getSum());//SUM
                insertStatement.setLong(7, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }
}
