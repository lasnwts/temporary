package ru.usb.xbank_intgr_credit.service.db;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.Planall;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;


@Component
public class JdbcBatchInsert {

    Logger log = LoggerFactory.getLogger(JdbcBatchInsert.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchInsert(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    private static final String INSERT_TO_PLANALL = "INSERT INTO test_planall (CHANGE, DATEO, DATE_BEG,DATE_END,FILENAME,INPUT_DATE,NUMINSERT,OPER,S,SUM,VALUTA, ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?)";


    public void save(List<Planall> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_PLANALL);

            for (Planall currentRecord : entities) {
                insertStatement.setString(1, currentRecord.getChange()); //CHANGE
                insertStatement.setDate(2, currentRecord.getDate()); //DATEO
                insertStatement.setDate(3, currentRecord.getDateBeg()); //DATE_BEG
                insertStatement.setDate(4, currentRecord.getDateEnd()); //DATE_END
                insertStatement.setString(5, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(7, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setString(8, currentRecord.getOper());//OPER
                insertStatement.setString(9, currentRecord.getS());//S
                insertStatement.setBigDecimal(10, currentRecord.getSum());//SUM
                insertStatement.setString(11, currentRecord.getValuta());//VALUTA
                insertStatement.setLong(12, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }
}
