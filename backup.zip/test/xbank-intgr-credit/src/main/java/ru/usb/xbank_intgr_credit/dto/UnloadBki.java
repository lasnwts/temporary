package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TEST_UNLOAD_BKI")
public class UnloadBki {

    @Id
    //@GeneratedValue(generator = "increment")
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S")//2
    private String s;

    @Column(name = "TB_RELATIONSHIP")//3
    private int tbRelationship;

    @Column(name = "TB_TYPE")//4
    private String tbType;

    @Column(name = "TB_LOANTYPECODE")//5
    private String tbLoanTypeCode;

    @Column(name = "TB_STARTAMOUOUTST")//6
    private BigDecimal tbStartAmouOutst; //Оставляем

    @Column(name = "TB_CUROVERDUEDT_TA")//7
    private Date tbCuroverdueDtTa; //Оставляем

    @Column(name = "TB_MSPYMNTNXTRDT")//8
    private Date tbMsPymntNxtrDt; //Оставляем

    @Column(name = "TB_MSPYMNTNTRSTDT")//9
    private Date tbMsPymntNtrstDt; //Оставляем

    @Column(name = "TB_PASTDUEDAYS")//10
    private String tbPastDueDays;

    @Column(name = "TB_PAIDPASTDUEDAYS")//11
    private String tbPaidPastDueDays;

    @Column(name = "TB_LASTAMOUNT_30PD")//12
    private BigDecimal tbLastAmount30Pd; //Оставляем

    @Column(name = "TB_TTLAMOUNT24M30PD")//13
    private BigDecimal tbTtlAmount24m30Pd; //Оставляем

    @Column(name = "TB_DEBTRANGE")//14
    private String tbDebtRange;

    @Column(name = "TB_DEBTCALCDATE")//15
    private Date tbDebtCalcDate; //Оставляем

    @Column(name = "TB_INCOMEWAYTYPE")//16
    private String tbIncomeWayType;

    @Column(name = "TB_INCOMEINFOSOURCE")//17
    private String tbIncomeInfoSource;

    @Column(name = "TB_COBORROWERSDEBT")//18
    private String tbCoborrowersDebt;

    @Column(name = "TB_STATESUPPORT")//19
    private String tbStateSupport;

    @Column(name ="TB_STATESUPPORTINFO", length = 2000)
    private String tbStateSupportInfo;//20

    //20.11.2024
    // TB_LOANPURPOSECODE
    // TB_DATECONTRTERM
    @Column(name = "TB_LOANPURPOSECODE")//21
    private String tbLoanPurposeCode;

    @Column(name = "TB_DATECONTRTERM")//22
    private Date tbDateContrTerm; //Оставляем


    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки


    @Column(name = "PROCESSED")//21
    private String processed;

    @Column(name = "PROCESSED_TEXT")//22
    private String processedText;
}
