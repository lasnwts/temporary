package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.MigrInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchMigrInfo {


    /**
     * "CURR_TERM" VARCHAR2(255 CHAR),
     * "DATE_BEG_ORIG" DATE,
     * "DATE_END" DATE,
     * "DATE_END_ORIG" DATE,
     * "DATE_FIRST_PAY" DATE,
     * "DATE_LASTPAY_COMMIT" DATE,
     * "DATE_NEXT_PAYMENT" DATE,
     * "NUM_PMTS_MADE" VARCHAR2(255 CHAR),
     * "NUM_PMTS_REM" VARCHAR2(255 CHAR),
     * "ORIG_TERM" VARCHAR2(255 CHAR),
     * "PAY_DAY_CURR" VARCHAR2(255 CHAR),
     * "PAY_DAY_ORIG" VARCHAR2(255 CHAR),
     * "PAY_SUM_CURR" NUMBER(19,2),
     * "PRC_RATE_CURR" NUMBER,
     * "PRC_RATE_ORIG" NUMBER,
     * "REFINANCE" VARCHAR2(255 CHAR),
     * "SUM_LASTPAY_COMMIT" NUMBER(19,2),
     * "SUM_NEXT_PAYMENT" NUMBER(19,2),
     * "SUM_OVERDUE" NUMBER(19,2),
     * "TOTAL_DAYS_OVERDUE" VARCHAR2(255 CHAR),
     * <p>
     * "S" VARCHAR2(255 CHAR), 23
     * "FILENAME" VARCHAR2(255 CHAR), 24
     * "INPUT_DATE" TIMESTAMP (6), 25
     * "NUMINSERT" NUMBER(19,0), 26
     * "ID" NUMBER(19,0) NOT NULL ENABLE, 27
     */


    Logger log = LoggerFactory.getLogger(JdbcBatchMigrInfo.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchMigrInfo(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    //CURR_TERM,   1
    //DATE_BEG_ORIG, 2
    //DATE_END, 3
    //DATE_END_ORIG, 4
    //DATE_FIRST_PAY, 5
    //DATE_LASTPAY_COMMIT, 6
    //DATE_NEXT_PAYMENT, 7
    //NUM_PMTS_MADE, 8
    //NUM_PMTS_REM, 9
    //ORIG_TERM, 10
    //PAY_DAY_CURR, 11
    //PAY_DAY_ORIG, 12
    //PAY_SUM_CURR, 13
    //PRC_RATE_CURR, 14
    //PRC_RATE_ORIG, 15
    //REFINANCE, 16
    //SUM_LASTPAY_COMMIT, 17
    //SUM_NEXT_PAYMENT, 18
    //SUM_OVERDUE, 19
    //TOTAL_DAYS_OVERDUE, 20
    //S,  21
    //FILENAME,  22
    //INPUT_DATE,  23
    //NUMINSERT,  24
    //ID 25

    private static final String INSERT_TO_MIGR_INFO = "INSERT INTO TEST_MIGR_INFO (CURR_TERM,DATE_BEG_ORIG,DATE_END,DATE_END_ORIG,DATE_FIRST_PAY,DATE_LASTPAY_COMMIT,DATE_NEXT_PAYMENT,NUM_PMTS_MADE,NUM_PMTS_REM,ORIG_TERM,PAY_DAY_CURR,PAY_DAY_ORIG,PAY_SUM_CURR,PRC_RATE_CURR,PRC_RATE_ORIG,REFINANCE,SUM_LASTPAY_COMMIT,SUM_NEXT_PAYMENT,SUM_OVERDUE,TOTAL_DAYS_OVERDUE,S,FILENAME,INPUT_DATE,NUMINSERT,ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


    public void save(List<MigrInfo> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_MIGR_INFO);

            for (MigrInfo currentRecord : entities) {
                insertStatement.setString(1, currentRecord.getCurrTerm()); //CURR_TERM

                insertStatement.setDate(2, currentRecord.getDateBegOrig()); //DATE_BEG_ORIG
                insertStatement.setDate(3, currentRecord.getDateEnd()); //DATE_END
                insertStatement.setDate(4, currentRecord.getDateEndOrig()); //DATE_END_ORIG
                insertStatement.setDate(5, currentRecord.getDateFirstPay()); //DATE_FIRST_PAY
                insertStatement.setDate(6, currentRecord.getDateLastpayCommit()); //DATE_LASTPAY_COMMIT
                insertStatement.setDate(7, currentRecord.getDateNextPayment()); //DATE_NEXT_PAYMENT

                insertStatement.setString(8, currentRecord.getNumPmtsMade()); //NUM_PMTS_MADE
                insertStatement.setString(9, currentRecord.getNumPmtsRem()); //NUM_PMTS_REM
                insertStatement.setString(10, currentRecord.getOrigTerm()); //ORIG_TERM
                insertStatement.setString(11, currentRecord.getPayDayCurr()); //PAY_DAY_CURR
                insertStatement.setString(12, currentRecord.getPayDayOrig()); //PAY_DAY_ORIG

                insertStatement.setBigDecimal(13, currentRecord.getPaySumCurr());//PAY_SUM_CURR

                insertStatement.setBigDecimal(14, currentRecord.getPrcRateCurr());//PRC_RATE_CURR
                insertStatement.setBigDecimal(15, currentRecord.getPrcRateOrig());//PRC_RATE_ORIG

                insertStatement.setString(16, currentRecord.getRefinance()); //REFINANCE

                insertStatement.setBigDecimal(17, currentRecord.getSumLastpayCommit());//SUM_LASTPAY_COMMIT
                insertStatement.setBigDecimal(18, currentRecord.getSumNextPayment());//SUM_NEXT_PAYMENT
                insertStatement.setBigDecimal(19, currentRecord.getSumOverdue());//SUM_OVERDUE

                insertStatement.setString(20, currentRecord.getTotalDaysOverdue());//TOTAL_DAYS_OVERDUE

                insertStatement.setString(21, currentRecord.getS());//S
                insertStatement.setString(22, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(23, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(24, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setLong(25, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }


}
