package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;

//accbalance.csv
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TEST_ACCBALANCE")
public class AccBalance {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора

    @Column(name = "ACC")//3
    private String acc;//Балансовый счет для учета задолженности

    @Column(name = "SUM")//4
    private BigDecimal sum;//Сумма остатка на счете

    //Имя файла
    @Column(name = "FILENAME")//5
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//6
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//7
    private long numInsert; //Номер вставки

}
