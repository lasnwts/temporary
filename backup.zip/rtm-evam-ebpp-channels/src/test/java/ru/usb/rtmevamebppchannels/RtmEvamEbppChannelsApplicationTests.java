package ru.usb.rtmevamebppchannels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtmEvamEbppChannelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
