package ru.usb.rtmevamebppchannels.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    //File resource for temporary files
    @Value("${net.file.share}")
    private String netFileShare;

    //File resource for temporary files
    @Value("${file.charset:windows-1251}")
    private String fileCharset;

    public String getFileCharset() {
        return fileCharset;
    }

    /**
     * Количество задач в очереди
     */
    private int threads;


    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private Integer servicePoolSize;


    /**
     * Кол-во потоков
     */
    public synchronized int getThreads() {
        return threads;
    }

    public synchronized void setThreads(int threads) {
        this.threads = threads;
    }

    public int getServicePoolSize() {
        return servicePoolSize;
    }

    /**
     * JMS queue
     * tibco.queue.rtm=way4_interact
     */
    @Value("${tibco.queue.rtm:way4_interact}")
    private String emsQueueRtm;

    /**
     * Секция о программе
     */

    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.application.version}")
    private String appVersion;


    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    /**
     * Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Реализация
     */

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    public String getEmsQueueRtm() {
        return emsQueueRtm;
    }

    public String getNetFileShare() {
        return netFileShare;
    }
}
