package ru.usb.rtmevamebppchannels.utils;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class DateUtilites {

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    /**
     * Возвращаем дату в формате yyyy-MM-dd HH:mm:ss
     * Пример:2022-11-09 12:42:11
     * @return - строка с датой
     */
    public String getSdf(){
        return sdf.format(new Date());
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Возвращаем часть подстроки длиной менее 3997 символов
     *
     * @param line исходная строка
     * @return - обрезанная строка
     */
    public String getMaxLength3998(String line) {
        if (line == null) {
            return "";
        }
        if (line.trim().length() < 3998) {
            return line;
        }
        return line.trim().substring(0, 3997);
    }

    /**
     * Обрамление ошибки
     *
     * @param errorDetails - предыдущая запись о ошибке
     * @param message      - текущее сообщение о ошибке
     * @return - строка с ошибкой вместе
     */
    public String getErrorMessage(String errorDetails, String message) {
        if (errorDetails == null) {
            errorDetails = "";
        }

        if (message == null) {
            return errorDetails;
        }

        if (!errorDetails.isEmpty()) {
            return errorDetails + ", " + message;
        }
        return message;
    }


}
