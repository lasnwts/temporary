package ru.usb.rtmevamebppchannels.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.rtmevamebppchannels.model.MapDataToRTM;
import ru.usb.rtmevamebppchannels.model.MessageFromRTM;
import ru.usb.rtmevamebppchannels.utils.DateUtilites;


/**
 * Ошибка в процедуре
 * Тут еще не хватает StackTrace и анализа SQL Exception
 * SOURCE		Y	STRING	Константа “CHANNEL_event”
 * EVENT_TYPE		Y	STRING	Если ЕБПП вернул «успех», то присваивается значение “EBPP_UPD_SUCCESS”, иначе “EBPP_UPD_ERROR”
 * ID	ID	Y	NUMBER	Как есть
 * CLIENT_ID	CLIENT_ID	N	NUMBER	Как есть
 * CLIENT_DID	CLIENT_DID	N	NUMBER	Как есть
 * EVAM_ACTORID	EVAM_ACTORID	Y	STRING	Как есть
 * EVAM_SCENARIO 	EVAM_SCENARIO 	N	STRING	Как есть
 * EVENT_DATETIME		Y	DATA	Дата отправки мск. Формат YYYY-MM-DD HH24:MM:SS
 * CONTACT_ID	CONTACT_ID	Y	NUMBER	Как есть
 * ERROR_CODE		N	NUMBER	Код ошибки. Отправляется только если EVENT_TYPE= EBPP_UPD_ERROR
 * ERROR_DETAIL		N	STRING	Не кодифицированный текст ошибки
 * Отправляется только если EVENT_TYPE= EBPP_UPD_ERROR
 */

@Component
public class MappingToRtm {

    private final DateUtilites dateUtilits;

    @Autowired
    public MappingToRtm(DateUtilites dateUtilits) {
        this.dateUtilits = dateUtilits;
    }

    public MapDataToRTM mappingRTM(MessageFromRTM mapRTM) {

        MapDataToRTM mapErrRTM = new MapDataToRTM();

        if (mapRTM == null) {
            return null;
        }

        /**
         * Присвоение констант
         */
        mapErrRTM.setSource("CHANNEL_event");
        mapErrRTM.setEventType("EBPP_ERROR");
        mapErrRTM.setEventDateTime(dateUtilits.getSdf());
        mapErrRTM.setId(mapRTM.getId());
        mapErrRTM.setClientID(mapRTM.getClientId());
        mapErrRTM.setClientDID(mapRTM.getClientDid());
        mapErrRTM.setContactID(mapRTM.getContactId());
        mapErrRTM.setEwamActorid(mapRTM.getEvamActorid());
        mapErrRTM.setEwamScenario(mapRTM.getEvamScenario());

        /**
         * SQL Execption -??
         * StackTrace - deatil erre - ??
         */
        mapErrRTM.setErrorCode(""); //or 0
        mapErrRTM.setErrorDetail("");

        return mapErrRTM;
    }


}
