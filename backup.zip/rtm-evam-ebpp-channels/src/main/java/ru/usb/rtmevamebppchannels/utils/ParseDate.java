package ru.usb.rtmevamebppchannels.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.rtmevamebppchannels.configure.Configure;
import ru.usb.rtmevamebppchannels.configure.Elog;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class ParseDate {


    /**
     * формат даты-времени
     */
    private static final String FORMATDATE = "yyyy-MM-dd";
    private static final String FORMATDATETIME = "yyyy-MM-dd'T'HH:mm:ss";

    private final Configure configure;

    @Autowired
    public ParseDate(Configure configure) {
        this.configure = configure;
    }

    LocalDate date;

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(FORMATDATE);

    DateTimeFormatter shortDateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    DateTimeFormatter siebelDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");

    //
    DateTimeFormatter formatterShort = DateTimeFormatter.ofPattern(FORMATDATETIME);

    SimpleDateFormat sdfT = new SimpleDateFormat(FORMATDATETIME);

    SimpleDateFormat sdfS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    DateTimeFormatter formatterForm = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    Logger logger = LoggerFactory.getLogger(ParseDate.class);


    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:Дата = {}  не соответствует формату ::{}", Elog.UsbLogError, sDate, FORMATDATE);
            return false;
        }
    }

    /**
     * @param date - дата
     * @return - строка
     */
    public String getDate(LocalDate date) {
        try {
            return date.format(shortDateFormat);
        } catch (DateTimeException dateTimeException) {
            logger.error("{}: Ошибка преобразования даты {} в строку в формата {}", Elog.UsbLogError, date, "dd/MM/yyyy");
            logger.error("{}: Вместо даты возвращаем пустую строку ", Elog.UsbLogError);
            return "";
        }
    }


    /**
     * @param date
     * @return
     */
    public String getSiebelDate(LocalDate date) {
        try {
            return date.format(siebelDateFormat);
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:Ошибка преобразования даты {} в строку в формата {}", Elog.UsbLogError, date, "MM/dd/yyyy");
            logger.error("{}:Вместо даты возвращаем пустую строку", Elog.UsbLogError);
            return "";
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate(String sDate) {
        try {
            return LocalDate.parse(sDate, formatter);
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:=> Дата = {} -  не соответствует формату ::{}", Elog.UsbLogError, sDate, FORMATDATE);
            return null;
        }
    }

    /**
     * Возвращаем строковое значение даты yyyy-mm-dd
     *
     * @param dateString
     * @return
     */
    public String getPartDateStr(String dateString) {
        if (dateString == null) {
            logger.error("{}:[ParseDate].[getPartDateStr] = dateString. Передано NULL  значение! ", Elog.UsbLogError);
            logger.error("{}: Вместо даты возвращаем пустую   строку ", Elog.UsbLogError);
            return "";
        }
        if (dateString.trim().length() < 10) {
            logger.error("{}: [ParseDate].[getPartDateStr],dateString = {} Передано неверное значение!! ", Elog.UsbLogError, dateString);
            logger.error("{}:Вместо даты  возвращаем  -пустую строку ", Elog.UsbLogError);
            return "";
        }
        String dateStr = dateString.trim().substring(0, 10);
        return dateStr.trim();
    }

    /**
     * Возвращаем часть строки, это часы, минуты, сек = 00:00:00
     *
     * @param dateString
     * @return
     */
    public String getPartTimeStr(String dateString) {
        if (dateString == null) {
            logger.error("{}:[ParseDate].[getPartDateStr] = dateString. Передано NULL значение!", Elog.UsbLogError);
            logger.error("{}:: Вместо даты возвращаем пустую строку!", Elog.UsbLogError);
            return "";
        }
        if (dateString.trim().length() < 18) {
            logger.error("{}:[ParseDate].[getPartDateStr],dateString={} Передано неверное значение!", Elog.UsbLogError, dateString);
            logger.error("{}:Вместо временем возвращаем строку=00:00:00", Elog.UsbLogError);
            return "00:00:00";
        }
        String dateStr = dateString.trim().substring(dateString.trim().indexOf(" "));
        return dateStr.trim();
    }


    /**
     * Возвращаем новый формат даты, типа Зибель формат DD/MM/YYYY HH:M:SS
     *
     * @param datefrom
     * @return
     */
    public String getSiebelFormatDate(String datefrom) {
        if (datefrom == null) {
            logger.error("{}:[ParseDate].[getSiebelFormatDate] = datefrom. Передано NULL значение!", Elog.UsbLogError);
            logger.error("{}:Вместо даты возвращаем => пустую строку", Elog.UsbLogError);
            return "";
        }
        if (parseDate(getPartDateStr(datefrom))) {
            return getSiebelDate(getDate(getPartDateStr(datefrom))) + " " + getPartTimeStr(datefrom);
        }
        return "";
    }


    /**
     * К line значению параметра TEMPLATE_CODE добавляется “_” и текущая дата в формате ddMMyyyy
     *
     * @param line
     * @return
     */
    public String getDateDDMMYYYY(String line) {
        if (line == null) {
            logger.error("{}:[ParseDate].[getDateDDMMYYYY]TEMPLATE_CODE => TEMPLATE_CODE_ddMMYYYY. Передано NULL значение TEMPLATE_CODE!", Elog.UsbLogError);
            logger.error("{}:Вместо даты возвращаем пустую строку!", Elog.UsbLogError);
            return "";
        }
        return line + sdf.format(new Date());
    }


    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm:ss
     */
    public boolean parseDateSiebel(String sDate) {
        if (sDate == null) {
            logger.error("{}:Дата = sDate ==NULL! Функция parseDateSiebel! Дата не должна быть null", Elog.UsbLogError);
            return false;
        }
        return (parseLongDate(sDate) || parseShortDate(sDate));
    }

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm:ss
     */
    public boolean parseShortDate(String sDate) {

        if (sDate == null) {
            logger.error("{}:Дата = sDate ==NULL! Функция parseShortDate! Дата не должна быть null", Elog.UsbLogError);
            return false;
        }

        try {
            if (sDate.length() > 20) {
                sDate = sDate.substring(0, 19);
            }
            date = LocalDate.parse(sDate, formatterShort);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:Дата = {} ->  не соответствует формату ::{};", Elog.UsbLogError, sDate, FORMATDATETIME);
            return false;
        }
    }

    /**
     * Проверка на формат 2022-09-23 14:39:41
     *
     * @param dateString - строка с датой
     * @return - boolean
     */
    public boolean parseDateForm(String dateString) {

        if (dateString == null) {
            logger.error("{}:Дата = dateString ==NULL! Функция parseDateForm! Дата не должна быть null", Elog.UsbLogError);
            return false;
        }

        try {
            date = LocalDate.parse(dateString, formatterForm);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:=> Дата ={} ==  не соответствует формату ::{};", Elog.UsbLogError, dateString, "yyyy-MM-dd HH:mm:ss");
            return false;
        }
    }

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm:ss
     */
    public boolean parseLongDate(String sDate) {

        if (sDate == null) {
            logger.error("{}:Дата = sDate ==NULL! Функция parseLongDate! Дата не должна быть null", Elog.UsbLogError);
            return false;
        }

        try {
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:=: Дата = {} =  не соответствует формату :{};", Elog.UsbLogError, sDate, FORMATDATE);
            return false;
        }
    }

    public Date getRealDate(String sDate) {
        if (sDate == null) {
            return null;
        }
        try {
            if (sDate.length() > 20) {
                sDate = sDate.substring(0, 19);
            }
            return sdfT.parse(sDate);
        } catch (ParseException dateTimeException) {
            logger.error("{}::: Дата = {};  не соответствует формату ::{};", Elog.UsbLogError, sDate, FORMATDATETIME);
            return null;
        }
    }

    public String getSiebelDate(Date sDate) {
        if (sDate == null) {
            return "";
        }
        return sdfS.format(sDate);
    }


}
