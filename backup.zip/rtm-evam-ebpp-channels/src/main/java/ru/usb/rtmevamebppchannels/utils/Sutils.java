package ru.usb.rtmevamebppchannels.utils;

import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Класс с утилитами для строк
 */

@Component
public class Sutils {

    SimpleDateFormat shortDateFormat = new SimpleDateFormat("ddMMyyyy");

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Возвращаем строку в видк ddMMyyyy
     *
     * @return
     */
    public String getShortNowDate() {
        return shortDateFormat.format(new Date());
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        if (fileNameFull == null) {
            return false;
        }
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        return Files.exists(path);
    }

    //Получаем файл
    public File getFile(String location) {
        return new File(location);
    }

    /**
     * Получаем контекст файла
     *
     * @param file - файл
     * @return - контекст
     */
    public String getContentFile(File file, Charset charset) {
        String text = null;
        try {
            byte[] arrayBytes = Files.readAllBytes(file.toPath());
            text = new String(arrayBytes, charset);
        } catch (IOException e) {
            return null;
        }
        return text;
    }

}
