package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckMigrInfo;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.MigrInfoHeadPosition;
import ru.usb.xbank_intgr_credit.repository.MigrInfoRepo;
import ru.usb.xbank_intgr_credit.util.MigrInfoMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.MigrInfoHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadMigrInfo {

    private final Support support;
    private final MigrInfoHeadMap migrInfoHeadMap;
    private final MigrInfoMapper migrInfoMapper;
    private final MigrInfoRepo migrInfoRepo;
    private final Configure configure;

    @Autowired
    public LoadMigrInfo(Support support, MigrInfoHeadMap migrInfoHeadMap, MigrInfoMapper migrInfoMapper,
                        MigrInfoRepo migrInfoRepo, Configure configure) {
        this.support = support;
        this.migrInfoHeadMap = migrInfoHeadMap;
        this.migrInfoMapper = migrInfoMapper;
        this.migrInfoRepo = migrInfoRepo;
        this.configure = configure;
    }

    /**
     * Загрузка файла
     *
     * @param file - файл
     * @return - список ошибок
     */
    public List<LoadError> loadFile(File file, long thread) throws Exception {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadMigrInfo, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}:T{}:  Подготовка процесса: Load LoadMigrInfo к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<MigrInfoHeadPosition> migrInfoHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}:  Запуск процесса: LoadMigrInfo, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                migrInfoHeadPosition.set(migrInfoHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckMigrInfo checkMigrInfo = migrInfoMapper.map(line.trim(), migrInfoHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}:T{}:  MigrInfo={}", LG.USBLOGINFO, thread, checkMigrInfo.getMigrInfo());
                                if (checkMigrInfo.isExists()) {
                                    migrInfoRepo.saveAndFlush(checkMigrInfo.getMigrInfo()); //сохраняем
                                }
                                if (checkMigrInfo.getLoadError().isStatus()) {
                                    loadErrorList.add(checkMigrInfo.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            configure.setSyncErrorOnProcessed(true);
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadMigrInfo, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            configure.setSyncErrorOnProcessed(true);
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
            throw new IOException(e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadMigrInfo. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

