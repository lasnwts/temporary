package ru.usb.xbank_intgr_credit.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {
    @JsonProperty("scan_id")
    private String scanId;
    @JsonProperty("result")
    private Result result;
    @JsonProperty("artifacts")
    private ArrayList<Artifact> artifacts;
}
