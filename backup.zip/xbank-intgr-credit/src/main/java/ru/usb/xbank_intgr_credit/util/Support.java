package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;


import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class Support {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    DateTimeFormatter sdfTimeStamp = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss,SSSSSS");


    /**
     * Проверка даты формата dd.MM.yyyy HH:mm:ss
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateTimeStamp(String date) {
        try {
            LocalDateTime ldt = LocalDateTime.parse(date, sdfTimeStamp);
            if (ldt == null) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Проверка даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDate(String date) {
        return GenericValidator.isDate(date, "dd.MM.yyyy", true);
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDate(String date) {
        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDate:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Форматирование даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDate(Date date) {
        return sdf.format(date);
    }


    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    SimpleDateFormat numInsert = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    /**
     * Получение номера вставки
     * @return - номер вставки
     */
    public long getNumInsert(){
        return Long.parseLong(numInsert.format(new Date()));
    }


}

