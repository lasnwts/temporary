package ru.usb.xbank_intgr_credit.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties
public class Configure {

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * COMMA DELIMITER
     */
    @Value("${csv.delimiter:;}")
    private String csvDelimiter;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${net.file.share}")
    private String netFileShare;

}
