package ru.usb.xbank_intgr_credit.model;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class DogovHeadPosition {
    private int s;//'ВКИ (внутренний код для импорта) договора
    private int client;
    private int symbol;
    private int ndogUs;
    private int depart;
    private int dateBeg;
    private int dateEnd;
    private int sum;
    private int sumVkp;
    private int sumVkpPrc;
    private int sumVkpDeb;
    private int sumVkpPrcDeb;
    private int sumVkpPen;
    private int dateBki;
    private int dateOffer;
    private int pskPrcBeg;
    private int pskBeg;
    private int pskPrc;
    private int psk;
    private int uid;
    private int processed;
    private int processedText;
}
