package ru.usb.xbank_intgr_credit.service;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

@Log4j2
@Component
public class TestSecuredConnection {

    @Value("${http.client.ssl.trust-store}")
    private String trustStore;
    @Value("${http.client.ssl.trust-store-password}")
    private String trustStorePassword;


    public List<String> testConnectionTo(String aURL) throws Exception {
        List<String> certificationList = new ArrayList<>();
        URL destinationURL = new URL(aURL);
        HttpsURLConnection conn = (HttpsURLConnection) destinationURL
                .openConnection();
        conn.connect();
        Certificate[] certs = conn.getServerCertificates();
        for (Certificate cert : certs) {
            log.info("{}: Certificate is: {}", LG.USBLOGINFO, cert);
            certificationList.add(cert.toString());
            if (cert instanceof X509Certificate) {
                try {
                    ((X509Certificate) cert).checkValidity();
                    log.info("{}: Certificate is active for current date", LG.USBLOGINFO);
                } catch (CertificateExpiredException cee) {
                    log.info("{}: Certificate is expired", LG.USBLOGINFO);
                }
            }
        }
        return certificationList;
    }


    /**
     * Получить список сертификатов
     * @return - список алиасов
     */
    public List<String> getSslCert() {
        InputStream is = null;
        List<String> certList = new ArrayList<>();
        try {

            File file = new File(trustStore);
            is = new FileInputStream(file);
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            String password = trustStorePassword;
            keystore.load(is, password.toCharArray());


            Enumeration<String> enumeration = keystore.aliases();
            while (enumeration.hasMoreElements()) {
                String alias = enumeration.nextElement();
                log.info("{}:alias name: {}", LG.USBLOGINFO, alias);
                certList.add(alias);
                Certificate certificate = keystore.getCertificate(alias);
                log.info("{}:certificate.toString(): {}", LG.USBLOGINFO, certificate.toString());
            }

        } catch (CertificateException e) {
            log.info("{}:Error CertificateException ", LG.USBLOGINFO, e);
        } catch (NoSuchAlgorithmException e) {
            log.info("{}:Error NoSuchAlgorithmException ", LG.USBLOGINFO, e);
        } catch (FileNotFoundException e) {
            log.info("{}:Error FileNotFoundException ", LG.USBLOGINFO, e);
        } catch (KeyStoreException e) {
            log.info("{}:Error KeyStoreException ", LG.USBLOGINFO, e);
        } catch (IOException e) {
            log.info("{}:Error IOException ", LG.USBLOGINFO, e);
        } finally {
            if (null != is)
                try {
                    is.close();
                } catch (IOException e) {
                    log.error("{}:Error.finally! IOException ", LG.USBLOGINFO, e);
                }
        }
        return certList;
    }
}
