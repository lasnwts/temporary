package ru.usb.xbank_intgr_credit.model.sandboxreq;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class Sandbox {
    private boolean enabled;
    @JsonProperty("image_id")
    private String imageId;
    @JsonProperty("default_timeout")
    private String defaultTimeout;
    @JsonProperty("analysis_duration")
    private int analysisDuration;
    @JsonProperty("save_video")
    private boolean saveVideo;
}
