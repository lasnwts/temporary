package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * Список кредитных договоров
 * dogov.csv
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_DOGOV")
public class Dogov {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора

    @Column(name = "CLIENT")//2
    private String client;

    @Column(name = "SYMBOL")//3
    private String symbol;

    @Column(name = "NDOG_US")//4
    private String ndogUs;

    @Column(name = "DEPART")//5
    private String depart; //Обработанное поле

    @Column(name = "DEPART_TBANK")//5
    private String departTbank; //Поле из файла TBANK

    @Column(name = "DATE_BEG")//6
    private Date dateBeg;

    @Column(name = "DATE_END")//7
    private Date dateEnd;

    @Column(name = "SUM")//8
    private BigDecimal sum;

    @Column(name = "SUM_VKP")//9
    private BigDecimal sumVkp;

    @Column(name = "SUM_VKP_PRC")//10
    private BigDecimal sumVkpPrc;

    @Column(name = "SUM_VKP_DEB")//11
    private BigDecimal sumVkpDeb;

    @Column(name = "SUM_VKP_PRC_DEB")//12
    private BigDecimal sumVkpPrcDeb;

    @Column(name = "SUM_VKP_PEN")//13
    private BigDecimal sumVkpPen;

    @Column(name = "DATE_BKI")//14
    private Date dateBki;

    @Column(name = "DATE_OFFER")//15
    private Date dateOffer;

    @Column(name = "PSK_PRC_BEG")//16
    private BigDecimal pskPrcBeg;

    @Column(name = "PSK_BEG")//17
    private BigDecimal pskBeg;

    @Column(name = "PSK_PRC")//18
    private BigDecimal pskPrc;

    @Column(name = "PSK")//19
    private BigDecimal psk;

    @Column(name = "UUID")//20
    private String uid;

    //20.11.2024
    //SUMM_PDN
    //DECIMAL
    //Доход, используемый для расчета ПДН (на момент покупки)
    //150000.00
    @Column(name = "SUMM_PDN")
    private BigDecimal summPdn;

    //PDN
    //DECIMAL
    //Актуальное на момент покупки значение ПДН
    //30.55
    @Column(name = "PDN")
    private BigDecimal pdn;

    @Column(name = "PROCESSED")//21
    private String processed;

    @Column(name = "PROCESSED_TEXT")//22
    private String processedText;

    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки
}
