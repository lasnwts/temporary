package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.MigrInfoHeadPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class MigrInfoHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public MigrInfoHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;DATE_BEG_ORIG;DATE_END_ORIG;DATE_END  ;TOTAL_DAYS_OVERDUE;SUM_OVERDUE;NUM_PMTS_MADE;NUM_PMTS_REM
//ORIG_TERM;CURR_TERM;PRC_RATE_ORIG;PAY_DAY_ORIG;PRC_RATE_CURR
//PAY_DAY_CURR;PAY_SUM_CURR
// DATE_FIRST_PAY;DATE_LASTPAY_COMMIT;SUM_LASTPAY_COMMIT;DATE_NEXT_PAYMENT;SUM_NEXT_PAYMENT;REFINANCE
//DATE_FIRST_PAY;DATE_LASTPAY_COMMIT
//SUM_LASTPAY_COMMIT;DATE_NEXT_PAYMENT;SUM_NEXT_PAYMENT;REFINANCE

    /**
     * Преобразование строки в объект MigrInfoHeadPosition
     * @param line - строка
     * @return - объект MigrInfoHeadPosition
     */
    public MigrInfoHeadPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        MigrInfoHeadPosition migrInfoHeadPosition = new MigrInfoHeadPosition();
        migrInfoHeadPosition.setS(support.getPosition("S", values));
        migrInfoHeadPosition.setDateBegOrig(support.getPosition("DATE_BEG_ORIG", values));
        migrInfoHeadPosition.setDateEndOrig(support.getPosition("DATE_END_ORIG", values));
        migrInfoHeadPosition.setDateEnd(support.getPosition("DATE_END", values));
        migrInfoHeadPosition.setTotalDaysOverdue(support.getPosition("TOTAL_DAYS_OVERDUE", values));
        migrInfoHeadPosition.setSumOverdue(support.getPosition("SUM_OVERDUE", values));
        migrInfoHeadPosition.setNumPmtsMade(support.getPosition("NUM_PMTS_MADE", values));
        migrInfoHeadPosition.setNumPmtsRem(support.getPosition("NUM_PMTS_REM", values));
        migrInfoHeadPosition.setOrigTerm(support.getPosition("ORIG_TERM", values));
        migrInfoHeadPosition.setCurrTerm(support.getPosition("CURR_TERM", values));
        migrInfoHeadPosition.setPrcRateOrig(support.getPosition("PRC_RATE_ORIG", values));
        migrInfoHeadPosition.setPayDayOrig(support.getPosition("PAY_DAY_ORIG", values));
        migrInfoHeadPosition.setPrcRateCurr(support.getPosition("PRC_RATE_CURR", values));
        migrInfoHeadPosition.setPayDayCurr(support.getPosition("PAY_DAY_CURR", values));
        migrInfoHeadPosition.setPaySumCurr(support.getPosition("PAY_SUM_CURR", values));
        migrInfoHeadPosition.setDateFirstPay(support.getPosition("DATE_FIRST_PAY", values));
        migrInfoHeadPosition.setDateLastpayCommit(support.getPosition("DATE_LASTPAY_COMMIT", values));
        migrInfoHeadPosition.setSumLastpayCommit(support.getPosition("SUM_LASTPAY_COMMIT", values));
        migrInfoHeadPosition.setDateNextPayment(support.getPosition("DATE_NEXT_PAYMENT", values));
        migrInfoHeadPosition.setSumNextPayment(support.getPosition("SUM_NEXT_PAYMENT", values));
        migrInfoHeadPosition.setRefinance(support.getPosition("REFINANCE", values));
        return migrInfoHeadPosition;
    }


}
