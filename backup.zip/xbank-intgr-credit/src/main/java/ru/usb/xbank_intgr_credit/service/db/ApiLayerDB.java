package ru.usb.xbank_intgr_credit.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_credit.model.db.FtpsResponse;
import ru.usb.xbank_intgr_credit.model.db.TBankHistoryArchives;
import ru.usb.xbank_intgr_credit.model.db.TBankRunHistory;
import ru.usb.xbank_intgr_credit.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_credit.repository.TBankRunHistoryRepo;

import java.util.Date;
import java.util.Objects;

@Log4j2
@Service
public class ApiLayerDB {

    private static final String MICRO = "[xbank-intgr-credit]";

    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;
    private final TBankRunHistoryRepo tBankRunHistoryRepo;

    @Autowired
    public ApiLayerDB(TBankHistoryArchivesRepo tBankHistoryArchivesRepo, TBankRunHistoryRepo tBankRunHistoryRepo) {
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
        this.tBankRunHistoryRepo = tBankRunHistoryRepo;
    }

    /**
     * Сохранение истории архива
     *
     * @param ftpsResponse - объект ответа
     */
    public void saveHistoryArchiveBadZip(FtpsResponse ftpsResponse, TBankHistoryArchives tBankHistoryArchives) {
        if (tBankHistoryArchives == null) {
            tBankHistoryArchives = new TBankHistoryArchives();
        }
        tBankHistoryArchives.setError("415");
        if (ftpsResponse.getFile() != null) {
            tBankHistoryArchives.setErrortext("Ошибка разархивации файла: " + ftpsResponse.getFile().getName() + "; " + ftpsResponse.getMessage());
        } else {
            tBankHistoryArchives.setErrortext("Ошибка разархивации файла");
        }
        tBankHistoryArchives.setTbankFiles("0");
        tBankHistoryArchives.setDateEnd(new Date());
        tBankHistoryArchivesRepo.saveAndFlush(tBankHistoryArchives);
    }

    /**
     * Сохранение истории архива
     *
     * @param historyArchives - история архива
     */
    public void saveHistoryArchive(TBankHistoryArchives historyArchives) {
        tBankHistoryArchivesRepo.saveAndFlush(historyArchives);
    }


    /**
     * Получение истории архива
     *
     * @param archiveName - имя архива
     * @return - история архива
     */
    public TBankHistoryArchives getHistoryArchive(String archiveName) {
        TBankHistoryArchives tBankHistoryArchives = tBankHistoryArchivesRepo.getByName(archiveName);
        return Objects.requireNonNullElseGet(tBankHistoryArchives, TBankHistoryArchives::new);
    }

    /**
     * Сохранение истории запуска
     *
     */
    public void saveStartRun() {
        TBankRunHistory tBankRunHistory = new TBankRunHistory();
        tBankRunHistory.setStartTime(new Date());
        tBankRunHistory.setMicroservice(MICRO);
        tBankRunHistory.setStatus("START");
        tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
    }

    /**
     * Сохранение истории остановки
     *
     */
    public void saveEndRun(TBankRunHistory tBankRunHistory) {
        tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
    }

    /**
     * Сохранение истории остановки
     *
     */
    public void saveProcessEndRun() {
        TBankRunHistory tBankRunHistory = tBankRunHistoryRepo.getByMName(MICRO);
        if (tBankRunHistory != null){
            tBankRunHistory.setEndTime(new Date());
            tBankRunHistory.setStatus("END");
            tBankRunHistoryRepo.saveAndFlush(tBankRunHistory);
        }
    }


    /**
     * Получение истории запуска
     *
     * @return - история запуска
     */
    public TBankRunHistory getByMicroservice() {
        TBankRunHistory tBankRunHistory = tBankRunHistoryRepo.getByMName(MICRO);
        return Objects.requireNonNullElseGet(tBankRunHistory, TBankRunHistory::new);
    }

}
