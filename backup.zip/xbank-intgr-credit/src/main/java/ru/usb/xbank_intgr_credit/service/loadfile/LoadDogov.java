package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckFact;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;
import ru.usb.xbank_intgr_credit.model.FactHeadPosition;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.repository.DogovRepo;
import ru.usb.xbank_intgr_credit.util.DogovMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.DogovHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadDogov {
    private final Support support;
    private final DogovHeadMap dogovHeadMap;
    private final DogovMapper dogovMapper;
    private final DogovRepo dogovRepo;

    @Autowired
    public LoadDogov(Support support, DogovHeadMap dogovHeadMap, DogovMapper dogovMapper, DogovRepo dogovRepo) {
        this.support = support;
        this.dogovHeadMap = dogovHeadMap;
        this.dogovMapper = dogovMapper;
        this.dogovRepo = dogovRepo;
    }


    /**
     * Загрузка файла
     *
     * @param file - файл
     * @return - список проблем
     */
    public List<LoadError> loadFile(File file) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:Запуск процесса: LoadFact, переданный Файл {} не существует", LG.USBLOGERROR, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}: Подготовка процесса: Load LoadDogov к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, file.getAbsolutePath(), numInsert);
        AtomicReference<DogovHeadPosition> dogovHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}: Запуск процесса: LoadDogov, startTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.parallel().forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                dogovHeadPosition.set(dogovHeadMap.map(line)); //разбираем, что где находится в строке
                            } else {
                                CheckDogov checkDogov = dogovMapper.map(line, dogovHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}: Dogov={}", LG.USBLOGINFO, checkDogov.getDogov());
                                dogovRepo.saveAndFlush(checkDogov.getDogov()); //сохраняем
                                if (checkDogov.getLoadError().isStatus()) {
                                    loadErrorList.add(checkDogov.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, e.getMessage(), line);
                            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
                        }
                    }
            );
            log.info("{}:Завершение процесса: LoadDogov, endTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
            log.info("{}:Загружено записей:{}", LG.USBLOGINFO, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:Завершение процесса: LoadDogov. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

