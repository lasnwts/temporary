package ru.usb.xbank_intgr_credit.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class MigrInfoHeadPosition {
    private int s;
    private int dateBegOrig;
    private int dateEndOrig;
    private int dateEnd;
    private int totalDaysOverdue;
    private int sumOverdue;
    private int numPmtsMade;
    private int numPmtsRem;
    private int origTerm;
    private int currTerm;
    private int prcRateOrig;
    private int payDayOrig;
    private int prcRateCurr;
    private int payDayCurr;
    private int paySumCurr;
    private int dateFirstPay;
    private int dateLastpayCommit;
    private int sumLastpayCommit;
    private int dateNextPayment;
    private int sumNextPayment;
    private int refinance;
}
