package ru.usb.xbank_intgr_credit.service.ftp;

import it.sauronsoftware.ftp4j.FTPDataTransferListener;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class MyTransferListener implements FTPDataTransferListener {
    @Override
    public void started() {
        log.info("MyTransferListener started");
    }

    @Override
    public void transferred(int length) {
        log.info("MyTransferListener transferred");
    }

    @Override
    public void completed() {
        log.info("MyTransferListener completed");
    }

    @Override
    public void aborted() {
        log.info("MyTransferListener aborted");
    }

    @Override
    public void failed() {
        log.info("MyTransferListener failed");
    }
}
