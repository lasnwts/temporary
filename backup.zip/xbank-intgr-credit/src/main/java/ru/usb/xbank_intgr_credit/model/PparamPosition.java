package ru.usb.xbank_intgr_credit.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class PparamPosition {
    private int s;//'ВКИ (внутренний код для импорта) договора
    private int vidoper;//Код вида операции
    private int daypay;//День платежа
    private int daycalc;//День начисления
    private int sumpay;//Cумма платежа
    private int dateCalc;//Начало расчета
    private int datePay;//Начало гашений
    private int dateEnd;//Окончание планирования
    private int operCount;//Количество операций
    private int onlyPrc;//Всегда 0
    private int gashPayPeriod;//Если дата платежа не менялась и не будет меняться, то заполнять 1
}
