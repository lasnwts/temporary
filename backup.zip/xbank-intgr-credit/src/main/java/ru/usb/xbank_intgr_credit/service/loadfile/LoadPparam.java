package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckPparam;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PparamPosition;
import ru.usb.xbank_intgr_credit.repository.PparamRepo;
import ru.usb.xbank_intgr_credit.util.PparamMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.PparamHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadPparam {

    private final Support support;
    private final PparamHeadMap pparamHeadMap;
    private final PparamMapper pparamMapper;
    private final PparamRepo pparamRepo;

    @Autowired
    public LoadPparam(Support support, PparamHeadMap pparamHeadMap, PparamMapper pparamMapper, PparamRepo pparamRepo) {
        this.support = support;
        this.pparamHeadMap = pparamHeadMap;
        this.pparamMapper = pparamMapper;
        this.pparamRepo = pparamRepo;
    }

    public List<LoadError> loadFile(File file) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:Запуск процесса: LoadPparam, переданный Файл {} не существует", LG.USBLOGERROR, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}: Подготовка процесса: Load LoadPparam к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, file.getAbsolutePath(), numInsert);
        AtomicReference<PparamPosition> pparamPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}: Запуск процесса: LoadPparam, startTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.parallel().forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                pparamPosition.set(pparamHeadMap.map(line)); //разбираем, что где находится в строке
                            } else {
                                CheckPparam checkPparam = pparamMapper.map(line, pparamPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}: Pparam={}", LG.USBLOGINFO, checkPparam.getPparam());
                                pparamRepo.saveAndFlush(checkPparam.getPparam()); //сохраняем
                                if (checkPparam.getLoadError().isStatus()) {
                                    loadErrorList.add(checkPparam.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, e.getMessage(), line);
                            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
                        }
                    }
            );
            log.info("{}:Завершение процесса: LoadPparam, endTime={}", LG.USBLOGINFO, support.formatDateTime(new Date()));
            log.info("{}:Загружено записей:{}", LG.USBLOGINFO, count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:Stack trace:", LG.USBLOGERROR, e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:Завершение процесса: LoadPparam. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

