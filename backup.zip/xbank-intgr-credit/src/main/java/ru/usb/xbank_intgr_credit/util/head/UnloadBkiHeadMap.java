package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.UnloadBkiPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class UnloadBkiHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public UnloadBkiHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    /**
     * Преобразование строки в объект UnloadBkiPosition
     *
     * @param line - строка
     * @return - объект UnloadBkiPosition
     */
    public UnloadBkiPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        UnloadBkiPosition unloadBkiPosition = new UnloadBkiPosition();
        unloadBkiPosition.setS(support.getPosition("S", values)); //1
        unloadBkiPosition.setTbRelationship(support.getPosition("TB_RELATIONSHIP", values));//2
        unloadBkiPosition.setTbType(support.getPosition("TB_TYPE", values));//3
        unloadBkiPosition.setTbLoanTypeCode(support.getPosition("TB_LOANTYPECODE", values));//4
        unloadBkiPosition.setTbStartAmouOutst(support.getPosition("TB_STARTAMOUOUTST", values));//5
        unloadBkiPosition.setTbCuroverdueDtTa(support.getPosition("TB_CUROVERDUEDT_TA", values));//6
        unloadBkiPosition.setTbMspymntNxtrdt(support.getPosition("TB_MSPYMNTNXTRDT", values));//7
        unloadBkiPosition.setTbMspymntNtrstdt(support.getPosition("TB_MSPYMNTNTRSTDT", values));//8
        unloadBkiPosition.setTbPastDueDays(support.getPosition("TB_PASTDUEDAYS", values));//9
        unloadBkiPosition.setTbPaidPastDueDays(support.getPosition("TB_PAIDPASTDUEDAYS", values));//10
        unloadBkiPosition.setTbLastAmount30Pd(support.getPosition("TB_LASTAMOUNT_30PD", values));//11
        unloadBkiPosition.setTbTtlAmount24m30Pd(support.getPosition("TB_TTLAMOUNT24M30PD", values));//12
        unloadBkiPosition.setTbDebtRange(support.getPosition("TB_DEBTRANGE", values));//13
        unloadBkiPosition.setTbDebtCalcDate(support.getPosition("TB_DEBTCALCDATE", values));//14
        unloadBkiPosition.setTbIncomeWayType(support.getPosition("TB_INCOMEWAYTYPE", values));//15
        unloadBkiPosition.setTbIncomeInfoSource(support.getPosition("TB_INCOMEINFOSOURCE", values));//16
        unloadBkiPosition.setTbCoborrowersDebt(support.getPosition("TB_COBORROWERSDEBT", values));//17
        unloadBkiPosition.setTbStateSupport(support.getPosition("TB_STATESUPPORT", values));//18
        unloadBkiPosition.setTbStateSupportInfo(support.getPosition("TB_STATESUPPORTINFO", values));//19
        unloadBkiPosition.setTbLoanPurposeCode(support.getPosition("TB_LOANPURPOSECODE", values));//20
        unloadBkiPosition.setTbDateContrTerm(support.getPosition("TB_DATECONTRTERM", values));//21
        return unloadBkiPosition;
    }
}
