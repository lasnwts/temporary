package ru.usb.xbank_intgr_credit.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class LoadError {
    private int lineNumber;  //Номер строки
    private String fileName; //Имя файла
    private String line;    //Строка с ошибкой
    private String errorMessage; //описание ошибки
    private Date date; //дата и время возникновения ошибки
    private boolean status; //false - нет ошибок, true - есть ошибка

    @Override
    public String toString() {
        return "LoadError{" +
                "Номер строки в файле =" + lineNumber +
                ", Имя файла='" + fileName +
                ", Ошибка='" + errorMessage +
                ", Строка='" + line +
                '}';
    }
}
