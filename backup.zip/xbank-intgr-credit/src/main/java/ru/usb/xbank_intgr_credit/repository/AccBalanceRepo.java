package ru.usb.xbank_intgr_credit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_credit.dto.AccBalance;

public interface AccBalanceRepo extends JpaRepository<AccBalance, Long> {
}
