package ru.usb.xbank_intgr_credit.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Planall;

@Component
public class PlanallToIson {


    private static final Logger log = LoggerFactory.getLogger(PlanallToIson.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Получение документа в виде Json строки
     * @param document - Pack
     * @return - Json строка
     */
    public String getJson(Planall document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [Planall] == NULL!", LG.USBLOGERROR);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа Planall :{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Planall:", LG.USBLOGERROR, e);
            return null;
        }
    }

}
