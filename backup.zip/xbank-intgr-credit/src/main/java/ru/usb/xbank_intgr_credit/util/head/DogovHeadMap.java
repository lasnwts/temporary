package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class DogovHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public DogovHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;CLIENT;SYMBOL;NDOG_US;DEPART;DATE_BEG;DATE_END;SUM;SUM_VKP;SUM_VKP_PRC;SUM_VKP_DEB;SUM_VKP_PRC_DEB;SUM_VKP_PEN;DATE_BKI;DATE_OFFER;PSK_PRC_BEG;PSK_BEG;PSK_PRC;PSK;UID;PROCESSED;PROCESSED_TEXT

    /**
     * Преобразование строки в объект DogovHeadPosition
     * @param line - строка
     * @return - объект DogovHeadPosition
     */
    public DogovHeadPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        DogovHeadPosition dogovHeadPosition = new DogovHeadPosition();
        dogovHeadPosition.setS(support.getPosition("S", values));
        dogovHeadPosition.setClient(support.getPosition("CLIENT", values));
        dogovHeadPosition.setSymbol(support.getPosition("SYMBOL", values));
        dogovHeadPosition.setNdogUs(support.getPosition("NDOG_US", values));
        dogovHeadPosition.setDepart(support.getPosition("DEPART", values));
        dogovHeadPosition.setDateBeg(support.getPosition("DATE_BEG", values));
        dogovHeadPosition.setDateEnd(support.getPosition("DATE_END", values));
        dogovHeadPosition.setSum(support.getPosition("SUM", values));
        dogovHeadPosition.setSumVkp(support.getPosition("SUM_VKP", values));
        dogovHeadPosition.setSumVkpPrc(support.getPosition("SUM_VKP_PRC", values));
        dogovHeadPosition.setSumVkpDeb(support.getPosition("SUM_VKP_DEB", values));
        dogovHeadPosition.setSumVkpPrcDeb(support.getPosition("SUM_VKP_PRC_DEB", values));
        dogovHeadPosition.setSumVkpPen(support.getPosition("SUM_VKP_PEN", values));
        dogovHeadPosition.setDateBki(support.getPosition("DATE_BKI", values));
        dogovHeadPosition.setDateOffer(support.getPosition("DATE_OFFER", values));
        dogovHeadPosition.setPskPrcBeg(support.getPosition("PSK_PRC_BEG", values));
        dogovHeadPosition.setPskBeg(support.getPosition("PSK_BEG", values));
        dogovHeadPosition.setPskPrc(support.getPosition("PSK_PRC", values));
        dogovHeadPosition.setPsk(support.getPosition("PSK", values));
        dogovHeadPosition.setUid(support.getPosition("UID", values));
        dogovHeadPosition.setProcessed(support.getPosition("PROCESSED", values));
        dogovHeadPosition.setProcessedText(support.getPosition("PROCESSED_TEXT", values));
        return dogovHeadPosition;
    }

}

