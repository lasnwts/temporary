package ru.usb.xbank_intgr_credit.model;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class AccBalancePosition {
    private int s;//ВКИ (внутренний код для импорта) договора
    private int acc;//Балансовый счет для учета задолженности
    private int sum;//;Сумма планового платежа
}
