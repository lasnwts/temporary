package ru.usb.xbank_intgr_credit.service.zip;

import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.db.FtpsResponse;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

/**
 * Проверка ZIP арххива
 */
@Log4j2
@Component
public class ZipCheck {

    private final ZipApi zipApi;

    @Autowired
    public ZipCheck(ZipApi zipApi) {
        this.zipApi = zipApi;
    }


    /**
     * Проверка ZIP арххива
     *
     * @return - true если архив корректный
     */
    public boolean isValidZipFile(FtpsResponse ftpsResponse, String tempDirectory, long thread) {

        try {
            Optional<List<Path>> optionalList = zipApi.unzipFile(ftpsResponse.getFile().getAbsolutePath(), tempDirectory, ftpsResponse.getFile().getName());
            if (optionalList.isPresent()) {
                List<Path> pathList = optionalList.get();
                if (pathList.isEmpty()) {
                    log.error("{}:T{}: Проверка ZIP архива:{}  - архив пустой!", LG.USBLOGERROR, thread, ftpsResponse.getFile().getName());
                    return false;
                } else {
                    deleteZip(pathList, thread, tempDirectory); //Чистим
                }
                return true;
            } else {
                log.error("{}:T{}: Проверка ZIP архива:{}  завершилась с ошибкой, архив пустой!", LG.USBLOGERROR, thread, ftpsResponse.getFile().getName());
                return false;
            }
        } catch (Exception e) {
            log.error("{}:T{}: Проверка ZIP архива:{}  завершилась с ошибкой распаковки :{}", LG.USBLOGERROR, thread, ftpsResponse.getFile().getName(), e.getMessage());
            return false;
        }
        finally {
            try {
                //Чистим
                if (Files.exists(Path.of(tempDirectory))) {
                    FileUtils.cleanDirectory(new File(tempDirectory));
                }
            } catch (IOException e) {
                log.error("{}:T{}: Очистка после проверки ZIP архива:{}  завершилась с ошибкой:{}", LG.USBLOGERROR, thread, ftpsResponse.getFile().getName(), e.getMessage());
            }
        }
    }

    /**
     * Удаление файлов
     *
     * @param pathList - список файлов
     */
    @SneakyThrows
    private void deleteZip(List<Path> pathList, long thread, String tempDirectory) {
        pathList.forEach(
                path -> {
                    try {
                        if (Files.isRegularFile(path)){
                            Files.deleteIfExists(path);
                        }
                    } catch (Exception e) {
                        log.error("{}:T{}: Ошибка при удалении файла:{}, error:{}", LG.USBLOGERROR, thread, path, e.getMessage());
                    }
                }
        );

    }

}
