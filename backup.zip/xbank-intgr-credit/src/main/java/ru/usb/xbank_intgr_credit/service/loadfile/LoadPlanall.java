package ru.usb.xbank_intgr_credit.service.loadfile;


import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckPlanall;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PlanallHeadPosition;
import ru.usb.xbank_intgr_credit.repository.PlanallRepo;
import ru.usb.xbank_intgr_credit.service.kafka.KafkaProducerService;
import ru.usb.xbank_intgr_credit.util.PlanallMapper;
import ru.usb.xbank_intgr_credit.util.PlanallToIson;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.PlanalHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadPlanall {

    private final Support support;
    private final PlanalHeadMap planalHeadMap;
    private final PlanallMapper planalMapper;
    private final PlanallRepo planalRepo;
    private final Configure configure;
    private final KafkaProducerService kafkaProducerService;
    private final PlanallToIson planallToIson;

    @Autowired
    public LoadPlanall(Support support, PlanalHeadMap planalHeadMap, PlanallMapper planalMapper,
                       PlanallRepo planalRepo, Configure configure, KafkaProducerService kafkaProducerService, PlanallToIson planallToIson) {
        this.support = support;
        this.planalHeadMap = planalHeadMap;
        this.planalMapper = planalMapper;
        this.planalRepo = planalRepo;
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.planallToIson = planallToIson;
    }

public List<LoadError> loadFile(File file, long thread) throws Exception {

    List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

    //Если файла не существует, выходим
    if (!file.exists()) {
        log.error("{}:T{}: Запуск процесса: LoadPlanall, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
        loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
        return loadErrorList;
    }

    long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
    log.info("{}:T{}: Подготовка процесса: Load LoadPlanall к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
    AtomicReference<PlanallHeadPosition> planallHeadPosition = new AtomicReference<>();
    long startTime = System.currentTimeMillis();
    log.info("{}:T{}: Запуск процесса: LoadPlanall, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
    try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
        final AtomicInteger count = new AtomicInteger();
        lines.forEach(line -> {
                    count.incrementAndGet(); //+1 на каждую строку
                    try {
                        if (count.get() == 1) { //строка 1 - заголовок
                            planallHeadPosition.set(planalHeadMap.map(line.trim())); //разбираем, что где находится в строке
                        } else {
                            CheckPlanall checkPlanall = planalMapper.map(line.trim(), planallHeadPosition.get(), file.getName(), numInsert, count.get());
                            log.debug("{}:T{}: Planall={}", LG.USBLOGINFO, thread, checkPlanall.getPlanall());
                            if (checkPlanall.isExists()){
                                //planalRepo.saveAndFlush(checkPlanall.getPlanall()); //сохраняем
                                kafkaProducerService.sendMessage("planall", planallToIson.getJson(checkPlanall.getPlanall()));

                            }
                            if (checkPlanall.getLoadError().isStatus()) {
                                loadErrorList.add(checkPlanall.getLoadError());
                            }
                        }
                    } catch (Exception e) {
                        configure.setSyncErrorOnProcessed(true);
                        loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                        log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                        log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                        try {
                            throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                        } catch (InvalidCharsetException ex) {
                            log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                        }
                    }
                }
        );
        log.info("{}:T{}: Завершение процесса: LoadPlanall, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

    } catch (IOException e) {
        configure.setSyncErrorOnProcessed(true);
        loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
        log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
        log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread,e);
        throw new IOException(e);
    }
    long endTime = System.currentTimeMillis();
    log.info("{}:T{}: Завершение процесса: LoadPlanall. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread,((endTime - startTime) / 1000) + 1);
    return loadErrorList;
}
}

