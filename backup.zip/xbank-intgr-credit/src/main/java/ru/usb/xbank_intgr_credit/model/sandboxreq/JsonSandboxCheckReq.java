package ru.usb.xbank_intgr_credit.model.sandboxreq;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class JsonSandboxCheckReq {
    @JsonProperty("file_uri")
    private String fileUri;
    @JsonProperty("file_name")
    private String fileName;
    @JsonProperty("async_result")
    private boolean asyncResult;
    @JsonProperty("short_result")
    private boolean shortResult;
    @JsonProperty("options")
    private Options options;
}
