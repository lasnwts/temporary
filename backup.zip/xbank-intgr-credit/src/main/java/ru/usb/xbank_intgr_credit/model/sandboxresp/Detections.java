package ru.usb.xbank_intgr_credit.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 */

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class Detections {
    @JsonProperty("detect")
    private String detect;
    @JsonProperty("threat")
    private String threat;
}
