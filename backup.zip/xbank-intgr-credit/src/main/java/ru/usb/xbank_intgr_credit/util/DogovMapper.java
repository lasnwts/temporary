package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;
import ru.usb.xbank_intgr_credit.model.LoadError;

import java.util.Date;

@Log4j2
@Component
public class DogovMapper {

    private final Support support;
    private final Configure configure;

    @Autowired
    public DogovMapper(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    /**
     * Маппинг строки файла в объект
     *
     * @param line              - строка файла
     * @param dogovHeadPosition - позиция заголовков
     * @param fileName          - имя файла
     * @param numInsert         - номер записи
     * @param lineNumber        - номер строки в файле
     * @return - объект
     */
    public CheckDogov map(String line, DogovHeadPosition dogovHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        Dogov dogov = new Dogov();
        //Константы
        dogov.setNumInsert(numInsert);
        dogov.setFileName(fileName);
        dogov.setInputDate(new Date());

        try {
            if (dogovHeadPosition.getS() > -1) {
                dogov.setS(values[dogovHeadPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:S: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getClient() > -1) {
                dogov.setClient(values[dogovHeadPosition.getClient()]);
            } else {
                setLoadError("Не найден обязательный параметр:CLIENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:CLIENT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CLIENT: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSymbol() > -1) {
                dogov.setSymbol(values[dogovHeadPosition.getSymbol()]);
            } else {
                setLoadError("Не найден обязательный параметр:SYMBOL", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SYMBOL" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SYMBOL: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getNdogUs() > -1) {
                dogov.setNdogUs(values[dogovHeadPosition.getNdogUs()]);
            } else {
                setLoadError("Не найден обязательный параметр:NDOG_US", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:NDOG_US" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:NDOG_US: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDepart() > -1) {
                dogov.setDepart(values[dogovHeadPosition.getDepart()]);
            } else {
                setLoadError("Не найден обязательный параметр:DEPART", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DEPART" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DEPART: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateBeg() > -1 && support.checkDateLine(values[dogovHeadPosition.getDateBeg() ])) {
                dogov.setDateBeg(support.convertDateToSqlDate(support.parseDateLine(values[dogovHeadPosition.getDateBeg()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_BEG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_BEG: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateEnd() > -1 && support.checkDateLine(values[dogovHeadPosition.getDateEnd()])) {
                dogov.setDateEnd(support.convertDateToSqlDate(support.parseDateLine(values[dogovHeadPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_END" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSum() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSum()])) {
                dogov.setSum(support.parseDecimal(values[dogovHeadPosition.getSum()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkp() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSumVkp()])) {
                dogov.setSumVkp(support.parseDecimal(values[dogovHeadPosition.getSumVkp()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM_VKP: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPrc() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSumVkpPrc()])) {
                dogov.setSumVkpPrc(support.parseDecimal(values[dogovHeadPosition.getSumVkpPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PRC" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM_VKP_PRC: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpDeb() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSumVkpDeb()])) {
                dogov.setSumVkpDeb(support.parseDecimal(values[dogovHeadPosition.getSumVkpDeb()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_DEB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_DEB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM_VKP_DEB: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPrcDeb() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSumVkpPrcDeb()])) {
                dogov.setSumVkpPrcDeb(support.parseDecimal(values[dogovHeadPosition.getSumVkpPrcDeb()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PRC_DEB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PRC_DEB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM_VKP_PRC_DEB: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getSumVkpPen() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getSumVkpPen()])) {
                dogov.setSumVkpPen(support.parseDecimal(values[dogovHeadPosition.getSumVkpPen()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_VKP_PEN", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUM_VKP_PEN" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM_VKP_PEN: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateBki() > -1 && support.checkDateLine(values[dogovHeadPosition.getDateBki()])) {
                dogov.setDateBki(support.convertDateToSqlDate(support.parseDateLine(values[dogovHeadPosition.getDateBki()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BKI", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_BKI" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_BKI: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getDateOffer() > -1 && support.checkDateLine(values[dogovHeadPosition.getDateOffer()])) {
                dogov.setDateOffer(support.convertDateToSqlDate(support.parseDateLine(values[dogovHeadPosition.getDateOffer()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_OFFER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_OFFER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_OFFER: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPskPrcBeg() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getPskPrcBeg()])) {
                dogov.setPskPrcBeg(support.parseDecimal(values[dogovHeadPosition.getPskPrcBeg()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_PRC_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_PRC_BEG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PSK_PRC_BEG: {}", LG.USBLOGERROR, e.getMessage());
        }

        //PSK_PRC_BEG;PSK_BEG;PSK_PRC;PSK;UID;PROCESSED;PROCESSED_TEXT

        try {
            if (dogovHeadPosition.getPskBeg() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getPskBeg()])) {
                dogov.setPskBeg(support.parseDecimal(values[dogovHeadPosition.getPskBeg()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_BEG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PSK_BEG: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPskPrc() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getPskPrc()])) {
                dogov.setPskPrc(support.parseDecimal(values[dogovHeadPosition.getPskPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK_PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK_PRC" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PSK_PRC: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getPsk() > -1 && support.checkDecimalBool(values[dogovHeadPosition.getPsk()])) {
                dogov.setPsk(support.parseDecimal(values[dogovHeadPosition.getPsk()]));
            } else {
                setLoadError("Не найден обязательный параметр:PSK", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PSK" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PSK: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getUid() > -1) {
                dogov.setUid(values[dogovHeadPosition.getUid()]);
            } else {
                setLoadError("Не найден обязательный параметр:UID", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:UID" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:UID: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getProcessed() > -1) {
                dogov.setProcessed(values[dogovHeadPosition.getProcessed()]);
            } else {
                setLoadError("Не найден обязательный параметр:PROCESSED", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PROCESSED" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PROCESSED: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (dogovHeadPosition.getProcessedText() > -1) {
                dogov.setProcessedText(values[dogovHeadPosition.getProcessedText()]);
            } else {
                setLoadError("Не найден обязательный параметр:PROCESSED_TEXT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PROCESSED_TEXT" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:PROCESSED_TEXT: {}", LG.USBLOGERROR, e.getMessage());
        }

        return new CheckDogov(dogov, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
