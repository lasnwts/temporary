package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustContHeadPosition;

@Component
public class CustContHeadMap {

    private static final String COMMA_DELIMITER = ";";

    /**
     * Маппинг строки
     *
     * @param line - строка
     * @return - объект
     */
    public CustContHeadPosition map(String line) {
        String[] values = line.split(COMMA_DELIMITER);
        CustContHeadPosition custContHeadPosition = new CustContHeadPosition();
        custContHeadPosition.setClient(getPosition("CLIENT", values));
        custContHeadPosition.setContactsPrivate(getPosition("CONTACTS_PRIVATE", values));
        custContHeadPosition.setContactsActiv(getPosition("CONTACTS_ACTIV", values));
        custContHeadPosition.setContactsNumb(getPosition("CONTACTS_NUMB", values));
        custContHeadPosition.setContactsType(getPosition("CONTACTS_TYPE", values));
        return custContHeadPosition;
    }


    /**
     * Получение позиции
     *
     * @param key    - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values) {

        for (int i = 0; i < values.length; i++) {
            if (values[i].equalsIgnoreCase(key)) {
                return i;
            }
        }
        return -1;

    }
}