package ru.usb.xbank_intgr_clients.service.sandbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.FacFile;
import ru.usb.xbank_intgr_clients.model.sandboxreq.JsonSandboxCheckReq;
import ru.usb.xbank_intgr_clients.model.sandboxreq.MarkSuspiciousFilesOptions;
import ru.usb.xbank_intgr_clients.model.sandboxreq.Options;
import ru.usb.xbank_intgr_clients.model.sandboxreq.Sandbox;
import ru.usb.xbank_intgr_clients.model.sandboxresp.SandBoxCheck;

import java.util.List;



@Log4j2
@Service
public class CheckSandBox {

    @Value("${sandbox.url-check}")
    String sandboxUrlCheck;
    @Value("${sandbox.token}")
    String sandboxToken;

    private final RestTemplate restTemplateConnect;

    @Autowired
    public CheckSandBox(RestTemplate restTemplateConnect) {
        this.restTemplateConnect = restTemplateConnect;
    }

    /**
     * Подготовка запроса на проверку файла
     * @param facFile - файл, который нужно проверить
     * @return - результат проверки
     */
    public FacFile checkSandBox(FacFile facFile, long thread) {
        // Запрос на проверку файла
        log.info("{}:T{} CheckSandBox, Запрос на проверку файла в песочнице => file:{}, uri:{}", LG.USBLOGINFO, thread,
                facFile.getFile().getAbsolutePath(), facFile.getFileUri());
        facFile.setCheckStatus(2); //в процессе проверки
        //Подготовка файла
        JsonSandboxCheckReq jsonSandboxCheckReq = getJsonSandboxCheckReq(facFile);

        try {
            String checkReqStr = new ObjectMapper().writeValueAsString(jsonSandboxCheckReq);
            log.info("{}:T{} Подготовлен запрос на проверку файла в песочнице:{}", LG.USBLOGINFO, thread, checkReqStr);

            HttpHeaders headersCheck = new HttpHeaders();
            headersCheck.setAccept(List.of(MediaType.APPLICATION_JSON));
            headersCheck.add("X-API-Key", sandboxToken);

            HttpEntity<Object> entityCheck = new HttpEntity<>(checkReqStr, headersCheck);
            log.info("{}:T{} Подготовлен запрос в песочницу, на результат сканирования, header:{} ", LG.USBLOGINFO, thread, headersCheck);
            log.info("{}:T{} Подготовлен запрос в песочницу, на результат сканирования, body:{} ", LG.USBLOGINFO, thread, checkReqStr);
            log.info("{}:T{} Подготовлен запрос в песочницу, на результат сканирования, Request:{} ", LG.USBLOGINFO, thread, entityCheck);
            ResponseEntity<String> responseCheck = restTemplateConnect.postForEntity(sandboxUrlCheck, entityCheck, String.class);
            log.info("{}:T{} Выполнен запрос. Получен ответ: Response code={}, body из песочницы:{} ", LG.USBLOGINFO, thread, responseCheck.getStatusCode(), responseCheck.getBody());
            facFile.setCheckStatus(responseCheck.getStatusCode().value());
            facFile.setStatus(responseCheck.getStatusCode());
            if (!responseCheck.getStatusCode().is2xxSuccessful()) {
                log.error("{}:T{} Ошибка при запросе на проверку файла - Статус: {} Ответ: {}", LG.USBLOGERROR, thread, responseCheck.getStatusCode(), responseCheck.getBody());
                facFile.setCheckMessage("Ошибка при запросе на проверку файла - Статус: " + responseCheck.getStatusCode() + " Ответ: " + responseCheck.getBody());
                return facFile;
            } else {
                SandBoxCheck jsonSandboxCheckResp = new ObjectMapper().readValue(responseCheck.getBody(), SandBoxCheck.class);
                if (!jsonSandboxCheckResp.getErrors().isEmpty()) {
                    log.error("{}:T{} При проверке в песочнице файла:{}, возникла ошибка:{}", LG.USBLOGERROR, thread, facFile.getFile().getName(), jsonSandboxCheckResp.getErrors().get(0).getMessage());
                    facFile.setCheckMessage(jsonSandboxCheckResp.getErrors().get(0).getMessage());
                    return facFile;
                } else {
                    log.info("{}:T{} Файл:{}, статус проверки: verdict={}, ScanState={}, duration={}", LG.USBLOGINFO, thread, facFile.getFile().getName(),
                            jsonSandboxCheckResp.getData().getResult().getVerdict(),
                            jsonSandboxCheckResp.getData().getResult().getScanState(),
                            jsonSandboxCheckResp.getData().getResult().getDuration());
                    facFile.setResult(jsonSandboxCheckResp.getData().getResult());
                    facFile.setCheckStatus(responseCheck.getStatusCode().value()); //д.б. 200
                    return facFile;
                }
            }
        } catch (JsonProcessingException | HttpServerErrorException | HttpClientErrorException |
                 ResourceAccessException e) {
            log.error("{}T{} Ошибка:{} при формировании запроса на проверку файла:{}", LG.USBLOGERROR, thread, e.getMessage(), facFile.getFile().getName());
            log.debug("{}T{} Ошибка:{} при формировании запроса на проверку файла:{}", LG.USBLOGERROR, thread, e.getMessage(), facFile.getFile().getName());
            if (e instanceof HttpServerErrorException){
                log.error("{} HttpServerErrorException:{}", LG.USBLOGERROR, e.getMessage());
                facFile.setStatus(((HttpServerErrorException) e).getStatusCode());
                if (((HttpServerErrorException) e).getStatusCode() == HttpStatus.NOT_FOUND){
                    facFile.setCheckStatus(404);
                } else {
                    facFile.setCheckStatus(((HttpServerErrorException) e).getStatusCode().value());
                }
            }
            if (e instanceof HttpClientErrorException){
                log.error("{}T{} HttpClientErrorException:{}", LG.USBLOGERROR, thread, e.getMessage());
                facFile.setCheckStatus(((HttpClientErrorException) e).getStatusCode().value());
            }
            if (e instanceof ResourceAccessException){
                log.error("{}T{} ResourceAccessException:{}", LG.USBLOGERROR, thread, e.getMessage());
                facFile.setCheckStatus(500);
            }
            facFile.setCheckMessage(e.getMessage());
            return facFile;
        }


    }

    @Value("${sandbox.analysis.duration:60}")
    private int sandboxAnalysisDuration;

    /**
     * Получение теля запроса
     * Изменение от 16.08.2024
     *  + Надо сделать запрос async и short =  true
     *     "mark_suspicious_files_options": {
     *       "encrypted_not_unpacked": true, 1
     *       "max_depth_exceeded": true,2
     *       "office_encrypted": true,3
     *       "office_has_macros": true,4
     *       "office_has_embedded": true,5
     *       "office_has_active_x": true,6
     *       "office_has_dde": true,7
     *       "office_has_remote_data": true,8
     *       "office_has_remote_template": true,9
     *       "office_has_action": true,10
     *       "pdf_encrypted": true,11
     *       "pdf_has_embedded": true,12
     *       "pdf_has_open_action": true,13
     *       "pdf_has_action": true,14
     *       "pdf_has_javascript": true, 15
     *     }
     *
     * @param facFile - объект FacFile
     * @return - тело запроса
     */
    private JsonSandboxCheckReq getJsonSandboxCheckReq(FacFile facFile) {
        JsonSandboxCheckReq jsonSandboxCheckReq = new JsonSandboxCheckReq();
        jsonSandboxCheckReq.setFileUri(facFile.getFileUri());
        jsonSandboxCheckReq.setFileName(facFile.getName());
        jsonSandboxCheckReq.setAsyncResult(false);
        jsonSandboxCheckReq.setShortResult(false);
        //SandBox
        Sandbox sandbox = new Sandbox();
        sandbox.setEnabled(true);
        sandbox.setImageId("win7-sp1-x64");
        sandbox.setAnalysisDuration(sandboxAnalysisDuration);
        sandbox.setSaveVideo(false);
        //Option
        Options options = new Options();
        options.setSandbox(sandbox);
        options.setAnalysisDepth(5); //Из fsd
        //MarkFiles
        MarkSuspiciousFilesOptions markSuspiciousFilesOptions = new MarkSuspiciousFilesOptions();
        markSuspiciousFilesOptions.setEncryptedNotUnpacked(true); //1
        markSuspiciousFilesOptions.setMaxDepthExceeded(true); //2
        markSuspiciousFilesOptions.setOfficeEncrypted(true); //3
        markSuspiciousFilesOptions.setOfficeHasMacros(true); //4
        markSuspiciousFilesOptions.setOfficeHasEmbedded(true);//5
        markSuspiciousFilesOptions.setOfficeHasActiveX(true); //6
        markSuspiciousFilesOptions.setOfficeHasDde(true); //7
        markSuspiciousFilesOptions.setOfficeHasRemoteData(true);//8
        markSuspiciousFilesOptions.setOfficeHasRemoteTemplate(true);//9
        markSuspiciousFilesOptions.setOfficeHasAction(true);//10
        markSuspiciousFilesOptions.setPdfEncrypted(true);//11
        markSuspiciousFilesOptions.setPdfHasEmbedded(true);//12
        markSuspiciousFilesOptions.setPdfHasOpenAction(true);//13
        markSuspiciousFilesOptions.setPdfHasAction(true);//14
        markSuspiciousFilesOptions.setPdfHasJavascript(true);//15
        options.setMarkSuspiciousFilesOptions(markSuspiciousFilesOptions);
        //Request
        jsonSandboxCheckReq.setOptions(options);
        return jsonSandboxCheckReq;
    }
}
