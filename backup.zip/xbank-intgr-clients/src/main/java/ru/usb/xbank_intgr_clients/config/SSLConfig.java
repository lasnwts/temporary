package ru.usb.xbank_intgr_clients.config;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.nio.file.Paths;

@Log4j2
@Service
public class SSLConfig {

    @Value("${http.client.ssl.trust-store}")
    private String trustStore;
    @Value("${http.client.ssl.trust-store-password}")
    private String tsPass;

    @EventListener(ApplicationReadyEvent.class)
    @Order(1)
    public void sslConfig() {
        Path path;
        try {
            path = Paths.get(trustStore);
            if (path.toFile().exists()){
                log.info("{}:Файл сертификата: существует{} существует", LG.USBLOGINFO, path.toString());
                extracted(path.toString());
            } else {
                log.error("{}:Ошибка регистрации JKS:Файл сертификата: НЕ существует{} существует! Работа невозможна!!", LG.USBLOGERROR, path.toString());
            }
        } catch (Exception exception) {
            log.error("{}: Произошла ошибка, возможно файл сертификата: {} не найден", LG.USBLOGERROR, trustStore);
            log.error("{}: SSLConfig: {}", LG.USBLOGERROR, exception.getMessage());
        }
    }

    private void extracted(String path) {
        System.setProperty("javax.net.ssl.trustStore", path);
        System.setProperty("javax.net.ssl.trustStorePassword", tsPass);
        log.info("{}: SSL:[{}] сертификат зарегистрирован в системе", LG.USBLOGINFO, path);
    }

}
