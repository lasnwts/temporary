package ru.usb.xbank_intgr_clients.model.s3;


import lombok.*;
import org.springframework.http.HttpStatus;

import java.util.List;

/**
 * Результат проверки подключения к S3
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class CheckS3 {
    private String message; //Описание
    private HttpStatus errorCode; //Статус
    private boolean success; //Результат проверки
    private List<String> data; //Список бакетов (или файлов)
    private List<String> buckets; //Список бакетов (или файлов)
}
