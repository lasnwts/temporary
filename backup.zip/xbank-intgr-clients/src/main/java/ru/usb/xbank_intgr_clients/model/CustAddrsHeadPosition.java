package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustAddrsHeadPosition {
    private int client; //2
    private int addressType;//3
    private int addressDateReg;//4
    private int levelFiasRegion;//5
    private int aoguidRegion;//6
    private int levelFiasRegionArea;//7
    private int aoguidRegionArea;//8
    private int levelFiasCity;//9
    private int aoguidCity;//10
    private int levelFiasSetCity;//11
    private int aoguidSetCity;//12
    private int levelFiasStreet;    //13
    private int aoguidStreet;//14
    private int levelFiasHouse;//15
    private int aoguidHouse;//16
    private int levelFiasApartment;//17
    private int aoguidApartment;//18
    private int addressHouse;//19
    private int addressHouseKorp;//20
    private int addressApartament;//21
    private int temporaryReg;//22
    private int dateRegEnd;//23

}
