package ru.usb.xbank_intgr_clients.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_clients.dto.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Long> {
}
