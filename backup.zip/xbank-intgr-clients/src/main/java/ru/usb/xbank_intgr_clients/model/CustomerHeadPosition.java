package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustomerHeadPosition {
    private int client;
    private int name;
    private int datePers;
    private int bornPlace;
    private int regStatus;
    private int agreeAdvert;
    private int agreeSell;
    private int resident;
    private int countryCode;
    private int inn;
    private int sexCode;
    private int marigeStatusCode;
    private int declName;
    private int declCaseGrCode;
    private int levEducCode;
    private int wel;
}
