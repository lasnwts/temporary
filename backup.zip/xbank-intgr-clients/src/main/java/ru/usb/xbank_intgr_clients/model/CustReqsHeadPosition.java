package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustReqsHeadPosition {
    private int reqsCustNumb;//Идентификационный номер клиента
    private int dateChngName;//Дата изменения ФИО
    private int childrenCount;//Количество детей
    private int dependantsCount;//Количество иждивенцев
    private int familyMembers;//Количество членов семьи
    private int prevLastName;//Прежние ФИО
    private int reasonChngName;//Причина изменения ФИО
    private int occupationState;//Тип занятости.наименование
}
