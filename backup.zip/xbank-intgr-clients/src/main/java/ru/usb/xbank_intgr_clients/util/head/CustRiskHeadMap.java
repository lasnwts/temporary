package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustRiskHeadPosition;

@Component
public class CustRiskHeadMap {

    private static final String COMMA_DELIMITER = ";";

    //GR_CLIENT;GR_DATE_START;GR_DATE_END;GR_ACC_FEATURE;GR_GROUP_NUM;GR_CRED_GROUP_NUM;GR_SERVICE_QUAL;GR_PRC_RESERV;GR_FIX;GR_;GR_RESUME

    /**
     * Маппинг строки
     * @param line - строка
     * @return - объект
     */
    public CustRiskHeadPosition map(String line) {
        String[] values = line.split(COMMA_DELIMITER);
        CustRiskHeadPosition custRiskHeadPosition = new CustRiskHeadPosition();
        custRiskHeadPosition.setGrClient(getPosition("GR_CLIENT", values));
        custRiskHeadPosition.setGrDateStart(getPosition("GR_DATE_START", values));
        custRiskHeadPosition.setGrDateEnd(getPosition("GR_DATE_END", values));
        custRiskHeadPosition.setGrAccFeature(getPosition("GR_ACC_FEATURE", values));
        custRiskHeadPosition.setGrGroupNum(getPosition("GR_GROUP_NUM", values));
        custRiskHeadPosition.setGrCredGroupNum(getPosition("GR_CRED_GROUP_NUM", values));
        custRiskHeadPosition.setGrServiceQual(getPosition("GR_SERVICE_QUAL", values));
        custRiskHeadPosition.setGrPrcReserv(getPosition("GR_PRC_RESERV", values));
        custRiskHeadPosition.setGrFix(getPosition("GR_FIX", values));
        custRiskHeadPosition.setGr(getPosition("GR_PEOPLE", values));
        custRiskHeadPosition.setGrResume(getPosition("GR_RESUME", values));
        return custRiskHeadPosition;
    }



    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
