package ru.usb.xbank_intgr_clients.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustRisk;
import ru.usb.xbank_intgr_clients.model.CustRiskHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;
import ru.usb.xbank_intgr_clients.repository.CustRiskRepo;
import ru.usb.xbank_intgr_clients.util.CustRiskMapper;
import ru.usb.xbank_intgr_clients.util.Support;
import ru.usb.xbank_intgr_clients.util.head.CustRiskHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadCustRisk {

    private final Support support;
    private final CustRiskHeadMap custRiskHeadMap;
    private final CustRiskMapper custRiskMapper;
    private final CustRiskRepo custRiskRepo;
    private final Configure configure;

    @Autowired
    public LoadCustRisk(Support support, CustRiskHeadMap custRiskHeadMap,
                        CustRiskMapper custRiskMapper, CustRiskRepo custRiskRepo, Configure configure) {
        this.support = support;
        this.custRiskHeadMap = custRiskHeadMap;
        this.custRiskMapper = custRiskMapper;
        this.custRiskRepo = custRiskRepo;
        this.configure = configure;
    }


    public List<LoadError> loadFile(File file, long thread) throws Exception {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadCustRisk, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}:T{}: Подготовка процесса: Load LoadCustRisk к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<CustRiskHeadPosition> custRiskHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadCustRisk, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                custRiskHeadPosition.set(custRiskHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckCustRisk checkCustRisk = custRiskMapper.map(line.trim(), custRiskHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}:T{}: CustRisk={}", LG.USBLOGINFO, thread, checkCustRisk.getCustRisk());
                                custRiskRepo.saveAndFlush(checkCustRisk.getCustRisk()); //сохраняем
                                if (checkCustRisk.getLoadError().isStatus()) {
                                    loadErrorList.add(checkCustRisk.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            configure.setSyncErrorOnProcessed(true);
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadCustRisk, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            configure.setSyncErrorOnProcessed(true);
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
            throw new IOException(e);
        }
        try {
            if (Files.deleteIfExists(file.toPath())) {
                log.info("{}:T{}: Файл {} удален", LG.USBLOGINFO, thread, file.getAbsolutePath());
            } else {
                log.info("{}:T{}: Файл {} не удален, возникла проблема при удалении.", LG.USBLOGINFO, thread, file.getAbsolutePath());
            }
        } catch (IOException e) {
            log.info("{}:T{}: Возникла ошибка при удалении файла:{}, ошибка:{}", LG.USBLOGINFO, thread, file.getAbsolutePath(), e.getMessage());
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadCustRisk. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

