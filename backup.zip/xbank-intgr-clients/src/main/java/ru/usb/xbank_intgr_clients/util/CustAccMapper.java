package ru.usb.xbank_intgr_clients.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.dto.CustAcc;
import ru.usb.xbank_intgr_clients.dto.check.CheckCustAcc;
import ru.usb.xbank_intgr_clients.model.CustAccHeadPosition;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class CustAccMapper {

    private final Configure configure;

    @Autowired
    public CustAccMapper(Configure configure) {
        this.configure = configure;
    }

    private static final String COMMA_DELIMITER = ";";

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");


    //    private int inspectCustNmb;//CLIENT таблицы tbank.customer.csv
    //    private int accBankNumb;//Номер счета
    //    private int accBankOpenDate;//Дата открытия счета
    //    private int accBankBik;//БИК банка
    //    private int accBankCloseDate;//Дата закрытия

    //INSPECT_CUST_NMBR;ACC_BANK_NUMB;ACC_BANK_OPEN_DATE;ACC_BANK_BIK;ACC_BANK_CLOSE_DATE

    public CheckCustAcc map(String line, CustAccHeadPosition custAccHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(COMMA_DELIMITER);
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        CustAcc custAcc = new CustAcc();
        //Константы
        custAcc.setNumInsert(numInsert);
        custAcc.setInputDate(new Date());
        custAcc.setFileName(configure.getArchiveName());

        try {
            if (custAccHeadPosition.getInspectCustNmb() > -1) {
                custAcc.setInspectCustNmb(values[custAccHeadPosition.getInspectCustNmb()]);
            } else {
                setLoadError("Не найден обязательный параметр:INSPECT_CUST_NMBR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:INSPECT_CUST_NMBR" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:INSPECT_CUST_NMBR: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //ACC_BANK_NUMB
            if (custAccHeadPosition.getAccBankNumb() > -1) {
                custAcc.setAccBankNumb(values[custAccHeadPosition.getAccBankNumb()]);
            } else {
                setLoadError("Не найден обязательный параметр:ACC_BANK_NUMB", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACC_BANK_NUMB" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ACC_BANK_NUMB: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //ACC_BANK_OPEN_DATE
            if (custAccHeadPosition.getAccBankOpenDate() > -1 && checkDateLine(values[custAccHeadPosition.getAccBankOpenDate()])) {
                custAcc.setAccBankOpenDate(convertDateToSqlDate(parseDateLine(values[custAccHeadPosition.getAccBankOpenDate()])));
            } else {
                setLoadError("Ошибка в параметре:ACC_BANK_OPEN_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACC_BANK_OPEN_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ACC_BANK_OPEN_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //ACC_BANK_BIK
            if (custAccHeadPosition.getAccBankBik() > -1) {
                custAcc.setAccBankBik(values[custAccHeadPosition.getAccBankBik()]);
            } else {
                setLoadError("Не найден обязательный параметр:ACC_BANK_BIK", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACC_BANK_BIK" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ACC_BANK_BIK: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }

        try {
            //ACC_BANK_CLOSE_DATE
            if (custAccHeadPosition.getAccBankCloseDate() > -1 && checkDateLine(values[custAccHeadPosition.getAccBankCloseDate()])) {
                custAcc.setAccBankCloseDate(convertDateToSqlDate(parseDateLine(values[custAccHeadPosition.getAccBankCloseDate()])));
            } else {
                setLoadError("Ошибка в параметре:ACC_BANK_CLOSE_DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACC_BANK_CLOSE_DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:ACC_BANK_CLOSE_DATE: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Stack Trace: ", LG.USBLOGERROR, e);
        }
        return new CheckCustAcc(custAcc, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

}
