package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustContHeadPosition {
    private int client; //CLIENT таблицы tbank.customer.csv
    private int contactsPrivate;
    private int contactsActiv;
    private int contactsNumb;//Номер (адрес)
    private int contactsType;//Тип связи
}
