package ru.usb.xbank_intgr_clients.model;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustAccHeadPosition {
    private int inspectCustNmb;//CLIENT таблицы tbank.customer.csv
    private int accBankNumb;//Номер счета
    private int accBankOpenDate;//Дата открытия счета
    private int accBankBik;//БИК банка
    private int accBankCloseDate;//Дата закрытия
}
