package ru.usb.xbank_intgr_clients.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustRiskHeadPosition {
    private int grClient;//CLIENT таблицы tbank.customer.csv
    private int grDateStart;//Дата начала принадлежности
    private int grDateEnd;//Дата конца принадлежности
    private int grAccFeature;//Доходы/расходы относить на себестоимость
    private int grGroupNum;//Номер группы риск
    private int grCredGroupNum;//Номер расчетной группы кредитного риска
    private int grServiceQual;//Признак качества обслуживания долга
    private int grPrcReserv;//Процент резервирования
    private int grFix;//Зафиксировано пользователем
    private int gr;//Сетевое имя пользователя внесшего изменения
    private int grResume;//Причина отнесения в группу риска
}
