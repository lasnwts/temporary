package ru.usb.xbank_intgr_clients.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.FacFile;

import java.util.Optional;

@Service
public class MapperFacFile {
    private static final Logger log = LoggerFactory.getLogger(MapperFacFile.class);
    ObjectMapper objectMapper = new ObjectMapper();
    public Optional<FacFile> getFacFile(String json) {
        if (json == null) {
            log.error("{}: На маппер MapperFacFile поступил объект, строка [Json] == NULL!", LG.USBLOGERROR);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, FacFile.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", LG.USBLOGERROR, e);
            return Optional.empty();        }
    }
}
