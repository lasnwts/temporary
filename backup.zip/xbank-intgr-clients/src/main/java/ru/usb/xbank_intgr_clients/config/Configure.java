package ru.usb.xbank_intgr_clients.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.LoadError;

import java.util.List;

@Getter
@Setter
@Component
@ConfigurationProperties
public class Configure {

    @Value("${hour.begin:8}")
    private int hourBegin; //Время начала работы

    @Value("${hour.end:22}")
    private int hourEnd; //Время окончания работы

    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Информация о загрузке файлов
     * tbank.custacc.csv
     * tbank.custaddrs.csv
     * tbank.custcont.csv
     * tbank.custdocs.csv
     * tbank.custempr.csv
     * tbank.custinspect.csv
     * tbank.customer.csv
     * tbank.custreqs.csv
     * tbank.custrisk.csv
     * tbank.custsoc.csv
     */
    private boolean custacc; //Успешность загрузки = true 1
    private boolean custaddrs; //Успешность загрузки = true 2
    private boolean custcont; //Успешность загрузки = true 3
    private boolean custdocs; //Успешность загрузки = true 4
    private boolean custempr; //Успешность загрузки = true 5
    private boolean custinspect; //Успешность загрузки = true 6
    private boolean customer; //Успешность загрузки = true 7
    private boolean custreqs; //Успешность загрузки = true 8
    private boolean custrisk; //Успешность загрузки = true 9
    private boolean custsoc; //Успешность загрузки = true 10

    private String errorSummary; //Всякие ошибки

    private List<LoadError> loadErrorListcustacc; //1
    private List<LoadError> loadErrorListcustaddrs; //2
    private List<LoadError> loadErrorListcustcont; //3
    private List<LoadError> loadErrorListcustdocs; //4
    private List<LoadError> loadErrorListcustempr; //5
    private List<LoadError> loadErrorListcustinspect; //6
    private List<LoadError> loadErrorListcustomer; //7
    private List<LoadError> loadErrorListcustreqs; //8
    private List<LoadError> loadErrorListcustrisk; //9
    private List<LoadError> loadErrorListcustsoc; //10


    /**
     * Количество задач в очереди
     */
    private int threads;

    /**
     * Путь к общей папке с файлами
     */
    @Value("${scheduler.delay}")
    private String schedulerDelay;

    /**
     * Проверка разрешена работа по времени или нет.
     */
    @Value("${work.time:true}")
    private boolean workTime;

    /**
     * Установка разрешена работа по времени или нет.
     */
    public synchronized void setSyncWorkTime(boolean workTime) {
        this.workTime = workTime;
    }

    /**
     * Получение разрешена работа по времени или нет.
     */
    public synchronized boolean isSyncWorkTime() {
        return workTime;
    }


    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private Integer servicePoolSize;

    /**
     * Кол-во потоков
     */
    public synchronized int getThreads() {
        return threads;
    }

    public synchronized void setThreads(int threads) {
        this.threads = threads;
    }

    public int getServicePoolSize() {
        return servicePoolSize;
    }


    private String letter5xxSubject = "S3 = Tbankfiles недоступен Микросервис: xbank-intgr-clients Статус: 5xx";

    private String letter5x = "S3 = Tbankfiles недоступен\n" +
            "Микросервис: xbank-intgr-credit\n" +
            "Статус: 500\n" +
            "Описание ошибки : Internal Server Error\n";

    private String letter4xxSubject = "S3 = Tbankfiles недоступен Микросервис: xbank-intgr-clients Статус: 4xx";

    private String letter4x = "S3 = Tbankfiles проблемы см авторизацией\n" +
            "Микросервис: xbank-intgr-credit\n" +
            "Статус: 4xx\n" +
            "Описание ошибки : \n";


    private String letterFtps = "ftps.uralsib.ru недоступен\n" +
            "Микросервис: xbank-intgr-clients\n" +
            "Статус: 500\n" +
            "Описание ошибки : Internal Server Error\n";

    private String letterFtpsSubject = "ftps.uralsib.ru недоступен Микросервис: xbank-intgr-clients";


    private String letterBadZzip = "Не загружен zip-архив\n" +
            "Файл: rup_o_credddddddddddddd.zip\n" +
            "Микросервис: xbank-intgr-clients\n" +
            "Дата: 09.10.2024 15:12:30\n" +
            "Описание: например, не прошел проверку на битость.\n";

    private String letterBadZzipSubject = "Не загружен zip-архив Микросервис: xbank-intgr-clients";

    private String letterUnzipError = "Ошибка при разархивации\n" + "Микросервис:  xbank-intgr-clients\n";

    private String letterUnzipSubjectError = "Ошибка при разархивации Микросервис:  xbank-intgr-clients";

    private String letterVirusSubject = "Внимание Файл заражен! Микросервис: xbank-intgr-clients";

    private String letterNoneStatusCheck = "Файл не прошел проверку. Микросервис: xbank-intgr-clients";


    /**
     * Настройки FTPS
     */
    @Value("${ftps.user}")
    private String ftpsUser;

    @Value("${ftps.password}")
    private String ftpsPassword;

    @Value("${ftps.directory}")
    private String ftpsDirectory;

    /**
     * S3
     */
    @Value("${s3.file.mask}")
    private String s3MaskFile; //Маска файла

    @Value("${s3.file.ext}")
    private String s3ExtFile; //Расширение файла

    @Value("${s3.bucket.base}")
    private String s3BucketBase; //основной бакет

    @Value("${s3.bucket.quarantine}")
    private String s3BucketQuarantine; //Карантин бакет

    @Value("${s3.directory.input}")
    private String s3DirInput; //Директория для файла

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * COMMA DELIMITER
     */
    @Value("${csv.delimiter:;}")
    private String csvDelimiter;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${net.file.share}")
    private String netFileShare;

    /**
     * Проверка в SandBox
     */
    @Value("${check.sandbox:true}")
    private String checkSandBox;


}
