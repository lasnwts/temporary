package ru.usb.xbank_intgr_clients.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_clients.dto.CustInspect;

public interface CustInspectRepo extends JpaRepository<CustInspect, Long>{
}
