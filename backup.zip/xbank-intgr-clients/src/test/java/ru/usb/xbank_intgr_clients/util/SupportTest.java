package ru.usb.xbank_intgr_clients.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.xbank_intgr_clients.config.Configure;

import static org.junit.jupiter.api.Assertions.*;

class SupportTest {

    private Support support;
    private Configure configure;


    @BeforeEach
    void setUp() {
        configure = new Configure();
        support = new Support(configure);
    }

    @Test
    void getFileName() {
        String fileName = "C:/test/tbank.customer.csv";
        System.out.println(support.getFileName(fileName));
        assertEquals("tbank.customer.csv", support.getFileName(fileName));
    }


    @Test
    void getExtension() {
        String fileName = "C:/test/tbank.customer.csv";
        System.out.println(support.getExtension(fileName));
        assertEquals("csv", support.getExtension(fileName));

    }

}