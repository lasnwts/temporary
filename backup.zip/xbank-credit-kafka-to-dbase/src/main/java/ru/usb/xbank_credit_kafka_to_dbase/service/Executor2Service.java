package ru.usb.xbank_credit_kafka_to_dbase.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xbank_credit_kafka_to_dbase.config.Configure;
import ru.usb.xbank_credit_kafka_to_dbase.config.LG;
import ru.usb.xbank_credit_kafka_to_dbase.dto.Planall;
import ru.usb.xbank_credit_kafka_to_dbase.repository.PlanallRepo;


import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class Executor2Service {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    Logger log = LoggerFactory.getLogger(Executor2Service.class);

    private final Configure configure;
    private final PlanallRepo planallRepo;

    private static ExecutorService executorService;

    @Autowired
    public Executor2Service(Configure configure, PlanallRepo planallRepo) {
        this.configure = configure;
        this.planallRepo = planallRepo;
    }

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = Executors.newFixedThreadPool(poolSize);
    }

    public synchronized ExecutorService getThreadPool() {
        return executorService;
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(Planall messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        log.debug("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
        log.debug("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.debug("{}:T{} Поток передан на запуск в executor service. Поток с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
    }

    class MyThread implements Runnable {
        Planall message;
        CountDownLatch latch;

        MyThread(CountDownLatch c, Planall messageBody) {
            latch = c;
            message = messageBody;
            new Thread(this);
        }

        public void run() {
            //Старт потока
            log.debug("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());
            //Обработка сообщения
            planallRepo.saveAndFlush(message);
            //Подвал завершения потока
            log.debug("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.debug("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }
    }
}


