package ru.usb.xbank_credit_kafka_to_dbase.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xbank_credit_kafka_to_dbase.config.Configure;
import ru.usb.xbank_credit_kafka_to_dbase.config.LG;
import ru.usb.xbank_credit_kafka_to_dbase.dto.Planall;
import ru.usb.xbank_credit_kafka_to_dbase.repository.PlanallRepo;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class Executors2Service {

    Logger log = LoggerFactory.getLogger(Executors2Service.class);

    private final Configure configure;
    private final PlanallRepo planallRepo;

    private static ExecutorService executorService;

    @Autowired
    public Executors2Service(Configure configure, PlanallRepo planallRepo) {
        this.configure = configure;
        this.planallRepo = planallRepo;
    }

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = Executors.newFixedThreadPool(poolSize);
    }

    public synchronized ExecutorService getThreadPool() {
        return executorService;
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(List<Planall> messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        log.debug("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
        log.debug("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.debug("{}:T{} Поток передан на запуск в executor service. Поток с сообщением:{}", LG.USBLOGINFO, Thread.currentThread().getId(), messageBody);
    }

    class MyThread implements Runnable {
        List<Planall> messages;
        CountDownLatch latch;

        MyThread(CountDownLatch c, List<Planall> messageBody) {
            latch = c;
            messages = messageBody;
            new Thread(this);
        }

        public void run() {
            //Старт потока
            log.debug("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());
            //Обработка сообщения
            planallRepo.saveAllAndFlush(messages);
            //Подвал завершения потока
            log.debug("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            log.debug("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        }
    }
}



