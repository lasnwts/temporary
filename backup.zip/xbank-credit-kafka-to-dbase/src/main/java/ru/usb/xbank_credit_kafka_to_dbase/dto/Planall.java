package ru.usb.xbank_credit_kafka_to_dbase.dto;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

@Entity
@Table(name = "TBANK_PLANALL")
public class Planall {

    @Id
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    //S;DATE;DATE_BEG;DATE_END;OPER;SUM;CHANGE;VALUTA

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора

    @Column(name = "DATEO")//3
    private Date date;//Дата планового платежа

    @Column(name = "DATE_BEG")//4
    private Date dateBeg;//Дата начала периода

    @Column(name = "DATE_END")//5
    private Date dateEnd;//Дата окончания периода

    @Column(name = "OPER")//6
    private String oper;//Вид плановой операции по договору

    @Column(name = "SUM")//7
    private BigDecimal sum;//;Сумма планового платежа

    @Column(name = "CHANGE")//8
    private String change;//Вариант изменения планового графика

    @Column(name = "VALUTA")//9
    private String valuta;//Код валюты операции

    //Имя файла
    @Column(name = "FILENAME")//10
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//11
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//12
    private long numInsert; //Номер вставки

    public Planall() {
        //
    }

    public Planall(long id, String s, Date date, Date dateBeg, Date dateEnd, String oper, BigDecimal sum,
                   String change, String valuta, String fileName, java.util.Date inputDate, long numInsert) {
        this.id = id;
        this.s = s;
        this.date = date;
        this.dateBeg = dateBeg;
        this.dateEnd = dateEnd;
        this.oper = oper;
        this.sum = sum;
        this.change = change;
        this.valuta = valuta;
        this.fileName = fileName;
        this.inputDate = inputDate;
        this.numInsert = numInsert;
    }

    public Planall(String s, Date date, Date dateBeg, Date dateEnd, String oper, BigDecimal sum,
                   String change, String valuta, String fileName, java.util.Date inputDate, long numInsert) {
        this.s = s;
        this.date = date;
        this.dateBeg = dateBeg;
        this.dateEnd = dateEnd;
        this.oper = oper;
        this.sum = sum;
        this.change = change;
        this.valuta = valuta;
        this.fileName = fileName;
        this.inputDate = inputDate;
        this.numInsert = numInsert;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDateBeg() {
        return dateBeg;
    }

    public void setDateBeg(Date dateBeg) {
        this.dateBeg = dateBeg;
    }

    public Date getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Date dateEnd) {
        this.dateEnd = dateEnd;
    }

    public String getOper() {
        return oper;
    }

    public void setOper(String oper) {
        this.oper = oper;
    }

    public BigDecimal getSum() {
        return sum;
    }

    public void setSum(BigDecimal sum) {
        this.sum = sum;
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }

    public String getValuta() {
        return valuta;
    }

    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public java.util.Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(java.util.Date inputDate) {
        this.inputDate = inputDate;
    }

    public long getNumInsert() {
        return numInsert;
    }

    public void setNumInsert(long numInsert) {
        this.numInsert = numInsert;
    }

    @Override
    public String toString() {
        return "Planall{" +
                "id=" + id +
                ", s='" + s + '\'' +
                ", date=" + date +
                ", dateBeg=" + dateBeg +
                ", dateEnd=" + dateEnd +
                ", oper='" + oper + '\'' +
                ", sum=" + sum +
                ", change='" + change + '\'' +
                ", valuta='" + valuta + '\'' +
                ", fileName='" + fileName + '\'' +
                ", inputDate=" + inputDate +
                ", numInsert=" + numInsert +
                '}';
    }
}
