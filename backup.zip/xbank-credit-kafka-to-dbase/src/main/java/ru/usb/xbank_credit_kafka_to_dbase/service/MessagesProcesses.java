package ru.usb.xbank_credit_kafka_to_dbase.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_credit_kafka_to_dbase.dto.Planall;
import ru.usb.xbank_credit_kafka_to_dbase.util.PlanallMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MessagesProcesses {

    private static final Logger log = LoggerFactory.getLogger(MessageProcess.class);
    List<Planall> planallList = new ArrayList<>();

    private final Executors2Service executor2Service;
    private final PlanallMapper planallMapper;

    @Autowired
    public MessagesProcesses(Executors2Service executor2Service, PlanallMapper planallMapper) {
        this.executor2Service = executor2Service;
        this.planallMapper = planallMapper;
    }

    public void process(String message) {
        //Парсим сообщение
        Optional<Planall> planall = planallMapper.parse(message);
        if (planall.isEmpty()) {
            log.error("Error parsing message: {}", message);
        } else {
            log.debug("Parsed message: {}", planall.get());
            planallList.add(planall.get());
            if (planallList.size() > 2) {
                executor2Service.getTask(planallList);
                planallList.clear();
            }
        }
    }

}
