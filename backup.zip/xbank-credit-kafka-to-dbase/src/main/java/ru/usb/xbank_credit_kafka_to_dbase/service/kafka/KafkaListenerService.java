package ru.usb.xbank_credit_kafka_to_dbase.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.xbank_credit_kafka_to_dbase.config.LG;
import ru.usb.xbank_credit_kafka_to_dbase.service.MessageProcess;
import ru.usb.xbank_credit_kafka_to_dbase.service.MessagesProcesses;


@Configuration
@EnableKafka
public class KafkaListenerService {

    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final MessageProcess messageProcess;
    private final MessagesProcesses messagesProcesses;


    @Autowired
    public KafkaListenerService(MessageProcess messageProcess, MessagesProcesses messagesProcesses) {
        this.messageProcess = messageProcess;
        this.messagesProcesses = messagesProcesses;
    }

    @Value("${service.attempt:4}")
    private int countAttempt;

    @Value("${max.size.queue:100}") //Максимальное число записей, принятых в обработку
    private int maxSizeQueue;

    @Value("${ack.nack.duration:10}") //Задержка перед приемом новой порции сообщений
    private int ackDuration;

    @KafkaListener(topics = "${kafka.event.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {
        ack.acknowledge(); //Сообщение забираем сразу
            logger.debug("{}:: Сообщение из Kafka, START.", LG.USBLOGINFO);
            logger.debug("{}::++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", LG.USBLOGINFO);
            logger.debug("{}::KafkaListener(record.partition) == {}", LG.USBLOGINFO, recordKafka.partition());
            logger.debug("{}::KafkaListener(record.key)       == {}", LG.USBLOGINFO, recordKafka.key());
            logger.debug("{}::KafkaListener(record.value)     == {}", LG.USBLOGINFO, recordKafka.value());
            logger.debug("{}::KafkaListener(topic)            == {}", LG.USBLOGINFO, recordKafka.topic());
            logger.debug("{}::KafkaListener(Offset)           == {}", LG.USBLOGINFO, recordKafka.offset());
            logger.debug("{}::-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-", LG.USBLOGINFO);
           messagesProcesses.process(recordKafka.value());
//           messageProcess.process(recordKafka.value());
        }


}
