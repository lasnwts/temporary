package ru.usb.xbank_credit_kafka_to_dbase.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.util.Objects;

/**
 * Класс конфигурации для создания DataSource, которые используются для обращения к базе данных.
 * В данном классе устанавливаются параметры для подключения, взятые с application.properties
 */
@Configuration
public class JdbcConfig {

    private Environment env;

    @Autowired
    public JdbcConfig(Environment env) {
        this.env = env;
    }

    @Bean(name = "citiDataSource")
    public DataSource creDataSource() {
        DriverManagerDataSource datasource = new DriverManagerDataSource();
        datasource.setDriverClassName(Objects.requireNonNull(env.getProperty("citi.driverClassName")));
        datasource.setUrl(env.getProperty("citi.url"));
        datasource.setUsername(env.getProperty("citi.username"));
        datasource.setPassword(env.getProperty("citi.password"));
        return datasource;
    }
}
