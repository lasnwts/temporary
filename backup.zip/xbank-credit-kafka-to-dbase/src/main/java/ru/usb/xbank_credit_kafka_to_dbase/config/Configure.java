package ru.usb.xbank_credit_kafka_to_dbase.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties
public class Configure {

    //Простановка ошибки на любом процессе
    //false - нет ошибки
    //true - возникла ошибки
    private boolean errorOnProcessed;

    public synchronized boolean getSyncErrorOnProcessed() {
        return errorOnProcessed;
    }

    public synchronized void setSyncErrorOnProcessed(boolean errorOnProcessed) {
        this.errorOnProcessed = errorOnProcessed;
    }


    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Информация о загрузке файлов
     */
    private boolean accBalance; //Успешность загрузки = true
    private boolean dogov; //Успешность загрузки = true
    private boolean fact; //Успешность загрузки = true
    private boolean migrInfo; //Успешность загрузки = true
    private boolean planall; //Успешность загрузки = true
    private boolean pparam; //Успешность загрузки = true
    private boolean prcscheme; //Успешность загрузки = true
    private boolean unloadbki; //Успешность загрузки = true

    private String errorSummary; //Всякие ошибки

    /**
     * Количество задач в очереди
     */
    private int threads;

    /**
     * Путь к общей папке с файлами
     */
    @Value("${scheduler.delay}")
    private String schedulerDelay;

    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private Integer servicePoolSize;

    /**
     * Кол-во потоков
     */
    public synchronized int getThreads() {
        return threads;
    }

    public synchronized void setThreads(int threads) {
        this.threads = threads;
    }

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;
}
