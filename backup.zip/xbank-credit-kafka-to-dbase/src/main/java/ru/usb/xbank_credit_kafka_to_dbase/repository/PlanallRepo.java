package ru.usb.xbank_credit_kafka_to_dbase.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_credit_kafka_to_dbase.dto.Planall;

public interface PlanallRepo extends JpaRepository<Planall, Long> {
}
