package ru.usb.xbank_credit_kafka_to_dbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XbankCreditKafkaToDbaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
