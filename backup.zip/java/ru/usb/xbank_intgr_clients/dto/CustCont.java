package ru.usb.xbank_intgr_clients.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.persistence.TemporalType;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_CUSTCONT")
public class CustCont {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")
    private long id; //1

    @Column(name = "CLIENT")//2
    private String client; //CLIENT таблицы tbank.customer.csv

    //Принадлежность
    @Column(name = "CONTACTS_PRIVATE")//3
    private String contactsPrivate;

    //Действующий контакт
    @Column(name = "CONTACTS_ACTIV")//4
    private String contactsActiv;

    @Column(name = "CONTACTS_NUMB")//5
    private String contactsNumb;//Номер (адрес)

    @Column(name = "CONTACTS_TYPE")//6
    private String contactsType;//Тип связи

    @Column(name = "FILENAME")//7
    private String fileName;//Имя файла

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INPUT_DATE")//8
    private Date inputDate;//Дата внесения записи

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки



}
