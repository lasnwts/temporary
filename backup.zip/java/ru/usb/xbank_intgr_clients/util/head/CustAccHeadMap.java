package ru.usb.xbank_intgr_clients.util.head;

import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.model.CustAccHeadPosition;

@Component
public class CustAccHeadMap {

    private static final String COMMA_DELIMITER = ";";

    //INSPECT_CUST_NMBR;ACC_BANK_NUMB;ACC_BANK_OPEN_DATE;ACC_BANK_BIK;ACC_BANK_CLOSE_DATE
    public CustAccHeadPosition  map(String line){
        String[] values = line.split(COMMA_DELIMITER);
        CustAccHeadPosition  custAccHeadPosition = new CustAccHeadPosition();
        custAccHeadPosition.setInspectCustNmb(getPosition("ACC_BANK_CLIENT", values));
        custAccHeadPosition.setAccBankNumb(getPosition("ACC_BANK_NUMB", values));
        custAccHeadPosition.setAccBankOpenDate(getPosition("ACC_BANK_OPEN_DATE", values));
        custAccHeadPosition.setAccBankBik(getPosition("ACC_BANK_BIK", values));
        custAccHeadPosition.setAccBankCloseDate(getPosition("ACC_BANK_CLOSE_DATE", values));
        return custAccHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }
}
