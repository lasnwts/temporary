package ru.usb.xbank_intgr_clients.service.sandbox;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.FacFile;
import ru.usb.xbank_intgr_clients.model.sandbox.SandBoxResponse;

import java.util.Date;

/**
 * Отправка файла в сэндбокс (песочница) *
 */

@Log4j2
@Service
public class PutSandBox {

    private final RestTemplate restTemplateConnect;

    @Autowired
    public PutSandBox(RestTemplate restTemplateConnect) {
        this.restTemplateConnect = restTemplateConnect;
    }
    // Sandbox
    @Value("${sandbox.url-upload}")
    String sandboxUrlUpload;

    @Value("${sandbox.token}")
    String sandboxToken;

    public FacFile putFileToSandBox(FacFile facFile, long thread) {
        log.info("{}:T{} Отправка файла:{} в SandBox на проверку", LG.USBLOGINFO, thread,facFile.getFile().getAbsolutePath());
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-API-Key", sandboxToken);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        FileSystemResource fileSystemResource = new FileSystemResource(facFile.getFile().getAbsolutePath());
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileSystemResource);
        HttpEntity<Object> entity = new HttpEntity<>(body, headers);
        try {
            ResponseEntity<SandBoxResponse> response = restTemplateConnect.postForEntity(sandboxUrlUpload, entity, SandBoxResponse.class);
            log.info("{}:T{} Response:{}", LG.USBLOGINFO, thread,response.getBody());
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && response.getBody().getData() != null && response.getBody().getErrors() != null) {
                facFile.setCheckStatus(200); //успешно передан на проверку
                facFile.setFileUri(response.getBody().getData().getFileUri());
                facFile.setCheckMessage("Файл передан в песочницу для проверки");
                facFile.setDate(new Date()); //Проставим дату
                facFile.setErrors(response.getBody().getErrors());
                log.info("{}:T{} Файл передан в песочницу. Файл:{}", LG.USBLOGINFO, thread, facFile.toString());
                return facFile;
            } else {
                facFile.setCheckStatus(response.getStatusCodeValue()); //ошибка передачи на проверку
                if (response.getBody() != null && response.getBody().getData() != null
                        && response.getBody().getData().getFileUri() != null){
                    facFile.setFileUri(response.getBody().getData().getFileUri());
                }
                facFile.setCheckMessage("Ошибка передачи файла в SandBox");
                facFile.setDate(new Date()); //Проставим дату
                if (response.getBody() != null && response.getBody().getErrors() != null){
                    facFile.setErrors(response.getBody().getErrors());
                }
            }
        } catch (HttpServerErrorException | HttpClientErrorException | ResourceAccessException e) {
            log.error("{}:T{} Ошибка:{}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{} Ошибка: stack:{}", LG.USBLOGERROR, thread, e);
            facFile.setCheckStatus(400); //ошибка передачи на проверку
            facFile.setCheckMessage(e.getMessage());
            return facFile; //возвращаем файл для дальнейшего разбора
        }
        log.info("{}:T{} PutSandBox finished, File={}", LG.USBLOGINFO, thread, facFile.getFile().getAbsolutePath());
        return facFile;
    }
}
