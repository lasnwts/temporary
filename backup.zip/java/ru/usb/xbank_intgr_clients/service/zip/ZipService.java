package ru.usb.xbank_intgr_clients.service.zip;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_clients.config.Configure;
import ru.usb.xbank_intgr_clients.config.LG;
import ru.usb.xbank_intgr_clients.model.db.FtpsResponse;
import ru.usb.xbank_intgr_clients.model.db.TBankHistoryArchives;
import ru.usb.xbank_intgr_clients.service.ApiLayer;
import ru.usb.xbank_intgr_clients.service.db.ApiLayerDB;
import ru.usb.xbank_intgr_clients.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_clients.util.Support;


import java.io.IOException;
import java.nio.file.Files;

@Log4j2
@Component
public class ZipService {

    private final ApiLayer apiLayer;
    private final ServiceMailError serviceMailError;
    private final Configure configure;
    private final Support support;
    private final ZipCheck zipCheck;
    private final ApiLayerDB apiLayerDB;

    @Autowired
    public ZipService(ApiLayer apiLayer, ServiceMailError serviceMailError, Configure configure,
                      Support support, ZipCheck zipCheck, ApiLayerDB apiLayerDB) {
        this.apiLayer = apiLayer;
        this.serviceMailError = serviceMailError;
        this.configure = configure;
        this.support = support;
        this.zipCheck = zipCheck;
        this.apiLayerDB = apiLayerDB;
    }

    /**
     * Проверка zip-архива
     *
     * @param ftpsResponse - объект ответа
     */
    public FtpsResponse checkZip(FtpsResponse ftpsResponse, TBankHistoryArchives tBankHistoryArchives) {
        if (zipCheck.isValidZipFile(ftpsResponse, apiLayer.getThreadTempPath(Thread.currentThread().getId()), Thread.currentThread().getId())) {
            ftpsResponse.setCode(200);
            log.info("{}:T{}: Файл:{} успешно прошел проверку zip-архива", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getName());
            return ftpsResponse;
        } else {
            ftpsResponse.setCode(415);
            ftpsResponse.setMessage("zip-архив поврежден");
            apiLayerDB.saveHistoryArchiveBadZip(ftpsResponse, tBankHistoryArchives); //Записываем, что архив битый
            serviceMailError.sendMailSubject(configure.getLetterBadZzipSubject(), configure.getLetterBadZzip()
                    + "\n\r" + "Файл:" + support.getWrapNull(ftpsResponse.getFile().getName()) +
                    "\n\r" + "Описание:" + support.getWrapNull(ftpsResponse.getMessage()));
            log.error("{}:T{}: Файл:{} НЕ прошел проверку zip-архива", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getName());
            try {
                Files.deleteIfExists(ftpsResponse.getFile().toPath());
                log.info("{}:T{}: Файл:{} удален", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getAbsolutePath());
            } catch (IOException e) {
                log.error("{}:T{}: Ошибка:{} при удалении файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage(), ftpsResponse.getFile().getAbsolutePath());
                ftpsResponse.setCode(500);
                ftpsResponse.setMessage("Ошибка при удалении файла: " + support.getWrapNull(e.getMessage()));
                ftpsResponse.setHttpStatus(HttpStatus.SERVICE_UNAVAILABLE);
            }
            return ftpsResponse;
        }
    }
}
