package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custinspect implements Serializable {

   public String INSPECT_CUST_NMBR;
   public String INSPECT_INSPECT_DATE;
   public String INSPECT_INSPECTOR;
   public String INSPECT_NAME;
   public String INSPECT_NOTES;
}