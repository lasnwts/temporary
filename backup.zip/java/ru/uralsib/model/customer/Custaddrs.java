package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custaddrs implements Serializable {
   public String CLIENT;
   public String ADDRESS_TYPE;
   public String Level_Fias_region;
   public String AOGUID_region;
   public String Level_Fias_region_area;
   public String AOGUID_region_area;
   public String Level_Fias_city;
   public String AOGUID_city;
   public String Level_Fias_set_sity;
   public String AOGUID_set_sity;
   public String Level_Fias_STREET;
   public String AOGUID_street;
   public String Level_Fias_house;
   public String AOGUID_house;
   public String Level_Fias_apartment;
   public String AOGUID_apartment;
   public String ADDRESS_HOUSE;
   public String ADDRESS_HOUSE_KORP;
   public String ADDRESS_APARTAMENT;
   public String TEMPORARY_REG;
   public String ADDRESS_DATE_REG;
   public String DATE_REG_END;
}