package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Pparam implements Serializable {

   public String S;
   public String VIDOPER;
   public String DAYPAY;
   public String DAYCALC;
   public String SUMPAY;
   public String DATE_CALC;
   public String DATE_PAY;
   public String DATE_END;
   public String OPER_COUNT;
   public String ONLY_PRC;
   public String GASH_PAY_PERIOD;
   public String DEPART_FOR_CUT;

}