package ru.uralsib.service.s3;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

@Slf4j
@Service
public class AmazonS3Service {
    @Value("${s3.bucket}")
    private String bucketName;


    private final AmazonS3 s3;

    public AmazonS3Service(AmazonS3 s3) {
        this.s3 = s3;
    }

    /**
     * @param nameFile - название файла
     * @param file     -передаваемый файл
     * @return - путь до файла в S3
     * @throws IOException - IOException
     */
    public String uploadFile(String nameFile, File file) throws IOException {
        if (file != null){
        var b=s3.putObject(bucketName, nameFile, file);
        log.info("в S3 добавлен файл {}, etag {}",nameFile, b.getETag());
        }
        return nameFile;
    }

    /**
     * @param nameFolder       - родительская директория
     * @param originalFilename - название файла
     * @param bytes            -передаваемый файл в байтах
     * @return - путь до файла в S3
     * @throws IOException - IOException
     */
    public String uploadFile(String nameFolder, String originalFilename, byte[] bytes) throws IOException {
        File file = upload(originalFilename, bytes);

        var fileName = nameFolder + "/" + originalFilename;
        s3.putObject(bucketName, fileName, file);
        return fileName;
    }

    public byte[] downloadFile(String fileUrl) throws IOException {
        return getFile(fileUrl);
    }

    public void deleteFile(String fileUrl) {
        if (fileUrl != null) {
            s3.deleteObject(bucketName, fileUrl);
        }
    }

    public List<String> listFiles(String bucketName) {
        List<String> list = new LinkedList<>();
        s3.listObjects(bucketName).getObjectSummaries().forEach(itemResult -> {
            list.add(itemResult.getKey());
            log.info(itemResult.getKey());
        });
        return list;
    }


    private File upload(String name, byte[] content) throws IOException {
        File file = new File(name);
        try (FileOutputStream iofs = new FileOutputStream(file)) {
            iofs.write(content);
        }
        return file;
    }

    public byte[] getFile(String key) throws IOException {
        try (S3Object obj = s3.getObject(bucketName, key)) {
            S3ObjectInputStream stream = obj.getObjectContent();
            byte[] content = IOUtils.toByteArray(stream);
            stream.close();
            return content;
        } catch (IOException e) {
            log.error("ошибка получения файла {}", e.getMessage(), e);
        }
        throw new IOException("файл не найден " + key);
    }
}