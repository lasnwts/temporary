package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class CsvService {

    public File printCsv(String fileName, List<Object> data, int dictIndex) {

        if (data == null || data.size() == 0){
            log.info("Пустой набор объектов, файл: не формируем:{}", fileName);
            return null;
        }


        try {
            var strRes = makeString(data, dictIndex);
            var file = new File(fileName);
            FileUtils.writeStringToFile(file, strRes, "Cp1251");
            return file;
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    public String escapeSpecialCharacters(String data) {
        var escapedData = data.replaceAll("\\R", " ");
        if (data.contains(",") || data.contains("\"") || data.contains("'")) {
            data = data.replace("\"", "\"\"");
            escapedData = "\"" + data + "\"";
        }
        return escapedData;
    }

    private String makeString(List<Object> data, int dictIndex) throws NoSuchFieldException, IllegalAccessException {
        var stringBuilder = new StringBuilder();
        // header
        var headersDict = getHeadersDict(dictIndex);
        var properties = data.get(0).getClass().getDeclaredFields();
        for (var i = 0; i < properties.length; i++) {
            var name = properties[i].getName();
            if (name.equals("DEPART_FOR_CUT")) // Это поле не выводим
                continue;
            if (headersDict.containsKey(name))
                name = headersDict.get(name);
            if (i != 0)
                stringBuilder.append(";");
            stringBuilder.append(name);
        }
        // rows
        for (var i = 0; i < data.size(); i++) {
            var row = data.get(i);
            stringBuilder.append("\n");
            var propertiesRows = data.get(0).getClass().getDeclaredFields();
            for (var j = 0; j < propertiesRows.length; j++) {
                var name = propertiesRows[j].getName();
                if (name.equals("DEPART_FOR_CUT")) // Это поле не выводим
                    continue;
                var valueObject = row.getClass().getDeclaredField(name).get(row);
                var valueString = valueObject != null ? valueObject.toString() : "";
                if (j != 0)
                    stringBuilder.append(";");
                stringBuilder.append(escapeSpecialCharacters(valueString.replace(";","")));
            }
        }
        return stringBuilder.toString();
    }

    public Map<String, String> getHeadersDict(int index) {
        var headersDict = new HashMap<String, String>();
        if (index == 1) {
            headersDict.put("S", "Номер кредита");
            headersDict.put("REASON", "Причина исключения кредита");
            headersDict.put("TOTAL_DAYS_OVERDUE", "Количество дней просрочки");
            headersDict.put("DATE_END_ORIG", "Срок кредита");
        } else if (index == 2) {
            headersDict.put("CLIENT", "Идентификационный номер клиента");
            headersDict.put("REASON", "Причина исключения клиента");
        }
        return headersDict;
    }
}
