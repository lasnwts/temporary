package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.uralsib.model.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ConvertService {

    public String convertToString(Map<String, Integer> limit, List<Object> data) throws NoSuchFieldException, IllegalAccessException {

        var updatedLimit = updateLimit(limit, data);
        return makeString(updatedLimit, data);
    }

    private Map<String, Integer> updateLimit(Map<String, Integer> limit, List<Object> data) {
        var properties = data.get(0).getClass().getDeclaredFields();
        for (var i = 0; i < properties.length; i++) {

            var name = properties[i].getName();
            var fieldValues = new ArrayList<String>();
            data.forEach(d -> {
                try {
                    fieldValues.add(d.getClass().getDeclaredField(name).get(d).toString());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });

            var max = getMaxLength(fieldValues);
            max = Math.max(max, name.length() + 1);

            if (limit.keySet().contains(name))
                max = Math.min(limit.get(name), max);

            limit.put(name, max);
        }

        return limit;
    }

    int getMaxLength(ArrayList<String> collection) {
        var maxLength = 0;
        for (var i = 0; i < collection.size(); i++) {
            var item = collection.get(i);

            if (item.length() > maxLength)
                maxLength = item.length();
        }
        return maxLength;
    }

    private String makeString(Map<String, Integer> limit, List<Object> data) throws NoSuchFieldException, IllegalAccessException {
        var stringBuilder = new StringBuilder();
        // header
        var properties = data.get(0).getClass().getDeclaredFields();
        for (var i = 0; i < properties.length; i++) {
            var name = properties[i].getName();
            if (name.equals("DEPART_FOR_CUT")) // Это поле не выводим
                continue;

            var countSkip = limit.get(name) - 1 - name.length();
            if (countSkip < 0)
                countSkip = 0;

            stringBuilder.append("<" + name + " ".repeat(countSkip) + ">");
        }
        stringBuilder.append("END_HEAD");
        // rows
        for (var i = 0; i < data.size(); i++) {
            var row = data.get(i);
            stringBuilder.append("\n");
            var propertiesRows = data.get(0).getClass().getDeclaredFields();
            for (var j = 0; j < propertiesRows.length; j++) {
                var name = propertiesRows[j].getName();
                if (name.equals("DEPART_FOR_CUT")) // Это поле не выводим
                    continue;

                var valueString = row.getClass().getDeclaredField(name).get(row).toString();

                var countSkip = limit.get(name) - valueString.length();
                if (countSkip >= 0)
                    stringBuilder.append(valueString + " ".repeat(countSkip + 1));
                else {
                    var skip = name.length() + 1 - limit.get(name);
                    if (skip < 0)
                        skip = 0;
                    stringBuilder.append(valueString.substring(0, limit.get(name)) + " ".repeat(skip + 1));
                }
            }
        }

        return stringBuilder.toString();
    }

    String getFormatedText(Object value, String name) {
        if (value == null)
            return "";

        if (value.getClass() == Timestamp.class)
            return new SimpleDateFormat("dd/MM/yyyy").format(value);

        if (name.equals("S")) {
            return "CITI_PL_" + value.toString();
        }

        if (name.equals("CLIENT")) {
            return "CITI_" + value.toString();
        }

        if (name.equals("PRC")) {
            var valueString = value.toString();
            return valueString.substring(1, 4) + "." + valueString.substring(4, 10);
        }

        if (name.equals("NUM")) {
            var valueString = value.toString();
            var length = valueString.length();
            return valueString.substring(length - 9, length - 2) + "." + valueString.substring(length - 2, length);
        }

        if (name.equals("INT")) {
            return value.toString().replace("+", "");
        }

        if (name.equals("DATE")) {
            return value.toString().replace('.', '/');
        }

        if (name.equals("DEPART")) {
            return value.toString().substring(0, 2);
        }

        if (name.equals("STR_NUM")) {
            return value.toString().replace(',', '.');
        }

        if (value.getClass() == Double.class)
            return String.format("%.2f",value).replace("\"", "").replace(',', '.');

        return value.toString();
    }

    public Map<String, String> getDepartDict() {
        var departDict = new HashMap<String, String>();
        departDict.put("00", "0-099"); // MOSCOW
        departDict.put("01", "0-022"); // ST.PETERSBURG
        departDict.put("03", "0-001"); // SAMARA
        departDict.put("04", "0-024"); // YEKATERINBURG
        departDict.put("05", "0-001"); // NIZHNIY NOVGOROD
        departDict.put("06", "0-047"); // ROSTOV
        departDict.put("07", "0-047"); // VOLGOGRAD
        departDict.put("08", "0-001"); // UFA
        departDict.put("09", "0-028");
        departDict.put("10", "0-032");
        return departDict;
    }

    public Map<String, String> getDepartForCutDict() {
        var departDict = new HashMap<String, String>();
        departDict.put("00", "099"); // MOSCOW
        departDict.put("01", "022"); // ST.PETERSBURG
        departDict.put("03", "001"); // SAMARA
        departDict.put("04", "024"); // YEKATERINBURG
        departDict.put("05", "001"); // NIZHNIY NOVGOROD
        departDict.put("06", "047"); // ROSTOV
        departDict.put("07", "047"); // VOLGOGRAD
        departDict.put("08", "001"); // UFA
        departDict.put("09", "028");
        departDict.put("10", "032");
        return departDict;
    }

//    public Dogov сreditToDogov(Credit credit) {
//        return new Dogov(
//                credit.getS(),
//                credit.getCLIENT(),
//                credit.getSYMBOL(),
//                credit.getNDOG_US(),
//                credit.getDEPART(),
//                credit.getDATE_BEG(),
//                credit.getDATE_END(),
//                credit.getSUM(),
//                credit.getSUM_VKP(),
//                credit.getSUM_VKP_PRC(),
//                credit.getSUM_VKP_DEB(),
//                credit.getSUM_VKP_PRC_DEB(),
//                credit.getSUM_VKP_PEN(),
//                credit.getDATE_BKI(),
//                credit.getDATE_OFFER(),
//                credit.getPSK_PRC(),
//                credit.getPSK(),
//                credit.getUID()
//        );
//    }
//
//    public Pparam сreditToPparam(Credit credit) {
//        return new Pparam(
//                credit.getS(),
//                credit.getVIDOPER(),
//                credit.getDAYPAY(),
//                credit.getDAYCALC(),
//                credit.getSUMPAY(),
//                credit.getDATE_CALC(),
//                credit.getDATE_PAY(),
//                credit.getDATE_END_PPARAM(),
//                credit.getOPER_COUNT(),
//                credit.getONLY_PRC(),
//                credit.getGASH_PAY_PERIOD(),
//                credit.getDEPART_FOR_CUT()
//        );
//    }
//
//    public PrcScheme сreditToPrcScheme(Credit credit) {
//        return new PrcScheme(
//                credit.getS(),
//                credit.getP_CODE(),
//                credit.getPRC(),
//                credit.getDATE_BEG_PRC_SCHEME(),
//                credit.getDATE_END_PRC_SCHEME(),
//                credit.getDEPART_FOR_CUT()
//        );
//    }
//
//    public Adds сreditToAdds(Credit credit) {
//        return new Adds(
//                credit.getS(),
//                credit.getDATE_BEG_ORIG(),
//                credit.getDATE_END_ORIG(),
//                credit.getDATE_END_ADDS(),
//                credit.getTOTAL_DAYS_OVERDUE(),
//                credit.getSUM_OVERDUE(),
//                credit.getNUM_PMTS_MADE(),
//                credit.getNUM_PMTS_REM(),
//                credit.getORIG_TERM(),
//                credit.getCURR_TERM(),
//                credit.getPRC_RATE_ORIG(),
//                credit.getPAY_DAY_ORIG(),
//                credit.getPRC_RATE_CURR(),
//                credit.getPAY_DAY_CURR(),
//                credit.getPAY_SUM_CURR(),
//                credit.getDATE_FIRST_PAY(),
//                credit.getDATE_LASTPAY_COMMIT(),
//                credit.getSUM_LASTPAY_COMMIT(),
//                credit.getDATE_NEXT_PAYMENT(),
//                credit.getSUM_NEXT_PAYMENT(),
//                credit.getHOLIDAY_TYPE(),
//                credit.getHOLIDAY_DATE_APPL(),
//                credit.getHOLIDAY_DATE_PROV(),
//                credit.getHOLIDAY_DATE_BEGIN(),
//                credit.getHOLIDAY_DATE_END_PLAN(),
//                credit.getHOLIDAY_DATE_END_FACT(),
//                credit.getHOLIDAY_END_REASON(),
//                credit.getHOLIDAY_DATE_TERM_APPL(),
//                credit.getAFTER_HOLIDAY_DATE_FIRST_PAY_FACT(),
//                credit.getHOLIDAY_DATE_FIRST_REAB_PAY(),
//                credit.getHOLIDAY_DATE_LAST_REAB_PAY(),
//                credit.getHOLIDAY_TYPE().isEmpty() ? "" : credit.getHOLIDAY_PRC_RATE(),
//                credit.getHOLIDAY_TYPE().isEmpty() ? "" : credit.getHOLIDAY_PRC_SUM_TOT(),
//                credit.getHOLIDAY_STATUS(),
//                credit.getAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN(),
//                credit.getDATE_END_BEFORE(),
//                credit.getDATE_END_ACTUAL(),
//                credit.getHOLIDAY_TYPE().isEmpty() ? "" : credit.getHOLIDAY_PRC_SUM_REM(),
//                credit.getDEPART_FOR_CUT()
//        );
//    }
}
