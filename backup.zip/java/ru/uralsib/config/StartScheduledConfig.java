package ru.uralsib.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author Petr Vershinin
 * create on 18.12.2022
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
@Transactional
public class StartScheduledConfig {

//    public static boolean printReportsEnabled = false;
//    public static boolean sendEnabled = false;
//    public static boolean printRejectionsEnabled = false;
//    public static boolean scanAgreementsEnabled = false;
//    public static boolean printAnniversaryEnabled = false;
//    public static boolean printRejectionsReportEnabled = false;
//    public static boolean printThroughReportEnabled = false;
//
//    private final ScanDirectoryService scanDirectoryService;
//    private final UnzipFilesService unzipFilesService;
//    private final ReportService reportService;
//    private final AgreementService agreementService;
//    private final RejectionsService rejectionsService;

    /**
     * Запускает процесс по расписанию,
     * <p>
     * https://www.ibm.com/docs/ru/urbancode-release/6.1.0?topic=interval-cron-expressions-defining-frequency
     */
//    @Scheduled(cron = "0 0/10 7-22 * * ?")//Каждые 10 минут c 7.00 до 22.00
//    public void printReports() throws IOException {
//        if (printReportsEnabled) {
//            log.info("Формирование отчетов запущено " + LocalDateTime.now());
//            reportService.printAllReports();
//        }
//    }
//
//    @Scheduled(cron = "0 0 0/3 * * ?")//Каждые 3 часа
//    public void startScanAgreements() throws IOException {
//        if (scanAgreementsEnabled) {
//            log.info("Процесс распаковки согласий запущен " + LocalDateTime.now());
//            var dateStart = new Timestamp(new Date().getTime());
//            scanDirectoryService.scanDirectory(dateStart, FileTypes.AGREEMENT);
//            unzipFilesService.extractZip(dateStart, FileTypes.AGREEMENT);
//        }
//    }

//    @Scheduled(cron = "0/9 * 7-22 * * ?") //Каждые 9 секунд c 7.00 до 22.00, чтобы обеспечить условие до 400 заявок в час
//    public void sendAgreement() throws IOException, JAXBException, ServiceException {
//        if (sendEnabled) {
//            agreementService.sendNextToCrif();
//        }
//    }
//
//    @Scheduled(cron = "0 0 22 * * MON-FRI")//в 22.00
//    public void printRejections() throws IOException {
//        if (printRejectionsEnabled) {
//            log.info("Формирование реестров отказов запущено " + LocalDateTime.now());
//            rejectionsService.print();
//        }
//    }

}

