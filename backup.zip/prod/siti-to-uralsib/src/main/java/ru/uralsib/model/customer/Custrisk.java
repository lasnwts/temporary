package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custrisk implements Serializable {

   public String GR_CLIENT;
   public String GR_DATE_START;
   public String GR_DATE_END;
   public String GR_ACC_FEATURE;
   public String GR_GROUP_NUM;
   public String GR_CRED_GROUP_NUM;
   public String GR_SERVICE_QUAL;
   public String GR_PRC_RESERV;
   public String GR_FIX;
   public String GR_PEOPLE;
   public String GR_RESUME;

}