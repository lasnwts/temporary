package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custacc implements Serializable {
   public String ACC_BANK_CLIENT;
   public String ACC_BANK_BIK;
   public String ACC_BANK_OPEN_DATE;
   public String ACC_BANK_CLOSE_DATE;
   public String ACC_BANK_NUMB;
}