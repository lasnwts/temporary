package ru.uralsib.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnloadBKI {
    //S; 1
    // TB_RELATIONSHIP;2
    // TB_TYPE;3
    // TB_LOANTYPECODE;4
    // TB_STARTAMOUOUTST;5
    // TB_CUROVERDUEDT_TA; 6
    // TB_MSPYMNTNXTRDT; 7
    // TB_MSPYMNTNTRSTDT; 8
    // TB_PASTDUEDAYS; 9
    // TB_PAIDPASTDUEDAYS; 10
    // TB_LASTAMOUNT_30PD; 11
    // TB_TTLAMOUNT24M30PD; 12
    // TB_DEBTRANGE; 13
    // TB_DEBTCALCDATE; 14
    // TB_INCOMEWAYTYPE; 15
    // TB_INCOMEINFOSOURCE;16
    // TB_COBORROWERSDEBT; 17
    // TB_STATESUPPORT; 18
    // TB_STATESUPPORTINFO; 19
    // TB_LOANPURPOSECODE; 20
    // TB_DATECONTRTERM 21


    public String S; //1
    public String TB_RELATIONSHIP; //2
    public String TB_TYPE; //3
    public String TB_LOANTYPECODE; //4
    public String TB_STARTAMOUOUTST; //5
    public String TB_CUROVERDUEDT_TA; //6
    public String TB_MSPYMNTNXTRDT; //7
    public String TB_MSPYMNTNTRSTDT; //8
    public String TB_PASTDUEDAYS; //9
    public String TB_PAIDPASTDUEDAYS; //10
    public String TB_LASTAMOUNT_30PD; //11
    public String TB_TTLAMOUNT24M30PD; //12
    public String TB_DEBTRANGE; //13
    public String TB_DEBTCALCDATE; //14
    public String TB_INCOMEWAYTYPE; //15
    public String TB_INCOMEINFOSOURCE; //16
    public String TB_COBORROWERSDEBT; //17
    public String TB_STATESUPPORT; //18
    public String TB_STATESUPPORTINFO; //19
    public String TB_LOANPURPOSECODE; //20
    public String TB_DATECONTRTERM; //21
    public String DEPART_FOR_CUT; //22
//    public String PROCESSED;

//    public UnloadBKI(String s, String TB_RELATIONSHIP, String TB_TYPE, String TB_LOANTYPECODE,
//                     String TB_STARTAMOUOUTST, String TB_CUROVERDUEDT_TA, String TB_MSPYMNTNXTRDT,
//                     String TB_MSPYMNTNTRSTDT, String TB_PASTDUEDAYS, String TB_PAIDPASTDUEDAYS,
//                     String TB_LASTAMOUNT_30PD, String TB_TTLAMOUNT24M30PD, String TB_DEBTRANGE,
//                     String TB_DEBTCALCDATE, String TB_INCOMEWAYTYPE, String TB_INCOMEINFOSOURCE,
//                     String TB_COBORROWERSDEBT, String TB_STATESUPPORT, String TB_STATESUPPORTINFO,
//                     String TB_LOANPURPOSECODE, String TB_DATECONTRTERM, String DEPART_FOR_CUT) {
//        S = s;
//        this.TB_RELATIONSHIP = TB_RELATIONSHIP;
//        this.TB_TYPE = TB_TYPE;
//        this.TB_LOANTYPECODE = TB_LOANTYPECODE;
//        this.TB_STARTAMOUOUTST = TB_STARTAMOUOUTST;
//        this.TB_CUROVERDUEDT_TA = TB_CUROVERDUEDT_TA;
//        this.TB_MSPYMNTNXTRDT = TB_MSPYMNTNXTRDT;
//        this.TB_MSPYMNTNTRSTDT = TB_MSPYMNTNTRSTDT;
//        this.TB_PASTDUEDAYS = TB_PASTDUEDAYS;
//        this.TB_PAIDPASTDUEDAYS = TB_PAIDPASTDUEDAYS;
//        this.TB_LASTAMOUNT_30PD = TB_LASTAMOUNT_30PD;
//        this.TB_TTLAMOUNT24M30PD = TB_TTLAMOUNT24M30PD;
//        this.TB_DEBTRANGE = TB_DEBTRANGE;
//        this.TB_DEBTCALCDATE = TB_DEBTCALCDATE;
//        this.TB_INCOMEWAYTYPE = TB_INCOMEWAYTYPE;
//        this.TB_INCOMEINFOSOURCE = TB_INCOMEINFOSOURCE;
//        this.TB_COBORROWERSDEBT = TB_COBORROWERSDEBT;
//        this.TB_STATESUPPORT = TB_STATESUPPORT;
//        this.TB_STATESUPPORTINFO = TB_STATESUPPORTINFO;
//        this.TB_LOANPURPOSECODE = TB_LOANPURPOSECODE;
//        this.TB_DATECONTRTERM = TB_DATECONTRTERM;
//        this.DEPART_FOR_CUT = DEPART_FOR_CUT;
//    }
}
