package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExcelService {

    public void printExcel(String filePath, String sheetName, List<Object> data) throws IOException {

        try (var wb = new HSSFWorkbook();) {
            var createHelper = wb.getCreationHelper();
            var sheet = wb.createSheet(sheetName);

            // header
            var headersDict = getHeadersDict();
            var rowHeader = sheet.createRow((short) 0);
            var properties = data.get(0).getClass().getDeclaredFields();
            for (var i = 0; i < properties.length; i++) {
                var header = properties[i].getName();
                if (headersDict.containsKey(header))
                    header = headersDict.get(header);
                rowHeader.createCell(i).setCellValue(createHelper.createRichTextString(header));
            }
            // rows
            for (var i = 0; i < data.size(); i++) {
                var row = data.get(i);
                var rowItem = sheet.createRow((short) i + 1);
                var propertiesRows = data.get(0).getClass().getDeclaredFields();
                for (var j = 0; j < propertiesRows.length; j++) {
                    var name = propertiesRows[j].getName();
                    var valueString = row.getClass().getDeclaredField(name).get(row).toString();
                    rowItem.createCell(j).setCellValue(createHelper.createRichTextString(valueString));
                }
            }

            // Write the output to a file
            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                autoSizeColumns(wb).write(fileOut);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    private HSSFWorkbook autoSizeColumns(HSSFWorkbook workbook) {
        for (var i = 0; i < workbook.getNumberOfSheets(); i++) {
            var sheet = workbook.getSheetAt(i);
            if (sheet.getPhysicalNumberOfRows() > 0) {
                var cellIterator = sheet.getRow(sheet.getFirstRowNum()).cellIterator();
                while (cellIterator.hasNext()) {
                    sheet.autoSizeColumn(cellIterator.next().getColumnIndex());
                }
            }
        }
        return workbook;
    }

    public Map<String, String> getHeadersDict() {
        var departDict = new HashMap<String, String>();
        departDict.put("S", "Номер кредита Ситибанк");
        departDict.put("REASON", "Причина исключения кредита из пула PL");
        departDict.put("TOTAL_DAYS_OVERDUE", "Количество дней просрочки");
        departDict.put("IS_RESTRUCT", "Наличие реструктуризации");
        departDict.put("TYPE_RESTRUCT", "Тип реструктуризации");
        departDict.put("DATE_END_RESTRUCT", "Дата окончания реструктуризации");
        departDict.put("DATE_BEG_ORIG", "Дата выдачи кредита (рефинансирование)");
        return departDict;
    }
}
