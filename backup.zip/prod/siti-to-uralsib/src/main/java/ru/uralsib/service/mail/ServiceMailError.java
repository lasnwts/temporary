package ru.uralsib.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.uralsib.config.Configure;
import ru.uralsib.config.LG;
import ru.uralsib.model.MessageError;


import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class ServiceMailError {

    public static final long MINUTE = 60000; // 1 минута

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ServiceMailError.class);

    private final MessageError messageError;
    private final Configure configure;
    private final EmailServiceImpl emailService;

    @Autowired
    public ServiceMailError(MessageError messageError, Configure configure, EmailServiceImpl emailService) {
        this.messageError = messageError;
        this.configure = configure;
        this.emailService = emailService;
    }

    /**
     * Проверка когда отправляли почту в последний раз
     *
     * @return -- true - можно отправлять письмо, false - еще не прошло время с последней отправки
     */
    public boolean checkMail() {
        if (messageError.getDate() == null) {
            logger.info("{}: Email error еще ни разу не отправлялся с момента запуска сервиса, можно отправлять.", LG.USBLOGINFO);
            return true;
        } else {
            String slog = "Email error был отправлен:" + getFormattedDate(messageError.getDate()) +
                    ", сейчас::"+getFormattedDate(new Date())+" что превысило время ожидания в минутах: "+ configure.getMailDelayMinutes();

            if (new Date().after(new Date(messageError.getDate().getTime() + configure.getMailDelayMinutes() * MINUTE))) {
                logger.info("{}:{},{}", LG.USBLOGINFO, slog, " - можно отправлять");
                return true;
            } else {
                logger.info("{}:{},{}", LG.USBLOGINFO, slog, " - отправлять нельзя!");
                return false;
            }
        }
    }

    /**
     * Отправка почтового сообщения администраторам
     *
     * @param body - тело сообщения
     */
    public void sendMailError(String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), body);
            messageError.setBody(body);
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(configure.getMailSubjects());
            messageError.setDate(new Date());
            logger.info("{} Отправлено письмо по адресам:{} Сообщение=:{}", LG.USBLOGINFO, configure.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailErrorSubject(String subject, String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(configure.getMailTo(), subject, body);
            messageError.setBody(getWnull(body));
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(getWnull(configure.getMailSubjects()));
            messageError.setDate(new Date());
            logger.info("{}: Отправлено письмо по адресам:{} Сообщение:{}", LG.USBLOGINFO, configure.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailSubject(String subject, String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(configure.getMailTo(), subject, body);
            messageError.setBody(getWnull(body));
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(getWnull(configure.getMailSubjects()));
            messageError.setDate(new Date());
            logger.info("{}:[sendMailSubject] Отправлено письмо по адресам:{} Сообщение:{}", LG.USBLOGINFO, configure.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailBusinessSubject(String subject, String body) {
        emailService.sendSimpleEmail(configure.getMailToBusiness(), subject, body);
        messageError.setBody(body);
        messageError.setCount(messageError.getCount() + 1);
        messageError.setSubject(configure.getMailSubjects());
        messageError.setDate(new Date());
        logger.info("{}: Отправлено письмо по адресам:{} Сообщение:{}", LG.USBLOGINFO, configure.getMailTo(), messageError);
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWnull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Преобразуем даты в строку
     *
     * @param date - дата
     * @return - строка с датой
     */
    private String getFormattedDate(Date date) {
        if (date == null) {
            logger.error("{}: [getFormattedDate] вместо date передан NULL", LG.USBLOGWARNING);
            return "";
        }
        try {
            return getWnull(sdf.format(date));
        } catch (Exception e) {
            logger.error("{}: [getFormattedDate] возникла ошибка при преобразовании даты в строку", LG.USBLOGWARNING);
            return "";
        }

    }
}
