package ru.uralsib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import ru.uralsib.dto.PlanallDto;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface RepoPlanall extends JpaRepository<PlanallDto, Long> {

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "5000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select d.id, d.S,d.dateo,d.DATE_BEG,d.DATE_END,d.OPER,d.SUM,d.CHANGE,d.VALUTA from tbank_PLANALL d where d.s in (select b.s from tbank_dogov b where b.s is not null and b.processed is null and b.depart like :depart)")
    Stream<PlanallDto> getFlowPlanall(@Param("depart") String depart);


    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "5000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select d.id, d.S,d.dateo,d.DATE_BEG,d.DATE_END,d.OPER,d.SUM,d.CHANGE,d.VALUTA from tbank_PLANALL d where d.s in (select s from tbank_dogov where processed is null and depart like :depart) and rownum < 100")
    List<PlanallDto> getListlanall(@Param("depart") String depart);




}
