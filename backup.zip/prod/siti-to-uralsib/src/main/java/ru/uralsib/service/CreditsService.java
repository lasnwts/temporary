package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.uralsib.model.*;
import ru.uralsib.service.flow.FlowFact;
import ru.uralsib.service.flow.FlowPlanall;
import ru.uralsib.service.s3.AmazonS3Service;
import ru.uralsib.utils.DepartMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CreditsService {
    private final GetJDBCDataService getJDBCDataService;
    private final ConvertService convertService;
    private final ExcelService excelService;
    private final CheckCreditsService checkCreditsService;
    private final CsvService csvService;
    private final AmazonS3Service s3Service;
    private final MailService mailService;
    private final DepartMapper departMapper;
    private final FlowPlanall flowPlanall;
    private final FlowFact flowFact;

    @Value("${file.delete:false}")
    private boolean deletedFile; //Удалять файлы после выгрузки

    /**
     * путь конечных файлов
     */
    private String folderCredits;


    public void printPrcScheme(List<PrcScheme> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных PrcScheme");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных prc_scheme" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("PRC", 10);
                saveInFile(dataObj, limit, folderCredits + "prc_scheme" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей prc_scheme - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printPparam(List<Pparam> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных pparam");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных pparam" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("VIDOPER", 25);
                saveInFile(dataObj, limit, folderCredits + "pparam" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей pparam - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printAdds(List<Adds> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных migr_info");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных migr_info" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                saveInFile(dataObj, limit, folderCredits + "migr_info" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей migr_info - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printDogov(List<Dogov> data) throws IOException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных Dogov");
            return;
        }

//        var decFormat = new DecimalFormat("#,0000000.00");
//        data.forEach(d -> {
//            var sumVkp = Double.parseDouble(d.getSUM_VKP()) - Double.parseDouble(d.getSUM_VKP_DEB());
//            d.setSUM_VKP(decFormat.format(sumVkp).replace(',', '.'));
//            var sumVkpPrc = Double.parseDouble(d.getSUM_VKP_PRC()) - Double.parseDouble(d.getSUM_VKP_PRC_DEB());
//            d.setSUM_VKP_PRC(decFormat.format(sumVkpPrc).replace(',', '.'));
//        });

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART().substring(2, 5).equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных Dogov" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("CLIENT", 25);
                saveInFile(dataObj, limit, folderCredits + "dogov" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей dogov - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printFailedCredit(List<FailedCredit> data) throws IOException {
        if (data == null || data.stream().count() == 0) {
            log.info("Нет исключенных кредитов");
        } else {
            var dataObj = new ArrayList<Object>();
            data.forEach(dataObj::add);
            excelService.printExcel(folderCredits + "ExcludedCredits.xls", "ExcludedCredits", dataObj);
        }
    }

    public void saveInFile(List<Object> dataObj, Map<String, Integer> limit, String fileName) throws IOException, NoSuchFieldException, IllegalAccessException {

        var strRes = convertService.convertToString(limit, dataObj);
        var file = new File(fileName);
        FileUtils.writeStringToFile(file, strRes, "cp866");
    }

    private Credit filterCredit(Credit credit, List<Credit> dataCredit) {
        if (credit.getHOLIDAY_TYPE().equals("09")) {
            var finalCredit = credit;
            var creditsOther09 = dataCredit.stream().filter(s -> s.getS().equals(finalCredit.getS()) &&
                    !s.getHOLIDAY_TYPE().equals("09")).collect(Collectors.toList());
            if (creditsOther09.isEmpty()) {
                credit.setHOLIDAY_TYPE("");
                credit.setHOLIDAY_DATE_APPL("");
                credit.setHOLIDAY_DATE_PROV("");
                credit.setHOLIDAY_DATE_BEGIN("");
                credit.setHOLIDAY_DATE_END_PLAN("");
                credit.setHOLIDAY_DATE_END_FACT("");
                credit.setHOLIDAY_END_REASON("");
                credit.setHOLIDAY_DATE_TERM_APPL("");
                credit.setAFTER_HOLIDAY_DATE_FIRST_PAY_FACT("");
                credit.setHOLIDAY_DATE_FIRST_REAB_PAY("");
                credit.setHOLIDAY_DATE_LAST_REAB_PAY("");
                credit.setHOLIDAY_PRC_RATE("");
                credit.setHOLIDAY_PRC_SUM_TOT("");
                credit.setHOLIDAY_STATUS("");
                credit.setAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN("");
                credit.setDATE_END_BEFORE("");
                credit.setDATE_END_ACTUAL("");
                credit.setHOLIDAY_PRC_SUM_REM("");
            } else return null;
        }
        return credit;
    }

    /**
     * Обработка данных по кредитам
     *
     * @throws IOException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    public void processingCredits() throws IOException, NoSuchFieldException, IllegalAccessException {

        System.gc();

        var failedCredits = checkCreditsService.checkCredits();

        folderCredits = this.getClass().getResource("/").getFile();

        if (failedCredits == null || failedCredits.size() == 0) {
            log.error("Нет данных об исключенных кредитах");
        } else {
            var dataObj = new ArrayList<Object>();
            failedCredits.forEach(dataObj::add);
            var datePrinted = Calendar.getInstance().getTime();
            var dateStrDay = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted);
            var dateStrTime = new SimpleDateFormat("HH.mm.ss").format(datePrinted);
            var fileName = "credit_exception" + "_" + dateStrDay + "T" + dateStrTime + ".csv";
            var file = csvService.printCsv(folderCredits + fileName, dataObj, 1);
            s3Service.uploadFile("Retail/Credits/Credit_Exceptions/" + fileName, file);
            Files.deleteIfExists(file.toPath());
            //FileUtils.delete(file);
//            mailService.sendMail("Не прошли проверку", "Микросервис: Intgr-credit-Retail\n" +
//                    "Описание ошибки: Кредиты не прошли проверку.\n" +
//                    "Ссылка на файл: https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/Credit_Exceptions/\n" + fileName);
            failedCredits.forEach(f -> {
                getJDBCDataService.updateFailedCredit(f);
            });
        }

        System.gc();

        log.info("Запускаем подготовку файлов по кредитам Get Dogov");
        var dogovToPrint = getJDBCDataService.getDogov();
        log.info("Получен список кредитов dogov в количестве:{}", dogovToPrint.size());

        if (dogovToPrint == null || dogovToPrint.size() == 0) {
            log.info("Нет данных о кредитах");
            return;
        }

        var datePrinted = Calendar.getInstance().getTime();
        var dateStr = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted) + "T" + new SimpleDateFormat("HH.mm.ss").format(datePrinted);
        var folderNameSt = "Retail/Credits/" + dateStr + "/";

        var departDict = convertService.getDepartForCutDict();

//        var factToPrint = getJDBCDataService.getFact();
//        var planallToPrint = new ArrayList<>();
//        var planallToPrint = getJDBCDataService.getPlanall();
//        var pparamToPrint = getJDBCDataService.getPparam();
//        var prc_schemeToPrint = getJDBCDataService.getPrcScheme();
//        var accbalanceToPrint = getJDBCDataService.getAccbalance();
//        var migr_infoToPrint = getJDBCDataService.getAdds();

        departDict.values().stream().distinct().forEach(d -> {
            try {

//                var dogovDepartData = dogovToPrint.stream().filter(s -> s.getDEPART().equals(d)).collect(Collectors.toList());
                log.info("Получаем данные по Dogov для depart={}", d);
                var dogovDepartData = getJDBCDataService.getDogovDepart(d); //Выбор по договорам
                if (dogovDepartData == null || dogovDepartData.size() == 0) {
                    log.info("Нет данных о кредитах " + d);
                    return;
                }
                log.info("Получено Dogov={} для depart={}", dogovDepartData.size(), d);
                var folderName = folderNameSt + d + "/";
                var dataObj = new ArrayList<Object>();
                var dataObjd = new ArrayList<Object>();
                dogovDepartData.forEach(dataObj::add);
                //Меняем DEPART на DEPART_TBANK
                dataObj.forEach(new Consumer<Object>() {
                    @Override
                    public void accept(Object o) {
                        try {
                            var dogov = (Dogov) o;
                            dataObjd.add(departMapper.getDepartChange((Dogov) o));
                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                    }
                });


                var fileName = "dogov" + d + "_" + dateStr + ".csv";
                var file = csvService.printCsv(folderCredits + fileName, dataObjd, 0);
                if (file != null) {
                    s3Service.uploadFile(folderName + fileName, file);
                    if (deletedFile) {
                        Files.deleteIfExists(file.toPath());
                        log.info("Удален файл " + file);
                    }
                }

                System.gc();


//                var pparamDepartData = pparamToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                log.info("Получаем данные по pparam для depart={}", d);
                var pparamDepartData = getJDBCDataService.getPparam(d);
                if (pparamDepartData == null || pparamDepartData.isEmpty()) {
                    log.error("Нет данных о pparam для depart={}", d);
                } else {
                    log.info("Получено pparam={} для depart={}", pparamDepartData.size(), d);
                    dataObj = new ArrayList<Object>();
                    pparamDepartData.forEach(dataObj::add);
                    fileName = "pparam" + d + "_" + dateStr + ".csv";
                    file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                    if (file != null) {
                        s3Service.uploadFile(folderName + fileName, file);
                        if (deletedFile) {
                            Files.deleteIfExists(file.toPath());
                            log.info("Удален файл pparamDepartData:{} ", file);
                        }
                    }
                }

                System.gc();

//                var prc_schemeDepartData = prc_schemeToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                log.info("Получаем данные по prc_scheme для depart={}", d);
                var prc_schemeDepartData = getJDBCDataService.getPrcScheme(d);
                if (prc_schemeDepartData == null || prc_schemeDepartData.isEmpty()) {
                    log.error("Нет данных о prc_scheme для depart={}", d);
                } else {
                    log.info("Получено prc_scheme={} для depart={}", prc_schemeDepartData.size(), d);
                    dataObj = new ArrayList<Object>();
                    prc_schemeDepartData.forEach(dataObj::add);
                    fileName = "prc_scheme" + d + "_" + dateStr + ".csv";
                    file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                    if (file != null) {
                        s3Service.uploadFile(folderName + fileName, file);
                        if (deletedFile) {
                            Files.deleteIfExists(file.toPath());
                            log.info("Удален файл " + file);
                        }
                    }
                }

                System.gc();

//                var accbalanceDepartData = accbalanceToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                log.info("Получаем данные по accbalance для depart={}", d);
                var accbalanceDepartData = getJDBCDataService.getAccbalance(d);
                if (accbalanceDepartData == null || accbalanceDepartData.isEmpty()) {
                    log.error("Нет данных о accbalance для depart={}", d);
                } else {
                    log.info("Получено accbalance={} для depart={}", accbalanceDepartData.size(), d);
                    dataObj = new ArrayList<Object>();
                    accbalanceDepartData.forEach(dataObj::add);
                    fileName = "accbalance" + d + "_" + dateStr + ".csv";
                    file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                    if (file != null) {
                        s3Service.uploadFile(folderName + fileName, file);
                        if (deletedFile) {
                            Files.deleteIfExists(file.toPath());
                            log.info("Удален файл,accbalance " + file);
                        }
                    }
                }

                System.gc();

//                var migr_infoDepartData = migr_infoToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                log.info("Получаем данные по migr_info для depart={}", d);
                var migr_infoDepartData = getJDBCDataService.getAdds(d);
                if (migr_infoDepartData == null || migr_infoDepartData.isEmpty()) {
                    log.error("Нет данных о migr_info для depart={}", d);
                } else {
                    log.info("Получено migr_info={} для depart={}", migr_infoDepartData.size(), d);
                    dataObj = new ArrayList<Object>();
                    migr_infoDepartData.forEach(dataObj::add);
                    fileName = "migr_info" + d + "_" + dateStr + ".csv";
                    file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                    if (file != null) {
                        s3Service.uploadFile(folderName + fileName, file);
                        if (deletedFile) {
                            Files.deleteIfExists(file.toPath());
                            log.info("Удален файл,migr_info " + file);
                        }
                    }
                }

                System.gc();


                log.info("Получаем данные по Planall для depart={}. Данные идут потоком, поэтому длину не подсчитать сразу.", d);
//                var planallDepartData = planallToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
//                var planallDepartData = getJDBCDataService.getPlanall(d);
//                dataObj = new ArrayList<Object>();
//                planallDepartData.forEach(dataObj::add);
                fileName = "planall" + d + "_" + dateStr + ".csv";
                file = flowPlanall.getFlowPlanall(fileName, d);
//                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null) {
                    log.info("Файл с данными по Planall для depart={} - сформирован Размер файла:{}", d, file.length());
                    s3Service.uploadFile(folderName + fileName, file);
                    //  FileUtils.delete(file);
                    if (deletedFile) {
                        Files.deleteIfExists(file.toPath());
                        log.info("Удален файл " + file);
                    }
                } else {
                    log.error("Файл с данными по Planall для depart={} не сформирован", d);
                }

                System.gc();

                log.info("Получаем данные по Fact для depart={}. Данные идут потоком, поэтому длину не подсчитать сразу.", d);
                //                //var factToPrint = getJDBCDataService.getFactTBank(d);
//                var factDepartData = getJDBCDataService.getFactTBank(d);
////                var factDepartData = factToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
//                dataObj = new ArrayList<Object>();
//                factDepartData.forEach(dataObj::add);
                fileName = "fact" + d + "_" + dateStr + ".csv";
                file = flowFact.getFlowFact(fileName, d);
//                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null) {
                    log.info("Файл с данными по Fact для depart={} - сформирован Размер файла:{}", d, file.length());
                    s3Service.uploadFile(folderName + fileName, file);
                    if (deletedFile) {
                        Files.deleteIfExists(file.toPath());
                        log.info("Удален файл factDepartData:" + file);
                    }
                } else {
                    log.error("Файл с данными по Fact для depart={} не сформирован", d);
                }

                System.gc();

            } catch (IOException e) {
                log.error("В процессе возникла ошибка: {}", e.getMessage());
                throw new RuntimeException(e);
            }
        });

        mailService.sendMail("Данные по кредитам обработаны", "Микросервис: Intgr-Credits-Retail\n" +
                "Данные по кредитам обработаны, записаны в https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/\n" + "_" + dateStr);
        log.info("Отправлено письмо на почту");
        log.info("Обновляем записи в таблице dogov");
        getJDBCDataService.updateListCredits(dogovToPrint, "Success"); //Обновляем записи
//        dogovToPrint.forEach(f -> {
//            getJDBCDataService.updateCredits(f.getS(), "Success");
//        });
    }
}
