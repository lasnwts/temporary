package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.uralsib.model.Credit;
import ru.uralsib.model.FailedCredit;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class CheckCreditsService {

    private final GetJDBCDataService getJDBCDataService;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    List<String> listRestruct = Arrays.asList(
            "04",
            "06",
            "08"
    );

    /**
     * Проверка кредитов
     * @return Коллекция кредитов, не прошедших проверку
     */
    public List<FailedCredit> checkCredits() {

        var failedCredits = new ArrayList<FailedCredit>();
        var failCreditsLog = new ArrayList<FailedCredit>();

        for (var i = 1; i <= 2; i++) {
            failCreditsLog.clear();
            failCreditsLog.addAll(getJDBCDataService.creditsCheck(i)) ;
            if (failCreditsLog.size() > 0){
                log.info("Ошибочных записей по кредитам в V_GET_FAILED_CREDITS_CHECK_" + i + " := " + failCreditsLog.size());
                log.info(" ------------------Список кредитов с данной ошибкой:{}---------------------", i);
                failCreditsLog.forEach(s -> log.info(s.toString()));
                log.info(" ------------------Конец списка кредитов с данной ошибкой:{}---------------------",i);
            }
            failedCredits.addAll(getJDBCDataService.creditsCheck(i)) ;
        }
        log.info("Всего записей по кредитам в V_GET_FAILED_CREDITS_CHECK := " + failedCredits.size());
        return failedCredits;
    }

    public FailedCredit checkCredit(Credit credit) {

        var excludeReason = "";
        if (checkUp1(credit))
            excludeReason += "Количество дней просрочки более 30 дней;";

        if (checkUp2(credit))
            excludeReason += "Наличие просрочки и реструктуризации;";

        if (checkUp3(credit, listRestruct))
            excludeReason += "Наличие действующей реструктуризации;";

        if (checkUp4(credit, listRestruct))
            excludeReason += "Льготный период каникул завершился менее 6 месяцев назад;";

        if (checkUp5(credit))
            excludeReason += "Рефинансирование выполнено менее 6 месяцев назад;";

        if (excludeReason.length() > 0)
            return new FailedCredit(
                    credit.getNDOG_US(),
                    excludeReason,
                    credit.getTOTAL_DAYS_OVERDUE(),
                    dateFormat.format(getMinDate(credit.getHOLIDAY_DATE_END_PLAN(), credit.getHOLIDAY_DATE_END_FACT(), dateFormat))
            );
        else
            return null;
    }

    private boolean checkUp1(Credit credit) {
        return Integer.parseInt(credit.getTOTAL_DAYS_OVERDUE()) > 30;
    }

    private boolean checkUp2(Credit credit) {
        return Integer.parseInt(credit.getTOTAL_DAYS_OVERDUE()) >= 1 && !credit.getHOLIDAY_TYPE().isEmpty();
    }

    private boolean checkUp3(Credit credit, List<String> listRestruct) {

        if (credit.getHOLIDAY_TYPE().isEmpty())
            return false;

        try {
            if (!listRestruct.contains(credit.getHOLIDAY_TYPE()))
                return false;

            if (!(credit.getHOLIDAY_STATUS().equals("01")))
                return false;

            var dateStart = dateFormat.parse(credit.getHOLIDAY_DATE_BEGIN());
            var dateBuy = dateFormat.parse(credit.getDATE_BEG());

            var dateEnd = getMinDate(credit.getHOLIDAY_DATE_END_PLAN(), credit.getHOLIDAY_DATE_END_FACT(), dateFormat);
            if (dateEnd == null)
                return false;

            return !dateEnd.before(dateBuy) && !dateBuy.before(dateStart);

        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }
    }

    private boolean checkUp4(Credit credit, List<String> listRestruct) {

        if (credit.getHOLIDAY_TYPE().isEmpty())
            return false;

        try {
            if (!listRestruct.contains(credit.getHOLIDAY_TYPE()))
                return false;

            var dateBuy = dateFormat.parse(credit.getDATE_BEG());

            var dateEnd = getMinDate(credit.getHOLIDAY_DATE_END_PLAN(), credit.getHOLIDAY_DATE_END_FACT(), dateFormat);
            if (dateEnd == null)
                return false;

            var dateDiff = getMonthsDifference(dateEnd, dateBuy);

            return (dateDiff <= 5);
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }
    }

    private boolean checkUp5(Credit credit) {

        if (credit.getHOLIDAY_TYPE().isEmpty())
            return false;

        try {
            if (!credit.getHOLIDAY_TYPE().equals("09"))
                return false;

            var dateBuy = dateFormat.parse(credit.getDATE_BEG());
            var dateStart = dateFormat.parse(credit.getDATE_BEG_ORIG());

            var dateDiff = getMonthsDifference(dateStart, dateBuy);

            return (dateDiff <= 5);
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }
    }

    private Date getMinDate(String date1, String date2, SimpleDateFormat dateFormat) {
        try {
            if (!date1.isEmpty() && !date2.isEmpty()) {
                var dateFirst = dateFormat.parse(date1);
                var dateSecond = dateFormat.parse(date2);
                return dateFirst.before(dateSecond) ? dateFirst : dateSecond;
            } else if (!date1.isEmpty()) {
                return dateFormat.parse(date1);
            } else if (!date2.isEmpty()) {
                return dateFormat.parse(date2);
            } else
                return null;
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    private static final int getMonthsDifference(Date dateStart, Date dateEnd) {
        var date1 = new GregorianCalendar();
        date1.setTime(dateStart);
        var date2 = new GregorianCalendar();
        date2.setTime(dateEnd);
        var m1 = date1.get(Calendar.YEAR) * 12 + date1.get(Calendar.MONTH);
        var m2 = date2.get(Calendar.YEAR) * 12 + date2.get(Calendar.MONTH);
        var mDiff = m2 - m1;
        if (mDiff > 0 && date2.get(Calendar.DAY_OF_MONTH) < date1.get(Calendar.DAY_OF_MONTH)) {
            mDiff--;
        }
        return mDiff;
    }
}
