package ru.uralsib;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.FileSystemResource;
import ru.uralsib.config.Configure;
import ru.uralsib.config.LG;
import ru.uralsib.dto.PlanallDto;
import ru.uralsib.repository.RepoPlanall;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@SpringBootApplication
public class CitiToUralsibApplication implements CommandLineRunner {

    private final Configure configure;

    @Autowired
    public CitiToUralsibApplication(Configure configure) {
        this.configure = configure;
    }

    private static final Logger logger = LoggerFactory.getLogger(CitiToUralsibApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitiToUralsibApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        /***
         * Проверка путей
         */
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));
        logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
        configure.setTempDirUploadFile(path.toString());
        logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


        logger.info("----------------------------------------------------------------------------------------------------------------------------------------------------------+");
        logger.info(" ПРОДУКТОВАЯ СХЕМА. TBANK_* ");
        logger.info("Name service                 : siti-to-uralsib. version:1.0.14");
        logger.info("-----------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
}
