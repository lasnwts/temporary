package ru.uralsib.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;

@Entity
public class FactDto {


    @Id
    @Column(name = "ID")
    public String ID;

    @Column(name = "S")
    public String S;

    @Column(name = "DATEO")
    public Date DATEO;

    @Column(name = "OPER")
    public String OPER;

    @Column(name = "SUM")
    public BigDecimal SUM;

    @Column(name = "VALUTA")
    public String VALUTA;

    public FactDto() {
        //
    }

    public FactDto(String ID, String S, Date DATEO, String OPER, BigDecimal SUM, String VALUTA) {
        this.ID = ID;
        this.S = S;
        this.DATEO = DATEO;
        this.OPER = OPER;
        this.SUM = SUM;
        this.VALUTA = VALUTA;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getS() {
        return S;
    }

    public void setS(String s) {
        S = s;
    }

    public Date getDATEO() {
        return DATEO;
    }

    public void setDATEO(Date DATEO) {
        this.DATEO = DATEO;
    }

    public String getOPER() {
        return OPER;
    }

    public void setOPER(String OPER) {
        this.OPER = OPER;
    }

    public BigDecimal getSUM() {
        return SUM;
    }

    public void setSUM(BigDecimal SUM) {
        this.SUM = SUM;
    }

    public String getVALUTA() {
        return VALUTA;
    }

    public void setVALUTA(String VALUTA) {
        this.VALUTA = VALUTA;
    }
}
