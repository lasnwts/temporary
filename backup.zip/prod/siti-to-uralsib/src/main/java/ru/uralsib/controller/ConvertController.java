package ru.uralsib.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.uralsib.service.*;

import java.io.IOException;

/**
 * @author Petr Vershinin
 * create on 15.11.2022
 */
@RestController
@RequiredArgsConstructor
@Api(value = "user", description = "Контроллер REST API " +
        "Формирование файлов по клиентам, кредитам и БКИ.", tags = "Rest API 2.(Файлы формируются в S3)")

public class ConvertController {
    private final GetJDBCDataService getJDBCDataService;
    private final CreateFileService createFileService;
    private final CreditsService creditsService;
    private final CustomersService customersService;
    private final BkiService bkiService;

    @GetMapping("/processingCredits")
    @ApiOperation(value = "Запуск процесса формирования файлов по кредитам",
            notes = "После завершения выполнения процесс, просто вернет true.",
            response = String.class)
    public boolean processingCredits() throws IOException, NoSuchFieldException, IllegalAccessException {
        creditsService.processingCredits();
        return true;
    }

    @GetMapping("/processingCustomers")
    @ApiOperation(value = "Запуск процесса формирования файлов по клиентам",
            notes = "После завершения выполнения процесс, просто вернет true.",
            response = String.class)
    public boolean processingCustomers() throws IOException, NoSuchFieldException, IllegalAccessException {
        customersService.processingCustomers();
        return true;
    }

    @GetMapping("/processingBki")
    @ApiOperation(value = "Запуск процесса формирования файлов по БКИ",
            notes = "После завершения выполнения процесс, просто вернет true.",
            response = String.class)
    public boolean processingBki() throws IOException, NoSuchFieldException, IllegalAccessException {
        bkiService.processingBki();
        return true;
    }
}
