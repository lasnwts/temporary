package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.uralsib.service.s3.AmazonS3Service;
import ru.uralsib.utils.DepartMapper;

import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class BkiService {
    private final GetJDBCDataService getJDBCDataService;
    private final ConvertService convertService;
    private final ExcelService excelService;
    private final CheckBkiService checkBkiService;
    private final CsvService csvService;
    private final AmazonS3Service s3Service;
    private final MailService mailService;
    private final DepartMapper departMapper;

    @Value("${file.delete:false}")
    private boolean deletedFile; //Удалять файлы после выгрузки

    /**
     * путь конечных файлов
     */
    private String folderCredits;

    /**
     * Обработка данных по кредитам
     *
     * @throws IOException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    public void processingBki() throws IOException, NoSuchFieldException, IllegalAccessException {

        var failedCredits = checkBkiService.checkCredits();

        folderCredits = this.getClass().getResource("/").getFile();

        if (failedCredits == null || failedCredits.isEmpty()) {
            log.error("Нет данных об исключенных БКИ кредитах");
        } else {
            var dataObj = new ArrayList<Object>();
            failedCredits.forEach(dataObj::add);
            var datePrinted = Calendar.getInstance().getTime();
            var dateStrDay = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted);
            var dateStrTime = new SimpleDateFormat("HH.mm.ss").format(datePrinted);
            var fileName = "bki_credit_exception" + "_" + dateStrDay + "T" + dateStrTime + ".csv";
            var file = csvService.printCsv(folderCredits + fileName, dataObj, 1);
            s3Service.uploadFile("Retail/Credits/Credit_Exceptions/" + fileName, file);
            FileUtils.delete(file);
            mailService.sendMail("Не прошли проверку", "Микросервис: Intgr-credit-Retail\n" +
                    "Описание ошибки: Кредиты не прошли проверку.\n" +
                    "Ссылка на файл: https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/Credit_Exceptions/\n" + fileName);
            failedCredits.forEach(f -> {
                getJDBCDataService.updateFailedBki(f);
            });
        }

        var datePrinted = Calendar.getInstance().getTime();
        var dateStr = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted) + "T" + new SimpleDateFormat("HH.mm.ss").format(datePrinted);
        var folderNameSt = "Retail/Credits/" + dateStr + "/";

        var departDict = convertService.getDepartForCutDict();

        var unloadBkiPrint = getJDBCDataService.getUnloadBki(); //Новый файл

        departDict.values().stream().distinct().forEach(d -> {
            try {
                var folderName = folderNameSt + d + "/";
                //Подготовка файла BKI
                //unload_BKI001_23.10.2024T09.20.30.csv
                var unloadBkiDepartData = unloadBkiPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                var dataObj = new ArrayList<Object>();
                unloadBkiDepartData.forEach(dataObj::add);
                var fileName = "unload_BKI" + d + "_" + dateStr + ".csv";
                var file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                    if (deletedFile){
                        Files.deleteIfExists(file.toPath());
                        log.info("Удален файл " + file);
                    }
                }
            } catch (IOException e) {
                log.error("В процессе возникла ошибка: {}", e.getMessage());
                throw new RuntimeException(e);
            }
        });

        mailService.sendMail("Данные по БКИ обработаны", "Микросервис: Intgr-Credits-Retail\n" +
                "Данные по БКИ обработаны, записаны в https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/\n" + "_" + dateStr);
        unloadBkiPrint.forEach(f -> {
            getJDBCDataService.updateBki(f.getS(), "Success");
        });
    }
}
