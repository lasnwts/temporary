package ru.uralsib.service.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.uralsib.config.Configure;
import ru.uralsib.config.LG;
import ru.uralsib.dto.PlanallDto;
import ru.uralsib.repository.RepoPlanall;
import ru.uralsib.utils.Support;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Stream;

@Service
public class FlowPlanall {

    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    private final RepoPlanall repoPlanall;
    private final EntityManager entityManager;
    private final Configure configure;
    private final Support support;

    String fullFileNameCSV;
    //Количество строк
    int lineCount;

    @Autowired
    public FlowPlanall(RepoPlanall repoPlanall, EntityManager entityManager, Configure configure, Support support) {
        this.repoPlanall = repoPlanall;
        this.entityManager = entityManager;
        this.configure = configure;
        this.support = support;
    }

    Logger logger = LoggerFactory.getLogger(FlowPlanall.class);


    public void start() {
        logger.info("Запуск FlowPlanall");
    }

    @Transactional(readOnly = true)
    public File getFlowPlanall(String fileName, String depart) {
        //Получаем список записей из базы
        Stream<PlanallDto> fTableStream = null;

        try {
            fTableStream = repoPlanall.getFlowPlanall(depart);
            if (fTableStream == null) {
                logger.error("{} fTableStream = repoPlanall.getFlowPlanall(depart) - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return null;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = repoPlanall.getFlowPlanall(depart)", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return null;
        }
        logger.info("{}:###################### < Starting the process Flow Plamall of unloading data from a table to a file > ##############################", LG.USBLOGINFO);
        lineCount = 0; //Обнулили счетчик записей, строк
        fullFileNameCSV = configure.getTempDirUploadFile() + File.separator + fileName; //Создаем файл во временной директории

        try {
            ru.uralsib.service.flow.FileWriter.write(fullFileNameCSV, support.getHeaderPlanall()); //Шапка
            fTableStream.forEach(fTable -> {
                logger.debug(fTable.toString());
                try {
                    ru.uralsib.service.flow.FileWriter.write(fullFileNameCSV,
                            fTable.getS() + ";" + getDate(fTable.getDATEO()) + ";" + getDate(fTable.getDATE_BEG()) + ";"
                                    + getDate(fTable.getDATE_END()) + ";" + getWrapNull(fTable.getOPER()) + ";" + getWrapNull(fTable.getCHANGE()) + ";" +
                                    getDoubles(fTable.getSUM()) + ";" + getWrapNull(fTable.getVALUTA()));
                } catch (IOException e) {
                    logger.error("Возникла ошибка при записи файла:{}, error:{}", fullFileNameCSV, e.getMessage());
                }
                lineCount = lineCount + 1; //Подсчитываем число записей в файле
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено записей:{}", LG.USBLOGINFO, lineCount);
            logger.info("{}:Output data in File ={}", LG.USBLOGINFO, fullFileNameCSV);
            return new File(fullFileNameCSV);
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", LG.USBLOGERROR);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл", LG.USBLOGERROR);
            logger.error("{}:!PrintStackTrace:", LG.USBLOGERROR, e);
            return null;
        } finally {
            fTableStream.close();
        }
    }


    /**
     * *
     * Получение даты в формате dd/MM/yyyy
     *
     * @param date - дата в формате Date
     * @return - дата в формате dd/MM/yyyy
     */
    private String getDate(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }


    /**
     * Получение числа с плавающей точкой в формате 0.00
     * @param value - число с плавающей точкой
     * @return - число с плавающей точкой в формате 0.00
     */
    private String getDoubles(BigDecimal value) {
        if (value == null) {
            return "";
        }
        return String.format("%.2f", value).replace("\"", "").replace(',', '.');
    }


    /**
     * Получение строки с null
     *
     * @param s - строка
     * @return - строка с null
     */
    private String getWrapNull(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s;
    }
}
