package ru.uralsib.utils;

import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class Support {

    public String getWrapNull(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s;
    }

    public String getSummaFormatter(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.replace(",", ".");
    }

    /**
     * Шапка файла
     * @return - строка с шапкой файла
     */
    public String getHeaderPlanall() {
        return "S;DATE;DATE_BEG;DATE_END;OPER;SUM;CHANGE;VALUTA";
    }

    /**
     * Шапка файла
     * @return - строка с шапкой файла
     */
    public String getHeaderFact() {
        return "S;DATE;OPER;SUM;VALUTA";
    }

}
