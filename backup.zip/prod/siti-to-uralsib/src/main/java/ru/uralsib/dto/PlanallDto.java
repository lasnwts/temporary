package ru.uralsib.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;

@Entity
public class PlanallDto {

    @Id
    @Column(name = "ID")
    public String ID;

    @Column(name = "S")
    public String S;

    @Column(name = "DATEO")
    public Date DATEO;

    @Column(name = "DATE_BEG")
    public Date DATE_BEG;

    @Column(name = "DATE_END")
    public Date DATE_END;

    @Column(name = "OPER")
    public String OPER;

    @Column(name = "SUM")
    public BigDecimal SUM;

    @Column(name = "CHANGE")
    public String CHANGE;

    @Column(name = "VALUTA")
    public String VALUTA;


    public PlanallDto() {
        //
    }


    public PlanallDto(String ID, String s, Date DATEO, Date DATE_BEG, Date DATE_END, String OPER, BigDecimal SUM, String CHANGE, String VALUTA) {
        this.ID = ID;
        S = s;
        this.DATEO = DATEO;
        this.DATE_BEG = DATE_BEG;
        this.DATE_END = DATE_END;
        this.OPER = OPER;
        this.SUM = SUM;
        this.CHANGE = CHANGE;
        this.VALUTA = VALUTA;
    }

    @Override
    public String toString() {
        return "PlanallDto{" +
                "ID='" + ID + '\'' +
                ", S='" + S + '\'' +
                ", DATE_BEG='" + DATE_BEG + '\'' +
                ", DATE_END='" + DATE_END + '\'' +
                ", OPER='" + OPER + '\'' +
                ", SUM='" + SUM + '\'' +
                ", CHANGE='" + CHANGE + '\'' +
                ", VALUTA='" + VALUTA + '\'' +
                '}';
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getS() {
        return S;
    }

    public void setS(String s) {
        S = s;
    }

    public Date getDATEO() {
        return DATEO;
    }

    public void setDATEO(Date DATEO) {
        this.DATEO = DATEO;
    }

    public Date getDATE_BEG() {
        return DATE_BEG;
    }

    public void setDATE_BEG(Date DATE_BEG) {
        this.DATE_BEG = DATE_BEG;
    }

    public Date getDATE_END() {
        return DATE_END;
    }

    public void setDATE_END(Date DATE_END) {
        this.DATE_END = DATE_END;
    }

    public String getOPER() {
        return OPER;
    }

    public void setOPER(String OPER) {
        this.OPER = OPER;
    }

    public BigDecimal getSUM() {
        return SUM;
    }

    public void setSUM(BigDecimal SUM) {
        this.SUM = SUM;
    }

    public String getCHANGE() {
        return CHANGE;
    }

    public void setCHANGE(String CHANGE) {
        this.CHANGE = CHANGE;
    }

    public String getVALUTA() {
        return VALUTA;
    }

    public void setVALUTA(String VALUTA) {
        this.VALUTA = VALUTA;
    }
}
