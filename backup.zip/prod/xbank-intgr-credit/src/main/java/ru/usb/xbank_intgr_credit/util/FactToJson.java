package ru.usb.xbank_intgr_credit.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Fact;

@Component
public class FactToJson {

    private static final Logger log = LoggerFactory.getLogger(FactToJson.class);
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Получение документа в виде Json строки
     * @param document - Pack
     * @return - Json строка
     */
    public String getJson(Fact document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [Fact] == NULL!", LG.USBLOGERROR);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа Fact :{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Fact:", LG.USBLOGERROR, e);
            return null;
        }
    }
}
