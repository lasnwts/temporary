package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.dto.UnloadBki;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckUnloadBki;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.UnloadBkiPosition;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class UnloadBkiMapper {
    private final Configure configure;

    @Autowired
    public UnloadBkiMapper(Configure configure) {
        this.configure = configure;
    }

    public CheckUnloadBki map(String line, UnloadBkiPosition unloadBkiPosition, String fileName, long numInsert, int lineNumber, long maxId) {
        String[] values = line.split(configure.getCsvDelimiter());
        boolean checkSexist = false; //флаг проверки наличия обязательного параметра

        //Пустая срока
        if (values.length < 2) {
            return new CheckUnloadBki(new UnloadBki(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        LoadError loadError = new LoadError();
        loadError.setFileName(configure.getArchiveName());  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        UnloadBki unloadBki = new UnloadBki();
        //Константы
        unloadBki.setFileName(configure.getArchiveName());  //имя файла
        unloadBki.setNumInsert(numInsert);
        unloadBki.setInputDate(new Date());

        unloadBki.setId(maxId + lineNumber); //Присваиваем номер записи

        try {//2
            if (unloadBkiPosition.getS() > -1) {
                unloadBki.setS(values[unloadBkiPosition.getS()]);
                //Проверка на ссылку договора
                if (!values[unloadBkiPosition.getS()].trim().isEmpty()){
                    checkSexist = true;
                }
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:S: {}", LG.USBLOGERROR, e.getMessage());
        }

        try { //3
            if (unloadBkiPosition.getTbRelationship() > -1 && checkInt(values[unloadBkiPosition.getTbRelationship()])) {
                unloadBki.setTbRelationship(parseInt(values[unloadBkiPosition.getTbRelationship()]));
            } else {
                setLoadError("Не найден обязательный параметр:TB_RELATIONSHIP", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_RELATIONSHIP" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_RELATIONSHIP: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//4
            if (unloadBkiPosition.getTbType() > -1 && checkInt(values[unloadBkiPosition.getTbType()])) {
                unloadBki.setTbType(values[unloadBkiPosition.getTbType()]);
            } else {
                unloadBki.setTbType(null);
                //setLoadError("Не найден обязательный параметр:TB_TYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_TYPE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_TYPE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//5
            if (unloadBkiPosition.getTbLoanTypeCode() > -1 && checkInt(values[unloadBkiPosition.getTbLoanTypeCode()])) {
                unloadBki.setTbLoanTypeCode(values[unloadBkiPosition.getTbLoanTypeCode()]);
            } else {
                unloadBki.setTbLoanTypeCode(null);
                //setLoadError("Не найден обязательный параметр:TB_LOANTYPECODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_LOANTYPECODE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_LOANTYPECODE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//6
            if (unloadBkiPosition.getTbStartAmouOutst() > -1 && checkDecimalBool(values[unloadBkiPosition.getTbStartAmouOutst()])) {
                unloadBki.setTbStartAmouOutst(parseDecimal(values[unloadBkiPosition.getTbStartAmouOutst()]));
            } else {
                setLoadError("Не найден обязательный параметр:TB_STARTAMOUOUTST", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_STARTAMOUOUTST" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_STARTAMOUOUTST: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//7
            if (unloadBkiPosition.getTbCuroverdueDtTa() > -1 && checkDateLine(values[unloadBkiPosition.getTbCuroverdueDtTa()])) {
                unloadBki.setTbCuroverdueDtTa(convertDateToSqlDate(parseDateLine(values[unloadBkiPosition.getTbCuroverdueDtTa()])));
            } else {
                setLoadError("Не найден обязательный параметр:TB_CUROVERDUEDT_TA", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_CUROVERDUEDT_TA" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_CUROVERDUEDT_TA: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//8
            if (unloadBkiPosition.getTbMspymntNxtrdt() > -1 && checkDateLine(values[unloadBkiPosition.getTbMspymntNxtrdt()])) {
                unloadBki.setTbMsPymntNxtrDt(convertDateToSqlDate(parseDateLine(values[unloadBkiPosition.getTbMspymntNxtrdt()])));
            } else {
                setLoadError("Не найден обязательный параметр:TB_MSPYMNTNXTRDT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_MSPYMNTNXTRDT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_MSPYMNTNXTRDT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//9
            if (unloadBkiPosition.getTbMspymntNtrstdt() > -1 && checkDateLine(values[unloadBkiPosition.getTbMspymntNtrstdt()])) {
                unloadBki.setTbMsPymntNtrstDt(convertDateToSqlDate(parseDateLine(values[unloadBkiPosition.getTbMspymntNtrstdt()])));
            } else {
                setLoadError("Не найден обязательный параметр:TB_MSPYMNTNTRSTDT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_MSPYMNTNTRSTDT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_MSPYMNTNTRSTDT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//10
            if (unloadBkiPosition.getTbPastDueDays() > -1 && checkInt(values[unloadBkiPosition.getTbPastDueDays()])) {
                unloadBki.setTbPastDueDays(values[unloadBkiPosition.getTbPastDueDays()]);
            } else {
                unloadBki.setTbPastDueDays(null);
                //setLoadError("Не найден обязательный параметр:TB_PASTDUEDAYS", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_PASTDUEDAYS" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_PASTDUEDAYS: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//11
            if (unloadBkiPosition.getTbPaidPastDueDays() > -1 && checkInt(values[unloadBkiPosition.getTbPaidPastDueDays()])) {
                unloadBki.setTbPaidPastDueDays(values[unloadBkiPosition.getTbPaidPastDueDays()]);
            } else {
                unloadBki.setTbPaidPastDueDays(null);
                //setLoadError("Не найден обязательный параметр:TB_PAIDPASTDUEDAYS", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_PAIDPASTDUEDAYS" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_PAIDPASTDUEDAYS: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//12
            if (unloadBkiPosition.getTbLastAmount30Pd() > -1 && checkDecimalBool(values[unloadBkiPosition.getTbLastAmount30Pd()])) {
                unloadBki.setTbLastAmount30Pd(parseDecimal(values[unloadBkiPosition.getTbLastAmount30Pd()]));
            } else {
                setLoadError("Не найден обязательный параметр:TB_LASTAMOUNT_30PD", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_LASTAMOUNT_30PD" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_LASTAMOUNT_30PD: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//13
            if (unloadBkiPosition.getTbTtlAmount24m30Pd() > -1 && checkDecimalBool(values[unloadBkiPosition.getTbTtlAmount24m30Pd()])) {
                unloadBki.setTbTtlAmount24m30Pd(parseDecimal(values[unloadBkiPosition.getTbTtlAmount24m30Pd()]));
            } else {
                setLoadError("Не найден обязательный параметр:TB_TTLAMOUNT24M30PD", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_TTLAMOUNT24M30PD" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_TTLAMOUNT24M30PD: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//14
            if (unloadBkiPosition.getTbDebtRange() > -1 && checkInt(values[unloadBkiPosition.getTbDebtRange()])) {
                unloadBki.setTbDebtRange(values[unloadBkiPosition.getTbDebtRange()]);
            } else {
                unloadBki.setTbDebtRange(null);
                //setLoadError("Не найден обязательный параметр:TB_DEBTRANGE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_DEBTRANGE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_DEBTRANGE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//15
            if (unloadBkiPosition.getTbDebtCalcDate() > -1 && checkDateLine(values[unloadBkiPosition.getTbDebtCalcDate()])) {
                unloadBki.setTbDebtCalcDate(convertDateToSqlDate(parseDateLine(values[unloadBkiPosition.getTbDebtCalcDate()])));
            } else {
                setLoadError("Не найден обязательный параметр:TB_DEBTCALCDATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_DEBTCALCDATE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_DEBTCALCDATE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//16
            if (unloadBkiPosition.getTbIncomeWayType() > -1 && checkInt(values[unloadBkiPosition.getTbIncomeWayType()])) {
                unloadBki.setTbIncomeWayType(values[unloadBkiPosition.getTbIncomeWayType()]);
            } else {
                unloadBki.setTbIncomeWayType(null);
                //setLoadError("Не найден обязательный параметр:TB_INCOMEWAYTYPE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_INCOMEWAYTYPE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_INCOMEWAYTYPE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//17
            if (unloadBkiPosition.getTbIncomeInfoSource() > -1 && checkInt(values[unloadBkiPosition.getTbIncomeInfoSource()])) {
                unloadBki.setTbIncomeInfoSource(values[unloadBkiPosition.getTbIncomeInfoSource()]);
            } else {
                unloadBki.setTbIncomeInfoSource(null);
                //setLoadError("Не найден обязательный параметр:TB_INCOMEINFOSOURCE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_INCOMEINFOSOURCE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_INCOMEINFOSOURCE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//18
            if (unloadBkiPosition.getTbCoborrowersDebt() > -1 && checkInt(values[unloadBkiPosition.getTbCoborrowersDebt()])) {
                unloadBki.setTbCoborrowersDebt(values[unloadBkiPosition.getTbCoborrowersDebt()]);
            } else {
                unloadBki.setTbCoborrowersDebt(null);
                //setLoadError("Не найден обязательный параметр:TB_COBORROWERSDEBT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_COBORROWERSDEBT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_COBORROWERSDEBT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//19 tbStateSupport
            if (unloadBkiPosition.getTbStateSupport() > -1 && checkInt(values[unloadBkiPosition.getTbStateSupport()])) {
                unloadBki.setTbStateSupport(values[unloadBkiPosition.getTbStateSupport()]);
            } else {
                unloadBki.setTbStateSupport(null);
                //setLoadError("Не найден обязательный параметр:TB_STATESUPPORT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_STATESUPPORT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_STATESUPPORT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//20
            if (unloadBkiPosition.getTbStateSupportInfo() > -1) {
                unloadBki.setTbStateSupportInfo(values[unloadBkiPosition.getTbStateSupportInfo()]);
            } else {
                setLoadError("Не найден обязательный параметр:TB_STATE_SUPPORT_INFO", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_STATE_SUPPORT_INFO" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_STATE_SUPPORT_INFO: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {//21
            if (unloadBkiPosition.getTbLoanPurposeCode() > -1) {
                unloadBki.setTbLoanPurposeCode(values[unloadBkiPosition.getTbLoanPurposeCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:TB_LOANPURPOSECODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_LOANPURPOSECODE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_LOANPURPOSECODE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }
        if (!checkSexist) {
            log.error("{}:T{}: Ошибка в записи:{} - нет S, е будет загружена!", LG.USBLOGERROR, Thread.currentThread().getId(), unloadBki);
        }

        try {//22
            if (unloadBkiPosition.getTbDateContrTerm() > -1 && checkDateLine(values[unloadBkiPosition.getTbDateContrTerm()])) {
                unloadBki.setTbDateContrTerm(convertDateToSqlDate(parseDateLine(values[unloadBkiPosition.getTbDateContrTerm()])));
            } else {
                setLoadError("Не найден обязательный параметр:TB_DATECONTRTERM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TB_DATECONTRTERM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TB_DATECONTRTERM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }
        if (!checkSexist) {
            log.error("{}:T{}: Ошибка в записи:{} - нет S, е будет загружена!", LG.USBLOGERROR, Thread.currentThread().getId(), unloadBki);
        }
        return new CheckUnloadBki(unloadBki, loadError, checkSexist);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        if (date.contains(".")){
            date = date.replace(".", "/");
        }
        if (date.contains("-")){
            date = date.replace("-", "/");
        }

        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            if (date.contains(".")){
                date = date.replace(".", "/");
            }
            if (date.contains("-")){
                date = date.replace("-", "/");
            }

            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

}
