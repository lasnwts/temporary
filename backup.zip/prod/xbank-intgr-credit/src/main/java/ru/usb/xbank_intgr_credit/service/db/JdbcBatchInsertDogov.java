package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.Dogov;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchInsertDogov {

    /**
     *
     * 	"CLIENT" VARCHAR2(255 CHAR), 1
     * 	"NDOG_US" VARCHAR2(255 CHAR), 2
     * 	"DATE_BEG" DATE, 3
     * 	"DATE_BKI" DATE, 4
     * 	"DATE_END" DATE, 5
     * 	"DATE_OFFER" DATE, 6
     * 	"DEPART" VARCHAR2(255 CHAR), 7
     * 	"PSK" NUMBER(19,2), 8
     * 	"PSK_BEG" NUMBER(19,2 ), 9
     * 	"PSK_PRC" NUMBER(19,2), 10
     * 	"PSK_PRC_BEG" NUMBER(19,2), 11
     * 	"SUM" NUMBER(19,2), 12
     * 	"SUM_VKP" NUMBER(19,2), 13
     * 	"SUM_VKP_DEB" NUMBER(19,2), 14
     * 	"SUM_VKP_PEN" NUMBER(19,2), 15
     * 	"SUM_VKP_PRC" NUMBER(19,2), 16
     * 	"SUM_VKP_PRC_DEB" NUMBER(19,2), 17
     * 	"SYMBOL" VARCHAR2(255 CHAR), 18
     * 	"UUID" VARCHAR2(255 CHAR), 19
     * 	"PDN" NUMBER(19,2), 20
     * 	"SUMM_PDN" NUMBER(19,2), 21
     * 	"DEPART_TBANK" VARCHAR2(255 CHAR), 22
     * 	"S" VARCHAR2(255 CHAR), 23
     * 	"FILENAME" VARCHAR2(255 CHAR), 24
     * 	"INPUT_DATE" TIMESTAMP (6), 25
     * 	"NUMINSERT" NUMBER(19,0), 26
     * 	"ID" NUMBER(19,0) NOT NULL ENABLE, 27
     */


    Logger log = LoggerFactory.getLogger(JdbcBatchInsertDogov.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchInsertDogov(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    private static final String INSERT_TO_DOGOV = "INSERT INTO TBANK_DOGOV (CLIENT, NDOG_US,DATE_BEG,DATE_BKI,DATE_END,DATE_OFFER,DEPART,PSK,PSK_BEG,PSK_PRC,PSK_PRC_BEG,SUM,SUM_VKP,SUM_VKP_DEB,SUM_VKP_PEN,SUM_VKP_PRC,SUM_VKP_PRC_DEB,SYMBOL,UUID,PDN,SUMM_PDN,DEPART_TBANK,S,FILENAME,INPUT_DATE,NUMINSERT,ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


    public void save(List<Dogov> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_DOGOV);


            // ,,,,,S,FILENAME,INPUT_DATE,NUMINSERT,ID

            for (Dogov currentRecord : entities) {
                insertStatement.setString(1, currentRecord.getClient()); //CLIENT
                insertStatement.setString(2, currentRecord.getNdogUs()); //NDOG_US
                insertStatement.setDate(3, currentRecord.getDateBeg()); //DATE_BEG
                insertStatement.setDate(4, currentRecord.getDateBki()); //DATE_BKI
                insertStatement.setDate(5, currentRecord.getDateEnd()); //DATE_END
                insertStatement.setDate(6, currentRecord.getDateOffer()); //DATE_OFFER
                insertStatement.setString(7, currentRecord.getDepart()); //DEPART
                insertStatement.setBigDecimal(8, currentRecord.getPsk());//PSK

                insertStatement.setBigDecimal(9, currentRecord.getPskBeg());//PSK_BEG
                insertStatement.setBigDecimal(10, currentRecord.getPskPrc());//PSK_PRC
                insertStatement.setBigDecimal(11, currentRecord.getPskPrcBeg());//PSK_PRC_BEG
                insertStatement.setBigDecimal(12, currentRecord.getSum());//SUM
                insertStatement.setBigDecimal(13, currentRecord.getSumVkp());//SUM_VKP
                insertStatement.setBigDecimal(14, currentRecord.getSumVkpDeb());//SUM_VKP_DEB
                insertStatement.setBigDecimal(15, currentRecord.getSumVkpPen());//SUM_VKP_PEN
                insertStatement.setBigDecimal(16, currentRecord.getSumVkpPrc());//SUM_VKP_PRC
                insertStatement.setBigDecimal(17, currentRecord.getSumVkpPrcDeb());//SUM_VKP_PRC_DEB

                insertStatement.setString(18, currentRecord.getSymbol());//SYMBOL
                insertStatement.setString(19, currentRecord.getUid());//UUID

                insertStatement.setBigDecimal(20, currentRecord.getPdn());//PDN
                insertStatement.setBigDecimal(21, currentRecord.getSummPdn());//SUMM_PDN

                insertStatement.setString(22, currentRecord.getDepart());//DEPART_TBANK

                insertStatement.setString(23, currentRecord.getS());//S
                insertStatement.setString(24, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(25, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(26, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setLong(27, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }

}
