package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.UnloadBki;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchUnloadBki {

    /**
     TB_COBORROWERSDEBT, 1
     TB_CUROVERDUEDT_TA, 2
     TB_DATECONTRTERM, 3
     TB_DEBTCALCDATE, 4
     TB_DEBTRANGE, 5
     TB_INCOMEINFOSOURCE, 6
     TB_INCOMEWAYTYPE, 7
     TB_LASTAMOUNT_30PD, 8
     TB_LOANPURPOSECODE, 9
     TB_LOANTYPECODE, 10
     TB_MSPYMNTNTRSTDT, 11
     TB_MSPYMNTNXTRDT, 12
     TB_PAIDPASTDUEDAYS, 13
     TB_PASTDUEDAYS, 14
     TB_RELATIONSHIP,  15
     TB_STARTAMOUOUTST, 16
     TB_STATESUPPORT, 17
     TB_STATESUPPORTINFO,  18
     TB_TTLAMOUNT24M30PD, 19
     TB_TYPE, 20
     S,  21
     FILENAME,  22
     INPUT_DATE,  23
     NUMINSERT,  24
     ID 25
     */

    Logger log = LoggerFactory.getLogger(JdbcBatchUnloadBki.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchUnloadBki(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }


    private static final String INSERT_TO_UNLOAD_BKI = "INSERT INTO TBANK_UNLOAD_BKI (TB_COBORROWERSDEBT, TB_CUROVERDUEDT_TA,TB_DATECONTRTERM,TB_DEBTCALCDATE,TB_DEBTRANGE,TB_INCOMEINFOSOURCE,TB_INCOMEWAYTYPE,TB_LASTAMOUNT_30PD,TB_LOANPURPOSECODE,TB_LOANTYPECODE,TB_MSPYMNTNTRSTDT,TB_MSPYMNTNXTRDT,TB_PAIDPASTDUEDAYS,TB_PASTDUEDAYS,TB_RELATIONSHIP, TB_STARTAMOUOUTST,TB_STATESUPPORT,TB_STATESUPPORTINFO, TB_TTLAMOUNT24M30PD,TB_TYPE,S,FILENAME,INPUT_DATE,NUMINSERT,ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


    public void save(List<UnloadBki> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_UNLOAD_BKI);

            for (UnloadBki currentRecord : entities) {
                insertStatement.setString(1, currentRecord.getTbCoborrowersDebt()); //TB_COBORROWERSDEBT

                insertStatement.setDate(2, currentRecord.getTbCuroverdueDtTa()); //TB_CUROVERDUEDT_TA
                insertStatement.setDate(3, currentRecord.getTbDateContrTerm()); //TB_DATECONTRTERM
                insertStatement.setDate(4, currentRecord.getTbDebtCalcDate()); //TB_DEBTCALCDATE

                insertStatement.setString(5, currentRecord.getTbDebtRange()); //TB_DEBTRANGE
                insertStatement.setString(6, currentRecord.getTbIncomeInfoSource()); //TB_INCOMEINFOSOURCE
                insertStatement.setString(7, currentRecord.getTbIncomeWayType()); //TB_INCOMEWAYTYPE

                insertStatement.setBigDecimal(8, currentRecord.getTbLastAmount30Pd());//TB_LASTAMOUNT_30PD

                insertStatement.setString(9, currentRecord.getTbLoanPurposeCode()); //TB_LOANPURPOSECODE
                insertStatement.setString(10, currentRecord.getTbLoanTypeCode()); //TB_LOANTYPECODE

                insertStatement.setDate(11, currentRecord.getTbMsPymntNtrstDt()); //TB_MSPYMNTNTRSTDT
                insertStatement.setDate(12, currentRecord.getTbMsPymntNxtrDt()); //TB_MSPYMNTNXTRDT

                insertStatement.setString(13, currentRecord.getTbPaidPastDueDays()); //TB_PAIDPASTDUEDAYS
                insertStatement.setString(14, currentRecord.getTbPastDueDays()); //TB_PASTDUEDAYS

                insertStatement.setInt(15, currentRecord.getTbRelationship());//TB_RELATIONSHIP

                insertStatement.setBigDecimal(16, currentRecord.getTbStartAmouOutst());//TB_STARTAMOUOUTST

                insertStatement.setString(17, currentRecord.getTbStateSupport()); //TB_STATESUPPORT
                insertStatement.setString(18, currentRecord.getTbStateSupportInfo()); //TB_STATESUPPORTINFO

                insertStatement.setBigDecimal(19, currentRecord.getTbTtlAmount24m30Pd());//TB_TTLAMOUNT24M30PD

                insertStatement.setString(20, currentRecord.getTbType()); //TB_TYPE

                insertStatement.setString(21, currentRecord.getS());//S
                insertStatement.setString(22, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(23, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(24, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setLong(25, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }


}
