package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.Pparam;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchPParam {

    /**
     * "ID" NUMBER(19,0) NOT NULL ENABLE,
     * 	"DATE_CALC" DATE, //1
     * 	"DATE_END" DATE, //2
     * 	"DATE_PAY" DATE, //3
     * 	"DAYCALC" NUMBER(10,0), //4
     * 	"DAYPAY" NUMBER(10,0), //5
     * 	GASH_PAY_PERIOD" NUMBER(10,0), //6
     * 	"FILENAME" VARCHAR2(255 CHAR),  //7
     * 	"INPUT_DATE" TIMESTAMP (6), //8
     * 	"NUMINSERT" NUMBER(19,0), //9
     * 	"ONLY_PRC" NUMBER(10,0), //10
     * 	"OPER_COUNT" NUMBER(10,0), //11
     * 	"S" VARCHAR2(255 CHAR), //12
     * 	"SUMPAY" NUMBER(19,2), //13
     * 	"VIDOPER" VARCHAR2(255 CHAR), //14
     */


    Logger log = LoggerFactory.getLogger(JdbcBatchPParam.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchPParam(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    private static final String INSERT_TO_PPARAM = "INSERT INTO TBANK_PPARAM (DATE_CALC, DATE_END, DATE_PAY," +
            "DAYCALC,DAYPAY,GASH_PAY_PERIOD,FILENAME,INPUT_DATE,NUMINSERT,ONLY_PRC,OPER_COUNT,S,SUMPAY,VIDOPER, ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?, ?, ?, ?)";


    public void save(List<Pparam> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_PPARAM);

            for (Pparam currentRecord : entities) {
                insertStatement.setDate(1, currentRecord.getDateCalc()); //DATE_CALC
                insertStatement.setDate(2, currentRecord.getDateEnd()); //DATE_END
                insertStatement.setDate(3, currentRecord.getDatePay()); //DATE_PAY
                insertStatement.setString(4, currentRecord.getDaycalc()); //DAYCALC
                insertStatement.setString(5, currentRecord.getDaypay()); //DAYPAY
                insertStatement.setString(6, currentRecord.getGashPayPeriod()); //GASH_PAY_PERIOD
                insertStatement.setString(7, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(9, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setString(10, currentRecord.getOnlyPrc());//ONLY_PRC
                insertStatement.setString(11, currentRecord.getOperCount());//OPER_COUNT
                insertStatement.setString(12, currentRecord.getS());//S
                insertStatement.setBigDecimal(13, currentRecord.getSumpay());//SUMPAY
                insertStatement.setString(14, currentRecord.getVidoper());//VIDOPER
                insertStatement.setLong(15, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }

}
