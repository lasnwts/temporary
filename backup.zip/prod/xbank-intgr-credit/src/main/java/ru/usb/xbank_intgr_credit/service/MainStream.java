package ru.usb.xbank_intgr_credit.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.db.FtpsFile;
import ru.usb.xbank_intgr_credit.model.db.FtpsResponse;
import ru.usb.xbank_intgr_credit.model.db.TBankHistoryArchives;
import ru.usb.xbank_intgr_credit.model.db.TBankRunHistory;
import ru.usb.xbank_intgr_credit.service.db.ApiLayerDB;
import ru.usb.xbank_intgr_credit.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_credit.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_credit.service.xloadfile.*;
import ru.usb.xbank_intgr_credit.service.zip.ZipApi;
import ru.usb.xbank_intgr_credit.service.zip.ZipService;
import ru.usb.xbank_intgr_credit.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
public class MainStream {

    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final ApiLayer apiLayer;
    private final ServiceMailError serviceMailError;
    private final Configure configure;
    private final Support support;
    private final ApiLayerDB apiLayerDB;
    private final ApiLayerS3 apiLayerS3;
    private final ZipApi zipApi;
    private final ExecutorsAccBalance executorsAccBalance;
    private final ExecutorsDogov executorsDogov;
    private final ExecutorsFact executorsFact;
    private final ExecutorsMigrInfo executorsMigrInfo;
    private final ExecutorsPparam executorsPparam;
    private final ExecutorsPrcShema executorsPrcShema;
    private final ExecutorsPlanall executorsPlanall;
    private final ExecutorsUnloadBki executorsUnloadBki;
    private final ZipService zipService;


    @Autowired
    public MainStream(ApiLayer apiLayer, ServiceMailError serviceMailError, Configure configure,
                      Support support, ApiLayerDB apiLayerDB, ApiLayerS3 apiLayerS3,
                      ZipApi zipApi, ExecutorsAccBalance executorsAccBalance,
                      ExecutorsDogov executorsDogov, ExecutorsFact executorsFact,
                      ExecutorsMigrInfo executorsMigrInfo, ExecutorsPparam executorsPparam,
                      ExecutorsPrcShema executorsPrcShema, ExecutorsPlanall executorsPlanall,
                      ExecutorsUnloadBki executorsUnloadBki, ZipService zipService) {
        this.apiLayer = apiLayer;
        this.serviceMailError = serviceMailError;
        this.configure = configure;
        this.support = support;
        this.apiLayerDB = apiLayerDB;
        this.apiLayerS3 = apiLayerS3;
        this.zipApi = zipApi;
        this.executorsAccBalance = executorsAccBalance;
        this.executorsDogov = executorsDogov;
        this.executorsFact = executorsFact;
        this.executorsMigrInfo = executorsMigrInfo;
        this.executorsPparam = executorsPparam;
        this.executorsPrcShema = executorsPrcShema;
        this.executorsPlanall = executorsPlanall;
        this.executorsUnloadBki = executorsUnloadBki;
        this.zipService = zipService;
    }

    /**
     * Основной процесс
     */
    public void run() {
        if (configure.isServiceEnabled()) { //Работаем только если сервис включен
            //Получаем список объектов
            getListFile();
        }
    }

    /**
     * Получение списка файлов
     */
    public void getListFile() {
        log.info("{}: Запрос на получение списка файлов", LG.USBLOGINFO);
        Optional<List<String>> linkList = apiLayerS3.getListFiles(configure.getS3BucketBase(), configure.getS3DirectoryCred()); //Получаем список файлов
        if (linkList.isPresent()) {
            linkList.get().forEach(log::info); //для смены на debug
            log.info("{}: Получен список файлов в s3 по маске:{} в количестве:{}", LG.USBLOGINFO, configure.getS3DirectoryCred(), linkList.get().size());
            //Теперь пойдем по каждому файлу..
            linkList.get().forEach(fileFromS3 -> {
                processedFileFromS3(new FtpsFile(fileFromS3)); //старт обработки файла по линку
            });
        }
    }

    /**
     * Обработка файла
     *
     * @param ftpsFile - объект файла
     */
    public void processedFileFromS3(FtpsFile ftpsFile) {
        //Обнуляем показатели
        support.setSuccessLoadFile();
        if (apiLayer.checkFileInDataBase(support.getFileName(ftpsFile.getFileLink()), Thread.currentThread().getId())) {
            log.info("{}:T{}:[processedFileFromS3] Файл:{} найден в базе. В таблице TBANK_HISTORY_ARCHIVES", LG.USBLOGINFO, Thread.currentThread().getId(), support.getFileName(ftpsFile.getFileLink()));
        } else {
            //Стартуем, смотрим есть ли такой файл базе данныхgetName
            TBankHistoryArchives tBankHistoryArchives = apiLayerDB.getHistoryArchive(support.getFileName(support.getFileName(ftpsFile.getFileLink())));
            log.info("{}:[processedFileFromS3] Файл:{} взят в обработку.", LG.USBLOGINFO, support.getFileName(ftpsFile.getFileLink()));
            //Скачиваем файл
            log.info("{}:T{}:[processedFileFromS3] Запускаем скачивание файла {}. Так как файл не обработан", LG.USBLOGINFO, Thread.currentThread().getId(), support.getFileName(ftpsFile.getFileLink()));
            apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
            try {
                ftpsFile.setFile(apiLayer.getFileFromS3(ftpsFile.getFileLink(), configure.getS3BucketBase(), support.getFileName(ftpsFile.getFileLink())));
                ftpsFile.setName(ftpsFile.getFile().getName()); //имя
                ftpsFile.setSize(ftpsFile.getFile().length());//размер
            } catch (Exception e) {
                log.error("{}:T{}:[processedFileFromS3] Ошибка при скачивании файла:{} из S3. Ошибка:{}", LG.USBLOGERROR, Thread.currentThread().getId(), support.getFileName(ftpsFile.getFileLink()), e.getMessage());
                support.setSuccessLoadFile();
                return;
            }
            log.info("{}:T{}:[processedFileFromS3] Файл записан в директорию: {} ", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsFile.getFile().getAbsolutePath());
            //Передаем в работу
            unzipProcess(ftpsFile, tBankHistoryArchives);
        }
    }

    /**
     * Работа с архивом
     *
     * @param ftpsFile             -
     * @param tBankHistoryArchives -
     */
    public void unzipProcess(FtpsFile ftpsFile, TBankHistoryArchives tBankHistoryArchives) {
        FtpsResponse ftpsResponse = new FtpsResponse();
        ftpsResponse.setFile(ftpsFile.getFile());
        ftpsResponse.setName(ftpsFile.getName());
        ftpsResponse.setCode(201);
        ftpsResponse.setMessage("");
        ftpsResponse.setHttpStatus(HttpStatus.OK);
        ftpsResponse.setFileLink(ftpsFile.getFileLink());
        //--1
        //Проверяем можно распаковать или нет
        ftpsResponse = zipService.checkZip(ftpsResponse, tBankHistoryArchives);
        if (ftpsResponse.getCode() != 200) {
            log.info("{} Архив поврежден, обработка файла:{} прекращена", LG.USBLOGERROR, ftpsResponse.getName());
            tBankHistoryArchives.setError("415");
            tBankHistoryArchives.setErrortext("Архив поврежден, обработка файла прекращена");
            apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
            //Чистим директорию
            support.cleanTempDirectory();
            return; //Выходим, если архив поврежден
        }
        //Все в порядке, распаковываем
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
        Optional<List<Path>> pathList = unzipFile(ftpsResponse.getFile(), path);
        configure.setArchiveName(ftpsResponse.getName());
        configure.setErrorSummary(""); //Инициация
        configure.setSyncErrorOnProcessed(false); //Пока ошибок нет
        configure.setNumInsert(support.getNumInsert()); //Номер вставки
        //Тут будет обработка файлов
        pathList.ifPresent(paths -> paths.forEach(pathIn -> {
            log.info("{}:T{}: Распакован файл:{}", LG.USBLOGINFO, Thread.currentThread().getId(), pathIn.getFileName());
            if (support.checkFileMask(pathIn.getFileName().toString())) {
                log.info("{}:T{}: Файл:{} прошел проверку на маску, но он не участвует в загрузке", LG.USBLOGINFO, Thread.currentThread().getId(), pathIn.getFileName());
            } else {
                switch (support.getFileName(pathIn.toString()).toLowerCase()) {
                    case "accbalance.csv":
                    case "tbank.accbalance.csv":
                        executorsAccBalance.getTask(pathIn);
                        configure.setAccBalance(true); //Была попытка загрузки
                        break;
                    case "dogov.csv":
                    case "tbank.dogov.csv":
                        executorsDogov.getTask(pathIn);
                        configure.setDogov(true); //Была попытка загрузки
                        break;
                    case "fact.csv":
                    case "tbank.fact.csv":
                        executorsFact.getTask(pathIn);
                        configure.setFact(true); //Была попытка загрузки
                        break;
                    case "migr_info.csv":
                    case "tbank.migr_info.csv":
                        executorsMigrInfo.getTask(pathIn);
                        configure.setMigrInfo(true); //Была попытка загрузки
                        break;
                    case "planall.csv":
                    case "tbank.planall.csv":
                        executorsPlanall.getTask(pathIn);
                        configure.setPlanall(true); //Была попытка загрузки
                        break;
                    case "pparam.csv":
                    case "tbank.pparam.csv":
                        executorsPparam.getTask(pathIn);
                        configure.setPparam(true); //Была попытка загрузки
                        break;
                    case "prc_scheme.csv":
                    case "tbank.prc_scheme.csv":
                        executorsPrcShema.getTask(pathIn);
                        configure.setPrcscheme(true); //Была попытка загрузки
                        break;
                    case "unload_bki.csv":
                    case "tbank.unload_bki.csv":
                    case "tbank.bki.csv":
                        executorsUnloadBki.getTask(pathIn);
                        configure.setUnloadbki(true); //Была попытка загрузки
                        break;
                    default:
                        log.error("{}:T{}: Неизвестный файл:{}", LG.USBLOGERROR, Thread.currentThread().getId(), pathIn.getFileName());
                        configure.setErrorSummary(configure.getErrorSummary() + "\n\r" + "Неизвестный файл:" + pathIn.getFileName());
                        break;
                }
            }
        }));

        //Ждем окончания работы потоков
        int i = 39999; //Более 30 минут ожидания
        while (configure.getThreads() > 0 || i == 0) {
            i--;
            try {
                Thread.sleep(500); //Время ожидания в секундах
            } catch (InterruptedException eI) {
                log.error("{}: Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR);
                Thread.currentThread().interrupt();
                return;
            }
        }
        //Удаляем файл..
        if (ftpsResponse.getFile() != null) {
            try {
                Files.deleteIfExists(ftpsResponse.getFile().toPath());
                log.info("{}:T{}: Файл:{} удален", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getAbsolutePath());
            } catch (IOException e) {
                log.error("{}:T{}: Ошибка:{} при удалении файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage(), ftpsResponse.getFile().getAbsolutePath());
            }
        }
        //Чистим директорию
        support.cleanTempDirectory();
        //Сохраняем архив
        checkResults(ftpsResponse, tBankHistoryArchives);
        //--1
    }

    /**
     * Проверка результатов
     *
     * @param ftpsResponse         - объект ответа
     * @param tBankHistoryArchives - объект архива
     */
    public void checkResults(FtpsResponse ftpsResponse, TBankHistoryArchives tBankHistoryArchives) {
        if (tBankHistoryArchives == null){
            tBankHistoryArchives = apiLayerDB.getHistoryArchive(ftpsResponse.getName());
        }
        if (!configure.getSyncErrorOnProcessed()) {
            //Переносим файл в processed
            log.info("{}:T{}: Файл:{} (подготовка), переносится в processed", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
            moveFileS3(ftpsResponse, "processed/cre");
            //Формируем сообщение
            if (support.checkSuccessLoadFile()) {
                log.info("{}:T{}: Архив с данными клиента успешно загружен в БД citymigration, файл {}", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
                serviceMailError.sendMailBusinessSubject("Архив с данными клиентов успешно загружен в БД citymigration, файл " + ftpsResponse.getName(),
                        "Архив с данными клиента успешно загружен в БД citymigration"
                                + "\n\r" + "Файл:" + support.getWrapNull(ftpsResponse.getName()) +
                                "\n\r" + "Микросервис: Xbank-intgr-clients");
                tBankHistoryArchives.setError("0");
                tBankHistoryArchives.setErrortext("Архив с данными клиента успешно загружен в БД citymigration, все файлы присутствовали");
                tBankHistoryArchives.setTbankFiles("1");
                tBankHistoryArchives.setDateEnd(new Date());
                apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
            } else {
                log.error("{}:T{}: При загрузке Архива с данными клиентов загружен. Не все файлы были в архиве. Файл {}, проблемы:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getName(), support.getReason(support.getWrapNull(support.getDescLoad())));
                serviceMailError.sendMailBusinessSubject("Архив с данными клиентов загружен. Есть некоторые проблем, файл " + ftpsResponse.getName(),
                        "Ошибка при загрузке файла " + support.getWrapNull(ftpsResponse.getName()) + " в БД citymigration"
                                + "\n\r Описание:\n\r " + support.getReason(support.getWrapNull(support.getDescLoad())) + "\n\r"
                                + "\n\r" + support.getWrapNull(configure.getErrorSummary()) +
                                "\n\r" + "Микросервис: Xbank-intgr-clients");
                tBankHistoryArchives.setError("0");
                tBankHistoryArchives.setDateEnd(new Date());
                tBankHistoryArchives.setErrortext("Архив с данными клиента успешно загружен. При загрузке Архива с данными клиентов возникли проблемы, нет части файлов.");
                apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
            }
        } else {
            log.info("{}:T{}: Произошла ошибка при загрузке файла в БД citymigration, файл {}", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
            serviceMailError.sendMailBusinessSubject("Произошла ошибка при загрузке файла в БД citymigration, файл " + support.getWrapNull(ftpsResponse.getName()),
                    "Подробности ошибки смотрите в системном журнале сервиса." + "\n\r" + "Микросервис: Xbank-intgr-clients");
            tBankHistoryArchives.setError("1");
            tBankHistoryArchives.setErrortext(" Произошла ошибка при загрузке файла в БД citymigration");
            tBankHistoryArchives.setTbankFiles("1");
            tBankHistoryArchives.setDateEnd(new Date());
            apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
            //Переносим файл в err/
            moveFileS3(ftpsResponse, "error/cre");
        }
        //Чистим директорию
        support.cleanTempDirectory();
    }

    /**
     * Сохранение файла в бакет S3
     *
     * @param ftpsResponse - объект ответа
     * @param direction    - направление (processed или err
     */
    public void moveFileS3(FtpsResponse ftpsResponse, String direction) {
        log.info("{}:T{}: Файл:{} (подготовка), переносится в {}/", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName(), direction);
        if (apiLayerS3.copyFileS3(configure.getS3BucketBase(), ftpsResponse.getFileLink(), configure.getS3BucketBase(),
                direction + "/" + ftpsResponse.getName(), Thread.currentThread().getId())) {
            log.info("{}:T{}: Файл:{} перенесен в {}}/", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName(), direction);
            //Удаляем файл из s3
            log.info("{}:T{}: Файл:{} (подготовка), удаляем из s3", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
            if (apiLayerS3.deleteFileS3(configure.getS3BucketBase(), ftpsResponse.getFileLink(), Thread.currentThread().getId()).is2xxSuccessful()) {
                log.info("{}:T{}: Файл:{} удален из s3", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
            } else {
                log.error("{}:T{}: Файл:{} не удален из s3", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getName());
            }
        }
    }


    /**
     * Распаковка файла
     *
     * @param file - файл
     * @param path - путь к файлу
     * @return - список файлов
     */
    public Optional<List<Path>> unzipFile(File file, Path path) {
        if (file == null) {
            log.error("{}: File is null", LG.USBLOGERROR);
            return Optional.empty();
        }
        String fileName = file.getName();
        try {
            Optional<List<Path>> pathList = zipApi.unzipFile(file.getAbsolutePath(), path.toString(), file.getName());
            if (pathList.isPresent()) {
                log.info("{}: File {} unzipped to {}", LG.USBLOGINFO, file.getAbsolutePath(), pathList.toString());
            } else {
                log.error("{}: File {} not unzipped. Каталог пустой!", LG.USBLOGERROR, file.getAbsolutePath());
                serviceMailError.sendMailBusinessSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                        + "\n Имя файла: " + fileName + "\n"
                        + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                        + "\n Сообщение об ошибке: После распаковки => Каталог пустой!");
                Files.deleteIfExists(file.toPath());
                support.cleanTempDirectory();
                return Optional.empty();
            }
            return pathList; //отдаем список
        } catch (Exception e) {
            log.error("{}: Error unzipping file: {}", LG.USBLOGERROR, e.getMessage());
            serviceMailError.sendMailBusinessSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                    + "\n Имя файла: " + support.getWrapNull(fileName) + "\n"
                    + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                    + "\n Сообщение об ошибке: ошибка при разархивации файла");
            return Optional.empty();
        }
    }

}


