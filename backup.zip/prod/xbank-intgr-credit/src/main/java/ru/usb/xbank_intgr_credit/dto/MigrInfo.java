package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * Created by 1 on 07.05.2018.
 */
//migr_info.csv	Информация по кредитным договорам

//S;DATE_BEG_ORIG;DATE_END_ORIG;DATE_END  ;TOTAL_DAYS_OVERDUE;SUM_OVERDUE;NUM_PMTS_MADE;
// NUM_PMTS_REM;ORIG_TERM;CURR_TERM;PRC_RATE_ORIG;PAY_DAY_ORIG;PRC_RATE_CURR;PAY_DAY_CURR;
// PAY_SUM_CURR;DATE_FIRST_PAY;DATE_LASTPAY_COMMIT;SUM_LASTPAY_COMMIT;DATE_NEXT_PAYMENT;SUM_NEXT_PAYMENT;REFINANCE

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_MIGR_INFO")
public class MigrInfo {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S")//2
    private String s;

    @Column(name = "DATE_BEG_ORIG")//3
    private Date dateBegOrig;

    @Column(name = "DATE_END_ORIG")//4
    private Date dateEndOrig;

    @Column(name = "DATE_END")//5
    private Date dateEnd;

    @Column(name = "TOTAL_DAYS_OVERDUE")//6
    private String totalDaysOverdue;

    @Column(name = "SUM_OVERDUE")//7
    private BigDecimal sumOverdue;

    @Column(name = "NUM_PMTS_MADE")//8
    private String numPmtsMade;

    @Column(name = "NUM_PMTS_REM")//9
    private String numPmtsRem;

    @Column(name = "ORIG_TERM")//10
    private String origTerm;

    @Column(name = "CURR_TERM")//11
    private String currTerm;

    @Column(name = "PRC_RATE_ORIG", columnDefinition = "NUMBER", precision = 6, scale = 1)//12
    private BigDecimal prcRateOrig;

    //  PRC_RATE_CURR, PAY_DAY_CURR,  DATE_FIRST_PAY,  DATE_LASTPAY_COMMIT, DATE_NEXT_PAYMENT
    @Column(name = "PAY_DAY_ORIG")//13
    private String payDayOrig;

    @Column(name = "PRC_RATE_CURR", columnDefinition = "NUMBER", precision = 6, scale = 1)//14
    private BigDecimal prcRateCurr;

    @Column(name = "PAY_DAY_CURR")//15
    private String payDayCurr;

    @Column(name = "PAY_SUM_CURR")//16
    private BigDecimal paySumCurr;

    @Column(name = "DATE_FIRST_PAY")//17
    private Date dateFirstPay;

    @Column(name = "DATE_LASTPAY_COMMIT")//18
    private Date dateLastpayCommit;

    @Column(name = "SUM_LASTPAY_COMMIT")//19
    private BigDecimal sumLastpayCommit;

    @Column(name = "DATE_NEXT_PAYMENT")//20
    private Date dateNextPayment;

    @Column(name = "SUM_NEXT_PAYMENT")//21
    private BigDecimal sumNextPayment;

    @Column(name = "REFINANCE")//22
    private String refinance;

    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки
}
