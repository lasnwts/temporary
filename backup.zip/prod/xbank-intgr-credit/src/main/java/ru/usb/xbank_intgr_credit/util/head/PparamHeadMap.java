package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.PparamPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class PparamHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public PparamHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;VIDOPER ;DAYPAY;DAYCALC;SUMPAY;DATE_CALC;DATE_PAY;DATE_END;OPER_COUNT;ONLY_PRC;GASH_PAY_PERIOD

    /**
     * Преобразование строки в объект PparamPosition
     *
     * @param line - строка
     * @return - объект PparamPosition
     */
    public PparamPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        PparamPosition pparamPosition = new PparamPosition();
        pparamPosition.setS(support.getPosition("S", values));
        pparamPosition.setVidoper(support.getPosition("VIDOPER", values));
        pparamPosition.setDaypay(support.getPosition("DAYPAY", values));
        pparamPosition.setDaycalc(support.getPosition("DAYCALC", values));
        pparamPosition.setSumpay(support.getPosition("SUMPAY", values));
        pparamPosition.setDateCalc(support.getPosition("DATE_CALC", values));
        pparamPosition.setDatePay(support.getPosition("DATE_PAY", values));
        pparamPosition.setDateEnd(support.getPosition("DATE_END", values));
        pparamPosition.setOperCount(support.getPosition("OPER_COUNT", values));
        pparamPosition.setOnlyPrc(support.getPosition("ONLY_PRC", values));
        pparamPosition.setGashPayPeriod(support.getPosition("GASH_PAY_PERIOD", values));
        return pparamPosition;
    }

}
