package ru.usb.xbank_intgr_credit.dto;

/**
 * Created by 1 on 08.06.2021.
 * файл =pparam.csv
 */

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * Класс для передачи параметров
 *     //S;VIDOPER ;DAYPAY;DAYCALC;SUMPAY;DATE_CALC;DATE_PAY;DATE_END;OPER_COUNT;ONLY_PRC;GASH_PAY_PERIOD
 *     //id записи;ВКИ (внутренний код для импорта) договора;
 *     //Количество операций;Всегда 0;Если дата платежа не менялась и не будет меняться, то заполнять 1.;Имя файла;Дата внесения записи
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_PPARAM")
public class Pparam {

    //01.11.2024 : 2.	Таблица TBANK_pparam поля DAYPAY , DAYCALC (дни платежа, начисления). предаваться будет как число, например , 5, 6, 7… до 31). По этим полям нужно поправить type = Number

    @Id
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора

    @Column(name = "VIDOPER")//2
    private String vidoper;//Код вида операции

    @Column(name = "DAYPAY")//3
    private String daypay;//День платежа

    @Column(name = "DAYCALC")//4
    private String daycalc;//День начисления

    @Column(name = "SUMPAY")//5
    private BigDecimal sumpay;//Cумма платежа

    @Column(name = "DATE_CALC")//6
    private Date dateCalc;//Начало расчета

    @Column(name = "DATE_PAY")//7
    private Date datePay;//Начало гашений

    @Column(name = "DATE_END")//8
    private Date dateEnd;//Окончание планирования

    @Column(name = "OPER_COUNT")//9
    private String operCount;//Количество операций

    @Column(name = "ONLY_PRC")//10
    private String onlyPrc;//Всегда 0

    @Column(name = "GASH_PAY_PERIOD")//11
    private String gashPayPeriod;//Если дата платежа не менялась и не будет меняться, то заполнять 1

    //Имя файла
    @Column(name = "FILENAME")//12
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//13
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//14
    private long numInsert; //Номер вставки
}
