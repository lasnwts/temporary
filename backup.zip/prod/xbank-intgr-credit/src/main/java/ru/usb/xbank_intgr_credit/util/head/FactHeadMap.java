package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.FactHeadPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class FactHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public FactHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;DATE;OPER;SUM;VALUTA

    /**
     * Преобразование строки в объект FactHeadPosition
     * @param line - строка
     * @return - объект FactHeadPosition
     */
    public FactHeadPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        FactHeadPosition factHeadPosition = new FactHeadPosition();
        factHeadPosition.setS(support.getPosition("S", values));
        factHeadPosition.setDate(support.getPosition("DATE", values));
        factHeadPosition.setOper(support.getPosition("OPER", values));
        factHeadPosition.setSum(support.getPosition("SUM", values));
        factHeadPosition.setValuta(support.getPosition("VALUTA", values));
        return factHeadPosition;
    }
}
