package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.AccBalancePosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class AccBalanceHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public AccBalanceHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    /**
     * Преобразование строки в объект AccBalancePosition
     *
     * @param line - строка
     * @return - объект AccBalancePosition
     */

    public AccBalancePosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        AccBalancePosition accBalancePosition = new AccBalancePosition();
        accBalancePosition.setS(support.getPosition("S", values));
        accBalancePosition.setSum(support.getPosition("SUM", values));
        accBalancePosition.setAcc(support.getPosition("ACC", values));
        return accBalancePosition;
    }
}
