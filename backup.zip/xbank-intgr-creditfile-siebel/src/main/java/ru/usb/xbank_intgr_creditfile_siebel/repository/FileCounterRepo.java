package ru.usb.xbank_intgr_creditfile_siebel.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileCounter;

import javax.persistence.QueryHint;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface FileCounterRepo extends JpaRepository<FileCounter, Long>{

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT FILE_COUNT FROM TBANK_FILECOUNTER WHERE FILE_CODE =:code")
    int getCount(int code);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT count(*) FROM TBANK_FILECOUNTER WHERE FILE_CODE =:code")
    Integer checkExistCount(int code);

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT * FROM TBANK_FILECOUNTER WHERE FILE_CODE =:code and ROWNUM = 1")
    FileCounter getFileCount(int code);
}
