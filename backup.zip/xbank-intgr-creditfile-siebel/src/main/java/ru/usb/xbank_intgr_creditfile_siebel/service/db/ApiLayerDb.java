package ru.usb.xbank_intgr_creditfile_siebel.service.db;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileCounter;
import ru.usb.xbank_intgr_creditfile_siebel.model.FileTemp;
import ru.usb.xbank_intgr_creditfile_siebel.model.TBankHistoryArchives;
import ru.usb.xbank_intgr_creditfile_siebel.model.TBankHistoryFiles;
import ru.usb.xbank_intgr_creditfile_siebel.repository.FileCounterRepo;
import ru.usb.xbank_intgr_creditfile_siebel.repository.FileCredTempRepo;
import ru.usb.xbank_intgr_creditfile_siebel.repository.TBankHistoryArchivesRepo;
import ru.usb.xbank_intgr_creditfile_siebel.repository.TBankHistoryFilesRepo;
import ru.usb.xbank_intgr_creditfile_siebel.util.Support;

import java.util.Date;
import java.util.List;

@Log4j2
@Service
public class ApiLayerDb {

    private final Support support;
    private final FileCounterRepo fileCounterRepo;
    private final FileCredTempRepo fileCredTempRepo;
    private final TBankHistoryFilesRepo tBankHistoryFilesRepo;
    private final TBankHistoryArchivesRepo tBankHistoryArchivesRepo;

    @Autowired
    public ApiLayerDb(Support support, FileCounterRepo fileCounterRepo, FileCredTempRepo fileCredTempRepo,
                      TBankHistoryFilesRepo tBankHistoryFilesRepo, TBankHistoryArchivesRepo tBankHistoryArchivesRepo) {
        this.support = support;
        this.fileCounterRepo = fileCounterRepo;
        this.fileCredTempRepo = fileCredTempRepo;
        this.tBankHistoryFilesRepo = tBankHistoryFilesRepo;
        this.tBankHistoryArchivesRepo = tBankHistoryArchivesRepo;
    }

    /**
     * Сохранить историю файлов
     *
     * @param tBankHistoryFiles - история файлов
     */
    public void saveFileHistory(TBankHistoryFiles tBankHistoryFiles) {
        tBankHistoryFilesRepo.save(tBankHistoryFiles);
    }


    /**
     * Получить количество строк по дате
     * <p>
     * SELECT COUNT(*) FROM table WHERE date = :date
     *
     * @param date дата
     * @return количество строк
     */
    public synchronized int getCountRows(Date date) {
        if (fileCounterRepo.checkExistCount(support.getCode(date)) == 0) {
            return 0;
        } else {
            return fileCounterRepo.getCount(support.getCode(date));
        }
    }

    /**
     * Сохранить количество строк по дате
     *
     * @param date дата
     */
    public synchronized void saveCountRows(Date date) {
        FileCounter fileCounter = fileCounterRepo.getFileCount(support.getCode(date));
        if (fileCounter == null) {
            fileCounter = new FileCounter();
        }
        fileCounter.setDate(support.convertDateToSqlDate(date));
        fileCounter.setFileCount(fileCounter.getFileCount() + 1);
        fileCounter.setCode(support.getCode(date));
        fileCounterRepo.save(fileCounter);
    }

    /**
     * Сохранить временный файл
     *
     * @param fileTemp - временный файл
     */
    public void saveFileCredTemp(FileTemp fileTemp) {
        fileCredTempRepo.saveAndFlush(fileTemp);
    }


    /**
     * Удалить временный файл
     * <p>
     * DELETE FROM table WHERE id = :id
     * <p>
     * Удаляем записи  таблице filecredtemp
     * <p>
     *
     * @param id - идентификатор файла
     */
    public void deleteFileId(long id) {
        fileCredTempRepo.deleteById(id);
    }

    /**
     * Получаем список записей
     *
     * @param archive - архив
     * @param folder  - папка
     * @param name    - имя файла
     * @return - количество записей
     */
    public int checkFileDate(String archive, String folder, String name) {
        return tBankHistoryFilesRepo.checkFileProcessedDate(archive, folder, name);
    }

    /**
     * Получаем список записей
     *
     * @param archive - архив
     * @param folder  - папка
     * @param name    - имя файла
     * @return - количество записей
     */
    public List<TBankHistoryFiles> checkFileProcessedKafka(String archive, String folder, String name) {
        return tBankHistoryFilesRepo.checkFileProcessedKafka(archive, folder, name);
    }

    /**
     * Проверка, что файл не обработан
     *
     * @param archive - архив
     * @param folder  - папка
     * @param name    - имя файла
     * @return - true если файл не обработан
     */
    public boolean checkFileProcessed(String archive, String folder, String name) {
        final boolean[] result = {false};
        List<TBankHistoryFiles> list = tBankHistoryFilesRepo.checkFileProcessedKafka(archive, folder, name);
        if (!list.isEmpty()) {
            list.forEach(tBankHistoryFiles -> {
                if (tBankHistoryFiles.getKafkaIn() != null && tBankHistoryFiles.getKafkaIn().equalsIgnoreCase("1")) {
                    result[0] = true;
                }
            });
        }
        if (checkFileDate(archive, folder, name) > 0) {
            result[0] = true;
        }
        return result[0];
    }

    /**
     * Удалить временный файл
     * <p>
     * DELETE FROM table WHERE file_guid = :guid AND file_name NOT LIKE :maskFile
     * <p>
     * Удаляем записи  таблице filecredtemp
     * <p>
     *
     * @param guid     - идентификатор файла
     * @param maskFile - маска файла
     */
    public void deleteFileCredTemp(String guid, String maskFile) {
        fileCredTempRepo.deleteByFileGuid(guid, maskFile);
    }

    /**
     * Получить список временных файлов
     *
     * @param guid - идентификатор файла
     * @return - список временных файлов
     */
    public List<FileTemp> getListFile(String guid) {
        return fileCredTempRepo.getTempFile(guid);
    }


    /**
     * пРОВЕРИТЬ ЧТО ФАЙЛ НЕ ОБРАБАТЫВАЛ
     * <p>
     * SELECT COUNT(*) FROM table WHERE file_guid = :guid AND file_name LIKE :fileName AND file_busy = 1
     * <p>
     * Проверяем что файл не обработан
     * <p>
     *
     * @param fileGuid - идентификатор файла
     * @param fileName - маска файла
     * @return - true если файл не обработан
     */
    public boolean getBusyFile(String fileGuid, String fileName) {
        return fileCredTempRepo.getBusy(fileGuid, fileName) > 0;
    }


    /**
     * Удалить временный файл
     * <p>
     * DELETE FROM table WHERE id = :id
     * <p>
     * Удаляем записи  таблице filecredtemp
     * <p>
     *
     * @param id - идентификатор файла
     */
    public void deleteFileCredTemp(long id) {
        fileCredTempRepo.deleteById(id);
    }


    /**
     * Проверка, что архив не обработан
     * @param archiveName - имя архива
     * @return - количество записей, если значение больше 0, то архив обработан!
     */
    public int checkArchiveProcessed(String archiveName){
        return tBankHistoryArchivesRepo.getCountFileName(archiveName);
    }

    /**
     * Получить архив
     * @param archiveName - имя архива
     * @return - архив
     */
    public TBankHistoryArchives getArchive(String archiveName){
        return tBankHistoryArchivesRepo.getByName(archiveName);
    }

    /**
     * Сохранить архив
     * @param tBankHistoryArchives - архив
     */
    public void saveArchive(TBankHistoryArchives tBankHistoryArchives){
        tBankHistoryArchivesRepo.save(tBankHistoryArchives);
    }

    /**
     * Получаем общее кол-во файлов
     * @param fileName - имя файла архива
     * @return - число
     */
    public int getAllFiles(String fileName){
        return tBankHistoryFilesRepo.getCountAllFile(fileName);
    }

    /**
     * Получаем общее кол-во файлов с ошибкой
     * @param fileName - имя файла архива
     * @return - число
     */
    public int getBadFiles(String fileName){
        return tBankHistoryFilesRepo.getCountBadFile(fileName);
    }

    /**
     * Получаем общее кол-во договоров
     * @param fileName - имя файла архива
     * @return - число
     */
    public int getCountDog(String fileName){
        return tBankHistoryFilesRepo.getCountFolder(fileName);
    }

    /**
     * Получаем общее кол-во договоров
     * @param fileName - имя файла архива
     * @return - число
     */
    public int getCountSuccessFiles(String fileName){
        return tBankHistoryFilesRepo.getCountSuccessFile(fileName);
    }


}
