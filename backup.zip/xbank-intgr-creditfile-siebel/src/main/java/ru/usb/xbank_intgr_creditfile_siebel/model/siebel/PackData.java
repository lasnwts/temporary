package ru.usb.xbank_intgr_creditfile_siebel.model.siebel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class PackData {
    @JsonProperty("archivename")
    private String archivename;

    @JsonProperty("assetnumber")
    private String assetnumber;

    @JsonProperty("filename")
    private String filename;

    @JsonProperty("fileext")
    private String fileext;

    @JsonProperty("fileid")
    private String fileid;

    @JsonProperty("filesize")
    private long filesize;

    @JsonProperty("filelink")
    private String filelink;

    @JsonProperty("doctype")
    private String doctype;

    @JsonProperty("filecomment")
    private String filecomment;
}
