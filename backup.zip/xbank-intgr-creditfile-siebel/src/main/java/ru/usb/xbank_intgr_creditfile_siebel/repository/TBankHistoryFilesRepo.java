package ru.usb.xbank_intgr_creditfile_siebel.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.xbank_intgr_creditfile_siebel.model.TBankHistoryFiles;

import javax.persistence.QueryHint;

import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface TBankHistoryFilesRepo extends JpaRepository<TBankHistoryFiles, Long>{

    /**
     * Условие передачи файла в БД (файл передан):
     * a)	;
     * b)	В БД есть строка: ARCHIVE_NAME = имени zip-архива и FOLDER_NAME = имя каталога/номер кредитного договора и
     * FILE_NAME = имя обрабатываемого файла и DATE_END заполнено;
     * @param archiveName - имя архива
     * @param folderName - имя каталога
     * @param fileName - имя файла
     * @return - количество строк в БД
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from tbank_history_files where archive_name =:archiveName and folder_name =:folderName and file_name =:fileName and date_end is not null")
    int checkFileProcessedDate(String archiveName, String folderName, String fileName);


    /**
     * c)	В БД есть строка: ARCHIVE_NAME = имени zip-архива и FOLDER_NAME = имя каталога/номер кредитного договора
     * и FILE_NAME = имя обрабатываемого файла и KAFKAIN = 1
     * @param archiveName - имя архива
     * @param folderName - имя каталога
     * @param fileName - имя файла
     * @return - количество строк в БД
     */
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select ID,ARCHIVE_NAME,DATE_END,DATE_START,ERROR,ERROR_TEXT,FILE_EXT,FILE_GUID,FILE_LINK,FILE_NAME,FILE_NAME_GUID,FILE_SIZE,FOLDER_NAME,KAFKA_IN,PACKID from tbank_history_files where archive_name =:archiveName and folder_name =:folderName and file_name =:fileName and kafka_in is not null")
    List<TBankHistoryFiles> checkFileProcessedKafka(String archiveName, String folderName, String fileName);


    //Кол-во  успешных файлов
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from  tbank_history_files where archive_name =:fileName and error is null")
    int getCountSuccessFile(String fileName);

    //Кол-во всех файлов
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from  tbank_history_files where archive_name =:fileName")
    int getCountAllFile(String fileName);

    //Количество файлов с ошибкой обработки
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(*) from  tbank_history_files where archive_name =:fileName and error is not null")
    int getCountBadFile(String fileName);


    //Количество договоров
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select count(distinct folder_name) from  tbank_history_files where archive_name =:fileName")
    int getCountFolder(String fileName);
}
