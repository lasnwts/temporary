package ru.usb.xbank_intgr_creditfile_siebel.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.xbank_intgr_creditfile_siebel.config.LG;
import ru.usb.xbank_intgr_creditfile_siebel.service.s3.AmazonS3Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/s3")
@Tag(name = "Контроллер S3. Для работы с хранилищем", description = "Управление файлами в хранилище s3")
public class StorageController {
    private final AmazonS3Service s3Service;
    private static final String STATUS_CODE = "status code";


    @Autowired
    public StorageController(AmazonS3Service s3Service) {
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/{bucketName}/files", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/{bucketName}/files. Метод : Upload. Метод загрузки файла в хранилище в корзину Bucket.")
    public ResponseEntity<Map<String, String>> upload(
            @PathVariable("bucketName") String bucketName,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        try {
            s3Service.uploadFile(bucketName, files.getOriginalFilename(), files.getBytes());
            result.put("path", s3Service.getFileLink(bucketName, files.getOriginalFilename()));
            log.info("{} path:{}", LG.USBLOGINFO, result.get("path"));
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(result);
        }
    }

    @PostMapping(value = "/{bucketName}/file", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "/{bucketName}/file. Метод : Upload. Метод загрузки файла в хранилище в корзину Bucket.")
    public ResponseEntity<Map<String, String>> uploadKey(
            @PathVariable("bucketName") String bucketName,
            @RequestPart(value = "file") MultipartFile files) {
        Map<String, String> result = new HashMap<>();
        try {
            s3Service.uploadFile(bucketName, files.getOriginalFilename(), files.getBytes());
            result.put("path", s3Service.getFileLink(bucketName, files.getOriginalFilename()));
            log.info("{} path:{}", LG.USBLOGINFO, result.get("path"));
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            result.put("error", e.getMessage());
            log.error("", e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(result);
        }
    }

    @GetMapping(value = "/{bucketName}/{catalog}/{keyName}", consumes = "application/octet-stream")
    @Operation(summary = "/{bucketName}/{catalog}/{keyName}. Метод Download file (получить / скачать файл) Метод получения файла из хранилища.")
    public ResponseEntity<ByteArrayResource> downloadFileLink(
            @PathVariable("bucketName") String bucketName,
            @PathVariable(value = "catalog", required = false) String catalog,
            @PathVariable("keyName") String keyName) {
        byte[] data = null;
        try {
            log.info("{}:downloadFile: Получение файла:{}/{} из бакета:{}", LG.USBLOGINFO, catalog, keyName, bucketName);
            data = s3Service.downloadFile(bucketName, catalog + "/" + keyName);
            ByteArrayResource resource = new ByteArrayResource(data);
            ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                    .filename(keyName, StandardCharsets.UTF_8)
                    .build();
            return ResponseEntity
                    .ok()
                    .contentLength(data.length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", contentDisposition.toString())
                    .body(resource);
        } catch (Exception e) {
            log.error("{}:downloadFile: Возникла ошибка: ", LG.USBLOGERROR, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(new ByteArrayResource(e.getMessage().getBytes(StandardCharsets.UTF_8)));
        }
    }

    @GetMapping(value = "/{bucketName}/{keyName}", consumes = "application/octet-stream")
    @Operation(summary = "/{bucketName}/{keyName}. Метод Download file (получить / скачать файл) Метод получения файла из хранилища.")
    public ResponseEntity<ByteArrayResource> downloadFile(
            @PathVariable("bucketName") String bucketName,
            @PathVariable("keyName") String keyName) {
        byte[] data = null;
        try {
            log.info("{}:downloadFile: Получение файла:{} из бакета:{}", LG.USBLOGINFO, keyName, bucketName);
            data = s3Service.downloadFile(bucketName, keyName);
            ByteArrayResource resource = new ByteArrayResource(data);
            ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                    .filename(keyName, StandardCharsets.UTF_8)
                    .build();
            return ResponseEntity
                    .ok()
                    .contentLength(data.length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", contentDisposition.toString())
                    .body(resource);
        } catch (Exception e) {
            log.error("{}:downloadFile: Возникла ошибка: ", LG.USBLOGERROR, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(new ByteArrayResource(e.getMessage().getBytes(StandardCharsets.UTF_8)));
        }
    }

    @DeleteMapping("/{bucketName}/files/{keyName}")
    @Operation(summary = "/{bucketName}/files/{keyName}. Метод Delete Удаление файла из хранилища. bucketName - имя корзины, keyName - имя файла")
    public ResponseEntity<String> delete(
            @PathVariable("bucketName") String bucketName,
            @PathVariable(value = "keyName") String keyName) {
        try {
            log.info("{} Файл:{} удален из бакета:{}", LG.USBLOGINFO, keyName, bucketName);
            return ResponseEntity.status(s3Service.deleteFile(bucketName, keyName)).body("");
        } catch (Exception e) {
            log.error("{}: Ошибка удаления файла по s3:{}/{}", LG.USBLOGINFO, bucketName, keyName);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body("Ошибка удаления");
        }
    }

    @GetMapping("/{bucketName}/files")
    @Operation(summary = "/{bucketName}/files. Метод Get list Objects in buckets. Получить список всех файлов в корзине хранилища")
    public ResponseEntity<List<String>> listObjects(
            @PathVariable("bucketName") String bucketName) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(s3Service.listFiles(bucketName));
        } catch (Exception e) {
            List<String> errorList = new ArrayList<>();
            errorList.add(e.getMessage());
            log.error("{}:listObjects: Возникла ошибка: ", LG.USBLOGERROR, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(errorList);
        }
    }

    @PostMapping(value = "/checkBucket")
    @Operation(summary = "/checkBucket. Метод : check Bucket. Проверка наличия бакета = Bucket.")
    public ResponseEntity<String> checkBucket(@RequestBody String bucketName) {
        try {
            if (s3Service.checkBucket(bucketName)) {
                return ResponseEntity.status(HttpStatus.OK).body("bucket exist");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("bucket NOT exist");
            }
        } catch (Exception e) {
            log.error("{}: Ошибка при проверке существования бакета={}", LG.USBLOGERROR, bucketName, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(e.getMessage());
        }
    }

    @GetMapping("/{bucketName}/{key}")
    @Operation(summary = "/{bucketName}/{key}}. Метод ge tKey Link. Получить ссылку на файл.")
    public ResponseEntity<String> getKeyLink(
            @PathVariable(name = "bucketName") String bucketName,
            @PathVariable(name = "key") String key) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(s3Service.getFileLink(bucketName, key));
        } catch (Exception e) {
            log.error("{}:getKeyLink: Возникла ошибка: ", LG.USBLOGERROR, e);
            return ResponseEntity.status(getStatusCode(e.getMessage())).body(e.getMessage());
        }
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    private HttpStatus getStatusCode(String line) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        if (line != null && line.toLowerCase().contains(STATUS_CODE)) {

            String code = line.toLowerCase().substring(line.toLowerCase().indexOf(STATUS_CODE) + 13,
                    line.toLowerCase().indexOf(STATUS_CODE) + 16);

            switch (code) {
                case "404":
                    httpStatus = HttpStatus.NOT_FOUND;
                    break;
                case "400":
                    httpStatus = HttpStatus.BAD_REQUEST;
                    break;
                case "401":
                    httpStatus = HttpStatus.UNAUTHORIZED;
                    break;
                case "403":
                    httpStatus = HttpStatus.FORBIDDEN;
                    break;
                case "405":
                    httpStatus = HttpStatus.METHOD_NOT_ALLOWED;
                    break;
                case "501":
                    httpStatus = HttpStatus.NOT_IMPLEMENTED;
                    break;
                case "502":
                    httpStatus = HttpStatus.BAD_GATEWAY;
                    break;
                case "503":
                    httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
                    break;
                case "504":
                    httpStatus = HttpStatus.GATEWAY_TIMEOUT;
                    break;
                case "300":
                    httpStatus = HttpStatus.MULTIPLE_CHOICES;
                    break;
                case "301":
                    httpStatus = HttpStatus.MOVED_PERMANENTLY;
                    break;
                default:
                    httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                    break;
            }
        }
        return httpStatus;
    }

}
