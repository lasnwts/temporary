package ru.usb.xbank_intgr_creditfile_siebel.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties
public class Configure {

    /**
     * Топик Кафка
     */
    @Value("${kafka.siebel.topic}")
    private String siebelTopic;

    @Value("${system.from}")
    private String systemFrom;

    @Value("${system.to}")
    private String systemTo;

    @Value("${system.service}")
    private String systemService;


    //s3
    @Value("${s3.url}")
    private String s3Url;

    /**
     * 1.1.	Если по результату запроса получен ответ с ошибками:
     * •	500, 502, 503, 504, то повторить попытку запроса. Количество попыток = 10, обработка попыток = нелинейно,
     * общее время = 10 минут. Если попытки завершены, и ошибка не изменилась,
     * то сгенерировать и направить сообщение Email в службу технической поддержки - Пример 4
     */
    private String letter5xxSubject = "S3 = Tbankfiles недоступен Микросервис: Xbank-intgr-creditfile-Siebel Статус: 5xx";

    private String letter5x = "S3 = Tbankfiles недоступен\n" +
            "Микросервис: Xbank-intgr-creditfile-Siebel\n" +
            "Статус: 500\n" +
            "Описание ошибки : Internal Server Error\n";

    private String letter4xxSubject = "S3 = Tbankfiles недоступен Микросервис: Xbank-intgr-creditfile-Siebel Статус: 4xx";

    private String letter4x = "S3 = Tbankfiles проблемы см авторизацией\n" +
            "Микросервис: Xbank-intgr-creditfile-Siebel\n" +
            "Статус: 4xx\n" +
            "Описание ошибки : \n";

    private String letterUnzipError = "Ошибка при разархивации\n" + "Микросервис: Xbank-intgr-creditfile-Siebel\n";

    private String letterUnzipSubjectError = "Ошибка при разархивации Микросервис: Xbank-intgr-creditfile-Siebel";

    private String letterUnzipEmpty = "Файл пустой\n" + "Микросервис: Xbank-intgr-creditfile-Siebel\n";

    private String letterEmptySubjectError = "Файл пустой. Микросервис: Xbank-intgr-creditfile-Siebel";

    //getLetterNumDogSubjectError
    private String letterNumDogSubjectError = "Номер кредитного договора не соответствует маске – досье по кредиту не передано. Микросервис: Xbank-intgr-creditfile-Siebel";
    private String letterNumDogError = "Номер кредитного договора не соответствует маске – досье по кредиту не передано. Микросервис: Xbank-intgr-creditfile-Siebel";

    //Имя папки: 000125612560121/
    //Имя файла: rup_o_dosdddddddddddddd .zip
    //Микросервис: Xbank-intgr-creditfile-Siebel
    //Дата: 09.10.2024 15:12:30

    /**
     * Количество папок с договорами
     */
    private int reportFolderCount;

    //Количество файлов в архиве
    private int reportFilesCount;

    /**
     * Кол-во успешно переданных и файлов с проблемами
     */
    private int reportFileSuccess;
    private int reportFileError;


    /**
     * Количество задач в очереди
     */
    private int threads;


    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private Integer servicePoolSize;


    /**
     * Кол-во потоков
     */
    public synchronized int getThreads() {
        return threads;
    }

    public synchronized void setThreads(int threads) {
        this.threads = threads;
    }

    public int getServicePoolSize() {
        return servicePoolSize;
    }

    /**
     * Путь к общей папке с файлами
     */
    @Value("${scheduler.delay}")
    private String schedulerDelay;

    /**
     * GUID - для работы с файлами
     */
    private String guid;


    /**
     * Количество файлов в день
     */
    @Value("${file.count}")
    private int fileCountPerDay;

    /**
     * S3
     */
    @Value("${s3.file.mask}")
    private String s3MaskFile; //Маска файла

    @Value("${s3.file.ext}")
    private String s3ExtFile; //Расширение файла

    @Value("${s3.bucket.base}")
    private String s3BucketBase; //основной бакет

    @Value("${s3.directory.cred}")
    private String s3DirectoryCred; //поддиректория с кредитами

    /**
     * Количество файлов за 1 день < 125000
     */
    int fileCount;

    public synchronized void setSyncFileCount(int fileCount) {
        this.fileCount = fileCount;
    }

    public synchronized int getSyncFileCount() {
        return fileCount;
    }

    /**
     * Проверка разрешена работа по времени или нет.
     */
    @Value("${work.time:true}")
    private boolean workTime;

    /**
     * Установка разрешена работа по времени или нет.
     */
    public synchronized void setSyncWorkTime(boolean workTime) {
        this.workTime = workTime;
    }

    /**
     * Получение разрешена работа по времени или нет.
     */
    public synchronized boolean isSyncWorkTime() {
        return workTime;
    }

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Временная директория для размещения файлов выгрузки
     */
    String tempDirUploadFile;

    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * COMMA DELIMITER
     */
    @Value("${csv.delimiter:;}")
    private String csvDelimiter;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;

    /**
     * net.file.share - внутренняя шара
     */
    @Value("${net.file.share}")
    private String netFileShare;

}
