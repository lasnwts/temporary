package ru.usb.xbank_intgr_creditfile_siebel.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Date;

/**
 * Счетчик файлов, за день
 * 2.	Реализовать на уровне микросервиса счетчик количества переданных файлов в день (сообщений в Kafka).
 * Количество переданных файлов в день должно быть настройкой микросервиса. По умолчанию 125 тыс файлов в день.
 * При достижении порога количества обработки файлов, обработать до конца архив и завершить работу микросервиса.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_FILECOUNTER")
public class FileCounter {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "FILE_COUNT")//id записи
    private int fileCount; //количество файлов

    @Column(name = "FILE_DATA")//дата вставки, обновления
    private Date date; //Дата

    @Column(name = "FILE_CODE")//id записи - по сути. Пример YYYYMMDD
    private int code;
}
