package ru.usb.xbank_intgr_creditfile_siebel.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_creditfile_siebel.config.LG;

import java.io.File;
import java.util.List;
import java.util.Optional;


@Log4j2
@Service
public class ApiLayerS3 {

    private final CheckS3Service checkS3Service;
    private final AmazonS3Service amazonS3Service;

    @Autowired
    public ApiLayerS3(CheckS3Service checkS3Service, AmazonS3Service amazonS3Service) {
        this.checkS3Service = checkS3Service;
        this.amazonS3Service = amazonS3Service;
    }

    /**
     * Получить список файлов
     *
     * @param bucketName имя бакета
     * @return список файлов
     */
    public Optional<List<String>> getListFiles(String bucketName) {
        return checkS3Service.getListFiles(checkS3Service.getReadListObjects(bucketName));
    }


    /**
     * Скачивание файла из бакета
     *
     * @param fileLink   - имя файла
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     */
    public File downloadFileFromS3(String fileLink, String bucketName, String fileName) throws Exception {
        try {
            File file = amazonS3Service.upload(fileName, amazonS3Service.getFile(bucketName, fileLink));//Скачиваем файл с S3 по бакету и линку
            log.info("{}: Загружен файл:{} размером bytes.length={}", LG.USBLOGINFO, file.getName(), file.length());
            return file;
        } catch (Exception e) {
            log.error("{}:[downloadFileFromS3] Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[downloadFileFromS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Удаление файла из бакета
     *
     * @param bucketName - имя бакета
     * @param fileLink   - имя файла
     */
    public void deleteFileFromS3(String bucketName, String fileLink) {
        amazonS3Service.deleteFile(bucketName, fileLink);
    }

    /**
     * Сохранение файла в бакет
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToS3(String bucketName, String key, File file) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, key, file) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[saveFileToS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Сохранение файла в бакет ERROR
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToErrorS3(String bucketName, String key, File file) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, "error/" + key, file) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]: Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[saveFileToErrorS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }


    /**
     * Копирование файла в бакет
     *
     * @param sourceBucket      - имя исходного бакета
     * @param sourceKey         - имя исходного файла
     * @param destinationBucket - имя бакета назначения
     * @param destinationKey    - имя файла назначения
     */
    public void copyFileS3(String sourceBucket, String sourceKey, String destinationBucket, String destinationKey){
        try {
            amazonS3Service.copyFile(sourceBucket, sourceKey, destinationBucket, destinationKey);
        } catch (Exception e) {
            log.error("{}:[copyFileS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error:stackTrace:", LG.USBLOGERROR, e);
        }
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    public HttpStatus getS3StatusCode(String line) {
        return amazonS3Service.getStatusCode(line);
    }

}
