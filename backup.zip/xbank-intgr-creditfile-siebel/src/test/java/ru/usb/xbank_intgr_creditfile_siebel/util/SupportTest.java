package ru.usb.xbank_intgr_creditfile_siebel.util;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import ru.usb.xbank_intgr_creditfile_siebel.config.Configure;

import java.io.File;
import java.util.Optional;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SupportTest {

    private Support support;
    private Configure configure;


    @BeforeEach
    void setUp() {
        configure = new Configure();
        support = new Support(configure);
    }

    @Test
    void getCreditNameTest() {
        String creditName = support.getCreditName("C:\\AppServer\\Project\\Banking\\tbank\\xbank-intgr-creditfile-siebel\\transform\\rup_o_dos20241010125135\\00037021756592\\Уведомление + график платежей.pdf");
        System.out.println(creditName);
        assertEquals("Уведомление + график платежей.pdf", creditName);
    }

    @Test
    void getCreditNumber() {
        System.out.print("Separator=");
        System.out.println(Pattern.quote(File.separator));
        Optional<String> creditNumber = support.getCreditNumber("C:\\AppServer\\Project\\Banking\\tbank\\xbank-intgr-creditfile-siebel\\transform\\rup_o_dos20241010125135\\00037021756592\\Уведомление + график платежей.pdf");
        if (creditNumber.isPresent()) {
            System.out.println(creditNumber.get());
            assertEquals("00037021756592", creditNumber.get());
        } else {
            System.out.println("Credit number not found");
        }
    }

    @Test
    void checkIntNumDog() {
        boolean result = support.checkIntNumDog("00037021756592");
        System.out.println(result);
        assertTrue(result);
    }

    @Test
    void checkIntNumDogFalse() {
        boolean result = support.checkIntNumDog("0003702_1756592");
        System.out.println(result);
        assertFalse(result);
    }

}