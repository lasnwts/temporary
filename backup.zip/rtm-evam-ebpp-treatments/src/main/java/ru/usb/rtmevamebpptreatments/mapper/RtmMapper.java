package ru.usb.rtmevamebpptreatments.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.model.MessageFromRTM;
import ru.usb.rtmevamebpptreatments.model.RtmMessage;
import ru.usb.rtmevamebpptreatments.model.RtmParam;
import ru.usb.rtmevamebpptreatments.service.mail.ServiceMailError;

import java.util.ArrayList;
import java.util.List;


/**
 * Класс мапирования сообщений из РТМ (JSON) в объект POJO java
 */
@Component
public class RtmMapper {

    Logger logger = LoggerFactory.getLogger(RtmMapper.class);

    private final ServiceMailError serviceMailError;

    @Autowired
    public RtmMapper(ServiceMailError serviceMailError) {
        this.serviceMailError = serviceMailError;
    }

    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Метод мапирования сообщений из Кафка от РТМ в POJO
     *
     * @param rtmParamList строка с сообщением
     * @return - объект
     */
    public MessageFromRTM mapRTM(List<RtmParam> rtmParamList) {

        MessageFromRTM mapRTM = new MessageFromRTM();

        if (rtmParamList == null || rtmParamList.isEmpty()) {
            logger.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
            logger.error("{}:На маппер поступил объект NULL! Класс [RtmMapper] метод [mapRTM]", Elog.UsbLogError);
            logger.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-", Elog.UsbLogError);
            return null;
        }

/**
 * Сообщение получаемое от RTM
 * ACT_TYPE
 * CONTACT_ID
 * STATUS
 * CYCLE_CODE
 * CLIENT_HASH
 * CLIENT_ID
 * CLIENT_NAME
 * CERTIFICATE_NUMBER
 * BIRTH_DATE
 * MOBILE_PHONE
 * HOME_PHONE
 * PRESALE_TYPE
 * OFFER_TYPE_CODE
 * CAMPAIGNCODE
 * PRIORITY
 * START_DATE
 * END_DATE
 * CLIENT_SEGMENT
 * PRODUCT_ID
 * CONTRACT_NUM
 * CONTRACT_TYPE
 * CAMPAIGN_MNEM
 * FILIAL_ID
 * ACRM_CALL_DESCR
 * REGION_CODE
 * TIME_SHIFT
 * CLIENT_DID
 * OLD_CLIENT_HASH
 * CHANNEL_INFO
 * PARAM_INFO
 * ID
 * EVAM_ACTORID
 * EVAM_SCENARIO
 */

        rtmParamList.forEach(rtmParam-> {

                //ACT_TYPE
                if (rtmParam.getParamName().equalsIgnoreCase("ACT_TYPE")) {
                    mapRTM.setActType(rtmParam.getParamValue().trim());
                }

                // CONTACT_ID
                if (rtmParam.getParamName().equalsIgnoreCase("CONTACT_ID")) {
                    mapRTM.setContactId(rtmParam.getParamValue().trim());
                }

                /// STATUS
                if (rtmParam.getParamName().equalsIgnoreCase("STATUS")) {
                    mapRTM.setStatus(rtmParam.getParamValue().trim());
                }

                // CYCLE_CODE
                if (rtmParam.getParamName().equalsIgnoreCase("CYCLE_CODE")) {
                    mapRTM.setCycleCode(rtmParam.getParamValue().trim());
                }

                //CLIENT_HASH
                if (rtmParam.getParamName().equalsIgnoreCase("CLIENT_HASH")) {
                    mapRTM.setClientHash(rtmParam.getParamValue().trim());
                }

                //CLIENT_ID
                if (rtmParam.getParamName().equalsIgnoreCase("CLIENT_ID")) {
                    mapRTM.setClientId(rtmParam.getParamValue().trim());
                }

                //CLIENT_NAME
                if (rtmParam.getParamName().equalsIgnoreCase("CLIENT_NAME")) {
                    mapRTM.setClientName(rtmParam.getParamValue().trim());
                }

                // CERTIFICATE_NUMBER
                if (rtmParam.getParamName().equalsIgnoreCase("CERTIFICATE_NUMBER")) {
                    mapRTM.setCertificateNumber(rtmParam.getParamValue().trim());
                }

                // BIRTH_DATE
                if (rtmParam.getParamName().equalsIgnoreCase("BIRTH_DATE")) {
                    mapRTM.setBirthDate(rtmParam.getParamValue().trim());
                }

                // MOBILE_PHONE
                if (rtmParam.getParamName().equalsIgnoreCase("MOBILE_PHONE")) {
                    mapRTM.setMobilePhone(rtmParam.getParamValue().trim());
                }

                // HOME_PHONE
                if (rtmParam.getParamName().equalsIgnoreCase("HOME_PHONE")) {
                    mapRTM.setHomePhone(rtmParam.getParamValue().trim());
                }

                // PRESALE_TYPE
                if (rtmParam.getParamName().equalsIgnoreCase("PRESALE_TYPE")) {
                    mapRTM.setPresaleType(rtmParam.getParamValue().trim());
                }

                // OFFER_TYPE_CODE
                if (rtmParam.getParamName().equalsIgnoreCase("OFFER_TYPE_CODE")) {
                    mapRTM.setOfferTypeCode(rtmParam.getParamValue().trim());
                }

                // CAMPAIGNCODE
                if (rtmParam.getParamName().equalsIgnoreCase("CAMPAIGNCODE")) {
                    mapRTM.setCampaignCode(rtmParam.getParamValue().trim());
                }

                // PRIORITY
                if (rtmParam.getParamName().equalsIgnoreCase("PRIORITY")) {
                    mapRTM.setPriority(rtmParam.getParamValue().trim());
                }

                // START_DATE
                if (rtmParam.getParamName().equalsIgnoreCase("START_DATE")) {
                    mapRTM.setStartDate(rtmParam.getParamValue().trim());
                }

                // END_DATE
                if (rtmParam.getParamName().equalsIgnoreCase("END_DATE")) {
                    mapRTM.setEndDate(rtmParam.getParamValue().trim());
                }

                // CLIENT_SEGMENT
                if (rtmParam.getParamName().equalsIgnoreCase("CLIENT_SEGMENT")) {
                    mapRTM.setClientSegment(rtmParam.getParamValue().trim());
                }

                // PRODUCT_ID
                if (rtmParam.getParamName().equalsIgnoreCase("PRODUCT_ID")) {
                    mapRTM.setProductId(rtmParam.getParamValue().trim());
                }

                //CONTRACT_NUM
                if (rtmParam.getParamName().equalsIgnoreCase("CONTRACT_NUM")) {
                    mapRTM.setContactNum(rtmParam.getParamValue().trim());
                }


                // CONTRACT_TYPE
                if (rtmParam.getParamName().equalsIgnoreCase("CONTRACT_TYPE")) {
                    mapRTM.setContractType(rtmParam.getParamValue().trim());
                }

                // CAMPAIGN_MNEM
                if (rtmParam.getParamName().equalsIgnoreCase("CAMPAIGN_MNEM")) {
                    mapRTM.setCampaignMNem(rtmParam.getParamValue().trim());
                }

                // FILIAL_ID
                if (rtmParam.getParamName().equalsIgnoreCase("FILIAL_ID")) {
                    mapRTM.setFilialId(rtmParam.getParamValue().trim());
                }

                // ACRM_CALL_DESCR
                if (rtmParam.getParamName().equalsIgnoreCase("ACRM_CALL_DESCR")) {
                    mapRTM.setAcrmCallDescr(rtmParam.getParamValue().trim());
                }

                // REGION_CODE
                if (rtmParam.getParamName().equalsIgnoreCase("REGION_CODE")) {
                    mapRTM.setRegionCode(rtmParam.getParamValue().trim());
                }

                //TIME_SHIFT
                if (rtmParam.getParamName().equalsIgnoreCase("TIME_SHIFT")) {
                    mapRTM.setTimeShift(rtmParam.getParamValue().trim());
                }

                //CLIENT_DID
                if (rtmParam.getParamName().equalsIgnoreCase("CLIENT_DID")) {
                    mapRTM.setClientDid(rtmParam.getParamValue().trim());
                }
                //OLD_CLIENT_HASH
                if (rtmParam.getParamName().equalsIgnoreCase("OLD_CLIENT_HASH")) {
                    mapRTM.setOldClientHash(rtmParam.getParamValue().trim());
                }
                // CHANNEL_INFO
                if (rtmParam.getParamName().equalsIgnoreCase("CHANNEL_INFO")) {
                    mapRTM.setChannelInfo(rtmParam.getParamValue().trim());
                }
                // PARAM_INFO
                if (rtmParam.getParamName().equalsIgnoreCase("PARAM_INFO")) {
                    mapRTM.setParamInfo(rtmParam.getParamValue().trim());
                }

                // ID
                if (rtmParam.getParamName().equalsIgnoreCase("ID")) {
                    mapRTM.setId(rtmParam.getParamValue().trim());
                }

                // EVAM_ACTORID
                if (rtmParam.getParamName().equalsIgnoreCase("EVAM_ACTORID")) {
                    mapRTM.setEvamActorid(rtmParam.getParamValue().trim());
                }

                // EVAM_SCENARIO
                if (rtmParam.getParamName().equalsIgnoreCase("EVAM_SCENARIO")) {
                    mapRTM.setEvamScenario(rtmParam.getParamValue().trim());
                }
        });

        return mapRTM;

    }

    /**
     * Мапируем текстовое сообщение в RTM Params
     *
     * @param strMessage - строка
     * @return - Lsit<RtmParam></RtmParam>
     */
    public RtmMessage mapStringToRtmMessage(String strMessage) {

        List<RtmParam> messageRTM = new ArrayList<>();

        try {
            messageRTM = objectMapper.readValue(StringUtils.newStringUtf8(StringUtils.getBytesUtf8(strMessage)), new TypeReference<List<RtmParam>>() {
            });

            return new RtmMessage(messageRTM);

        } catch (JsonProcessingException e) {
            logger.error("{}:Warning : Ошибка при парсинге Json: {}", Elog.UsbLogError, e.getMessage());
            logger.error("{}:StackTrace:", Elog.UsbLogError, e);
            serviceMailError.sendMailError("Ошибка при парсинге Json:" + e.getMessage() + "\n\r" +
                    "Исходное сообщение:" + strMessage);
            return null;
        }

    }

}
