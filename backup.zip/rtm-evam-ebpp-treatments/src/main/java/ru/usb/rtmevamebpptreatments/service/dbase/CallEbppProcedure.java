package ru.usb.rtmevamebpptreatments.service.dbase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.mapper.MappingToRtm;
import ru.usb.rtmevamebpptreatments.model.MapDataToRTM;
import ru.usb.rtmevamebpptreatments.model.MessageFromRTM;
import ru.usb.rtmevamebpptreatments.service.SenderService;
import ru.usb.rtmevamebpptreatments.service.mail.ServiceMailError;

import java.sql.*;

@Service
public class CallEbppProcedure {

    private final SenderService senderService;
    private final ServiceMailError serviceMailError;
    private final MappingToRtm mappingToRtm;

    @Autowired
    public CallEbppProcedure(SenderService senderService, ServiceMailError serviceMailError,
                             MappingToRtm mappingToRtm) {
        this.senderService = senderService;
        this.serviceMailError = serviceMailError;
        this.mappingToRtm = mappingToRtm;
    }

    private static final Logger logger = LoggerFactory.getLogger(CallEbppProcedure.class);

    // Переменные для подключения к БД из файла properties
    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String user;

    @Value("${spring.datasource.password}")
    private String pass;

    @Value("${ebpp.timeout:30}")
    private int timeout;

    @Value("${ebpp.procedure}")
    private String procedure;

//    private String result; //Результат отработки процедуры


    @Nullable
    public String getProcedure(String clobBody, MessageFromRTM mapRTM, long threadId) {
        CallableStatement cstmt = null;
        String result = "";
        boolean catchFlag = false;
        try (Connection con = DriverManager.getConnection(url, user, pass)) {
            cstmt = con.prepareCall("{call " + procedure + "(?, ?)}");
            cstmt.setString(1, clobBody);
            cstmt.registerOutParameter(2, Types.VARCHAR);
            cstmt.setQueryTimeout(timeout);
            cstmt.execute();
            result = cstmt.getString(2);
            logger.info("{} Ответ процедуры Oracle:{}", Elog.UsbLogInfo, result);
        } catch (SQLException e) {
            logger.error("{}:Выполняем вызов процедуры: {} - Возникла ошибка SQLException", Elog.UsbLogError, procedure, e);
            catchFlag = true;
            MapDataToRTM dataToRTM = mappingToRtm.mappingRTM(mapRTM);
            dataToRTM.setEventType("EBPP_UPD_ERROR");
            sentMessageToRTM(e.getMessage(), dataToRTM, mapRTM); //Отправка сообщения с ошибками
        } finally {
            if (cstmt != null) {
                try {
                    cstmt.close();
                } catch (SQLException e) {
                    logger.error("{}:cstmt.close():Возникла ошибка SQLException", Elog.UsbLogError, e);
                }
            }
        }
        if (!catchFlag){
            if (result != null && result.toUpperCase().contains("SOURCE")){
                return result;
            } else {
                //Если процедура вернула, что то невнятное, но отработала
                MapDataToRTM dataToRTM = mappingToRtm.mappingRTM(mapRTM);
                dataToRTM.setEventType("EBPP_UPD_ERROR");
                dataToRTM.setErrorCode("4");
                dataToRTM.setErrorDetail("Сообщение отправлено в ЕБПП, но ЕБПП возвращает ошибку записи:" + result);
                logger.error("{}:Другие ошибки на шине, не относящиеся к другим кодам. Процедура вернула неверный вариант CLOBa:{}", Elog.UsbLogError, result);
                senderService.sendMessage(dataToRTM.toErrorCSV(), Thread.currentThread().getId());
                return null;
            }
        } else {
            return null;
        }
    }

    /**
     * Отправка сообщений с ошибками в РТМ
     *
     * @param exception - строка с ошибкой
     * @param dataToRTM - подготовленное сообщение
     */
    private void sentMessageToRTM(String exception, MapDataToRTM dataToRTM, MessageFromRTM mapRTM) {
        if (exception.toLowerCase().contains("could not establish the connection")) {
            dataToRTM.setErrorCode("1");
            dataToRTM.setErrorDetail("Нет сетевого доступа или не доступна БД:" + exception);
            logger.error("{}:Нет сетевого доступа или не доступна БД. Возникла ошибка SQLException:{}", Elog.UsbLogError, exception);
            senderService.sendMessage(dataToRTM.toErrorCSV(), Thread.currentThread().getId());
            serviceMailError.sendMailErrorSubject("Возникла ошибка, при вызове процедуры:" + procedure,
                    "Ошибка:\n\r" + exception + "\n\r" + "=-==============" + "\n\r" +
                            "Сообщение :\n\r" +
                            mapRTM.toString());
            return;
        }
        if (exception.toLowerCase().contains(" timed out")) {
            dataToRTM.setErrorCode("3");
            dataToRTM.setErrorDetail("Таймаут вызова процедуры в ЕБПП, не смогли вызвать процедуру:" + procedure + "; Error:" + exception);
            logger.error("{}:Таймаут вызова процедуры в ЕБПП, не смогли вызвать процедуру:{} - Возникла ошибка SQLException:{}", Elog.UsbLogError, procedure, exception);
            senderService.sendMessage(dataToRTM.toErrorCSV(), Thread.currentThread().getId());
            serviceMailError.sendMailErrorSubject("Возникла ошибка, Таймаут вызова процедуры в ЕБПП, не смогли вызвать процедуру:" + procedure,
                    "Ошибка:\n\r " + exception + "\n\r" + "================" + "\n\r" +
                            "Сообщение:\n\r" +
                            mapRTM.toString());
            return;
        }
        dataToRTM.setErrorCode("4");
        dataToRTM.setErrorDetail("Сообщение отправлено в ЕБПП, но ЕБПП возвращает ошибку записи:" + exception);
        logger.error("{}:Сообщение отправлено в ЕБПП, но ЕБПП возвращает ошибку записи::{}", Elog.UsbLogError, exception);
        senderService.sendMessage(dataToRTM.toErrorCSV(), Thread.currentThread().getId());
        serviceMailError.sendMailErrorSubject("Возникла ошибка, Сообщение отправлено в ЕБПП, но ЕБПП возвращает ошибку записи",
                "Ошибка:\n\r " + exception + "\n\r" + "===============" + "\n\r" +
                        "Сообщение:\n\r" +
                        mapRTM.toString());
    }

}
