package ru.usb.rtmevamebpptreatments.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.rtmevamebpptreatments.configure.Configure;
import ru.usb.rtmevamebpptreatments.configure.Elog;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class EmailServiceImpl implements EmailService {
    private final JavaMailSender emailSender;
    private final Configure configure;

    @Autowired
    public EmailServiceImpl(JavaMailSender emailSender, Configure configure) {
        this.emailSender = emailSender;
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Override
    public void sendSimpleEmail(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:: Переменные toAddress, subject, message не могут быть NULL!", Elog.UsbLogError);
            return;
        }

        logger.info("{}:Send email message, toAddress:{} |subject:{} [ |message:{}]", Elog.UsbLogInfo, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(configure.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:Email подготовлен к отправке по адресу:  {}", Elog.UsbLogInfo, mailRecepient);
                    try {
                        emailSender.send(simpleMailMessage);
                        logger.info("{}:Email отправлен отправке по адресу:{}  ", Elog.UsbLogInfo, mailRecepient);
                    } catch (Exception mailEx) {
                        logger.error("{}:Возникла ошибка при отправке письма:", Elog.UsbLogError, mailEx);
                    }
                });
            } else {
                logger.error("{}:  ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", Elog.UsbLogError);
            }
        } else {
            logger.error("{}:  ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", Elog.UsbLogError);
        }
    }

    @Override
    public void sendSimpleEmailThrow(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("{}:Error:: Переменные toAddress, subject, message не могут быть NULL!", Elog.UsbLogError);
            return;
        }

        logger.info("{}: Send email message, toAddress:{} |subject:{} [ |message:{}]", Elog.UsbLogInfo, toAddress, subject, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(configure.getMailFrom());
                    simpleMailMessage.setSubject(subject);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("{}:Email подготовлен к отправке по адресу:: {}", Elog.UsbLogInfo, mailRecepient);
                    emailSender.send(simpleMailMessage);
                    logger.info("{}:Email отправлен отправке по адресу::  {}", Elog.UsbLogInfo, mailRecepient);
                });
            } else {
                logger.error("{}:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", Elog.UsbLogError);
            }
        } else {
            logger.error("{}:ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!", Elog.UsbLogError);
        }
    }


    @Override
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment) {
        logger.info("{}: Send email [sendEmailWithAttachment] message, toAddress:{} |subject:{}  |message:{} |attachment:{}", Elog.UsbLogInfo,
                toAddress, subject, message, attachment);
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
            messageHelper.setFrom(configure.getMailFrom());
            String[] mailRecepients = toAddress.split(",");
            messageHelper.setTo(mailRecepients);
            messageHelper.setSubject(subject);
            messageHelper.setText(message);
            FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
            messageHelper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
        } catch (MessagingException | FileNotFoundException e) {
            logger.error("{}:Возникла ошибка при отправке письма, метод sendEmailWithAttachment: [MessagingException | FileNotFoundException]:", Elog.UsbLogError, e);
        }
        try {
            emailSender.send(mimeMessage);
        } catch (Exception mailEx){
            logger.error("{}:Возникла ошибка при отправке письма, метод sendEmailWithAttachment: [Exception]:", Elog.UsbLogError, mailEx);
        }
    }
}
