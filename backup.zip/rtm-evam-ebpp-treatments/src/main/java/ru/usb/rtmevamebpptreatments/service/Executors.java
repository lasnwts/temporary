package ru.usb.rtmevamebpptreatments.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.rtmevamebpptreatments.configure.Configure;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.mapper.CheckMapFromRTM;
import ru.usb.rtmevamebpptreatments.mapper.MappingToRtm;
import ru.usb.rtmevamebpptreatments.mapper.RtmMapper;
import ru.usb.rtmevamebpptreatments.model.MapDataToRTM;
import ru.usb.rtmevamebpptreatments.model.MessageFromRTM;
import ru.usb.rtmevamebpptreatments.service.dbase.CallEbppProcedure;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Executor service
 */

@Service
public class Executors {
    private final Configure configure;
    private final CallEbppProcedure ebppProcedure;
    private final SenderService senderService;
    private final RtmMapper rtmMapper;
    private final CheckMapFromRTM checkMapFromRTM;
    private final MappingToRtm mappingToRtm;


    /**
     * инициализация: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    @Autowired
    public Executors(Configure configure, CallEbppProcedure ebppProcedure, SenderService senderService,
                     RtmMapper rtmMapper, CheckMapFromRTM checkMapFromRTM, MappingToRtm mappingToRtm) {
        this.configure = configure;
        this.ebppProcedure = ebppProcedure;
        this.senderService = senderService;
        this.rtmMapper = rtmMapper;
        this.checkMapFromRTM = checkMapFromRTM;
        this.mappingToRtm = mappingToRtm;
    }

    Logger logger = LoggerFactory.getLogger(Executors.class);


    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody) {
        configure.setThreads(configure.getThreads() + 1);
        logger.info("{}:Запуск getTask потока, с сообщением:{}", Elog.UsbLogInfo, messageBody);
        logger.info("{}:Длина очереди задач:{}", Elog.UsbLogInfo, configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
            logger.error("{}:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", Elog.UsbLogError, e);
            logger.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
        }
        logger.info("{}:Поток передан на запуск в executor service. Поток с сообщением:{}", Elog.UsbLogInfo, messageBody);
    }

    class MyThread implements Runnable {
        String message;
        String kafkaMessage;
        CountDownLatch latch;


        MyThread(CountDownLatch c, String messageBody) {
            latch = c;
            message = messageBody;
            new Thread(this);
        }

        public void run() {
            logger.info("{}:Запуск потока id={}", Elog.UsbLogInfo, Thread.currentThread().getId());
            //Здесь проверки
            MessageFromRTM mapRTM = rtmMapper.mapRTM(rtmMapper.mapStringToRtmMessage(message).getRtmParamList());
            //Проверяем, что все параметры есть, если это так - вызываем процедуру в ЕБПП, иначе отправляем ошибку
            if (checkMapFromRTM.checkMapRtm(mapRTM)) {
                //Здесь вызов процедуры
                senderService.sendMessage(ebppProcedure.getProcedure(message, mapRTM, Thread.currentThread().getId()), Thread.currentThread().getId());
            } else {
                //Здесь формируем сообщение об ошибке, при парсинге
                MapDataToRTM dataToRTM = mappingToRtm.mappingRTM(mapRTM);
                dataToRTM.setEventType("EBPP_UPD_ERROR");
                dataToRTM.setErrorCode("2");
                dataToRTM.setErrorDetail(checkMapFromRTM.getErrorDetail(mapRTM));
                logger.error("{}: Создан объект для отправки в EMS на РТМ, по ошибке, что нет обязательных аттрибутов={}", Elog.UsbLogInfo, dataToRTM.getErrorDetail());
                //Отправляем в EMS сообщение
                senderService.sendMessage(dataToRTM.toErrorCSV(), Thread.currentThread().getId());
            }
            //Подвал завершения потока
            logger.info("{}:Поток завершен id={}", Elog.UsbLogInfo, Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            logger.info("{}:::Длина очереди задач={}", Elog.UsbLogInfo, configure.getThreads());
        }
    }


}
