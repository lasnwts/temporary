package ru.usb.rtmevamebpptreatments.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageProcess {

    Logger logger = LoggerFactory.getLogger(MessageProcess.class);

    private final Executors executors;

    @Autowired
    public MessageProcess(Executors executors) {
        this.executors = executors;
    }

    public void processWorker(String body){
        executors.getTask(body);
    }

}
