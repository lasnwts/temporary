package ru.usb.rtmevamebpptreatments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Сообщение получаемое от RTM
 * ACT_TYPE
 * CONTACT_ID
 * STATUS
 * CYCLE_CODE
 * CLIENT_HASH
 * CLIENT_ID
 * CLIENT_NAME
 * CERTIFICATE_NUMBER
 * BIRTH_DATE
 * MOBILE_PHONE
 * HOME_PHONE
 * PRESALE_TYPE
 * OFFER_TYPE_CODE
 * CAMPAIGNCODE
 * PRIORITY
 * START_DATE
 * END_DATE
 * CLIENT_SEGMENT
 * PRODUCT_ID
 * CONTRACT_NUM
 * CONTRACT_TYPE
 * CAMPAIGN_MNEM
 * FILIAL_ID
 * ACRM_CALL_DESCR
 * REGION_CODE
 * TIME_SHIFT
 * CLIENT_DID
 * OLD_CLIENT_HASH
 * CHANNEL_INFO
 * PARAM_INFO
 * ID
 * EVAM_ACTORID
 * EVAM_SCENARIO
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageFromRTM {

    @JsonProperty("ACT_TYPE")
    private String actType;

    @JsonProperty("CONTACT_ID")
    private String contactId;

    @JsonProperty("STATUS")
    private String status;

    @JsonProperty("CYCLE_CODE")
    private String cycleCode;

    @JsonProperty("CLIENT_HASH")
    private String clientHash;

    @JsonProperty("CLIENT_ID")
    private String clientId;

    @JsonProperty("CLIENT_NAME")
    private String clientName;

    @JsonProperty("CERTIFICATE_NUMBER")
    private String certificateNumber;

    @JsonProperty("BIRTH_DATE")
    private String birthDate;

    @JsonProperty("MOBILE_PHONE")
    private String mobilePhone;

    @JsonProperty("HOME_PHONE")
    private String homePhone;

    @JsonProperty("PRESALE_TYPE")
    private String presaleType;

    @JsonProperty("OFFER_TYPE_CODE")
    private String offerTypeCode;

    @JsonProperty("CAMPAIGNCODE")
    private String campaignCode;

    @JsonProperty("PRIORITY")
    private String priority;

    @JsonProperty("START_DATE")
    private String startDate;

    @JsonProperty("END_DATE")
    private String endDate;

    @JsonProperty("CLIENT_SEGMENT")
    private String clientSegment;

    @JsonProperty("PRODUCT_ID")
    private String productId;

    @JsonProperty("CONTRACT_NUM")
    private String contactNum;

    @JsonProperty("CONTRACT_TYPE")
    private String contractType;

    @JsonProperty("CAMPAIGN_MNEM")
    private String campaignMNem;

    @JsonProperty("FILIAL_ID")
    private String filialId;

    @JsonProperty("ACRM_CALL_DESCR")
    private String acrmCallDescr;

    @JsonProperty("REGION_CODE")
    private String regionCode;

    @JsonProperty("TIME_SHIFT")
    private String timeShift;

    @JsonProperty("CLIENT_DID")
    private String clientDid;

    @JsonProperty("OLD_CLIENT_HASH")
    private String oldClientHash;

    @JsonProperty("CHANNEL_INFO")
    private String channelInfo;

    @JsonProperty("PARAM_INFO")
    private String paramInfo;

    @JsonProperty("ID")
    private String id;

    @JsonProperty("EVAM_ACTORID")
    private String evamActorid;

    @JsonProperty("EVAM_SCENARIO")
    private String evamScenario;

    public MessageFromRTM() {
        //
    }

    public MessageFromRTM(String actType, String contactId, String status, String cycleCode, String clientHash,
                          String clientId, String clientName, String certificateNumber, String birthDate,
                          String mobilePhone, String homePhone, String presaleType, String offerTypeCode,
                          String campaignCode, String priority, String startDate, String endDate, String clientSegment,
                          String productId, String contactNum, String contractType, String campaignMNem, String filialId,
                          String acrmCallDescr, String regionCode, String timeShift, String clientDid,
                          String oldClientHash, String channelInfo, String paramInfo, String id,
                          String evamActorid, String evamScenario) {
        this.actType = actType;
        this.contactId = contactId;
        this.status = status;
        this.cycleCode = cycleCode;
        this.clientHash = clientHash;
        this.clientId = clientId;
        this.clientName = clientName;
        this.certificateNumber = certificateNumber;
        this.birthDate = birthDate;
        this.mobilePhone = mobilePhone;
        this.homePhone = homePhone;
        this.presaleType = presaleType;
        this.offerTypeCode = offerTypeCode;
        this.campaignCode = campaignCode;
        this.priority = priority;
        this.startDate = startDate;
        this.endDate = endDate;
        this.clientSegment = clientSegment;
        this.productId = productId;
        this.contactNum = contactNum;
        this.contractType = contractType;
        this.campaignMNem = campaignMNem;
        this.filialId = filialId;
        this.acrmCallDescr = acrmCallDescr;
        this.regionCode = regionCode;
        this.timeShift = timeShift;
        this.clientDid = clientDid;
        this.oldClientHash = oldClientHash;
        this.channelInfo = channelInfo;
        this.paramInfo = paramInfo;
        this.id = id;
        this.evamActorid = evamActorid;
        this.evamScenario = evamScenario;
    }

    public String getActType() {
        return actType;
    }

    public void setActType(String actType) {
        this.actType = actType;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCycleCode() {
        return cycleCode;
    }

    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }

    public String getClientHash() {
        return clientHash;
    }

    public void setClientHash(String clientHash) {
        this.clientHash = clientHash;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public String getPresaleType() {
        return presaleType;
    }

    public void setPresaleType(String presaleType) {
        this.presaleType = presaleType;
    }

    public String getOfferTypeCode() {
        return offerTypeCode;
    }

    public void setOfferTypeCode(String offerTypeCode) {
        this.offerTypeCode = offerTypeCode;
    }

    public String getCampaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getClientSegment() {
        return clientSegment;
    }

    public void setClientSegment(String clientSegment) {
        this.clientSegment = clientSegment;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getContactNum() {
        return contactNum;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getCampaignMNem() {
        return campaignMNem;
    }

    public void setCampaignMNem(String campaignMNem) {
        this.campaignMNem = campaignMNem;
    }

    public String getFilialId() {
        return filialId;
    }

    public void setFilialId(String filialId) {
        this.filialId = filialId;
    }

    public String getAcrmCallDescr() {
        return acrmCallDescr;
    }

    public void setAcrmCallDescr(String acrmCallDescr) {
        this.acrmCallDescr = acrmCallDescr;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getTimeShift() {
        return timeShift;
    }

    public void setTimeShift(String timeShift) {
        this.timeShift = timeShift;
    }

    public String getClientDid() {
        return clientDid;
    }

    public void setClientDid(String clientDid) {
        this.clientDid = clientDid;
    }

    public String getOldClientHash() {
        return oldClientHash;
    }

    public void setOldClientHash(String oldClientHash) {
        this.oldClientHash = oldClientHash;
    }

    public String getChannelInfo() {
        return channelInfo;
    }

    public void setChannelInfo(String channelInfo) {
        this.channelInfo = channelInfo;
    }

    public String getParamInfo() {
        return paramInfo;
    }

    public void setParamInfo(String paramInfo) {
        this.paramInfo = paramInfo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEvamActorid() {
        return evamActorid;
    }

    public void setEvamActorid(String evamActorid) {
        this.evamActorid = evamActorid;
    }

    public String getEvamScenario() {
        return evamScenario;
    }

    public void setEvamScenario(String evamScenario) {
        this.evamScenario = evamScenario;
    }

    @Override
    public String toString() {
        return "MessageFromRTM{" +
                "actType='" + actType + '\'' +
                ", contactId='" + contactId + '\'' +
                ", status='" + status + '\'' +
                ", cycleCode='" + cycleCode + '\'' +
                ", clientHash='" + clientHash + '\'' +
                ", clientId='" + clientId + '\'' +
                ", clientName='" + clientName + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", homePhone='" + homePhone + '\'' +
                ", presaleType='" + presaleType + '\'' +
                ", offerTypeCode='" + offerTypeCode + '\'' +
                ", campaignCode='" + campaignCode + '\'' +
                ", priority='" + priority + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", clientSegment='" + clientSegment + '\'' +
                ", productId='" + productId + '\'' +
                ", contactNum='" + contactNum + '\'' +
                ", contractType='" + contractType + '\'' +
                ", campaignMNem='" + campaignMNem + '\'' +
                ", filialId='" + filialId + '\'' +
                ", acrmCallDescr='" + acrmCallDescr + '\'' +
                ", regionCode='" + regionCode + '\'' +
                ", timeShift='" + timeShift + '\'' +
                ", clientDid='" + clientDid + '\'' +
                ", oldClientHash='" + oldClientHash + '\'' +
                ", channelInfo='" + channelInfo + '\'' +
                ", paramInfo='" + paramInfo + '\'' +
                ", id='" + id + '\'' +
                ", evamActorid='" + evamActorid + '\'' +
                ", evamScenario='" + evamScenario + '\'' +
                '}';
    }
}
