package ru.usb.rtmevamebpptreatments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Параметр из сообщения RTM
 * Пример:
 * {
 * "PARAM_NAME": "CERTIFICATE_NUMBER",
 * "PARAM_TYPE": "STRING",
 * "PARAM_VALUE": "8009 929682"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RtmParam {

    //PARAM_NAME - имя параметра
    @JsonProperty("PARAM_NAME")
    private String paramName;

    //PARAM_TYPE - тип параметра
    @JsonProperty("PARAM_TYPE")
    private String paramType;

    //PARAM_VALUE - значение переменной
    @JsonProperty("PARAM_VALUE")
    private String paramValue;

    public RtmParam() {
    }

    public RtmParam(String paramName, String paramType, String paramValue) {
        this.paramName = paramName;
        this.paramType = paramType;
        this.paramValue = paramValue;
    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public String getParamType() {
        return paramType;
    }

    public void setParamType(String paramType) {
        this.paramType = paramType;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    @Override
    public String toString() {
        return "RtmParam{" +
                "paramName='" + paramName + '\'' +
                ", paramType='" + paramType + '\'' +
                ", paramValue='" + paramValue + '\'' +
                '}';
    }
}
