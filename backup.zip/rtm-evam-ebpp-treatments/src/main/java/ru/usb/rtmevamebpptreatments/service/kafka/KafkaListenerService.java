package ru.usb.rtmevamebpptreatments.service.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.service.MessageProcess;
import ru.usb.rtmevamebpptreatments.service.mail.ServiceMailError;
import ru.usb.rtmevamebpptreatments.utils.AuxMethods;


@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;
    private final AuxMethods aux;
    private final MessageProcess messageProcess;

    @Autowired
    public KafkaListenerService(ServiceMailError serviceMailError, AuxMethods aux, MessageProcess messageProcess) {
        this.serviceMailError = serviceMailError;
        this.aux = aux;
        this.messageProcess = messageProcess;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.attempt:4}")
    private int countAttempt;

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {

        ack.acknowledge(); //Сообщение забираем сразу

        if (logDebug) {
            logger.info("{}:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", Elog.UsbLogInfo, recordKafka.offset());
            logger.info("{}:KafkaListener(record.partition) == {}", Elog.UsbLogInfo, recordKafka.partition());
            logger.info("{}:KafkaListener(record.key)       == {}", Elog.UsbLogInfo, recordKafka.key());
            logger.info("{}:KafkaListener (record.value)    == {}", Elog.UsbLogInfo, recordKafka.value());
            logger.info("{}:KafkaListener(topic)            == {}", Elog.UsbLogInfo, recordKafka.topic());
            logger.info("{}:KafkaListener(Offset)           == {}", Elog.UsbLogInfo, recordKafka.offset());
            logger.info("{}:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", Elog.UsbLogInfo);
        }


        if (recordKafka.value() == null) {
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
            logger.error("{}:: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!", Elog.UsbLogError);
            logger.error("{}::+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", Elog.UsbLogError, recordKafka.offset());
            logger.error("{}::KafkaListener(record.partition) == {}", Elog.UsbLogError, recordKafka.partition());
            logger.error("{}::KafkaListener(record.key)       == {}", Elog.UsbLogError, recordKafka.key());
            logger.error("{}::KafkaListener(record.value)     == {}", Elog.UsbLogError, recordKafka.value());
            logger.error("{}::KafkaListener(topic)            == {}", Elog.UsbLogError, recordKafka.topic());
            logger.error("{}::KafkaListener(Offset)           == {}", Elog.UsbLogError, recordKafka.offset());
            logger.error("{}::++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", Elog.UsbLogError);
            logger.error("{}::!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Elog.UsbLogError);
            serviceMailError.sendMailErrorSubject(" Сообщение из Kafka пришло пустое", aux.getWrapNull(recordKafka.value()) + "\n\r" +
                    "KafkaListener(Offset)" + recordKafka.offset());
        }


        /**
         * Обработка сообщения
         * @param message  - тело сообщения
         */
        messageProcess.processWorker(recordKafka.value());
    }
}
