package ru.usb.rtmevamebpptreatments.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.model.MessageFromRTM;

/**
 * Класс проверки сообщений из РТМ на полноту параметров
 */

@Component
public class CheckMapFromRTM {
    Logger logger = LoggerFactory.getLogger(CheckMapFromRTM.class);

    /**
     * Проверка что все параметры есть
     *
     * @param mapRTM = MapRTM
     * @return = все параметры есть, false - нет всех параметров
     * ==============================================================
     * Обязательные параметры
     * ==============================================================
     * Параметр для процедуры ЕБПП	ACT_TYPE	Y	STRING	Как есть
     * CONTACT_ID	CONTACT_ID	Y	NUMBER	Как есть
     * Не передается в ЕБПП	ID	Y	NUMBER	Параметр для обратной связи
     * Не передается в ЕБПП	EVAM_ACTORID	Y	STRING	Параметр для обратной связи
     * ==============================================================
     */
    public boolean checkMapRtm(MessageFromRTM mapRTM) {

        if (mapRTM == null) {
            return false;
        }

        //ACT_TYPE
        if (mapRTM.getActType() == null || mapRTM.getActType().trim().isEmpty()) {
            logger.error("{}:checkMapRtm:Не указан ACT_TYPE", Elog.UsbLogError);
            return false;
        }


        //CONTACT_ID
        if (mapRTM.getContactId() == null || mapRTM.getContactId().trim().isEmpty()) {
            logger.error("{}:checkMapRtm:Не указан CONTACT_ID", Elog.UsbLogError);
            return false;
        }


        //EVAM_ACTORID
        if (mapRTM.getEvamActorid() == null || mapRTM.getEvamActorid().trim().isEmpty()) {
            logger.error("{}:checkMapRtm:Не указан EVAM_ACTORID", Elog.UsbLogError);
            return false;
        }

        //ID
        if (mapRTM.getId() == null || mapRTM.getId().trim().isEmpty()) {
            logger.error("{}:checkMapRtm:Не указан ID", Elog.UsbLogError);
            return false;
        }
        return true;
    }


    /**
     * Формирование вербального описания ошибки, в случае отсутствия обязательных параметров
     *
     * @param mapRTM - сообщение из РТМ
     * @return - описания строкой
     */
    public String getErrorDetail(MessageFromRTM mapRTM) {

        String errorDetail = "Отсутствуют обязательные атрибуты:";

        //ACT_TYPE
        if (mapRTM.getContactId() == null || mapRTM.getContactId().trim().isEmpty()) {
            errorDetail = errorDetail + "не указан CONTACT_ID,";
        }

        //CONTACT_ID
        if (mapRTM.getActType() == null || mapRTM.getActType().trim().isEmpty()) {
            errorDetail = errorDetail + "не указан CONTACT_ID,";
        }

        //EVAM_ACTORID
        if (mapRTM.getEvamActorid() == null || mapRTM.getEvamActorid().trim().isEmpty()) {
            errorDetail = errorDetail + "не указан EVAM_ACTORID,";
        }

        //ID
        if (mapRTM.getId() == null || mapRTM.getId().trim().isEmpty()) {
            errorDetail = errorDetail + "не указан ID,";
        }
        return removeComma(errorDetail);
    }

    /**
     * Remove trailing comma, убрать крайнюю запятую
     *
     * @return строка без запятой в конце
     */
    private String removeComma(String line) {
        if (line.substring(line.length() - 1).equalsIgnoreCase(",")) {
            return line.substring(0, line.length() - 1);
        } else {
            return line;
        }

    }
}
