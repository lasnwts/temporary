package ru.usb.rtmevamebpptreatments;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.rtmevamebpptreatments.configure.Configure;
import ru.usb.rtmevamebpptreatments.configure.Elog;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class RtmEvamEbppTreatmentsApplication implements CommandLineRunner {

	private final Configure configure;

	Logger logger = LoggerFactory.getLogger(RtmEvamEbppTreatmentsApplication.class);

	@Autowired
	public RtmEvamEbppTreatmentsApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(RtmEvamEbppTreatmentsApplication.class, args);
	}


	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r Сервис передачи данных из РТМ в ЕБПП (канал предложений).")
				.contact(new Contact().email("lyapustinas@smartsoftware.ru"))
				.version(appVersion)
				.description("API для МП 973339. Инициативы 8589 КЛИЕНТСКИЙ ОПЫТ. Обновление предложений в ЕБПП из РТМ" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}


	@Override
	public void run(String... args) throws Exception {

		/***
		 * Проверка путей
		 */
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
				FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", Elog.UsbLogInfo, path);
		} else {
			logger.info("{}:Directory {}  = already exists", Elog.UsbLogInfo, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));

		logger.info("{}:+--------------------------------------------------------------------------------------------------------------------+", Elog.UsbLogInfo);
		logger.info("{}: Created by 24.04.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", Elog.UsbLogInfo);
		logger.info("{}:----------------------------------------------------------------------------------------------------------------------", Elog.UsbLogInfo);
		logger.info("{}: Описание пакетов                  :", Elog.UsbLogInfo);
		logger.info("{}:----------------------------------------------------------------------------------------------------------------------+", Elog.UsbLogInfo);
		logger.info("{}: configure                         :  Конфигурационные классы;", Elog.UsbLogInfo);
		logger.info("{}: controller                        :  Rest Controller для тестов и управления;", Elog.UsbLogInfo);
		logger.info("{}: mapper                            :  Мапперы Rtm->Kafka-jdbc-Parameters;", Elog.UsbLogInfo);
		logger.info("{}: model                             :  POJO;", Elog.UsbLogInfo);
		logger.info("{}: service                           :  Сервисы по приему сообщений, передаче сообщений", Elog.UsbLogInfo);
		logger.info("{}: utils                             :  Различные утилиты", Elog.UsbLogInfo);
		logger.info("{}: Name of service                   : {}", Elog.UsbLogInfo, configure.getAppName());
		logger.info("{}: Description of service            : {}", Elog.UsbLogInfo, configure.getAppDescription());
		logger.info("{}: Количество потоков                : {}", Elog.UsbLogInfo, configure.getServicePoolSize());
		logger.info("{}:=---------------------------------------------------------------------------------------------------------------------=", Elog.UsbLogInfo);
		logger.info("{}: Modified reason                   : 0.0.10", Elog.UsbLogInfo);
		logger.info("{}:-----------------------------------------------------------------------------------------------------------------------", Elog.UsbLogInfo);

	}
}
