package ru.usb.rtmevamebpptreatments.model;

public class MapDataToRTM {

    /**
     * 'SOURCE'
     * "'CHANNEL_event'"
     */
    private String source;


    /**
     * 'EVENT_TYPE'
     * "'IBSO_SUCCESS'"
     */
    private String eventType;

    /**
     * 'ID'
     * concat("'" , $Parse-JSON/ns2:ActivityOutputClass/root/PARAM[PARAM_NAME='ID']/PARAM_VALUE, "'")
     */
    private String id;

    /**
     * 'CLIENT_ID'
     * concat("'" , $Parse-JSON/ns2:ActivityOutputClass/root/PARAM[PARAM_NAME='CLIENT_ID']/PARAM_VALUE, "'")
     */
    private String clientID;


    /**
     * 'CLIENT_DID'
     * concat("'" , $Parse-JSON/ns2:ActivityOutputClass/root/PARAM[PARAM_NAME='CLIENT_DID']/PARAM_VALUE, "'")
     */
    private String clientDID;


    /**
     * 'EVENT_DATETIME'
     * concat("'" , translate(substring-before(current-dateTime(), '.'), 'T', ' '), "'")
     */
    private String eventDateTime;

    /**
     * 'CONTACT_ID'
     * concat("'" , $Parse-JSON/ns2:ActivityOutputClass/root/PARAM[PARAM_NAME='CONTACT_ID']/PARAM_VALUE, "'")
     */
    private String contactID;

    /**
     * Новые парметры
     * EVAM_ACTORID
     * EVAM_SCENARIO
     */
    private String ewamActorid;
    private String ewamScenario;

    /**
     * 'ERROR_CODE'
     * MApErrRTM = 2
     */
    private String errorCode;


    /**
     * 'ERROR_DETAIL'
     */
    private String errorDetail;

    public MapDataToRTM() {
        //
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    public void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    /**
     * Реализация
     */


    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public String getClientDID() {
        return clientDID;
    }

    public void setClientDID(String clientDID) {
        this.clientDID = clientDID;
    }

    public String getEventDateTime() {
        return eventDateTime;
    }

    public void setEventDateTime(String eventDateTime) {
        this.eventDateTime = eventDateTime;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public String getEwamActorid() {
        return ewamActorid;
    }

    public void setEwamActorid(String ewamActorid) {
        this.ewamActorid = ewamActorid;
    }

    public String getEwamScenario() {
        return ewamScenario;
    }

    public void setEwamScenario(String ewamScenario) {
        this.ewamScenario = ewamScenario;
    }


    @Override
    public String toString() {
        return "MapData{" +
                "source='" + source + '\'' +
                ", eventType='" + eventType + '\'' +
                ", id='" + id + '\'' +
                ", clientID='" + clientID + '\'' +
                ", clientDID='" + clientDID + '\'' +
                ", eventDateTime='" + eventDateTime + '\'' +
                ", contactID='" + contactID + '\'' +
                ", ewamActorid='" + ewamActorid + '\'' +
                ", ewamScenario='" + ewamScenario + '\'' +
                '}';
    }

    /**
     * Отправка сообщения в EMS
     *
     * @return
     */
    public String toCSV() {
        return "SOURCE" + "," + getWrapNull(source) + "," +
                "EVENT_TYPE" + "," + getWrapNull(eventType) + "," +
                "ID" + "," + getNumeric(id) + "," +
                getEmptyParameters("CLIENT_ID" + "," + getWrapNull(clientID) + ",", clientID) +
                getEmptyParameters("CLIENT_DID" + "," + getWrapNull(clientDID) + ",", clientDID) +
                "EVAM_ACTORID" + "," + getWrapNull(getEwamActorid()) + "," +
                getEmptyParameters("EVAM_SCENARIO" + "," + getWrapNull(getEwamScenario()) + ",", ewamScenario) +
                "EVENT_DATETIME" + "," + eventDateTime + "," +
                "CONTACT_ID" + "," + getWrapNull(contactID);
    }

    /**
     * Отправка сообщения в EMS
     *
     * @return
     */
    public String toErrorCSV() {
        return "SOURCE" + "," + getWrapNull(source) + "," +
                "EVENT_TYPE" + "," + getWrapNull(eventType) + "," +
                "ID" + "," + getNumeric(id) + "," +
                getEmptyParameters("CLIENT_ID" + "," + getWrapNull(clientID) + ",", clientID) +
                getEmptyParameters("CLIENT_DID" + "," + getWrapNull(clientDID) + ",", clientDID) +
                "EVAM_ACTORID" + "," + getWrapNull(getEwamActorid()) + "," +
                getEmptyParameters("EVAM_SCENARIO" + "," + getWrapNull(getEwamScenario()) + ",", ewamScenario) +
                "EVENT_DATETIME" + "," + eventDateTime + "," +
                "CONTACT_ID" + "," + getWrapNull(contactID) + "," +
                "ERROR_CODE" + "," + getWrapNull(errorCode) + "," +
                "ERROR_DETAIL" + ",'" + get4000Symbols(getDelSingleQuote(getWrapNull(errorDetail))) + "'";
    }

    /**
     * Возвращаем число или пустое место вместо числа
     *
     * @param parameter - строковый параметр
     * @return - число
     */
    private String getNumeric(String parameter) {
        if (parameter == null) {
            return "";
        }
        if (parameter.isEmpty()) {
            return "";
        }
        if (parameter.length() == 0) {
            return "";
        }
        try {
            Long.parseLong(parameter);
        } catch (NumberFormatException nfe) {
            return "";
        }
        return parameter.trim();
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Замена одинарных кавычек двойными
     *
     * @param line- переданная строка
     * @return - строка после обработки
     */
    private String getDelSingleQuote(String line) {
        return line.replace("'", "\"");
     }

    /**
     * Обрезаем строку до 4000 символов
     *
     * @param line - строка до обрезания
     * @return - усеченная строка
     */
    private String get4000Symbols(String line) {
        if (line.length() > 3999) {
            return line.substring(0, 3999);
        }
        return line;
    }

    /**
     * Проверка необязательных параметров. Если параметры естьЮ, включаем их, если нет, то нет
     * ------------------------------------------------------------------------------------------
     * Проверяем наличие:
     * ------------------
     * CLIENT_ID
     * CLIENT_DID
     * EVAM_SCENARIO
     * ------------------
     *
     * @param line      - вся строка
     * @param parameter - параметр
     * @return - результат
     */
    private String getEmptyParameters(String line, String parameter) {
        if (parameter == null || parameter.trim().isEmpty()) {
            return "";
        } else {
            return line;
        }
    }


}
