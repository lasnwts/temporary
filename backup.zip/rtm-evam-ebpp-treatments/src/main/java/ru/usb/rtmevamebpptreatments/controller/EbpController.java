package ru.usb.rtmevamebpptreatments.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.rtmevamebpptreatments.configure.Configure;
import ru.usb.rtmevamebpptreatments.configure.Elog;
import ru.usb.rtmevamebpptreatments.mapper.CheckMapFromRTM;
import ru.usb.rtmevamebpptreatments.mapper.RtmMapper;
import ru.usb.rtmevamebpptreatments.model.MessageFromRTM;
import ru.usb.rtmevamebpptreatments.service.MessageProcess;
import ru.usb.rtmevamebpptreatments.service.UploadService;
import ru.usb.rtmevamebpptreatments.utils.Sutils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с ЕБПП", description = "Передаем Json в базу данных (процедуру) ЕБПП")
public class EbpController {

    private final UploadService uploadService;
    private final Sutils sutils;
    private final MessageProcess messageProcess;
    private final RtmMapper rtmMapper;
    private final CheckMapFromRTM checkMapFromRTM;
    private final Configure configure;

    @Autowired
    public EbpController(UploadService uploadService, Sutils sutils, MessageProcess messageProcess,
                         RtmMapper rtmMapper, CheckMapFromRTM checkMapFromRTM, Configure configure) {
        this.uploadService = uploadService;
        this.sutils = sutils;
        this.messageProcess = messageProcess;
        this.rtmMapper = rtmMapper;
        this.checkMapFromRTM = checkMapFromRTM;
        this.configure = configure;
    }

    private final Logger logger = LoggerFactory.getLogger(EbpController.class);

    @PostMapping(
            path = "/check",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Проверка файла JSON на наличие обязательных полей.")
    public ResponseEntity<String> handleUpload(
            @RequestPart("file") MultipartFile file) {

        logger.info("{}: POST запрос (требуется загрузить файл вручную): .api/v1/check:file", Elog.UsbLogInfo);

        File fileInput = null;
        MessageFromRTM mapRTM = null;
        try {
            fileInput = new File(uploadService.uploadFileToServer(file));
            if (sutils.checkFileExists(fileInput)) {
                logger.info("{}: Получен файл:{} ", Elog.UsbLogInfo, fileInput.getName());
                logger.info("{}: Путь к файлу ::{}", Elog.UsbLogInfo, fileInput.getPath());
                logger.info("{}: Размер файл ::{}", Elog.UsbLogInfo, fileInput.length());
                //Здесь проверки
                mapRTM = rtmMapper.mapRTM(rtmMapper.mapStringToRtmMessage(sutils.getContentFile(fileInput, Charset.forName(configure.getFileCharset()))).getRtmParamList());
                //Проверяем, что все параметры есть, если это так - вызываем процедуру в ЕБПП, иначе отправляем ошибку
                if (checkMapFromRTM.checkMapRtm(mapRTM)) {
                    //Здесь вызов процедуры
                    return ResponseEntity.status(HttpStatus.OK).body("Документ валиден.");
                } else {
                    //Здесь формируем сообщение об ошибке, при парсинге
                    logger.error("{}: Ошибка, нет обязательных аттрибутов={}", Elog.UsbLogInfo, checkMapFromRTM.getErrorDetail(mapRTM));
                    return new ResponseEntity<>("Ошибка. Документ не валиден.\n" + " нет обязательных аттрибутов:" + checkMapFromRTM.getErrorDetail(mapRTM), HttpStatus.BAD_REQUEST);
                }
            }
        } catch (IOException e) {
            logger.error("{}: Возникла ошибка загрузки файла на сервер:", Elog.UsbLogInfo, e);
            return new ResponseEntity<>("Ошибка.Документ не валиден.\n\r" + " Возникла ошибка загрузки файла на сервер:" + getErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("{}: Возникла ошибка парсинга сообщения в MessageFromRTM:", Elog.UsbLogInfo, e);
            return new ResponseEntity<>("Ошибка. Документ не  валиден \n\r" + " Возникла ошибка парсинга сообщения в MessageFromRTM::" + getErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("Документ не валиден.", HttpStatus.BAD_REQUEST);
    }


    @PostMapping(
            path = "/load",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Передача файла JSON в процедуру ЕБПП.")
    public ResponseEntity<String> handleLoad(
            @RequestPart("file") MultipartFile file) {

        logger.info("{}:POST запрос (требуется загрузить файл вручную):api/v1/load:file", Elog.UsbLogInfo);

        File fileInput = null;
        MessageFromRTM mapRTM = null;
        try {
            fileInput = new File(uploadService.uploadFileToServer(file));
            if (sutils.checkFileExists(fileInput)) {
                logger.info("{}:Получен файл  :{} ", Elog.UsbLogInfo, fileInput.getName());
                logger.info("{}:Путь к файлу ::{}", Elog.UsbLogInfo, fileInput.getPath());
                logger.info("{}:Размер файла ::{}", Elog.UsbLogInfo, fileInput.length());
                //Здесь проверки
                mapRTM = rtmMapper.mapRTM(rtmMapper.mapStringToRtmMessage(sutils.getContentFile(fileInput, Charset.forName(configure.getFileCharset()))).getRtmParamList());
                //Проверяем, что все параметры есть, если это так - вызываем процедуру в ЕБПП, иначе отправляем ошибку
                if (checkMapFromRTM.checkMapRtm(mapRTM)) {
                    //Здесь вызов процедуры
                    messageProcess.processWorker(sutils.getContentFile(fileInput, Charset.forName(configure.getFileCharset())));
                    return ResponseEntity.status(HttpStatus.OK).body("Документ отправлен в базу ЕБПП.");
                } else {
                    //Здесь формируем сообщение об ошибке, при парсинге
                    logger.error("{}: Ошибка,нет обязательных аттрибутов={}", Elog.UsbLogInfo, checkMapFromRTM.getErrorDetail(mapRTM));
                    return new ResponseEntity<>("Ошибка. Документ не валиден.\n" + " нет обязательных аттрибутов:" + checkMapFromRTM.getErrorDetail(mapRTM), HttpStatus.BAD_REQUEST);
                }
            }
        } catch (IOException e) {
            logger.error("{}: Возникла ошибка загрузки файла на сервер:", Elog.UsbLogInfo, e);
            return new ResponseEntity<>("Ошибка. Документ не валиден.\n\r" + " Возникла ошибка загрузки файла на сервер:" + getErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("{}: Возникла ошибка парсинга сообщения в MessageFromRTM:", Elog.UsbLogInfo, e);
            return new ResponseEntity<>("Ошибка. Документ не валиден.\n\r" + " Возникла ошибка парсинга сообщения в MessageFromRTM::" + getErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("Документ не валиден.", HttpStatus.BAD_REQUEST);
    }
    /**
     * Приведение к разумному ответу, если сообщение n null
     * @param line - сообщение
     * @return - результат
     */
    private String getErrorMessage(String line){
        if (line==null){
            return " сообщение пустое";
        }
        return line.trim().substring(0,80);
    }
}