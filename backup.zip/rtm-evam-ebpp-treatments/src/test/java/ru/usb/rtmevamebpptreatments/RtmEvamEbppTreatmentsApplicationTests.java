package ru.usb.rtmevamebpptreatments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtmEvamEbppTreatmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
