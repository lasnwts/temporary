package ru.usb.afs955083pu.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.afs955083pu.config.Configure;
import ru.usb.afs955083pu.model.AnswerErrorMessage;
import ru.usb.afs955083pu.model.VW_RPT_HIST_CARD;
import ru.usb.afs955083pu.repository.JpaRptHistCardRepository;
import ru.usb.afs955083pu.utils.StrUtils;
import ru.usb.afs955083pu.utils.WorkWithFiles;

import javax.persistence.EntityManager;
import java.nio.file.FileSystems;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
public class GetRptHistCard {

    private static String FILENAME = "vw_rpt_hist_card_";

    private String fileCSV;

    Logger logger = LoggerFactory.getLogger(GetRptHistCard.class);

    @Autowired
    Configure configure;

    @Autowired
    JpaRptHistCardRepository jpaRptHistCardRepository;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    StrUtils strUtils;

    @Autowired
    AnswerErrorMessage errorMessage;

    private EntityManager entityManager;

    public GetRptHistCard(JpaRptHistCardRepository jpaRptHistCardRepository, EntityManager entityManager) {
        this.jpaRptHistCardRepository = jpaRptHistCardRepository;
        this.entityManager = entityManager;
    }

    @Transactional(readOnly = true)
    public AnswerErrorMessage getAllRecords(AnswerErrorMessage errorMessage) {
        Stream<VW_RPT_HIST_CARD> fTableStream = null;

        try {
            fTableStream = jpaRptHistCardRepository.getAll();
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage("!Error! An error occurred: fTableStream = jpaRptHistCardRepository.getAll()" + e.getMessage());
            return errorMessage;
        }

        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  fTableStream = jpaRptHistCardRepository.getAll() == NULL     !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage("!Error! TableStream = jpaRptHistCardRepository.getAll() == NULL");
            return errorMessage;
        }

        try {
            AtomicInteger rownum = new AtomicInteger();
            logger.info("###################################################################################");
            logger.info("#  Output VW_RPT_HIST_CARD to a file                                              #");
            logger.info("###################################################################################");

            /**
             * Получаем имя файл
             */
            fileCSV = configure.getFileDirectory() + FileSystems.getDefault().getSeparator() + FILENAME + withFiles.getCurrentTimeStamp() + "." + configure.getExtFile();

            /**
             * Выводим заголовок CSV
             */
            logger.info("Filename={}", fileCSV);
            if (configure.isServiceDebug()) {
                logger.info(withFiles.getHeaderCsv("VW_RPT_HIST_CARD"));
            }

            //Вывод заголовка в файл
            withFiles.wFPP(withFiles.getHeaderCsv("VW_RPT_HIST_CARD").replace(";", configure.getSeparateSymbol()), fileCSV, configure.isCharsetUTF());

            //Инициализируем переменную
            fTableStream.forEach(fTable -> {
                rownum.getAndIncrement();

                //Запись строки в файл
                //withFiles.wFPP(fTable.toCsv(), fileCSV, configure.isCharsetUTF());

                String s = fTable.getID() + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getCLASS_ID(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getSTATE_ID(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getSTATE_CARD(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getCLIENT(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getCLIENTNAME(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getWAY4_ID(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getCARDID(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getHASH(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getPAN(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        withFiles.getDateStr(fTable.getHTIME()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getUSER_ID(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getU2_NAME(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        withFiles.getDateStr(fTable.getHTIME2()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getUSER_ID2(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getU2_NAME(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getSUMM(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getNUM(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getSTAT(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol();

                withFiles.wFPP(s, fileCSV, configure.isCharsetUTF());

                if (configure.isServiceDebug()) {
                    logger.info(s);
                }

                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while write information to a file {} }!!!!!!", fileCSV);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage(" An error occurred while write information to a file::" + e.getMessage());
        } finally {
            //Закрываем файл
            fTableStream.close();
        }
        logger.info("###### < Ended process write file {} #####", fileCSV);
        return errorMessage;
    }

}


