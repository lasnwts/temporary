package ru.usb.afs955083pu.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class WorkWithFiles {

    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }


    /**
     * Получение заголовкой CSV файлов
     *
     * @return строка - заголовок
     */
    public String getHeaderCsv(String model) {
        switch (model) {

            case "VW_RPT_HIST_CARD":
                return "ID;CLASS_ID;STATE_ID;STATE_CARD;CLIENT;CLIENTNAME;WAY4_ID;CARDID;HASH;PAN;HTIME;USER_ID;U_NAME;HTIME2;USER_ID2;U2_NAME;SUMM;NUM;STAT;";
            case "VW_RPT_AFS_CLIENT_START":
                return "id; class_id;cl_name;client;cl_date;born_place;doc;adr_reg;adr_fac;date_first;staff;segment;segment_date;";
            default:
                logger.error("Произошла ошибка, нужно остановить программу!");
                break;
        }
        return null;
    }


    /**
     * Возвращает Дату_Время в виде строки
     *
     * @return
     */
    public String getCurrentTimeStamp() {
        return new SimpleDateFormat("ddMMyyyy HH:mm:ss").format(new Date()).replace(":", "_").replace(" ", "_");
    }

    /**
     * Возвращает Дату Время в виде строки     *
     *
     * @return
     */
    public String getDateStr(Date date) {
        if (date == null) {
            return "";
        } else {
            return new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(date);
        }
    }

    /**
     * Возвращает Дату в виде строки     *
     *
     * @return
     */
    public String getDate(Date date) {
        if (date == null) {
            return "";
        } else {
            return new SimpleDateFormat("dd.MM.yyyy").format(date);
        }
    }

    /**
     * Запись в файл
     *
     * @param line         - строка для записи
     * @param fullFileName - имя файла
     * @param charSetUTF   - кодировка
     */
    public void wFPP(String line, String fullFileName, boolean charSetUTF) {
        FileWriterPP.write(fullFileName, line, charSetUTF);
        FileWriterPP.write(fullFileName, "\r\n", charSetUTF);
    }

}
