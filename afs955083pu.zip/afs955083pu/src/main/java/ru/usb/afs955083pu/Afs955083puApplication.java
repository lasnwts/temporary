package ru.usb.afs955083pu;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.afs955083pu.config.Configure;
import ru.usb.afs955083pu.model.AnswerErrorMessage;
import ru.usb.afs955083pu.service.ServiceMailError;
import ru.usb.afs955083pu.service.processed.GetAfsClientStartProcessed;
import ru.usb.afs955083pu.service.processed.GetRptHistCard;
import ru.usb.afs955083pu.utils.WorkWithFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@EnableSwagger2
@SpringBootApplication
public class Afs955083puApplication implements CommandLineRunner {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    GetRptHistCard getRptHistCard;

    @Autowired
    GetAfsClientStartProcessed getAfsClientStartProcessed;

    @Autowired
    ServiceMailError serviceMailError;

    Logger logger = LoggerFactory.getLogger(Afs955083puApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(Afs955083puApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        // Показываем версию
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Version of service:" + configure.getAppVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        //ППроверяем существование директории, куда будут выложены файлы
        Path path = Paths.get(configure.getFileDirectory());
        if (!Files.exists(path)) {
			logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Error!! Directory {} - not exists! Error!", path.toString());
			logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        } else {
            logger.info("Directory {} = already exists.", path.toString());
        }


        // Проверка наличия директорий
        if (withFiles.checkPathExists(configure.getFileDirectory())) {
            logger.info("Success. Директория для выгрузки файлов CSV существует:{}", configure.getFileDirectory());
        } else {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Error. Директория для выгрузки файлов CSV  НЕ существует:{}", configure.getFileDirectory());
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }


        /**
         * Test
         */
        AnswerErrorMessage answerErrorMessage = new AnswerErrorMessage("",false);
//        answerErrorMessage = getRptHistCard.getAllRecords(answerErrorMessage);
//        if (answerErrorMessage.isErrorFlag()) {
//            serviceMailError.sendMailError("Возникла ошибка в процессе выгрузки файла. " + answerErrorMessage.getErrorMessage());
//        }
        answerErrorMessage = getAfsClientStartProcessed.getAllRecords(answerErrorMessage);
        if (answerErrorMessage.isErrorFlag()) {
            serviceMailError.sendMailError("Возникла ошибка в процессе выгрузки файла. " + answerErrorMessage.getErrorMessage());
        }


    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service afs955083pu", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Задача №955083 .Rest Api Title 07/12/2022")
                .description("Api Definition by @alexander")
                .version(configure.getAppVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }

}
