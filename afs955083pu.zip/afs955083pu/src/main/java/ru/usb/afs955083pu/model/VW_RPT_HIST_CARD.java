package ru.usb.afs955083pu.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Entity
public class VW_RPT_HIST_CARD {

    @Id
    private long ID;
    private String CLASS_ID;
    private String STATE_ID;
    private String STATE_CARD;
    private String CLIENT;
    private String CLIENTNAME;
    private String WAY4_ID;
    private String CARDID;
    private String HASH;
    private String PAN;

    @Temporal(TemporalType.TIMESTAMP)
    private Date HTIME;
    private String USER_ID;
    private String U_NAME;

    @Temporal(TemporalType.TIMESTAMP)
    private Date HTIME2;
    private String USER_ID2;
    private String U2_NAME;
    private String SUMM;
    private String NUM;
    private String STAT;

    public VW_RPT_HIST_CARD() {
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public String getCLASS_ID() {
        return CLASS_ID;
    }

    public void setCLASS_ID(String CLASS_ID) {
        this.CLASS_ID = CLASS_ID;
    }

    public String getSTATE_ID() {
        return STATE_ID;
    }

    public void setSTATE_ID(String STATE_ID) {
        this.STATE_ID = STATE_ID;
    }

    public String getSTATE_CARD() {
        return STATE_CARD;
    }

    public void setSTATE_CARD(String STATE_CARD) {
        this.STATE_CARD = STATE_CARD;
    }

    public String getCLIENT() {
        return CLIENT;
    }

    public void setCLIENT(String CLIENT) {
        this.CLIENT = CLIENT;
    }

    public String getCLIENTNAME() {
        return CLIENTNAME;
    }

    public void setCLIENTNAME(String CLIENTNAME) {
        this.CLIENTNAME = CLIENTNAME;
    }

    public String getWAY4_ID() {
        return WAY4_ID;
    }

    public void setWAY4_ID(String WAY4_ID) {
        this.WAY4_ID = WAY4_ID;
    }

    public String getCARDID() {
        return CARDID;
    }

    public void setCARDID(String CARDID) {
        this.CARDID = CARDID;
    }

    public String getHASH() {
        return HASH;
    }

    public void setHASH(String HASH) {
        this.HASH = HASH;
    }

    public String getPAN() {
        return PAN;
    }

    public void setPAN(String PAN) {
        this.PAN = PAN;
    }

    public Date getHTIME() {
        return HTIME;
    }

    public void setHTIME(Date HTIME) {
        this.HTIME = HTIME;
    }

    public String getUSER_ID() {
        return USER_ID;
    }

    public void setUSER_ID(String USER_ID) {
        this.USER_ID = USER_ID;
    }

    public String getU_NAME() {
        return U_NAME;
    }

    public void setU_NAME(String u_NAME) {
        U_NAME = u_NAME;
    }

    public Date getHTIME2() {
        return HTIME2;
    }

    public void setHTIME2(Date HTIME2) {
        this.HTIME2 = HTIME2;
    }

    public String getUSER_ID2() {
        return USER_ID2;
    }

    public void setUSER_ID2(String USER_ID2) {
        this.USER_ID2 = USER_ID2;
    }

    public String getU2_NAME() {
        return U2_NAME;
    }

    public void setU2_NAME(String u2_NAME) {
        U2_NAME = u2_NAME;
    }

    public String getSUMM() {
        return SUMM;
    }

    public void setSUMM(String SUMM) {
        this.SUMM = SUMM;
    }

    public String getNUM() {
        return NUM;
    }

    public void setNUM(String NUM) {
        this.NUM = NUM;
    }

    public String getSTAT() {
        return STAT;
    }

    public void setSTAT(String STAT) {
        this.STAT = STAT;
    }

    @Override
    public String toString() {
        return "VW_RPT_HIST_CARD{" +
                "ID=" + ID +
                ", CLASS_ID='" + CLASS_ID + '\'' +
                ", STATE_ID='" + STATE_ID + '\'' +
                ", STATE_CARD='" + STATE_CARD + '\'' +
                ", CLIENT='" + CLIENT + '\'' +
                ", CLIENTNAME='" + CLIENTNAME + '\'' +
                ", WAY4_ID='" + WAY4_ID + '\'' +
                ", CARDID='" + CARDID + '\'' +
                ", HASH='" + HASH + '\'' +
                ", PAN='" + PAN + '\'' +
                ", HTIME=" + HTIME +
                ", USER_ID='" + USER_ID + '\'' +
                ", U_NAME='" + U_NAME + '\'' +
                ", HTIME2=" + HTIME2 +
                ", USER_ID2='" + USER_ID2 + '\'' +
                ", U2_NAME='" + U2_NAME + '\'' +
                ", SUMM='" + SUMM + '\'' +
                ", NUM='" + NUM + '\'' +
                ", STAT='" + STAT + '\'' +
                '}';
    }


    public String toCsv() {
        return ID + ";" + CLASS_ID + ";" + STATE_ID + ";" + STATE_CARD + ";" + CLIENT + ";" + CLIENTNAME + ";" + WAY4_ID + ";"
                + CARDID + ";" + HASH + ";" + PAN + ";" + HTIME + ";" + USER_ID + ";" + U_NAME + ";" + HTIME2 + ";" + USER_ID2 +
                ";" + U2_NAME + ";" + SUMM + ";" + NUM + ";" + STAT + ";";
    }


}
