package ru.usb.afs955083pu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.afs955083pu.model.VW_RPT_HIST_CARD;

import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaRptHistCardRepository extends JpaRepository<VW_RPT_HIST_CARD, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value ="select ID,CLASS_ID,STATE_ID,STATE_CARD,CLIENT,CLIENTNAME,WAY4_ID,CARDID,HASH,PAN,HTIME,USER_ID,U_NAME,HTIME2,USER_ID2,U2_NAME,SUMM,NUM,STAT from VW_RPT_HIST_CARD", nativeQuery = true)
    Stream<VW_RPT_HIST_CARD> getAll();

}
