package ru.usb.afs955083pu.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class StrUtils {

    private String separator = "QUOTE_SEMICOLON";

    private String sDelimiter = ";";

    Logger logger = LoggerFactory.getLogger(StrUtils.class);

    /**
     * Функция заменяющая точку с запятой на QUOTE_SEMICOLON
     *
     * @param line - строка
     * @return - строка с замененной частью
     */
    public String replaceSemicolon(String line, String delimiter, String separatorSymbol) {

        if (separatorSymbol == null) {
            separatorSymbol = separator;
        }

        if (delimiter == null) {
            delimiter = sDelimiter;
        }

        if (line != null && !line.isEmpty()) {
            return line.replace(delimiter, separatorSymbol);
        } else {
            return "";
        }
    }
}
