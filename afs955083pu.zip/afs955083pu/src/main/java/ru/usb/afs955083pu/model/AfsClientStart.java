package ru.usb.afs955083pu.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "VW_CRIT_USB_IMG_DREF_SIEBEL")
public class AfsClientStart {

    @Id
    private long id;
    private String class_id;
    private String  cl_name;
    private String client;
    private Date cl_date;
    private String born_place;
    private String doc;
    private String adr_reg;
    private String adr_fac;
    private Date date_first;
    private String staff;
    private String segment;
    private Date segment_date;

    public AfsClientStart() {
    }

    public AfsClientStart(long id, String class_id, String cl_name, String client, Date cl_date, String born_place,
                          String doc, String adr_reg, String adr_fac, Date date_first, String staff, String segment, Date segment_date) {
        this.id = id;
        this.class_id = class_id;
        this.cl_name = cl_name;
        this.client = client;
        this.cl_date = cl_date;
        this.born_place = born_place;
        this.doc = doc;
        this.adr_reg = adr_reg;
        this.adr_fac = adr_fac;
        this.date_first = date_first;
        this.staff = staff;
        this.segment = segment;
        this.segment_date = segment_date;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getCl_name() {
        return cl_name;
    }

    public void setCl_name(String cl_name) {
        this.cl_name = cl_name;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public Date getCl_date() {
        return cl_date;
    }

    public void setCl_date(Date cl_date) {
        this.cl_date = cl_date;
    }

    public String getBorn_place() {
        return born_place;
    }

    public void setBorn_place(String born_place) {
        this.born_place = born_place;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getAdr_reg() {
        return adr_reg;
    }

    public void setAdr_reg(String adr_reg) {
        this.adr_reg = adr_reg;
    }

    public String getAdr_fac() {
        return adr_fac;
    }

    public void setAdr_fac(String adr_fac) {
        this.adr_fac = adr_fac;
    }

    public Date getDate_first() {
        return date_first;
    }

    public void setDate_first(Date date_first) {
        this.date_first = date_first;
    }

    public String getStaff() {
        return staff;
    }

    public void setStaff(String staff) {
        this.staff = staff;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public Date getSegment_date() {
        return segment_date;
    }

    public void setSegment_date(Date segment_date) {
        this.segment_date = segment_date;
    }

    @Override
    public String toString() {
        return "AfsClientStart{" +
                "id=" + id +
                ", class_id='" + class_id + '\'' +
                ", cl_name='" + cl_name + '\'' +
                ", client='" + client + '\'' +
                ", cl_date=" + cl_date +
                ", born_place='" + born_place + '\'' +
                ", doc='" + doc + '\'' +
                ", adr_reg='" + adr_reg + '\'' +
                ", adr_fac='" + adr_fac + '\'' +
                ", date_first=" + date_first +
                ", staff='" + staff + '\'' +
                ", segment='" + segment + '\'' +
                ", segment_date=" + segment_date +
                '}';
    }
}
