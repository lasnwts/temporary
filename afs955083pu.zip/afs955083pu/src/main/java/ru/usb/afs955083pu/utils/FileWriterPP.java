package ru.usb.afs955083pu.utils;

import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;


/**
 * Запись файла
 */
public class FileWriterPP {

    public static void write(String fileName, String text, boolean charsetUTF) {
        //Определяем файл
        File file = new File(fileName);

        try {
            //проверяем, что если файл не существует то создаем его
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = null;
            //PrintWriter обеспечит возможности записи в файл
            if (charsetUTF) {
                fw = new FileWriter(file.getAbsoluteFile(), Charset.forName("UTF8"), true);
            } else {
                fw = new FileWriter(file.getAbsoluteFile(), Charset.forName("windows-1251"), true);
            }
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(text);

            try {

                if (bw != null)
                    bw.close();

                if (fw != null)
                    fw.close();

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
