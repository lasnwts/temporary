package ru.usb.afs955083pu.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.afs955083pu.config.Configure;
import ru.usb.afs955083pu.model.MessageError;

import javax.mail.internet.AddressException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class ServiceMailError {


    public static final long MINUTE = 60 * 1000; // in milli-seconds.

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ServiceMailError.class);

    @Autowired
    MessageError messageError;

    @Autowired
    Configure configure;

    @Autowired
    EmailServiceImpl emailService;

    /**
     * Проверка когда отправляли почту в последний раз
     *
     * @return -- true - можно отправлять письмо, false - еще не прошло время с последней отправки
     */
    public boolean checkMail() {
        if (messageError.getDate() == null) {
            logger.info("Email error еще ни разу не отправлялся с момента запуска сервиса, можно отправлять.");
            return true;
        } else {
            if (new Date().after(new Date(messageError.getDate().getTime() + configure.getMailDelayMinutes() * MINUTE))) {
                logger.info("Email error был отправлен:" + sdf.format(messageError.getDate()) + ", сейчас::" + sdf.format(new Date()) +
                        " что превысило время ожидания в минутах:" + configure.getMailDelayMinutes() + " => можно отправлять.");
                return true;
            } else {
                logger.info("Email error был отправлен:" + sdf.format(messageError.getDate()) + ", сейчас::" + sdf.format(new Date()) +
                        " время ожидания в минутах:" + configure.getMailDelayMinutes() + " отправлять нельзя.");
                return false;
            }
        }
    }

    /**
     * Отправка почтового сообщения администраторам
     *
     * @param body - тело сообщения
     */
    public void sendMailError(String body) {
        if (checkMail()) {
            try {
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), body);
                messageError.setBody(body);
                messageError.setCount(messageError.getCount() + 1);
                messageError.setSubject(configure.getMailSubjects());
                messageError.setDate(new Date());
                logger.info("Отправлено письмо по адресам:" + configure.getMailTo() + "Сообщение:" + messageError.toString());
            } catch (Exception e) {
                logger.error("!!ERROR Ошибка отправки письма по адресам:" + configure.getMailTo() + "Сообщение:" + messageError.toString());
                throw new RuntimeException(e);
            }
        }
    }
}
