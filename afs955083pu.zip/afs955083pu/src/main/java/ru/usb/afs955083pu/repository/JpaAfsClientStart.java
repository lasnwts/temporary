package ru.usb.afs955083pu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.afs955083pu.model.AfsClientStart;

import javax.persistence.QueryHint;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaAfsClientStart extends JpaRepository<AfsClientStart, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"),
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value ="select id, class_id,cl_name,client,cl_date,born_place,doc,adr_reg,adr_fac," +
            "date_first,staff,segment,segment_date from VW_RPT_AFS_CLIENT_START", nativeQuery = true)
    Stream<AfsClientStart> getAllRecord();

}
