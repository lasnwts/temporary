package ru.usb.afs955083pu.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.afs955083pu.config.Configure;
import ru.usb.afs955083pu.model.AfsClientStart;
import ru.usb.afs955083pu.model.AnswerErrorMessage;
import ru.usb.afs955083pu.model.VW_RPT_HIST_CARD;
import ru.usb.afs955083pu.repository.JpaAfsClientStart;
import ru.usb.afs955083pu.repository.JpaRptHistCardRepository;
import ru.usb.afs955083pu.utils.StrUtils;
import ru.usb.afs955083pu.utils.WorkWithFiles;

import javax.persistence.EntityManager;
import java.nio.file.FileSystems;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
public class GetAfsClientStartProcessed {

    private static String FILENAME = "VW_RPT_AFS_CLIENT_START_";

    private String fileCSV;

    Logger logger = LoggerFactory.getLogger(GetAfsClientStartProcessed.class);

    @Autowired
    Configure configure;

    @Autowired
    JpaAfsClientStart jpaAfsClientStart;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    StrUtils strUtils;

    @Autowired
    AnswerErrorMessage errorMessage;

    private EntityManager entityManager;

    public GetAfsClientStartProcessed(JpaAfsClientStart jpaAfsClientStart, EntityManager entityManager) {
        this.jpaAfsClientStart = jpaAfsClientStart;
        this.entityManager = entityManager;
    }

    @Transactional(readOnly = true)
    public AnswerErrorMessage getAllRecords(AnswerErrorMessage errorMessage) {
        Stream<AfsClientStart> fTableStream = null;

        try {
            fTableStream = jpaAfsClientStart.getAllRecord();
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!getAllRecords!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!! fTableStream = jpaAfsClientStart.getAllRecord();!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage("!Error! An error occurred: fTableStream = jpaAfsClientStart.getAllRecord()::" + e.getMessage());
            return errorMessage;
        }

        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!! fTableStream = jpaAfsClientStart.getAllRecord();!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  fTableStream = jpaRptHistCardRepository.getAll() == NULL     !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage("!Error!  fTableStream = jpaAfsClientStart.getAllRecord(): == NULL");
            return errorMessage;
        }

        try {
            AtomicInteger rownum = new AtomicInteger();
            logger.info("###################################################################################");
            logger.info("#  Output VW_RPT_AFS_CLIENT_START to a file                                       #");
            logger.info("###################################################################################");

            /**
             * Получаем имя файл
             */
            fileCSV = configure.getFileDirectory() + FileSystems.getDefault().getSeparator() + FILENAME + withFiles.getCurrentTimeStamp() + "." + configure.getExtFile();

            /**
             * Выводим заголовок CSV
             */
            logger.info("Filename={}", fileCSV);
            if (configure.isServiceDebug()) {
                logger.info(withFiles.getHeaderCsv("VW_RPT_AFS_CLIENT_START"));
            }

            //Вывод заголовка в файл
            withFiles.wFPP(withFiles.getHeaderCsv("VW_RPT_AFS_CLIENT_START").replace(";", configure.getSeparateSymbol()), fileCSV, configure.isCharsetUTF());

            //Инициализируем переменную
            fTableStream.forEach(fTable -> {
                rownum.getAndIncrement();

                //Запись строки в файл
                //withFiles.wFPP(fTable.toCsv(), fileCSV, configure.isCharsetUTF());

                String s = fTable.getId() + configure.getSeparateSymbol() +

                        strUtils.replaceSemicolon(fTable.getClass_id(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getCl_name(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getClient(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        withFiles.getDate(fTable.getCl_date()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getBorn_place(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getDoc(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getAdr_reg(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getAdr_fac(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        withFiles.getDate(fTable.getDate_first()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getStaff(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        strUtils.replaceSemicolon(fTable.getSegment(), configure.getSeparateSymbol(), configure.getSeparateReplacel()) + configure.getSeparateSymbol() +
                        withFiles.getDate(fTable.getSegment_date()) + configure.getSeparateSymbol();

                withFiles.wFPP(s, fileCSV, configure.isCharsetUTF());

                if (configure.isServiceDebug()) {
                    logger.info(s);
                }

                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while write information to a file {} }!!!!!!", fileCSV);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
            logger.error("PrintStackTrace::", e);
            errorMessage.setErrorFlag(true);
            errorMessage.setErrorMessage(" An error occurred while write information to a file::" + e.getMessage());
        } finally {
            //Закрываем файл
            fTableStream.close();
        }
        logger.info("###### < Ended process write file {} #####", fileCSV);
        return errorMessage;
    }


}
