package ru.usb.afs955083pu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Afs955083puApplicationTests {

	@Test
	void contextLoads() {
	}

}
