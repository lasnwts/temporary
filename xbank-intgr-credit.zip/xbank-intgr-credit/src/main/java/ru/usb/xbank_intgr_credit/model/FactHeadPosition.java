package ru.usb.xbank_intgr_credit.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class FactHeadPosition {
    private int s;//1
    private int date;//2
    private int oper;//3
    private int sum;//4
    private int valuta;//5
}
