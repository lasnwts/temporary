package ru.usb.xbank_intgr_credit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.xbank_intgr_credit.model.db.TBankRunHistory;

import javax.persistence.QueryHint;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface TBankRunHistoryRepo extends JpaRepository<TBankRunHistory, Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select * from tbank_run_history where microservice =:name and end_time is null and rownum=1")
    TBankRunHistory getByMName(String name);

}
