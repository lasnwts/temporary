package ru.usb.xbank_intgr_credit.service.xloadfile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.service.loadfile.LoadUnBKI;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

@Service
public class ExecutorsUnloadBki {
    /**
     * host.timeout=60
     * host.delta=20
     */
    @Value("${host.timeout:60}")
    private long hostTimeOut;

    @Value("${host.delta:10}")
    private long delta;


    private final Configure configure;
    private final LoadUnBKI loadUnBKI;

    @Autowired
    public ExecutorsUnloadBki(Configure configure, LoadUnBKI loadUnBKI) {
        this.configure = configure;
        this.loadUnBKI = loadUnBKI;
    }

    /**
     * инициализация: ExecutorService executorService = ExecutorsAccBalance.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    Logger log = LoggerFactory.getLogger(ExecutorsUnloadBki.class);

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(Path path) {
        configure.setThreads(configure.getThreads() + 1);
        File file = path.toFile();
        log.info("{}:T{} Запуск getTask потока, с сообщением:{}", LG.USBLOGERROR, Thread.currentThread().getId(), file.getName());
        log.info("{}:T{} Длина очереди задач:{}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new ExecutorsUnloadBki.MyThread(cdl, file));
        } catch (Exception e) {
            log.error("{}:T{} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
            log.error("{}:T{} Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.USBLOGERROR, Thread.currentThread().getId(), e);
            log.error("{}:T{} =!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.USBLOGERROR, Thread.currentThread().getId());
        }
        log.info("{}:T{} Поток передан на запуск в executor service. Поток с файлом:{}", LG.USBLOGINFO, Thread.currentThread().getId(), file.getAbsolutePath());
    }

    class MyThread implements Runnable {
        File localFile;
        CountDownLatch latch;

        MyThread(CountDownLatch c, File file) {
            latch = c;
            localFile = file;
            new Thread(this);
        }

        public void run() {
            log.info("{}: Запуск потока id={}", LG.USBLOGINFO, Thread.currentThread().getId());
            /**-
             * Основной процесс
             * @param value - сообщение из Кафка
             */
            log.info("{}:T{}: Поток запущен для обработки файла={}", LG.USBLOGINFO, Thread.currentThread().getId(), localFile.getAbsolutePath());
            List<LoadError> loadErrors = null;
            try {
                loadErrors = loadUnBKI.loadFile(localFile, Thread.currentThread().getId());
                if (!loadErrors.isEmpty()) {
                    log.error("{}:T{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, Thread.currentThread().getId(), loadErrors.size());
                    loadErrors.forEach(loadError -> log.info("{}:T{}:=: {}", LG.USBLOGERROR, Thread.currentThread().getId(), loadError));
                    configure.setLoadErrorsListUnloadBki(loadErrors); //Какие возникли ошибки
                }
                //Подвал завершения потока
                log.info("{}:T{} Поток завершен id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
                configure.setThreads(configure.getThreads() - 1);
                log.info("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
            } catch (Exception e) {
                configure.setSyncErrorOnProcessed(true);
                log.error("{}:T{}: Ошибка при загрузке файла в БД citymigration, файл {}, ошибка:{}",
                        LG.USBLOGERROR, Thread.currentThread().getId(), localFile.getAbsolutePath(), e.getMessage());
                //Подвал аварийного завершения потока
                log.info("{}:T{} Поток завершен с ошибкой id={}", LG.USBLOGINFO, Thread.currentThread().getId(), Thread.currentThread().getId());
                configure.setThreads(configure.getThreads() - 1);
                log.info("{}:T{}: :Длина очереди задач={}", LG.USBLOGINFO, Thread.currentThread().getId(), configure.getThreads());
            }
        }
    }
}
