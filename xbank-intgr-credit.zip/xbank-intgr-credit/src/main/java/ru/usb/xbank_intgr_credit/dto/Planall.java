package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_PLANALL")
public class Planall {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    //S;DATE;DATE_BEG;DATE_END;OPER;SUM;CHANGE;VALUTA

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора

    @Column(name = "DATEO")//3
    private Date date;//Дата планового платежа

    @Column(name = "DATE_BEG")//4
    private Date dateBeg;//Дата начала периода

    @Column(name = "DATE_END")//5
    private Date dateEnd;//Дата окончания периода

    @Column(name = "OPER")//6
    private String oper;//Вид плановой операции по договору

    @Column(name = "SUM")//7
    private BigDecimal sum;//;Сумма планового платежа

    @Column(name = "CHANGE")//8
    private String change;//Вариант изменения планового графика

    @Column(name = "VALUTA")//9
    private String valuta;//Код валюты операции

    //Имя файла
    @Column(name = "FILENAME")//10
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//11
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//12
    private long numInsert; //Номер вставки

}
