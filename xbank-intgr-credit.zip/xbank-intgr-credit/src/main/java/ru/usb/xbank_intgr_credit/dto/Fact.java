package ru.usb.xbank_intgr_credit.dto;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * Информация о фактических операциях
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_FACT")
public class Fact {
    //S;DATE;OPER;SUM;VALUTA;FILENAME;INPUT_DATE

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S") //2
    private String s;//'ВКИ (внутренний код для импорта) договора TBK_Idкредита

    @Column(name = "DATEO")//дата операции
    private Date date;//3

    @Column(name = "OPER")//тип операции
    private String oper;//4

    @Column(name = "SUM")//сумма операции
    private BigDecimal sum;//5

    @Column(name = "VALUTA")//валюта операции
    private String valuta;//6

    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки
}