package ru.usb.xbank_intgr_credit.dto;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

//файл =prc_scheme.csv
//S;P_CODE;PRC;DATE_BEG;DATE_END

/**
 * Информация о процентных схемах
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TBANK_PRC_SCHEME")
public class PrcScheme {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

    @Column(name = "S") //2
    private String s;//ВКИ (внутренний код для импорта) договора;Код процентной схемы

    @Column(name = "P_CODE")//3
    private String pCode;//Код процентной схемы

    @Column(name = "PRC", columnDefinition = "NUMBER", precision = 6, scale = 1)//4
    private BigDecimal prc;//Процентная ставка (годовая)

    @Column(name = "DATE_BEG")//5
    private Date dateBeg;//Дата начала действия % схемы = Равна дате выдачи кредитного договора

    @Column(name = "DATE_END")//6
    private Date dateEnd;//Дата окончания действия % схемы

    //Имя файла
    @Column(name = "FILENAME")//7
    private String fileName;

    //Дата внесения записи
    @Column(name = "INPUT_DATE")//8
    private java.util.Date inputDate;

    @Column(name = "NUMINSERT")//9
    private long numInsert; //Номер вставки

}
