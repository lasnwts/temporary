package ru.usb.xbank_intgr_credit.model;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class PrcSchemePosition {
    private int s;//ВКИ (внутренний код для импорта) договора;Код процентной схемы
    private int pCode;//Код процентной схемы
    private int prc;//Процентная ставка (годовая)
    private int dateBeg;//Дата начала действия % схемы = Равна дате выдачи кредитного договора
    private int dateEnd;//Дата окончания действия % схемы
}
