package ru.usb.xbank_intgr_credit.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class PlanallHeadPosition {
    private int s;//ВКИ (внутренний код для импорта) договора
    private int date;//Дата планового платежа
    private int dateBeg;//Дата начала периода
    private int dateEnd;//Дата окончания периода
    private int oper;//Вид плановой операции по договору
    private int sum;//;Сумма планового платежа
    private int change;//Вариант изменения планового графика
    private int valuta;//Код валюты операции
}
