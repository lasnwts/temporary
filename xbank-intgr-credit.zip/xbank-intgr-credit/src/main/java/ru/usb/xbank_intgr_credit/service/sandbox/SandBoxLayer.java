package ru.usb.xbank_intgr_credit.service.sandbox;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.FacFile;
import ru.usb.xbank_intgr_credit.model.S3Result;
import ru.usb.xbank_intgr_credit.model.db.FtpsResponse;
import ru.usb.xbank_intgr_credit.model.db.S3File;
import ru.usb.xbank_intgr_credit.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_credit.service.s3.AmazonS3Service;
import ru.usb.xbank_intgr_credit.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_credit.util.Support;

@Log4j2
@Service
public class SandBoxLayer {

    @Value("${sandbox.url-upload}")
    String sandboxUrlUpload;

    @Value("${delta.begin}")
    long hostTimeOut;

    @Value("${delta.timeout}")
    long delta;

    private final PutSandBox putSandBox;
    private final Configure configure;
    private final AmazonS3Service amazonS3Service;
    private final ServiceMailError serviceMailError;
    private final ApiLayerS3 apiLayerS3;
    private final Support support;
    private final CheckSandBox checkSandBox;

    @Autowired
    public SandBoxLayer(PutSandBox putSandBox, Configure configure, AmazonS3Service amazonS3Service,
                        ServiceMailError serviceMailError, ApiLayerS3 apiLayerS3, Support support, CheckSandBox checkSandBox) {
        this.putSandBox = putSandBox;
        this.configure = configure;
        this.amazonS3Service = amazonS3Service;
        this.serviceMailError = serviceMailError;
        this.apiLayerS3 = apiLayerS3;
        this.support = support;
        this.checkSandBox = checkSandBox;
    }

    /**
     * Получение FacFile
     *
     * @param ftpsResponse - FtpsResponse
     * @return - FacFile
     */
    public FacFile getFacFile(FtpsResponse ftpsResponse) {
        FacFile facFile = new FacFile();
        facFile.setFile(ftpsResponse.getFile());
        facFile.setCheckStatus(0);
        facFile.setCheckMessage("не проверен");
        facFile.setName(ftpsResponse.getName());
        facFile.setMessage(ftpsResponse.getMessage());
        return facFile;
    }


    /**
     * Получение S3Result
     *
     * @param s3File - S3File
     * @param facFile - FacFile
     * @return - S3Result
     */
    public S3Result getS3Result(S3File s3File, FacFile facFile){
        S3Result s3Result = new S3Result();
        s3Result.setResult(s3File.isSuccess());
        s3Result.setFacFile(facFile);
        s3Result.setTag(s3File.getKey());
        s3Result.setDescription(s3File.getBucket());
        return s3Result;
    }


    /**
     * Загрузка файла в SandBox
     *
     * @param s3Result - S3Result
     * @return - S3Result
     */
    public S3Result uploadFileToSandBox(S3Result s3Result) {
        if (s3Result.isResult()) {
            FacFile facFile = null;
            int i = 1;
            do {
                facFile = putSandBox.putFileToSandBox(s3Result.getFacFile(), Thread.currentThread().getId());
                if (facFile.getCheckStatus() == 200) {
                    break;
                }
                try {
                    log.info("{}:T{} utSandBox.putFileToSandBox(s3Result.getFacFile()), result={} Ждем {} секунд, попытка №{}", LG.USBLOGINFO, Thread.currentThread().getId(),
                            facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:T{} utSandBox.putFileToSandBox(s3Result.getFacFile()) Ошибка ожидания, InterruptedException:{}", LG.USBLOGERROR, Thread.currentThread().getId(),
                            e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11; //выходим
                }
                i++; //+ 1 счетчик
            } while (facFile.getCheckStatus() != 200 && i < 11);
            s3Result.setFacFile(facFile);
        } else {
            s3Result.getFacFile().setCheckStatus(-1); //Файл не загружен
            s3Result.getFacFile().setCheckMessage("Файл не загружался для проверки, потому что ранее не удалось загрузить фал в карантинный бакет s3");
        }
        return s3Result;
    }

    /**
     * Проверка файла
     *
     * @param facFile - FacFile
     * @return - true - break, false (условия не совпали)
     */
    private boolean checkClean(FacFile facFile) {
        if (facFile.getCheckStatus() == 200 && facFile.getResult().getVerdict().equalsIgnoreCase("CLEAN")
                && (facFile.getResult().getScanState().equalsIgnoreCase("FULL") || facFile.getResult().getScanState().equalsIgnoreCase("PARTIAL"))) {
            facFile.setCheckStatus(201); //Успешно проверен
            facFile.setCheckMessage("Файл проверен успешно");
            return true;
        }
        //Если заражен
        if (facFile.getCheckStatus() == 200 && (facFile.getResult().getVerdict().equalsIgnoreCase("VIRUS")
                || facFile.getResult().getVerdict().equalsIgnoreCase("DANGEROUS")
                || facFile.getResult().getVerdict().equalsIgnoreCase("UNWANTED"))) {
            facFile.setCheckStatus(601); //Успешно проверен
            facFile.setCheckMessage("Файл содержит вирус!");
            log.info("{}:T{} Файл:{} содержит вирус.", LG.USBLOGINFO, Thread.currentThread().getId(), facFile.getFile().getName());
            return true;
        }
        if (facFile.getCheckStatus() == 401 || facFile.getCheckStatus() == 405) {
            facFile.setCheckMessage("Ошибка авторизации");
            log.error("{}:T{} Ошибка авторизации, файл:{} не проверить!.", LG.USBLOGERROR, Thread.currentThread().getId(), facFile.getFile().getName());
            serviceMailError.sendMailBusinessSubject(configure.getLetterNoneStatusCheck() , "Файл не прошел проверку в песочнице.\n\r"
                    + facFile.getFile().getName() + "\n\r" + "Описание:" + facFile.getCheckMessage() + "Вероятнее всего : Ошибка авторизации");
            return true;
        }
        //Файл потерян, доработка
        if (facFile.getStatus() != null && facFile.getStatus().is4xxClientError()) {
            facFile.setCheckMessage("SandBox потерял файл!");
            log.error("{}:T{} SandBox потерял файл:{}. Статус:{}. Придется его передать снова на проверку.", LG.USBLOGERROR, Thread.currentThread().getId(), facFile.getFile().getName(), facFile.getCheckStatus());
            serviceMailError.sendMailBusinessSubject(configure.getLetterNoneStatusCheck() , "Файл не прошел проверку в песочнице.\n\r"
                    + facFile.getFile().getName() + "\n\r" + "Описание:" + facFile.getCheckMessage() + "Вероятнее всего : SandBox потерял файл.");
            return true;
        }
        if (facFile.getStatus() != null && facFile.getStatus().is5xxServerError()) {
            facFile.setCheckMessage("Ошибка сервера");
            log.error("{}:T{} Ошибка сервера, файл:{} не проверить!.", LG.USBLOGERROR, Thread.currentThread().getId(), facFile.getFile().getName());
            serviceMailError.sendMailBusinessSubject(configure.getLetterNoneStatusCheck() , "Файл не прошел проверку в песочнице.\n\r"
                    + facFile.getFile().getName() + "\n\r" + "Описание:" + facFile.getCheckMessage() + "Вероятнее всего : Ошибка сервера");
            return true;
        }
        if (facFile.getCheckStatus() == 404) {
            facFile.setCheckMessage("Файл потерян песочницей");
            log.error("{}:T{} Файл потерян песочницей (404), файл:{} не проверен.", LG.USBLOGERROR, Thread.currentThread().getId(), facFile.getFile().getName());
            serviceMailError.sendMailBusinessSubject(configure.getLetterNoneStatusCheck() , "Файл не прошел проверку в песочнице.\n\r"
                    + facFile.getFile().getName() + "\n\r" + "Описание:" + facFile.getCheckMessage() + "Вероятнее всего : Файл потерян песочницей");
            return true;
        }
        if (facFile.getCheckStatus() == 500) {
            facFile.setCheckMessage("Ошибка сервера");
            log.error("{}:T{} Ошибка сервера, файл:{} не проверить!.", LG.USBLOGERROR, Thread.currentThread().getId(), facFile.getFile().getName());
            serviceMailError.sendMailBusinessSubject(configure.getLetterNoneStatusCheck() , "Файл не прошел проверку в песочнице.\n\r"
                    + facFile.getFile().getName() + "\n\r" + "Описание:" + facFile.getCheckMessage() + "Вероятнее всего : Ошибка сервера");
            return true;
        }

        return false; //.Условия не совпали
    }


    /**
     * Успешно проверенный файл без проблем
     */
    public void success201(S3Result s3Result) {
        try {
            log.info("{}:T{} Файл:{} успешно проверен. Удаляем его из карантинного бакета:{}", LG.USBLOGINFO, Thread.currentThread().getId(),
                    s3Result.getFacFile().getFile().getName(), configure.getS3BucketQuarantine());
            //Отправляем в bucket
            if (apiLayerS3.copyFileS3(configure.getS3BucketQuarantine(),s3Result.getTag(), configure.getS3BucketBase(), configure.getS3DirInput() +
                    "/" + s3Result.getFacFile().getName(), Thread.currentThread().getId())) {//удалить файл после помещения в s3
                log.info("{}:T{} Файл:{} успешно передан в бакет:{} ", LG.USBLOGINFO, Thread.currentThread().getId(),
                        s3Result.getFacFile().getFile().getName(), configure.getS3BucketBase());
                amazonS3Service.deleteFile(configure.getS3BucketQuarantine(), s3Result.getFacFile().getFile().getName(), Thread.currentThread().getId()); //Удаляем файл из карантина
            }
        } catch (Exception e) {
            log.error("{}:T{} Возникла ошибка при попытке удалить файл:{} из бакета:{}, ссылка:{}", LG.USBLOGERROR, Thread.currentThread().getId(),
                    s3Result.getFacFile().getFile().getName(), configure.getS3BucketQuarantine(), s3Result.getTag());
            serviceMailError.sendMailErrorSubject("Factorin. PT Sandbox проблема.  Возникла ошибка при попытке удалить файл из s3 бакета:" + support.getWrapNull(s3Result.getTag()),
                    "Ошибка  Описание ошибки: " + e.getMessage()
                            + "\n\r" + "Bucket: " + configure.getS3BucketQuarantine() + "\n\r" + " message: " + support.getWrapNull(s3Result.getFacFile().getMessage()));
        }
    }


    /**
     * Проверка SandBox
     *
     * @param s3Result - S3Result
     * @return - S3Result
     */
    public S3Result checkSandBox(S3Result s3Result) {
        if (s3Result.isResult() && s3Result.getFacFile() != null && s3Result.getFacFile().getCheckStatus() == 200
                && s3Result.getFacFile().getFileUri() != null && !s3Result.getFacFile().getFileUri().isEmpty()) {

            FacFile facFile = null;
            int i = 1;

            /**
             * Замрем на 5 секунд, иначе мы сразу идем на опрос сервера SandBox
             */
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                log.error("{}:T{} Замрем на 5 секунд, иначе мы сразу идем на опрос сервера SandBox, Функция=checkSandBox.checkSandBox(s3Result.getFacFile(), InterruptedException:{}", LG.USBLOGERROR,
                        Thread.currentThread().getId(), e.getMessage());
                Thread.currentThread().interrupt();
            }

            do {
                facFile = checkSandBox.checkSandBox(s3Result.getFacFile(), Thread.currentThread().getId());
                /***
                 * В результате выполнения запроса PT Sandbox направляет сообщение с кодом 200 и текстом сообщения. Если в тексте сообщения указаны значения в полях:
                 * ­	scan_state = FULL;
                 * ­	verdict = CLEAN,
                 * то файл успешно прошел проверку и допускается для передачи в S3-хранилище (NetApp) в бакет постоянного хранения
                 */
                if (checkClean(facFile)) {
                    break; //выходим
                }
                try {
                    log.info("{}:T{} checkSandBox.checkSandBox(s3Result.getFacFile(), result={} Ждем окончания проверки файла {} секунд, попытка №{}", LG.USBLOGINFO, Thread.currentThread().getId(),
                            facFile.getCheckStatus(), hostTimeOut + i * delta, i);
                    Thread.sleep((hostTimeOut + i * delta) * 1000);
                } catch (InterruptedException e) {
                    log.error("{}:T{} checkSandBox.checkSandBox(s3Result.getFacFile(), InterruptedException:{}", LG.USBLOGERROR,
                            Thread.currentThread().getId(), e.getMessage());
                    Thread.currentThread().interrupt();
                    i = 11; //выходим
                }
                i++; //+ 1 счетчик
            } while (i < 11);
            s3Result.setFacFile(facFile);
        } else {
            if (s3Result.getFacFile() != null) {
                s3Result.getFacFile().setCheckStatus(400); //Файл не загружен
                s3Result.getFacFile().setCheckMessage("Возникли проблемы: ошибка в процессе передачи на проверку");
            }
        }
        return s3Result;
    }



}
