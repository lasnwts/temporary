package ru.usb.xbank_intgr_credit.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.model.sandbox.Errors;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EngineResult {
    @JsonProperty("engine_code_name")
    private String engineCodeName;
    @JsonProperty("engine_subsystem")
    private String engineSubsystem;
    @JsonProperty("engine_version")
    private String engineVersion;
    @JsonProperty("database_time")
    private double databaseTime;
    @JsonProperty("database_version")
    private String databaseVersion;
    @JsonProperty("errors")
    private ArrayList<Errors> errors;
    @JsonProperty("detections")
    private ArrayList<Detections> detections;
    @JsonProperty("result")
    private Result result;
    @JsonProperty("details")
    private Details details;
}
