package ru.usb.xbank_intgr_credit.model.db;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

/**
 * microservice	Наименование микросервиса	пример:
 * Xbank-intgr-clients или Xbank-intgr-credit	VARCHAR2(255)
 * start_time	Дата и время начала работы		TIMESTAMP(6)
 * end_time	Дата и время завершения работы		TIMESTAMP(6)
 * status	Статус выполнения	Success – отработал корректно
 * NotData – нет данных
 * Error- завершен с ошибкой	VARCHAR2(10)
 * errortext	Сообщение об ошибке	Если status = 0, то указать причину	VARCHAR2(255)
 */


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "TEST_RUN_HISTORY")
public class TBankRunHistory {
    @Id
//    @GeneratedValue (strategy = GenerationType.AUTO)
    @GeneratedValue (strategy = GenerationType.SEQUENCE)
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "ID")//id записи
    private long id; //1

//    @Id
//    @GeneratedValue(generator = "uuid-hibernate-generator")
//    @GenericGenerator(name = "uuid-hibernate-generator", strategy = "org.hibernate.id.UUIDGenerator")
//    private UUID id;

    @Column(name = "MICROSERVICE")//2
    private String microservice;

    @Column(name = "START_TIME")//3
    private java.util.Date startTime;

    @Column(name = "END_TIME")//4
    private java.util.Date endTime;

    @Column(name = "STATUS")//5
    private String status;

    @Column(name = "ERROR")//6
    private String error;

    @Column(name = "ERRORTEXT")//7
    private String errorText;

}
