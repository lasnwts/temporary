package ru.usb.xbank_intgr_credit.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckDogov {
    private Dogov dogov;//Список кредитных договоров
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация
}
