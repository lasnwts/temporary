package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.repository.DogovRepo;
import ru.usb.xbank_intgr_credit.service.db.JdbcBatchInsertDogov;
import ru.usb.xbank_intgr_credit.util.DogovMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.DogovHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadDogov {
    private final Support support;
    private final DogovHeadMap dogovHeadMap;
    private final DogovMapper dogovMapper;
    private final DogovRepo dogovRepo;
    private final Configure configure;
    private final JdbcBatchInsertDogov jdbcBatchInsertDogov;

    @Autowired
    public LoadDogov(Support support, DogovHeadMap dogovHeadMap, DogovMapper dogovMapper, DogovRepo dogovRepo,
                     Configure configure, JdbcBatchInsertDogov jdbcBatchInsertDogov) {
        this.support = support;
        this.dogovHeadMap = dogovHeadMap;
        this.dogovMapper = dogovMapper;
        this.dogovRepo = dogovRepo;
        this.configure = configure;
        this.jdbcBatchInsertDogov = jdbcBatchInsertDogov;
    }


    /**
     * Загрузка файла
     *
     * @param file - файл
     * @return - список проблем
     */
    public List<LoadError> loadFile(File file, long thread) throws Exception {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadFact, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = configure.getNumInsert(); //Номер под которым будет идти вставка в базу
        //New Section
        String smaxId = dogovRepo.getMaxId();
        long maxId;
        if (smaxId != null) {
            maxId = Long.parseLong(smaxId);
        } else {
            maxId = 0;
        }
        List<Dogov> dogovList = new ArrayList<>();
        //New Section

        log.info("{}:T{}:  Подготовка процесса: Load LoadDogov к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<DogovHeadPosition> dogovHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}:  Запуск процесса: LoadDogov, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                dogovHeadPosition.set(dogovHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckDogov checkDogov = dogovMapper.map(line.trim(), dogovHeadPosition.get(), file.getName(), numInsert, count.get(), maxId);
                                log.debug("{}: Dogov={}", LG.USBLOGINFO, checkDogov.getDogov());
                                if (checkDogov.isExists()) {
                                    //dogovRepo.saveAndFlush(checkDogov.getDogov()); //сохраняем
                                    //New Section
                                    dogovList.add(checkDogov.getDogov());
                                    if (dogovList.size() == 5000) {
                                        log.info("{}:T{}: Загрузка записей [dogov]:{}", LG.USBLOGINFO, thread, dogovList.size());
                                        jdbcBatchInsertDogov.save(dogovList);
                                        dogovList.clear();
                                    }
                                    //New Section

                                }
                                if (checkDogov.getLoadError().isStatus()) {
                                    loadErrorList.add(checkDogov.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            configure.setSyncErrorOnProcessed(true);
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );

            //Вариант 3 сохраняем остаток
            if (!dogovList.isEmpty()) {
                jdbcBatchInsertDogov.save(dogovList);
                log.info("{}:T{}: Загрузка [dogov, basement] записей:{}", LG.USBLOGINFO, thread, dogovList.size());
                dogovList.clear();
            }
            //Подвал


            log.info("{}:T{}: Завершение процесса: LoadDogov, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            configure.setSyncErrorOnProcessed(true);
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, e);
            throw new IOException(e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadDogov. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, ((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

