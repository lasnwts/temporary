package ru.usb.xbank_intgr_credit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.xbank_intgr_credit.dto.Pparam;

public interface PparamRepo extends JpaRepository<Pparam, Long> {
}
