package ru.usb.xbank_intgr_credit.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.dto.AccBalance;
import ru.usb.xbank_intgr_credit.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckAccBalance {
    private AccBalance accBalance;//Информация об остатках на счетах учета задолженности
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация
}
