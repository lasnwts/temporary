package ru.usb.xbank_intgr_credit.model.s3;

import lombok.*;
import org.springframework.http.HttpStatus;

import java.io.File;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class CheckFile {
    private File file;
    private HttpStatus errorCode; //Статус
    private String message; //Описание
    private boolean success; //Результат проверки
    private Exception except; //ошибка
}
