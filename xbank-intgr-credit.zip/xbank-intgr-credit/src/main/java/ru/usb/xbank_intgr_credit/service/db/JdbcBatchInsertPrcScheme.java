package ru.usb.xbank_intgr_credit.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.Fact;
import ru.usb.xbank_intgr_credit.dto.PrcScheme;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchInsertPrcScheme {

    /**
     * "ID" NUMBER(19,0) NOT NULL ENABLE,
     * 	"DATE_BEG" DATE,
     * 	"DATE_END" DATE,
     * 	"FILENAME" VARCHAR2(255 CHAR),
     * 	"INPUT_DATE" TIMESTAMP (6),
     * 	"NUMINSERT" NUMBER(19,0),
     * 	"P_CODE" VARCHAR2(255 CHAR),
     * 	"PRC" NUMBER,
     * 	"S" VARCHAR2(255 CHAR),
     */
    Logger log = LoggerFactory.getLogger(JdbcBatchInsertPrcScheme.class);

    private final JdbcConfig jdbcConfig;

    @Autowired
    public JdbcBatchInsertPrcScheme(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    private static final String INSERT_TO_PRC_SCHEME = "INSERT INTO TEST_PRC_SCHEME (DATE_BEG,DATE_END,FILENAME,INPUT_DATE,NUMINSERT,P_CODE,PRC,S,ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ?)";


    public void save(List<PrcScheme> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_PRC_SCHEME);

            for (PrcScheme currentRecord : entities) {
                insertStatement.setDate(1, currentRecord.getDateBeg()); //DATE_BEG
                insertStatement.setDate(2, currentRecord.getDateEnd()); //DATE_END
                insertStatement.setString(3, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(5, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setString(6, currentRecord.getPCode());//P_CODE
                insertStatement.setBigDecimal(7, currentRecord.getPrc());//PRC
                insertStatement.setString(8, currentRecord.getS());//S
                insertStatement.setLong(9, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }
}
