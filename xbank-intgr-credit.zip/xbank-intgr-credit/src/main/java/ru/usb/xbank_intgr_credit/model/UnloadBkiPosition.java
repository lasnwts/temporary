package ru.usb.xbank_intgr_credit.model;

import lombok.*;

import javax.persistence.Column;
import java.sql.Date;

/**
 * //S;TB_RELATIONSHIP;TB_TYPE;TB_LOANTYPECODE;TB_STARTAMOUOUTST;TB_CUROVERDUEDT_TA;TB_MSPYMNTNXTRDT;TB_MSPYMNTNTRSTDT;TB_PASTDUEDAYS;TB_PAIDPASTDUEDAYS;TB_LASTAMOUNT_30PD;TB_TTLAMOUNT24M30PD;TB_DEBTRANGE;TB_DEBTCALCDATE;TB_INCOMEWAYTYPE;TB_INCOMEINFOSOURCE;TB_COBORROWERSDEBT;TB_STATESUPPORT;TB_STATESUPPORTINFO;TB_LOANPURPOSECODE;
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class UnloadBkiPosition {

    private int s; //1
    private int tbRelationship;//2
    private int tbType;//3
    private int tbLoanTypeCode;//4
    private int tbStartAmouOutst;//5
    private int tbCuroverdueDtTa;//6
    private int tbMspymntNxtrdt;//7
    private int tbMspymntNtrstdt;//8
    private int tbPastDueDays;//9
    private int tbPaidPastDueDays;//10
    private int tbLastAmount30Pd;//11
    private int tbTtlAmount24m30Pd;//12
    private int tbDebtRange;//13
    private int tbDebtCalcDate;//14
    private int tbIncomeWayType;//15
    private int tbIncomeInfoSource;//16
    private int tbCoborrowersDebt;//17
    private int tbStateSupport;//18
    private int tbStateSupportInfo;//19
    private int tbLoanPurposeCode;    //20
    private int tbDateContrTerm; //21

}
