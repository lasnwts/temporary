package ru.usb.xbank_intgr_credit.service.db;

import com.amazonaws.services.rekognition.model.Face;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.JdbcConfig;
import ru.usb.xbank_intgr_credit.dto.Fact;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class JdbcBatchInsertFact {

    /**
     * "ID" NUMBER(19,0) NOT NULL ENABLE,
     * 	"DATEO" DATE,
     * 	"FILENAME" VARCHAR2(255 CHAR),
     * 	"INPUT_DATE" TIMESTAMP (6),
     * 	"NUMINSERT" NUMBER(19,0),
     * 	"OPER" VARCHAR2(255 CHAR),
     * 	"S" VARCHAR2(255 CHAR),
     * 	"SUM" NUMBER(19,2),
     * 	"VALUTA" VARCHAR2(255 CHAR),
     */


    Logger log = LoggerFactory.getLogger(JdbcBatchInsertFact.class);

    @Autowired
    JdbcConfig jdbcConfig;

    private static final String INSERT_TO_FACT = "INSERT INTO tbank_fact (DATEO,FILENAME,INPUT_DATE,NUMINSERT,OPER,S,SUM,VALUTA, ID) " +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ?)";


    public void save(List<Fact> entities) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_FACT);

            for (Fact currentRecord : entities) {
                insertStatement.setDate(1, currentRecord.getDate()); //DATEO
                insertStatement.setString(2, currentRecord.getFileName()); //FILENAME
                insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));//INPUT_DATE
                insertStatement.setLong(4, currentRecord.getNumInsert());//NUMINSERT
                insertStatement.setString(5, currentRecord.getOper());//OPER
                insertStatement.setString(6, currentRecord.getS());//S
                insertStatement.setBigDecimal(7, currentRecord.getSum());//SUM
                insertStatement.setString(8, currentRecord.getValuta());//VALUTA
                insertStatement.setLong(9, currentRecord.getId());//ID
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
        }
    }
}
