package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.MigrInfo;
import ru.usb.xbank_intgr_credit.dto.check.CheckMigrInfo;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.MigrInfoHeadPosition;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class MigrInfoMapper {

    private final Configure configure;

    @Autowired
    public MigrInfoMapper(Configure configure) {
        this.configure = configure;
    }

    /**
     * Преобразование строки в объект MigrInfo
     *
     * @param line                 - строка
     * @param migrInfoHeadPosition - позиции заголовка
     * @param fileName             - имя файла
     * @param numInsert            - номер записи
     * @param lineNumber           - номер строки в файле
     * @return - объект CheckMigrInfo
     */
    public CheckMigrInfo map(String line, MigrInfoHeadPosition migrInfoHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        MigrInfo migrInfo = new MigrInfo();
        migrInfo.setFileName(fileName);
        migrInfo.setNumInsert(numInsert);
        migrInfo.setInputDate(new Date());

        try {
            if (migrInfoHeadPosition.getS() > -1) {
                migrInfo.setS(values[migrInfoHeadPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateBegOrig() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateBegOrig()])) {
                migrInfo.setDateBegOrig(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateBegOrig()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG_ORIG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_BEG_ORIG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_BEG_ORIG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateEndOrig() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateEndOrig()])) {
                migrInfo.setDateEndOrig(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateEndOrig()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END_ORIG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_END_ORIG" + e.getMessage(), loadError);
            log.error("{}:T:{} Ошибка в параметре:DATE_END_ORIG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateEnd() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateEnd()])) {
                migrInfo.setDateEnd(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_END" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getTotalDaysOverdue() > -1 && checkInt(values[migrInfoHeadPosition.getTotalDaysOverdue()])) {
                migrInfo.setTotalDaysOverdue(parseInt(values[migrInfoHeadPosition.getTotalDaysOverdue()]));
            } else {
                setLoadError("Не найден обязательный параметр:TOTAL_DAYS_OVERDUE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:TOTAL_DAYS_OVERDUE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:TOTAL_DAYS_OVERDUE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getSumOverdue() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getSumOverdue()])) {
                migrInfo.setSumOverdue(parseDecimal(values[migrInfoHeadPosition.getSumOverdue()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_OVERDUE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM_OVERDUE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_OVERDUE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getNumPmtsMade() > -1 && checkInt(values[migrInfoHeadPosition.getNumPmtsMade()])) {
                migrInfo.setNumPmtsMade(parseInt(values[migrInfoHeadPosition.getNumPmtsMade()]));
            } else {
                setLoadError("Не найден обязательный параметр:NUM_PMTS_MADE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NUM_PMTS_MADE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:NUM_PMTS_MADE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getNumPmtsRem() > -1 && checkInt(values[migrInfoHeadPosition.getNumPmtsRem()])) {
                migrInfo.setNumPmtsRem(parseInt(values[migrInfoHeadPosition.getNumPmtsRem()]));
            } else {
                setLoadError("Не найден обязательный параметр:NUM_PMTS_REM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:NUM_PMTS_REM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:NUM_PMTS_REM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getOrigTerm() > -1 && checkInt(values[migrInfoHeadPosition.getOrigTerm()])) {
                migrInfo.setOrigTerm(parseInt(values[migrInfoHeadPosition.getOrigTerm()]));
            } else {
                setLoadError("Не найден обязательный параметр:ORIG_TERM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ORIG_TERM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:ORIG_TERM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getCurrTerm() > -1 && checkInt(values[migrInfoHeadPosition.getCurrTerm()])) {
                migrInfo.setCurrTerm(parseInt(values[migrInfoHeadPosition.getCurrTerm()]));
            } else {
                setLoadError("Не найден обязательный параметр:CURR_TERM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CURR_TERM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:CURR_TERM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getPrcRateOrig() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getPrcRateOrig()])) {
                migrInfo.setPrcRateOrig(parseDecimal(values[migrInfoHeadPosition.getPrcRateOrig()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRC_RATE_ORIG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRC_RATE_ORIG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PRC_RATE_ORIG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getPayDayOrig() > -1 && checkInt(values[migrInfoHeadPosition.getPayDayOrig()])) {
                migrInfo.setPayDayOrig(parseInt(values[migrInfoHeadPosition.getPayDayOrig()]));
            } else {
                setLoadError("Не найден обязательный параметр:PAY_DAY_ORIG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PAY_DAY_ORIG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PAY_DAY_ORIG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getPrcRateCurr() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getPrcRateCurr()])) {
                migrInfo.setPrcRateCurr(parseDecimal(values[migrInfoHeadPosition.getPrcRateCurr()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRC_RATE_CURR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PRC_RATE_CURR" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PRC_RATE_CURR: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getPayDayCurr() > -1 && checkInt(values[migrInfoHeadPosition.getPayDayCurr()])) {
                migrInfo.setPayDayCurr(parseInt(values[migrInfoHeadPosition.getPayDayCurr()]));
            } else {
                setLoadError("Не найден обязательный параметр:PAY_DAY_CURR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PAY_DAY_CURR" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PAY_DAY_CURR: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getPaySumCurr() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getPaySumCurr()])) {
                migrInfo.setPaySumCurr(parseDecimal(values[migrInfoHeadPosition.getPaySumCurr()]));
            } else {
                setLoadError("Не найден обязательный параметр:PAY_SUM_CURR", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:PAY_SUM_CURR" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PAY_SUM_CURR: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateFirstPay() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateFirstPay()])) {
                migrInfo.setDateFirstPay(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateFirstPay()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_FIRST_PAY", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_FIRST_PAY" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_FIRST_PAY: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateLastpayCommit() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateLastpayCommit()])) {
                migrInfo.setDateLastpayCommit(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateLastpayCommit()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_LASTPAY_COMMIT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_LASTPAY_COMMIT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_LASTPAY_COMMIT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getSumLastpayCommit() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getSumLastpayCommit()])) {
                migrInfo.setSumLastpayCommit(parseDecimal(values[migrInfoHeadPosition.getSumLastpayCommit()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_LASTPAY_COMMIT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM_LASTPAY_COMMIT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_LASTPAY_COMMIT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getDateNextPayment() > -1 && checkDateLine(values[migrInfoHeadPosition.getDateNextPayment()])) {
                migrInfo.setDateNextPayment(convertDateToSqlDate(parseDateLine(values[migrInfoHeadPosition.getDateNextPayment()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_NEXT_PAYMENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_NEXT_PAYMENT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_NEXT_PAYMENT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getSumNextPayment() > -1 && checkDecimalBool(values[migrInfoHeadPosition.getSumNextPayment()])) {
                migrInfo.setSumNextPayment(parseDecimal(values[migrInfoHeadPosition.getSumNextPayment()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM_NEXT_PAYMENT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM_NEXT_PAYMENT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM_NEXT_PAYMENT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (migrInfoHeadPosition.getRefinance() > -1 && checkInt(values[migrInfoHeadPosition.getRefinance()])) {
                migrInfo.setRefinance(parseInt(values[migrInfoHeadPosition.getRefinance()]));
            } else {
                setLoadError("Не найден обязательный параметр:REFINANCE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:REFINANCE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:REFINANCE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }
        return new CheckMigrInfo(migrInfo, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }


    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

}
