package ru.usb.xbank_intgr_credit.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.S3Result;
import ru.usb.xbank_intgr_credit.model.db.*;
import ru.usb.xbank_intgr_credit.service.db.ApiLayerDB;
import ru.usb.xbank_intgr_credit.service.ftp.ApiLayerFtps;
import ru.usb.xbank_intgr_credit.service.mail.ServiceMailError;
import ru.usb.xbank_intgr_credit.service.s3.ApiLayerS3;
import ru.usb.xbank_intgr_credit.service.sandbox.SandBoxLayer;
import ru.usb.xbank_intgr_credit.service.xloadfile.*;
import ru.usb.xbank_intgr_credit.service.zip.ZipApi;
import ru.usb.xbank_intgr_credit.service.zip.ZipService;
import ru.usb.xbank_intgr_credit.util.Support;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;


@Log4j2
@Service
public class MainStream {


    @Value("${s3.wait.time:10}")
    private long waitTime; //В секундах, время ожидания между попытками

    @Value("${s3.delta.time:10}")
    private long deltaTime; //Увеличение в секундах

    private final ApiLayer apiLayer;
    private final ApiLayerFtps apiLayerFtps;
    private final ServiceMailError serviceMailError;
    private final Configure configure;
    private final Support support;
    private final ApiLayerDB apiLayerDB;
    private final ApiLayerS3 apiLayerS3;
    private final ZipApi zipApi;
    private final ExecutorsAccBalance executorsAccBalance;
    private final ExecutorsDogov executorsDogov;
    private final ExecutorsFact executorsFact;
    private final ExecutorsMigrInfo executorsMigrInfo;
    private final ExecutorsPparam executorsPparam;
    private final ExecutorsPrcShema executorsPrcShema;
    private final ExecutorsPlanall executorsPlanall;
    private final SandBoxLayer sandBoxLayer;
    private final ZipService zipService;

    @Autowired
    public MainStream(ApiLayer apiLayer, ApiLayerFtps apiLayerFtps, ServiceMailError serviceMailError,
                      Configure configure, Support support, ApiLayerDB apiLayerDB, ApiLayerS3 apiLayerS3,
                      ZipApi zipApi, ExecutorsAccBalance executorsAccBalance, ExecutorsDogov executorsDogov,
                      ExecutorsFact executorsFact, ExecutorsMigrInfo executorsMigrInfo, ExecutorsPparam executorsPparam,
                      ExecutorsPrcShema executorsPrcShema, ExecutorsPlanall executorsPlanall,
                      SandBoxLayer sandBoxLayer, ZipService zipService) {
        this.apiLayer = apiLayer;
        this.apiLayerFtps = apiLayerFtps;
        this.serviceMailError = serviceMailError;
        this.configure = configure;
        this.support = support;
        this.apiLayerDB = apiLayerDB;
        this.apiLayerS3 = apiLayerS3;
        this.zipApi = zipApi;
        this.executorsAccBalance = executorsAccBalance;
        this.executorsDogov = executorsDogov;
        this.executorsFact = executorsFact;
        this.executorsMigrInfo = executorsMigrInfo;
        this.executorsPparam = executorsPparam;


        this.executorsPrcShema = executorsPrcShema;
        this.executorsPlanall = executorsPlanall;
        this.sandBoxLayer = sandBoxLayer;
        this.zipService = zipService;
    }

    /**
     * Основной процесс
     */
    public void run() {
        if (configure.isServiceEnabled()) { //Работаем только если сервис включен
            //Получаем список объектов
            getListFile();
        }
    }

    /**
     * Получение списка файлов
     */
    public void getListFile() {
        log.info("{}: Запрос на получение списка файлов", LG.USBLOGINFO);
        CheckFileList checkFileList = apiLayer.getListTbank();
        if (checkFileList.isSuccess()) {
            if (checkFileList.getList() != null && !checkFileList.getList().isEmpty()) {
                apiLayerDB.saveStartRun(); //Сохраняем дату и время старта сервиса
                //Обработка файлов
                checkFileList.getList().forEach(ftpsFile -> {
                    if (support.checkFileMask(ftpsFile.getName())) {
                        startFileProcessed(ftpsFile); //старт обработки файла
                    }
                });
                apiLayerDB.saveProcessEndRun(); //Сохраняем дату и время старта сервиса
            }
        } else {
            log.info("{}: Ошибка при получении списка файлов. Статус={}, описание:{}", LG.USBLOGINFO, checkFileList.getCode(), checkFileList.getMessage());
            serviceMailError.sendMailErrorSubject(configure.getLetterFtpsSubject(), "Ошибка при получении списка файлов\n\r" + configure.getLetterFtps()
                    + "\n\r Статус =" + checkFileList.getCode() + "\n\r" +
                    "Описание: " + checkFileList.getMessage());
        }
    }

    /**
     * Обработка файла
     *
     * @param ftpsFile имя файла
     */
    public void startFileProcessed(FtpsFile ftpsFile) {
        int rhodeCode = 0; //201 - успешно 601 - вирус, 40X , 50X - просто ошибка.
        S3File s3File = new S3File();
        s3File.setSuccess(false);
        s3File.setName(ftpsFile.getName());
        s3File.setSize(ftpsFile.getSize());
        //Обнуляем показатели
        support.setSuccessLoadFile();

        //Стартуем
        TBankHistoryArchives tBankHistoryArchives = apiLayerDB.getHistoryArchive(ftpsFile.getName());

        log.info("{}: Файл взят в обработку:{}, размером:{}", LG.USBLOGINFO, ftpsFile.getName(), ftpsFile.getSize());
        if (apiLayer.checkFileInDataBase(ftpsFile.getName(), Thread.currentThread().getId())) {
            log.info("{}:T{}: Файл:{} найден в базе. В таблице TBANK_HISTORY_ARCHIVES", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsFile.getName());
        } else {
            //Скачиваем файл
            log.info("{}:T{}:Запускаем скачивание файла {}.Так как файл не обработан", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsFile.getName());
            FtpsResponse ftpsResponse = apiLayerFtps.downloadFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), ftpsFile.getName(), apiLayer.getTempPath(), Thread.currentThread().getId());
            log.info("{}:T{}:Файл {} записан в директорию. Статус:{}", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsFile.getName(), ftpsResponse.getHttpStatus());
            //Загружаем в бакет
            if (ftpsResponse.getCode() == 200 && ftpsResponse.getFile() != null) {
                s3File = saveFileToS3(ftpsResponse, tBankHistoryArchives); //Сохраняем файл в S3
            } else {
                log.error("{}:T{}: Ошибка при загрузке файла в S3 бакет. описание файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getMessage());
                serviceMailError.sendMailErrorSubject(configure.getLetterFtpsSubject(), "Ошибка при загрузке файла в S3 бакет. \n\r" + configure.getLetterFtps()
                        + "\n\r Статус =" + ftpsResponse.getCode() + "\n\r" +
                        "Описание: " + ftpsResponse.getMessage());
                return; //Выходим
            }
            if (!s3File.isSuccess()) {
                log.error("{}:T{}: Ошибка при загрузке в S3 бакет:{} - файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), s3File.getBucket(), s3File.getName());
                return; //Выходим
            }
            //Проверяем zip-архив в SandBox
            S3Result s3Result = sandBoxLayer.uploadFileToSandBox(sandBoxLayer.getS3Result(s3File, sandBoxLayer.getFacFile(ftpsResponse)));
            if (!s3Result.isResult()) {
                log.error("{}:T{}: Ошибка при загрузке файла:{} в SandBox.", LG.USBLOGERROR, Thread.currentThread().getId(), s3Result.getFacFile().getName());
                serviceMailError.sendMailErrorSubject(configure.getLetterFtpsSubject(), "Ошибка при загрузке файла в SandBox \n\r" + s3Result.getFacFile().getName()
                        + "\n\r Статус =" + s3Result.getFacFile().getStatus().toString());
            } else {
                if (configure.isCheckSandBox()) {
                    //Запускаем check
                    s3Result = sandBoxLayer.checkSandBox(s3Result);
                    rhodeCode = s3Result.getFacFile().getCheckStatus();
                    //Проверяем успешность
                    if (s3Result.getFacFile().getCheckStatus() == 201) {
                        sandBoxLayer.success201(s3Result); //Если успешно, переносим файл и продолжаем.
                    } else {
                        //Удаляем файл из S3...
                        try {
                            apiLayerS3.deleteFileS3(configure.getS3BucketQuarantine(), s3Result.getTag(), Thread.currentThread().getId());
                            log.info("{}:T{}: Файл:{} удален из S3 бакета.", LG.USBLOGINFO, Thread.currentThread().getId(), s3Result.getFacFile().getName());
                            Files.deleteIfExists(s3Result.getFacFile().getFile().toPath());
                        } catch (Exception e) {
                            log.error("{}:T{}: Ошибка при удалении файла:{} из бакета.", LG.USBLOGERROR, Thread.currentThread().getId(), s3Result.getFacFile().getName());
                        }
                        //формируем письмо в поддержку...
                        if (rhodeCode == 601) {
                            serviceMailError.sendMailErrorSubject(configure.getLetterVirusSubject(), "Файл:" + s3Result.getFacFile().getName() + " вирусный. Удален из S3 бакета.");
                            //Удаляем файл из FTPS
                            FtpsResponse ftpsResponseDelete = apiLayer.deleteFtpsFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), ftpsResponse.getFile().getName());
                            if (ftpsResponseDelete.getCode() != 200) {
                                log.error("{}:T{}:[VIRUS,ERR=601] Ошибка при удалении файла {} из FTPS. Статус:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getFile().getName(), ftpsResponseDelete.getCode());
                            } else {
                                log.info("{}:T{}:[VIRUS,ERR=601] Файл:{}  удален из FTPS.", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getName());
                            }
                        } else {
                            serviceMailError.sendMailErrorSubject(configure.getLetterNoneStatusCheck(), "Файл:" + s3Result.getFacFile().getName() + " не прошел проверку. Удален из S3 бакета.");
                        }
                        if (rhodeCode == 601) {
                            tBankHistoryArchives.setError("601");
                            tBankHistoryArchives.setErrortext("Файл вирусный.ERROR=601");
                        } else {
                            tBankHistoryArchives.setError("400"); //Файл не прошел проверку
                            tBankHistoryArchives.setErrortext("Файл не прошел проверку.");
                        }
                        tBankHistoryArchives.setDateEnd(new Date());
                        apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
                    }
                } else {
                    rhodeCode = 201; //Без проверки идем
                }
            }


            if (rhodeCode == 201) {
                //Проверяем можно распаковать или нет
                ftpsResponse = zipService.checkZip(ftpsResponse, tBankHistoryArchives);
                if (ftpsResponse.getCode() != 200) {
                    log.info("{} Архив поврежден, обработка файла:{} прекращена", LG.USBLOGERROR, ftpsResponse.getName());
                    //Чистим директорию
                    support.cleanTempDirectory();
                    //Сохраняем историю в TRUN
                    TBankRunHistory tBankRunHistory = apiLayerDB.getByMicroservice();
                    tBankRunHistory.setStatus("error");
                    tBankRunHistory.setError("1");
                    tBankRunHistory.setEndTime(new Date());
                    apiLayerDB.saveEndRun(tBankRunHistory); //Сохраняем
                    return; //Выходим, если архив поврежден
                }
                //Распаковываем
                Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                        FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
                Optional<List<Path>> pathList = unzipFile(ftpsResponse.getFile(), path);
                configure.setErrorSummary(""); //Инициация
                //Тут будет обработка файлов
                pathList.ifPresent(paths -> paths.forEach(new Consumer<>() {
                    @Override
                    public void accept(Path path) {
                        log.info("{}:T{}: Распакован файл:{}", LG.USBLOGINFO, Thread.currentThread().getId(), path.getFileName());
                        switch (support.getFileName(path.toString())) {
                            case "accbalance.csv":
                                executorsAccBalance.getTask(path);
                                configure.setAccBalance(true); //Была попытка загрузки
                                break;
                            case "dogov.csv":
                                executorsDogov.getTask(path);
                                configure.setDogov(true); //Была попытка загрузки
                                break;
                            case "fact.csv":
                                executorsFact.getTask(path);
                                configure.setFact(true); //Была попытка загрузки
                                break;
                            case "migr_info.csv":
                                executorsMigrInfo.getTask(path);
                                configure.setMigrInfo(true); //Была попытка загрузки
                                break;
                            case "planall.csv":
                                executorsPlanall.getTask(path);
                                configure.setPlanall(true); //Была попытка загрузки
                                break;
                            case "pparam.csv":
                                executorsPparam.getTask(path);
                                configure.setPparam(true); //Была попытка загрузки
                                break;
                            case "prc_scheme.csv":
                                executorsPrcShema.getTask(path);
                                configure.setPrcscheme(true); //Была попытка загрузки
                                break;
                            default:
                                log.error("{}:T{}: Неизвестный файл:{}", LG.USBLOGERROR, Thread.currentThread().getId(), path.getFileName());
                                configure.setErrorSummary(configure.getErrorSummary() + "\n\r" + "Неизвестный файл:" + path.getFileName());
                                break;
                        }
                    }
                }));

                //Ждем окончания работы потоков
                int i = 1999; //16 минут ожидания
                while (configure.getThreads() > 0 || i == 0) {
                    i--;
                    try {
                        Thread.sleep(500); //Время ожидания в секундах
                    } catch (InterruptedException eI) {
                        log.error("{}: Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR);
                        Thread.currentThread().interrupt();
                    }
                }

                //Сохраняем архив
                tBankHistoryArchives = apiLayerDB.getHistoryArchive(ftpsResponse.getName());
                tBankHistoryArchives.setDateEnd(new Date());
            } //Окончание ==201
            //Проверяем результат
            //Архив с данными клиента успешно загружен в БД citymigration
            //Файл: rup_o_cus20241010125135.zip
            //Микросервис: Xbank-intgr-clients
            if (rhodeCode == 201) {
                if (support.checkSuccesLoadFile()) {
                    //Удаляем файл из FTPS
                    FtpsResponse ftpsResponseDelete = apiLayer.deleteFtpsFile(configure.getFtpsUser(), configure.getFtpsPassword(), configure.getFtpsDirectory(), ftpsResponse.getFile().getName());
                    if (ftpsResponseDelete.getCode() != 200) {
                        log.error("{}:T{}:[success201] Ошибка при удалении файла {} из FTPS. Статус:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getFile().getName(), ftpsResponseDelete.getCode());
                    } else {
                        log.info("{}:T{}:[success201] Файл:{}  удален из FTPS.", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
                    }
                    log.info("{}:T{}: Архив с данными клиента успешно загружен в БД citymigration, файл {}", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getName());
                    serviceMailError.sendMailSubject("Архив с данными клиентов успешно загружен в БД citymigration, файл " + ftpsResponse.getName(),
                            "Архив с данными клиента успешно загружен в БД citymigration"
                                    + "\n\r" + "Файл:" + support.getWrapNull(ftpsResponse.getName()) +
                                    "\n\r" + "Микросервис: Xbank-intgr-clients");
                    tBankHistoryArchives.setError("0");
                    tBankHistoryArchives.setErrortext("Архив с данными клиента успешно загружен в БД citymigration");
                    tBankHistoryArchives.setTbankFiles("1");
                    apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
                } else {
                    log.error("{}:T{}: При загрузке Архива с данными клиентов возникли проблемы, файл {}, проблемы:{}", LG.USBLOGERROR, Thread.currentThread().getId(), ftpsResponse.getName(), support.getReason(support.getWrapNull(support.getDescLoad())));
                    serviceMailError.sendMailBusinessSubject("При загрузке Архива с данными клиентов возникли проблемы, файл " + ftpsResponse.getName(),
                            "Ошибка при загрузке файла " + ftpsResponse.getName() + " в БД citymigration"
                                    + "\n\r Описание:\n\r " + support.getReason(support.getWrapNull(support.getDescLoad())) + "\n\r"
                                    + "\n\r" + support.getWrapNull(configure.getErrorSummary()) +
                                    "\n\r" + "Микросервис: Xbank-intgr-clients");
                    tBankHistoryArchives.setError("1");
                    tBankHistoryArchives.setErrortext("При загрузке Архива с данными клиентов возникли проблемы");
                    apiLayerDB.saveHistoryArchive(tBankHistoryArchives);
                    //Чистим директорию
                    support.cleanTempDirectory();
                }
                //Удаляем файл..
                if (ftpsResponse.getFile() != null) {
                    try {
                        Files.deleteIfExists(ftpsResponse.getFile().toPath());
                        log.info("{}:T{}: Файл:{} удален", LG.USBLOGINFO, Thread.currentThread().getId(), ftpsResponse.getFile().getAbsolutePath());
                    } catch (IOException e) {
                        log.error("{}:T{}: Ошибка:{} при удалении файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage(), ftpsResponse.getFile().getAbsolutePath());
                    }
                }
            }
            //Чистим директорию
            support.cleanTempDirectory();
        }
        //Сохраняем историю в TRUN
        TBankRunHistory tBankRunHistory = apiLayerDB.getByMicroservice();
        if (tBankHistoryArchives != null && tBankHistoryArchives.getError().equalsIgnoreCase("1")) {
            tBankRunHistory.setStatus("error");
            tBankRunHistory.setError("1");
            if (tBankHistoryArchives.getErrortext() != null && tBankHistoryArchives.getArchiveName() != null) {
                tBankRunHistory.setErrorText(tBankHistoryArchives.getArchiveName() + " " + tBankHistoryArchives.getErrortext());
            }
        } else {
            if (tBankRunHistory != null && tBankRunHistory.getStatus() != null && !tBankRunHistory.getStatus().equalsIgnoreCase("error")) {
                if (tBankHistoryArchives != null && tBankHistoryArchives.getError().equalsIgnoreCase("0")) {
                    tBankRunHistory.setStatus("success");
                }
            }
        }
        apiLayerDB.saveEndRun(tBankRunHistory); //Сохраняем
    }


    /**
     * Сохранение файла в бакет S3
     *
     * @param ftpsResponse - объект ответа
     */
    public S3File saveFileToS3(FtpsResponse ftpsResponse, TBankHistoryArchives tBankHistoryArchives) {
        S3File s3File = null;
        if (ftpsResponse.getCode() == 200 && ftpsResponse.getFile() != null) {
            try {
                s3File = saveFileToS3Amazon(configure.getS3BucketQuarantine(), ftpsResponse.getFile(), Thread.currentThread().getId());
                if (s3File.isSuccess()) {
                    log.info("{}:T{}: Файл {} сохранен в S3 бакет. Размер файла:{}", LG.USBLOGINFO, Thread.currentThread().getId(), s3File.getName(), s3File.getSize());
                    tBankHistoryArchives.setErrortext("Файл сохранен в S3 бакет ");
                    apiLayerDB.saveHistoryArchive(tBankHistoryArchives, ftpsResponse, "0");
                } else {
                    log.error("{}:T{}: Файл {} не сохранен в S3 бакет. Размер файла:{}", LG.USBLOGERROR, Thread.currentThread().getId(), s3File.getName(), s3File.getSize());
                    tBankHistoryArchives.setError("1");
                    tBankHistoryArchives.setErrortext("Не удалось сохранить файл в S3 бакет ");
                    apiLayerDB.saveHistoryArchive(tBankHistoryArchives, ftpsResponse, "0");
                }
            } catch (Exception e) {
                log.error("{}:T{}: Ошибка при попытке сохранения файла в S3 бакет. Ошибка:{}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
                tBankHistoryArchives.setError("1");
                tBankHistoryArchives.setErrortext("Ошибка при попытке сохранения файла в S3 бакет. Ошибка: " + support.getWrapNull(e.getMessage()));
                apiLayerDB.saveHistoryArchive(tBankHistoryArchives, ftpsResponse, "0");
            }
        }
        return s3File;
    }


    /**
     * Сохранение файла в бакет Карантина
     *
     * @param bucket - бакет
     * @param file   - объект файла
     */
    public S3File saveFileToS3Amazon(String bucket, File file, long thread) throws Exception {
        //TEST TEST TEST
        Thread.sleep(500);

        long timeWait = waitTime * 1000; //Время ожидания между попытками...
        int i = 0; //Счетчик попыток
        boolean success = false;
        Exception exception = null;
        //Создаем описание
        S3File s3File = new S3File();
        s3File.setBucket(bucket);
        s3File.setName(file.getName());
        s3File.setKey(file.getName());
        s3File.setSize(file.length());
        s3File.setSuccess(false); //пока нет окончательного успеха или провала
        do {
            i++;
            try {
                if (apiLayerS3.saveFileToS3(bucket, file.getName(), file, Thread.currentThread().getId())) {
                    log.info("{}:T{} File {} uploaded to S3 bucket {}", LG.USBLOGINFO, thread, file.getName(), bucket);
                    success = true;
                    s3File.setSuccess(true);
                } else {
                    log.error("{}:T{}: saveFileToS3 - File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
                }
            } catch (Exception e) {
                log.error("{}:T{}: Ошибка возникла при попытке сохранения файла! Номер попытки:{}, время ожидания до следующей попытки={} секунд",
                        LG.USBLOGERROR, thread, i, timeWait / 1000);
                exception = e; //Для переноса
                log.error("{}:T{}: Error saving file to S3: {}", LG.USBLOGERROR, thread, e.getMessage());
                try {
                    Thread.sleep(timeWait); //Время ожидания в секундах
                } catch (InterruptedException eI) {
                    log.error("{}:T{} Ошибка во время ожидания Thread.sleep!", LG.USBLOGERROR, thread);
                    Thread.currentThread().interrupt();
                }
                timeWait = timeWait + (deltaTime * 1000); //Увеличение времени ожидания
            }
        } while (!success && i < 10);
        if (!success) {
            log.error("{}:T{}: File {} not uploaded to S3 bucket {}", LG.USBLOGERROR, thread, file.getName(), bucket);
            String errorMess = null;
            if (exception != null && exception.getMessage() != null) {
                errorMess = exception.getMessage();
            } else {
                errorMess = "Неизвестная ошибка";
            }
            if (apiLayerS3.getS3StatusCode(errorMess).is4xxClientError()) {
                serviceMailError.sendMailBusinessSubject(configure.getLetter4xxSubject(), configure.getLetter4x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            } else {
                serviceMailError.sendMailBusinessSubject(configure.getLetter5xxSubject(), configure.getLetter5x()
                        + "\n\r" + "Файл:" + support.getWrapNull(file.getName())
                        + "\n\r" + "Status=" + support.getWrapNull(String.valueOf(apiLayerS3.getS3StatusCode(errorMess))) +
                        "\n\r" + "Описание:" + support.getWrapNull(errorMess));
            }
        }
        return s3File;
    }


    /**
     * Распаковка файла
     *
     * @param file - файл
     * @param path - путь к файлу
     * @return - список файлов
     */
    public Optional<List<Path>> unzipFile(File file, Path path) {
        try {
            Optional<List<Path>> pathList = zipApi.unzipFile(file.getAbsolutePath(), path.toString(), file.getName());
            if (pathList.isPresent()) {
                log.info("{}: File {} unzipped to {}", LG.USBLOGINFO, file.getAbsolutePath(), pathList.toString());
            } else {
                log.error("{}: File {} not unzipped. Каталог пустой!", LG.USBLOGERROR, file.getAbsolutePath());
                serviceMailError.sendMailBusinessSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                        + "\n Имя файла: " + file.getName() + "\n"
                        + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                        + "\n Сообщение об ошибке: После распаковки => Каталог пустой!");
                Files.deleteIfExists(file.toPath());
                support.cleanTempDirectory();
                return Optional.empty();
            }
            return pathList; //отдаем список
        } catch (Exception e) {
            log.error("{}: Error unzipping file: {}", LG.USBLOGERROR, e.getMessage());
            if (file != null) {
                serviceMailError.sendMailBusinessSubject(configure.getLetterUnzipSubjectError(), configure.getLetterUnzipError()
                        + "\n Имя файла: " + file.getName() + "\n"
                        + "\n Дата : " + support.formatDateTime(new Date()) + "\n"
                        + "\n Сообщение об ошибке: ошибка при разархивации файла");
            }
            return Optional.empty();
        }
    }

}


