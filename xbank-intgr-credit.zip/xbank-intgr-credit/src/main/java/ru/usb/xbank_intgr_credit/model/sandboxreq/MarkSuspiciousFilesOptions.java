package ru.usb.xbank_intgr_credit.model.sandboxreq;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 *     "mark_suspicious_files_options": {
 *       "encrypted_not_unpacked": true,
 *       "max_depth_exceeded": true,
 *       "office_encrypted": true,
 *       "office_has_macros": true,
 *       "office_has_embedded": true,
 *       "office_has_active_x": true,
 *       "office_has_dde": true,
 *       "office_has_remote_data": true,
 *       "office_has_remote_template": true,
 *       "office_has_action": true,
 *       "pdf_encrypted": true,
 *       "pdf_has_embedded": true,
 *       "pdf_has_open_action": true,
 *       "pdf_has_action": true,
 *       "pdf_has_javascript": true
 *     }
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class MarkSuspiciousFilesOptions {

    @JsonProperty("encrypted_not_unpacked")
    private boolean encryptedNotUnpacked;

    @JsonProperty("max_depth_exceeded")
    private boolean maxDepthExceeded;

    @JsonProperty("office_encrypted")
    private boolean officeEncrypted;

    @JsonProperty("office_has_macros")
    private boolean officeHasMacros;

    @JsonProperty("office_has_embedded")
    private boolean officeHasEmbedded;

    @JsonProperty("office_has_active_x")
    private boolean officeHasActiveX;

    @JsonProperty("office_has_dde")
    private boolean officeHasDde;

    @JsonProperty("office_has_remote_data")
    private boolean officeHasRemoteData;

    @JsonProperty("office_has_remote_template")
    private boolean officeHasRemoteTemplate;

    @JsonProperty("office_has_action")
    private boolean officeHasAction;

    @JsonProperty("pdf_encrypted")
    private boolean pdfEncrypted;

    @JsonProperty("pdf_has_embedded")
    private boolean pdfHasEmbedded;

    @JsonProperty("pdf_has_open_action")
    private boolean pdfHasOpenAction;

    @JsonProperty("pdf_has_action")
    private boolean pdfHasAction;

    @JsonProperty("pdf_has_javascript")
    private boolean pdfHasJavascript;

}
