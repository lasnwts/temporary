package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.PrcScheme;
import ru.usb.xbank_intgr_credit.dto.check.CheckPrcScheme;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PrcSchemePosition;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class PrcSchemeMapper {

    private final Configure configure;

    @Autowired
    public PrcSchemeMapper(Configure configure) {
        this.configure = configure;
    }

    /**
     * Маппинг строки из файла в объект PrcScheme
     *
     * @param line              - строка из файла
     * @param prcSchemePosition - позиция полей в строке
     * @param fileName          - имя файла
     * @param numInsert         - номер записи
     * @param lineNumber        - номер строки в файле
     * @return - объект PrcScheme
     */
    public CheckPrcScheme map(String line, PrcSchemePosition prcSchemePosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        PrcScheme prcScheme = new PrcScheme();
        prcScheme.setNumInsert(numInsert);
        prcScheme.setFileName(configure.getArchiveName());
        prcScheme.setInputDate(new Date());

        //S;P_CODE;PRC;DATE_BEG;DATE_END
        try {
            if (prcSchemePosition.getS() > -1) {
                prcScheme.setS(values[prcSchemePosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (prcSchemePosition.getPCode() > -1) {
                prcScheme.setPCode(values[prcSchemePosition.getPCode()]);
            } else {
                setLoadError("Не найден обязательный параметр:P_CODE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:P_CODE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:P_CODE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (prcSchemePosition.getPrc() > -1 && checkDecimalBool(values[prcSchemePosition.getPrc()])) {
                prcScheme.setPrc(parseDecimal(values[prcSchemePosition.getPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:PRC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:PRC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (prcSchemePosition.getDateBeg() > -1 && checkDateLine(values[prcSchemePosition.getDateBeg()])) {
                prcScheme.setDateBeg(convertDateToSqlDate(parseDateLine(values[prcSchemePosition.getDateBeg()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_BEG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_BEG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (prcSchemePosition.getDateEnd() > -1 && checkDateLine(values[prcSchemePosition.getDateEnd()])) {
                prcScheme.setDateEnd(convertDateToSqlDate(parseDateLine(values[prcSchemePosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_END" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }
        return new CheckPrcScheme(prcScheme, loadError);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

}
