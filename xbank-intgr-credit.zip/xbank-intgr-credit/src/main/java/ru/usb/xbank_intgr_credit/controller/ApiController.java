package ru.usb.xbank_intgr_credit.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.FacFile;
import ru.usb.xbank_intgr_credit.service.ApiLayer;
import ru.usb.xbank_intgr_credit.service.mail.EmailServiceImpl;
import ru.usb.xbank_intgr_credit.util.Support;


import java.io.IOException;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api/check")
@Tag(name = "Контроллер для работы с песочницей SandBox ", description = "Проверка файлов антивирусом.")
public class ApiController {

    private final Logger log = LoggerFactory.getLogger(ApiController.class);
    private final EmailServiceImpl emailService;
    private final Support support;
    private final ApiLayer apiLyaer;


    @Autowired
    public ApiController(EmailServiceImpl emailService, Support support, ApiLayer apiLyaer) {
        this.emailService = emailService;
        this.support = support;
        this.apiLyaer = apiLyaer;
    }


    @PostMapping(value = "/uploadScanFile", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @Operation(summary = "Выберите файл ля проверки в SandBox и нажмите Execute. Вы получите ответ в виде Json. Загрузите его в метод:createScanTaskFile.")
    public FacFile upload(@RequestPart(value = "file") MultipartFile files) throws IOException {
        log.info("{}: Поступил запрос на загрузку файла:{}, размером:{} в SandBox", LG.USBLOGINFO, files.getOriginalFilename(), files.getSize());
        return apiLyaer.delFile(apiLyaer.putSandBox(apiLyaer.getFacFile(support.upload(files.getOriginalFilename(), files.getBytes()))));
    }

    @PostMapping(value = "/createScanTaskFile")
    @Operation(summary = "createScanTask в виде File. Метод получения статуса о проверке файла в песочнице SandBox.")
    public FacFile createScanTaskFile(@RequestBody String fac) {
        log.info("{}: Поступил запрос createScanTask в виде File на проверку файла:{} в SandBox", LG.USBLOGINFO, fac);
        FacFile facFile = apiLyaer.getFacString(fac).orElse(new FacFile());
        log.info("{}: Полученный запрос в виде объекта FacFile:{}", LG.USBLOGINFO, facFile);
        return apiLyaer.checkSandBox(facFile);
    }

}
