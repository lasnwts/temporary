package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.AccBalance;
import ru.usb.xbank_intgr_credit.dto.check.CheckAccBalance;
import ru.usb.xbank_intgr_credit.model.AccBalancePosition;
import ru.usb.xbank_intgr_credit.model.LoadError;

import java.math.BigDecimal;
import java.util.Date;

@Log4j2
@Component
public class AccBalancsMapper {

    private final Configure configure;

    @Autowired
    public AccBalancsMapper(Configure configure) {
        this.configure = configure;
    }

//S;ACC;SUM

    public CheckAccBalance map(String line, AccBalancePosition accBalancePosition,  String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        AccBalance accBalance = new AccBalance();
        accBalance.setNumInsert(numInsert);
        accBalance.setInputDate(new Date());
        accBalance.setFileName(configure.getArchiveName());

        try {
            if (accBalancePosition.getS() > -1) {
                accBalance.setS(values[accBalancePosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try{
            if (accBalancePosition.getAcc() > -1) {
                accBalance.setAcc(values[accBalancePosition.getAcc()]);
            } else {
                setLoadError("Не найден обязательный параметр:ACC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:ACC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:ACC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (accBalancePosition.getSum() > -1 && checkDecimalBool(values[accBalancePosition.getSum()])) {
                accBalance.setSum(parseDecimal(values[accBalancePosition.getSum()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }
        return new CheckAccBalance(accBalance, loadError);
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
