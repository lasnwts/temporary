package ru.usb.xbank_intgr_credit.model.db;

import lombok.*;

import java.io.File;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class FtpsFile {
    private File file; //Файл
    private String name; //Имя файла
    private String fileLink; //Линк в s3
    private long size; //Размер файла

    //Особый конструктор
    public FtpsFile(String fileLink) {
        this.fileLink = fileLink;
    }
}
