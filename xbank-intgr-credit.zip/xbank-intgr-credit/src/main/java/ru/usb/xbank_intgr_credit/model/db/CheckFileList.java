package ru.usb.xbank_intgr_credit.model.db;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class CheckFileList {
    private List<FtpsFile> list;
    private boolean success;
    private String message;
    private int code;

}
