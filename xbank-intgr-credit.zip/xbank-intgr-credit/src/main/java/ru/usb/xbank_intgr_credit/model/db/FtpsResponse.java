package ru.usb.xbank_intgr_credit.model.db;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.io.File;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class FtpsResponse {
    private int code;
    private String message;
    private HttpStatus httpStatus;
    private String name;
    private File file;

    public FtpsResponse(int code, String message, HttpStatus httpStatus) {
        this.code = code;
        this.message = message;
        this.httpStatus = httpStatus;
    }

    @Override
    public String toString() {
        return "FtpsResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", httpStatus=" + httpStatus +
                '}';
    }
}
