package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.PlanallHeadPosition;
import ru.usb.xbank_intgr_credit.util.Support;

@Component
public class PlanalHeadMap {

    private final Support support;
    private final Configure configure;

    @Autowired
    public PlanalHeadMap(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;DATE;DATE_BEG;DATE_END;OPER;SUM;CHANGE;VALUTA

    /**
     * Преобразование строки в объект PlanallHeadPosition
     * @param line - строка
     * @return - объект PlanallHeadPosition
     */
    public PlanallHeadPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        PlanallHeadPosition planalHeadPosition = new PlanallHeadPosition();
        planalHeadPosition.setS(support.getPosition("S", values));
        planalHeadPosition.setDate(support.getPosition("DATE", values));
        planalHeadPosition.setDateBeg(support.getPosition("DATE_BEG", values));
        planalHeadPosition.setDateEnd(support.getPosition("DATE_END", values));
        planalHeadPosition.setOper(support.getPosition("OPER", values));
        planalHeadPosition.setSum(support.getPosition("SUM", values));
        planalHeadPosition.setChange(support.getPosition("CHANGE", values));
        planalHeadPosition.setValuta(support.getPosition("VALUTA", values));
        return planalHeadPosition;
    }
}
