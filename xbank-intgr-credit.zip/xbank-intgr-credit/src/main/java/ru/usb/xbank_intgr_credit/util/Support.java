package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;


import java.math.BigDecimal;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class Support {

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfTime = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    DateTimeFormatter sdfTimeStamp = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss,SSSSSS");


    /**
     * Проверка даты формата dd.MM.yyyy HH:mm:ss
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateTimeStamp(String date) {
        try {
            LocalDateTime ldt = LocalDateTime.parse(date, sdfTimeStamp);
            if (ldt == null) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка файла
     *
     * @param fileName - имя файла
     * @return - результат проверки
     */
    public boolean checkFileMask(String fileName) {
        if (fileName == null || fileName.trim().length() < 12) return false;
        return fileName.substring(0, 9).equalsIgnoreCase(configure.getS3MaskFile()) &&
                getExtension(fileName).equalsIgnoreCase(configure.getS3ExtFile());
    }

    /**
     * Получение расширения файла
     *
     * @param line - строка
     * @return - расширение
     */
    public String getExtension(String line) {
        return FilenameUtils.getExtension(line);
    }

    /**
     * Очистка директории
     */
    public void cleanTempDirectory() {
        try {
            FileUtils.cleanDirectory(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                    FileSystems.getDefault().getSeparator() + configure.getNetFileShare()).toFile());
        } catch (Exception e) {
            log.error("{}:Support.cleanTempDirectory:Ошибка при удалении директории {}", LG.USBLOGERROR, e.getMessage());
        }
    }

    /**
     * Получение позиции
     *
     * @param key    - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values) {

        for (int i = 0; i < values.length; i++) {
            if (values[i].equalsIgnoreCase(key)) {
                return i;
            }
        }
        return -1;
    }


    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Получение причины ошибки
     *
     * @param line - строка с ошибкой
     * @return - причина ошибки
     */
    public String getReason(String line) {
        if (line == null || line.isEmpty()) {
            return "Файл не удалось проверить. Обработка невозможна.";
        } else {
            return line.trim();
        }
    }

    /**
     * Проверка даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDate(String date) {
        return GenericValidator.isDate(date, "dd.MM.yyyy", true);
    }

    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }


    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDate(String date) {
        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDate:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Форматирование даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDate(Date date) {
        return sdf.format(date);
    }


    /**
     * Форматирование даты и времени
     *
     * @param date - дата
     * @return - результат проверки
     */
    public String formatDateTime(Date date) {
        return sdfTime.format(date);
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    SimpleDateFormat numInsert = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    /**
     * Получение номера вставки
     *
     * @return - номер вставки
     */
    public long getNumInsert() {
        return Long.parseLong(numInsert.format(new Date()));
    }

    /**
     * Получение имени файла
     *
     * @param line - строка
     * @return - имя файла
     */
    public String getFileName(String line) {
        return FilenameUtils.getName(line);
    }

    /**
     *      Переменные для проверки
     *      --------------------------------------------------------
     *     private boolean accBalance; //Успешность загрузки = true
     *     private boolean dogov; //Успешность загрузки = true
     *     private boolean fact; //Успешность загрузки = true
     *     private boolean migrInfo; //Успешность загрузки = true
     *     private boolean planall; //Успешность загрузки = true
     *     private boolean pparam; //Успешность загрузки = true
     *     private boolean prcscheme; //Успешность загрузки = true
     */

    /**
     * Проверка успешности загрузки файлов
     *
     * @return - результат проверки
     */
    public boolean checkSuccesLoadFile() {

        //Проверяем успешномть загрузки
        if (configure.isAccBalance() &&
                configure.isDogov() &&
                configure.isFact() &&
                configure.isMigrInfo() &&
                configure.isPlanall() &&
                configure.isPparam() &&
                configure.isPrcscheme()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Установка перед загрузкой
     */
    public void setSuccessLoadFile() {
        configure.setDogov(false);
        configure.setFact(false);
        configure.setMigrInfo(false);
        configure.setPlanall(false);
        configure.setPparam(false);
        configure.setPrcscheme(false);
    }


    /**
     * Получение описания ошибки
     * ----------------------------------
     * tbank_accbalance.csv
     * tbank_dogov.csv
     * tbank_dogov.txt
     * tbank_dogov2.csv
     * tbank_fact.csv
     * tbank_migr_info.csv
     * tbank_migr_info.txt
     * tbank_planall.csv
     * tbank_pparam.csv
     * tbank_prc_scheme.csv
     *
     * @return - описание ошибки
     */
    public String getDescLoad() {

        String result = "";

        if (!configure.isAccBalance()) {
            result = result + " Отсутствует или возникли проблемы с файлом accbalance.csv \n";
        }
        if (!configure.isDogov()) {
            result = result + " Отсутствует или возникли проблемы с файлом dogov.csv \n";
        }
        if (!configure.isFact()) {
            result = result + " Отсутствует или возникли проблемы с файлом fact.csv \n";
        }
        if (!configure.isMigrInfo()) {
            result = result + " Отсутствует или возникли проблемы с файлом migr_info.csv \n";
        }
        if (!configure.isPlanall()) {
            result = result + " Отсутствует или возникли проблемы с файлом planall.csv \n";
        }
        if (!configure.isPparam()) {
            result = result + " Отсутствует или возникли проблемы с файлом pparam.csv \n";
        }
        if (!configure.isPrcscheme()) {
            result = result + " Отсутствует или возникли проблемы с файлом prc_scheme.csv \n";
        }

        return result;
    }


}

