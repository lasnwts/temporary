package ru.usb.xbank_intgr_credit.model.sandbox;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Поля в схеме error
 * Поле | Тип | Описание
 * message | string |  Описание
 * type | string | Тип ошибки
 */

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Errors {
    private String message; //Описание
    private String type; //Тип ошибки
}
