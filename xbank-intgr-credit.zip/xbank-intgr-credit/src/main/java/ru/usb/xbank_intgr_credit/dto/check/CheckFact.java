package ru.usb.xbank_intgr_credit.dto.check;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.dto.Fact;
import ru.usb.xbank_intgr_credit.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckFact {
    private Fact fact;//Информация о фактических операциях
    private LoadError loadError; //Ошибки
}
