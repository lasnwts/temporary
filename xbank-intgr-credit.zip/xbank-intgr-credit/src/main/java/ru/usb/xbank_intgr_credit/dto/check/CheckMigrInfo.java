package ru.usb.xbank_intgr_credit.dto.check;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.usb.xbank_intgr_credit.dto.MigrInfo;
import ru.usb.xbank_intgr_credit.model.LoadError;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CheckMigrInfo {
    private MigrInfo migrInfo;//Информация по кредитным договорам
    private LoadError loadError; //Ошибки
    private boolean exists; //Есть ли информация
}
