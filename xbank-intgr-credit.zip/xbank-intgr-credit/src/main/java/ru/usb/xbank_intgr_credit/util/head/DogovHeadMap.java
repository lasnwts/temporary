package ru.usb.xbank_intgr_credit.util.head;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.model.DogovHeadPosition;

@Component
public class DogovHeadMap {

    private final Configure configure;

    @Autowired
    public DogovHeadMap(Configure configure) {
        this.configure = configure;
    }

//S;CLIENT;SYMBOL;NDOG_US;DEPART;DATE_BEG;DATE_END;SUM;SUM_VKP;SUM_VKP_PRC;SUM_VKP_DEB;SUM_VKP_PRC_DEB;SUM_VKP_PEN;DATE_BKI;DATE_OFFER;PSK_PRC_BEG;PSK_BEG;PSK_PRC;PSK;UID;PROCESSED;PROCESSED_TEXT

    /**
     * Преобразование строки в объект DogovHeadPosition
     * @param line - строка
     * @return - объект DogovHeadPosition
     */
    public DogovHeadPosition map(String line){
        String[] values = line.split(configure.getCsvDelimiter());
        DogovHeadPosition dogovHeadPosition = new DogovHeadPosition();
        dogovHeadPosition.setS(getPosition("S", values));
        dogovHeadPosition.setClient(getPosition("CLIENT", values));
        dogovHeadPosition.setSymbol(getPosition("SYMBOL", values));
        dogovHeadPosition.setNdogUs(getPosition("NDOG_US", values));
        dogovHeadPosition.setDepart(getPosition("DEPART", values));
        dogovHeadPosition.setDateBeg(getPosition("DATE_BEG", values));
        dogovHeadPosition.setDateEnd(getPosition("DATE_END", values));
        dogovHeadPosition.setSum(getPosition("SUM", values));
        dogovHeadPosition.setSumVkp(getPosition("SUM_VKP", values));
        dogovHeadPosition.setSumVkpPrc(getPosition("SUM_VKP_PRC", values));
        dogovHeadPosition.setSumVkpDeb(getPosition("SUM_VKP_DEB", values));
        dogovHeadPosition.setSumVkpPrcDeb(getPosition("SUM_VKP_PRC_DEB", values));
        dogovHeadPosition.setSumVkpPen(getPosition("SUM_VKP_PEN", values));
        dogovHeadPosition.setDateBki(getPosition("DATE_BKI", values));
        dogovHeadPosition.setDateOffer(getPosition("DATE_OFFER", values));
        dogovHeadPosition.setPskPrcBeg(getPosition("PSK_PRC_BEG", values));
        dogovHeadPosition.setPskBeg(getPosition("PSK_BEG", values));
        dogovHeadPosition.setPskPrc(getPosition("PSK_PRC", values));
        dogovHeadPosition.setPsk(getPosition("PSK", values));
        dogovHeadPosition.setUid(getPosition("UID", values));
        dogovHeadPosition.setProcessed(getPosition("PROCESSED", values));
        dogovHeadPosition.setProcessedText(getPosition("PROCESSED_TEXT", values));
        //20.11.2024
        dogovHeadPosition.setPdn(getPosition("PDN", values));
        dogovHeadPosition.setSummPdn(getPosition("SUMM_PDN", values));
        return dogovHeadPosition;
    }

    /**
     * Получение позиции
     * @param key - ключ
     * @param values - значения
     * @return - позиция
     */
    public int getPosition(String key, String[] values){

        for (int i = 0; i < values.length; i++) {
            if(values[i].equalsIgnoreCase(key)){
                return i;
            }
        }
        return -1;
    }

}

