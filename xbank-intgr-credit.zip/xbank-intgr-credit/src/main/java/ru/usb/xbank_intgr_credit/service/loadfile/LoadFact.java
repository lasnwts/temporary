package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckFact;
import ru.usb.xbank_intgr_credit.model.FactHeadPosition;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.repository.FactRepo;
import ru.usb.xbank_intgr_credit.util.FactMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.FactHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadFact {

    private final Support support;
    private final FactHeadMap factHeadMap;
    private final FactMapper factMapper;
    private final FactRepo factRepo;
    private final Configure configure;

    @Autowired
    public LoadFact(Support support, FactHeadMap factHeadMap, FactMapper factMapper, FactRepo factRepo, Configure configure) {
        this.support = support;
        this.factHeadMap = factHeadMap;
        this.factMapper = factMapper;
        this.factRepo = factRepo;
        this.configure = configure;
    }

    /**
     * Загрузка файла
     *
     * @param file - файл
     * @return - список ошибок
     */
    public List<LoadError> loadFile(File file, long thread) throws Exception {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{}: Запуск процесса: LoadFact, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}:T{}:  Подготовка процесса: Load LoadFact к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<FactHeadPosition> factHeadPosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}:  Запуск процесса: LoadFact, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), StandardCharsets.UTF_8)) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                factHeadPosition.set(factHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckFact checkFact = factMapper.map(line.trim(), factHeadPosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}:T{}: Fact={}", LG.USBLOGINFO, thread, checkFact.getFact());
                                if (checkFact.isExists()){
                                    factRepo.saveAndFlush(checkFact.getFact()); //сохраняем
                                }
                                if (checkFact.getLoadError().isStatus()) {
                                    loadErrorList.add(checkFact.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            configure.setSyncErrorOnProcessed(true);
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                            try {
                                throw new InvalidCharsetException("Вероятнее всего нарушена кодировка файла. Должна быть UTF-8." + e.getMessage());
                            } catch (InvalidCharsetException ex) {
                                log.error("{}:T{}:Вероятнее всего нарушена кодировка файла. Должна быть UTF-8. Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, ex.getMessage(), line);
                            }
                        }
                    }
            );
            log.info("{}:T{}: Завершение процесса: LoadFact, endTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
            log.info("{}:T{}: Загружено записей:{}", LG.USBLOGINFO, thread, count);

        } catch (IOException e) {
            configure.setSyncErrorOnProcessed(true);
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}: Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
            throw new IOException(e);
        }
        long endTime = System.currentTimeMillis();
        log.info("{}:T{}: Завершение процесса: LoadFact. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread,((endTime - startTime) / 1000) + 1);
        return loadErrorList;
    }
}

