package ru.usb.xbank_intgr_credit;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.service.MainStream;
import ru.usb.xbank_intgr_credit.service.loadfile.*;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@SpringBootApplication
public class XbankIntgrCreditApplication implements CommandLineRunner {

	@Autowired
	LoadFact loadFact;
	@Autowired
	LoadPlanall loadPlanall;
	@Autowired
	LoadAccBalance loadAccBalance;
	@Autowired
	LoadPrcScheme loadPrcScheme;
	@Autowired
	LoadPparam loadPparam;
	@Autowired
	LoadDogov loadDogov;
	@Autowired
	LoadMigrInfo loadMigrInfo;

	@Autowired
	MainStream mainStream;



	private static final Logger logger = LoggerFactory.getLogger(XbankIntgrCreditApplication.class);

	private final Configure configure;

	@Autowired
	public XbankIntgrCreditApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(XbankIntgrCreditApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${spring.application.name}:0.1.10") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r (Service [Микросервис: Xbank-intgr-credit] Интеграционный поток по получению архивов с данными кредитов от Т-банка)")
				.contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
				.version(appVersion)
				.description("API для [Интеграционный поток по получению архивов с данными кредитов от Т-банка]" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {
		// Проверка путей
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
				FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
		} else {
			logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));

		logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
		configure.setTempDirUploadFile(path.toString());
		logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


		logger.info(".");
		logger.info("..");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : Xbank-intgr-credit", LG.USBLOGINFO);
		logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 27/10/2024 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| tbank.dogov.csv              : Список кредитных договоров", LG.USBLOGINFO);
		logger.info("{}:| tbank.fact.csv               : Информация о фактических операциях", LG.USBLOGINFO);
		logger.info("{}:| tbank.pparam.csv             : Информация о параметрах планирования", LG.USBLOGINFO);
		logger.info("{}:| tbank.prc_scheme.csv         : Информация о процентных схемах", LG.USBLOGINFO);
		logger.info("{}:| tbank.planall.csv            : Информация о полных плановых графиках", LG.USBLOGINFO);
		logger.info("{}:| tbank.accbalance.csv         : Информация об остатках на счетах учета задолженности", LG.USBLOGINFO);
		logger.info("{}:| tbank.migr_info.csv          : Информация по кредитным договорам", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  27.10.2024  : 0.0.11 ПОКА НЕТ", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("...");
		logger.info("....");
		logger.info(".....");


		/**********************************************************************
		 * Потом убрать
		 * ********************************************************************
		 */


		String pathFile = "C:/AppServer/Data/TBANK/CREDIT";

//        String filePath = pathFile + "/" + "fact.csv";
//        File file = new File(filePath);
//
//
//        List<LoadError> loadErrors = loadFact.loadFile(file);
//        if (!loadErrors.isEmpty()) {
//            logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//            loadErrors.forEach(loadError -> {
//                logger.info("{}:{}", LG.USBLOGERROR, loadError);
//            });
//        }

//		//tbank_planall.csv
//		String filePath = pathFile + "/" + "planall.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadPlanall.loadFile(file);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}

//		//tbank_accbalance.csv
//		String filePath = pathFile + "/" + "accbalance.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadAccBalance.loadFile(file);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}



		//tbank_prc_scheme.csv
//		String filePath = pathFile + "/" + "prc_scheme.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadPrcScheme.loadFile(file);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}

//		//tbank_pparam.csv
//		String filePath = pathFile + "/" + "tbank_pparam.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadPparam.loadFile(file, 1);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}

//		//tbank_dogov.csv
//		String filePath = pathFile + "/" + "dogov.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadDogov.loadFile(file);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}

//		//tbank_migr_info.csv
//		String filePath = pathFile + "/" + "migr_info.csv";
//		File file = new File(filePath);
//
//
//		List<LoadError> loadErrors = loadMigrInfo.loadFile(file);
//		if (!loadErrors.isEmpty()) {
//			logger.error("{}: Возникли ошибки загрузки в количестве:{}", LG.USBLOGERROR, loadErrors.size());
//			loadErrors.forEach(loadError -> {
//				logger.info("{}:{}", LG.USBLOGERROR, loadError);
//			});
//		}
//		mainStream.run();


	}
}
