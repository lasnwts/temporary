package ru.usb.xbank_intgr_credit;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@SpringBootApplication
public class XbankIntgrCreditApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(XbankIntgrCreditApplication.class);

	private final Configure configure;

	@Autowired
	public XbankIntgrCreditApplication(Configure configure) {
		this.configure = configure;
	}

	public static void main(String[] args) {
		SpringApplication.run(XbankIntgrCreditApplication.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${spring.application.name}:2.1.10") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API \n\r (Service [Микросервис: Xbank-intgr-credit] Интеграционный поток по получению архивов с данными кредитов от Т-банка)")
				.contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
				.version(appVersion)
				.description("API для [Интеграционный поток по получению архивов с данными кредитов от Т-банка]" +
						" library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {
		// Проверка путей
		Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
				FileSystems.getDefault().getSeparator() + configure.getNetFileShare());
		if (!Files.exists(path)) {
			Files.createDirectory(path);
			logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
		} else {
			logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
		}
		//Очистка директории
		FileUtils.cleanDirectory(new File(path.toString()));

		logger.info("Создана директория для файлов выгрузки из базы данных={}", path);
		configure.setTempDirUploadFile(path.toString());
		logger.info("Назначена директория для выгрузки в файле конфигурации tempDirUploadFile={}", path);


		//Проверка сколько времени
		if (LocalDateTime.now().getHour() > configure.getHourEnd()) {
			configure.setSyncWorkTime(false);
			logger.info("{} Время работы завершено", LG.USBLOGINFO);
		}
		if (LocalDateTime.now().getHour() < configure.getHourBegin()) {
			configure.setSyncWorkTime(false);
			logger.info("{} Время работы еще не наступило", LG.USBLOGINFO);
		}
		if (configure.isSyncWorkTime()) {
			logger.info("Сейчас установлено, что время рабочее:{} ", configure.isSyncWorkTime());
		} else {
			logger.info("Сейчас установлено, что время  НЕ рабочее:{} ", configure.isSyncWorkTime());
		}


		logger.info(".");
		logger.info("..");
		logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
		logger.info("{}:| ВНИМАНИЕ! ЭТО ТЕСТОВАЯ СХЕМА!                    ", LG.USBLOGINFO);
		logger.info("{}:| Name service                 : Xbank-intgr-credit", LG.USBLOGINFO);
		logger.info("{}:| Version of service           : 0.0.10", LG.USBLOGINFO);
		logger.info("{}:| Description of service       : Интеграционный поток по получению архивов с данными клиентов от Т-банка.", LG.USBLOGINFO);
		logger.info("{}:| Date created                 : 27/10/2024 ", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| tbank.dogov.csv              : Список кредитных договоров", LG.USBLOGINFO);
		logger.info("{}:| tbank.fact.csv               : Информация о фактических операциях", LG.USBLOGINFO);
		logger.info("{}:| tbank.pparam.csv             : Информация о параметрах планирования", LG.USBLOGINFO);
		logger.info("{}:| tbank.prc_scheme.csv         : Информация о процентных схемах", LG.USBLOGINFO);
		logger.info("{}:| tbank.planall.csv            : Информация о полных плановых графиках", LG.USBLOGINFO);
		logger.info("{}:| tbank.accbalance.csv         : Информация об остатках на счетах учета задолженности", LG.USBLOGINFO);
		logger.info("{}:| tbank.migr_info.csv          : Информация по кредитным договорам", LG.USBLOGINFO);
		logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  27.10.2024  : 0.0.11 Изменены имена файлов. Теперь они без префикса tbank_", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  20.11.2024  : 0.1.02 Полностью переработан.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  21.11.2024  : 0.1.03 Смена кодировки файлов на UTF-8.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  21.11.2024  : 0.1.04 Новые имена файлов.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  22.11.2024  : 0.1.05 Изменена обработка поля Depart, файл dogov.csv.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  23.11.2024  : 0.1.15 Изменение алгоритма, FTPS убран. Файлы берутся из S3.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  25.11.2024  : 0.1.17 Внесены изменения тип данных для файла BKI и маску файла дб tbank.bki.csv.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  25.11.2024  : 0.1.18 Внесены изменения в поле SUM. Если null -> null.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  26.11.2024  : 0.1.19 Внесено изменение в работу с tbank_history_archives", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  26.11.2024  : 0.1.20 Внесены изменения в форматы дат", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  26.11.2024  : 0.1.21 Исправлен тип поля PRC_RATE_CURR в MigrInfo", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  26.11.2024  : 0.1.22 Подправлен механизм анализа пустых строк", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  30.11.2024  : 0.1.23 Таблица BKI дополнена полем PROCESSED", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  30.11.2024  : 0.1.24 Введена проверка на поле S во всех файлах. С пустым полем строка не грузится.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  30.11.2024  : 0.1.25 Исправлена ошибка маппинга полей BKI.", LG.USBLOGINFO);
		logger.info("{}:| Reason modified  12.12.2024  : 2.1.10 Полностью переработанная концепция загрузки 2-х таблиц Fact и Planall.", LG.USBLOGINFO);
		logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
		logger.info("...");
		logger.info("....");
		logger.info(".....");

	}
}
