package ru.usb.xbank_intgr_credit.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class GetObjectFromS3 {
    private String bucket;
    private String key;
}
