package ru.usb.xbank_intgr_credit.model.sandboxresp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Image {
    @JsonProperty("image_id")
    private String imageId;
    @JsonProperty("version")
    private String version;
    @JsonProperty("os")
    private Os os;
}
