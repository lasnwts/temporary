package ru.usb.xbank_intgr_credit.service.loadfile;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.check.CheckAccBalance;
import ru.usb.xbank_intgr_credit.model.AccBalancePosition;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.repository.AccBalanceRepo;
import ru.usb.xbank_intgr_credit.util.AccBalancsMapper;
import ru.usb.xbank_intgr_credit.util.Support;
import ru.usb.xbank_intgr_credit.util.head.AccBalanceHeadMap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Log4j2
@Component
public class LoadAccBalance {

    private final Support support;
    private final AccBalanceHeadMap accBalanceHeadMap;
    private final AccBalancsMapper accBalanceMapper;
    private final AccBalanceRepo accBalanceRepo;

    @Autowired
    public LoadAccBalance(Support support, AccBalanceHeadMap accBalanceHeadMap,
                          AccBalancsMapper accBalanceMapper, AccBalanceRepo accBalanceRepo) {
        this.support = support;
        this.accBalanceHeadMap = accBalanceHeadMap;
        this.accBalanceMapper = accBalanceMapper;
        this.accBalanceRepo = accBalanceRepo;
    }

    public List<LoadError> loadFile(File file, long thread) {

        List<LoadError> loadErrorList = new ArrayList<>(); //Готовим список проблем

        //Если файла не существует, выходим
        if (!file.exists()) {
            log.error("{}:T{} Запуск процесса: LoadAccBalance, переданный Файл {} не существует", LG.USBLOGERROR, thread, file.getAbsolutePath());
            loadErrorList.add(new LoadError(0, file.getAbsolutePath(), "IOException - проблема с файлом в целом", "Файл не существует по указанному пути", new Date(), true));
            return loadErrorList;
        }

        long numInsert = support.getNumInsert(); //Номер под которым будет идти вставка в базу
        log.info("{}:T{}: Подготовка процесса: Load LoadAccBalance к запуску, передан файл для загрузки:{}, номер загрузки -  поле [NUMINSERT] в таблице:{} ", LG.USBLOGINFO, thread, file.getAbsolutePath(), numInsert);
        AtomicReference<AccBalancePosition> accBalancePosition = new AtomicReference<>();
        long startTime = System.currentTimeMillis();
        log.info("{}:T{}: Запуск процесса: LoadAccBalance, startTime={}", LG.USBLOGINFO, thread, support.formatDateTime(new Date()));
        try (Stream<String> lines = Files.lines(Paths.get(file.getAbsolutePath()), Charset.forName("windows-1251"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(line -> {
                        count.incrementAndGet(); //+1 на каждую строку
                        try {
                            if (count.get() == 1) { //строка 1 - заголовок
                                accBalancePosition.set(accBalanceHeadMap.map(line.trim())); //разбираем, что где находится в строке
                            } else {
                                CheckAccBalance checkAccBalance = accBalanceMapper.map(line.trim() + ";", accBalancePosition.get(), file.getName(), numInsert, count.get());
                                log.debug("{}: AccBalance={}", LG.USBLOGINFO, checkAccBalance.getAccBalance());
                                accBalanceRepo.saveAndFlush(checkAccBalance.getAccBalance()); //сохраняем
                                if (checkAccBalance.getLoadError().isStatus()) {
                                    loadErrorList.add(checkAccBalance.getLoadError());
                                }
                            }
                        } catch (Exception e) {
                            loadErrorList.add(new LoadError(count.get(), file.getName(), line, e.getMessage(), new Date(), true));
                            log.error("{}:T{}: Ошибка {}, при обработке записи:{}", LG.USBLOGERROR, thread, e.getMessage(), line);
                            log.debug("{}:T{}: Stack trace:", LG.USBLOGERROR, thread, e);
                        }
                    }
            );
            log.info("{}:T{}:FILE:{} Завершение процесса: LoadAccBalance, endTime={}", LG.USBLOGINFO, thread, file.getName(), support.formatDateTime(new Date()));
            log.info("{}:T{}:FILE:{} Загружено записей:{}", LG.USBLOGINFO, thread, file.getName(), count);

        } catch (IOException e) {
            loadErrorList.add(new LoadError(0, file.getName(), "IOException - проблема с файлом в целом", e.getMessage(), new Date(), true));
            log.error("{}:T{}:FILE:{} Ошибка {}, при обработке файла:{}", LG.USBLOGERROR, thread, file.getName(), e.getMessage(), file.getAbsolutePath());
            log.debug("{}:T{}:FILE:{} Stack trace:", LG.USBLOGERROR, thread, file.getName(), e);
        }
        long endTime = ((System.currentTimeMillis()- startTime) / 1000) + 1;
        log.info("{}:T{}: Завершение процесса: LoadAccBalance. Время прошедшее с начала работы в сек :={}", LG.USBLOGINFO, thread, endTime);
        return loadErrorList;
    }
}

