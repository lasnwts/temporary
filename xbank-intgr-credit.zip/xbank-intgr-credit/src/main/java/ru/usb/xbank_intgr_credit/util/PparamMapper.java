package ru.usb.xbank_intgr_credit.util;


import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Pparam;
import ru.usb.xbank_intgr_credit.dto.check.CheckPparam;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PparamPosition;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class PparamMapper {

    private final Configure configure;

    @Autowired
    public PparamMapper(Configure configure) {
        this.configure = configure;
    }

//S;VIDOPER                 ;DAYPAY;DAYCALC;SUMPAY;   DATE_CALC;DATE_PAY;DATE_END;OPER_COUNT;ONLY_PRC;GASH_PAY_PERIOD
    //S;VIDOPER ;DAYPAY;DAYCALC;SUMPAY;DATE_CALC;DATE_PAY;DATE_END;OPER_COUNT;ONLY_PRC;GASH_PAY_PERIOD
    //TBK_1111111111;боохйфеф_рмбфец;25;25;20005; 25/12/2024;25/12/2024;25/11/2026;24;0;1;

    public CheckPparam map(String line, PparamPosition pparamPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        Pparam pparam = new Pparam();
        pparam.setNumInsert(numInsert);
        pparam.setFileName(fileName);
        pparam.setInputDate(new Date());

        try {
            if (pparamPosition.getS() > -1) {
                pparam.setS(values[pparamPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getVidoper() > -1) {
                pparam.setVidoper(values[pparamPosition.getVidoper()]);
            } else {
                setLoadError("Не найден обязательный параметр:VIDOPER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:VIDOPER" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:VIDOPER: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getDaypay() > -1 && checkInt(values[pparamPosition.getDaypay()])) {
                pparam.setDaypay(parseInt(values[pparamPosition.getDaypay()]));
            } else {
                setLoadError("Не найден обязательный параметр:DAYPAY", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DAYPAY" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DAYPAY: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getDaycalc() > -1 && checkInt(values[pparamPosition.getDaycalc()])) {
                pparam.setDaycalc(parseInt(values[pparamPosition.getDaycalc()]));
            } else {
                setLoadError("Не найден обязательный параметр:DAYCALC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DAYCALC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DAYCALC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getSumpay() > -1 && checkDecimalBool(values[pparamPosition.getSumpay()])) {
                pparam.setSumpay(parseDecimal(values[pparamPosition.getSumpay()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUMPAY", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:SUMPAY" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:SUMPAY: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getDateCalc() > -1 && checkDateLine(values[pparamPosition.getDateCalc()])) {
                pparam.setDateCalc(convertDateToSqlDate(parseDateLine(values[pparamPosition.getDateCalc()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_CALC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_CALC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_CALC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getDatePay() > -1 && checkDateLine(values[pparamPosition.getDatePay()])) {
                pparam.setDatePay(convertDateToSqlDate(parseDateLine(values[pparamPosition.getDatePay()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_PAY", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_PAY" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_PAY: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getDateEnd() > -1 && checkDateLine(values[pparamPosition.getDateEnd()])) {
                pparam.setDateEnd(convertDateToSqlDate(parseDateLine(values[pparamPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:DATE_END" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getOperCount() > -1 && checkInt(values[pparamPosition.getOperCount()])) {
                pparam.setOperCount(parseInt(values[pparamPosition.getOperCount()]));
            } else {
                setLoadError("Не найден обязательный параметр:OPER_COUNT", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:OPER_COUNT" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:OPER_COUNT: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getOnlyPrc() > -1 && checkInt(values[pparamPosition.getOnlyPrc()])) {
                pparam.setOnlyPrc(parseInt(values[pparamPosition.getOnlyPrc()]));
            } else {
                setLoadError("Не найден обязательный параметр:ONLY_PRC", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:ONLY_PRC" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:ONLY_PRC: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (pparamPosition.getGashPayPeriod() > -1 && checkInt(values[pparamPosition.getGashPayPeriod()])) {
                pparam.setGashPayPeriod(parseInt(values[pparamPosition.getGashPayPeriod()]));
            } else {
                setLoadError("Не найден обязательный параметр:GASH_PAY_PERIOD", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:GASH_PAY_PERIOD" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:GASH_PAY_PERIOD: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        return new CheckPparam(pparam, loadError);
    }

    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }


    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }

    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

}
