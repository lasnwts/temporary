package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Dogov;
import ru.usb.xbank_intgr_credit.dto.Planall;
import ru.usb.xbank_intgr_credit.dto.check.CheckDogov;
import ru.usb.xbank_intgr_credit.dto.check.CheckPlanall;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PlanallHeadPosition;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j2
@Component
public class PlanallMapper {

    private final Configure configure;

    @Autowired
    public PlanallMapper(Configure configure) {
        this.configure = configure;
    }

    public CheckPlanall map(String line, PlanallHeadPosition planallHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());

        //Пустая срока
        if (values.length < 5) {
            return new CheckPlanall(new Planall(), new LoadError(lineNumber, fileName, line, "Неверный формат строки", new Date(), true), false);
        }

        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        Planall planall = new Planall();
        planall.setNumInsert(numInsert);
        planall.setFileName(configure.getArchiveName());
        planall.setInputDate(new Date());

        try {
            if (planallHeadPosition.getS() > -1) {
                planall.setS(values[planallHeadPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:S: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getDate() > -1 && checkDateLine(values[planallHeadPosition.getDate()])) {
                planall.setDate(convertDateToSqlDate(parseDateLine(values[planallHeadPosition.getDate()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getDateBeg() > -1 && checkDateLine(values[planallHeadPosition.getDateBeg()])) {
                planall.setDateBeg(convertDateToSqlDate(parseDateLine(values[planallHeadPosition.getDateBeg()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_BEG" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_BEG: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getDateEnd() > -1 && checkDateLine(values[planallHeadPosition.getDateEnd()])) {
                planall.setDateEnd(convertDateToSqlDate(parseDateLine(values[planallHeadPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_END" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getOper() > -1) {
                planall.setOper(values[planallHeadPosition.getOper()]);
            } else {
                setLoadError("Не найден обязательный параметр:OPER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OPER" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:OPER: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getSum() > -1 && checkDecimalBool(values[planallHeadPosition.getSum()])) {
                planall.setSum(parseDecimal(values[planallHeadPosition.getSum()]));
            } else {
                planall.setSum(null); //Ставим 0 если пусто
                //planall.setSum(parseDecimal("0.00")); //Ставим 0 если пусто
                setLoadError("Обязательный параметр planall:SUM установлен в 0", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре planall:SUM: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        /**
         * на интеграции если значение пустое, то принять как пустое. Изменить тип данных.
         * Данное поле может принимать только 0, 1 или пусто
         * нужно изменить по коду
         */
        try {
            if (planallHeadPosition.getChange() > -1 && checkInt(values[planallHeadPosition.getChange()])) {
                planall.setChange(values[planallHeadPosition.getChange()]);
            } else {
                planall.setChange(null); //Пустое значение
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CHANGE" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:CHANGE: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        try {
            if (planallHeadPosition.getValuta() > -1) {
                planall.setValuta(values[planallHeadPosition.getValuta()]);
            } else {
                setLoadError("Не найден обязательный параметр:VALUTA", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:VALUTA" + e.getMessage(), loadError);
            log.error("{}:T{}: Ошибка в параметре:VALUTA: {}", LG.USBLOGERROR, Thread.currentThread().getId(), e.getMessage());
        }

        return new CheckPlanall(planall, loadError, true);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }


    /**
     * Парсинг десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public BigDecimal parseDecimal(String value) {
        try {
            return new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * Проверка десятичного числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkDecimalBool(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Проверка числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public boolean checkInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Проверка даты формата dd/MM/yyyy
     *
     * @param date - дата
     * @return - результат проверки
     */
    public boolean checkDateLine(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        if (date.contains(".")){
            date = date.replace(".", "/");
        }
        if (date.contains("-")){
            date = date.replace("-", "/");
        }

        return GenericValidator.isDate(date, "dd/MM/yyyy", true);
    }

    SimpleDateFormat sdfLine = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Парсинг даты
     *
     * @param date - дата
     * @return - результат проверки
     */
    public Date parseDateLine(String date) {
        try {
            if (date.contains(".")){
                date = date.replace(".", "/");
            }
            if (date.contains("-")){
                date = date.replace("-", "/");
            }

            return sdfLine.parse(date);
        } catch (ParseException e) {
            log.error("{}:Support.parseDateLine:Ошибка:{} при парсинге даты {}", LG.USBLOGERROR, date, e.getMessage());
            return null;
        }
    }

    /**
     * Преобразование даты в java.sql.Date
     *
     * @param date - дата
     * @return - результат конверсии
     */
    public java.sql.Date convertDateToSqlDate(Date date) {
        return new java.sql.Date(date.getTime());
    }


    /**
     * Парсинг числа
     *
     * @param value - значение
     * @return - результат проверки
     */
    public int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

}
