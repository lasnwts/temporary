package ru.usb.xbank_intgr_credit.util;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.dto.Planall;
import ru.usb.xbank_intgr_credit.dto.check.CheckPlanall;
import ru.usb.xbank_intgr_credit.model.LoadError;
import ru.usb.xbank_intgr_credit.model.PlanallHeadPosition;

import java.util.Date;

@Log4j2
@Component
public class PlanallMapper {

    private final Support support;
    private final Configure configure;

    @Autowired
    public PlanallMapper(Support support, Configure configure) {
        this.support = support;
        this.configure = configure;
    }

    //S;DATE;DATE_BEG;DATE_END;OPER;SUM;CHANGE;VALUTA

    public CheckPlanall map(String line, PlanallHeadPosition planallHeadPosition, String fileName, long numInsert, int lineNumber) {
        String[] values = line.split(configure.getCsvDelimiter());
        LoadError loadError = new LoadError();
        loadError.setFileName(fileName);  //имя файла
        loadError.setLine(line); //Строка
        loadError.setStatus(false); //пока без ошибок
        loadError.setLineNumber(lineNumber); //номер строки в файле
        loadError.setDate(new Date());
        //Константы
        Planall planall = new Planall();
        planall.setNumInsert(numInsert);
        planall.setFileName(fileName);
        planall.setInputDate(new Date());

        try {
            if (planallHeadPosition.getS() > -1) {
                planall.setS(values[planallHeadPosition.getS()]);
            } else {
                setLoadError("Не найден обязательный параметр:S", loadError);
            }
        } catch (Exception e) {
            setLoadError("Не найден обязательный параметр:S" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:S: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getDate() > -1 && support.checkDateLine(values[planallHeadPosition.getDate()])) {
                planall.setDate(support.convertDateToSqlDate(support.parseDateLine(values[planallHeadPosition.getDate()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getDateBeg() > -1 && support.checkDateLine(values[planallHeadPosition.getDateBeg()])) {
                planall.setDateBeg(support.convertDateToSqlDate(support.parseDateLine(values[planallHeadPosition.getDateBeg()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_BEG", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_BEG" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_BEG: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getDateEnd() > -1 && support.checkDateLine(values[planallHeadPosition.getDateEnd()])) {
                planall.setDateEnd(support.convertDateToSqlDate(support.parseDateLine(values[planallHeadPosition.getDateEnd()])));
            } else {
                setLoadError("Не найден обязательный параметр:DATE_END", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:DATE_END" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:DATE_END: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getOper() > -1) {
                planall.setOper(values[planallHeadPosition.getOper()]);
            } else {
                setLoadError("Не найден обязательный параметр:OPER", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:OPER" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:OPER: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getSum() > -1 && support.checkDecimalBool(values[planallHeadPosition.getSum()])) {
                planall.setSum(support.parseDecimal(values[planallHeadPosition.getSum()]));
            } else {
                setLoadError("Не найден обязательный параметр:SUM", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:SUM" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:SUM: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getChange() > -1 && support.checkInt(values[planallHeadPosition.getChange()])) {
                planall.setChange(support.parseInt(values[planallHeadPosition.getChange()]));
            } else {
                setLoadError("Не найден обязательный параметр:CHANGE", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:CHANGE" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:CHANGE: {}", LG.USBLOGERROR, e.getMessage());
        }

        try {
            if (planallHeadPosition.getValuta() > -1) {
                planall.setValuta(values[planallHeadPosition.getValuta()]);
            } else {
                setLoadError("Не найден обязательный параметр:VALUTA", loadError);
            }
        } catch (Exception e) {
            setLoadError("Ошибка в параметре:VALUTA" + e.getMessage(), loadError);
            log.error("{}:Ошибка в параметре:VALUTA: {}", LG.USBLOGERROR, e.getMessage());
        }

        return new CheckPlanall(planall, loadError);
    }


    /**
     * Установка ошибки
     *
     * @param errorMessage - сообщение об ошибке
     * @param loadError    - объект ошибки
     */
    private void setLoadError(String errorMessage, LoadError loadError) {
        if (loadError.isStatus()) {
            loadError.setErrorMessage(loadError.getErrorMessage().concat(", ").concat(errorMessage)); //соединяем сообщения с ошибкой
        } else {
            loadError.setErrorMessage(errorMessage); //Первая ошибка
            loadError.setStatus(true); //статус ошибки
        }
    }
}
