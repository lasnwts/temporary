package ru.usb.xbank_intgr_credit.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;
import ru.usb.xbank_intgr_credit.config.Configure;
import ru.usb.xbank_intgr_credit.config.LG;
import ru.usb.xbank_intgr_credit.service.mail.EmailServiceImpl;
import ru.usb.xbank_intgr_credit.util.Support;


/**
 * Класс для тестирования канала отправки почтовых сооющений
 */
@RestController
@RequestMapping("/api/mail")
@Tag(name = "Контроллер для проверки почтовой подсистемы", description = "Проверка отправки почты")
public class EmailController {

    private final Logger logger = LoggerFactory.getLogger(EmailController.class);
    private final EmailServiceImpl emailService;
    private final Support support;
    private final Configure configure;

    @Autowired
    public EmailController(EmailServiceImpl emailService, Support support, Configure configure) {
        this.emailService = emailService;
        this.support = support;
        this.configure = configure;
    }

    /**
     * Тест отправки почты
     */
    @GetMapping(value = "/email/{user-email}")
    @Operation(summary = "Электронный адрес для отправки.[Пример:user@spb.uralsib.ru]")
    public ResponseEntity<String> sendSimpleEmail(@Parameter(description = "email:user@spb.uralsib.ru")
                                           @PathVariable("user-email") String email) {
        try {
            emailService.sendSimpleEmailThrow(email, "Test email message from Service", "This is letter from service");
        } catch (MailException mailException) {
            logger.error("{}: while sending out email..", LG.USBLOGERROR, mailException);
            return new ResponseEntity<>("Unable to send email: \n\r " + support.getWrapNull(mailException.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>("Please check your inbox", HttpStatus.OK);
    }


    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/set/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить")
                                                   @PathVariable("enabled") boolean enabled) {
        configure.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (configure.isServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        if (configure.isServiceEnabled()) {
            return new ResponseEntity<>("Сервис включен.Параметр=true", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Сервис выключен! Параметр=false", HttpStatus.OK);
        }
    }

}
