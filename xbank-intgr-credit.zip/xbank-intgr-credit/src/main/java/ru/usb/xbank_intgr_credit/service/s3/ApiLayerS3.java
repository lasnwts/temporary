package ru.usb.xbank_intgr_credit.service.s3;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.usb.xbank_intgr_credit.config.LG;


import java.io.File;
import java.util.List;
import java.util.Optional;

@Log4j2
@Component
public class ApiLayerS3 {

    private final AmazonS3Service amazonS3Service;
    private final CheckS3Service checkS3Service;

    @Autowired
    public ApiLayerS3(AmazonS3Service amazonS3Service, CheckS3Service checkS3Service) {
        this.amazonS3Service = amazonS3Service;
        this.checkS3Service = checkS3Service;
    }

    /**
     * Сохранение файла в бакет
     *
     * @param bucketName - имя бакета
     * @param key        - имя файла
     * @param file       - файл
     * @return - результат
     */
    public boolean saveFileToS3(String bucketName, String key, File file, long thread) throws Exception {
        try {
            return amazonS3Service.putObject(bucketName, key, file, thread) != null;
        } catch (Exception e) {
            log.error("{}:[saveFileToS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error[saveFileToS3]: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }


    /**
     * Удаление файла из бакета
     * @param bucketName - имя бакета
     * @param key - имя файла
     * @param thread - номер потока
     * @return - HTTPStatus
     * @throws Exception - исключение
     */
    public HttpStatus deleteFileS3(String bucketName, String key, long thread) {
        try {
            return amazonS3Service.deleteFile(bucketName, key, thread);
        } catch (Exception e) {
            log.error("{}:[deleteFileS3]:Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:Error[deleteFileS3]: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }

    /**
     * Копирование файла в бакет
     *
     * @param sourceBucket      - имя исходного бакета
     * @param sourceKey         - имя исходного файла
     * @param destinationBucket - имя бакета назначения
     * @param destinationKey    - имя файла назначения
     * @return
     */
    public boolean copyFileS3(String sourceBucket, String sourceKey, String destinationBucket, String destinationKey, long thread){
        try {
            amazonS3Service.copyFile(sourceBucket, sourceKey, destinationBucket, destinationKey);
            log.info("{}:T{} [copyFileS3] S3: Файл скопирован из {}/{} в {}/{}", LG.USBLOGINFO, thread, sourceBucket,sourceKey,
                    destinationBucket,destinationKey);
            return true;
        } catch (Exception e) {
            log.error("{}:T{}: [copyFileS3]:Error:{}", LG.USBLOGERROR, thread, e.getMessage());
            log.debug("{}:T{}: Error[copyFileS3]: stackTrace:", LG.USBLOGERROR, thread, e);
            return false;
        }
    }

    /**
     * Получить список файлов
     *
     * @param bucketName имя бакета
     * @return список файлов
     */
    public Optional<List<String>> getListFiles(String bucketName, String key) {
        return checkS3Service.getListFiles(checkS3Service.getReadListObjects(bucketName));
    }

    /**
     * Скачивание файла из бакета
     *
     * @param fileLink   - имя файла
     * @param bucketName - имя бакета
     * @param fileName   - имя файла
     */
    public File downloadFileFromS3(String fileLink, String bucketName, String fileName) throws Exception {
        try {
            File file = amazonS3Service.upload(fileName, amazonS3Service.getFile(bucketName, fileLink));//Скачиваем файл с S3 по бакету и линку
            log.info("{}: Загружен файл:{} размером bytes.length={}", LG.USBLOGINFO, file.getName(), file.length());
            return file;
        } catch (Exception e) {
            log.error("{}:[downloadFileFromS3] Error:{}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}:[downloadFileFromS3] Error: stackTrace:", LG.USBLOGERROR, e);
            throw e;
        }
    }


    /**
     * Получение статуса запроса
     *
     * @param line - строка с ошибкой
     * @return - HTTPStatus
     */
    public HttpStatus getS3StatusCode(String line) {
        if (line == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return amazonS3Service.getStatusCode(line);
    }

}
