package ru.usb.sinksiebeluniversal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.sinksiebeluniversal.config.Configure;
import ru.usb.sinksiebeluniversal.dto.MessageFromKafka;
import ru.usb.sinksiebeluniversal.model.SiebelRecord;
import ru.usb.sinksiebeluniversal.utils.ParseDate;

import java.util.Date;

@Service
public class ServiceMapper {

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;


    /**
     * Мапер сообщения по Кафка в строку записи БД Зибель. Таблица CX_DB_INT_IN
     * @param message - объект Сообщения из кафка
     * @return SiebelRecord
     */
    public SiebelRecord maperKafkaSiebel(MessageFromKafka message){

        //Создаем объект
        SiebelRecord siebelRecord = new SiebelRecord();
        /**
         * Служебные поля
         */
        siebelRecord.setCreated(new Date());
        siebelRecord.setCreated_by(configure.getInfoAppName().substring(0,14));
        siebelRecord.setLast_upd(new Date());
        siebelRecord.setLast_upd_by(configure.getInfoAppName().substring(0,14));
        siebelRecord.setRow_id(message.getPackID());
        /**
         * Информационные поля
          */
        siebelRecord.setSystem(message.getSystem_from());
        siebelRecord.setService(message.getService());
        siebelRecord.setPack_id(message.getPackID());
        siebelRecord.setPack(message.getPack());
        siebelRecord.setError_msg(message.getErrortext());

        return siebelRecord;
    }


}
