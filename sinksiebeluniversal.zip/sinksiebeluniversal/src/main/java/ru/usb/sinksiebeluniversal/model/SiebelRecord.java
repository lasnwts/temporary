package ru.usb.sinksiebeluniversal.model;

import io.micrometer.core.annotation.Counted;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Таблица Зибель для приема универсальных сообщений
 */
@Entity
@Table(name = "CX_DB_INT_IN")
public class SiebelRecord implements Serializable {


    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private long id;

    @Column(name = "row_id")
    private String row_id;

    /**
     * Какие-то системные вещи
     */
    @Column(name = "created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    @Column(name = "last_upd")
    @Temporal(TemporalType.TIMESTAMP)
    private Date last_upd;

    @Column(name = "last_upd_by")
    private String last_upd_by;

    @Column(name = "created_by")
    private String created_by;

    /**
     * Реальные поля сообщения из Kafka
     */

    /**
     * SystemFrom
     */
    @Column(name = "system")
    private String system;

    @Column(name = "service")
    private String service;

    @Column(name = "pack_id")
    private String pack_id;

    /**
     * Содержимое пакета
     */
    @Column(name = "pack")
    private String pack;

    /**
     * Текст сообщения об ошибке
     */
    @Column(name = "error_msg")
    private String error_msg;

    public SiebelRecord() {
    }

    public SiebelRecord(String row_id, Date created, Date last_upd,
                        String last_upd_by, String created_by,
                        String system, String service,
                        String pack_id, String pack, String error_msg) {
        this.row_id = row_id;
        this.created = created;
        this.last_upd = last_upd;
        this.last_upd_by = last_upd_by;
        this.created_by = created_by;
        this.system = system;
        this.service = service;
        this.pack_id = pack_id;
        this.pack = pack;
        this.error_msg = error_msg;
    }

    public String getRow_id() {
        return row_id;
    }

    public void setRow_id(String row_id) {
        this.row_id = row_id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getLast_upd() {
        return last_upd;
    }

    public void setLast_upd(Date last_upd) {
        this.last_upd = last_upd;
    }

    public String getLast_upd_by() {
        return last_upd_by;
    }

    public void setLast_upd_by(String last_upd_by) {
        this.last_upd_by = last_upd_by;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPack_id() {
        return pack_id;
    }

    public void setPack_id(String pack_id) {
        this.pack_id = pack_id;
    }

    public String getPack() {
        return pack;
    }

    public void setPack(String pack) {
        this.pack = pack;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    @Override
    public String toString() {
        return "{" +
                "row_id='" + row_id + '\'' +
                ", created=" + created +
                ", last_upd=" + last_upd +
                ", last_upd_by='" + last_upd_by + '\'' +
                ", created_by='" + created_by + '\'' +
                ", system='" + system + '\'' +
                ", service='" + service + '\'' +
                ", pack_id='" + pack_id + '\'' +
                ", pack='" + pack + '\'' +
                ", error_msg='" + error_msg + '\'' +
                '}';
    }

}
