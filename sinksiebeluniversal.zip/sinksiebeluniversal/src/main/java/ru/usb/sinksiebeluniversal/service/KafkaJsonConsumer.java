package ru.usb.sinksiebeluniversal.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.sinksiebeluniversal.config.Configure;
import ru.usb.sinksiebeluniversal.dto.MessageFromKafka;
import ru.usb.sinksiebeluniversal.model.SiebelRecord;
import ru.usb.sinksiebeluniversal.repository.JpaRepositorySiebel;
import ru.usb.sinksiebeluniversal.utils.ParseDate;

@Configuration
@EnableKafka
public class
KafkaJsonConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaJsonConsumer.class);

    @Autowired
    ParseDate parseDate;

    @Autowired
    ServiceMapper serviceMapper;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    JpaRepositorySiebel jpaRepositorySiebel;

    @Autowired
    Configure configure;

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.delay:60}")
    private int serviceDelay;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> record, Acknowledgment ack) {
        if (logDebug) {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.partition) == " + record.partition());
            logger.info("KafkaListener(record.key)       == " + record.key());
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("KafkaListener(topic)            == " + record.topic());
            logger.info("KafkaListener(Offset)           == " + String.valueOf(record.offset()));
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }


        /**
         * Сообщение по Kafka
         */
        MessageFromKafka message;

        try {
            message = objectMapper.readValue(StringUtils.newStringUtf8(StringUtils.getBytesUtf8(record.value())), MessageFromKafka.class);
            logger.info("Object MessageFromKafka::" + message.toString());
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : " + "Ошибка при парсинге Json: " + e.getMessage());
            serviceMailError.sendMailError("Topic:" + configure.getKafkaConsumerTopic() + " Ошибка при парсинге Json: " + e.getMessage());
            ack.acknowledge();
            message = null;
        }

        if (message != null) {
            /**
             * DTO для записи в БД
             */

            if (addRecord(serviceMapper.maperKafkaSiebel(message))) {
                ack.acknowledge();
            } else {
                //Задержка в NN секунд для обработки. Свойство - download.delay
                logger.info(" Seconds = " + serviceDelay + " - delay between downloaded.....");
                ack.nack(serviceDelay);
            }
        }
    }

    /**
     * Метод вставки записи в базу данных
     *
     * @param siebelRecord - DTO для записи в БД
     * @return - boolean (true - добавлен)
     */
    private boolean addRecord(SiebelRecord siebelRecord) {

        logger.info("В базу данных будет добавлен: " + siebelRecord.toString());

        try {
            jpaRepositorySiebel.save(siebelRecord);
            logger.info("Запись добавлена в БД " + siebelRecord.toString());
            return true;
        } catch (Exception exception) {
            logger.error("!!Error! Ошибка добавления записи в БД::", exception);
            serviceMailError.sendMailError("!!Error! Ошибка добавления записи в БД::" + exception.toString());
            return false;
        }
    }


}
