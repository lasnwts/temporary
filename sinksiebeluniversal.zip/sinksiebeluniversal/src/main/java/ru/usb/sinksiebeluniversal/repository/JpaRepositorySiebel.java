package ru.usb.sinksiebeluniversal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.sinksiebeluniversal.model.SiebelRecord;

public interface JpaRepositorySiebel extends JpaRepository<SiebelRecord, Long> {
}
