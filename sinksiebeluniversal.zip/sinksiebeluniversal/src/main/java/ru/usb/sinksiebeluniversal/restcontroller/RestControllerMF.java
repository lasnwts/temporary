package ru.usb.sinksiebeluniversal.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.sinksiebeluniversal.config.Configure;
import ru.usb.sinksiebeluniversal.dto.MessageFromKafka;
import ru.usb.sinksiebeluniversal.model.SiebelRecord;
import ru.usb.sinksiebeluniversal.repository.JpaRepositorySiebel;
import ru.usb.sinksiebeluniversal.service.ServiceMapper;
import ru.usb.sinksiebeluniversal.utils.ParseDate;

@RequestMapping("/api/v1")
@RestController
@Api(value = "user", description = "Контроллер для тестирования работы Sink адаптера.", tags = "1.Rest API базовое.")
public class RestControllerMF {

    @Autowired
    Configure configure;

    @Autowired
    ParseDate parseDate;

    @Autowired
    ServiceMapper serviceMapper;

    @Autowired
    JpaRepositorySiebel jpaRepositorySiebel;

    Logger logger = LoggerFactory.getLogger(RestControllerMF.class);

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() {
        logger.info("Get /version");
        if (configure.getVersion() == null) {
            logger.info("version not defined");
            return "version not defined";
        }
        logger.info("version: " + configure.getVersion());
        return (configure.getVersion());
    }

    @PostMapping("/add")
    //Вставляем API описание
    @ApiOperation(value = "Добавление записи в базу данных",
            notes = "Запись будет добавлена. id можно оставить =0, А формат даты: dd.MM.yy HH:mm:ss")
    public ResponseEntity<?> postRecord(@RequestBody MessageFromKafka message) {
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>POST input record>>>>>>>>>>>>>>>>>>");
        logger.info("postRecord:/ " + message.toString());
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");
        SiebelRecord siebelRecord = null;
        siebelRecord = serviceMapper.maperKafkaSiebel(message);
        logger.info("В базу данных будет добавлен: " + siebelRecord.toString());

        try {
            jpaRepositorySiebel.save(siebelRecord);
            logger.info(configure.getLogTagInfo(), "Запись добавлена в БД " + siebelRecord.toString());
            return new ResponseEntity<>(
                    "Запись добавлена в базу данных:" + message.toString(), HttpStatus.OK);
        } catch (Exception exception) {
            logger.error(configure.getLogTagError(), "!!Error! Ошибка добавления записи в БД::", exception);
            return new ResponseEntity<>(
                    "Произошла ошибка добавления записи в базу данных:" + message.toString() + "\n\r" + exception,
                    HttpStatus.NOT_ACCEPTABLE);
        }
    }

    @GetMapping("/getCount")
    @ApiOperation(value = "Получить количество записей в таблице БД",
            notes = "Таблица CX_DB_INT_IN")
    public ResponseEntity<?> getCountRecords() {
        long countRecords = jpaRepositorySiebel.count();
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>GET count of all record>>>>>>>>>>>>>>>>>>");
        logger.info("Counts Record:: " + countRecords);
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");
        return new ResponseEntity<>(
                countRecords,
                HttpStatus.OK);
    }

}
