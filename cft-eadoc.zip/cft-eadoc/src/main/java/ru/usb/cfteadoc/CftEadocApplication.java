package ru.usb.cfteadoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CftEadocApplication {

	public static void main(String[] args) {
		SpringApplication.run(CftEadocApplication.class, args);
	}

}
