package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Job;
import ru.usb.siebeltomobileapp.mapper.JobMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class JobSender {
    Logger logger = LoggerFactory.getLogger(JobSender.class);
    private final JobMap jobMap;
    private final KafkaProducerService kafkaProducerService;
    private final AuxMethods aux;
    @Autowired
    public JobSender(JobMap jobMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.jobMap = jobMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        Job job = jobMap.messageMapper(messageString);

        if (job == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.job : {}", job);

        /**
         * service - MP.job
         * Поле	Формат данных от SIebel	Формат данных для МП
         * contact_date_time	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         * job_date	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         * created_timestamp	MM/DD/YYYY HH24:MI:SS	формат javatime количество миллисекунд прошедших с 1970 года
         */

        //Проверяем дату и меняем в случае ее присутствия
        //contact_date_time
        if (job.getData() != null && aux.checkDateTime(job.getData().getContactDateTime())) {
            job.getData().setContactDateTime(aux.getUnixTime(job.getData().getContactDateTime()));
        }
        //job_date
        if (job.getData() != null && aux.checkDateTime(job.getData().getJobDate())) {
            job.getData().setJobDate(aux.getUnixTime(job.getData().getJobDate()));
        }
        //created_timestamp
        if (job.getData() != null && aux.checkDateTime(job.getData().getCreatedTimestamp())) {
            job.getData().setCreatedTimestamp(aux.getUnixTime(job.getData().getCreatedTimestamp()));
        }

        //Отправка
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(jobMap.getJsonToStr(job)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(jobMap.getJsonToStr(job)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(jobMap.getJsonToStr(job)));
            return false;
        }
    }
}
