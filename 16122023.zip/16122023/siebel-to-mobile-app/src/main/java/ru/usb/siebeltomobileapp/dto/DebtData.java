package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DebtData {
    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("stageType")
    private String stageType;

    @JsonProperty("debtNumber")
    private String debtNumber;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("agreementDate")
    private String agreementDate;
    @JsonProperty("cessionAgreementDate")
    private String cessionAgreementDate;

    @JsonProperty("isEp")
    private String isEp;

    @JsonProperty("nameCounterParty")
    private String nameCounterParty;

    @JsonProperty("nextPaymentDate")
    private String nextPaymentDate;

    @JsonProperty("overdueDays")
    private String overdueDays;

    @JsonProperty("creditType")
    private String creditType;

    @JsonProperty("returnPeriod")
    private String returnPeriod;

    @JsonProperty("productType")
    private String productType;

    @JsonProperty("creditSum")
    private String creditSum;
    @JsonProperty("comissionSum")
    private String comissionSum;

    @JsonProperty("dutySum")
    private String dutySum;

    @JsonProperty("mainDebtSum")
    private String mainDebtSum;

    @JsonProperty("monthlyPayment")
    private String monthlyPayment;

    @JsonProperty("percentSum")
    private String percentSum;

    @JsonProperty("overdue_percentSum")
    private String overdue_percentSum;

    @JsonProperty("penaltySum")
    private String penaltySum;
    @JsonProperty("totalSum")
    private String totalSum;

    @JsonProperty("totalWrittenOff")
    private String totalWrittenOff;

    @JsonProperty("fairDelayTotal")
    private String fairDelayTotal;

    @JsonProperty("overdueDate")
    private String overdueDate;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("organisationBranch")
    private String organisationBranch;


    @JsonProperty("organisationDivision")
    private String organisationDivision;

    @JsonProperty("loanAccountNumber")
    private String loanAccountNumber;

    @JsonProperty("statusABS")
    private String statusABS;

    @JsonProperty("cancellationDate")
    private String cancellationDate;

    @JsonProperty("lastPaymentAmount")
    private String lastPaymentAmount;

    @JsonProperty("lastPaymentDate")
    private String lastPaymentDate;

    @JsonProperty("presenceOfCollateral")
    private String presenceOfCollateral;

    @JsonProperty("judgmentEffectiveDate")
    private String judgmentEffectiveDate;


    @JsonProperty("currentDebtBasic")
    private String currentDebtBasic;

    @JsonProperty("currentDebtPercent")
    private String currentDebtPercent;

    @JsonProperty("finesPayment")
    private String finesPayment;

    @JsonProperty("debtAmountArrest")
    private String debtAmountArrest;

    @JsonProperty("stageStartDate")
    private String stageStartDate;

    @JsonProperty("salesRepFullName")
    private String salesRepFullName;

    @JsonProperty("bankrStage")
    private String bankrStage;

    public DebtData() {
        //
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getStageType() {
        return stageType;
    }

    public void setStageType(String stageType) {
        this.stageType = stageType;
    }

    public String getDebtNumber() {
        return debtNumber;
    }

    public void setDebtNumber(String debtNumber) {
        this.debtNumber = debtNumber;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAgreementDate() {
        return agreementDate;
    }

    public void setAgreementDate(String agreementDate) {
        this.agreementDate = agreementDate;
    }

    public String getCessionAgreementDate() {
        return cessionAgreementDate;
    }

    public void setCessionAgreementDate(String cessionAgreementDate) {
        this.cessionAgreementDate = cessionAgreementDate;
    }

    public String getIsEp() {
        return isEp;
    }

    public void setIsEp(String isEp) {
        this.isEp = isEp;
    }

    public String getNameCounterParty() {
        return nameCounterParty;
    }

    public void setNameCounterParty(String nameCounterParty) {
        this.nameCounterParty = nameCounterParty;
    }

    public String getNextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(String nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    public String getOverdueDays() {
        return overdueDays;
    }

    public void setOverdueDays(String overdueDays) {
        this.overdueDays = overdueDays;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }

    public String getReturnPeriod() {
        return returnPeriod;
    }

    public void setReturnPeriod(String returnPeriod) {
        this.returnPeriod = returnPeriod;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCreditSum() {
        return creditSum;
    }

    public void setCreditSum(String creditSum) {
        this.creditSum = creditSum;
    }

    public String getComissionSum() {
        return comissionSum;
    }

    public void setComissionSum(String comissionSum) {
        this.comissionSum = comissionSum;
    }

    public String getDutySum() {
        return dutySum;
    }

    public void setDutySum(String dutySum) {
        this.dutySum = dutySum;
    }

    public String getMainDebtSum() {
        return mainDebtSum;
    }

    public void setMainDebtSum(String mainDebtSum) {
        this.mainDebtSum = mainDebtSum;
    }

    public String getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(String monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public String getPercentSum() {
        return percentSum;
    }

    public void setPercentSum(String percentSum) {
        this.percentSum = percentSum;
    }

    public String getOverduePercentSum() {
        return overdue_percentSum;
    }

    public void setOverduePercentSum(String overduePercentSum) {
        this.overdue_percentSum = overduePercentSum;
    }

    public String getPenaltySum() {
        return penaltySum;
    }

    public void setPenaltySum(String penaltySum) {
        this.penaltySum = penaltySum;
    }

    public String getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(String totalSum) {
        this.totalSum = totalSum;
    }

    public String getTotalWrittenOff() {
        return totalWrittenOff;
    }

    public void setTotalWrittenOff(String totalWrittenOff) {
        this.totalWrittenOff = totalWrittenOff;
    }

    public String getFairDelayTotal() {
        return fairDelayTotal;
    }

    public void setFairDelayTotal(String fairDelayTotal) {
        this.fairDelayTotal = fairDelayTotal;
    }

    public String getOverdueDate() {
        return overdueDate;
    }

    public void setOverdueDate(String overdueDate) {
        this.overdueDate = overdueDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOrganisationBranch() {
        return organisationBranch;
    }

    public void setOrganisationBranch(String organisationBranch) {
        this.organisationBranch = organisationBranch;
    }

    public String getOrganisationDivision() {
        return organisationDivision;
    }

    public void setOrganisationDivision(String organisationDivision) {
        this.organisationDivision = organisationDivision;
    }

    public String getLoanAccountNumber() {
        return loanAccountNumber;
    }

    public void setLoanAccountNumber(String loanAccountNumber) {
        this.loanAccountNumber = loanAccountNumber;
    }

    public String getStatusABS() {
        return statusABS;
    }

    public void setStatusABS(String statusABS) {
        this.statusABS = statusABS;
    }

    public String getCancellationDate() {
        return cancellationDate;
    }

    public void setCancellationDate(String cancellationDate) {
        this.cancellationDate = cancellationDate;
    }

    public String getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    public void setLastPaymentAmount(String lastPaymentAmount) {
        this.lastPaymentAmount = lastPaymentAmount;
    }

    public String getLastPaymentDate() {
        return lastPaymentDate;
    }

    public void setLastPaymentDate(String lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    public String getPresenceOfCollateral() {
        return presenceOfCollateral;
    }

    public void setPresenceOfCollateral(String presenceOfCollateral) {
        this.presenceOfCollateral = presenceOfCollateral;
    }

    public String getJudgmentEffectiveDate() {
        return judgmentEffectiveDate;
    }

    public void setJudgmentEffectiveDate(String judgmentEffectiveDate) {
        this.judgmentEffectiveDate = judgmentEffectiveDate;
    }

    public String getCurrentDebtBasic() {
        return currentDebtBasic;
    }

    public void setCurrentDebtBasic(String currentDebtBasic) {
        this.currentDebtBasic = currentDebtBasic;
    }

    public String getCurrentDebtPercent() {
        return currentDebtPercent;
    }

    public void setCurrentDebtPercent(String currentDebtPercent) {
        this.currentDebtPercent = currentDebtPercent;
    }

    public String getFinesPayment() {
        return finesPayment;
    }

    public void setFinesPayment(String finesPayment) {
        this.finesPayment = finesPayment;
    }

    public String getDebtAmountArrest() {
        return debtAmountArrest;
    }

    public void setDebtAmountArrest(String debtAmountArrest) {
        this.debtAmountArrest = debtAmountArrest;
    }

    public String getStageStartDate() {
        return stageStartDate;
    }

    public void setStageStartDate(String stageStartDate) {
        this.stageStartDate = stageStartDate;
    }

    public String getSalesRepFullName() {
        return salesRepFullName;
    }

    public void setSalesRepFullName(String salesRepFullName) {
        this.salesRepFullName = salesRepFullName;
    }

    public String getBankrStage() {
        return bankrStage;
    }

    public void setBankrStage(String bankrStage) {
        this.bankrStage = bankrStage;
    }

    @Override
    public String toString() {
        return "DebtData{" +
                ", clientId='" + clientId + '\'' +
                ", stageType='" + stageType + '\'' +
                ", debtNumber='" + debtNumber + '\'' +
                ", comment='" + comment + '\'' +
                ", agreementDate='" + agreementDate + '\'' +
                ", cessionAgreementDate='" + cessionAgreementDate + '\'' +
                ", isEp='" + isEp + '\'' +
                ", nameCounterParty='" + nameCounterParty + '\'' +
                ", nextPaymentDate='" + nextPaymentDate + '\'' +
                ", overdueDays='" + overdueDays + '\'' +
                ", creditType='" + creditType + '\'' +
                ", returnPeriod='" + returnPeriod + '\'' +
                ", productType='" + productType + '\'' +
                ", creditSum='" + creditSum + '\'' +
                ", comissionSum='" + comissionSum + '\'' +
                ", dutySum='" + dutySum + '\'' +
                ", mainDebtSum='" + mainDebtSum + '\'' +
                ", monthlyPayment='" + monthlyPayment + '\'' +
                ", percentSum='" + percentSum + '\'' +
                ", overdue_percentSum='" + overdue_percentSum + '\'' +
                ", penaltySum='" + penaltySum + '\'' +
                ", totalSum='" + totalSum + '\'' +
                ", totalWrittenOff='" + totalWrittenOff + '\'' +
                ", fairDelayTotal='" + fairDelayTotal + '\'' +
                ", overdueDate='" + overdueDate + '\'' +
                ", currency='" + currency + '\'' +
                ", organisationBranch='" + organisationBranch + '\'' +
                ", organisationDivision='" + organisationDivision + '\'' +
                ", loanAccountNumber='" + loanAccountNumber + '\'' +
                ", statusABS='" + statusABS + '\'' +
                ", cancellationDate='" + cancellationDate + '\'' +
                ", lastPaymentAmount='" + lastPaymentAmount + '\'' +
                ", lastPaymentDate='" + lastPaymentDate + '\'' +
                ", presenceOfCollateral='" + presenceOfCollateral + '\'' +
                ", judgmentEffectiveDate='" + judgmentEffectiveDate + '\'' +
                ", currentDebtBasic='" + currentDebtBasic + '\'' +
                ", currentDebtPercent='" + currentDebtPercent + '\'' +
                ", finesPayment='" + finesPayment + '\'' +
                ", debtAmountArrest='" + debtAmountArrest + '\'' +
                ", stageStartDate='" + stageStartDate + '\'' +
                ", salesRepFullName='" + salesRepFullName + '\'' +
                ", bankrStage='" + bankrStage + '\'' +
                '}';
    }
}
