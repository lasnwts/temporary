package ru.usb.siebeltomobileapp.model;

/**
 * Класс для передачи сообщения о координатах
 */
public class GeoResponse {

    private String result;
    private boolean success;
    private Geo geo;
    private String externalId;
    private String packId;

    public GeoResponse() {
    }

    public GeoResponse(String result, boolean success) {
        this.result = result;
        this.success = success;
    }

    public GeoResponse(String result, boolean success, String externalId) {
        this.result = result;
        this.success = success;
        this.externalId = externalId;
    }

    public GeoResponse(String result, boolean success, String externalId, String packId) {
        this.result = result;
        this.success = success;
        this.externalId = externalId;
        this.packId = packId;
    }

    public GeoResponse(String result, boolean success, Geo geo, String externalId) {
        this.result = result;
        this.success = success;
        this.geo = geo;
        this.externalId = externalId;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Geo getGeo() {
        return geo;
    }

    public void setGeo(Geo geo) {
        this.geo = geo;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getPackId() {
        return packId;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    @Override
    public String toString() {
        return "GeoResponse{" +
                "result='" + result + '\'' +
                ", success=" + success +
                ", geo=" + geo +
                ", externalId='" + externalId + '\'' +
                ", packId='" + packId + '\'' +
                '}';
    }
}
