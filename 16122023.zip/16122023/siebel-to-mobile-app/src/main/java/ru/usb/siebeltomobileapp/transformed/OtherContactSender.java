package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.OtherContact;
import ru.usb.siebeltomobileapp.mapper.OtherContactMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class OtherContactSender {

    Logger logger = LoggerFactory.getLogger(OtherContactSender.class);

    private final OtherContactMap otherContactMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public OtherContactSender(OtherContactMap otherContactMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.otherContactMap = otherContactMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }


    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param contactString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String contactString, String route) {

        if (contactString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        OtherContact otherContact = otherContactMap.messageMapper(contactString);

        if (otherContact == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", contactString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.other_contact : {}", otherContact);

        //Проверяем дату и меняем в случае ее присутствия
        if (otherContact.getData() != null && aux.checkDateTime(otherContact.getData().getCreatedTimestamp())) {
            otherContact.getData().setCreatedTimestamp(aux.getUnixTime(otherContact.getData().getCreatedTimestamp()));
        }

        //Отправлен сообщение в топик
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(otherContactMap.getJsonToStr(otherContact)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(otherContactMap.getJsonToStr(otherContact)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(otherContactMap.getJsonToStr(otherContact)));
            return false;
        }

    }
}
