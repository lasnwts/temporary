package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Job {
    @JsonProperty("externalId")
    private String externalId;
    @JsonProperty("deleteTimestamp")
    private String deleteTimestamp;
    @JsonProperty("data")
    private JobData data;

    public Job() {
    }

    public Job(String externalId, JobData data) {
        this.externalId = externalId;
        this.data = data;
    }

    public Job(String externalId,  String deleteTimestamp, JobData data) {
        this.externalId = externalId;
        this.deleteTimestamp = deleteTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public JobData getData() {
        return data;
    }

    public void setData(JobData data) {
        this.data = data;
    }

    public String getDeleteTimestamp() {
        return deleteTimestamp;
    }

    public void setDeleteTimestamp(String deleteTimestamp) {
        this.deleteTimestamp = deleteTimestamp;
    }

    @Override
    public String toString() {
        return "Job{" +
                "externalId='" + externalId + '\'' +
                ", data=" + data +
                '}';
    }
}
