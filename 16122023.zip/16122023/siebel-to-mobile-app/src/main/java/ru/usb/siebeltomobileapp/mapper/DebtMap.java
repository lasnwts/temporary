package ru.usb.siebeltomobileapp.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Debt;
import ru.usb.siebeltomobileapp.utils.Utilites;

@Component
public class DebtMap {

    Logger logger = LoggerFactory.getLogger(DebtMap.class);

    private final Utilites utilites;

    @Autowired
    public DebtMap(Utilites utilites) {
        this.utilites = utilites;
    }

    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Мапинг строки в объект MessageFromKafka
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public Debt messageMapper(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [Debt]: поступил объект [message] == NULL! Класс [Debt]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        Debt debt = null;

        try {
            debt = objectMapper.readValue(utilites.wrapNullJson(message), Debt.class);
            logger.info("Object [Debt]:{}", debt);
            logger.info("Object [Deb.data]:{}", debt.getData());
            return debt;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Преобразование объекта в строку JSON
     *
     * @param debt объект
     * @return - строка Json
     */
    public String getJsonToStr(Debt debt) {

        if (debt == null) {
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [debt] == NULL! Класс [debt] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(debt);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [debt] в JSON строку!");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:Описание ошибки:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
