package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Client {

    @JsonProperty("externalId")
    private String externalId;

    @JsonProperty("deleteTimestamp")
    private String deleteTimestamp;

    @JsonProperty("data")
    private ClientData data;

    public Client() {
    }

    public Client(String externalId, ClientData data) {
        this.externalId = externalId;
        this.data = data;
    }

    public Client(String externalId, String deleteTimestamp, ClientData data) {
        this.externalId = externalId;
        this.deleteTimestamp = deleteTimestamp;
        this.data = data;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public ClientData getData() {
        return data;
    }

    public void setData(ClientData data) {
        this.data = data;
    }

    public String getDeleteTimestamp() {
        return deleteTimestamp;
    }

    public void setDeleteTimestamp(String deleteTimestamp) {
        this.deleteTimestamp = deleteTimestamp;
    }

    @Override
    public String toString() {
        return "Client{" +
                "externalId='" + externalId + '\'' +
                ", deleteTimestamp='" + deleteTimestamp + '\'' +
                ", data=" + data +
                '}';
    }
}
