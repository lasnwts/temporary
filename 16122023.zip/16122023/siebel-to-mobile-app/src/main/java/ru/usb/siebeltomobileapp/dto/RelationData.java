package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор, первичный ключ
 * clientId	Связь с клиентом
 * birthday	Дата рождения
 * mainAddress	Строка основного адреса
 * personFullName	ФИО связи
 * relationReason	Причина связи (напр. совпадает телефон)
 * status	Статус подтверждения
 * relationType	Тип связи
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelationData {
    @JsonProperty("clientId")
    private String clientId;    //Связь с клиентом
    @JsonProperty("birthday")
    private String birthday;    //Дата рождения
    @JsonProperty("mainAddress")
    private String mainAddress;//	Строка основного адреса

    @JsonProperty("personFullName")
    private String personFullName;    //ФИО связи

    @JsonProperty("relationReason")
    private String relationReason;//	Причина связи (напр. совпадает телефон)

    @JsonProperty("status")
    private String status;    //Статус подтверждения

    @JsonProperty("relationType")
    private String relationType;///	Тип связи

    public RelationData() {
    }

    public RelationData(String clientId, String birthday, String mainAddress,
                        String personFullName, String relationReason, String status, String relationType) {

        this.clientId = clientId;
        this.birthday = birthday;
        this.mainAddress = mainAddress;
        this.personFullName = personFullName;
        this.relationReason = relationReason;
        this.status = status;
        this.relationType = relationType;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getMainAddress() {
        return mainAddress;
    }

    public void setMainAddress(String mainAddress) {
        this.mainAddress = mainAddress;
    }

    public String getPersonFullName() {
        return personFullName;
    }

    public void setPersonFullName(String personFullName) {
        this.personFullName = personFullName;
    }

    public String getRelationReason() {
        return relationReason;
    }

    public void setRelationReason(String relationReason) {
        this.relationReason = relationReason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    @Override
    public String toString() {
        return "RelationData{" +
                ", clientId='" + clientId + '\'' +
                ", birthday='" + birthday + '\'' +
                ", mainAddress='" + mainAddress + '\'' +
                ", personFullName='" + personFullName + '\'' +
                ", relationReason='" + relationReason + '\'' +
                ", status='" + status + '\'' +
                ", relationType='" + relationType + '\'' +
                '}';
    }
}
