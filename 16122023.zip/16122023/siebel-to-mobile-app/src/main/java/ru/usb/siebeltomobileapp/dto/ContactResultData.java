package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор, первичный ключ
 * jobId	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)
 * clientId	Связь с клиентом
 * debtId	Идентификатор долга
 * node_id	Результат задачи (ID - последний узел дерева) заполняется, если контакт был добавлен с МП
 * contactType	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
 * contactDate	Дата контакта
 * description	Адрес/телефон/онлайн контакт на котором была коммуникация
 * result	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)
 * comment	Комментарий к контакту
 * paymentAmount	Сумма обещанного платежа
 * paymentDate	Дата обещанного платежа
 * noSaleReason	Описание причины
 * createdTimestamp	Дата и время создания объекта на МП
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactResultData {

    @JsonProperty("jobId")
    private String jobId; //	Идентификатор, указатель на задачу (в рамках данной системы системы равен id)

    @JsonProperty("clientId")
    private String clientId; //	Связь с клиентом

    @JsonProperty("debtId")
    private String debtId; //	Идентификатор долга

    @JsonProperty("contactType")
    private String contactType; //	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)

    @JsonProperty("contactDate")
    private String contactDate; //	Дата контакта
    @JsonProperty("description")
    private String description; //	Адрес/телефон/онлайн контакт на котором была коммуникация
    @JsonProperty("result")
    private String result; //	Результат контакта (последний узел дерева по результату задания) - Текстовое значение результата задания (или для задач с типом ANY тип/подтип)
    @JsonProperty("comment")
    private String comment; //	Комментарий к контакту

    @JsonProperty("paymentAmount")
    private String paymentAmount; //	Сумма обещанного платежа

    @JsonProperty("paymentDate")
    private String paymentDate; //	Дата обещанного платежа

    @JsonProperty("noSaleReason")
    private String noSaleReason; //	Описание причины

    @JsonProperty("createdTimestamp")
    private String createdTimestamp; //	Дата и время создания объекта на МП

    public ContactResultData() {
        //
    }
    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getDebtId() {
        return debtId;
    }

    public void setDebtId(String debtId) {
        this.debtId = debtId;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getContactDate() {
        return contactDate;
    }

    public void setContactDate(String contactDate) {
        this.contactDate = contactDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getNoSaleReason() {
        return noSaleReason;
    }

    public void setNoSaleReason(String noSaleReason) {
        this.noSaleReason = noSaleReason;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    @Override
    public String toString() {
        return "ContactResultData{" +
                ", jobId='" + jobId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", debtId='" + debtId + '\'' +
                ", contactType='" + contactType + '\'' +
                ", contactDate='" + contactDate + '\'' +
                ", description='" + description + '\'' +
                ", result='" + result + '\'' +
                ", comment='" + comment + '\'' +
                ", paymentAmount='" + paymentAmount + '\'' +
                ", paymentDate='" + paymentDate + '\'' +
                ", noSaleReason='" + noSaleReason + '\'' +
                ", createdTimestamp='" + createdTimestamp + '\'' +
                '}';
    }
}
