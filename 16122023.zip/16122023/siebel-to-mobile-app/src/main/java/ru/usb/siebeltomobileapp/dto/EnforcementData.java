package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnforcementData {
    @JsonProperty("debtId")
    private String debtId;
    @JsonProperty("judicialProceedingId")
    private String judicialProceedingId;
    @JsonProperty("number")
    private String number;

    @JsonProperty("date")
    private String date;

    @JsonProperty("amount")
    private String amount;

    @JsonProperty("excitationDate")
    private String excitationDate;

    @JsonProperty("endDate")
    private String endDate;

    @JsonProperty("basisEndEnforcementProceeding")
    private String basisEndEnforcementProceeding;

    @JsonProperty("type")
    private String type;

    @JsonProperty("enforcmentNumber")
    private String enforcmentNumber;

    @JsonProperty("fsspName")
    private String fsspName;

    @JsonProperty("status")
    private String status;

    @JsonProperty("result")
    private String result;

    @JsonProperty("client")
    private String client;

    @JsonProperty("thridParty")
    private String thridParty;

    @JsonProperty("leftToPay")
    private String leftToPay;

    public EnforcementData() {
        //
    }

    public String getDebtId() {
        return debtId;
    }

    public void setDebtId(String debtId) {
        this.debtId = debtId;
    }

    public String getJudicialProceedingId() {
        return judicialProceedingId;
    }

    public void setJudicialProceedingId(String judicialProceedingId) {
        this.judicialProceedingId = judicialProceedingId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getExcitationDate() {
        return excitationDate;
    }

    public void setExcitationDate(String excitationDate) {
        this.excitationDate = excitationDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getBasisEndEnforcementProceeding() {
        return basisEndEnforcementProceeding;
    }

    public void setBasisEndEnforcementProceeding(String basisEndEnforcementProceeding) {
        this.basisEndEnforcementProceeding = basisEndEnforcementProceeding;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEnforcmentNumber() {
        return enforcmentNumber;
    }

    public void setEnforcmentNumber(String enforcmentNumber) {
        this.enforcmentNumber = enforcmentNumber;
    }

    public String getFsspName() {
        return fsspName;
    }

    public void setFsspName(String fsspName) {
        this.fsspName = fsspName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getThridParty() {
        return thridParty;
    }

    public void setThridParty(String thridParty) {
        this.thridParty = thridParty;
    }

    public String getLeftToPay() {
        return leftToPay;
    }

    public void setLeftToPay(String leftToPay) {
        this.leftToPay = leftToPay;
    }

    @Override
    public String toString() {
        return "EnforcementData{" +
                ", debtId='" + debtId + '\'' +
                ", judicialProceedingId='" + judicialProceedingId + '\'' +
                ", number='" + number + '\'' +
                ", date='" + date + '\'' +
                ", amount='" + amount + '\'' +
                ", excitationDate='" + excitationDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", basisEndEnforcementProceeding='" + basisEndEnforcementProceeding + '\'' +
                ", type='" + type + '\'' +
                ", enforcmentNumber='" + enforcmentNumber + '\'' +
                ", fsspName='" + fsspName + '\'' +
                ", status='" + status + '\'' +
                ", result='" + result + '\'' +
                ", client='" + client + '\'' +
                ", thridParty='" + thridParty + '\'' +
                ", leftToPay='" + leftToPay + '\'' +
                '}';
    }
}
