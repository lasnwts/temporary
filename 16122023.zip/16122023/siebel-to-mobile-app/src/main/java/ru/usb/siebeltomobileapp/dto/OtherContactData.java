package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * "createdTimestamp": "11/29/2023 07:48:35",
 * "clientId": "1-4HZ4-482",
 * "otherContactTypeId": "",
 * "id": "1-1HYPE3-628",
 * "otherContact": "1-1HYPE3-628@AAAA.AAA"
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OtherContactData {
    @JsonProperty("createdTimestamp")
    private String createdTimestamp;
    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("otherContactTypeId")
    private String otherContactTypeId;
    @JsonProperty("otherContact")
    private String otherContact;

    public OtherContactData() {
    }

    public OtherContactData(String createdTimestamp, String clientId, String otherContactTypeId, String otherContact) {
        this.createdTimestamp = createdTimestamp;
        this.clientId = clientId;
        this.otherContactTypeId = otherContactTypeId;
        this.otherContact = otherContact;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getOtherContactTypeId() {
        return otherContactTypeId;
    }

    public void setOtherContactTypeId(String otherContactTypeId) {
        this.otherContactTypeId = otherContactTypeId;
    }

    public String getOtherContact() {
        return otherContact;
    }

    public void setOtherContact(String otherContact) {
        this.otherContact = otherContact;
    }

    @Override
    public String toString() {
        return "DataOtherContact{" +
                "createdTimestamp='" + createdTimestamp + '\'' +
                ", clientId='" + clientId + '\'' +
                ", otherContactTypeId='" + otherContactTypeId + '\'' +
                ", otherContact='" + otherContact + '\'' +
                '}';
    }
}
