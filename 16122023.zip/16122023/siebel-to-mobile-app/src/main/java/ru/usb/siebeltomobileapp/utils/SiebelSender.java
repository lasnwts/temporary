package ru.usb.siebeltomobileapp.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.config.Configure;
import ru.usb.siebeltomobileapp.mapper.MessageToSiebelMap;
import ru.usb.siebeltomobileapp.model.GeoResponse;
import ru.usb.siebeltomobileapp.model.MessageFromKafka;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;


/**
 * Отправка ответов в Siebel
 * <p>
 * Структура входящего сообщения
 * <p>
 * 1. 	system_from	Система-источник		Константа "MP-Hard"	String
 * +
 * 2.  	system_to	Система-приемник		Константа "SIEBEL"	String
 * +
 * 3.	service	Название сервиса			String
 * +
 * 4.	routeID	Идентификатор топика kafka			String
 * 5. 	mapper	Bдентификатор того, что тело запроса в конверте необходимо передать сервису Маппер		Пусто	String
 * 6.	packID	Уникальный идентификатор запроса		Уникальный идентификатор входящего запроса	String
 * +
 * 7. 	pack	Тело сообщения		Элемент с сообщением	String
 * +
 * 8. 	error	Код ошибки		Код ошибки (пусто  - успех, 1 - ошибка)	String
 * 9. 	errortext	Текст ошибки		Текст ошибки, если error = 1	String
 */

@Component
public class SiebelSender {
    private final Configure configure;
    private final KafkaProducerService kafkaProducerService;
    private final MessageToSiebelMap siebelMap;
    private final Utilites utilites;
    @Autowired
    public SiebelSender(Configure configure, KafkaProducerService kafkaProducerService, MessageToSiebelMap siebelMap, Utilites utilites) {
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.siebelMap = siebelMap;
        this.utilites = utilites;
    }
    Logger logger = LoggerFactory.getLogger(SiebelSender.class);

    public void sendToSiebel(GeoResponse geoResponse, String message) {

        /**
         * Создаем сообщение в Siebel
         *
         */
        MessageFromKafka messageToSiebel = new MessageFromKafka();
        messageToSiebel.setSystem_from("MP-Hard");
        messageToSiebel.setSystem_to(configure.getSiebelSystemTo());
        messageToSiebel.setService("MP.address");
        messageToSiebel.setPackID(geoResponse.getPackId());
        messageToSiebel.setPack(message);
        if (geoResponse.isSuccess()) {
            messageToSiebel.setError("");
            messageToSiebel.setErrortext("");
        } else {
            messageToSiebel.setError("1");
            messageToSiebel.setErrortext(utilites.getWrapNull(geoResponse.getResult()));
        }
        try {
            kafkaProducerService.sendMessage(configure.getSiebelTopic(), siebelMap.getJsonToStr(messageToSiebel));
        } catch (Exception exception) {
            logger.error("UsbLOg:При подготовке и отправке сообщения в Зибель произошла ошибка");
            logger.error("UsbLOg:Trace:", exception);
        }
    }
}
