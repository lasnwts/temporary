package ru.usb.siebeltomobileapp.model;

/**
 * . В случае, если значение в поле "service" = "MP.address", то:
 * 2.1 выполняется запрос к представлению T_DADATA_GEO_HISTORY в DB DMBY для обогащения полученного адреса данными по геокоординатам:
 * Процедура получения данных по геокоординатам адреса
 * select t.GEO_LAT, t.GEO_LON from T_DADATA_GEO_HISTORY t where t.ID_ADRESS = 'значение поля externalId';
 */
public class Geo {

    private String geoLon;
    private String geoLan;

    public Geo() {
    }

    public Geo(String geoLon, String geoLan) {
        this.geoLon = geoLon;
        this.geoLan = geoLan;
    }

    public String getGeoLon() {
        return geoLon;
    }

    public void setGeoLon(String geoLon) {
        this.geoLon = geoLon;
    }

    public String getGeoLan() {
        return geoLan;
    }

    public void setGeoLan(String geoLan) {
        this.geoLan = geoLan;
    }

    @Override
    public String toString() {
        return "Geo{" +
                "geoLon='" + geoLon + '\'' +
                ", geoLan='" + geoLan + '\'' +
                '}';
    }
}
