package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Phone;
import ru.usb.siebeltomobileapp.mapper.PhoneMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class PhoneSender {

    Logger logger = LoggerFactory.getLogger(PhoneSender.class);

    private final PhoneMap phoneMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public PhoneSender(PhoneMap phoneMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.phoneMap = phoneMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param phoneString - строка с сообщением
     * @param route       - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String phoneString, String route) {

        if (phoneString == null) {
            logger.error("UsbLog: Строка phoneString ==NULL");
            return false;
        }

        Phone phone = phoneMap.messageMapper(phoneString);

        if (phone == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", phoneString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.phone : {}", phone);

        //Проверяем дату и меняем в случае ее присутствия
        if (phone.getData() != null && aux.checkDateTime(phone.getData().getCreatedTimestamp())) {
            phone.getData().setCreatedTimestamp(aux.getUnixTime(phone.getData().getCreatedTimestamp()));
        }

        //Отправлен сообщение в топик
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(phoneMap.getJsonToStr(phone)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(phoneMap.getJsonToStr(phone)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(phoneMap.getJsonToStr(phone)));
            return false;
        }

    }
}
