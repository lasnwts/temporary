package ru.usb.siebeltomobileapp.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.Debt;
import ru.usb.siebeltomobileapp.mapper.DebtMap;
import ru.usb.siebeltomobileapp.service.kafka.produce.KafkaProducerService;
import ru.usb.siebeltomobileapp.utils.AuxMethods;

@Component
public class DebtSender {
    Logger logger = LoggerFactory.getLogger(DebtSender.class);

    private final DebtMap debtMap;

    private final KafkaProducerService kafkaProducerService;

    private final AuxMethods aux;

    @Autowired
    public DebtSender(DebtMap debtMap, KafkaProducerService kafkaProducerService, AuxMethods aux) {
        this.debtMap = debtMap;
        this.kafkaProducerService = kafkaProducerService;
        this.aux = aux;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @param route         - топик для МП
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString, String route) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        Debt debt = debtMap.messageMapper(messageString);

        if (debt == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.debt : {}", debt);


        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         *
         * service - MP.debt Поле	Формат данных от SIebel	Формат данных для МП
         * 1 agreement_date	MM/DD/YYYY	YYYY-MM-DD
         * 2 cession_agreement_date	MM/DD/YYYY	YYYY-MM-DD
         * 3 next_payment_date	MM/DD/YYYY	YYYY-MM-DD
         * 4 return_period	MM/DD/YYYY	YYYY-MM-DD
         * 5 overdue_date	MM/DD/YYYY	YYYY-MM-DD
         * 6 cancellation_date	MM/DD/YYYY	YYYY-MM-DD
         * 7 last_payment_date	MM/DD/YYYY	YYYY-MM-DD
         * 8 judgment_effective_date	MM/DD/YYYY	YYYY-MM-DD
         * 9 stage_start_date	MM/DD/YYYY HH24:MI:SS	YYYY-MM-DD
         */
        //1 agreement_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getAgreementDate())) {
            debt.getData().setAgreementDate(aux.getMpDate(debt.getData().getAgreementDate()));
        }
        //2 cession_agreement_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getCessionAgreementDate())) {
            debt.getData().setCessionAgreementDate(aux.getMpDate(debt.getData().getCessionAgreementDate()));
        }
        //3 next_payment_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getNextPaymentDate())) {
            debt.getData().setNextPaymentDate(aux.getMpDate(debt.getData().getNextPaymentDate()));
        }
        //4 return_period
        if (debt.getData() != null && aux.checkDate(debt.getData().getReturnPeriod())) {
            debt.getData().setReturnPeriod(aux.getMpDate(debt.getData().getReturnPeriod()));
        }
        //5 overdue_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getOverdueDate())) {
            debt.getData().setOverdueDate(aux.getMpDate(debt.getData().getOverdueDate()));
        }
        //6 cancellation_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getCancellationDate())) {
            debt.getData().setCancellationDate(aux.getMpDate(debt.getData().getCancellationDate()));
        }
        //7 last_payment_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getLastPaymentDate())) {
            debt.getData().setLastPaymentDate(aux.getMpDate(debt.getData().getLastPaymentDate()));
        }
        //8 judgment_effective_date
        if (debt.getData() != null && aux.checkDate(debt.getData().getJudgmentEffectiveDate())) {
            debt.getData().setJudgmentEffectiveDate(aux.getMpDate(debt.getData().getJudgmentEffectiveDate()));
        }
        //9 stage_start_date
        if (debt.getData() != null && aux.checkDateTime(debt.getData().getStageStartDate())) {
            debt.getData().setStageStartDate(aux.getMpDateTime(debt.getData().getStageStartDate()));
        }

        //excitation_date
        if (kafkaProducerService.sendMessage(route, aux.getWrapNull(debtMap.getJsonToStr(debt)))) {
            logger.info("UsbLog:Успешная отправки сообщения Phone в Topic={}, сообщение:{}; ", route, aux.getWrapNull(debtMap.getJsonToStr(debt)));
            return true;
        } else {
            logger.error("UsbLog:Ошибка при отправке пакета Phone в топик Topic={}; , сообщение:{}; ", route, aux.getWrapNull(debtMap.getJsonToStr(debt)));
            return false;
        }
    }
}
