package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * {
 * "externalId": "1-IHMYC7R",
 * "internalId": "",
 * "data": {
 * "court": "Нотариус города Стеритамак РБ Бусалаева Наталья Алексеевна",
 * "resultOfCourtsDecision": "Совершена ИН",
 * "status": "Завершено",
 * "monitoringResult": "Сбор документов завершен",
 * "debtId": "1-23RN74-17",
 * "numberCasesInCourt": "У-0000605027-0",
 * "submissionClaimDate": "",
 * "courtClaimSendingDate": "",
 * "type": "Исполнительная надпись",
 * "id": "1-HPB8FZX",
 * "amountJudgment": "0",
 * "amountRequirements": "90986.81"
 * }
 * }
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JudicialData {

    @JsonProperty("court")
    private String court; // "Нотариус города Стерлитамак РБ Бусалаева Наталья Алексеевна",

    @JsonProperty("resultOfCourtsDecision")
    private String resultOfCourtsDecision; //Совершена ИН

    @JsonProperty("status")
    private String status; //Завершено

    @JsonProperty("monitoringResult")
    private String monitoringResult; //Сбор документов завершен

    @JsonProperty("debtId")
    private String debtId; //1-23RN74-17

    @JsonProperty("numberCasesInCourt")
    private String numberCasesInCourt; //0000605027-0

    @JsonProperty("submissionClaimDate")
    private String submissionClaimDate;

    @JsonProperty("courtClaimSendingDate")
    private String courtClaimSendingDate;

    @JsonProperty("type")
    private String type; //Исполнительная надпись

    @JsonProperty("amountJudgment")
    private String amountJudgment; //0

    @JsonProperty("amountRequirements")
    private String amountRequirements; //90986.81

    public JudicialData() {
        //
    }

    public String getCourt() {
        return court;
    }

    public void setCourt(String court) {
        this.court = court;
    }

    public String getResultOfCourtsDecision() {
        return resultOfCourtsDecision;
    }

    public void setResultOfCourtsDecision(String resultOfCourtsDecision) {
        this.resultOfCourtsDecision = resultOfCourtsDecision;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMonitoringResult() {
        return monitoringResult;
    }

    public void setMonitoringResult(String monitoringResult) {
        this.monitoringResult = monitoringResult;
    }

    public String getDebtId() {
        return debtId;
    }

    public void setDebtId(String debtId) {
        this.debtId = debtId;
    }

    public String getNumberCasesInCourt() {
        return numberCasesInCourt;
    }

    public void setNumberCasesInCourt(String numberCasesInCourt) {
        this.numberCasesInCourt = numberCasesInCourt;
    }

    public String getSubmissionClaimDate() {
        return submissionClaimDate;
    }

    public void setSubmissionClaimDate(String submissionClaimDate) {
        this.submissionClaimDate = submissionClaimDate;
    }

    public String getCourtClaimSendingDate() {
        return courtClaimSendingDate;
    }

    public void setCourtClaimSendingDate(String courtClaimSendingDate) {
        this.courtClaimSendingDate = courtClaimSendingDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmountJudgment() {
        return amountJudgment;
    }

    public void setAmountJudgment(String amountJudgment) {
        this.amountJudgment = amountJudgment;
    }

    public String getAmountRequirements() {
        return amountRequirements;
    }

    public void setAmountRequirements(String amountRequirements) {
        this.amountRequirements = amountRequirements;
    }

    @Override
    public String toString() {
        return "DebtData{" +
                "court='" + court + '\'' +
                ", resultOfCourtsDecision='" + resultOfCourtsDecision + '\'' +
                ", status='" + status + '\'' +
                ", monitoringResult='" + monitoringResult + '\'' +
                ", debtId='" + debtId + '\'' +
                ", numberCasesInCourt='" + numberCasesInCourt + '\'' +
                ", submissionClaimDate='" + submissionClaimDate + '\'' +
                ", courtClaimSendingDate='" + courtClaimSendingDate + '\'' +
                ", type='" + type + '\'' +
                ", amountJudgment='" + amountJudgment + '\'' +
                ", amountRequirements='" + amountRequirements + '\'' +
                '}';
    }
}
