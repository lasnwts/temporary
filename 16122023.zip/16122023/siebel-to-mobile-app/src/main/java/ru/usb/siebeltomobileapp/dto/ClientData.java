package ru.usb.siebeltomobileapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * id	Идентификатор клиента
 * actualityDate	Дата актуальности
 * birthday	Дата рождения
 * fullName	ФИО полностью
 * lastName	Фамилия
 * firstName	Имя
 * middleName	Отчество
 * passportIssueDate	Дата выдачи паспорта
 * passportIssuer	Кто выдал паспорт
 * passport	Серия-номер паспорта
 * organization	Место работы
 * placeWork	Место работы (должность)
 * clientAlert	Алерты по пользователю (мошенник! Нельзя контактировать! И прочее…)
 * debtsCount	Количество долгов
 * debtsSum 	Сумма долгов
 * sumPayments	Сумма платежей
 * allOsz	Общая сумма задолженности
 * lawsuitAvail	Есть ли исполнительные производства
 * death_date	Дата смерти
 * debtOverdueCount	Всего договоров на просрочке поле "в т.ч. на просрочке"
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientData {
    @JsonProperty("actualityDate")
    private String actualityDate; //	Дата актуальности
    @JsonProperty("birthday")
    private String birthday; //	Дата рождения
    @JsonProperty("fullName")
    private String fullName; //	ФИО полностью

    @JsonProperty("lastName")
    private String lastName; //	Фамилия

    @JsonProperty("firstName")
    private String firstName; //	Имя

    @JsonProperty("middleName")
    private String middleName; //	Отчество

    @JsonProperty("passportIssueDate")
    private String passportIssueDate; //	Дата выдачи паспорта

    @JsonProperty("passportIssuer")
    private String passportIssuer; //	Кто выдал паспорт

    @JsonProperty("passport")
    private String passport; //	Серия-номер паспорта

    @JsonProperty("organization")
    private String organization; //	Место работы

    @JsonProperty("placeWork")
    private String placeWork; //	Место работы (должность)

    @JsonProperty("clientAlert")
    private String clientAlert; //	Алерты по пользователю (мошенник! Нельзя контактировать! И прочее…)

    @JsonProperty("debtsCount")
    private String debtsCount; //	Количество долгов

    @JsonProperty("debtsSum ")
    private String debtsSum; // 	Сумма долгов

    @JsonProperty("sumPayments")
    private String sumPayments; //	Сумма платежей

    @JsonProperty("allOsz")
    private String allOsz; //	Общая сумма задолженности

    @JsonProperty("lawsuitAvail")
    private String lawsuitAvail; //	Есть ли исполнительные производства

    @JsonProperty("deathDate")
    private String deathDate; //	Дата смерти

    @JsonProperty("debtOverdueCount")
    private String debtOverdueCount; //	Всего договоров на просрочке поле "в т.ч. на просрочке"

    public ClientData() {
        //
    }

    public String getActualityDate() {
        return actualityDate;
    }

    public void setActualityDate(String actualityDate) {
        this.actualityDate = actualityDate;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getPassportIssueDate() {
        return passportIssueDate;
    }

    public void setPassportIssueDate(String passportIssueDate) {
        this.passportIssueDate = passportIssueDate;
    }

    public String getPassportIssuer() {
        return passportIssuer;
    }

    public void setPassportIssuer(String passportIssuer) {
        this.passportIssuer = passportIssuer;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getPlaceWork() {
        return placeWork;
    }

    public void setPlaceWork(String placeWork) {
        this.placeWork = placeWork;
    }

    public String getClientAlert() {
        return clientAlert;
    }

    public void setClientAlert(String clientAlert) {
        this.clientAlert = clientAlert;
    }

    public String getDebtsCount() {
        return debtsCount;
    }

    public void setDebtsCount(String debtsCount) {
        this.debtsCount = debtsCount;
    }

    public String getDebtsSum() {
        return debtsSum;
    }

    public void setDebtsSum(String debtsSum) {
        this.debtsSum = debtsSum;
    }

    public String getSumPayments() {
        return sumPayments;
    }

    public void setSumPayments(String sumPayments) {
        this.sumPayments = sumPayments;
    }

    public String getAllOsz() {
        return allOsz;
    }

    public void setAllOsz(String allOsz) {
        this.allOsz = allOsz;
    }

    public String getLawsuitAvail() {
        return lawsuitAvail;
    }

    public void setLawsuitAvail(String lawsuitAvail) {
        this.lawsuitAvail = lawsuitAvail;
    }

    public String getDeathDate() {
        return deathDate;
    }

    public void setDeathDate(String deathDate) {
        this.deathDate = deathDate;
    }

    public String getDebtOverdueCount() {
        return debtOverdueCount;
    }

    public void setDebtOverdueCount(String debtOverdueCount) {
        this.debtOverdueCount = debtOverdueCount;
    }

    @Override
    public String toString() {
        return "ClientData{" +
                ", actualityDate='" + actualityDate + '\'' +
                ", birthday='" + birthday + '\'' +
                ", fullName='" + fullName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", passportIssueDate='" + passportIssueDate + '\'' +
                ", passportIssuer='" + passportIssuer + '\'' +
                ", passport='" + passport + '\'' +
                ", organization='" + organization + '\'' +
                ", placeWork='" + placeWork + '\'' +
                ", clientAlert='" + clientAlert + '\'' +
                ", debtsCount='" + debtsCount + '\'' +
                ", debtsSum='" + debtsSum + '\'' +
                ", sumPayments='" + sumPayments + '\'' +
                ", allOsz='" + allOsz + '\'' +
                ", lawsuitAvail='" + lawsuitAvail + '\'' +
                ", death_date='" + deathDate + '\'' +
                ", debtOverdueCount='" + debtOverdueCount + '\'' +
                '}';
    }
}
