package ru.usb.siebeltomobileapp.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.siebeltomobileapp.dto.OtherContact;
import ru.usb.siebeltomobileapp.utils.Utilites;

@Component
public class OtherContactMap {


    Logger logger = LoggerFactory.getLogger(OtherContactMap.class);

    private final Utilites utilites;

    @Autowired
    public OtherContactMap(Utilites utilites) {
        this.utilites = utilites;
    }

    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Мапинг строки в объект MessageFromKafka
     *
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public OtherContact messageMapper(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [OtherContact]: поступил объект [message] == NULL! Класс [OtherContact]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        OtherContact otherContact = null;

        try {
            otherContact = objectMapper.readValue(utilites.wrapNullJson(message), OtherContact.class);
            logger.info("Object [otherContact]:{}", otherContact);
            logger.info("Object [otherContact.data]:{}", otherContact.getData());
            return otherContact;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Преобразование объекта в строку JSON
     *
     * @param otherContact объект
     * @return - строка Json
     */
    public String getJsonToStr(OtherContact otherContact) {

        if (otherContact == null) {
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [otherContact] == NULL! Класс [otherContact] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(otherContact);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [{}] в JSON строку!", objectMapper);
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:Описание ошибки:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
