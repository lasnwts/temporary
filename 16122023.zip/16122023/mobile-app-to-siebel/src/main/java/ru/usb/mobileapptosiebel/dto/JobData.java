package ru.usb.mobileapptosiebel.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 1 id	Идентификатор, первичный ключ
 * 2 clientId	Связь с клиентом
 * 3 contactDateTime	Дата-время выхода на контакт
 * 4 contactType	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
 * 5 debtId	Идентификатор долга
 * 6 addressId	Адрес, если это DEPARTURE
 * 7 phoneId	Телефон, если это CALL
 * 8 judicalId	Судебное производство, если это JUDICAL
 * 9 enforcmentId	Исполнительное производство, если это ENFORCEMENT
 * 10 otherContactId	Онлайн контакт, если это ONLINE
 * 11 jobDate	Дата постановки задания
 * 12 status	Могут быть значения: CREATED, COMPLETE, CANCELED
 * 13 createdTimestamp	Дата и время создания объекта на МП
 * 14 jobType	Текстовое значение типа задания (для * 15 задач созданных в МП берутся данные из contact_tree_node)
 * 15 jobSubtype	Текстовое значение подтипа задания (для задач созданных в МП берутся данные из contact_tree_node)
 * 16 nodeId	Идентификатор узла подтипа задания из связанного дерева (для запуска дерева *  регистрации результата с данного шага)
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobData {

    @JsonProperty("clientId")
    private String clientId; //	Связь с клиентом

    @JsonProperty("contactDateTime")
    private String contactDateTime; //	Дата-время выхода на контакт

    @JsonProperty("contactType")
    private String contactType; //	Тип контакта на задание ВЫЕЗД, ЗВОНОК, ОНЛАЙН_КОНТАКТ, СудПроизводство/ИсполПроизводство (константы DEPARTURE, CALL, ONLINE, JUDICAL, ENFORCEMENT)
    @JsonProperty("debtId")
    private String debtId; //	Идентификатор долга

    @JsonProperty("addressId")
    private String addressId; //	Адрес, если это DEPARTURE

    @JsonProperty("phoneId")
    private String phoneId; //	Телефон, если это CALL

    @JsonProperty("judicalId")
    private String judicalId; //	Судебное производство, если это JUDICAL

    @JsonProperty("enforcmentId")
    private String enforcmentId; //	Исполнительное производство, если это ENFORCEMENT

    @JsonProperty("otherContactId")
    private String otherContactId; //	Онлайн контакт, если это ONLINE

    @JsonProperty("jobDate")
    private String jobDate; //	Дата постановки задания

    @JsonProperty("status")
    private String status; //Могут быть значения: CREATED, COMPLETE, CANCELED

    @JsonProperty("createdTimestamp")
    private String createdTimestamp; //	Дата и время создания объекта на МП

    @JsonProperty("jobType")
    private String jobType; //	Текстовое значение типа задания (для задач созданных в МП берутся данные из contact_tree_node)

    @JsonProperty("jobSubtype")
    private String jobSubtype; //	Текстовое значение подтипа задания (для задач созданных в МП берутся данные из contact_tree_node)

    @JsonProperty("nodeId")
    private String nodeId; //	Идентификатор узла подтипа задания из связанного дерева (для запуска дерева  регистрации результата с данного шага)

    public JobData() {
        //
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getContactDateTime() {
        return contactDateTime;
    }

    public void setContactDateTime(String contactDateTime) {
        this.contactDateTime = contactDateTime;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getDebtId() {
        return debtId;
    }

    public void setDebtId(String debtId) {
        this.debtId = debtId;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getJudicalId() {
        return judicalId;
    }

    public void setJudicalId(String judicalId) {
        this.judicalId = judicalId;
    }

    public String getEnforcmentId() {
        return enforcmentId;
    }

    public void setEnforcmentId(String enforcmentId) {
        this.enforcmentId = enforcmentId;
    }

    public String getOtherContactId() {
        return otherContactId;
    }

    public void setOtherContactId(String otherContactId) {
        this.otherContactId = otherContactId;
    }

    public String getJobDate() {
        return jobDate;
    }

    public void setJobDate(String jobDate) {
        this.jobDate = jobDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getJobSubtype() {
        return jobSubtype;
    }

    public void setJobSubtype(String jobSubtype) {
        this.jobSubtype = jobSubtype;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }


    @Override
    public String toString() {
        return "JobData{" +
                ", clientId='" + clientId + '\'' +
                ", contactDateTime='" + contactDateTime + '\'' +
                ", contactType='" + contactType + '\'' +
                ", debtId='" + debtId + '\'' +
                ", addressId='" + addressId + '\'' +
                ", phoneId='" + phoneId + '\'' +
                ", judicalId='" + judicalId + '\'' +
                ", enforcmentId='" + enforcmentId + '\'' +
                ", otherContactId='" + otherContactId + '\'' +
                ", jobDate='" + jobDate + '\'' +
                ", status='" + status + '\'' +
                ", createdTimestamp='" + createdTimestamp + '\'' +
                ", jobType='" + jobType + '\'' +
                ", jobSubtype='" + jobSubtype + '\'' +
                ", nodeId='" + nodeId + '\'' +
                '}';
    }
}
