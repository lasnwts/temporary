package ru.usb.mobileapptosiebel.transformed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.config.Configure;
import ru.usb.mobileapptosiebel.dto.AddressData;
import ru.usb.mobileapptosiebel.mapper.AddressMap;
import ru.usb.mobileapptosiebel.service.ProcessMessage;
import ru.usb.mobileapptosiebel.utils.AuxMethods;

@Component
public class AddressSender {
    Logger logger = LoggerFactory.getLogger(AddressSender.class);
    private final AddressMap addressMap;
    private final AuxMethods aux;
    private final ProcessMessage processMessage;
    private final Configure configure;

    @Autowired
    public AddressSender(AddressMap addressMap, AuxMethods aux, ProcessMessage processMessage, Configure configure) {
        this.addressMap = addressMap;
        this.aux = aux;
        this.processMessage = processMessage;
        this.configure = configure;
    }

    /**
     * Метод отправки сообщения в топик МП и переделки даты
     *
     * @param messageString - строка с сообщением
     * @return - true - успех и false -нет
     */
    public boolean getTransformSend(String messageString) {

        if (messageString == null) {
            logger.error("UsbLog: Строка == NULL!");
            return false;
        }

        AddressData addressData = addressMap.messageMapper(messageString);

        if (addressData == null) {
            logger.error("UsbLog: Ошибка преобразования сообщения: {} в объект ", messageString);
            return false;
        }

        logger.info("UsbLog: Поступил объект:MP.address : {}", addressData);

        /**
         *  =-= Проверяем дату и меняем в случае ее присутствия =-=
         */

        //created_timestamp
        if (aux.checkUnixDateTime(addressData.getCreatedTimestamp())) {
            addressData.setCreatedTimestamp(aux.getDateSiebelFormatString(aux.parseUnixDate(addressData.getCreatedTimestamp())));
        }

        //Отправка
        if (processMessage.sendMessSiebel(aux.getWrapNull(addressMap.getJsonToStr(addressData)), configure.getServiceAddress(), aux.getUUID())) {
            logger.info("UsbLog:Сообщение отправлено в Siebel");
            return true;
        } else {
            logger.error("UsbLog: Ошибка - сообщение не удалось отправить в Siebel");
            return false;
        }
    }
}
