package ru.usb.mobileapptosiebel.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.mobileapptosiebel.dto.Job;
import ru.usb.mobileapptosiebel.dto.JobData;
import ru.usb.mobileapptosiebel.utils.Utilites;

@Component
public class JobMap {
    Logger logger = LoggerFactory.getLogger(JobMap.class);
    private final Utilites utilites;
    @Autowired
    public JobMap(Utilites utilites) {
        this.utilites = utilites;
    }
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Мапинг строки в объект MessageFromKafka
     * @param message - строка с объектом
     * @return - SdBid - объект
     */
    public JobData messageMapper(String message) {

        if (message == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("На маппер [Job]: поступил объект [message] == NULL! Класс [Job]");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        JobData job = null;

        try {
            job = objectMapper.readValue(utilites.wrapNullJson(message), JobData.class);
            logger.info("Object [Job]:{}", job);
            return job;
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : Ошибка при парсинге Json:{}", e.getMessage());
            logger.error("UsbLogWarning : StackTrace:", e);
            return null;
        }
    }

    /**
     * Преобразование объекта в строку JSON
     * @param job объект
     * @return - строка Json
     */
    public String getJsonToStr(JobData job) {

        if (job == null) {
            logger.error("UsbLog:-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект [job] == NULL! Класс [job] метод [getJsonToStr]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(job);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [job] в JSON строку!");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:Описание ошибки:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
    }
}
