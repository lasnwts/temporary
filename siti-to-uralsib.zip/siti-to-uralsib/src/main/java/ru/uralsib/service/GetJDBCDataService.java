package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Service;
import ru.uralsib.dto.Client;
import ru.uralsib.model.*;
import ru.uralsib.model.customer.*;
import ru.uralsib.utils.UtilsForConvert;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Petr Vershinin
 * create on 15.11.2022
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class GetJDBCDataService {

    /**
     * размер выборки jdbc
     */
    @Value("${app.fetchSize}")
    private int fetchSize;
    /**
     * дата миграции
     */
    @Value("${app.dateMigration}")
    private String dateMigration;

    private final DataSource dataSource;
    private final ConvertService convertService;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    /**
     * фильтр для кредитов
     */
//    private static final String FILTER_CREDITS = "\n where a1.amxtdwu1rtacctnum in (select r.cm_reln_acctnumb from GRBMASTPER gm \n" +
//            "left join GRBRELN r on r.cm_reln_custnumb = gm.cm_cust_custnumb\n" +
//            "where rownum < 500)";
    private static final String FILTER_CREDITS = " ";

    public Map<String, Integer> getData(List<Client> clientList) {
        Map<String, Integer> result = new HashMap<>();

        var clientLength = clientList.stream()
                .map(Client::getClient)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_CUST_CUSTNUMB", clientLength);
        log.info("получено максимальная длина поля Client {}", clientLength);

        var nameLength = clientList.stream()
                .map(Client::getName)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_CUST_INDCORPNAME", nameLength);
        log.info("получено максимальная длина поля NameClient {}", nameLength);

        var bornPlaceLength = clientList.stream()
                .map(Client::getBornPlace)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_BIRTH_PLACE", bornPlaceLength);
        log.info("получено максимальная длина поля BornPlace {}", bornPlaceLength);

        var residentLength = clientList.stream()
                .map(Client::getResident)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_RESIDENT_INDICATOR", residentLength);
        log.info("получено максимальная длина поля  Resident {}", residentLength);

        var innLength = clientList.stream()
                .map(Client::getInn)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_CUST_TAX_ID", innLength);
        log.info("получено максимальная длина поля Inn {}", innLength);

        var sexCodeLength = clientList.stream()
                .map(Client::getSexCode)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_CUST_SEX", sexCodeLength);
        log.info("получено максимальная длина поля SexCode {}", sexCodeLength);


        var marigeStatusCodeLength = clientList.stream()
                .map(Client::getMarigeStatusCode)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CM_CUST_MSSTAT", marigeStatusCodeLength);
        log.info("получено максимальная длина поля MarigeStatusCode {}", marigeStatusCodeLength);

        var docLength = clientList.stream()
                .map(Client::getDoc)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("DOC", docLength);
        log.info("получено максимальная длина поля Doc {}", docLength);

        var contactsLength = clientList.stream()
                .map(Client::getContacts)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("CONTACTS", contactsLength);
        log.info("получено максимальная длина поля Contacts {}", contactsLength);

        var addressesLength = clientList.stream()
                .map(Client::getAddresses)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("ADDRESSES", addressesLength);
        log.info("получено максимальная длина поля Addresses {}", addressesLength);

        var mainJobLength = clientList.stream()
                .map(Client::getMainJob)
                .filter(Objects::nonNull)
                .mapToInt(String::length)
                .max().orElseThrow(RuntimeException::new);
        result.put("MAIN_JOB", mainJobLength);
        log.info("получено максимальная длина поля  MainJob {}", mainJobLength);
        return result;
    }


    public List<Client> getClients() {
        List<Client> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); Statement stmt = conn.createStatement()) {
            stmt.setFetchSize(fetchSize);
            ResultSet rs = stmt.executeQuery("select CM_CUST_CUSTNUMB,\n" +
                    "       CM_CUST_INDCORPNAME,\n" +
                    "       CM_CUST_BIRTH_DATE,\n" +
                    "       CM_BIRTH_PLACE,\n" +
                    "       CM_CUST_EMAIL_ADDR_1,\n" +
                    "       CM_CUST_EMAIL_ADDR_2,\n" +
                    "       CM_RESIDENT_INDICATOR,\n" +
                    "       CM_CUST_TAX_ID,\n" +
                    "       CM_CUST_SEX,\n" +
                    "       CM_CUST_MSSTAT\n" +
                    "from GRBMASTPER where  CM_RESIDENT_INDICATOR = 'Y' AND rownum<500");
            int i = 0;

            while (rs.next()) {
                log.info("обработано " + i++ + " строк");
                Client ct = new Client();
                var id = rs.getString("CM_CUST_CUSTNUMB");
                ct.setClient("CITI_" + id);
                var mail1 = rs.getString("CM_CUST_EMAIL_ADDR_1");
                var mail2 = rs.getString("CM_CUST_EMAIL_ADDR_2");
                var inn = rs.getString("CM_CUST_TAX_ID");
                ct.setInn(inn == null ? "" : inn);
                var sex = UtilsForConvert.getSex(rs);
                ct.setSexCode(sex);
                String rStat = UtilsForConvert.getStat(rs, sex);
                ct.setMarigeStatusCode(rStat);
                ct.setName(rs.getString("CM_CUST_INDCORPNAME"));
                ct.setDatePers(sdf.format(rs.getDate("CM_CUST_BIRTH_DATE")));
                ct.setBornPlace(rs.getString("CM_BIRTH_PLACE"));

                ct.setDoc(getDoc(conn, id));
                ct.setContacts(getContacts(conn, id, mail1, mail2));
                ct.setAddresses(getAddresses(conn, id));
                ct.setMainJob(getMainJob(conn, id));

                ct.setRegStatus("YES");//"Значения нет Всегда заполнять = YES"
                ct.setSelfIntrst("");
                ct.setResident("1");//Все клиенты будут резиденты, то есть у всех = 1
                ct.setCountryCode("RU");//"Значения нет Заполняем всем = RU"
                ct.setFoundAR("");
                ct.setIName("");
                ct.setLaw("");
                ct.setBusiness("");
                ct.setAnkNotes("");
                ct.setInfOtkaz("");
                ct.setNotes("");
                ct.setVidClCode("");
                ct.setInspect("");
                ct.setAccBank("");
                ct.setDeclFio("");
                ct.setFailLevelCode("");
                ct.setLevEducCode("");
                ct.setVisaInfo("");
                ct.setIsUniformCred("");
                ct.setGrRiskHist("");
                ct.setWel("");
                ct.setExtraJob("");
                ct.setExtraReqs("");
                ct.setMigrCard("");
                list.add(ct);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return list;
    }


    private String getDoc(Connection conn, String id) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("select* from CUSTID where CMACIDCUSTNBR=" + id + " AND CMACIDCUSTIDTYP='PP'");

            String issued;
            String divisionCode;

            while (rs.next()) {
                var iDate = rs.getDate("CMACIDISSUEDATE");
                var eDate = (rs.getDate("CMACIDEXPIRYDATE"));
                var idSd = rs.getString("CMACIDCUSTIDCD");
                String resulIdSd = UtilsForConvert.getIdSd(idSd);
                var passport = rs.getString("CMACIDCUSTID");
                var idType = rs.getString("CMACIDCUSTIDTYP");
                sb.append(iDate == null ? ";" : (sdf.format(iDate)) + ";") //Дата выдачи;
                        .append(eDate == null ? ";" : (sdf.format(eDate)) + ";") //Действителен до;
                        .append(resulIdSd) //Признак основного документа;
                        .append(passport == null ? ";" : passport.substring(0, 4) + ";") //Серия;
                        .append(passport == null ? ";" : passport.substring(4) + ";") //Номер;
                        .append(";")//Место выдачи;
                        .append(idType == null ? ";" : 21 + ";"); // Код типа удостоверения;значение "PP", значит для Уралсиб значение "21"


            }
            ResultSet rsCA = stmt.executeQuery("select CA_KEY_VAL,CA_FIELD_VAL from CUSTMISC where CA_CUSTNO =" + id + " AND CA_KEY_VAL='IDPP01'");
            while (rsCA.next()) {
                issued = rsCA.getString("CA_FIELD_VAL");
                divisionCode = rsCA.getString("CA_FIELD_VAL");

                sb.append(divisionCode == null ? ";" : divisionCode.substring(7) + ";") //Кем выдан;;
                        .append(issued == null ? ";" : issued.substring(0, 7) + ";") //Код подразделения;
                        .append(";");//где выдан (код ФИАС города);
            }
            rsCA.close();
            rs.close();

        }


        return sb.toString();


    }


    private String getContacts(Connection conn, String id, String mail1, String mail2) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("select* from GRBTEL where CMCUSTTELCUSTNO="
                    + id + " AND ((CMCUSTTELTYPE='006')OR(CMCUSTTELTYPE='001'))");

            while (rs.next()) {
                var type = rs.getString("CMCUSTTELTYPE");
                var nbr = rs.getString("CMCUSTTELNBR");
                String rType = UtilsForConvert.getrType(type);
                sb.append("1;") //Признак действующего контакта;
                        .append(nbr == null ? ";" : nbr + ";") //Номер (адрес);
                        .append(rType == null ? ";" : rType)  //Принадлежность контакта;
                        .append("PHONE;"); //Тип связи;
            }
            rs.close();
        }
        return sb.append(";") //Комментарии пользователя;
                .append(";")//Примечание
                .append("1;")  //Признак действующего контакта;
                .append(mail1 == null ? ";" : mail1 + ";") //mail1
                .append(mail2 == null ? ";" : mail2 + ";")  //mail2
                .append(";")//Принадлежность контакта;
                .append("MAIL;") //Тип связи;
                .append(";") //Комментарии пользователя;
                .append(";").toString();//Примечание

    }


    private String getAddresses(Connection conn, String id) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("select * from GRBADDRESS where DWHADDRNUMBER=" + id + " AND ((DWHADDRTYPECODE='020')OR(DWHADDRTYPECODE='002' ))");
            while (rs.next()) {
                var typeCode = rs.getString("DWHADDRTYPECODE");
                String resCode = UtilsForConvert.getResCode(typeCode);
                String tryDesc = UtilsForConvert.getTryDesc(rs);
                var postCode = rs.getString("DWHADDRPOSTCODE");
                var line2 = rs.getString("DWHADDRLINE2");
                var line4 = rs.getString("DWHADDRLINE4");
                var line6 = rs.getString("DWHADDRLINE6");
                var line7 = rs.getString("DWHADDRLINE7");
                var house = UtilsForConvert.getHouse(line2, line7);
                var bDate = rs.getString("DWHADDRESTBDATE");
                Date date = UtilsForConvert.getDate(bDate);
                sb.append(resCode == null ? ";" : resCode) //Код типа адреса;
                        .append(tryDesc == null ? "" : tryDesc + ", ") //Страна;
                        .append(postCode == null ? "" : postCode + ", ") //Почтовый индекс;
                        .append(line4 == null ? "" : line4 + ", ") //Адресная строка 4
                        .append(line6 == null ? "" : line6 + ", ") //Улица / проспект / бульвар и прочее
                        .append(house == null ? "" : house + ";") //Дом, корпус / строение / литера, квартира
                        .append("1;") //Признак временной регистрации;
                        .append(date == null ? ";" : sdf.format(date) + ";") //Дата регистрации;
                        .append(";");//Дата окончания регистрации (если регистрация временная)
            }
            rs.close();
        }
        return sb.toString();


    }


    private String getMainJob(Connection conn, String id) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("select * from CUSTEMPL where CMCUSTNUMB=" + id);
            while (rs.next()) {
                String rtdt = UtilsForConvert.getDate(rs);
                var name = rs.getString("CMEMPRNAME");
                sb.append(";") //Адрес;
                        .append(";")//Код ОКВЭД вида деятельности;
                        .append(rtdt == null ? ";" : rtdt + ";") //Дата начала работы на данном месте;
                        .append(";") //Код документа, подтверждающего трудовую деятельность;
                        .append(";") //Должность;
                        .append(";") //ИНН места работы;
                        .append(name == null ? ";" : name + ";") //Название места работы;
                        .append(";"); //Стаж на данном месте работы, месяцев;
            }
            ResultSet rsTel = stmt.executeQuery("select* from GRBTEL where CMCUSTTELCUSTNO="
                    + id + " AND CMCUSTTELTYPE='002'");
            while (rsTel.next()) {
                var tel = rsTel.getString("CMCUSTTELNBR");
                sb.append(tel == null ? ";" : tel + ";");//Телефон организации)
            }
            rs.close();
            rsTel.close();
        }

        return sb.toString();
    }

    public List<Credit> getCredits() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select gr.cm_reln_acctnumb as S\n" +
                    "      ,gr.cm_reln_custnumb as CLIENT\n" +
                    "      ,a1.amxtdwu1rtacctnum as NDOG_US\n" +
                    "      ,a1.amxtdwu1costctr as DEPART\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END\n" +
                    "      ,a1.amxtdwu1rtorigloanamt as SUM\n" +
                    "      ,tp.loan_sum as SUM_VKP\n" +
                    "      ,tp.prc_sum as SUM_VKP_PRC\n" +
                    "      ,tp.loan_deb_sum as SUM_VKP_DEB\n" +
                    "      ,tp.prc_deb_sum as SUM_VKP_PRC_DEB\n" +
                    "      ,tp.sum_peni as SUM_VKP_PEN\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_BKI\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_OFFER\n" +
                    "      ,a2.amxtdwu2acorigrate as PSK_PRC\n" +
                    "      ,psk.PSK_SUM_B as psk\n" +
                    "      ,ag.amxtdwugzamemonote as UIDD\n" +
                    "      ,a1.amxtdwu1blday as DAYPAY\n" +
                    "      ,a1.amxtdwu1blday as DAYCALC\n" +
                    "      ,a2.AMXTDWU2RTCURRDUEAMT as SUMPAY\n" +
                    "      ,a1.AMXTDWU1RTNXTDUEDATE as DATE_PAY\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END_PPARAM\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_rem as OPER_COUNT\n" +
                    "      ,a1.amxtdwu1rtloanrate as PRC\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_BEG_ORIG\n" +
                    "      ,a1.amxtdwu1rtorigmaturdate as DATE_END_ORIG\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END_ADDS\n" +
                    "      ,a1.amxtdwu1dqtotdayspdue as TOTAL_DAYS_OVERDUE\n" +
                    "      ,a2.amxtdwu2_dq_tot_amt_pdue as SUM_OVERDUE\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_made as NUM_PMTS_MADE\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_rem as NUM_PMTS_REM\n" +
                    "      ,a2.amxtdwu2rtorigterm as ORIG_TERM\n" +
                    "      ,a2.amxtdwu2rtcurrterm as CURR_TERM\n" +
                    "      ,a2.amxtdwu2acorigrate as PRC_RATE_ORIG\n" +
                    "      ,a2.amxtdwu2acaccrday as PAY_DAY_ORIG\n" +
                    "      ,a1.AMXTDWU1RTLOANRATE as PRC_RATE_CURR\n" +
                    "      ,a1.AMXTDWU1BLDAY as PAY_DAY_CURR\n" +
                    "      ,a2.AMXTDWU2BLFLATAMT as PAY_SUM_CURR\n" +
                    "      ,a2.amxtdwu2blfrstduedate as DATE_FIRST_PAY\n" +
                    "      ,a2.amxtdwu2rtlstpmtdate as DATE_LASTPAY_COMMIT\n" +
                    "      ,a2.AMXTDWU2RTLSTPMTAMT as SUM_LASTPAY_COMMIT\n" +
                    "      ,a1.amxtdwu1rtnxtduedate as DATE_NEXT_PAYMENT\n" +
                    "      ,a2.AMXTDWU2RTCURRDUEAMT as SUM_NEXT_PAYMENT\n" +
                    "      ,ph.HOLIDAY_TYPE\n" +
                    "      ,ph.HOLIDAY_DATE_APPL\n" +
                    "      ,ph.HOLIDAY_DATE_PROV\n" +
                    "      ,ph.HOLIDAY_DATE_BEGIN\n" +
                    "      ,ph.HOLIDAY_DATE_END_PLAN\n" +
                    "      ,ph.HOLIDAY_DATE_END_FACT\n" +
                    "      ,ph.HOLIDAY_END_REASON\n" +
                    "      ,ph.HOLIDAY_DATE_TERM_APPL\n" +
                    "      ,ph.AFTER_HOLIDAY_DATE_FIRST_PAY_FACT\n" +
                    "      ,ph.HOLIDAY_DATE_FIRST_REAB_PAY\n" +
                    "      ,ph.HOLIDAY_DATE_LAST_REAB_PAY\n" +
                    "      ,ph.HOLIDAY_PRC_RATE\n" +
                    "      ,ph.HOLIDAY_PRC_SUM_TOT\n" +
                    "      ,ph.HOLIDAY_STATUS\n" +
                    "      ,ph.AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN\n" +
                    "      ,ph.DATE_END_BEFORE\n" +
                    "      ,ph.DATE_END_ACTUAL\n" +
                    "      ,ph.HOLIDAY_PRC_SUM_REM\n" +
                    "      ,d.department as DEPART_NEW\n" +
                    " from AMUWG ag \n" +
                    "left join GRBRELN gr on ag.amxtdwugrtacctnum = gr.cm_reln_acctnumb\n" +
                    "left join AMUW1 a1 on ag.amxtdwugrtacctnum = a1.amxtdwu1rtacctnum\n" +
                    "left join AMUW2 a2 on ag.amxtdwugrtacctnum = a2.amxtdwu2rtacctnum\n" +
                    "left join PLHOLIDAYS ph on ag.amxtdwugrtacctnum = ph.acc_num\n" +
                    "left join PSK psk on ag.amxtdwugrtacctnum = psk.acc_num\n" +
                    "left join TOTAL_PAY_OFPL tp on ag.amxtdwugrtacctnum = tp.acc_num\n" +
                    "left join DEPART d on ag.amxtdwugrtacctnum = d.id_credit";

            var departDict = convertService.getDepartDict();

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Credit(
                                    convertService.getFormatedText(rs.getString(1), "S"),
                                    convertService.getFormatedText(rs.getString(2), "CLIENT"),
                                    "FL",
                                    convertService.getFormatedText(rs.getString(3), "NDOG_US"),
                                    departDict.get(convertService.getFormatedText(rs.getString(4), "DEPART")),
                                    dateMigration,
                                    convertService.getFormatedText(rs.getTimestamp(5), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(6), "NUM"),
                                    convertService.getFormatedText(rs.getDouble(7), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(8), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(9), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(10), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(11), "STR_NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(12), "DATE_BKI"),
                                    convertService.getFormatedText(rs.getTimestamp(13), "DATE_OFFER"),
                                    convertService.getFormatedText(rs.getString(14), "PRC"),
                                    convertService.getFormatedText(rs.getDouble(15), "STR_NUM"),
                                    convertService.getFormatedText(rs.getString(16), "UID"),
                                    "АННУИТЕТ_ПЛАТЕЖ",
                                    rs.getString(17),
                                    rs.getString(18),
                                    convertService.getFormatedText(rs.getString(19), "NUM"),
                                    dateMigration,
                                    convertService.getFormatedText(rs.getTimestamp(20), "DATE_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(21), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(22), "INT"),
                                    "0",
                                    "1",
                                    "PRC_CREDIT",
                                    convertService.getFormatedText(rs.getString(23), "PRC"),
                                    dateMigration,
                                    "31/12/4012",
                                    convertService.getFormatedText(rs.getTimestamp(24), "DATE_BEG_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(25), "DATE_END_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(26), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(27), "INT"),
                                    convertService.getFormatedText(rs.getString(28), "NUM"),
                                    convertService.getFormatedText(rs.getString(29), "INT"),
                                    convertService.getFormatedText(rs.getString(30), "INT"),
                                    convertService.getFormatedText(rs.getString(31), "INT"),
                                    convertService.getFormatedText(rs.getString(32), "INT"),
                                    convertService.getFormatedText(rs.getString(33), "PRC"),
                                    convertService.getFormatedText(rs.getString(34), "DAY"),
                                    convertService.getFormatedText(rs.getString(35), "PRC"),
                                    convertService.getFormatedText(rs.getString(36), "DAY"),
                                    convertService.getFormatedText(rs.getString(37), "NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(38), "DATE_FIRST_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(39), "DATE_LASTPAY_COMMIT"),
                                    convertService.getFormatedText(rs.getString(40), "NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(41), "DATE_NEXT_PAYMENT"),
                                    convertService.getFormatedText(rs.getString(42), "NUM"),
                                    convertService.getFormatedText(rs.getString(43), "HOLIDAY_TYPE"),
                                    convertService.getFormatedText(rs.getTimestamp(44), "HOLIDAY_DATE_APPL"),
                                    convertService.getFormatedText(rs.getTimestamp(45), "HOLIDAY_DATE_PROV"),
                                    convertService.getFormatedText(rs.getTimestamp(46), "HOLIDAY_DATE_BEGIN"),
                                    convertService.getFormatedText(rs.getTimestamp(47), "HOLIDAY_DATE_END_PLAN"),
                                    convertService.getFormatedText(rs.getTimestamp(48), "HOLIDAY_DATE_END_FACT"),
                                    convertService.getFormatedText(rs.getString(49), "HOLIDAY_END_REASON"),
                                    convertService.getFormatedText(rs.getTimestamp(50), "HOLIDAY_DATE_TERM_APPL"),
                                    convertService.getFormatedText(rs.getTimestamp(51), "AFTER_HOLIDAY_DATE_FIRST_PAY_FACT"),
                                    convertService.getFormatedText(rs.getTimestamp(52), "HOLIDAY_DATE_FIRST_REAB_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(53), "HOLIDAY_DATE_LAST_REAB_PAY"),
                                    convertService.getFormatedText(rs.getDouble(54), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(55), "STR_NUM"),
                                    convertService.getFormatedText(rs.getString(56), "HOLIDAY_STATUS"),
                                    convertService.getFormatedText(rs.getTimestamp(57), "AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN"),
                                    convertService.getFormatedText(rs.getTimestamp(58), "DATE_END_BEFORE"),
                                    convertService.getFormatedText(rs.getTimestamp(59), "DATE_END_ACTUAL"),
                                    convertService.getFormatedText(rs.getDouble(60), "STR_NUM"),
                                    rs.getString(61),
                                    ""
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Credit> getCreditsTBank() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select gr.cm_reln_acctnumb as S\n" +
                    "      ,gr.cm_reln_custnumb as CLIENT\n" +
                    "      ,a1.amxtdwu1rtacctnum as NDOG_US\n" +
                    "      ,a1.amxtdwu1costctr as DEPART\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END\n" +
                    "      ,a1.amxtdwu1rtorigloanamt as SUM\n" +
                    "      ,tp.loan_sum as SUM_VKP\n" +
                    "      ,tp.prc_sum as SUM_VKP_PRC\n" +
                    "      ,tp.loan_deb_sum as SUM_VKP_DEB\n" +
                    "      ,tp.prc_deb_sum as SUM_VKP_PRC_DEB\n" +
                    "      ,tp.sum_peni as SUM_VKP_PEN\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_BKI\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_OFFER\n" +
                    "      ,a2.amxtdwu2acorigrate as PSK_PRC\n" +
                    "      ,psk.PSK_SUM_B as psk\n" +
                    "      ,ag.amxtdwugzamemonote as UIDD\n" +
                    "      ,a1.amxtdwu1blday as DAYPAY\n" +
                    "      ,a1.amxtdwu1blday as DAYCALC\n" +
                    "      ,a2.AMXTDWU2RTCURRDUEAMT as SUMPAY\n" +
                    "      ,a1.AMXTDWU1RTNXTDUEDATE as DATE_PAY\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END_PPARAM\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_rem as OPER_COUNT\n" +
                    "      ,a1.amxtdwu1rtloanrate as PRC\n" +
                    "      ,a1.amxtdwu1rtaccteffdate as DATE_BEG_ORIG\n" +
                    "      ,a1.amxtdwu1rtorigmaturdate as DATE_END_ORIG\n" +
                    "      ,a1.amxtdwu1rtcurrmaturdate as DATE_END_ADDS\n" +
                    "      ,a1.amxtdwu1dqtotdayspdue as TOTAL_DAYS_OVERDUE\n" +
                    "      ,a2.amxtdwu2_dq_tot_amt_pdue as SUM_OVERDUE\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_made as NUM_PMTS_MADE\n" +
                    "      ,a2.amxtdwu2_rt_num_pmts_rem as NUM_PMTS_REM\n" +
                    "      ,a2.amxtdwu2rtorigterm as ORIG_TERM\n" +
                    "      ,a2.amxtdwu2rtcurrterm as CURR_TERM\n" +
                    "      ,a2.amxtdwu2acorigrate as PRC_RATE_ORIG\n" +
                    "      ,a2.amxtdwu2acaccrday as PAY_DAY_ORIG\n" +
                    "      ,a1.AMXTDWU1RTLOANRATE as PRC_RATE_CURR\n" +
                    "      ,a1.AMXTDWU1BLDAY as PAY_DAY_CURR\n" +
                    "      ,a2.AMXTDWU2BLFLATAMT as PAY_SUM_CURR\n" +
                    "      ,a2.amxtdwu2blfrstduedate as DATE_FIRST_PAY\n" +
                    "      ,a2.amxtdwu2rtlstpmtdate as DATE_LASTPAY_COMMIT\n" +
                    "      ,a2.AMXTDWU2RTLSTPMTAMT as SUM_LASTPAY_COMMIT\n" +
                    "      ,a1.amxtdwu1rtnxtduedate as DATE_NEXT_PAYMENT\n" +
                    "      ,a2.AMXTDWU2RTCURRDUEAMT as SUM_NEXT_PAYMENT\n" +
                    "      ,ph.HOLIDAY_TYPE\n" +
                    "      ,ph.HOLIDAY_DATE_APPL\n" +
                    "      ,ph.HOLIDAY_DATE_PROV\n" +
                    "      ,ph.HOLIDAY_DATE_BEGIN\n" +
                    "      ,ph.HOLIDAY_DATE_END_PLAN\n" +
                    "      ,ph.HOLIDAY_DATE_END_FACT\n" +
                    "      ,ph.HOLIDAY_END_REASON\n" +
                    "      ,ph.HOLIDAY_DATE_TERM_APPL\n" +
                    "      ,ph.AFTER_HOLIDAY_DATE_FIRST_PAY_FACT\n" +
                    "      ,ph.HOLIDAY_DATE_FIRST_REAB_PAY\n" +
                    "      ,ph.HOLIDAY_DATE_LAST_REAB_PAY\n" +
                    "      ,ph.HOLIDAY_PRC_RATE\n" +
                    "      ,ph.HOLIDAY_PRC_SUM_TOT\n" +
                    "      ,ph.HOLIDAY_STATUS\n" +
                    "      ,ph.AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN\n" +
                    "      ,ph.DATE_END_BEFORE\n" +
                    "      ,ph.DATE_END_ACTUAL\n" +
                    "      ,ph.HOLIDAY_PRC_SUM_REM\n" +
                    "      ,d.department as DEPART_NEW\n" +
                    " from AMUWG ag \n" +
                    "left join GRBRELN gr on ag.amxtdwugrtacctnum = gr.cm_reln_acctnumb\n" +
                    "left join AMUW1 a1 on ag.amxtdwugrtacctnum = a1.amxtdwu1rtacctnum\n" +
                    "left join AMUW2 a2 on ag.amxtdwugrtacctnum = a2.amxtdwu2rtacctnum\n" +
                    "left join PLHOLIDAYS ph on ag.amxtdwugrtacctnum = ph.acc_num\n" +
                    "left join PSK psk on ag.amxtdwugrtacctnum = psk.acc_num\n" +
                    "left join TOTAL_PAY_OFPL tp on ag.amxtdwugrtacctnum = tp.acc_num\n" +
                    "left join DEPART d on ag.amxtdwugrtacctnum = d.id_credit";

            var departDict = convertService.getDepartDict();

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Credit(
                                    convertService.getFormatedText(rs.getString(1), "S"),
                                    convertService.getFormatedText(rs.getString(2), "CLIENT"),
                                    "FL",
                                    convertService.getFormatedText(rs.getString(3), "NDOG_US"),
                                    departDict.get(convertService.getFormatedText(rs.getString(4), "DEPART")),
                                    dateMigration,
                                    convertService.getFormatedText(rs.getTimestamp(5), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(6), "NUM"),
                                    convertService.getFormatedText(rs.getDouble(7), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(8), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(9), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(10), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(11), "STR_NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(12), "DATE_BKI"),
                                    convertService.getFormatedText(rs.getTimestamp(13), "DATE_OFFER"),
                                    convertService.getFormatedText(rs.getString(14), "PRC"),
                                    convertService.getFormatedText(rs.getDouble(15), "STR_NUM"),
                                    convertService.getFormatedText(rs.getString(16), "UID"),
                                    "АННУИТЕТ_ПЛАТЕЖ",
                                    rs.getString(17),
                                    rs.getString(18),
                                    convertService.getFormatedText(rs.getString(19), "NUM"),
                                    dateMigration,
                                    convertService.getFormatedText(rs.getTimestamp(20), "DATE_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(21), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(22), "INT"),
                                    "0",
                                    "1",
                                    "PRC_CREDIT",
                                    convertService.getFormatedText(rs.getString(23), "PRC"),
                                    dateMigration,
                                    "31/12/4012",
                                    convertService.getFormatedText(rs.getTimestamp(24), "DATE_BEG_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(25), "DATE_END_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(26), "DATE_END"),
                                    convertService.getFormatedText(rs.getString(27), "INT"),
                                    convertService.getFormatedText(rs.getString(28), "NUM"),
                                    convertService.getFormatedText(rs.getString(29), "INT"),
                                    convertService.getFormatedText(rs.getString(30), "INT"),
                                    convertService.getFormatedText(rs.getString(31), "INT"),
                                    convertService.getFormatedText(rs.getString(32), "INT"),
                                    convertService.getFormatedText(rs.getString(33), "PRC"),
                                    convertService.getFormatedText(rs.getString(34), "DAY"),
                                    convertService.getFormatedText(rs.getString(35), "PRC"),
                                    convertService.getFormatedText(rs.getString(36), "DAY"),
                                    convertService.getFormatedText(rs.getString(37), "NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(38), "DATE_FIRST_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(39), "DATE_LASTPAY_COMMIT"),
                                    convertService.getFormatedText(rs.getString(40), "NUM"),
                                    convertService.getFormatedText(rs.getTimestamp(41), "DATE_NEXT_PAYMENT"),
                                    convertService.getFormatedText(rs.getString(42), "NUM"),
                                    convertService.getFormatedText(rs.getString(43), "HOLIDAY_TYPE"),
                                    convertService.getFormatedText(rs.getTimestamp(44), "HOLIDAY_DATE_APPL"),
                                    convertService.getFormatedText(rs.getTimestamp(45), "HOLIDAY_DATE_PROV"),
                                    convertService.getFormatedText(rs.getTimestamp(46), "HOLIDAY_DATE_BEGIN"),
                                    convertService.getFormatedText(rs.getTimestamp(47), "HOLIDAY_DATE_END_PLAN"),
                                    convertService.getFormatedText(rs.getTimestamp(48), "HOLIDAY_DATE_END_FACT"),
                                    convertService.getFormatedText(rs.getString(49), "HOLIDAY_END_REASON"),
                                    convertService.getFormatedText(rs.getTimestamp(50), "HOLIDAY_DATE_TERM_APPL"),
                                    convertService.getFormatedText(rs.getTimestamp(51), "AFTER_HOLIDAY_DATE_FIRST_PAY_FACT"),
                                    convertService.getFormatedText(rs.getTimestamp(52), "HOLIDAY_DATE_FIRST_REAB_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(53), "HOLIDAY_DATE_LAST_REAB_PAY"),
                                    convertService.getFormatedText(rs.getDouble(54), "STR_NUM"),
                                    convertService.getFormatedText(rs.getDouble(55), "STR_NUM"),
                                    convertService.getFormatedText(rs.getString(56), "HOLIDAY_STATUS"),
                                    convertService.getFormatedText(rs.getTimestamp(57), "AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN"),
                                    convertService.getFormatedText(rs.getTimestamp(58), "DATE_END_BEFORE"),
                                    convertService.getFormatedText(rs.getTimestamp(59), "DATE_END_ACTUAL"),
                                    convertService.getFormatedText(rs.getDouble(60), "STR_NUM"),
                                    rs.getString(61),
                                    ""
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<FailedCredit> creditsCheck(int numberCheck) {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select s,\n" +
                    "       REASON,\n" +
                    "       TOTAL_DAYS_OVERDUE,\n" +
                    "       DATE_END_ORIG\n" +
                    "       from V_GET_FAILED_CREDITS_CHECK_" + numberCheck;

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq, (rs, rowNum) ->
                            new FailedCredit(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    /**
     *
     * Проверка БКИ
     * @param numberCheck
     * @return
     */
    public List<FailedCredit> bkiCheck(int numberCheck) {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select s,\n" +
                    "       REASON,\n" +
                    "       TOTAL_DAYS_OVERDUE,\n" +
                    "       DATE_END_ORIG\n" +
                    "       from V_GET_FAILED_BKI_CHECK_" + numberCheck;

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq, (rs, rowNum) ->
                            new FailedCredit(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }


    public List<FailedCustomer> сustomersCheck(int numberCheck) {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select CLIENT,\n" +
                    "       REASON\n" +
                    "       from V_GET_FAILED_CUSTOMERS_CHECK_" + numberCheck;

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq, (rs, rowNum) ->
                            new FailedCustomer(
                                    rs.getString(1),
                                    rs.getString(2)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public void updateFailedBki(FailedCredit credit) {

        try (var conn = dataSource.getConnection();
             var statement = conn.prepareCall("{call PROC_UPDATE_FAILED_BKI(?)}");) {
            statement.setString(1, credit.S);
            statement.execute();

        } catch (SQLException ex) {
            log.error("[updateFailedBki]Ошибка:{}", ex.getMessage());
        }
    }

    public void updateFailedCredit(FailedCredit credit) {

        try (var conn = dataSource.getConnection();
             var statement = conn.prepareCall("{call PROC_UPDATE_FAILED_CREDIT(?)}");) {
            statement.setString(1, credit.S);
            statement.execute();

        } catch (SQLException ex) {
            log.error("[updateFailedCredit]Ошибка:{}", ex.getMessage());
        }
    }

    public void updateCustomer(String customer, String processed) {

        try (var conn = dataSource.getConnection();
             var statement = conn.prepareStatement("update TBANK_CUSTOMER c\n" +
                     "                set c.processed = ?\n" +
                     "                where c.client = ?");) {

            statement.setString(1, processed);
            statement.setString(2, customer);
            statement.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Успех по БКИ
     * @param credit -  номер БКИ
     * @param processed - строка успеха
     */
    public void updateBki(String credit, String processed) {

        try (var conn = dataSource.getConnection();
             var statement = conn.prepareStatement("update TBANK_UNLOAD_BKI c\n" +
                     "                set c.processed = ?\n" +
                     "                where c.S = ?");) {

            statement.setString(1, processed);
            statement.setString(2, credit);
            statement.execute();

        } catch (SQLException ex) {
            log.error("[updateBki]Ошибка:{}", ex.getMessage());
        }
    }

    /**
     * Успех по кредитам
     * @param credit
     * @param processed
     */
    public void updateCredits(String credit, String processed) {

        try (var conn = dataSource.getConnection();
             var statement = conn.prepareStatement("update TBANK_DOGOV c\n" +
                     "                set c.processed = ?\n" +
                     "                where c.S = ?");) {

            statement.setString(1, processed);
            statement.setString(2, credit);
            statement.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<Customer> getCustomers() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   c.CLIENT,\n" +
                    "   c.NAME,\n" +
                    "   c.DATE_PERS,\n" +
                    "   c.BORN_PLACE,\n" +
                    "   c.REG_STATUS,\n" +
                    "   c.AGREE_ADVERT,\n" +
                    "   c.AGREE_SELL,\n" +
                    "   c.RESIDENT,\n" +
                    "   c.COUNTRY_CODE,\n" +
                    "   c.INN,\n" +
                    "   c.SEX_CODE,\n" +
                    "   c.MARIGE_STATUS_CODE,\n" +
                    "   c.DECL_NAME,\n" +
                    "   c.DECL_CASE_GR_CODE,\n" +
                    "   c.LEV_EDUC_CODE,\n" +
                    "   c.well\n" +
                    "       from v_tbank_customer_not_processed c";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Customer(
                                    rs.getString(1),
                                    rs.getString(2),
                                    convertService.getFormatedText(rs.getTimestamp(3), "DATE_PERS"),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10),
                                    rs.getString(11),
                                    rs.getString(12),
                                    rs.getString(13),
                                    rs.getString(14),
                                    rs.getString(15),
                                    rs.getString(16)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custdocs> getCustdocs() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.CLIENT,\n" +
                    "   d.DOC_DATE,\n" +
                    "   d.DOC_DATE_END_M,\n" +
//                    "   d.DOC_DATE_END,\n" +
                    "   d.DOC_MAIN,\n" +
                    "   d.DOC_SER,\n" +
                    "   d.DOC_NUM,\n" +
                    "   d.DOC_PLACE,\n" +
                    "   d.DOC_TYPE,\n" +
                    "   d.DOC_WHO,\n" +
                    "   d.DOC_DEPART_CODE\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTDOCS d on c.client = d.client \n" +
                    "       where d.client is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custdocs(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "DOC_DATE"),
                                    convertService.getFormatedText(rs.getTimestamp(3), "DOC_DATE_END"),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custaddrs> getCustaddrs() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.CLIENT,\n" +
                    "   d.ADDRESS_TYPE,\n" +
                    "   d.Level_Fias_region,\n" +
                    "   d.AOGUID_region,\n" +
                    "   d.Level_Fias_region_area,\n" +
                    "   d.AOGUID_region_area,\n" +
                    "   d.Level_Fias_city,\n" +
                    "   d.AOGUID_city,\n" +
                    "   d.Level_Fias_set_city,\n" +
                    "   d.AOGUID_set_city,\n" +
                    "   d.Level_Fias_STREET,\n" +
                    "   d.AOGUID_street,\n" +
                    "   d.Level_Fias_house,\n" +
                    "   d.AOGUID_house,\n" +
                    "   d.Level_Fias_apartment,\n" +
                    "   d.AOGUID_apartment,\n" +
                    "   d.ADDRESS_HOUSE,\n" +
                    "   d.ADDRESS_HOUSE_KORP,\n" +
                    "   d.ADDRESS_APARTAMENT,\n" +
                    "   d.TEMPORARY_REG,\n" +
                    "   d.ADDRESS_DATE_REG,\n" +
                    "   d.DATE_REG_END\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTADDRS d on c.client = d.client \n" +
                    "       where d.client is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custaddrs(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10),
                                    rs.getString(11),
                                    rs.getString(12),
                                    rs.getString(13),
                                    rs.getString(14),
                                    rs.getString(15),
                                    rs.getString(16),
                                    rs.getString(17),
                                    rs.getString(18),
                                    rs.getString(19),
                                    rs.getString(20),
                                    convertService.getFormatedText(rs.getTimestamp(21), "ADDRESS_DATE_REG"),
                                    convertService.getFormatedText(rs.getTimestamp(22), "DATE_REG_END")
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custcont> getCustcont() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    " d.CLIENT,\n" +
                    "   d.CONTACTS_ACTIV,\n" +
                    "   d.CONTACTS_NUMB,\n" +
                    "   d.CONTACTS_PRIVATE,\n" +
                    "   d.CONTACTS_TYPE\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTCONT d on c.client = d.client \n" +
                    "       where d.client is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custcont(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custsoc> getCustsoc() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.SOC_CUSR_NMBR,\n" +
                    "   d.SOC_DATE_REG,\n" +
                    "   d.SOC_FOUND_CODE,\n" +
                    "   d.SOC_FOUND,\n" +
                    "   d.SOC_FOUND_NUM\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTSOC d on c.client = d.SOC_CUSR_NMBR \n" +
                    "       where d.SOC_CUSR_NMBR is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custsoc(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "SOC_DATE_REG"),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custacc> getCustacc() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.ACC_BANK_CLIENT,\n" +
                    "   d.ACC_BANK_BIK,\n" +
                    "   d.ACC_BANK_OPEN_DATE,\n" +
                    "   d.ACC_BANK_CLOSE_DATE,\n" +
                    "   d.ACC_BANK_NUMB\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTACC d on c.client = d.ACC_BANK_CLIENT \n" +
                    "       where d.ACC_BANK_CLIENT is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custacc(
                                    rs.getString(1),
                                    rs.getString(2),
                                    convertService.getFormatedText(rs.getTimestamp(3), "ACC_BANK_OPEN_DATE"),
                                    convertService.getFormatedText(rs.getTimestamp(4), "ACC_BANK_CLOSE_DATE"),
                                    rs.getString(5)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custinspect> getCustinspect() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.INSPECT_CUST_NMBR,\n" +
                    "   d.INSPECT_INSPECT_DATE,\n" +
                    "   d.INSPECT_INSPECTOR,\n" +
                    "   d.INSPECT_NAME,\n" +
                    "   d.INSPECT_NOTES\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTINSPECT d on c.client = d.INSPECT_CUST_NMBR \n" +
                    "       where d.INSPECT_CUST_NMBR is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custinspect(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "INSPECT_INSPECT_DATE"),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custempr> getCustempr() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.JOB_CLIENT,\n" +
                    "   d.JOB_MAIN_JOB,\n" +
                    "   d.JOB_WORK_PLACE_OKVED,\n" +
                    "   d.JOB_WORK_START_DATE,\n" +
                    "   d.JOB_KIND_DOC_CODE,\n" +
                    "   d.JOB_WORK_POSITION,\n" +
                    "   d.JOB_WORK_PLACE_INN,\n" +
                    "   d.JOB_WORK_PLACE_NAME,\n" +
                    "   d.JOB_SERVICE_LENGTH,\n" +
                    "   d.JOB_TEL_ORG\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join Tbank_Custempr d on c.client = d.JOB_CLIENT \n" +
                    "       where d.JOB_CLIENT is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custempr(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    convertService.getFormatedText(rs.getTimestamp(4), "JOB_WORK_START_DATE"),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custreqs> getCustreqs() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "      d.REQS_CUSTNUMB,\n" +
                    "   d.DATE_CHNG_NAME,\n" +
                    "   d.CHILDREN_COUNT,\n" +
                    "   d.DEPENDANTS_COUNT,\n" +
                    "   d.FAMILY_MEMBERS,\n" +
                    "   d.PREV_LAST_NAME,\n" +
                    "   d.REASON_CHNG_NAME,\n" +
                    "   d.OCCUPATION_STATE\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTREQS d on c.client = d.REQS_CUSTNUMB \n" +
                    "       where d.REQS_CUSTNUMB is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custreqs(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "DATE_CHNG_NAME"),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Custrisk> getCustrisk() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.GR_CLIENT,\n" +
                    "   d.GR_DATE_START,\n" +
                    "   d.GR_DATE_END,\n" +
                    "   d.GR_ACC_FEATURE,\n" +
                    "   d.GR_GROUP_NUM,\n" +
                    "   d.GR_CRED_GROUP_NUM,\n" +
                    "   d.GR_SERVICE_QUAL,\n" +
                    "   d.GR_PRC_RESERV,\n" +
                    "   d.GR_FIX,\n" +
                    "   d.GR_PEOPLE,\n" +
                    "   d.GR_RESUME\n" +
                    "       from v_tbank_customer_not_processed c\n" +
                    "       left join TBANK_CUSTRISK d on c.client = d.GR_CLIENT \n" +
                    "       where d.GR_CLIENT is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Custrisk(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "GR_DATE_START"),
                                    convertService.getFormatedText(rs.getTimestamp(3), "GR_DATE_END"),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10),
                                    rs.getString(11)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Dogov> getDogov() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" + //1
                    "   d.CLIENT,\n" + //2
                    "   d.SYMBOL,\n" + //3
                    "   d.NDOG_US,\n" + //4
                    "   d.DEPART,\n" + //5
                    "   d.DATE_BEG,\n" +  //6
                    "   d.DATE_END,\n" +  //7
                    "   d.SUM,\n" +  //8
                    "   d.SUM_VKP,\n" +  //9
                    "   d.SUM_VKP_PRC,\n" +  //10
                    "   d.SUM_VKP_DEB,\n" + //11
                    "   d.SUM_VKP_PRC_DEB,\n" +  //12
                    "   d.SUM_VKP_PEN,\n" + //13
                    "   d.DATE_BKI,\n" + //14
                    "   d.DATE_OFFER,\n" + //15
                    "   d.PSK_PRC_BEG,\n" + //16
                    "   d.PSK_BEG,\n" + //17
                    "   d.PSK_PRC,\n" + //18
                    "   d.PSK,\n" + //19
                    "   d.UUID,\n" +  //20
                    "   d.DEPART_TBANK\n" + //21
                    "from V_TBANK_DOGOV_NOT_PROCESSED d";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Dogov(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    convertService.getFormatedText(rs.getTimestamp(6), "DATE_BEG"),
                                    convertService.getFormatedText(rs.getTimestamp(7), "DATE_END"),
                                    convertService.getFormatedText(rs.getDouble(8), ""),
                                    convertService.getFormatedText(rs.getDouble(9), ""),
                                    convertService.getFormatedText(rs.getDouble(10), ""),
                                    convertService.getFormatedText(rs.getDouble(11), ""),
                                    convertService.getFormatedText(rs.getDouble(12), ""),
                                    convertService.getFormatedText(rs.getDouble(13), ""),
                                    convertService.getFormatedText(rs.getTimestamp(14), "DATE_BKI"),
                                    convertService.getFormatedText(rs.getTimestamp(15), "DATE_OFFER"),
                                    //convertService.getFormatedText(rs.getDouble(16),""),
                                    rs.getString(16),
                                    convertService.getFormatedText(rs.getDouble(17), ""),
                                    //convertService.getFormatedText(rs.getDouble(18),""),
                                    rs.getString(18),
                                    convertService.getFormatedText(rs.getDouble(19), ""),
                                    rs.getString(20),
                                    rs.getString(21)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Fact> getFact() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" +
                    "   d.dateo,\n" +
                    "   d.OPER,\n" +
                    "   d.SUM,\n" +
                    "   d.VALUTA,\n" +
                    "   t.DEPART\n" +
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_FACT d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Fact(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "dateo"),
                                    rs.getString(3),
                                    convertService.getFormatedText(rs.getDouble(4), ""),
                                    rs.getString(5),
                                    rs.getString(6)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Planall> getPlanall() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" +
                    "   d.dateo,\n" +
                    "   d.DATE_BEG,\n" +
                    "   d.DATE_END,\n" +
                    "   d.OPER,\n" +
                    "   d.SUM,\n" +
                    "   d.CHANGE,\n" +
                    "   d.VALUTA,\n" +
                    "   t.DEPART\n" +
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_PLANALL d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Planall(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "dateo"),
                                    convertService.getFormatedText(rs.getTimestamp(3), "DATE_BEG"),
                                    convertService.getFormatedText(rs.getTimestamp(4), "DATE_END"),
                                    rs.getString(5),
                                    convertService.getFormatedText(rs.getDouble(6), ""),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9)

                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Pparam> getPparam() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "    d.S,\n" +
                    "   d.VIDOPER,\n" +
                    "   d.DAYPAY,\n" +
                    "   d.DAYCALC,\n" +
                    "   d.SUMPAY,\n" +
                    "   d.DATE_CALC,\n" +
                    "   d.DATE_PAY,\n" +
                    "   d.DATE_END,\n" +
                    "   d.OPER_COUNT,\n" +
                    "   d.ONLY_PRC,\n" +
                    "   d.GASH_PAY_PERIOD,\n" +
                    "   t.DEPART\n" +
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_PPARAM d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Pparam(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    convertService.getFormatedText(rs.getDouble(5), ""),
                                    convertService.getFormatedText(rs.getTimestamp(6), "DATE_CALC"),
                                    convertService.getFormatedText(rs.getTimestamp(7), "DATE_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(8), "DATE_END"),
                                    rs.getString(9),
                                    rs.getString(10),
                                    rs.getString(11),
                                    rs.getString(12)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<PrcScheme> getPrcScheme() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" +
                    "   d.P_CODE,\n" +
                    "   d.PRC,\n" +
                    "   d.DATE_BEG,\n" +
                    "   d.DATE_END,\n" +
                    "   t.DEPART\n" +
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_PRC_SCHEME d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new PrcScheme(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
//                                    convertService.getFormatedText(rs.getDouble(3),""),
                                    convertService.getFormatedText(rs.getTimestamp(4), "DATE_BEG"),
                                    convertService.getFormatedText(rs.getTimestamp(5), "DATE_END"),
                                    rs.getString(6)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    public List<Accbalance> getAccbalance() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" +
                    "   d.ACC,\n" +
                    "   d.SUM,\n" +
                    "   t.DEPART\n" +
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_ACCBALANCE d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Accbalance(
                                    rs.getString(1),
                                    rs.getString(2),
                                    convertService.getFormatedText(rs.getDouble(3), ""),
                                    rs.getString(4)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    /**
     * d.S,d.TB_RELATIONSHIP, d.TB_TYPE, d.TB_LOANTYPECODE, d.TB_STARTAMOUOUTST, d.TB_CUROVERDUEDT_TA, d.TB_MSPYMNTNXTRDT, d.TB_MSPYMNTNTRSTDT, d.TB_PASTDUEDAYS, d.TB_PAIDPASTDUEDAYS, d.TB_LASTAMOUNT_30PD, d.TB_TTLAMOUNT24M30PD, d.TB_DEBTRANGE, d.TB_DEBTCALCDATE, d.TB_INCOMEWAYTYPE, d.TB_INCOMEINFOSOURCE, d.TB_COBORROWERSDEBT, d.TB_STATESUPPORT, d.TB_STATESUPPORTINFO, d.TB_LOANPURPOSECODE, d.TB_DATECONTRTERM
     *
     * @return
     */
    public List<UnloadBKI> getUnloadBki() {
        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select a.S ,a.TB_RELATIONSHIP, a.TB_TYPE ,a.TB_LOANTYPECODE, \n" +
                    "a.TB_STARTAMOUOUTST, a.TB_CUROVERDUEDT_TA,  a.TB_MSPYMNTNXTRDT,\n" +
                    "  a.TB_MSPYMNTNTRSTDT ,a.TB_PASTDUEDAYS,  a.TB_PAIDPASTDUEDAYS,  \n" +
                    "  a.TB_LASTAMOUNT_30PD,  a.TB_TTLAMOUNT24M30PD, a.TB_DEBTRANGE,  \n" +
                    "  a.TB_DEBTCALCDATE,\n" +
                    "  a.TB_INCOMEWAYTYPE,a.TB_INCOMEINFOSOURCE, a.TB_COBORROWERSDEBT , \n" +
                    "  a.TB_STATESUPPORT ,a.TB_STATESUPPORTINFO,a. TB_LOANPURPOSECODE,  \n" +
                    "  a.TB_DATECONTRTERM, b.DEPART  \n" +
                    "   from TBANK_UNLOAD_BKI a join TBANK_DOGOV b on a.S = b.S \n" +
                    "    where a.S is not null and a.processed is null";
            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq, (rs, rowNum) ->
                            new UnloadBKI(
                                    rs.getString(1),
                                    rs.getString(2),
                                    rs.getString(3),
                                    rs.getString(4),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10),
                                    rs.getString(11),
                                    rs.getString(12),
                                    rs.getString(13),
                                    rs.getString(14),
                                    rs.getString(15),
                                    rs.getString(16),
                                    rs.getString(17),
                                    rs.getString(18),
                                    rs.getString(19),
                                    rs.getString(20),
                                    rs.getString(21),
                                    rs.getString(22)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }


    public List<Adds> getAdds() {

        try (Connection conn = dataSource.getConnection();) {

            String sqlReq = "select \n" +
                    "   d.S,\n" +  //1
                    "   d.DATE_BEG_ORIG,\n" + //2
                    "   d.DATE_END_ORIG,\n" + //3
                    "   d.DATE_END,\n" + //4
                    "   d.TOTAL_DAYS_OVERDUE,\n" + //5
                    "   d.SUM_OVERDUE,\n" + //6
                    "   d.NUM_PMTS_MADE,\n" + //7
                    "   d.NUM_PMTS_REM,\n" + //8
                    "   d.ORIG_TERM,\n" + //9
                    "   d.CURR_TERM,\n" + //10
                    "   d.PRC_RATE_ORIG,\n" + //11
                    "   d.PAY_DAY_ORIG,\n" + //12
                    "   d.PRC_RATE_CURR,\n" + //13
                    "   d.PAY_DAY_CURR,\n" + //14
                    "   d.PAY_SUM_CURR,\n" + //15
                    "   d.DATE_FIRST_PAY,\n" + //16
                    "   d.DATE_LASTPAY_COMMIT,\n" + //17
                    "   d.SUM_LASTPAY_COMMIT,\n" + //18
                    "   d.DATE_NEXT_PAYMENT,\n" + //19
                    "   d.SUM_NEXT_PAYMENT,\n" + //20
                    "   d.REFINANCE,\n" + //21
                    "   t.DEPART\n" + //22
                    "from V_TBANK_DOGOV_NOT_PROCESSED t\n" +
                    "left join TBANK_MIGR_INFO d on d.s = t.s\n" +
                    "where d.S is not null";

            return new JdbcTemplate(new SingleConnectionDataSource(conn, true))
                    .query(sqlReq + FILTER_CREDITS, (rs, rowNum) ->
                            new Adds(
                                    rs.getString(1),
                                    convertService.getFormatedText(rs.getTimestamp(2), "DATE_BEG_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(3), "DATE_END_ORIG"),
                                    convertService.getFormatedText(rs.getTimestamp(4), "DATE_END"),
                                    rs.getString(5),
                                    rs.getString(6),
                                    rs.getString(7),
                                    rs.getString(8),
                                    rs.getString(9),
                                    rs.getString(10),
                                    //convertService.getFormatedText(rs.getDouble(11),""),
                                    rs.getString(11),
                                    rs.getString(12),
                                    //convertService.getFormatedText(rs.getDouble(13),""),
                                    rs.getString(13),
                                    rs.getString(14),
                                    convertService.getFormatedText(rs.getDouble(15), ""),
                                    convertService.getFormatedText(rs.getTimestamp(16), "DATE_FIRST_PAY"),
                                    convertService.getFormatedText(rs.getTimestamp(17), "DATE_LASTPAY_COMMIT"),
                                    convertService.getFormatedText(rs.getDouble(18), ""),
                                    convertService.getFormatedText(rs.getTimestamp(19), "DATE_NEXT_PAYMENT"),
                                    convertService.getFormatedText(rs.getDouble(20), ""),
                                    rs.getString(21),
                                    rs.getString(22)
                            ));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ArrayList<>();
        }
    }
}

