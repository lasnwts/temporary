package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.uralsib.dto.Client;
import ru.uralsib.utils.UtilsForConvert;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static ru.uralsib.config.Constant.*;

/**
 * @author Petr Vershinin
 * create on 11.11.2022
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CreateFileService {
    /**
     * путь конечного файла
     */
    @Value("${app.destination.folder}")
    private String folder;

    public String write(Map<String, Integer> map, List<Client> clients) throws IOException {
        List<String> listForWrite = new ArrayList<>();
        StringBuilder sb = getHeadSB(map);

        listForWrite.add(sb.toString());
        for (Client ct : clients) {
            listForWrite.add(getFinishLine(ct, map));
        }
        File file = new File("client.txt");

        FileUtils.writeLines(file, "cp866", listForWrite);
        FileUtils.delete(FileUtils.getFile(folder));
        FileUtils.moveFile(FileUtils.getFile(file),FileUtils.getFile(folder));

        return "Обработано "+clients.size()+" записей";
    }

    private StringBuilder getHeadSB(Map<String, Integer> map) {
        StringBuilder sb = new StringBuilder();
        sb.append(UtilsForConvert.getHeader(map.get("CM_CUST_CUSTNUMB"), CLIENT_MAX_SIZE, CLIENT))
                .append(UtilsForConvert.getHeader(0, DATE_ANK_MAX_SIZE, DATE_ANK))
                .append(UtilsForConvert.getHeader(map.get("CM_CUST_INDCORPNAME"), NAME_MAX_SIZE, NAME))
                .append(UtilsForConvert.getHeader(10, DATE_PERS_MAX_SIZE, DATE_PERS))
                .append(UtilsForConvert.getHeader(map.get("CM_BIRTH_PLACE"), BORN_PLACE_MAX_SIZE, BORN_PLACE))
                .append(UtilsForConvert.getHeader(map.get("DOC"), DOC_MAX_SIZE, DOC))
                .append(UtilsForConvert.getHeader(map.get("CONTACTS"), CONTACTS_MAX_SIZE, CONTACTS))
                .append(UtilsForConvert.getHeader(11, REG_STATUS_MAX_SIZE, REG_STATUS))
                .append(UtilsForConvert.getHeader(map.get("ADDRESSES"), ADDRESSES_MAX_SIZE, ADDRESSES))
                .append(UtilsForConvert.getHeader(0, SELF_INTRST_MAX_SIZE, SELF_INTRST))
                .append(UtilsForConvert.getHeader(1, AGREE_ADVERT_MAX_SIZE, AGREE_ADVERT))
                .append(UtilsForConvert.getHeader(3, RESIDENT_MAX_SIZE, RESIDENT))
                .append(UtilsForConvert.getHeader(3, COUNTRY_CODE_MAX_SIZE, COUNTRY_CODE))
                .append(UtilsForConvert.getHeader(map.get("CM_CUST_TAX_ID"), INN_MAX_SIZE, INN))
                .append(UtilsForConvert.getHeader(0, FONDS_AR_MAX_SIZE, FONDS_AR))
                .append(UtilsForConvert.getHeader(map.get("CM_CUST_SEX"), SEX_CODE_MAX_SIZE, SEX_CODE))
                .append(UtilsForConvert.getHeader(14, I_NAME_MAX_SIZE, I_NAME))
                .append(UtilsForConvert.getHeader(0, LAW_MAX_SIZE, LAW))
                .append(UtilsForConvert.getHeader(0, BUSINESS_MAX_SIZE, BUSINESS))
                .append(UtilsForConvert.getHeader(0, ANK_NOTES_MAX_SIZE, ANK_NOTES))
                .append(UtilsForConvert.getHeader(0, INF_OTKAZ_MAX_SIZE, INF_OTKAZ))
                .append(UtilsForConvert.getHeader(0, NOTES_MAX_SIZE, NOTES))
                .append(UtilsForConvert.getHeader(map.get("CM_CUST_MSSTAT"), MARIGE_STATUS_CODE_MAX_SIZE, MARIGE_STATUS_CODE))
                .append(UtilsForConvert.getHeader(0, VID_CL_CODE_MAX_SIZE, VID_CL_CODE))
                .append(UtilsForConvert.getHeader(0, INSPECT_MAX_SIZE, INSPECT))
                .append(UtilsForConvert.getHeader(0, ACC_BANK_MAX_SIZE, ACC_BANK))
                .append(UtilsForConvert.getHeader(0, FAIL_LEVEL_CODE_MAX_SIZE, FAIL_LEVEL_CODE))
                .append(UtilsForConvert.getHeader(0, LEV_EDUC_CODE_MAX_SIZE, LEV_EDUC_CODE))
                .append(UtilsForConvert.getHeader(0, VISA_INFO_MAX_SIZE, VISA_INFO))
                .append(UtilsForConvert.getHeader(0, IS_UNIFORM_CRED_MAX_SIZE, IS_UNIFORM_CRED))
                .append(UtilsForConvert.getHeader(0, GR_RISK_HIST_MAX_SIZE, GR_RISK_HIST))
                .append(UtilsForConvert.getHeader(0, WEL_MAX_SIZE, WEL))
                .append(UtilsForConvert.getHeader(map.get("MAIN_JOB"), MAIN_JOB_MAX_SIZE, MAIN_JOB))
                .append(UtilsForConvert.getHeader(0, EXTRA_JOB_MAX_SIZE, EXTRA_JOB))
                .append(UtilsForConvert.getHeader(0, EXTRA_REQS_MAX_SIZE, EXTRA_REQS))
                .append(UtilsForConvert.getHeader(0, MIGR_CARD_MAX_SIZE, MIGR_CARD))
                .append("END_HEAD");
        return sb;
    }

    private String getFinishLine(Client ct, Map<String, Integer> map) {

        StringBuilder sb = new StringBuilder();
        sb.append(getValue(ct.getClient(), CLIENT_MAX_SIZE, CLIENT, map.get("CM_CUST_CUSTNUMB"))).append(" ")
                .append(getValue(ct.getDateAnk(), DATE_ANK_MAX_SIZE, DATE_ANK, 0)).append(" ")
                .append(getValue(ct.getName(), NAME_MAX_SIZE, NAME, map.get("CM_CUST_INDCORPNAME"))).append(" ")
                .append(getValue(ct.getDatePers(), DATE_PERS_MAX_SIZE, DATE_PERS, 10)).append(" ")
                .append(getValue(ct.getBornPlace(), BORN_PLACE_MAX_SIZE, BORN_PLACE, map.get("CM_BIRTH_PLACE"))).append(" ")
                .append(getValue(ct.getDoc(), DOC_MAX_SIZE, DOC, map.get("DOC"))).append(" ")
                .append(getValue(ct.getContacts(), CONTACTS_MAX_SIZE, CONTACTS, map.get("CONTACTS"))).append(" ")
                .append(getValue(ct.getRegStatus(), REG_STATUS_MAX_SIZE, REG_STATUS, 11)).append(" ")
                .append(getValue(ct.getAddresses(), ADDRESSES_MAX_SIZE, ADDRESSES, map.get("ADDRESSES"))).append(" ")
                .append(getValue(ct.getSelfIntrst(), SELF_INTRST_MAX_SIZE, SELF_INTRST, 0)).append(" ")
                .append(getValue(ct.getAgreeAdvert(), AGREE_ADVERT_MAX_SIZE, AGREE_ADVERT, 0)).append(" ")
                .append(getValue(ct.getResident(), RESIDENT_MAX_SIZE, RESIDENT, 9)).append(" ")
                .append(getValue(ct.getCountryCode(), CONTACTS_MAX_SIZE, COUNTRY_CODE, 13)).append(" ")
                .append(getValue(ct.getInn(), INN_MAX_SIZE, INN, map.get("CM_CUST_TAX_ID"))).append(" ")
                .append(getValue(ct.getFoundAR(), FONDS_AR_MAX_SIZE, FONDS_AR, 0)).append(" ")
                .append(getValue(ct.getSexCode(), SEX_CODE_MAX_SIZE, SEX_CODE, 9)).append(" ")
                .append(getValue(ct.getIName(), I_NAME_MAX_SIZE, I_NAME, 0)).append(" ")
                .append(getValue(ct.getLaw(), LAW_MAX_SIZE, LAW, 0)).append(" ")
                .append(getValue(ct.getBusiness(), BUSINESS_MAX_SIZE, BUSINESS, 0)).append(" ")
                .append(getValue(ct.getAnkNotes(), ANK_NOTES_MAX_SIZE, ANK_NOTES, 0)).append(" ")
                .append(getValue(ct.getInfOtkaz(), INF_OTKAZ_MAX_SIZE, INF_OTKAZ, 0)).append(" ")
                .append(getValue(ct.getNotes(), NOTES_MAX_SIZE, NOTES, 0)).append(" ")
                .append(getValue(ct.getMarigeStatusCode(), MARIGE_STATUS_CODE_MAX_SIZE, MARIGE_STATUS_CODE, 9)).append(" ")
                .append(getValue(ct.getVidClCode(), VID_CL_CODE_MAX_SIZE, VID_CL_CODE, 0)).append(" ")
                .append(getValue(ct.getInspect(), INSPECT_MAX_SIZE, INSPECT, 0)).append(" ")
                .append(getValue(ct.getAccBank(), ACC_BANK_MAX_SIZE, ACC_BANK, 0)).append(" ")
                .append(getValue(ct.getDeclFio(), DECL_FIO_MAX_SIZE, DECL_FIO, 0)).append(" ")
                .append(getValue(ct.getFailLevelCode(), FAIL_LEVEL_CODE_MAX_SIZE, FAIL_LEVEL_CODE, 0)).append(" ")
                .append(getValue(ct.getLevEducCode(), LEV_EDUC_CODE_MAX_SIZE, LEV_EDUC_CODE, 0)).append(" ")
                .append(getValue(ct.getVisaInfo(), VISA_INFO_MAX_SIZE, VISA_INFO, 0)).append(" ")
                .append(getValue(ct.getIsUniformCred(), IS_UNIFORM_CRED_MAX_SIZE, IS_UNIFORM_CRED, 0)).append(" ")
                .append(getValue(ct.getGrRiskHist(), GR_RISK_HIST_MAX_SIZE, GR_RISK_HIST, 0)).append(" ")
                .append(getValue(ct.getWel(), WEL_MAX_SIZE, WEL, 0)).append(" ")
                .append(getValue(ct.getMainJob(), MAIN_JOB_MAX_SIZE, MAIN_JOB, map.get("MAIN_JOB"))).append(" ")
                .append(getValue(ct.getExtraJob(), EXTRA_JOB_MAX_SIZE, EXTRA_JOB, 0)).append(" ")
                .append(getValue(ct.getExtraReqs(), EXTRA_REQS_MAX_SIZE, EXTRA_REQS, 0)).append(" ")
                .append(getValue(ct.getMigrCard(), MIGR_CARD_MAX_SIZE, MIGR_CARD, 0)).append(" ")

        ;
        return sb.toString();


    }

    /**
     * @param data    - данные которые необходимо записать в файл
     * @param lConst  - константа длины поля
     * @param header  - заголовок с открывающейся угловой скобкой
     * @param lHeader - длина максимального поля в колонке из бд, если пустое ставиться 0, для некоторых значений выставляется в ручную
     * @return - строку с нужным количеством пробелов
     */
    private String getValue(String data, int lConst, String header, int lHeader) {

        String str = "";
        //если константа=0(случай когда значение пустое)1- boolean, то берем значение длины заголовка
        if (lConst == 0||lConst==1) {
            lConst = header.length();
        }


//если длина поля =0, то пробелы выставляем по константе
        if (lHeader > 0) {
            //если константа больше длины поля, справа дополняем пробелами
            if (lConst >= lHeader) {
                str = StringUtils.rightPad(data, lHeader);
            } else {
                if (data == null) {
                    str = "";
                } else {
                    str = data.substring(0, lConst);
                }

            }
        } else {
            str = StringUtils.rightPad(" ", lConst);
        }
        return str;
    }


}
