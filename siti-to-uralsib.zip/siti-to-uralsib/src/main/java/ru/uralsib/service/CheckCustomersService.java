package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.uralsib.model.customer.FailedCustomer;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class CheckCustomersService {

    private final GetJDBCDataService getJDBCDataService;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Проверка клиентов
     * @return Коллекция клиентов, не прошедших проверку
     */
    public List<FailedCustomer> checkCustomers() {

        var failedCustomers = new ArrayList<FailedCustomer>();

        for (var i = 1; i <= 11; i++) { //Был 5
            failedCustomers.addAll(getJDBCDataService.сustomersCheck(i)) ;
        }

        return failedCustomers;
    }
}
