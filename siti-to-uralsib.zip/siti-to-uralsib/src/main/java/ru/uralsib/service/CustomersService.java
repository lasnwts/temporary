package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.uralsib.model.*;
import ru.uralsib.service.s3.AmazonS3Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CustomersService {
    private final GetJDBCDataService getJDBCDataService;
    private final CheckCustomersService checkCustomersService;
    private final CsvService csvService;
    private final AmazonS3Service s3Service;
    private final MailService mailService;

    @Value("${file.delete:false}")
    private boolean deletedFile; //Удалять файлы после выгрузки

    /**
     * путь конечных файлов
     */
    @Value("${app.destination.folder.credits}")
    private String folderCredits;

    /**
     * Обработка данных по клиентам
     *
     * @throws IOException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    public void processingCustomers() throws IOException, NoSuchFieldException, IllegalAccessException {

        var failedCustomers = checkCustomersService.checkCustomers();

        folderCredits = this.getClass().getResource("/").getFile();

        if (failedCustomers == null || failedCustomers.size() == 0) {
            log.error("Нет данных об исключенных клиентах");
        } else {
            var dataObj = new ArrayList<Object>();
            failedCustomers.forEach(dataObj::add);
            var datePrinted = Calendar.getInstance().getTime();
            var dateStrDay = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted);
            var dateStrTime = new SimpleDateFormat("HH.mm.ss").format(datePrinted);
            var fileName = "clients_exception" + "_" + dateStrDay + "T" + dateStrTime + ".csv";
            var file = csvService.printCsv(folderCredits + fileName, dataObj, 2);
            s3Service.uploadFile("Retail/Clients/Client_Exceptions/" + fileName, file);
            FileUtils.delete(file);
            mailService.sendMail("Не прошли проверку", "Микросервис: Intgr-clients-Retail\n" +
                    "Описание ошибки: Клиенты не прошли проверку.\n" +
                    "Ссылка на файл: https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Clients/Client_Exceptions/\n" + fileName);
            failedCustomers.forEach(f -> {
                getJDBCDataService.updateCustomer(f.getCLIENT(), "Exceptions");
            });
        }

        var customersToPrint = getJDBCDataService.getCustomers();

        if (customersToPrint == null || customersToPrint.size() == 0) {
            log.error("Нет данных о клиентах");
            return;
        }

        var datePrinted = Calendar.getInstance().getTime();
        var dateStr = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted) + "T" + new SimpleDateFormat("HH.mm.ss").format(datePrinted);
        var folderName = "Retail/Clients/" + dateStr + "/";

        var dataObj = new ArrayList<Object>();
        customersToPrint.forEach(dataObj::add);
        var fileName = "customer" + "_" + dateStr + ".csv";
        var file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        if (file != null) {
            s3Service.uploadFile(folderName + fileName, file);
        }
        //    FileUtils.delete(file);
        if (deletedFile) {
            Files.deleteIfExists(file.toPath());
            log.info("Удален файл " + file);
        }


        var custdocsToPrint = getJDBCDataService.getCustdocs();
        dataObj = new ArrayList<Object>();
        custdocsToPrint.forEach(dataObj::add);
        fileName = "custdocs" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        if (file != null) {
            s3Service.uploadFile(folderName + fileName, file);
        }
        //  FileUtils.delete(file);
        if (deletedFile) {
            Files.deleteIfExists(file.toPath());
            log.info("Удален файл " + file);
        }

        var custaddrsToPrint = getJDBCDataService.getCustaddrs();
        dataObj = new ArrayList<Object>();
        custaddrsToPrint.forEach(dataObj::add);
        fileName = "custaddrs" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        if (file != null) {
            s3Service.uploadFile(folderName + fileName, file);
        }
        //   FileUtils.delete(file);
        if (deletedFile) {
            Files.deleteIfExists(file.toPath());
            log.info("Удален файл " + file);
        }


        var custcontToPrint = getJDBCDataService.getCustcont();
        dataObj = new ArrayList<Object>();
        custcontToPrint.forEach(dataObj::add);
        fileName = "custcont" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        if (file != null) {
            s3Service.uploadFile(folderName + fileName, file);
        }
        //   FileUtils.delete(file);
        if (deletedFile) {
            Files.deleteIfExists(file.toPath());
            log.info("Удален файл " + file);
        }


        /*
        var custsocToPrint = getJDBCDataService.getCustsoc();
        dataObj = new ArrayList<Object>();
        custsocToPrint.forEach(dataObj::add);
        fileName = "custsoc" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

        var custaccToPrint = getJDBCDataService.getCustacc();
        dataObj = new ArrayList<Object>();
        custaccToPrint.forEach(dataObj::add);
        fileName = "custacc" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

        var custinspectToPrint = getJDBCDataService.getCustinspect();
        dataObj = new ArrayList<Object>();
        custinspectToPrint.forEach(dataObj::add);
        fileName = "custinspect" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

        var custemprToPrint = getJDBCDataService.getCustempr();
        dataObj = new ArrayList<Object>();
        custemprToPrint.forEach(dataObj::add);
        fileName = "custempr" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

        var custreqsToPrint = getJDBCDataService.getCustreqs();
        dataObj = new ArrayList<Object>();
        custreqsToPrint.forEach(dataObj::add);
        fileName = "custreqs" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

        var custriskToPrint = getJDBCDataService.getCustrisk();
        dataObj = new ArrayList<Object>();
        custriskToPrint.forEach(dataObj::add);
        fileName = "custrisk" + "_" + dateStr + ".csv";
        file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
        s3Service.uploadFile(folderName + fileName,file);
        FileUtils.delete(file);

         */

        mailService.sendMail("Данные по клиентам обработаны", "Микросервис: Intgr-clients-Retail\n" +
                "Данные по клиентам обработаны, записаны в https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Clients/\n" + "_" + dateStr);
        customersToPrint.forEach(f -> {
            getJDBCDataService.updateCustomer(f.getCLIENT(), "Success");
        });
    }
}
