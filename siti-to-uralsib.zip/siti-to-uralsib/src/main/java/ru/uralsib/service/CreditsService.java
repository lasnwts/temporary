package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.uralsib.model.*;
import ru.uralsib.service.s3.AmazonS3Service;
import ru.uralsib.utils.DepartMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CreditsService {
    private final GetJDBCDataService getJDBCDataService;
    private final ConvertService convertService;
    private final ExcelService excelService;
    private final CheckCreditsService checkCreditsService;
    private final CsvService csvService;
    private final AmazonS3Service s3Service;
    private final MailService mailService;
    private final DepartMapper departMapper;

    @Value("${file.delete:false}")
    private boolean deletedFile; //Удалять файлы после выгрузки

    /**
     * путь конечных файлов
     */
    @Value("${app.destination.folder.credits}")
    private String folderCredits;

    public void printCredits() throws IOException, NoSuchFieldException, IllegalAccessException {

        var data = getJDBCDataService.getCredits();
        if (data == null || data.size() == 0) {
            log.error("Нет данных Credits");
            return;
        }

        log.info("Всего записей по кредитам = " + data.size());

//        var decFormat = new DecimalFormat("#,0000000.00");
//        data.forEach(d -> {
//            var PAY_SUM_CURR = Double.parseDouble(d.getPAY_SUM_CURR()) - Double.parseDouble(d.getSUM_VKP_PEN());
//            d.setPAY_SUM_CURR(decFormat.format(PAY_SUM_CURR).replace(',', '.'));
//        });

        var dataPrcScheme = new ArrayList<PrcScheme>();
        var dataPparam = new ArrayList<Pparam>();
        var dataAdds = new ArrayList<Adds>();
        var dataDogov = new ArrayList<Dogov>();
        var dataFailed = new ArrayList<FailedCredit>();

        data.forEach(credit -> {
            if (credit.getDEPART_NEW() != null && !credit.getDEPART_NEW().isEmpty())
                credit.setDEPART(credit.getDEPART_NEW());

            var departForCut = credit.getDEPART().substring(2, 5);
            credit.setDEPART_FOR_CUT(departForCut);

            var failed = checkCreditsService.checkCredit(credit);
            var finalCredit = credit;
            var creditFailed = dataFailed.stream().filter(s -> s.getS().equals(finalCredit.getNDOG_US())).collect(Collectors.toList());

            if (failed == null && creditFailed.isEmpty()) {
                var creditForPrint = filterCredit(credit, data);
                if (creditForPrint != null) {
//                    dataDogov.add(convertService.сreditToDogov(creditForPrint));
//                    dataPparam.add(convertService.сreditToPparam(creditForPrint));
//                    dataPrcScheme.add(convertService.сreditToPrcScheme(creditForPrint));
//                    dataAdds.add(convertService.сreditToAdds(creditForPrint));
                }
            } else if (creditFailed.isEmpty())
                dataFailed.add(failed);
            else {
                creditFailed.get(0).setREASON(creditFailed.get(0).getREASON() + failed.getREASON());
            }
        });

        printPrcScheme(dataPrcScheme);
        printPparam(dataPparam);
        printAdds(dataAdds);
        printDogov(dataDogov);
        printFailedCredit(dataFailed);

    }

    public void printPrcScheme(List<PrcScheme> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных PrcScheme");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных prc_scheme" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("PRC", 10);
                saveInFile(dataObj, limit, folderCredits + "prc_scheme" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей prc_scheme - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printPparam(List<Pparam> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных pparam");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных pparam" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("VIDOPER", 25);
                saveInFile(dataObj, limit, folderCredits + "pparam" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей pparam - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printAdds(List<Adds> data) throws IOException, NoSuchFieldException, IllegalAccessException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных migr_info");
            return;
        }

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных migr_info" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                saveInFile(dataObj, limit, folderCredits + "migr_info" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей migr_info - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printDogov(List<Dogov> data) throws IOException {

        if (data == null || data.stream().count() == 0) {
            log.error("Нет данных Dogov");
            return;
        }

//        var decFormat = new DecimalFormat("#,0000000.00");
//        data.forEach(d -> {
//            var sumVkp = Double.parseDouble(d.getSUM_VKP()) - Double.parseDouble(d.getSUM_VKP_DEB());
//            d.setSUM_VKP(decFormat.format(sumVkp).replace(',', '.'));
//            var sumVkpPrc = Double.parseDouble(d.getSUM_VKP_PRC()) - Double.parseDouble(d.getSUM_VKP_PRC_DEB());
//            d.setSUM_VKP_PRC(decFormat.format(sumVkpPrc).replace(',', '.'));
//        });

        var departDict = convertService.getDepartForCutDict();
        var countDataPrint = new AtomicInteger();
        departDict.values().stream().distinct().forEach(d -> {

            var departData = data.stream().filter(s -> s.getDEPART().substring(2, 5).equals(d)).collect(Collectors.toList());

            if (departData == null || departData.stream().count() == 0) {
                log.error("Нет данных Dogov" + d);
                return;
            }
            countDataPrint.set(countDataPrint.get() + departData.size());
            var dataObj = new ArrayList<Object>();
            departData.forEach(dataObj::add);

            try {
                var limit = new HashMap<String, Integer>();
                limit.put("S", 25);
                limit.put("CLIENT", 25);
                saveInFile(dataObj, limit, folderCredits + "dogov" + d + ".txt");
            } catch (IOException | NoSuchFieldException | IllegalAccessException e) {
                log.error(e.getMessage());
            }
        });
        log.info("Всего записей dogov - " + data.size() + ". Записано в файл - " + countDataPrint);
    }

    public void printFailedCredit(List<FailedCredit> data) throws IOException {
        if (data == null || data.stream().count() == 0) {
            log.info("Нет исключенных кредитов");
        } else {
            var dataObj = new ArrayList<Object>();
            data.forEach(dataObj::add);
            excelService.printExcel(folderCredits + "ExcludedCredits.xls", "ExcludedCredits", dataObj);
        }
    }

    public void saveInFile(List<Object> dataObj, Map<String, Integer> limit, String fileName) throws IOException, NoSuchFieldException, IllegalAccessException {

        var strRes = convertService.convertToString(limit, dataObj);
        var file = new File(fileName);
        FileUtils.writeStringToFile(file, strRes, "cp866");
    }

    private Credit filterCredit(Credit credit, List<Credit> dataCredit) {
        if (credit.getHOLIDAY_TYPE().equals("09")) {
            var finalCredit = credit;
            var creditsOther09 = dataCredit.stream().filter(s -> s.getS().equals(finalCredit.getS()) &&
                    !s.getHOLIDAY_TYPE().equals("09")).collect(Collectors.toList());
            if (creditsOther09.isEmpty()) {
                credit.setHOLIDAY_TYPE("");
                credit.setHOLIDAY_DATE_APPL("");
                credit.setHOLIDAY_DATE_PROV("");
                credit.setHOLIDAY_DATE_BEGIN("");
                credit.setHOLIDAY_DATE_END_PLAN("");
                credit.setHOLIDAY_DATE_END_FACT("");
                credit.setHOLIDAY_END_REASON("");
                credit.setHOLIDAY_DATE_TERM_APPL("");
                credit.setAFTER_HOLIDAY_DATE_FIRST_PAY_FACT("");
                credit.setHOLIDAY_DATE_FIRST_REAB_PAY("");
                credit.setHOLIDAY_DATE_LAST_REAB_PAY("");
                credit.setHOLIDAY_PRC_RATE("");
                credit.setHOLIDAY_PRC_SUM_TOT("");
                credit.setHOLIDAY_STATUS("");
                credit.setAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN("");
                credit.setDATE_END_BEFORE("");
                credit.setDATE_END_ACTUAL("");
                credit.setHOLIDAY_PRC_SUM_REM("");
            } else return null;
        }
        return credit;
    }

    /**
     * Обработка данных по кредитам
     *
     * @throws IOException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    public void processingCredits() throws IOException, NoSuchFieldException, IllegalAccessException {

        var failedCredits = checkCreditsService.checkCredits();

        folderCredits = this.getClass().getResource("/").getFile();

        if (failedCredits == null || failedCredits.size() == 0) {
            log.error("Нет данных об исключенных кредитах");
        } else {
            var dataObj = new ArrayList<Object>();
            failedCredits.forEach(dataObj::add);
            var datePrinted = Calendar.getInstance().getTime();
            var dateStrDay = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted);
            var dateStrTime = new SimpleDateFormat("HH.mm.ss").format(datePrinted);
            var fileName = "credit_exception" + "_" + dateStrDay + "T" + dateStrTime + ".csv";
            var file = csvService.printCsv(folderCredits + fileName, dataObj, 1);
            s3Service.uploadFile("Retail/Credits/Credit_Exceptions/" + fileName, file);
            FileUtils.delete(file);
            mailService.sendMail("Не прошли проверку", "Микросервис: Intgr-credit-Retail\n" +
                    "Описание ошибки: Кредиты не прошли проверку.\n" +
                    "Ссылка на файл: https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/Credit_Exceptions/\n" + fileName);
            failedCredits.forEach(f -> {
                getJDBCDataService.updateFailedCredit(f);
            });
        }

        var dogovToPrint = getJDBCDataService.getDogov();

//        dogovToPrint.forEach(new Consumer<Dogov>() {
//            @Override
//            public void accept(Dogov dogov) {
//                log.info("dogov.getS() - " + dogov.getS());
//                log.info("dogov.getDEPART() - " + dogov.getDEPART());
//                log.info("dogov.getDEPART_TBANK() - " + dogov.getDEPART_TBANK());
//            }
//        });

        if (dogovToPrint == null || dogovToPrint.size() == 0) {
            log.error("Нет данных о кредитах");
            return;
        }

        var datePrinted = Calendar.getInstance().getTime();
        var dateStr = new SimpleDateFormat("dd.MM.yyyy").format(datePrinted) + "T" + new SimpleDateFormat("HH.mm.ss").format(datePrinted);
        var folderNameSt = "Retail/Credits/" + dateStr + "/";

        var departDict = convertService.getDepartForCutDict();

        var factToPrint = getJDBCDataService.getFact();
        var planallToPrint = getJDBCDataService.getPlanall();
        var pparamToPrint = getJDBCDataService.getPparam();
        var prc_schemeToPrint = getJDBCDataService.getPrcScheme();
        var accbalanceToPrint = getJDBCDataService.getAccbalance();
        var migr_infoToPrint = getJDBCDataService.getAdds();
        var unloadBkiPrint = getJDBCDataService.getUnloadBki(); //Новый файл

        departDict.values().stream().distinct().forEach(d -> {
            try {

                var dogovDepartData = dogovToPrint.stream().filter(s -> s.getDEPART().equals(d)).collect(Collectors.toList());
                if (dogovDepartData == null || dogovDepartData.size() == 0) {
                    log.error("Нет данных о кредитах " + d);
                    return;
                }
                var folderName = folderNameSt + d + "/";

                var dataObj = new ArrayList<Object>();
                var dataObjd = new ArrayList<Object>();
                dogovDepartData.forEach(dataObj::add);
                //Меняем DEPART на DEPART_TBANK
                dataObj.forEach(new Consumer<Object>() {
                    @Override
                    public void accept(Object o) {
                        try {
                            var dogov = (Dogov) o;
                            dataObjd.add(departMapper.getDepartChange((Dogov) o));
                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                    }
                });
                

                var fileName = "dogov" + d + "_" + dateStr + ".csv";
                var file = csvService.printCsv(folderCredits + fileName, dataObjd, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }
               // FileUtils.delete(file);

                var factDepartData = factToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                factDepartData.forEach(dataObj::add);
                fileName = "fact" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
              //  FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }


                var planallDepartData = planallToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                planallDepartData.forEach(dataObj::add);
                fileName = "planall" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
              //  FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }


                var pparamDepartData = pparamToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                pparamDepartData.forEach(dataObj::add);
                fileName = "pparam" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
             //   FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }


                var prc_schemeDepartData = prc_schemeToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                prc_schemeDepartData.forEach(dataObj::add);
                fileName = "prc_scheme" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
//                FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }


                var accbalanceDepartData = accbalanceToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                accbalanceDepartData.forEach(dataObj::add);
                fileName = "accbalance" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
             //   FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }


                var migr_infoDepartData = migr_infoToPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                migr_infoDepartData.forEach(dataObj::add);
                fileName = "migr_info" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObj, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
             //   FileUtils.delete(file);
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }

                //Подготовка файла BKI
                //unload_BKI001_23.10.2024T09.20.30.csv
                var unloadBkiDepartData = unloadBkiPrint.stream().filter(s -> s.getDEPART_FOR_CUT().equals(d)).collect(Collectors.toList());
                dataObj = new ArrayList<Object>();
                unloadBkiDepartData.forEach(dataObj::add);
                fileName = "unload_BKI" + d + "_" + dateStr + ".csv";
                file = csvService.printCsv(folderCredits + fileName, dataObjd, 0);
                if (file != null){
                    s3Service.uploadFile(folderName + fileName, file);
                }
                if (deletedFile){
                    Files.deleteIfExists(file.toPath());
                    log.info("Удален файл " + file);
                }

            } catch (IOException e) {
                log.error("В процессе возникла ошибка: {}", e.getMessage());
                throw new RuntimeException(e);
            }
        });

        mailService.sendMail("Данные по кредитам обработаны", "Микросервис: Intgr-Credits-Retail\n" +
                "Данные по кредитам обработаны, записаны в https://msk-s3-test.fc.uralsibbank.ru/tbankfiles-test/Retail/Credits/\n" + "_" + dateStr);
        dogovToPrint.forEach(f -> {
            getJDBCDataService.updateCredits(f.getS(), "Success");
        });
    }
}
