package ru.uralsib.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.uralsib.dto.CommonMailDto;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class MailService {

    private final RestTemplate restTemplate;
    @Value("${app.mail}")
    private String url;

    public void printCsv(String fileName, List<Object> data) {

        try {

        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    public String escapeSpecialCharacters(String data) {
        var escapedData = data.replaceAll("\\R", " ");
        if (data.contains(",") || data.contains("\"") || data.contains("'")) {
            data = data.replace("\"", "\"\"");
            escapedData = "\"" + data + "\"";
        }
        return escapedData;
    }

    public void sendMail(String title, String body) {
        var dto = new CommonMailDto();
        dto.setBody(body);
        dto.setEmails(new String[]{"LyapustinAS@spb.uralsib.ru", "BeloborodoEV@ufa.uralsib.ru"});
        dto.setTitle(title);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        var request = new HttpEntity<>(dto, headers);
//        var response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
//        log.info("получен ответ от mail {}", response.getStatusCodeValue());
        log.info("получен ответ от mail {}", "Заглушка");
    }

}
