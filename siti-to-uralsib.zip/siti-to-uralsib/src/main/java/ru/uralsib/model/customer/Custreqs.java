package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custreqs implements Serializable {

   public String REQS_CUSTNUMB;
   public String DATE_CHNG_NAME;
   public String CHILDREN_COUNT;
   public String DEPENDANTS_COUNT;
   public String FAMILY_MEMBERS;
   public String PREV_LAST_NAME;
   public String REASON_CHNG_NAME;
   public String OCCUPATION_STATE;

}