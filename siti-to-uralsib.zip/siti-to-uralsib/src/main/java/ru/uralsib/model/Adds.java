package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Adds implements Serializable {

   public String S;
   public String DATE_BEG_ORIG;
   public String DATE_END_ORIG;
   public String DATE_END;
   public String TOTAL_DAYS_OVERDUE;
   public String SUM_OVERDUE;
   public String NUM_PMTS_MADE;
   public String NUM_PMTS_REM;
   public String ORIG_TERM;
   public String CURR_TERM;
   public String PRC_RATE_ORIG;
   public String PAY_DAY_ORIG;
   public String PRC_RATE_CURR;
   public String PAY_DAY_CURR;
   public String PAY_SUM_CURR;
   public String DATE_FIRST_PAY;
   public String DATE_LASTPAY_COMMIT;
   public String SUM_LASTPAY_COMMIT;
   public String DATE_NEXT_PAYMENT;
   public String SUM_NEXT_PAYMENT;
   public String REFINANCE;

   public String DEPART_FOR_CUT;

}