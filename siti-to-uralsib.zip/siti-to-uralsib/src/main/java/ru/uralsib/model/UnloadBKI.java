package ru.uralsib.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnloadBKI {
    //S; 1
    // TB_RELATIONSHIP;2
    // TB_TYPE;3
    // TB_LOANTYPECODE;4
    // TB_STARTAMOUOUTST;5
    // TB_CUROVERDUEDT_TA; 6
    // TB_MSPYMNTNXTRDT; 7
    // TB_MSPYMNTNTRSTDT; 8
    // TB_PASTDUEDAYS; 9
    // TB_PAIDPASTDUEDAYS; 10
    // TB_LASTAMOUNT_30PD; 11
    // TB_TTLAMOUNT24M30PD; 12
    // TB_DEBTRANGE; 13
    // TB_DEBTCALCDATE; 14
    // TB_INCOMEWAYTYPE; 15
    // TB_INCOMEINFOSOURCE;16
    // TB_COBORROWERSDEBT; 17
    // TB_STATESUPPORT; 18
    // TB_STATESUPPORTINFO; 19
    // TB_LOANPURPOSECODE; 20
    // TB_DATECONTRTERM 21


    public String S; //1
    public String TB_RELATIONSHIP; //2
    public String TB_TYPE; //3
    public String TB_LOANTYPECODE; //4
    public String TB_STARTAMOUOUTST; //5
    public String TB_CUROVERDUEDT_TA; //6
    public String TB_MSPYMNTNXTRDT; //7
    public String TB_MSPYMNTNTRSTDT; //8
    public String TB_PASTDUEDAYS; //9
    public String TB_PAIDPASTDUEDAYS; //10
    public String TB_LASTAMOUNT_30PD; //11
    public String TB_TTLAMOUNT24M30PD; //12
    public String TB_DEBTRANGE; //13
    public String TB_DEBTCALCDATE; //14
    public String TB_INCOMEWAYTYPE; //15
    public String TB_INCOMEINFOSOURCE; //16
    public String TB_COBORROWERSDEBT; //17
    public String TB_STATESUPPORT; //18
    public String TB_STATESUPPORTINFO; //19
    public String TB_LOANPURPOSECODE; //20
    public String TB_DATECONTRTERM; //21
    public String DEPART_FOR_CUT; //22

}
