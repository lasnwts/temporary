package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Accbalance implements Serializable {

   public String S;
   public String ACC;
   public String SUM;
   public String DEPART_FOR_CUT;

}