package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Сustdocs implements Serializable {

   public String CLIENT;
   public String DOC_DATE;
   public String DOC_DATE_END;
   public String DOC_MAIN;
   public String DOC_SER;
   public String DOC_NUM;
   public String DOC_PLACE;
   public String DOC_TYPE;
   public String DOC_WHO;
   public String DOC_DEPART_CODE;

}