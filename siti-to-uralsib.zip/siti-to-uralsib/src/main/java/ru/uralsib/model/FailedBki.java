package ru.uralsib.model;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FailedBki {
    public String S;
    public String REASON;
    public String count;
}
