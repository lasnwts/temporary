package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class FailedCredit implements Serializable {

   public String S;
   public String REASON;
   public String TOTAL_DAYS_OVERDUE;
   public String DATE_END_ORIG;

}