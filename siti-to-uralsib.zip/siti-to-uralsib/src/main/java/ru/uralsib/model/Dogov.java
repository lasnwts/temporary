package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Dogov implements Serializable {

   public String S;
   public String CLIENT;
   public String SYMBOL;
   public String NDOG_US;
   public String DEPART;
   public String DATE_BEG;
   public String DATE_END;
   public String SUM;
   public String SUM_VKP;
   public String SUM_VKP_PRC;
   public String SUM_VKP_DEB;
   public String SUM_VKP_PRC_DEB;
   public String SUM_VKP_PEN;
   public String DATE_BKI;
   public String DATE_OFFER;
   public String PSK_PRC_BEG;
   public String PSK_BEG;
   public String PSK_PRC;
   public String PSK;
   public String UID;
   public String DEPART_TBANK;

}