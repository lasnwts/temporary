package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custsoc implements Serializable {
   public String SOC_CUSR_NMBR;
   public String SOC_DATE_REG;
   public String SOC_FOUND_CODE;
   public String SOC_FOUND;
   public String SOC_FOUND_NUM;
}