package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Credit implements Serializable {

   public String S;
   public String CLIENT;
   public String SYMBOL;
   public String NDOG_US;
   public String DEPART;
   public String DATE_BEG;
   public String DATE_END;
   public String SUM;
   public String SUM_VKP;
   public String SUM_VKP_PRC;
   public String SUM_VKP_DEB;
   public String SUM_VKP_PRC_DEB;
   public String SUM_VKP_PEN;
   public String DATE_BKI;
   public String DATE_OFFER;
   public String PSK_PRC;
   public String PSK;
   public String UID;

   public String VIDOPER;
   public String DAYPAY;
   public String DAYCALC;
   public String SUMPAY;
   public String DATE_CALC;
   public String DATE_PAY;
   public String DATE_END_PPARAM;
   public String OPER_COUNT;
   public String ONLY_PRC;
   public String GASH_PAY_PERIOD;

   public String P_CODE;
   public String PRC;
   public String DATE_BEG_PRC_SCHEME;
   public String DATE_END_PRC_SCHEME;

   public String DATE_BEG_ORIG;
   public String DATE_END_ORIG;
   public String DATE_END_ADDS;
   public String TOTAL_DAYS_OVERDUE;
   public String SUM_OVERDUE;
   public String NUM_PMTS_MADE;
   public String NUM_PMTS_REM;
   public String ORIG_TERM;
   public String CURR_TERM;
   public String PRC_RATE_ORIG;
   public String PAY_DAY_ORIG;
   public String PRC_RATE_CURR;
   public String PAY_DAY_CURR;
   public String PAY_SUM_CURR;
   public String DATE_FIRST_PAY;
   public String DATE_LASTPAY_COMMIT;
   public String SUM_LASTPAY_COMMIT;
   public String DATE_NEXT_PAYMENT;
   public String SUM_NEXT_PAYMENT;
   public String HOLIDAY_TYPE;
   public String HOLIDAY_DATE_APPL;
   public String HOLIDAY_DATE_PROV;
   public String HOLIDAY_DATE_BEGIN;
   public String HOLIDAY_DATE_END_PLAN;
   public String HOLIDAY_DATE_END_FACT;
   public String HOLIDAY_END_REASON;
   public String HOLIDAY_DATE_TERM_APPL;
   public String AFTER_HOLIDAY_DATE_FIRST_PAY_FACT;
   public String HOLIDAY_DATE_FIRST_REAB_PAY;
   public String HOLIDAY_DATE_LAST_REAB_PAY;
   public String HOLIDAY_PRC_RATE;
   public String HOLIDAY_PRC_SUM_TOT;
   public String HOLIDAY_STATUS;
   public String AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN;
   public String DATE_END_BEFORE;
   public String DATE_END_ACTUAL;
   public String HOLIDAY_PRC_SUM_REM;

   public String DEPART_NEW;

   public String DEPART_FOR_CUT;
}