package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class FailedCustomer implements Serializable {

   public String CLIENT;
   public String REASON;

}