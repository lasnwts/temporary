package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custcont implements Serializable {

   public String CLIENT;
   public String CONTACTS_ACTIV;
   public String CONTACTS_NUMB;
   public String CONTACTS_PRIVATE;
   public String CONTACTS_TYPE;

}