package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Fact implements Serializable {

   public String S;
   public String DATE;
   public String OPER;
   public String SUM;
   public String VALUTA;
   public String DEPART_FOR_CUT;

}