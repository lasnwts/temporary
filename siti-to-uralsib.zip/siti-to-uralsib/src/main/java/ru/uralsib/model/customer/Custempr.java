package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Custempr implements Serializable {

   public String JOB_CLIENT;
   public String JOB_MAIN_JOB;
   public String JOB_WORK_PLACE_OKVED;
   public String JOB_WORK_START_DATE;
   public String JOB_KIND_DOC_CODE;
   public String JOB_WORK_POSITION;
   public String JOB_WORK_PLACE_INN;
   public String JOB_WORK_PLACE_NAME;
   public String JOB_SERVICE_LENGTH;
   public String JOB_TEL_ORG;

}