package ru.uralsib.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Customer implements Serializable {

   public String CLIENT;
   public String NAME;
   public String DATE_PERS;
   public String BORN_PLACE;
   public String REG_STATUS;
   public String AGREE_ADVERT;
   public String AGREE_SELL;
   public String RESIDENT;
   public String COUNTRY_CODE;
   public String INN;
   public String SEX_CODE;
   public String MARIGE_STATUS_CODE;
   public String DECL_NAME;
   public String DECL_CASE_GR_CODE;
   public String LEV_EDUC_CODE;
   public String WEL;

}