package ru.uralsib.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class Planall implements Serializable {

   public String S;
   public String DATE;
   public String DATE_BEG;
   public String DATE_END;
   public String OPER;
   public String SUM;
   public String CHANGE;
   public String VALUTA;
   public String DEPART_FOR_CUT;

}