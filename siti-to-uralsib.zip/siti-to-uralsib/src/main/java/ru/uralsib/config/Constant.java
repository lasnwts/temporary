package ru.uralsib.config;

/**
 * @author Petr Vershinin 5
 * create on 15.11.2022
 */
public class Constant {
    private Constant() {
    }

    public static final int CLIENT_MAX_SIZE = 25;
    public static final String CLIENT ="<CLIENT";

    public static final int DATE_ANK_MAX_SIZE = 0;
    public static final String DATE_ANK ="<DATE_ANK";

    public static final int NAME_MAX_SIZE = 128;
    public static final String NAME ="<NAME";

    public static final int DATE_PERS_MAX_SIZE = 10;
    public static final String DATE_PERS ="<DATE_PERS";

    public static final int BORN_PLACE_MAX_SIZE = 255;
    public static final String BORN_PLACE ="<BORN_PLACE";

    public static final int DOC_MAX_SIZE = 32000;
    public static final String DOC ="<DOC";

    public static final int CONTACTS_MAX_SIZE = 32000;
    public static final String CONTACTS ="<CONTACTS";

    public static final int REG_STATUS_MAX_SIZE = 20;
    public static final String REG_STATUS ="<REG_STATUS";

    public static final int ADDRESSES_MAX_SIZE = 32000;//array
    public static final String ADDRESSES ="<ADDRESSES";

    public static final int SELF_INTRST_MAX_SIZE = 1;//empty
    public static final String SELF_INTRST ="<SELF_INTRST";

    public static final int AGREE_ADVERT_MAX_SIZE = 1;//boolean
    public static final String AGREE_ADVERT ="<AGREE_ADVERT";

    public static final int RESIDENT_MAX_SIZE = 1;//boolean
    public static final String RESIDENT ="<RESIDENT";

    public static final int COUNTRY_CODE_MAX_SIZE = 13;
    public static final String COUNTRY_CODE ="<COUNTRY_CODE";

    public static final int INN_MAX_SIZE = 12;
    public static final String INN ="<INN";

    public static final int FONDS_AR_MAX_SIZE = 0;
    public static final String FONDS_AR ="<FONDS_AR";

    public static final int SEX_CODE_MAX_SIZE = 12;
    public static final String SEX_CODE ="<SEX_CODE";

    public static final int I_NAME_MAX_SIZE = 0;
    public static final String I_NAME ="<I_NAME";

    public static final int LAW_MAX_SIZE = 0;
    public static final String LAW ="<LAW";

    public static final int BUSINESS_MAX_SIZE = 0;
    public static final String BUSINESS ="<BUSINESS";

    public static final int ANK_NOTES_MAX_SIZE = 0;
    public static final String ANK_NOTES ="<ANK_NOTES";

    public static final int INF_OTKAZ_MAX_SIZE = 0;
    public static final String INF_OTKAZ ="<INF_OTKAZ";

    public static final int NOTES_MAX_SIZE = 0;
    public static final String NOTES ="<NOTES";

    public static final int MARIGE_STATUS_CODE_MAX_SIZE = 16;
    public static final String MARIGE_STATUS_CODE ="<MARIGE_STATUS_CODE";

    public static final int VID_CL_CODE_MAX_SIZE = 0;
    public static final String VID_CL_CODE ="<VID_CL_CODE";

    public static final int INSPECT_MAX_SIZE = 0;
    public static final String INSPECT ="<INSPECT";

    public static final int ACC_BANK_MAX_SIZE = 0;
    public static final String ACC_BANK ="<ACC_BANK";

    public static final int DECL_FIO_MAX_SIZE = 0;
    public static final String DECL_FIO ="<DECL_FIO";

    public static final int FAIL_LEVEL_CODE_MAX_SIZE = 0;
    public static final String FAIL_LEVEL_CODE ="<FAIL_LEVEL_CODE";

    public static final int LEV_EDUC_CODE_MAX_SIZE = 0;
    public static final String LEV_EDUC_CODE ="<LEV_EDUC_CODE";

    public static final int VISA_INFO_MAX_SIZE = 0;
    public static final String VISA_INFO ="<VISA_INFO";

    public static final int IS_UNIFORM_CRED_MAX_SIZE = 0;
    public static final String IS_UNIFORM_CRED ="<IS_UNIFORM_CRED";

    public static final int GR_RISK_HIST_MAX_SIZE = 0;
    public static final String GR_RISK_HIST ="<GR_RISK_HIST";

    public static final int WEL_MAX_SIZE = 0;
    public static final String WEL ="<WEL";

    public static final int MAIN_JOB_MAX_SIZE = 32000;
    public static final String MAIN_JOB ="<MAIN_JOB";

    public static final int EXTRA_JOB_MAX_SIZE = 0;
    public static final String EXTRA_JOB ="<EXTRA_JOB";

    public static final int EXTRA_REQS_MAX_SIZE = 0;
    public static final String EXTRA_REQS ="<EXTRA_REQS";

    public static final int MIGR_CARD_MAX_SIZE = 0;
    public static final String MIGR_CARD ="<MIGR_CARD";


}
