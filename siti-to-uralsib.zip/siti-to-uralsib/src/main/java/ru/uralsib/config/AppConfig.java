package ru.uralsib.config;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

@Configuration
public class AppConfig {

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public RestTemplate restTemplate() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
//создаем sslContext со стратегией которая доверят только доверенным центрам сертификации, для использования самоподписных сертификатов TrustSelfSignedStrategy()
        SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustAllStrategy()).build();
        //создаем фабрику для управления соединений подписанных CA используем DefaultHostnameVerifier, для пропуска проверки использовать NoopHostnameVerifier.INSTANCE
        //DefaultHostnameVerifier - реализация HostnameVerifaerб, которая проверяет, что имя хоста в SSl-сертификате соответствует действительному имени хоста сервера
        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, new DefaultHostnameVerifier());
        //регистрируем фабрики сокетов для https
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create().register("https", socketFactory).build();
        //менеджер соединений который управляет пулом, передаем ему socketFactoryRegistry чтоб он знал как управлять https
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        //кол-во максимальных одновременных соединений
        connectionManager.setMaxTotal(50);
        //максимальное кол-во соединений на каждый хост
        connectionManager.setDefaultMaxPerRoute(20);

        HttpClientBuilder builder= HttpClients.custom();
        builder.setConnectionManager(connectionManager);
        CloseableHttpClient httpClient = builder.build();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
        factory.setConnectTimeout(300000);
        factory.setReadTimeout(300000);

        return new RestTemplate(factory);
    }

}
