package ru.uralsib.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.uralsib.service.CreateFileService;
import ru.uralsib.service.CreditsService;
import ru.uralsib.service.CustomersService;
import ru.uralsib.service.GetJDBCDataService;

import java.io.IOException;

/**
 * @author Petr Vershinin
 * create on 15.11.2022
 */
@RestController
@RequiredArgsConstructor
public class ConvertController {
    private final GetJDBCDataService getJDBCDataService;
    private final CreateFileService createFileService;
    private final CreditsService creditsService;
    private final CustomersService customersService;

//    @GetMapping("/getClient")
//    public String getInfo() throws IOException {
//        var clients=getJDBCDataService.getClients();
//        var maxLengthFields = getJDBCDataService.getData(clients);
//
//        return createFileService.write(maxLengthFields,clients);
//    }
//
//    @GetMapping("/getCreditsCity")
//    public boolean getCreditsCity() throws IOException, NoSuchFieldException, IllegalAccessException {
//
//        creditsService.printCredits();
//        return true;
//    }

    @GetMapping("/processingCredits")
    public boolean processingCredits() throws IOException, NoSuchFieldException, IllegalAccessException {

        creditsService.processingCredits();
        return true;
    }

    @GetMapping("/processingCustomers")
    public boolean processingCustomers() throws IOException, NoSuchFieldException, IllegalAccessException {

        customersService.processingCustomers();
        return true;
    }
}
