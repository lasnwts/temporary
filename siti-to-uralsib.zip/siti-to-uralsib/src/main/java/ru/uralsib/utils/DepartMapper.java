package ru.uralsib.utils;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import ru.uralsib.model.Dogov;
import ru.uralsib.model.DogovDepartTbank;

@Log4j2
@Component
public class DepartMapper {

    /**
     *    public String S;
     *    public String CLIENT;
     *    public String SYMBOL;
     *    public String NDOG_US;
     *    public String DEPART;
     *    public String DATE_BEG;
     *    public String DATE_END;
     *    public String SUM;
     *    public String SUM_VKP;
     *    public String SUM_VKP_PRC;
     *    public String SUM_VKP_DEB;
     *    public String SUM_VKP_PRC_DEB;
     *    public String SUM_VKP_PEN;
     *    public String DATE_BKI;
     *    public String DATE_OFFER;
     *    public String PSK_PRC_BEG;
     *    public String PSK_BEG;
     *    public String PSK_PRC;
     *    public String PSK;
     *    public String UID;
     * @param dogov - сущность договора
     * @return -  сущность договора для изменения департамента
     */
    public DogovDepartTbank getDepartChange(Dogov dogov){
        DogovDepartTbank dogovDepartTbank = new DogovDepartTbank();
        dogovDepartTbank.setS(dogov.getS());
        dogovDepartTbank.setCLIENT(dogov.getCLIENT());
        dogovDepartTbank.setNDOG_US(dogov.getNDOG_US());
        dogovDepartTbank.setDEPART(dogov.getDEPART_TBANK());
        dogovDepartTbank.setDATE_BEG(dogov.getDATE_BEG());
        dogovDepartTbank.setDATE_END(dogov.getDATE_END());
        dogovDepartTbank.setSUM(dogov.getSUM());
        dogovDepartTbank.setSUM_VKP(dogov.getSUM_VKP());
        dogovDepartTbank.setSUM_VKP_PRC(dogov.getSUM_VKP_PRC());
        dogovDepartTbank.setSUM_VKP_DEB(dogov.getSUM_VKP_DEB());
        dogovDepartTbank.setSUM_VKP_PRC_DEB(dogov.getSUM_VKP_PRC_DEB());
        dogovDepartTbank.setSUM_VKP_PEN(dogov.getSUM_VKP_PEN());
        dogovDepartTbank.setDATE_BKI(dogov.getDATE_BKI());
        dogovDepartTbank.setDATE_OFFER(dogov.getDATE_OFFER());
        dogovDepartTbank.setPSK_PRC_BEG(dogov.getPSK_PRC_BEG());
        dogovDepartTbank.setPSK_BEG(dogov.getPSK_BEG());
        dogovDepartTbank.setPSK_PRC(dogov.getPSK_PRC());
        dogovDepartTbank.setPSK(dogov.getPSK());
        dogovDepartTbank.setUID(dogov.getUID());
        return dogovDepartTbank;
    }

}
