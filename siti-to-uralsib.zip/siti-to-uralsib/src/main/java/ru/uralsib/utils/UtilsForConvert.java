package ru.uralsib.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * @author Petr Vershinin
 * create on 15.11.2022
 */
@Slf4j
public class UtilsForConvert {
    private UtilsForConvert() {
    }

    /**
     * Метод формирует заголовок для поля
     *
     * @param lClientMax - длина самого большого значения поля из БД
     * @param maxSize    - максимальное значение поля/Константа
     * @param header     - название поля/Константа
     * @return - готовый заголовок для 1 - поля
     */
    public static String getHeader(int lClientMax, int maxSize, String header) {
        StringBuilder sb = new StringBuilder();
        //Если содержимое пустое возвращаем просто тег
        if (lClientMax > 0) {
            //находим что больше константа или lClientMax для поля client
            if (maxSize < lClientMax) {
                sb.append(StringUtils.rightPad(header, maxSize)).append(">");
            } else {
                sb.append(StringUtils.rightPad(header, lClientMax)).append(">");
            }
        } else {
            sb.append(header).append(">");
        }
        return sb.toString();
    }


    public static Date getDate(String bDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = simpleDateFormat.parse(bDate);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }
    public static String getDate(ResultSet rs) throws SQLException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        var date = rs.getDate("CMEMPLSTARTDT");
        String rtdt = null;
        if (date != null) {
            rtdt = sdf.format(date);
        }
        return rtdt;
    }
    public static String getResCode(String typeCode) {
        String resCode = null;
        if ("020".equals(typeCode)) {
            resCode = "REGISTRATION;";
        } else if ("002".equals(typeCode)) {
            resCode = "FACT;";
        }
        return resCode;
    }

    public static String getStat(ResultSet rs, String sex) throws SQLException {
        var stat = rs.getString("CM_CUST_MSSTAT");
        String rStat = null;
        if (Objects.equals(sex, "Ж")) {
            switch (stat) {
                case "S":
                    rStat = "НЕ ЗАМУЖ";
                    break;
                case "M":
                    rStat = "ЗАМУЖ";
                    break;
                case "D":
                    rStat = "DIVOR";
                    break;
                case "W":
                    rStat = "WIDOW";
                    break;
                default:
                    break;
            }
        } else {
            switch (stat) {
                case "S":
                    rStat = "UNMAR";
                    break;
                case "M":
                    rStat = "MAR";
                    break;
                case "D":
                    rStat = "DIVOR";
                    break;
                case "W":
                    rStat = "WIDOW";
                    break;
                default:
                    break;
            }
        }
        return rStat == null ? "" : rStat;
    }
    public static String getSex(ResultSet rs) throws SQLException {
        var sex = rs.getString("CM_CUST_SEX");
        String rSex = null;
        switch (sex) {
            case "F":
                rSex = "Ж";
                break;
            case "M":
                rSex = "М";
                break;
            default:
                break;
        }
        return rSex;
    }

    public static String getHouse( String line2, String line7) {
        String house = null;
        if (line7 != null) {
            house = line7;
        } else if (line2 != null) {
            house = line2;
        }
        return house;
    }

    public static String getIdSd(String idSd) {
        String resulIdSd;
        if (idSd != null) {
            resulIdSd = Objects.equals(idSd, "P") ? "1;" : ";";
        } else {
            resulIdSd = ";";
        }
        return resulIdSd;
    }

    public static String getrType(String type) {
        String rType = null;
        if ("006".equals(type)) {
            rType = "1;";
        } else if ("001".equals(type)) {
            rType = "3;";
        }
        return rType;
    }

    public static String getTryDesc(ResultSet rs) throws SQLException {
        String desc = null;
        var tryDesc = rs.getString("DWHADDRCTRYDESC");
        if(tryDesc.equalsIgnoreCase("RUSSIA")){
            desc="РОССИЯ";
        }
        return desc;
    }
}
