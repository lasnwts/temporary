package ru.uralsib.dto;

import lombok.Data;

/**
 * @author Petr Vershinin
 * create on 26.02.2023
 */
@Data
public class CommonMailDto {
    private String title;
    private String [] emails;
    private String body;
}
