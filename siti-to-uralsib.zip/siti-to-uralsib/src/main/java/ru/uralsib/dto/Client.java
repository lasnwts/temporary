package ru.uralsib.dto;

import lombok.Data;

/**
 * @author Petr Vershinin
 * create on 17.11.2022
 */
@Data
public class Client {
   private String client;
   private String dateAnk;
   private String name;
   private String datePers;
   private String bornPlace;
   private String doc;
   private String contacts;
   private String regStatus;
   private String addresses;
   private String selfIntrst;
   private String agreeAdvert;
   private String resident;
   private String countryCode;
   private String inn;
   private String foundAR;
   private String sexCode;
   private String iName;
   private String law;
   private String business;
   private String ankNotes;
   private String infOtkaz;
   private String notes;
   private String marigeStatusCode;
   private String vidClCode;
   private String inspect;
   private String accBank;
   private String declFio;
   private String failLevelCode;
   private String levEducCode;
   private String visaInfo;
   private String isUniformCred;
   private String grRiskHist;
   private String wel;
   private String mainJob;
   private String extraJob;
   private String extraReqs;
   private String migrCard;

}
