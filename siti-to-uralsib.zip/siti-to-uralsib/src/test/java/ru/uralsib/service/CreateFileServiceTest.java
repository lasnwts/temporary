package ru.uralsib.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.uralsib.dto.Client;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Petr Vershinin
 * create on 11.11.2022
 */
class CreateFileServiceTest {



}