package ru.uralsib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiToUralsibApplicationTests {

    @Test
    void contextLoads() {
    }

}
