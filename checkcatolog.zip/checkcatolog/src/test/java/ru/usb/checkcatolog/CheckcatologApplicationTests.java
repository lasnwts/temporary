package ru.usb.checkcatolog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckcatologApplicationTests {

	@Test
	void contextLoads() {
	}

}
