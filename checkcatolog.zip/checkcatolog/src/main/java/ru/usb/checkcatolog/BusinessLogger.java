package ru.usb.checkcatolog;

import org.slf4j.Logger;

public class BusinessLogger {
    private final Logger logger; // initialize in constructor, can even add a getter if needed

    public BusinessLogger(Logger logger) {
        this.logger = logger;
    }

    public void info(String msg) {
        logger.info("[BUSINESS] " + msg);
    }
}