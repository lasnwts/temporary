package ru.usb.checkcatolog;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {


    /**
     * Переменные для сохранение исходящимх файлов в ЦБ и входящих файлов
     * Сохранение направленных файлов и подписей в папку: \\fc\Uralsib\MSK\COMMON\VOL4\Obmen_BR_KYC\Отправленные в БР
     * Полученные от ЦБ файлы из ЛК без расшифровки должны сохраняться в папку: \\fc\Uralsib\MSK\COMMON\VOL4\Obmen_BR_KYC\Входящие от БР     *
     */

    //Наименование Хоста с которого будет идети работа по СКЗИ
    private String cryptoHost;

    //Полученные от ЦБ файлы из ЛК без расшифровки должны сохраняться в папку
    private String inputFromCB953905;

    //Сохранение направленных файлов и подписей в папку
    private String outputFileToCB953905;

    /**
     * Расшифрованные файлы из ЦБ
     */
    private String decryptoFromCBb;

    /**
     * Файлы с ошибкой  шифрования
     */
    private String cryptoError;

    /**
     * Зашифрованные файлы из ЦБ
     */
    private String cryptoFromCB;

    /**
     * папка с файлами для зашифровки и создания подписи для отправки в ЦБ
     */
    private String kycIn;

    /**
     *  В случае когда возвращается значение new - грузим только новые сообщения
     *  В случае all - загружаем все сообщения типа Zadach130
     */

    /**
     * папка с файлами логов
     */
    private String kycLogs;

    /**
     * папка с зашифрованными и подписанными файлами для отправки в ЦБ
     */
    private String kycOut;


    /**
     * Host 1 переменные
     */

    //Имя хоста с СКЗИ хост1
    @Value("${kyc.host1}")
    private String cryptoHost1;

    //Полученные от ЦБ файлы из ЛК без расшифровки должны сохраняться в папку
    @Value("${kyc.in953905fromcb1}")
    private String inputFromCB9539051;

    //Сохранение направленных файлов и подписей в папку
    @Value("${kyc.out953905tocb1}")
    private String outputFileToCB9539051;

    /**
     * Расшифрованные файлы из ЦБ
     */
    @Value("${kyc.forursb1}")
    private String decryptoFromCBb1;

    /**
     * Файлы с ошибкой  шифрования
     */
    @Value("${kyc.error1}")
    private String cryptoError1;

    /**
     * Зашифрованные файлы из ЦБ
     */
    @Value("${kyc.frombr1}")
    private String cryptoFromCB1;

    /**
     * папка с файлами для зашифровки и создания подписи для отправки в ЦБ
     */
    @Value("${kyc.in1}")
    private String kycIn1;

    /**
     *  В случае когда возвращается значение new - грузим только новые сообщения
     *  В случае all - загружаем все сообщения типа Zadach130
     */

    /**
     * папка с файлами логов
     */
    @Value("${kyc.logs1}")
    private String kycLogs1;

    /**
     * папка с зашифрованными и подписанными файлами для отправки в ЦБ
     */
    @Value("${kyc.out1}")
    private String kycOut1;

    /**
     * Host 2 переменные
     */

    //Имя хоста с СКЗИ хост1
    @Value("${kyc.host2}")
    private String cryptoHost2;

    //Полученные от ЦБ файлы из ЛК без расшифровки должны сохраняться в папку
    @Value("${kyc.in953905fromcb2}")
    private String inputFromCB9539052;

    //Сохранение направленных файлов и подписей в папку
    @Value("${kyc.out953905tocb2}")
    private String outputFileToCB9539052;

    /**
     * Расшифрованные файлы из ЦБ
     */
    @Value("${kyc.forursb2}")
    private String decryptoFromCBb2;

    /**
     * Файлы с ошибкой  шифрования
     */
    @Value("${kyc.error2}")
    private String cryptoError2;

    /**
     * Зашифрованные файлы из ЦБ
     */
    @Value("${kyc.frombr2}")
    private String cryptoFromCB2;

    /**
     * папка с файлами для зашифровки и создания подписи для отправки в ЦБ
     */
    @Value("${kyc.in2}")
    private String kycIn2;

    /**
     *  В случае когда возвращается значение new - грузим только новые сообщения
     *  В случае all - загружаем все сообщения типа Zadach130
     */

    /**
     * папка с файлами логов
     */
    @Value("${kyc.logs2}")
    private String kycLogs2;

    /**
     * папка с зашифрованными и подписанными файлами для отправки в ЦБ
     */
    @Value("${kyc.out2}")
    private String kycOut2;



    /**
     * Назначение переменных Хоста
     */
    public void setInputFromCB953905(String inputFromCB953905) {
        this.inputFromCB953905 = inputFromCB953905;
    }

    public void setOutputFileToCB953905(String outputFileToCB953905) {
        this.outputFileToCB953905 = outputFileToCB953905;
    }

    public void setDecryptoFromCBb(String decryptoFromCBb) {
        this.decryptoFromCBb = decryptoFromCBb;
    }

    public void setCryptoError(String cryptoError) {
        this.cryptoError = cryptoError;
    }

    public void setCryptoFromCB(String cryptoFromCB) {
        this.cryptoFromCB = cryptoFromCB;
    }

    public void setKycIn(String kycIn) {
        this.kycIn = kycIn;
    }

    public void setKycLogs(String kycLogs) {
        this.kycLogs = kycLogs;
    }

    public void setKycOut(String kycOut) {
        this.kycOut = kycOut;
    }

    public void setCryptoHost(String cryptoHost) {
        this.cryptoHost = cryptoHost;
    }

    /**
     * Реализация получение основной переменной
     */

    public String getCryptoHost() {
        return cryptoHost;
    }
    public String getInputFromCB953905() {
        return inputFromCB953905;
    }

    public String getOutputFileToCB953905() {
        return outputFileToCB953905;
    }

    public String getDecryptoFromCBb() {
        return decryptoFromCBb;
    }

    public String getCryptoError() {
        return cryptoError;
    }

    public String getCryptoFromCB() {
        return cryptoFromCB;
    }

    public String getKycIn() {
        return kycIn;
    }

    public String getKycLogs() {
        return kycLogs;
    }

    public String getKycOut() {
        return kycOut;
    }



    /**
     * Хост 1
     */

    public String getCryptoHost1() {
        return cryptoHost1;
    }

    public String getInputFromCB9539051() {
        return inputFromCB9539051;
    }

    public String getOutputFileToCB9539051() {
        return outputFileToCB9539051;
    }

    public String getDecryptoFromCBb1() {
        return decryptoFromCBb1;
    }

    public String getCryptoError1() {
        return cryptoError1;
    }

    public String getCryptoFromCB1() {
        return cryptoFromCB1;
    }

    public String getKycIn1() {
        return kycIn1;
    }

    public String getKycLogs1() {
        return kycLogs1;
    }

    public String getKycOut1() {
        return kycOut1;
    }

    /**
     * Хост 2
     */

    public String getCryptoHost2() {
        return cryptoHost2;
    }

    public String getInputFromCB9539052() {
        return inputFromCB9539052;
    }

    public String getOutputFileToCB9539052() {
        return outputFileToCB9539052;
    }

    public String getDecryptoFromCBb2() {
        return decryptoFromCBb2;
    }

    public String getCryptoError2() {
        return cryptoError2;
    }

    public String getCryptoFromCB2() {
        return cryptoFromCB2;
    }

    public String getKycIn2() {
        return kycIn2;
    }

    public String getKycLogs2() {
        return kycLogs2;
    }

    public String getKycOut2() {
        return kycOut2;
    }

    /**
     * Установка значений на хост 1 или 2
     * 1 - устанавливаем значения из КриптоХост 1 = kyc.host1
     * 2 - устанавливаем значения из КриптоХост 2 = kyc.host2
     */
    public void setCryptoHst(int hostNumber){
        if (hostNumber==1){
            setCryptoError(getCryptoError1());
            setCryptoFromCB(getCryptoFromCB1());
            setKycIn(getKycIn1());
            setKycLogs(getKycLogs1());
            setDecryptoFromCBb(getDecryptoFromCBb1());
            setInputFromCB953905(getInputFromCB9539051());
            setOutputFileToCB953905(getOutputFileToCB9539051());
            setKycOut(getKycOut1());
            setCryptoHost(getCryptoHost1());
        } else {
            setCryptoError(getCryptoError2());
            setCryptoFromCB(getCryptoFromCB2());
            setKycIn(getKycIn2());
            setKycLogs(getKycLogs2());
            setDecryptoFromCBb(getDecryptoFromCBb2());
            setInputFromCB953905(getInputFromCB9539052());
            setOutputFileToCB953905(getOutputFileToCB9539052());
            setKycOut(getKycOut2());
            setCryptoHost(getCryptoHost2());
        }


    }
}
