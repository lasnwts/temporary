package ru.usb.checkcatolog;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class Utils {

    BusinessLogger logger = new BusinessLogger(LoggerFactory.getLogger(this.getClass()));


    //Проверка наличия файла или каталога

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            logger.info("Directory :: [" + targetPath + "] exist.Ok.");
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }

}
