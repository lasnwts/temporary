package ru.usb.checkcatolog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckcatologApplication implements CommandLineRunner {

    @Autowired
    Utils utils;

    @Autowired
    Configure configure;

    @Autowired
    Switch962025 switch962025;

    Logger logger = LoggerFactory.getLogger(CheckcatologApplication.class);
//	Marker businessNotification = MarkerFactory.getMarker("BUSINESS_USB");
//
//	public static final String INFO = "info";

//	BusinessLogger logger = new BusinessLogger(LoggerFactory.getLogger(this.getClass()));

    public static void main(String[] args) {
        SpringApplication.run(CheckcatologApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        String s = "C:\\AppServer\\Data\\testCatalog\\cas1\\";

        logger.info("Start application");
        if (utils.checkPathExists(s)) {
            logger.info("Exists! => {}", s);
        } else {
            logger.error("Path not Exists! => {}", s);
        }


		configure.setCryptoHst(2);
        switch962025.getPrintedHost(0);
        switch962025.getPrintedHost(1);
        switch962025.getPrintedHost(2);

        configure.setCryptoHst(1);
        switch962025.getPrintedHost(0);

        logger.info(switch962025.getCryptoParams());

        logger.info("Host name СКЗМ= "+switch962025.getCryptoHostName());


    }
}
