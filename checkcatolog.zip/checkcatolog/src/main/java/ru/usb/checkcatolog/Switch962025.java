package ru.usb.checkcatolog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Переключатель между двумя серверами Crypto
 */

@Component
public class Switch962025 {

    Logger logger = LoggerFactory.getLogger(CheckcatologApplication.class);
    @Autowired
    Configure configure;

    /**
     * Печать всех переменных Хоста
     * 0 - рабочие переменные
     * 1 - Host 1
     * 2 - Host 2
     */
    public void getPrintedHost(int hostNumber) {

        logger.info("");
        logger.info("######################################################################################################");
        if (hostNumber < 1) {
            logger.info("#  Действующие Переменные для хоста СКЗИ                                                              #");
        } else {
            logger.info("#  Переменные для хоста {}                                                                            #", hostNumber);
        }

        logger.info("#  Наименования в скобках соответствуют имени в файле application.properties                         #");
        logger.info("######################################################################################################");


        if (hostNumber < 1) {
            logger.info("1. Зашифрованные файлы из ЦБ                :: {}", configure.getCryptoFromCB());
            logger.info("2. Расшифрованные файлы из ЦБ               :: {}", configure.getDecryptoFromCBb());
            logger.info("3. Файлы с ошибками в работе СКЗИ           :: {}", configure.getCryptoError());
            logger.info("4. Каталог логов СКЗИ                       :: {}", configure.getKycLogs());
            logger.info("5. Незашифрованные файлы из Банка в ЦБ      :: {}", configure.getKycIn());
            logger.info("6. Зашифрованные файлы из Банка в ЦБ        :: {}", configure.getKycOut());
            logger.info("7. Зашифрованные файлы из ЦБ                :: {}", configure.getInputFromCB953905());
            logger.info("8. Зашифрованные файлы из Банка в ЦБ        :: {}", configure.getOutputFileToCB953905());
            logger.info("9. Имя хоста СКЗИ                           :: {}", configure.getCryptoHost());
        }

        if (hostNumber == 1) {

            logger.info("1. Зашифрованные файлы из ЦБ           (kyc.frombr1)      :: {}", configure.getCryptoFromCB1());
            logger.info("2. Расшифрованные файлы из ЦБ          (kyc.forursb1)     :: {}", configure.getDecryptoFromCBb1());
            logger.info("3. Файлы с ошибками в работе СКЗИ      (kyc.error1)       :: {}", configure.getCryptoError1());
            logger.info("4. Каталог логов СКЗИ                  (kyc.logs1)        :: {}", configure.getKycLogs1());
            logger.info("5. Незашифрованные файлы из Банка в ЦБ (kyc.in1)          :: {}", configure.getKycIn1());
            logger.info("6. Зашифрованные файлы из Банка в ЦБ   (kyc.out1)         :: {}", configure.getKycOut1());
            logger.info("7. Зашифрованные файлы из ЦБ (kyc.in953905fromcb1)        :: {}", configure.getInputFromCB9539051());
            logger.info("8. Зашифрованные файлы из Банка в ЦБ (kyc.out953905tocb1) :: {}", configure.getOutputFileToCB9539051());
            logger.info("9. Имя хоста СКЗИ                                         :: {}", configure.getCryptoHost1());
        }

        if (hostNumber == 2) {
            logger.info("1. Зашифрованные файлы из ЦБ           (kyc.frombr2)      :: {}", configure.getCryptoFromCB2());
            logger.info("2. Расшифрованные файлы из ЦБ          (kyc.forursb2)     :: {}", configure.getDecryptoFromCBb2());
            logger.info("3. Файлы с ошибками в работе СКЗИ      (kyc.error2)       :: {}", configure.getCryptoError2());
            logger.info("4. Каталог логов СКЗИ                  (kyc.logs2)        :: {}", configure.getKycLogs2());
            logger.info("5. Незашифрованные файлы из Банка в ЦБ (kyc.in2)          :: {}", configure.getKycIn2());
            logger.info("6. Зашифрованные файлы из Банка в ЦБ   (kyc.out2)         :: {}", configure.getKycOut2());
            logger.info("7. Зашифрованные файлы из ЦБ (kyc.in953905fromcb2)        :: {}", configure.getInputFromCB9539052());
            logger.info("8. Зашифрованные файлы из Банка в ЦБ (kyc.out953905tocb2) :: {}", configure.getOutputFileToCB9539052());
            logger.info("9. Имя хоста СКЗИ                                         :: {}", configure.getCryptoHost2());
        }
        logger.info("######################################################################################################");

    }


    /**
     * Вернуть настройки СКЗИ
     * @return - реально настройки
     */
    public String getCryptoParams() {
        return
                "1. Зашифрованные файлы из ЦБ : " + configure.getCryptoFromCB() + "\n" +
                "2. Расшифрованные файлы из ЦБ : " + configure.getDecryptoFromCBb() + "\n" +
                "3. Файлы с ошибками в работе СКЗИ : " + configure.getCryptoError() + "\n" +
                "4. Каталог логов СКЗИ : " + configure.getKycLogs() + "\n" +
                "5. Незашифрованные файлы из Банка в ЦБ : " + configure.getKycIn() + "\n" +
                "6. Зашифрованные файлы из Банка в ЦБ : " + configure.getKycOut() + "\n" +
                "7. Зашифрованные файлы из ЦБ : " + configure.getInputFromCB953905() + "\n" +
                "8. Зашифрованные файлы из Банка в ЦБ : " + configure.getOutputFileToCB953905() + "\n" +
                "9. Имя хоста СКЗИ : " + configure.getCryptoHost();
    }

    /**
     * Запрос имени хоста машины СКЗИ
     * @return - имя хоста
     */
    public String getCryptoHostName(){
       return configure.getCryptoHost();
    }

}
