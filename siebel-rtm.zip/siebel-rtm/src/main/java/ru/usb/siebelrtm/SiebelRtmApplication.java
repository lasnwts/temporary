package ru.usb.siebelrtm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiebelRtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiebelRtmApplication.class, args);
	}

}
