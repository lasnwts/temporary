package ru.alex_example.springbootconfigcryptpassword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConfigCryptPasswordApplicationTests {

	@Test
	void contextLoads() {
	}

}
