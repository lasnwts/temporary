package ru.alex_example.springbootconfigcryptpassword.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties()
//@Validated
//@Profile("dev")
/*
 * Выяснилось, что при наличии переменных в локальном файле application.properties
 * переменные из локального файла будут применены, а переменные из удаленного файла затерты
 * */
@PropertySource("classpath:application.properties")
public class MyProperties {
    @Value("${login}")
    String login;
    @Value("${password}")
    String passwords;

    public String getLogin() {
        return login;
    }

    public String getPasswords() {
        return passwords;
    }

    @Override
    public String toString() {
        return "MyProperties{" +
                "name='" + login + '\'' +
                ", passwords='" + passwords + '\'' +
                '}';
    }
}
