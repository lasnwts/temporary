package ru.alex_example.springbootconfigcryptpassword;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.alex_example.springbootconfigcryptpassword.config.GlobalProperties;
import ru.alex_example.springbootconfigcryptpassword.config.MailProperties;
import ru.alex_example.springbootconfigcryptpassword.config.MyProperties;

@SpringBootApplication
public class SpringBootConfigCryptPasswordApplication implements CommandLineRunner {

	@Autowired
	MyProperties myProperties;

	@Autowired
	GlobalProperties globalProperties;

	@Autowired
	MailProperties mailProperties;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootConfigCryptPasswordApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("====================================================================");
		System.out.println("Application.Properties(login)="+myProperties.getLogin()+" .. Apllicatiopn.Properties(password)="+myProperties.getPasswords());
		System.out.println("====================================================================");
		System.out.println("Global"+globalProperties.toString());
		System.out.println("====================================================================");
		System.out.println("Global.Properties:Mail="+mailProperties.toString());
		System.out.println("====================================================================");
	}
}
