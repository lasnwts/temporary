package ru.alex_example.springbootconfigcryptpassword.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:global.properties")
public class GlobalProperties {
    @Value("${thread-pool}")
    private int threadPool;
    @Value("${email}")
    private String email;

    @Value("${global-password}")
    private String globalPassword;

    @Value("${mail.host}")
    private String mailhost;

    public String getMailhost() {
        return mailhost;
    }

    public void setMailhost(String mailhost) {
        this.mailhost = mailhost;
    }

    public int getThreadPool() {
        return threadPool;
    }

    public void setThreadPool(int threadPool) {
        this.threadPool = threadPool;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGlobalPassword() {
        return globalPassword;
    }

    public void setGlobalPassword(String globalPassword) {
        this.globalPassword = globalPassword;
    }

    @Override
    public String toString() {
        return "GlobalProperties{" +
                "threadPool=" + threadPool +
                ", email='" + email + '\'' +
                ", globalPassword='" + globalPassword + '\'' +
                ", mailhost='" + mailhost + '\'' +
                '}';
    }
}
