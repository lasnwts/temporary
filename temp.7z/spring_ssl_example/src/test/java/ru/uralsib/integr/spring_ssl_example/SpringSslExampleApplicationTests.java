package ru.uralsib.integr.spring_ssl_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSslExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
