package ru.example.generated_uuid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneratedUuidApplicationTests {

	@Test
	void contextLoads() {
	}

}
