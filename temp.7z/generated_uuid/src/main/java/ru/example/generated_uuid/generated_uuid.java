package ru.example.generated_uuid;

import java.util.UUID;

public interface generated_uuid {
    public UUID getUUID();
}
