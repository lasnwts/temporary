package ru.example.generated_uuid;

import com.fasterxml.uuid.Generators;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.UUID;

@SpringBootApplication
public class GeneratedUuidApplication {

    public static void main(String[] args) {
        SpringApplication.run(GeneratedUuidApplication.class, args);
        System.out.println("Start application");
        System.out.println("=======================================================");
        UUID uuid = UUID.randomUUID();
        System.out.println("UUID = " + uuid.toString());
        System.out.println("=======================================================");
        UUID_interf uuid_interf = new UUID_interf();
        System.out.println(" UUID from interface= " + uuid_interf.getUUID());
        System.out.println("=======================================================");
        System.out.println(" Построение на com.fasterxml.uuid<");
        UUID uuid1 = Generators.timeBasedGenerator().generate();
        System.out.println("fasterxml UUID =" + uuid1.toString());
        System.out.println("=======================================================");
    }

}
