package ru.example.generated_uuid;

import java.util.UUID;

public class UUID_interf implements generated_uuid{
    @Override
    public UUID getUUID() {
        return UUID.randomUUID();
    }
}
