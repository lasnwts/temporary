package ri.usb.citiimportxlsuuid.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "citianniversary")
public class UUIDAnniversaryW1 {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    private String customer;

    private String account;

    private String month_anniversary;

    private String uuid;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputdate;

    //Имя файла
    private String filename;

    //Номер строки
    private int numstr;

    public UUIDAnniversaryW1() {
    }

    public UUIDAnniversaryW1(long id, String customer, String account, String month_anniversary, String uuid, Date inputdate, String filename, int numstr) {
        this.id = id;
        this.customer = customer;
        this.account = account;
        this.month_anniversary = month_anniversary;
        this.uuid = uuid;
        this.inputdate = inputdate;
        this.filename = filename;
        this.numstr = numstr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getMonth_anniversary() {
        return month_anniversary;
    }

    public void setMonth_anniversary(String month_anniversary) {
        this.month_anniversary = month_anniversary;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Date getInputdate() {
        return inputdate;
    }

    public void setInputdate(Date inputdate) {
        this.inputdate = inputdate;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public int getNumstr() {
        return numstr;
    }

    public void setNumstr(int numstr) {
        this.numstr = numstr;
    }

    @Override
    public String toString() {
        return "UUIDAnniversaryW1{" +
                "id=" + id +
                ", customer='" + customer + '\'' +
                ", account='" + account + '\'' +
                ", month_anniversary='" + month_anniversary + '\'' +
                ", uuid='" + uuid + '\'' +
                ", inputdate=" + inputdate +
                ", filename='" + filename + '\'' +
                ", numstr=" + numstr +
                '}';
    }
}
