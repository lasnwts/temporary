package ri.usb.citiimportxlsuuid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ri.usb.citiimportxlsuuid.config.Configure;
import ri.usb.citiimportxlsuuid.service.ServProcessed;
import ri.usb.citiimportxlsuuid.utils.WorkWithFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

@SpringBootApplication
public class CitiImportXlsUuidApplication implements CommandLineRunner {

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    Configure configure;

    @Autowired
    ServProcessed servProcessed;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(CitiImportXlsUuidApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitiImportXlsUuidApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Показываем версию
        logger.info("12.07.2023г. v.0.0.1");
        logger.info("-----------------------------------------------");
        logger.info("| Service:" + configure.getAppName());
        logger.info("| Version of service:" + configure.getAppVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        /**
         * Проверка директорий
         */
        if (withFiles.checkPathExists(configure.getFileCsvDirectory())) {
            logger.info("Success. Директория: " + configure.getFileCsvDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileCsvDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileCsvDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileDirectory())) {
            logger.info("Success. Директория: " + configure.getFileDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileMoveDirectory())) {
            logger.info("Success. Директория: " + configure.getFileMoveDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileMoveDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileMoveDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileErrDirectory())) {
            logger.info("Success. Директория: " + configure.getFileErrDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileErrDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileErrDirectory());
        }
    }


    /*
     * Sheduler. Загрузки файлов
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {
        List<File> fileList = new ArrayList<>();

        /**
         * Запускаем сканирование каталога c файлами из СИТИ
         */
        fileList = withFiles.getDirList(configure.getFileDirectory());
        //Если файлы есть то отрабатываем по каждому файл
        if (fileList.size() > 0) {
            logger.info("<<<<<<<<<<<<<<<<<<<<< Start processed file XLSX job >>>>>>>>>>>>>>>>>>>");
            fileList.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {
                    //Проверяем, что это наш файл
                    if (file.getName().toUpperCase().contains(configure.getCitiFileExtension())) {
                        logger.info("File:Найден файл формата XLS:{}", file.getAbsolutePath());
                        if (file.getName().toUpperCase(Locale.ROOT).contains(configure.getCitiFileMaskBody())) {
                            logger.info("[UUIDAnniversaryW1]:СТАРТ ОБРАБОТКИ файла:{}", file.getAbsolutePath());
                            servProcessed.W1Service(file);
                            logger.info("[UUIDAnniversaryW1]:ОБРАБОТА ЗАВЕРШЕНА, файл:{}", file.getAbsolutePath());
                            System.gc();
                        }
                    }
                }
            });
            logger.info(">>>>>>>>>>>>>>>>>>> Stop processed file XLSX job >>>>>>>>>>>>>>>>>>>");
        }


    }

}


@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}