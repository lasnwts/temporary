package ri.usb.citiimportxlsuuid.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ri.usb.citiimportxlsuuid.config.Configure;
import ri.usb.citiimportxlsuuid.service.readxls.ReadAniversaryW1;
import ri.usb.citiimportxlsuuid.utils.WorkWithFiles;


import java.io.File;
import java.nio.file.FileSystems;

@Service
public class ServProcessed {


    Logger logger = LoggerFactory.getLogger(ServProcessed.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    ReadAniversaryW1 readAniversaryW1;


    /**
     * Запуск обработки файла UUIDAnniversaryW1
     */
    public void W1Service(File fName) {

        //Выполняем задержку, чтобы файл загрузился
        try {
            logger.info("Выполняем задержку перед обработкой файла{}, на {} секунд.", fName.getName(), Long.toString(configure.getCitiFileDelayUpload()));
            // в течение 1000 миллисекунд
            Thread.sleep(1000 * configure.getCitiFileDelayUpload());
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            if (readAniversaryW1.getFileXLS(fName)) {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
            } else {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName.getName());
            }
        } catch (Exception e) {
            logger.error("Ошибка обработки файла: {}, короткое наименование файла : {}", fName.getAbsolutePath(), fName.getName());
            logger.error("Error:{}", e.getMessage());
            withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
        }
    }
}
