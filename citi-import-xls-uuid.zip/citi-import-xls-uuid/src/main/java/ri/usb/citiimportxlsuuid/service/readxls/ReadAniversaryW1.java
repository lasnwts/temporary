package ri.usb.citiimportxlsuuid.service.readxls;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ri.usb.citiimportxlsuuid.config.Configure;
import ri.usb.citiimportxlsuuid.model.UUIDAnniversaryW1;
import ri.usb.citiimportxlsuuid.repository.JpaUUIDAnniversaryW1Repo;
import ri.usb.citiimportxlsuuid.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

@Component
public class ReadAniversaryW1 {


    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    Configure configure;

    @Autowired
    JpaUUIDAnniversaryW1Repo jpaW1Repo;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadAniversaryW1.class);

    public Workbook workbook;
    private String sDate;
    private int rowEnd;

    private String getString(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return null;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return "";
                    }
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return null;
                }
            default:
                return null;
        }
    }

    /**
     * Основной код чтения и создания объектов из записей XLS файла
     *
     * @param xlsFile
     * @return
     */

    public boolean getFileXLS(File xlsFile) {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(xlsFile);
        } catch (FileNotFoundException e) {
            logger.error("ReadPHoliday:getFileXLS:FileNotFoundException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        }
        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = null;
        try {
            myWorkBook = new XSSFWorkbook(fis);

            /**
             * Основное тело
             */

            // Return first sheet from the XLSX workbook
            XSSFSheet mySheet = myWorkBook.getSheetAt(0);

            // Get iterator to all the rows in current sheet
            Iterator<Row> rowIterator = mySheet.iterator();

            // Traversing over each row of XLSX file
            while (rowIterator.hasNext()) {

                Row row = rowIterator.next();

                if (row.getRowNum() == 0) {
                    row = rowIterator.next();
                }

                UUIDAnniversaryW1 depart = new UUIDAnniversaryW1();

                // For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                int currentCell = 0;

                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    if (currentCell == 0) {
                        depart.setCustomer(getString(cell));
                    }

                    if (currentCell == 1) {
                        depart.setAccount(getString(cell));
                    }

                    if (currentCell == 2) {
                        depart.setMonth_anniversary(getString(cell));
                    }

                    if (currentCell == 3) {
                        depart.setUuid(getString(cell));
                    }

                    currentCell = currentCell + 1;

                    if (currentCell > 3) {
                        break;
                    }

                }
                /**
                 * Служебные параметры дата и время вставки + имя файла
                 */

                depart.setInputdate(new Date());
                depart.setFilename(xlsFile.getName());
                depart.setNumstr(row.getRowNum() + 1);
                jpaW1Repo.saveAndFlush(depart);
                if (configure.isFileFlagCSV()) {
                    logger.info(depart.toString());
                }
                depart = null;
            }

        } catch (IOException e) {
            logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        } finally {
            try {
                myWorkBook.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
            try {
                fis.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
        }
        return true;
    }

}
