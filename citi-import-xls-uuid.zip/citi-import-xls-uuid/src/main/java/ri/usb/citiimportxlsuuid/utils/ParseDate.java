package ri.usb.citiimportxlsuuid.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class ParseDate {

    /**
     * формат даты-времени
     */
    LocalDate date;

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");


    Logger logger = LoggerFactory.getLogger(ParseDate.class);

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
//            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return false;
        }
    }

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm
     */
    public boolean parseDate2(String sDate) {
        try {
            date = LocalDate.parse(sDate, formatter2);
            return true;
        } catch (DateTimeException dateTimeException) {
//            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter2.toString());
            return false;
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate(String sDate) {
        try {
            return LocalDate.parse(sDate, formatter);
        } catch (DateTimeException dateTimeException) {
//            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter.toString());
            return null;
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate2(String sDate) {
        try {
            return LocalDate.parse(sDate, formatter2);
        } catch (DateTimeException dateTimeException) {
//            logger.error("Дата = " + sDate + " не соответствует формату ::" + formatter2.toString());
            return null;
        }
    }

    /**
     * ПРоверка и получения даты из файла CITI
     *
     * @param sDate
     * @return
     */
    public LocalDate getDtf(String sDate) {
        if (parseDate(sDate)) {
            return getDate(sDate);
        } else {
//            return LocalDate.parse("19170101", formatter);
            return null;
        }
    }

    /**
     * ПРоверка и получения даты из файла CITI
     *
     * @param sDate
     * @return
     */
    public LocalDate getDtf2(String sDate) {
        if (parseDate2(sDate)) {
            return getDate2(sDate);
        } else {
//            return LocalDate.parse("1917-01-01", formatter2);
            return null;
        }
    }
}
