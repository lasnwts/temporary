package ri.usb.citiimportxlsuuid.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ri.usb.citiimportxlsuuid.model.UUIDAnniversaryW1;

public interface JpaUUIDAnniversaryW1Repo extends JpaRepository<UUIDAnniversaryW1, Long> {
}
