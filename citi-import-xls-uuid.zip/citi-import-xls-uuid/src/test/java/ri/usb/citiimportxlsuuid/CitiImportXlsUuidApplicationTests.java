package ri.usb.citiimportxlsuuid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiImportXlsUuidApplicationTests {

	@Test
	void contextLoads() {
	}

}
