package ru.usb.testproject.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.testproject.dto.CIT_REQUEST;
import ru.usb.testproject.model.CIT_REQUEST2;
import ru.usb.testproject.model.Person;
import ru.usb.testproject.model.RequestCit;

@Component
public class RequestXML {

    Logger logger = LoggerFactory.getLogger(RequestXML.class);

    XmlMapper mapper = new XmlMapper();

    public String getSerialize2(CIT_REQUEST2 citRequest) throws JsonProcessingException {
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        String xml = mapper.writeValueAsString(citRequest);
        return xml;

    }

    public CIT_REQUEST getDeserialize() throws JsonProcessingException {

        String sXML = "<?xml version=\"1.0\" encoding=\"ISO-8859-5\"?>\n" +
                "\n" +
                "<CIT_REQUEST>\n" +
                "\n" +
                "                <SYSTEM>\n" +
                "\n" +
                "                               <BP_ID Value=\"EA_DOCUM_IN\"/>\n" +
                "\n" +
                "                               <CIT_Version Value=\"1.0\"/>\n" +
                "\n" +
                "                               <ERR Value=\"\"/>\n" +
                "\n" +
                "                               <FORMAT Value=\"JSON\"/>\n" +
                "\n" +
                "                               <INTERFACE_RET Value=\"\"/>\n" +
                "\n" +
                "                               <MAIN_ID Value=\"\"/>\n" +
                "\n" +
                "                               <MSG_ID Value=\"16844811720361\"/>\n" +
                "\n" +
                "                               <SYNC Value=\"N\"/>\n" +
                "\n" +
                "                               <SYS_ID Value=\"EARCHIVE\"/>\n" +
                "\n" +
                "                               <TAR_ID Value=\"IBSO_DISTR\"/>\n" +
                "\n" +
                "                               <Version Value=\"002\"/>\n" +
                "\n" +
                "                </SYSTEM>\n" +
                "\n" +
                "                <DATA><BODY>\"Test\"</BODY>\n" +
                "\n" +
                "                </DATA>\n" +
                "\n" +
                "</CIT_REQUEST>";

        String xml3 ="<CIT_REQUEST>\n" +
                "<SYSTEM>\n" +
                "<BP_ID Value=\"EA_DOCUM_IN\"/>\n" +
                "<CIT_Version Value=\"1.0\"/>\n" +
                "<ERR Value=\"\"/>\n" +
                "<FORMAT Value=\"JSON\"/>\n" +
                "<INTERFACE_RET Value=\"\"/>\n" +
                "<MAIN_ID Value=\"\"/>\n" +
                "<MSG_ID Value=\"16844811720361\"/>\n" +
                "<SYNC Value=\"N\"/>\n" +
                "<SYS_ID Value=\"EARCHIVE\"/>\n" +
                "<TAR_ID Value=\"IBSO_DISTR\"/>\n" +
                "<Version Value=\"002\"/>\n" +
                "</SYSTEM>\n" +
                "       <DATA>\n" +
                "    <messageId Value=\"16844811720361\"/>\n" +
                "    <id_documents Value=\"238\"/>\n" +
                "    <ERR Value=\"400\"/>\n" +
                "    <ERR_Value Value=\"Некорректная структура сообщения\"/>\n" +
                "  </DATA>" +
                "</CIT_REQUEST>";

        String xml2 ="<CIT_REQUEST>\n" +
                "<SYSTEM>\n" +
                "<BP_ID Value=\"EA_DOCUM_IN\"/>\n" +
                "<CIT_Version Value=\"1.0\"/>\n" +
                "<ERR Value=\"\"/>\n" +
                "<FORMAT Value=\"JSON\"/>\n" +
                "<INTERFACE_RET Value=\"\"/>\n" +
                "<MAIN_ID Value=\"\"/>\n" +
                "<MSG_ID Value=\"16844811720361\"/>\n" +
                "<SYNC Value=\"N\"/>\n" +
                "<SYS_ID Value=\"EARCHIVE\"/>\n" +
                "<TAR_ID Value=\"IBSO_DISTR\"/>\n" +
                "<Version Value=\"002\"/>\n" +
                "</SYSTEM>\n" +
                "</CIT_REQUEST>";


        String xml4 ="<CIT_REQUEST>\n" +
                "<SYSTEM>\n" +
                "<BP_ID Value=\"EA_DOCUM_IN\"/>\n" +
                "<CIT_Version Value=\"1.0\"/>\n" +
                "<ERR Value=\"\"/>\n" +
                "<FORMAT Value=\"JSON\"/>\n" +
                "<INTERFACE_RET Value=\"\"/>\n" +
                "<MAIN_ID Value=\"\"/>\n" +
                "<MSG_ID Value=\"16844811720361\"/>\n" +
                "<SYNC Value=\"N\"/>\n" +
                "<SYS_ID Value=\"EARCHIVE\"/>\n" +
                "<TAR_ID Value=\"IBSO_DISTR\"/>\n" +
                "<Version Value=\"002\"/>\n" +
                "</SYSTEM>\n" +
                "       <DATA>\n" +
                "    <messageId Value=\"16844811720361\"/>\n" +
                "    <versionRelativeContentLink Value=\"versionRelativeContentLink16844811720361\"/>\n" +
                "    <id_files Value=\"id_files844811720361\"/>\n" +
                "    <id_documents Value=\"238\"/>\n" +
                "    <ERR Value=\"400\"/>\n" +
                "    <ERR_Value Value=\"Некорректная структура сообщения\"/>\n" +
                "  </DATA>" +
                "</CIT_REQUEST>";


        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        CIT_REQUEST citRequest = mapper.readValue(xml4, CIT_REQUEST.class);
        System.out.println(citRequest);

        logger.info("citRequest.system={}", citRequest.getSYSTEM().toString());
        logger.info("citRequest.system.getBP_ID().getValue()={}", citRequest.getSYSTEM().getBP_ID().getValue());
        if (citRequest.getDATA()!=null){
            logger.info("citRequest.data={}", citRequest.getDATA().toString());
        }


        return citRequest;

    }

    public void getSerialize(CIT_REQUEST citRequest) throws JsonProcessingException {
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        String xml = mapper.writeValueAsString(citRequest);

        logger.info("XmlParserJackson:xml={}", xml);

    }
}
