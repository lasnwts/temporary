package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SYSTEM {

    @JsonProperty(value = "BP_ID")
    public BP_ID BP_ID;

    @JsonProperty(value = "CIT_Version")
    public CIT_Version CIT_Version;
    @JsonProperty(value = "ERR")
    public ERR ERR;
    @JsonProperty(value = "FORMAT")
    public FORMAT FORMAT;
    @JsonProperty(value = "INTERFACE_RET")
    public INTERFACE_RET INTERFACE_RET;
    @JsonProperty(value = "MAIN_ID")
    public MAIN_ID MAIN_ID;
    @JsonProperty(value = "MSG_ID")
    public MSG_ID MSG_ID;

    @JsonProperty(value = "SYNC")
    public SYNC SYNC;
    @JsonProperty(value = "SYS_ID")
    public SYS_ID SYS_ID;

    @JsonProperty(value = "TAR_ID")
    public TAR_ID TAR_ID;

    @JsonProperty(value = "Version")
    public Version Version;

    public SYSTEM() {
    }

    public SYSTEM(ru.usb.testproject.dto.BP_ID BP_ID, ru.usb.testproject.dto.CIT_Version CIT_Version,
                  ru.usb.testproject.dto.ERR ERR, ru.usb.testproject.dto.FORMAT FORMAT,
                  ru.usb.testproject.dto.INTERFACE_RET INTERFACE_RET, ru.usb.testproject.dto.MAIN_ID MAIN_ID,
                  ru.usb.testproject.dto.MSG_ID MSG_ID, ru.usb.testproject.dto.SYNC SYNC,
                  ru.usb.testproject.dto.SYS_ID SYS_ID, ru.usb.testproject.dto.TAR_ID TAR_ID,
                  ru.usb.testproject.dto.Version version) {
        this.BP_ID = BP_ID;
        this.CIT_Version = CIT_Version;
        this.ERR = ERR;
        this.FORMAT = FORMAT;
        this.INTERFACE_RET = INTERFACE_RET;
        this.MAIN_ID = MAIN_ID;
        this.MSG_ID = MSG_ID;
        this.SYNC = SYNC;
        this.SYS_ID = SYS_ID;
        this.TAR_ID = TAR_ID;
        this.Version = version;
    }

    @JsonProperty(value = "BP_ID")
    public ru.usb.testproject.dto.BP_ID getBP_ID() {
        return BP_ID;
    }

    @JsonProperty(value = "BP_ID")
    public void setBP_ID(ru.usb.testproject.dto.BP_ID BP_ID) {
        this.BP_ID = BP_ID;
    }

    @JsonProperty(value = "CIT_Version")
    public ru.usb.testproject.dto.CIT_Version getCIT_Version() {
        return CIT_Version;
    }

    @JsonProperty(value = "CIT_Version")
    public void setCIT_Version(ru.usb.testproject.dto.CIT_Version CIT_Version) {
        this.CIT_Version = CIT_Version;
    }

    @JsonProperty(value = "ERR")
    public ru.usb.testproject.dto.ERR getERR() {
        return ERR;
    }

    @JsonProperty(value = "ERR")
    public void setERR(ru.usb.testproject.dto.ERR ERR) {
        this.ERR = ERR;
    }

    @JsonProperty(value = "FORMAT")
    public ru.usb.testproject.dto.FORMAT getFORMAT() {
        return FORMAT;
    }

    @JsonProperty(value = "FORMAT")
    public void setFORMAT(ru.usb.testproject.dto.FORMAT FORMAT) {
        this.FORMAT = FORMAT;
    }

    @JsonProperty(value = "INTERFACE_RET")
    public ru.usb.testproject.dto.INTERFACE_RET getINTERFACE_RET() {
        return INTERFACE_RET;
    }

    @JsonProperty(value = "INTERFACE_RET")
    public void setINTERFACE_RET(ru.usb.testproject.dto.INTERFACE_RET INTERFACE_RET) {
        this.INTERFACE_RET = INTERFACE_RET;
    }

    @JsonProperty(value = "MAIN_ID")
    public ru.usb.testproject.dto.MAIN_ID getMAIN_ID() {
        return MAIN_ID;
    }

    @JsonProperty(value = "MAIN_ID")
    public void setMAIN_ID(ru.usb.testproject.dto.MAIN_ID MAIN_ID) {
        this.MAIN_ID = MAIN_ID;
    }

    @JsonProperty(value = "MSG_ID")
    public ru.usb.testproject.dto.MSG_ID getMSG_ID() {
        return MSG_ID;
    }

    @JsonProperty(value = "MSG_ID")
    public void setMSG_ID(ru.usb.testproject.dto.MSG_ID MSG_ID) {
        this.MSG_ID = MSG_ID;
    }

    @JsonProperty(value = "SYNC")
    public ru.usb.testproject.dto.SYNC getSYNC() {
        return SYNC;
    }

    @JsonProperty(value = "SYNC")
    public void setSYNC(ru.usb.testproject.dto.SYNC SYNC) {
        this.SYNC = SYNC;
    }

    @JsonProperty(value = "SYS_ID")
    public ru.usb.testproject.dto.SYS_ID getSYS_ID() {
        return SYS_ID;
    }

    @JsonProperty(value = "SYS_ID")
    public void setSYS_ID(ru.usb.testproject.dto.SYS_ID SYS_ID) {
        this.SYS_ID = SYS_ID;
    }

    @JsonProperty(value = "TAR_ID")
    public ru.usb.testproject.dto.TAR_ID getTAR_ID() {
        return TAR_ID;
    }

    @JsonProperty(value = "TAR_ID")
    public void setTAR_ID(ru.usb.testproject.dto.TAR_ID TAR_ID) {
        this.TAR_ID = TAR_ID;
    }

    @JsonProperty(value = "Version")
    public ru.usb.testproject.dto.Version getVersion() {
        return Version;
    }

    @JsonProperty(value = "Version")
    public void setVersion(ru.usb.testproject.dto.Version version) {
        Version = version;
    }

    @Override
    public String toString() {
        return "SYSTEM{" +
                "BP_ID=" + BP_ID +
                ", CIT_Version=" + CIT_Version +
                ", ERR=" + ERR +
                ", FORMAT=" + FORMAT +
                ", INTERFACE_RET=" + INTERFACE_RET +
                ", MAIN_ID=" + MAIN_ID +
                ", MSG_ID=" + MSG_ID +
                ", SYNC=" + SYNC +
                ", SYS_ID=" + SYS_ID +
                ", TAR_ID=" + TAR_ID +
                ", Version=" + Version +
                '}';
    }
}
