package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class id_files {
    @JsonProperty(value = "Value")
    public String Value;

    public id_files() {
    }

    public id_files(String value) {
        Value = value;
    }

    @JsonProperty(value = "Value")
    public String getValue() {
        return Value;
    }

    @JsonProperty(value = "Value")
    public void setValue(String value) {
        Value = value;
    }
}
