package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DATA {
    @JsonProperty(value = "BODY")
    public String BODY;

    /**
     *     <messageId Value="16844811720361"/>
     *     <id_documents Value="238"/>
     *     <ERR Value="400"/>
     *     <ERR_Value Value="Некорректная структура сообщения"/>
     */

    @JsonProperty(value = "ERR")
    public ERR err;

    @JsonProperty(value = "ERR_Value")
    public ERR_Value errValue;

    @JsonProperty(value = "id_files")
    public id_files id_files;

    @JsonProperty(value = "id_documents")
    public id_documents id_documents;

    @JsonProperty(value = "messageId")
    public messageId messageId;

    @JsonProperty(value = "versionRelativeContentLink")
    public versionRelativeContentLink versionRelativeContentLink;


    public DATA() {
    }

    public DATA(String BODY) {
        this.BODY = BODY;
    }

    @JsonProperty(value = "BODY")
    public String getBODY() {
        return BODY;
    }

    @JsonProperty(value = "BODY")
    public void setBODY(String BODY) {
        this.BODY = BODY;
    }

    @JsonProperty(value = "ERR")
    public ERR getErr() {
        return err;
    }

    @JsonProperty(value = "ERR")
    public void setErr(ERR err) {
        this.err = err;
    }

    @JsonProperty(value = "ERR_Value")
    public ERR_Value getErrValue() {
        return errValue;
    }

    @JsonProperty(value = "ERR_Value")
    public void setErrValue(ERR_Value errValue) {
        this.errValue = errValue;
    }

    @JsonProperty(value = "versionRelativeContentLink")
    public ru.usb.testproject.dto.versionRelativeContentLink getVersionRelativeContentLink() {
        return versionRelativeContentLink;
    }

    @JsonProperty(value = "versionRelativeContentLink")
    public void setVersionRelativeContentLink(ru.usb.testproject.dto.versionRelativeContentLink versionRelativeContentLink) {
        this.versionRelativeContentLink = versionRelativeContentLink;
    }

    @JsonProperty(value = "messageId")
    public ru.usb.testproject.dto.messageId getMessageId() {
        return messageId;
    }

    @JsonProperty(value = "messageId")
    public void setMessageId(ru.usb.testproject.dto.messageId messageId) {
        this.messageId = messageId;
    }

    @JsonProperty(value = "id_documents")
    public ru.usb.testproject.dto.id_documents getId_documents() {
        return id_documents;
    }

    @JsonProperty(value = "id_documents")
    public void setId_documents(ru.usb.testproject.dto.id_documents id_documents) {
        this.id_documents = id_documents;
    }

    @JsonProperty(value = "id_files")
    public ru.usb.testproject.dto.id_files getId_files() {
        return id_files;
    }

    @JsonProperty(value = "id_files")
    public void setId_files(ru.usb.testproject.dto.id_files id_files) {
        this.id_files = id_files;
    }
}
