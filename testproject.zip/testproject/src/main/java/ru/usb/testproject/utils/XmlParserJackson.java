package ru.usb.testproject.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.testproject.model.Person;
import ru.usb.testproject.model.Person2;

@Component
public class XmlParserJackson {
    Logger logger = LoggerFactory.getLogger(XmlParserJackson.class);

    XmlMapper mapper = new XmlMapper();

    public void getSerialize() throws JsonProcessingException {
        Person person = new Person("Иван", "Федорович", 23, "Крузенштерн");

        String xml = mapper.writeValueAsString(person);

        logger.info("XmlParserJackson:xml={}", xml);

    }

    public Person2 getDeserialize() throws JsonProcessingException {

        String sXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" +
                "<System>\n" +
                "\t<name>Иван</name>\n" +
                "\t<secondName>Федорович</secondName>\n" +
                "\t<age>23</age>\n" +
                "\t<address>Крузенштерн</address>\n" +
                "</System>";
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        Person2 person = mapper.readValue(sXML, Person2.class);

        logger.info("Person={}", person);
        return person;

    }

    public String getSerialize2(Person2 person) throws JsonProcessingException {
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        String xml = mapper.writeValueAsString(person);
        return xml;

    }
}
