package ru.usb.testproject.model;

public class Person {

    private String name;
    private String secondName;
    private int age;

    private String address;

    public Person() {
    }

    public Person(String name, String secondName, int age, String address) {
        this.name = name;
        this.secondName = secondName;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", secondName='" + secondName + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                '}';
    }
}
