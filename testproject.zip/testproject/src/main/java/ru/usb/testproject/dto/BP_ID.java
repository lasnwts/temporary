package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BP_ID {
    @JsonProperty(value = "Value")
    public String Value;

    public BP_ID() {
    }

    public BP_ID(String value) {
        Value = value;
    }

    @JsonProperty(value = "Value")
    public String getValue() {
        return Value;
    }

    @JsonProperty(value = "Value")
    public void setValue(String value) {
        Value = value;
    }
}
