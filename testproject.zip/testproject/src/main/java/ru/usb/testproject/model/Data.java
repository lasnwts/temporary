package ru.usb.testproject.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Data {
    @JacksonXmlProperty(localName = "BODY")
    private String body;

    public Data() {
    }

    public Data(String body) {
        this.body = body;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
