package ru.usb.testproject.configure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {

    /**
     * Зашифрованные файлы из ЦБ
     */
    private String cryptoFromCB;


    /**
     * Зашифрованные файлы из ЦБ
     */
    @Value("${kyc.frombr1}")
    private String cryptoFromCB1;


    public String getCryptoFromCB() {
        return cryptoFromCB1;
    }

    public String getCryptoFromCB1() {
        return cryptoFromCB1;
    }
}
