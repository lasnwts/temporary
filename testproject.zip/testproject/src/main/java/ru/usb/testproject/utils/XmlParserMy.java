package ru.usb.testproject.utils;

import org.apache.juneau.json.JsonParser;
import org.apache.juneau.json.JsonSerializer;
import org.apache.juneau.marshall.Xml;
import org.apache.juneau.parser.ParseException;
import org.apache.juneau.serializer.SerializeException;
import org.apache.juneau.xml.XmlParser;
import org.apache.juneau.xml.XmlSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.testproject.model.Person;
import ru.usb.testproject.model.Person2;

import java.util.logging.XMLFormatter;

@Component
public class XmlParserMy {

    Logger logger = LoggerFactory.getLogger(XmlParserMy.class);


    public void marshallXML() throws SerializeException, ParseException {

        Person person = new Person("Иван", "Федорович", 23, "Крузенштерн");

        String sXml = "<System><address>Гражданский проспект 106-1-34</address><age>56</age><page>6</page><name>Саша</name><secondName>Ильин</secondName></System>";
//        String sXml = "<object><address>Гражданский проспект 106-1-34</address><age>56</age><name>Саша</name><secondName>Ильин</secondName></object>";

        logger.info("Класс Person={}", person.toString());

        XmlSerializer xmlSerializerDEFAULT_NS_SQ = XmlSerializer.DEFAULT_NS_SQ;  //1
        XmlSerializer xmlSerializerDEFAULT = XmlSerializer.DEFAULT; //2
        XmlSerializer xmlSerializerDEFAULT_NS = XmlSerializer.DEFAULT_NS; //3
        XmlSerializer xmlSerializerDEFAULT_SQ = XmlSerializer.DEFAULT_SQ; //4
        XmlSerializer xmlSerializerDEFAULT_SQ_READABLE = XmlSerializer.DEFAULT_SQ_READABLE; //5
        XmlSerializer xmlSerializerDEFAULT_NS_SQ_READABLE = XmlSerializer.DEFAULT_NS_SQ_READABLE; //6

        String xml1 = xmlSerializerDEFAULT_NS_SQ.serialize(person);
        String xml2 = xmlSerializerDEFAULT.serialize(person);
        String xml3 = xmlSerializerDEFAULT_NS.serialize(person);
        String xml4 = xmlSerializerDEFAULT_SQ.serialize(person);
        String xml5 = xmlSerializerDEFAULT_SQ_READABLE.serialize(person);
        String xml6 = xmlSerializerDEFAULT_NS_SQ_READABLE.serialize(person);

        String xml = xmlSerializerDEFAULT.serializeToString(person);

        logger.info("Класс xml1={}", xml1);
        logger.info("Класс xml2={}", xml2);
        logger.info("Класс xml3={}", xml3);
        logger.info("Класс xml4={}", xml4);
        logger.info("Класс xml5={}", xml5);
        logger.info("Класс xml6={}", xml6);
        logger.info("Класс xml={}", xml);

        XmlParser xmlParser = XmlParser.DEFAULT;
        Person2 person1 = xmlParser.parse(sXml, Person2.class);
        logger.info("Person1={}", person1.toString());

        JsonSerializer jsonSerializer = JsonSerializer.DEFAULT;
        String json1 = jsonSerializer.serialize(person);

        logger.info("=================[Json]==================");
        logger.info("json1={}", json1);

        String jsonStr = "{\n" +
                "\t\"address\": \"Фрунзенская 77\",\n" +
                "\t\"age\": 45,\n" +
                "\t\"name\": \"Настя\",\n" +
                "\t\"secondName\": \"Козлова\"\n" +
                "}";
        JsonParser jsonParser = JsonParser.DEFAULT;
        Person person2 = jsonParser.parse(jsonStr, Person.class);
        logger.info("person2={}", person2.toString());


    }
}
