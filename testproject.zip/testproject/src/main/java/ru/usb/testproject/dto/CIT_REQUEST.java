package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class CIT_REQUEST{
    @JsonProperty(value = "SYSTEM")
    public SYSTEM SYSTEM;
    @JsonProperty(value = "DATA")
    public DATA DATA;

    public CIT_REQUEST() {
    }

    public CIT_REQUEST(ru.usb.testproject.dto.SYSTEM SYSTEM, ru.usb.testproject.dto.DATA DATA) {
        this.SYSTEM = SYSTEM;
        this.DATA = DATA;
    }

    public CIT_REQUEST(ru.usb.testproject.dto.SYSTEM SYSTEM) {
        this.SYSTEM = SYSTEM;
    }

    @JsonProperty(value = "SYSTEM")
    public ru.usb.testproject.dto.SYSTEM getSYSTEM() {
        return SYSTEM;
    }

    @JsonProperty(value = "SYSTEM")
    public void setSYSTEM(ru.usb.testproject.dto.SYSTEM SYSTEM) {
        this.SYSTEM = SYSTEM;
    }

    @JsonProperty(value = "DATA")
    public ru.usb.testproject.dto.DATA getDATA() {
        return DATA;
    }

    @JsonProperty(value = "DATA")
    public void setDATA(ru.usb.testproject.dto.DATA DATA) {
        this.DATA = DATA;
    }
}
