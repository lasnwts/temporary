package ru.usb.testproject.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class CIT_REQUEST2 {

    @JacksonXmlProperty(localName = "SYSTEM")
    private System2 system;

    @JacksonXmlProperty(localName = "DATA")
    private Data data;

    public CIT_REQUEST2() {
    }

    public CIT_REQUEST2(System2 system, Data data) {
        this.system = system;
        this.data = data;
    }

    public System2 getSystem() {
        return system;
    }

    public void setSystem(System2 system) {
        this.system = system;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

}
