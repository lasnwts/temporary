package ru.usb.testproject.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 *                 <SYSTEM>
 *
 *                                <BP_ID Value="EA_DOCUM_IN"/>
 *
 *                                <CIT_Version Value="1.0"/>
 *
 *                                <ERR Value=""/>
 *
 *                                <FORMAT Value="JSON"/>
 *
 *                                <INTERFACE_RET Value=""/>
 *
 *                                <MAIN_ID Value=""/>
 *
 *                                <MSG_ID Value="16844811720361"/>
 *
 *                                <SYNC Value="N"/>
 *
 *                                <SYS_ID Value="EARCHIVE"/>
 *
 *                                <TAR_ID Value="IBSO_DISTR"/>
 *
 *                                <Version Value="002"/>
 *
 *                 </SYSTEM>
 */
//@JsonIgnoreProperties(ignoreUnknown = true)
public class System2 {

    @JacksonXmlProperty(isAttribute = true, localName = "BP_ID")
    private String BP_ID;

    @JacksonXmlProperty(localName = "CIT_Version")
    private String CIT_Version;
    @JacksonXmlProperty(localName = "ERR")
    private String ERR;
    @JacksonXmlProperty(localName = "FORMAT")
    private String FORMAT;
    @JacksonXmlProperty(localName = "INTERFACE_RET")
    private String INTERFACE_RET;
    @JacksonXmlProperty(localName = "MAIN_ID")
    private String MAIN_ID;
    @JacksonXmlProperty(localName = "MSG_ID")
    private String MSG_ID;
    @JacksonXmlProperty(localName = "SYNC")
    private String SYNC;
    @JacksonXmlProperty(localName = "SYS_ID")
    private String SYS_ID;
    @JacksonXmlProperty(localName = "TAR_ID")
    private String TAR_ID;
    @JacksonXmlProperty(localName = "Version")
    private String Version;

    public System2() {
    }

    public System2(String BP_ID, String CIT_Version, String ERR, String FORMAT, String INTERFACE_RET,
                   String MAIN_ID, String MSG_ID, String SYNC, String SYS_ID, String TAR_ID, String version) {
        this.BP_ID = BP_ID;
        this.CIT_Version = CIT_Version;
        this.ERR = ERR;
        this.FORMAT = FORMAT;
        this.INTERFACE_RET = INTERFACE_RET;
        this.MAIN_ID = MAIN_ID;
        this.MSG_ID = MSG_ID;
        this.SYNC = SYNC;
        this.SYS_ID = SYS_ID;
        this.TAR_ID = TAR_ID;
        this.Version = version;
    }

    public String getBP_ID() {
        return BP_ID;
    }

    public void setBP_ID(String BP_ID) {
        this.BP_ID = BP_ID;
    }

    public String getCIT_Version() {
        return CIT_Version;
    }

    public void setCIT_Version(String CIT_Version) {
        this.CIT_Version = CIT_Version;
    }

    public String getERR() {
        return ERR;
    }

    public void setERR(String ERR) {
        this.ERR = ERR;
    }

    public String getFORMAT() {
        return FORMAT;
    }

    public void setFORMAT(String FORMAT) {
        this.FORMAT = FORMAT;
    }

    public String getINTERFACE_RET() {
        return INTERFACE_RET;
    }

    public void setINTERFACE_RET(String INTERFACE_RET) {
        this.INTERFACE_RET = INTERFACE_RET;
    }

    public String getMAIN_ID() {
        return MAIN_ID;
    }

    public void setMAIN_ID(String MAIN_ID) {
        this.MAIN_ID = MAIN_ID;
    }

    public String getMSG_ID() {
        return MSG_ID;
    }

    public void setMSG_ID(String MSG_ID) {
        this.MSG_ID = MSG_ID;
    }

    public String getSYNC() {
        return SYNC;
    }

    public void setSYNC(String SYNC) {
        this.SYNC = SYNC;
    }

    public String getSYS_ID() {
        return SYS_ID;
    }

    public void setSYS_ID(String SYS_ID) {
        this.SYS_ID = SYS_ID;
    }

    public String getTAR_ID() {
        return TAR_ID;
    }

    public void setTAR_ID(String TAR_ID) {
        this.TAR_ID = TAR_ID;
    }

    public String getVersion() {
        return Version;
    }

    public void setVersion(String version) {
        Version = version;
    }

    @Override
    public String toString() {
        return "SYSTEM{" +
                "BP_ID='" + BP_ID + '\'' +
                ", CIT_Version='" + CIT_Version + '\'' +
                ", ERR='" + ERR + '\'' +
                ", FORMAT='" + FORMAT + '\'' +
                ", INTERFACE_RET='" + INTERFACE_RET + '\'' +
                ", MAIN_ID='" + MAIN_ID + '\'' +
                ", MSG_ID='" + MSG_ID + '\'' +
                ", SYNC='" + SYNC + '\'' +
                ", SYS_ID='" + SYS_ID + '\'' +
                ", TAR_ID='" + TAR_ID + '\'' +
                ", Version='" + Version + '\'' +
                '}';
    }
}
