package ru.usb.testproject.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TAR_ID {

    @JsonProperty(value = "Value")
    public String Value;

    public TAR_ID(String value) {
        Value = value;
    }

    public TAR_ID() {
    }

    @JsonProperty(value = "Value")
    public String getValue() {
        return Value;
    }


    @JsonProperty(value = "Value")
    public void setValue(String value) {
        Value = value;
    }
}
