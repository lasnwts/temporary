package ru.usb.testproject.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

@JacksonXmlRootElement(localName = "CIT_REQUEST")
public class RequestCit {

    @JacksonXmlProperty(localName = "SYSTEM")
    @JacksonXmlElementWrapper(useWrapping = false)
     Systems[] systems;

     class Systems {
        @JacksonXmlProperty(localName = "FIELD")
        private BP_ID bpId;

        public Systems() {
        }

        public Systems(BP_ID bpId) {
            this.bpId = bpId;
        }

        public BP_ID getBpId() {
            return bpId;
        }

        public void setBpId(BP_ID bpId) {
            this.bpId = bpId;
        }
    }

     class BP_ID {
        @JacksonXmlProperty(isAttribute = true, localName = "Value")
        private String key;
        @JacksonXmlText(value = true)
        private String value;

        public BP_ID() {
        }

        public BP_ID(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public RequestCit() {
    }

    public RequestCit(Systems[] systems) {
        this.systems = systems;
    }

    public Systems[] getSystems() {
        return systems;
    }

    public void setSystems(Systems[] systems) {
        this.systems = systems;
    }
}
