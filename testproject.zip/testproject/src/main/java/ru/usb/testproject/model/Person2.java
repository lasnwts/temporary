package ru.usb.testproject.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Person2 {

    private String name;
    private String secondName;
    private int age;
    private String address;

    //@JacksonXmlProperty()
    private long page;

    public Person2() {
    }

    public Person2(String name, String secondName, int age, String address, long page) {
        this.name = name;
        this.secondName = secondName;
        this.age = age;
        this.address = address;
        this.page = page;
    }

    public long getPage() {
        return page;
    }

    public void setPage(long page) {
        this.page = page;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Person2{" +
                "name='" + name + '\'' +
                ", secondName='" + secondName + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                ", page=" + page +
                '}';
    }
}
