package ru.usb.testproject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.testproject.configure.Configure;
import ru.usb.testproject.utils.WorkWithFiles;

import java.io.File;
import java.util.List;
import java.util.function.Consumer;

@SpringBootApplication
public class TestprojectApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(TestprojectApplication.class);

	@Autowired
	Configure configure;

	@Autowired
	WorkWithFiles workWithFiles;

	public static void main(String[] args) {
		SpringApplication.run(TestprojectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		/**
		 * Проставляем флаг
		 * configure.getInputFromCB953905()
		 */
		List<String> list = workWithFiles.getDirFileWithExt(configure.getCryptoFromCB(), "enc");

		if (list!=null){
			if (list.size()>0){
				list.forEach(new Consumer<String>() {
					@Override
					public void accept(String s) {
						File file = new File(s);
						if (!workWithFiles.createFileFlag(workWithFiles.getOnlyFileName(file.getName()) + ".flg", configure.getCryptoFromCB())) {
							logger.error("Ошибка при создании файла флага: {}", file.getName() + ".flg");
						}
					}
				});
			}
		}

	}
}
