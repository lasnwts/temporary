package ru.usb.testproject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.CachedIntrospectionResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.testproject.configure.Configure;
import ru.usb.testproject.dto.CIT_REQUEST;
import ru.usb.testproject.model.Person2;
import ru.usb.testproject.utils.RequestXML;
import ru.usb.testproject.utils.WorkWithFiles;
import ru.usb.testproject.utils.XmlParserJackson;
import ru.usb.testproject.utils.XmlParserMy;

@SpringBootApplication
public class TestprojectApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(TestprojectApplication.class);

	@Autowired
	Configure configure;

	@Autowired
	WorkWithFiles workWithFiles;

	@Autowired
	XmlParserMy xmlParserMy;

	@Autowired
	XmlParserJackson xmlParserJackson;

	@Autowired
	RequestXML requestXML;

	public static void main(String[] args) {
		SpringApplication.run(TestprojectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		System.out.println("Помощь = URl help=>https://www.youtube.com/watch?v=ve4zhOGulII");
		System.out.println("Он лайн преобразование: https://json2csharp.com/code-converters/xml-to-java");

//		/**
//		 * Проставляем флаг
//		 * configure.getInputFromCB953905()
//		 */
//		List<String> list = workWithFiles.getDirFileWithExt(configure.getCryptoFromCB(), "enc");
//
//		if (list!=null){
//			if (list.size()>0){
//				list.forEach(new Consumer<String>() {
//					@Override
//					public void accept(String s) {
//						File file = new File(s);
//						if (!workWithFiles.createFileFlag(workWithFiles.getOnlyFileName(file.getName()) + ".flg", configure.getCryptoFromCB())) {
//							logger.error("Ошибка при создании файла флага: {}", file.getName() + ".flg");
//						}
//					}
//				});
//			}
//		}

		//juneau-marshall
		xmlParserMy.marshallXML();

		//jackson
		xmlParserJackson.getSerialize();
		Person2 person = xmlParserJackson.getDeserialize();
		logger.info("----------------Main Process ---------------");
		logger.info("PersonMain={}", person.toString());
		String xmlStr = xmlParserJackson.getSerialize2(person);
		logger.info("xml={}", xmlStr);

		//CIT_REQUEST
		CIT_REQUEST citRequest = requestXML.getDeserialize();
		requestXML.getSerialize(citRequest);


	}
}
