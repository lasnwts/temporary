package ru.usb.directory_traversal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectoryTraversalApplicationTests {

	@Test
	void contextLoads() {
	}

}
