package ru.usb.directory_traversal;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.directory_traversal.config.Configure;
import ru.usb.directory_traversal.config.LG;
import ru.usb.directory_traversal.utils.ArchiveCreated;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.zip.ZipOutputStream;

@SpringBootApplication
public class DirectoryTraversalApplication implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DirectoryTraversalApplication.class);

    private final Configure configure;
    private final ArchiveCreated archiveCreated;


    public DirectoryTraversalApplication(Configure configure, ArchiveCreated archiveCreated) {
        this.configure = configure;
        this.archiveCreated = archiveCreated;
    }

    public static void main(String[] args) {
        SpringApplication.run(DirectoryTraversalApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        // Проверка путей
        Path path = Paths.get(configure.getTargetDirectory());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            logger.info("{}:Directory {}  = created", LG.USBLOGINFO, path);
        } else {
            logger.info("{}:Directory {}  = already exists", LG.USBLOGINFO, path);
        }
        //Очистка директории
        FileUtils.cleanDirectory(new File(path.toString()));


//        FileOutputStream fos = new FileOutputStream("C:\\AppServer\\Data\\TBANK\\target\\dirCompressed.zip");
//        ZipOutputStream zipOut = new ZipOutputStream(fos);


        List<String> sDirectory = archiveCreated.getDirectory(configure.getSourceDirectory());
        if (sDirectory != null) {
            sDirectory.forEach(s -> {

                if (s != null && !archiveCreated.getUniversePath(s).equalsIgnoreCase(configure.getSourceDirectory())) {
                    logger.info("Директория:{} взята в работу", s);
                    try {
                        File file = new File(s);
                        logger.info("Full name:{}, Dir:{}", file, archiveCreated.getFileName(s));
                        FileOutputStream fos = new FileOutputStream(configure.getTargetDirectory() + "/rup_o_dos_" + archiveCreated.getFileName(s) + ".zip");
                        ZipOutputStream zipOut = new ZipOutputStream(fos);
                        archiveCreated.zipFile(file, archiveCreated.getFileName(s), zipOut);
                    } catch (Exception e) {
                        logger.error("archiveCreated :: error:{} ", e.getMessage());
                    }
                }
            });
        }


    }
}
