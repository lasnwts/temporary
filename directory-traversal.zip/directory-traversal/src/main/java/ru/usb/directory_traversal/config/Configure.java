package ru.usb.directory_traversal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {


    @Value("${source.file}")
    private String sourceDirectory; //Директория с исходными файлами

    @Value("${target.file}")
    private String targetDirectory; //Директория с файлами архивов

    public String getSourceDirectory() {
        return sourceDirectory;
    }

    public String getTargetDirectory() {
        return targetDirectory;
    }
}
