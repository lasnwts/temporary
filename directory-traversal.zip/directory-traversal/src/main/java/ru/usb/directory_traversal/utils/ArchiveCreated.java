package ru.usb.directory_traversal.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ArchiveCreated {

    private static final Logger logger = LoggerFactory.getLogger(ArchiveCreated.class);


    public void archiveCreated() {
        System.out.println("Archive created");
    }

    /**
     * Упаковка единичного файла, ZIP
     *
     * @param fileTozip Имя файла, который надо упаковать в ZIP
     * @param zipFile   Имя файла архива
     * @return Имя файла архива
     * @throws IOException
     */
    public void ZipFile(String fileTozip, String zipFile) throws IOException {
        logger.info("ZipFile :: fileTozip file:{} to zipFile:{} ", fileTozip, zipFile);
        FileOutputStream fos = new FileOutputStream(zipFile);
        try {
            ZipOutputStream zipOut = new ZipOutputStream(fos);
            File fileToZip = new File(fileTozip);
            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            zipOut.close();
            fis.close();
            fos.close();
        } catch (IOException e) {
            logger.error("ZipFile :: fileTozip file:{} to zipFile:{} ", fileTozip, zipFile);
            throw e;
        }
    }

    /**
     * Упаковка нескольких файлов, ZIP
     *
     * @param filesTozip Имя файлов, которые надо упаковать в ZIP
     * @param zipFile    Имя файла архива
     * @return Имя файла архива
     * @throws IOException
     */
    public void ZipFiles(String[] filesTozip, String zipFile) throws IOException {
        logger.info("ZipFiles :: filesTozip files:{} to zipFile:{} ", filesTozip, zipFile);
        FileOutputStream fos = new FileOutputStream(zipFile);
        try {
            ZipOutputStream zipOut = new ZipOutputStream(fos);
            for (String srcFile : filesTozip) {
                File fileToZip = new File(srcFile);
                FileInputStream fis = new FileInputStream(fileToZip);
                ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
                zipOut.putNextEntry(zipEntry);

                byte[] bytes = new byte[1024];
                int length;
                while ((length = fis.read(bytes)) >= 0) {
                    zipOut.write(bytes, 0, length);
                }
                fis.close();
            }
            zipOut.close();
            fos.close();
        } catch (IOException e) {
            logger.error("ZipFiles :: filesTozip files:{} to zipFile:{} ", filesTozip, zipFile);
            throw e;
        }
    }

    public void ZipFile(File fileTozip, String zipFile) throws IOException {
        try (OutputStream os = new FileOutputStream("zip_file.zip");
             ZipOutputStream zos = new ZipOutputStream(os)) {
            String s = "Hello, world!";
            ZipEntry entry = new ZipEntry("text_file.txt");
            zos.putNextEntry(entry);
            zos.write(s.getBytes());
            zos.closeEntry();
        }
        System.out.println("ZIP file created successfully");
    }


    /**
     * Упаковка директории, ZIP
     *
     * @param fileToZip Имя директории, которую надо упаковать в ZIP
     * @param dirName - Имя директории, которую надо упаковать в архив

     */
    public void zipFile(File fileToZip, String dirName, ZipOutputStream zipOut) throws IOException {

//        FileOutputStream fos = new FileOutputStream(zipOutName);
//        ZipOutputStream zipOut = new ZipOutputStream(fos);

        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (dirName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(dirName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(dirName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, dirName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(dirName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }

    /**
     * Приведение записи к одному виду
     * @param path - полный путь к каталогу
     * @return - полный путь к каталогу
     */
    public String getUniversePath(String path) {
        String result = "";
        if (path != null) {
            result = path.replace("\\", "/");
        }
        return result;
    }

    /**
     * Возвращает список каталогов
     * List all folders.
     * URL=https://mkyong.com/java/java-how-to-list-all-files-in-a-directory/
     *
     * @param pathRoot - корневой каталог, с которого начинается просмотр
     * @return - список строковых ссылок на катлоги
     */
    public List<String> getDirectory(String pathRoot) {

        if (!checkPathExists(pathRoot)) {
            logger.error("WorkWithFiles:::Error! Directory not exists! ::{}", pathRoot);
            return null;
        }

        List<String> result;
        try (Stream<Path> walk = Files.walk(Paths.get(pathRoot))) {

            result = walk.filter(Files::isDirectory)
                    .map(x -> x.toString()).collect(Collectors.toList());

//            result.forEach(System.out::println);

        } catch (IOException e) {
            logger.error("PrintStackTrace::", e);
            return null;
        }
        return result;
    }


    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            logger.info("Directory :: [" + targetPath + "] exist.Ok.");
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }

    /**
     * Получение имени файла из полного пути
     *
     * @param path - полный путь к файлу
     * @return - имя файла
     */
    public String getFileName(String path) {
        String result = "";
        if (path != null) {
            result = path.substring(path.lastIndexOf("\\") + 1);
        }
        return result;
    }

}
