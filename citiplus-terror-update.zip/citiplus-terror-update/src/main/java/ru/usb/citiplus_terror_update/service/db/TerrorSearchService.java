package ru.usb.citiplus_terror_update.service.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import ru.usb.citiplus_terror_update.config.LG;

import java.util.List;
import java.util.Map;

/**
 * Сервис поиска записей в таблице Oracle INTEGRATION_TERR.
 * <p>
 * Поддерживает поиск по точному значению поля NUMBER и поиск по части наименования NAMEU.
 * Имя таблицы задаётся через свойство {@code terror.db.table}.
 */
@Slf4j
@Service
public class TerrorSearchService {

    private final JdbcTemplate jdbcTemplate;
    private final String tableName;
    private final String searchSql;

    public TerrorSearchService(JdbcTemplate jdbcTemplate,
                               @Value("${terror.db.table}") String tableName) {
        this.jdbcTemplate = jdbcTemplate;
        this.tableName = tableName;
        this.searchSql = String.format("""
                SELECT "NUMBER", "TU", "CB_DATE", "CE_DATE",
                       "NAMEU", "GR", "YR", "MR",
                       "ND", "DESCRIPT",
                       "KD", "VD", "SD", "RG",
                       "KODCN", "KODCR", "AMR", "ADRESS",
                       "TERRTYPE", "TERROR",
                       "DIRECTOR", "FOUNDER", "ROW_ID", "UPDATED"
                FROM %s
                WHERE "NUMBER" = ?
                """, tableName);
    }

    /**
     * Ищет все записи таблицы по точному значению поля NUMBER (idSubEkta).
     *
     * @param number значение поля NUMBER
     * @return список найденных записей, пустой список если ничего не найдено
     */
    public List<Map<String, Object>> findByNumber(String number) {
        log.info("{}: DB поиск по NUMBER=[{}]", LG.USBLOGINFO, number);
        List<Map<String, Object>> result = jdbcTemplate.queryForList(searchSql, number);
        log.info("{}: DB найдено записей=[{}] для NUMBER=[{}]", LG.USBLOGINFO, result.size(), number);
        return result;
    }

    /**
     * Ищет записи где поле NAMEU содержит указанную строку (без учёта регистра).
     * <p>
     * Спецсимволы LIKE ({@code %}, {@code _}, {@code !}) в пользовательском вводе
     * автоматически экранируются через {@code ESCAPE '!'}.
     * Значение передаётся через {@code PreparedStatement} — защита от SQL-инъекции обеспечена.
     *
     * @param nameu часть наименования для поиска
     * @return список найденных записей, пустой список если ничего не найдено
     */
    public List<Map<String, Object>> findByNameu(String nameu) {
        String sql = String.format("""
                SELECT "NUMBER", "TU", "CB_DATE", "CE_DATE",
                       "NAMEU", "GR", "YR", "MR",
                       "ND", "DESCRIPT",
                       "KD", "VD", "SD", "RG",
                       "KODCN", "KODCR", "AMR", "ADRESS",
                       "TERRTYPE", "TERROR",
                       "DIRECTOR", "FOUNDER", "ROW_ID", "UPDATED"
                FROM %s
                WHERE UPPER("NAMEU") LIKE UPPER(?) ESCAPE '!'
                """, tableName);
        String escaped = nameu.replace("!", "!!").replace("%", "!%").replace("_", "!_");
        String pattern = "%" + escaped + "%";
        log.info("{}: DB поиск по NAMEU LIKE=[{}]", LG.USBLOGINFO, pattern);
        List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, pattern);
        log.info("{}: DB найдено записей=[{}] для NAMEU=[{}]", LG.USBLOGINFO, result.size(), nameu);
        return result;
    }
}
