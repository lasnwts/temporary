package ru.usb.citiplus_terror_update.config;

public enum LG {
    USBLOGINFO, USBLOGWARNING, USBLOGERROR, USBLOGDEBUG;
}
