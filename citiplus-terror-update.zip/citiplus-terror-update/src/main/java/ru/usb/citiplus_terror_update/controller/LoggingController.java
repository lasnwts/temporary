package ru.usb.citiplus_terror_update.controller;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.citiplus_terror_update.config.LG;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * REST контроллер для динамического управления уровнем логирования.
 * <p>
 * Позволяет изменять уровень логирования для любого пакета или класса
 * без перезапуска сервиса. Поддерживаемые уровни: TRACE, DEBUG, INFO, WARN, ERROR.
 */
@Slf4j
@RestController
@RequestMapping("/api/log")
@Tag(name = "Logging", description = "Управление уровнем логирования")
public class LoggingController {

    private static final String ROOT_LOGGER = "ROOT";
    private static final String APP_PACKAGE = "ru.usb.citiplus_terror_update";

    @Operation(
            summary = "Установить уровень логирования",
            description = "Изменяет уровень логирования для указанного пакета/класса. " +
                    "Допустимые уровни: TRACE, DEBUG, INFO, WARN, ERROR. " +
                    "Если logger не указан — применяется к пакету сервиса."
    )
    @PostMapping("/level")
    public ResponseEntity<String> setLevel(
            @Parameter(description = "Уровень логирования: TRACE, DEBUG, INFO, WARN, ERROR", required = true)
            @RequestParam String level,
            @Parameter(description = "Имя logger или пакета. По умолчанию: " + APP_PACKAGE)
            @RequestParam(required = false) String logger) {

        String loggerName = (logger != null && !logger.isBlank()) ? logger : APP_PACKAGE;

        Level newLevel = Level.toLevel(level.toUpperCase(), null);
        if (newLevel == null) {
            return ResponseEntity.badRequest()
                    .body("Недопустимый уровень: [" + level + "]. Допустимые: TRACE, DEBUG, INFO, WARN, ERROR");
        }

        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        ch.qos.logback.classic.Logger targetLogger = context.getLogger(loggerName);
        Level oldLevel = targetLogger.getLevel();
        targetLogger.setLevel(newLevel);

        log.info("{}: Уровень логирования изменён logger=[{}] {} -> {}",
                LG.USBLOGINFO, loggerName, oldLevel, newLevel);
        return ResponseEntity.ok(
                "Logger [" + loggerName + "] уровень изменён: " + oldLevel + " -> " + newLevel);
    }

    @Operation(
            summary = "Получить текущий уровень логирования",
            description = "Возвращает текущий уровень логирования для указанного пакета/класса."
    )
    @GetMapping("/level")
    public ResponseEntity<Map<String, String>> getLevel(
            @Parameter(description = "Имя logger или пакета. По умолчанию: " + APP_PACKAGE)
            @RequestParam(required = false) String logger) {

        String loggerName = (logger != null && !logger.isBlank()) ? logger : APP_PACKAGE;

        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        ch.qos.logback.classic.Logger targetLogger = context.getLogger(loggerName);

        Map<String, String> result = new LinkedHashMap<>();
        result.put("logger", loggerName);
        result.put("level", targetLogger.getLevel() != null
                ? targetLogger.getLevel().toString()
                : "inherited (" + targetLogger.getEffectiveLevel() + ")");

        return ResponseEntity.ok(result);
    }

    @Operation(
            summary = "Получить уровни всех логгеров сервиса",
            description = "Возвращает текущие уровни логирования для ROOT и пакета сервиса."
    )
    @GetMapping("/levels")
    public ResponseEntity<Map<String, String>> getLevels() {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

        Map<String, String> result = new LinkedHashMap<>();
        result.put(ROOT_LOGGER,
                context.getLogger(ROOT_LOGGER).getLevel().toString());
        result.put(APP_PACKAGE,
                context.getLogger(APP_PACKAGE).getEffectiveLevel().toString());

        // все логгеры с явно установленным уровнем
        context.getLoggerList().stream()
                .filter(l -> l.getLevel() != null && !l.getName().equals(ROOT_LOGGER))
                .sorted((a, b) -> a.getName().compareTo(b.getName()))
                .forEach(l -> result.put(l.getName(), l.getLevel().toString()));

        return ResponseEntity.ok(result);
    }
}
