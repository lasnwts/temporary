package ru.usb.citiplus_terror_update.service;

import org.springframework.stereotype.Service;
import ru.usb.citiplus_terror_update.model.HistoryEvent;
import ru.usb.citiplus_terror_update.model.SubEkt;
import ru.usb.citiplus_terror_update.model.TerrorListDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Сервис заполнения дат субъектов из истории событий.
 * <p>
 * История содержит список событий с именами: {@code DataVklyucheniya}, {@code DataIsklyucheniya}, {@code DataIzmeneniya}.
 * Метод {@link #fillDates} вызывается перед добавлением DTO в буфер Kafka и заполняет
 * поля {@code dataVklyucheniya} и {@code dataIsklyucheniya} каждого субъекта.
 */
@Service
public class TerrorListService {

    /**
     * Заполняет поля {@code dataVklyucheniya} и {@code dataIsklyucheniya} для всех субъектов DTO.
     * Для каждого субъекта берётся максимальная дата из списка событий истории.
     *
     * @param dto DTO сообщения Kafka
     */
    public void fillDates(TerrorListDto dto) {
        if (dto.getAktualNyjPerechen() == null || dto.getAktualNyjPerechen().getSubEkt() == null) {
            return;
        }
        dto.getAktualNyjPerechen().getSubEkt().forEach(subEkt -> {
            List<HistoryEvent> events = getEvents(subEkt);
            subEkt.setDataVklyucheniya(getMaxDate(events, "DataVklyucheniya").orElse(null));
            subEkt.setDataIsklyucheniya(getMaxDate(events, "DataIsklyucheniya").orElse(null));
        });
    }

    /**
     * Возвращает максимальную дату включения из истории субъекта.
     *
     * @param subEkt субъект из списка
     * @return максимальная дата включения или {@link java.util.Optional#empty()}
     */
    public Optional<LocalDate> getMaxDataVklyucheniya(SubEkt subEkt) {
        return getMaxDate(getEvents(subEkt), "DataVklyucheniya");
    }

    /**
     * Возвращает максимальную дату исключения из истории субъекта.
     *
     * @param subEkt субъект из списка
     * @return максимальная дата исключения или {@link java.util.Optional#empty()}
     */
    public Optional<LocalDate> getMaxDataIsklyucheniya(SubEkt subEkt) {
        return getMaxDate(getEvents(subEkt), "DataIsklyucheniya");
    }

    /**
     * Извлекает список событий из истории субъекта. Возвращает пустой список если история null.
     */
    private List<HistoryEvent> getEvents(SubEkt subEkt) {
        if (subEkt.getIstoriya() == null ||
                subEkt.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya() == null) {
            return List.of();
        }
        return subEkt.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya();
    }

    /**
     * Извлекает максимальную дату из списка событий по указанному имени.
     *
     * @param events список событий из истории
     * @param name   имя события (DataVklyucheniya, DataIsklyucheniya, DataIzmeneniya)
     * @return максимальная дата или {@link java.util.Optional#empty()}
     */
    private Optional<LocalDate> getMaxDate(List<HistoryEvent> events, String name) {
        return events.stream()
                .filter(e -> name.equals(e.getName()))
                .map(HistoryEvent::getValue)
                .map(LocalDate::parse)
                .max(LocalDate::compareTo);
    }
}
