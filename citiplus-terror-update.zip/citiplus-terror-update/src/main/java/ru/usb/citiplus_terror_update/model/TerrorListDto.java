package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TerrorListDto {
    private String versiyaFormata;
    private String dataPerechnya;
    private String dataPredyduschegoPerechnya;
    private AktualNyjPerechen aktualNyjPerechen;
    private Object poslednieVklyuchennye;
    private Object poslednieIsklyuchennye;

    @JsonProperty("Subject")
    private Integer subject;
    private Integer finish;
    private String filename;

    public String print() {
        return "TerrorListDto{" +
                "versiyaFormata='" + versiyaFormata + '\'' +
                ", dataPerechnya='" + dataPerechnya + '\'' +
                ", dataPredyduschegoPerechnya='" + dataPredyduschegoPerechnya + '\'' +
                ", aktualNyjPerechen=" + aktualNyjPerechen +
                '}';
    }

    /**
     * Подробный вывод для debug логирования.
     * Показывает как поля JSON смапировались на поля TerrorListDto и всех вложенных объектов.
     */
    public String printDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n=== TerrorListDto ===");
        sb.append("\n  versiyaFormata       = ").append(versiyaFormata);
        sb.append("\n  dataPerechnya        = ").append(dataPerechnya);
        sb.append("\n  dataPredyduschegoPerechnya = ").append(dataPredyduschegoPerechnya);
        sb.append("\n  subject              = ").append(subject);
        sb.append("\n  finish               = ").append(finish);
        sb.append("\n  filename             = ").append(filename);
        if (aktualNyjPerechen != null && aktualNyjPerechen.getSubEkt() != null) {
            sb.append("\n  subEkt.count         = ").append(aktualNyjPerechen.getSubEkt().size());
            for (int i = 0; i < aktualNyjPerechen.getSubEkt().size(); i++) {
                SubEkt s = aktualNyjPerechen.getSubEkt().get(i);
                sb.append("\n  --- subEkt[").append(i).append("] ---");
                sb.append("\n    idSubEkta          = ").append(s.getIdSubEkta());
                sb.append("\n    uns                = ").append(s.getUns());
                sb.append("\n    tipSubEkta         = ").append(s.getTipSubEkta() != null
                        ? s.getTipSubEkta().getIdentifikator() + " / " + s.getTipSubEkta().getNaimenovanie() : null);
                sb.append("\n    dataVklyucheniya    = ").append(s.getDataVklyucheniya());
                sb.append("\n    dataIsklyucheniya   = ").append(s.getDataIsklyucheniya());
                sb.append("\n    terrorist           = ").append(s.isTerrorist());
                sb.append("\n    primechanie         = ").append(s.getPrimechanie());
                if (s.getIstoriya() != null && s.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya() != null) {
                    s.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya()
                            .forEach(e -> sb.append("\n    istoriya            = ").append(e.getName()).append("=").append(e.getValue()));
                }
                if (s.getFl() != null) {
                    sb.append("\n    fl.fio              = ").append(s.getFl().getFio());
                    sb.append("\n    fl.fiolat           = ").append(s.getFl().getFioLat());
                    sb.append("\n    fl.dataRozhdeniya   = ").append(s.getFl().getDataRozhdeniya());
                    sb.append("\n    fl.godRozhdeniya    = ").append(s.getFl().getGodRozhdeniya());
                    sb.append("\n    fl.mestoRozhdeniya  = ").append(s.getFl().getMestoRozhdeniya());
                    sb.append("\n    fl.inn              = ").append(s.getFl().getInn());
                    sb.append("\n    fl.snils            = ").append(s.getFl().getSnils());
                    if (s.getFl().getSpisokGrazhdanstv() != null) {
                        sb.append("\n    fl.grazhdanstvo     = ").append(s.getFl().getSpisokGrazhdanstv().getGrazhdanstvo());
                    }
                    if (s.getFl().getSpisokDokumentov() != null && s.getFl().getSpisokDokumentov().getDokument() != null) {
                        s.getFl().getSpisokDokumentov().getDokument().forEach(d ->
                                sb.append("\n    fl.dokument         = ")
                                        .append(d.getTipDokumenta() != null ? d.getTipDokumenta().getIdentifikator() + "/" + d.getTipDokumenta().getNaimenovanie() : null)
                                        .append(" seriya=").append(d.getSeriya())
                                        .append(" nomer=").append(d.getNomer())
                                        .append(" organ=").append(d.getOrganVydachi())
                                        .append(" data=").append(d.getDataVydachi()));
                    }
                    if (s.getFl().getSpisokDrNaimenovanij() != null && s.getFl().getSpisokDrNaimenovanij().getDrNaimenovanie() != null) {
                        sb.append("\n    fl.drNaimenovanie.count = ").append(s.getFl().getSpisokDrNaimenovanij().getDrNaimenovanie().size());
                        s.getFl().getSpisokDrNaimenovanij().getDrNaimenovanie().forEach(dr ->
                                sb.append("\n    fl.drNaimenovanie   = fio=").append(dr.getFio())
                                        .append(" fiolat=").append(dr.getFioLat())
                                        .append(" inn=").append(dr.getInn()));
                    }
                }
                if (s.getOrg() != null) {
                    sb.append("\n    org.naimenovanie    = ").append(s.getOrg().getNaimenovanie());
                    sb.append("\n    org.naimenovanieLat = ").append(s.getOrg().getNaimenovanieLat());
                    sb.append("\n    org.inn             = ").append(s.getOrg().getInn());
                    sb.append("\n    org.ogrn            = ").append(s.getOrg().getOgrn());
                    sb.append("\n    org.dataRegistratsii= ").append(s.getOrg().getDataRegistratsii());
                    sb.append("\n    org.mestoRegistratsii= ").append(s.getOrg().getMestoRegistratsii());
                }
                if (s.getSpisokAdresov() != null && s.getSpisokAdresov().getAdres() != null) {
                    s.getSpisokAdresov().getAdres().forEach(a ->
                            sb.append("\n    adres               = tipId=")
                                    .append(a.getTipAdresa() != null ? a.getTipAdresa().getIdentifikator() : null)
                                    .append(" tekst=").append(a.getTekstAdresa())
                                    .append(" strana=").append(a.getStrana() != null ? a.getStrana().getKod() : null));
                }
            }
        } else {
            sb.append("\n  aktualNyjPerechen    = null или subEkt пуст");
        }
        sb.append("\n====================\n");
        return sb.toString();
    }
}
