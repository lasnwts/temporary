package ru.usb.citiplus_terror_update.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.citiplus_terror_update.config.LG;

import ru.usb.citiplus_terror_update.service.kafka.KafkaConsumerService;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/kafka")
@Tag(name = "Kafka", description = "Управление чтением сообщений из Kafka")
public class KafkaController {

    private static final String LISTENER_ID = "terrorListener";
    private static final String LISTENER_NOT_FOUND = "Listener не найден: ";

    private final KafkaListenerEndpointRegistry registry;
    private final KafkaConsumerService kafkaConsumerService;

    @Operation(summary = "Перечитать топик с начала",
            description = "Однократно перематывает offset в начало топика. После прочтения consumer продолжает работу в обычном режиме.")
    @PostMapping("/rewind")
    public ResponseEntity<String> rewind() {
        kafkaConsumerService.rewindToBeginning();
        log.info("{}: Kafka rewind запрошен через API", LG.USBLOGINFO);
        return ResponseEntity.ok("Перемотка топика в начало выполнена");
    }

    @Operation(summary = "Запустить чтение", description = "Запускает Kafka listener для чтения сообщений из топика")
    @PostMapping("/start")
    public ResponseEntity<String> start() {
        MessageListenerContainer container = registry.getListenerContainer(LISTENER_ID);
        if (container == null) {
            return ResponseEntity.badRequest().body(LISTENER_NOT_FOUND + LISTENER_ID);
        }
        if (container.isRunning()) {
            return ResponseEntity.ok("Listener уже запущен");
        }
        container.start();
        log.info("{}: Kafka listener [{}] запущен через API", LG.USBLOGINFO, LISTENER_ID);
        return ResponseEntity.ok("Listener запущен");
    }

    @Operation(summary = "Остановить чтение", description = "Останавливает Kafka listener")
    @PostMapping("/stop")
    public ResponseEntity<String> stop() {
        MessageListenerContainer container = registry.getListenerContainer(LISTENER_ID);
        if (container == null) {
            return ResponseEntity.badRequest().body(LISTENER_NOT_FOUND + LISTENER_ID);
        }
        if (!container.isRunning()) {
            return ResponseEntity.ok("Listener уже остановлен");
        }
        container.stop();
        log.info("{}: Kafka listener [{}] остановлен через API", LG.USBLOGINFO, LISTENER_ID);
        return ResponseEntity.ok("Listener остановлен");
    }

    @Operation(summary = "Статус listener", description = "Возвращает текущий статус Kafka listener")
    @GetMapping("/status")
    public ResponseEntity<String> status() {
        MessageListenerContainer container = registry.getListenerContainer(LISTENER_ID);
        if (container == null) {
            return ResponseEntity.badRequest().body(LISTENER_NOT_FOUND + LISTENER_ID);
        }
        String status = container.isRunning() ? "запущен" : "остановлен";
        return ResponseEntity.ok("Listener [" + LISTENER_ID + "] " + status);
    }
}
