package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SpisokAdresov {
    private List<Adres> adres;
}
