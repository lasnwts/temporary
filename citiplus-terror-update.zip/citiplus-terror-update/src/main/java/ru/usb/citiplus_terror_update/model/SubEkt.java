package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.time.LocalDate;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubEkt {
    private String idSubEkta;
    private String uns;
    private TipSubEkta tipSubEkta;
    private Istoriya istoriya;
    private Fl fl;
    private Org org;
    private SpisokAdresov spisokAdresov;
    private String primechanie;
    private boolean terrorist;
    private LocalDate dataVklyucheniya;
    private LocalDate dataIsklyucheniya;
}
