package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Org {
    private String naimenovanie;
    private String naimenovanieLat;
    private String dataRegistratsii;
    private String mestoRegistratsii;
    private String inn;
    private String ogrn;
    private SpisokDrNaimenovanij spisokDrNaimenovanij;
}
