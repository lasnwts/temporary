package ru.usb.citiplus_terror_update.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("citiplus-terror-update")
                        .description("Сервис читает обновления террористических списков из Apache Kafka " +
                                "и записывает данные в таблицу Oracle INTEGRATION_TERR.")
                        .version("0.0.1")
                        .contact(new Contact()
                                .name("ПАО Банк «Уралсиб»")
                                .url("https://uralsib.ru")
                                .email("lyapustinas@spb.uralsib.ru")))
                .tags(List.of(
                        new Tag().name("Kafka").description("Управление чтением сообщений из Kafka")
                ));
    }
}
