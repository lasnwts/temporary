package ru.usb.citiplus_terror_update.service.mail;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.citiplus_terror_update.config.Config;
import ru.usb.citiplus_terror_update.config.LG;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Сервис отправки email сообщений.
 * <p>
 * При отправке по списку адресатов каждый адрес обрабатывается отдельно —
 * ошибка отправки одному получателю не прерывает отправку остальным.
 * Все ошибки (сетевые, аутентификации, неверный адрес) логируются.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender emailSender;
    private final Config config;

    private static final String METHOD_SEND_SIMPLE       = "sendSimpleEmail";
    private static final String METHOD_SEND_SIMPLE_THROW = "sendSimpleEmailThrow";
    private static final String METHOD_SEND_ATTACHMENT   = "sendEmailWithAttachment";
    private static final String LOG_SENDING = "{}: [{}] отправка письма получателей=[{}] subject=[{}]";

    /**
     * Отправляет простое текстовое письмо каждому адресату из списка отдельно.
     * При ошибке отправки одному адресату — логирует и продолжает отправку остальным.
     *
     * @param toAddress список адресов через запятую
     * @param subject   тема письма
     * @param message   текст письма
     */
    public void sendSimpleEmail(String toAddress, String subject, String message) {
        if (!validateParams(toAddress, subject, message, METHOD_SEND_SIMPLE)) return;

        List<String> recipients = parseRecipients(toAddress, METHOD_SEND_SIMPLE);
        if (recipients.isEmpty()) return;

        log.info(LOG_SENDING, LG.USBLOGINFO, METHOD_SEND_SIMPLE, recipients.size(), subject);

        for (String recipient : recipients) {
            sendToSingleRecipient(recipient, subject, message, METHOD_SEND_SIMPLE);
        }
    }

    /**
     * Отправляет простое текстовое письмо каждому адресату из списка отдельно.
     * Аналогичен {@link #sendSimpleEmail}, но логирует ошибки с пометкой метода.
     *
     * @param toAddress список адресов через запятую
     * @param subject   тема письма
     * @param message   текст письма
     */
    public void sendSimpleEmailThrow(String toAddress, String subject, String message) {
        if (!validateParams(toAddress, subject, message, METHOD_SEND_SIMPLE_THROW)) return;

        List<String> recipients = parseRecipients(toAddress, METHOD_SEND_SIMPLE_THROW);
        if (recipients.isEmpty()) return;

        log.info(LOG_SENDING, LG.USBLOGINFO, METHOD_SEND_SIMPLE_THROW, recipients.size(), subject);

        for (String recipient : recipients) {
            sendToSingleRecipient(recipient, subject, message, METHOD_SEND_SIMPLE_THROW);
        }
    }

    /**
     * Отправляет письмо с вложением каждому адресату из списка отдельно.
     * При ошибке отправки одному адресату — логирует и продолжает отправку остальным.
     *
     * @param toAddress  список адресов через запятую
     * @param subject    тема письма
     * @param message    текст письма
     * @param attachment путь к файлу вложения
     */
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment)
            throws FileNotFoundException {

        if (!validateParams(toAddress, subject, message, METHOD_SEND_ATTACHMENT)) return;
        if (attachment == null) {
            log.error("{}: [{}] attachment не может быть null", LG.USBLOGERROR, METHOD_SEND_ATTACHMENT);
            return;
        }

        FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
        List<String> recipients = parseRecipients(toAddress, METHOD_SEND_ATTACHMENT);
        if (recipients.isEmpty()) return;

        log.info("{}: [{}] отправка письма с вложением=[{}] получателей=[{}]",
                LG.USBLOGINFO, METHOD_SEND_ATTACHMENT, attachment, recipients.size());

        for (String recipient : recipients) {
            try {
                MimeMessage mimeMessage = emailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
                helper.setFrom(config.getMailFrom());
                helper.setTo(recipient.trim());
                helper.setSubject(subject);
                helper.setText(message);
                helper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
                emailSender.send(mimeMessage);
                log.info("{}: [{}] письмо отправлено recipient=[{}]",
                        LG.USBLOGINFO, METHOD_SEND_ATTACHMENT, recipient);
            } catch (MailAuthenticationException e) {
                log.error("{}: [{}] ошибка аутентификации на почтовом сервере recipient=[{}] error=[{}]",
                        LG.USBLOGERROR, METHOD_SEND_ATTACHMENT, recipient, e.getMessage(), e);
            } catch (MailSendException e) {
                log.error("{}: [{}] ошибка отправки (сеть/сервер/адрес) recipient=[{}] error=[{}]",
                        LG.USBLOGERROR, METHOD_SEND_ATTACHMENT, recipient, e.getMessage(), e);
            } catch (MessagingException e) {
                log.error("{}: [{}] ошибка формирования сообщения recipient=[{}] error=[{}]",
                        LG.USBLOGERROR, METHOD_SEND_ATTACHMENT, recipient, e.getMessage(), e);
            } catch (Exception e) {
                log.error("{}: [{}] неожиданная ошибка recipient=[{}] error=[{}]",
                        LG.USBLOGERROR, METHOD_SEND_ATTACHMENT, recipient, e.getMessage(), e);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Отправляет письмо одному адресату с детальным логированием типа ошибки.
     */
    private void sendToSingleRecipient(String recipient, String subject, String message, String methodName) {
        log.debug("{}: [{}] подготовка письма recipient=[{}]", LG.USBLOGINFO, methodName, recipient);
        try {
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setFrom(config.getMailFrom());
            mail.setTo(recipient.trim());
            mail.setSubject(subject);
            mail.setSentDate(new Date());
            mail.setText(message);
            emailSender.send(mail);
            log.info("{}: [{}] письмо отправлено recipient=[{}]", LG.USBLOGINFO, methodName, recipient);
        } catch (MailAuthenticationException e) {
            log.error("{}: [{}] ошибка аутентификации на почтовом сервере host=[{}] recipient=[{}] error=[{}]",
                    LG.USBLOGERROR, methodName, config.getMailHost(), recipient, e.getMessage(), e);
        } catch (MailSendException e) {
            log.error("{}: [{}] ошибка отправки (сеть/сервер недоступен/неверный адрес) recipient=[{}] error=[{}]",
                    LG.USBLOGERROR, methodName, recipient, e.getMessage(), e);
        } catch (Exception e) {
            log.error("{}: [{}] неожиданная ошибка при отправке recipient=[{}] error=[{}]",
                    LG.USBLOGERROR, methodName, recipient, e.getMessage(), e);
        }
    }

    /**
     * Проверяет обязательные параметры на null.
     */
    private boolean validateParams(String toAddress, String subject, String message, String methodName) {
        if (toAddress == null || subject == null || message == null) {
            log.error("{}: [{}] параметры toAddress, subject, message не могут быть null toAddress=[{}] subject=[{}]",
                    LG.USBLOGERROR, methodName, toAddress, subject);
            return false;
        }
        return true;
    }

    /**
     * Разбирает строку адресов через запятую в список.
     */
    private List<String> parseRecipients(String toAddress, String methodName) {
        List<String> recipients = Arrays.stream(toAddress.split("\\s*,\\s*"))
                .filter(s -> !s.isBlank())
                .toList();
        if (recipients.isEmpty()) {
            log.error("{}: [{}] список адресатов пуст toAddress=[{}]", LG.USBLOGERROR, methodName, toAddress);
        }
        return recipients;
    }
}
