package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Dokument {
    private TipDokumenta tipDokumenta;
    private String seriya;
    private String nomer;
    private String organVydachi;
    private String dataVydachi;
    private String dataS;
    private String dataPo;
    private String priznakDejstvitelNosti;
}
