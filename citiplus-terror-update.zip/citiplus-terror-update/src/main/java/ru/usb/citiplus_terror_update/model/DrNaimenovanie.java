package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DrNaimenovanie {
    private String fio;
    private String familiya;
    private String imya;
    private String otchestvo;
    @JsonProperty("fiolat")
    private String fioLat;
    private String dataRozhdeniya;
    private String godRozhdeniya;
    private String mestoRozhdeniya;
    private String inn;
    private String snils;
    private SpisokDokumentov spisokDokumentov;
}
