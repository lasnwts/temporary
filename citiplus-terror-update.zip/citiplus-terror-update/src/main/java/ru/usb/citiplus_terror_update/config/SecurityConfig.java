package ru.usb.citiplus_terror_update.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

/**
 * Конфигурация Spring Security.
 * <p>
 * Использует HTTP Basic аутентификацию. Пользователь и пароль задаются
 * через свойства {@code service.user} и {@code service.password} в application.properties.
 * Открытый доступ: {@code /actuator/health}.
 * Все остальные маршруты требуют роль {@code USER}.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    public static final String USR = "USER";

    @Value("${service.user}")
    private String serviceUser;

    @Value("${service.password}")
    private String servicePassword;

    /**
     * Бин кодировщика паролей BCrypt.
     * Используется для проверки пароля пользователя при аутентификации.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Создаёт пользователя в памяти на основе значений из {@code service.user} и {@code service.password}.
     * Пароль должен быть захеширован алгоритмом BCrypt.
     *
     * @return менеджер пользователей в памяти
     */
    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails user = User.withUsername(serviceUser)
                .password(servicePassword)
                .roles(USR)
                .build();
        return new InMemoryUserDetailsManager(user);
    }

    /**
     * Настраивает цепочку фильтров безопасности:
     * <ul>
     *   <li>CSRF отключён (сервис без сессий)</li>
     *   <li>{@code /actuator/health} — открыт без аутентификации</li>
     *   <li>Все остальные маршруты требуют роль {@code USER} через HTTP Basic</li>
     * </ul>
     *
     * @param http объект настройки безопасности
     * @return настроенная цепочка фильтров
     * @throws Exception при ошибке конфигурации
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers("/actuator/health").permitAll() // Allow public access
                        .requestMatchers(HttpMethod.PUT, "/api/sets/*").hasRole(USR)
                        .requestMatchers("/**").hasRole(USR) // Require ADMIN role for admin paths
                        .requestMatchers("/api/**").hasRole(USR)
                        .anyRequest().authenticated()
                );
        return http.httpBasic(withDefaults()).build();
    }

}
