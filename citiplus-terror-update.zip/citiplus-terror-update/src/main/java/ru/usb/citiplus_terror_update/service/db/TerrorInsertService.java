package ru.usb.citiplus_terror_update.service.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import ru.usb.citiplus_terror_update.config.LG;
import ru.usb.citiplus_terror_update.model.*;
import ru.usb.citiplus_terror_update.service.mail.ServiceMailError;

import java.sql.Date;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Сервис пакетной вставки записей в таблицу Oracle INTEGRATION_TERR.
 * <p>
 * Обрабатывает два типа субъектов:
 * <ul>
 *   <li>{@code fl} — физическое лицо. Записи перемножаются по гражданствам × документам.
 *       Для каждого drNaimenovanie создаются отдельные строки.</li>
 *   <li>{@code org} — организация. Создаётся 1 или 2 записи в зависимости от наличия
 *       naimenovanie и naimenovanieLat.</li>
 * </ul>
 * Все строковые поля усекаются до максимальной длины соответствующего поля VARCHAR2.
 */
@Slf4j
@Service
public class TerrorInsertService {

    private final JdbcTemplate jdbcTemplate;
    private final String insertSql;
    private final String tableName;
    private final String appName;
    private final String procedureName;
    private final ServiceMailError serviceMailError;

    // TU: identifikator -> TU value
    private static final Map<Long, Integer> TU_MAP = Map.of(1L, 1, 2L, 3, 3L, 1, 4L, 3);

    // KD: tipDokumenta.identifikator -> KD code
    private static final Map<Long, String> KD_MAP = Map.ofEntries(
            Map.entry(1631718L,    "02"),
            Map.entry(1631725L,    "02"),
            Map.entry(1631726L,    "01"),
            Map.entry(1631727L,    "02"),
            Map.entry(14382683L,   "04"),
            Map.entry(74199428L,   "02"),
            Map.entry(74199429L,   "02"),
            Map.entry(74199431L,   "02"),
            Map.entry(74984730L,   "02"),
            Map.entry(746085885L,  "03"),
            Map.entry(746085996L,  "03"),
            Map.entry(746140005L,  "03"),
            Map.entry(1215068989L, "02"),
            Map.entry(1215068990L, "02"),
            Map.entry(1215068992L, "04")
    );

    public TerrorInsertService(JdbcTemplate jdbcTemplate,
                               @Value("${terror.db.table}") String tableName,
                               @Value("${info.application.name}") String appName,
                               @Value("${terror.db.procedure}") String procedureName,
                               ServiceMailError serviceMailError) {
        this.jdbcTemplate = jdbcTemplate;
        this.tableName = tableName;
        this.appName = appName;
        this.procedureName = procedureName;
        this.serviceMailError = serviceMailError;
        this.insertSql = String.format("""
                INSERT INTO %s (
                    "NUMBER", "TU", "CB_DATE", "CE_DATE",
                    "NAMEU", "GR", "YR", "MR",
                    "ND", "DESCRIPT",
                    "KD", "VD", "SD", "RG",
                    "KODCN", "KODCR", "AMR", "ADRESS",
                    "TERRTYPE", "TERROR"
                ) VALUES (
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?
                )
                """, tableName);
    }

    /**
     * Пакетная вставка списка DTO в таблицу БД.
     * Для каждого DTO извлекает субъекты и формирует строки через {@link #toFlRows} или {@link #toOrgRows}.
     * Поле INTEGRATION_STATUS устанавливается в 0.
     *
     * @param batch список DTO для вставки
     */
    @SuppressWarnings("java:S3776")
    public void insertBatch(List<TerrorListDto> batch) {
        List<Object[]> rows = new ArrayList<>();
        for (TerrorListDto dto : batch) {
            if (dto.getAktualNyjPerechen() == null || dto.getAktualNyjPerechen().getSubEkt() == null) continue;
            for (SubEkt s : dto.getAktualNyjPerechen().getSubEkt()) {
                if (s.getFl() != null) {
                    rows.addAll(toFlRows(s));
                } else if (s.getOrg() != null) {
                    rows.addAll(toOrgRows(s));
                }
            }
        }
        if (rows.isEmpty()) return;
        try {
            int chunkSize = 500;
            for (int i = 0; i < rows.size(); i += chunkSize) {
                List<Object[]> chunk = rows.subList(i, Math.min(i + chunkSize, rows.size()));
                jdbcTemplate.batchUpdate(insertSql, new BatchPreparedStatementSetter() {
                    @Override public void setValues(java.sql.PreparedStatement ps, int j) throws java.sql.SQLException {
                        Object[] row = chunk.get(j);
                        for (int k = 0; k < row.length; k++) ps.setObject(k + 1, row[k]);
                    }
                    @Override public int getBatchSize() { return chunk.size(); }
                });
            }
            log.info("{}: DB batch вставлено записей=[{}]", LG.USBLOGINFO, rows.size());
        } catch (Exception e) {
            log.error("{}: DB ошибка batch вставки количество строк=[{}] error=[{}]",
                    LG.USBLOGERROR, rows.size(), e.getMessage(), e);
            log.error("{}: DB SQL=[{}]", LG.USBLOGERROR, insertSql.replaceAll("\\s+", " ").trim());
            for (int i = 0; i < Math.min(rows.size(), 3); i++) {
                log.error("{}: DB строка[{}] values=[{}]",
                        LG.USBLOGERROR, i, Arrays.toString(rows.get(i)));
            }
            // попытка построчной вставки для локализации проблемной записи
            int errorIndex = -1;
            for (int i = 0; i < rows.size(); i++) {
                try {
                    jdbcTemplate.update(insertSql, rows.get(i));
                } catch (Exception rowEx) {
                    errorIndex = i;
                    log.error("{}: DB проблемная строка index=[{}] values=[{}] error=[{}]",
                            LG.USBLOGERROR, i, Arrays.toString(rows.get(i)), rowEx.getMessage());
                    break;
                }
            }
            if (errorIndex == -1) {
                log.error("{}: DB построчная вставка прошла успешно, ошибка была только в batch", LG.USBLOGERROR);
            }
            String subject = appName + " ERROR: ошибка вставки в БД";
            String body = "Ошибка batch вставки в таблицу " + tableName +
                    "\nКоличество строк: " + rows.size() +
                    (errorIndex >= 0 ? "\nПроблемная строка index=" + errorIndex +
                            "\nЗначения: " + Arrays.toString(rows.get(errorIndex)) : "") +
                    "\nОшибка: " + e.getMessage();
            serviceMailError.sendMailErrorSubject(subject, body);
        }
    }


    // -------------------------------------------------------------------------

    /**
     * Вызывает процедуру Oracle после завершения загрузки файла (finish=1).
     * Имя процедуры задаётся через свойство {@code terror.db.procedure}.
     * Ошибка логируется, но не прерывает обработку.
     */
    public void callUploadCompleted() {
        try {
            jdbcTemplate.execute("BEGIN " + procedureName + "; END;");
            log.info("{}: DB процедура [{}] выполнена", LG.USBLOGINFO, procedureName);
        } catch (Exception e) {
            log.error("{}: DB ошибка вызова процедуры [{}] error=[{}]", LG.USBLOGERROR, procedureName, e.getMessage(), e);
        }
    }

    // -------------------------------------------------------------------------
    // ORG rows
    // -------------------------------------------------------------------------

    /**
     * Формирует список строк для вставки по субъекту типа организация.
     * Если заполнены оба поля naimenovanie и naimenovanieLat — создаются две записи.
     *
     * @param s субъект с полем org
     * @return список строк для батча
     */
    private List<Object[]> toOrgRows(SubEkt s) {
        Org org = s.getOrg();
        List<Object[]> rows = new ArrayList<>();

        Date cbDate = calcCbDate(s);
        Date ceDate = calcCeDate(s);
        Integer tu  = TU_MAP.get(s.getTipSubEkta() != null ? s.getTipSubEkta().getIdentifikator() : -1L);

        String amr   = extractAmr(s);
        String adres = extractAdres(s);
        String kodcr = extractKodcrOrg(s);
        String kodcn = extractKodcnOrg(s);
        String gr    = org.getDataRegistratsii();

        // naimenovanie и naimenovanieLat — отдельные записи если оба заполнены
        List<String> names = new ArrayList<>();
        if (isNotBlank(org.getNaimenovanie()))    names.add(org.getNaimenovanie());
        if (isNotBlank(org.getNaimenovanieLat())) names.add(org.getNaimenovanieLat());
        if (names.isEmpty()) names.add(null);

        for (String nameu : names) {
            rows.add(buildOrgRow(s, org, tu, cbDate, ceDate,
                    nameu, gr, kodcn, kodcr, amr, adres));
        }
        return rows;
    }

    /**
     * Собирает массив параметров для одной строки INSERT по организации.
     * Поля YR, DESCRIPT, KD, VD, SD не заполняются (null).
     */
    @SuppressWarnings("java:S107")
    private Object[] buildOrgRow(SubEkt s, Org org, Integer tu, Date cbDate, Date ceDate,
                                 String nameu, String gr,
                                 String kodcn, String kodcr, String amr, String adres) {
        return new Object[]{
                toLong(s.getIdSubEkta()),              // NUMBER  INTEGER
                tu,                                    // TU      INTEGER
                cbDate,                                // CB_DATE DATE
                ceDate,                                // CE_DATE DATE
                trunc(nameu, 4000),                    // NAMEU   NVARCHAR2(4000)
                toDate(gr),                            // GR      DATE
                null,                                  // YR      INTEGER
                trunc(org.getMestoRegistratsii(), 255),// MR      NVARCHAR2(255)
                trunc(org.getInn(), 30),               // ND      NVARCHAR2(30)
                null,                                  // DESCRIPT NVARCHAR2(255)
                null,                                  // KD      NVARCHAR2(2)
                null,                                  // VD      NVARCHAR2(512)
                null,                                  // SD      NVARCHAR2(50)
                trunc(org.getOgrn(), 50),              // RG      NVARCHAR2(50)
                trunc(kodcn, 255),                     // KODCN   NVARCHAR2(255)
                trunc(kodcr, 255),                     // KODCR   NVARCHAR2(255)
                trunc(amr, 255),                       // AMR     NVARCHAR2(255)
                trunc(adres, 255),                     // ADRESS  NVARCHAR2(255)
                trunc(s.getPrimechanie(), 50),          // TERRTYPE NVARCHAR2(50)
                s.isTerrorist() ? 1 : 0                // TERROR  INTEGER
        };
    }

    // -------------------------------------------------------------------------
    // FL rows
    // -------------------------------------------------------------------------

    /**
     * Формирует список строк для вставки по субъекту типа физическое лицо.
     * Строки перемножаются по: гражданства × документы.
     * Для каждого drNaimenovanie создаются отдельные строки с данными из drNaimenovanie.
     *
     * @param s субъект с полем fl
     * @return список строк для батча
     */
    @SuppressWarnings("java:S3776")
    private List<Object[]> toFlRows(SubEkt s) {
        Fl fl = s.getFl();
        List<Object[]> rows = new ArrayList<>();

        Date cbDate = calcCbDate(s);
        Date ceDate = calcCeDate(s);
        Integer tu   = TU_MAP.get(s.getTipSubEkta() != null ? s.getTipSubEkta().getIdentifikator() : -1L);

        // адреса
        String amr   = extractAmr(s);
        String adres = extractAdres(s);
        String kodcr = extractKodcr(s);

        // гражданства — по одной записи на каждое
        List<String> grazhdanstva = fl.getSpisokGrazhdanstv() != null
                && fl.getSpisokGrazhdanstv().getGrazhdanstvo() != null
                ? fl.getSpisokGrazhdanstv().getGrazhdanstvo()
                : Collections.singletonList(null);

        // документы основной записи
        List<Dokument> docs = getDocs(fl.getSpisokDokumentov());

        // drNaimenovanie
        List<DrNaimenovanie> drList = fl.getSpisokDrNaimenovanij() != null
                && fl.getSpisokDrNaimenovanij().getDrNaimenovanie() != null
                ? fl.getSpisokDrNaimenovanij().getDrNaimenovanie()
                : Collections.emptyList();

        for (String kodcn : grazhdanstva) {
            if (docs.isEmpty()) {
                // основная запись без документа
                rows.add(buildFlRow(s, fl, tu, cbDate, ceDate,
                        fl.getFio(), fl.getFioLat(),
                        toDate(fl.getDataRozhdeniya()), fl.getGodRozhdeniya(), fl.getMestoRozhdeniya(),
                        fl.getInn(), fl.getSnils(),
                        null, null, null, null,
                        kodcn, kodcr, amr, adres));
            } else {
                for (Dokument doc : docs) {
                    rows.add(buildFlRow(s, fl, tu, cbDate, ceDate,
                            fl.getFio(), fl.getFioLat(),
                            toDate(fl.getDataRozhdeniya()), fl.getGodRozhdeniya(), fl.getMestoRozhdeniya(),
                            fl.getInn(), fl.getSnils(),
                            mapKd(doc), buildVd(doc), doc.getSeriya(), doc.getNomer(),
                            kodcn, kodcr, amr, adres));
                }
            }

            // drNaimenovanie — отдельные записи
            for (DrNaimenovanie dr : drList) {
                List<Dokument> drDocs = getDocs(dr.getSpisokDokumentov());
                if (drDocs.isEmpty()) {
                    rows.add(buildFlRow(s, fl, tu, cbDate, ceDate,
                            dr.getFio(), dr.getFioLat(),
                            toDate(dr.getDataRozhdeniya()), dr.getGodRozhdeniya(), dr.getMestoRozhdeniya(),
                            dr.getInn(), dr.getSnils(),
                            null, null, null, null,
                            kodcn, kodcr, amr, adres));
                } else {
                    for (Dokument doc : drDocs) {
                        rows.add(buildFlRow(s, fl, tu, cbDate, ceDate,
                                dr.getFio(), dr.getFioLat(),
                                toDate(dr.getDataRozhdeniya()), dr.getGodRozhdeniya(), dr.getMestoRozhdeniya(),
                                dr.getInn(), dr.getSnils(),
                                mapKd(doc), buildVd(doc), doc.getSeriya(), doc.getNomer(),
                                kodcn, kodcr, amr, adres));
                    }
                }
            }
        }
        return rows;
    }

    /**
     * Собирает массив параметров для одной строки INSERT по физическому лицу.
     * NAMEU формируется как fio;fiolat (только непустые значения).
     */
    @SuppressWarnings("java:S107")
    private Object[] buildFlRow(SubEkt s, Fl fl, Integer tu, Date cbDate, Date ceDate,
                                String fio, String fioLat,
                                Date gr, String yr, String mr,
                                String nd, String descript,
                                String kd, String vd, String sd, String rg,
                                String kodcn, String kodcr, String amr, String adres) {
        return new Object[]{
                toLong(s.getIdSubEkta()),                       // NUMBER   INTEGER
                tu,                                             // TU       INTEGER
                cbDate,                                         // CB_DATE  DATE
                ceDate,                                         // CE_DATE  DATE
                trunc(joinNonBlank(";", fio, fioLat), 4000),    // NAMEU    NVARCHAR2(4000)
                gr,                                             // GR       DATE
                toInteger(yr),                                  // YR       INTEGER
                trunc(mr, 255),                                 // MR       NVARCHAR2(255)
                trunc(nd, 30),                                  // ND       NVARCHAR2(30)
                trunc(descript, 255),                           // DESCRIPT NVARCHAR2(255)
                trunc(kd, 2),                                   // KD       NVARCHAR2(2)
                trunc(vd, 512),                                 // VD       NVARCHAR2(512)
                trunc(sd, 50),                                  // SD       NVARCHAR2(50)
                trunc(rg, 50),                                  // RG       NVARCHAR2(50)
                trunc(kodcn, 255),                              // KODCN    NVARCHAR2(255)
                trunc(kodcr, 255),                              // KODCR    NVARCHAR2(255)
                trunc(amr, 255),                                // AMR      NVARCHAR2(255)
                trunc(adres, 255),                              // ADRESS   NVARCHAR2(255)
                trunc(s.getPrimechanie(), 50),                  // TERRTYPE NVARCHAR2(50)
                s.isTerrorist() ? 1 : 0                         // TERROR   INTEGER
        };
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Вычисляет CB_DATE как максимум из dataVklyucheniya и dataIzmeneniya из истории.
     */
    private Date calcCbDate(SubEkt s) {
        Date dvk = toDate(s.getDataVklyucheniya());
        Date dim = extractDataIzmeneniya(s);
        if (dvk == null) return dim;
        if (dim == null) return dvk;
        return dim.after(dvk) ? dim : dvk;
    }

    /**
     * Возвращает CE_DATE из поля dataIsklyucheniya субъекта.
     */
    private Date calcCeDate(SubEkt s) {
        if (s.getDataIsklyucheniya() == null) return null;
        return Date.valueOf(s.getDataIsklyucheniya());
    }

    /**
     * Извлекает максимальное значение dataIzmeneniya из истории субъекта.
     */
    private Date extractDataIzmeneniya(SubEkt s) {
        if (s.getIstoriya() == null || s.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya() == null)
            return null;
        return s.getIstoriya().getDataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya().stream()
                .filter(e -> "dataIzmeneniya".equalsIgnoreCase(e.getName()) && e.getValue() != null)
                .map(e -> toDate(e.getValue()))
                .filter(Objects::nonNull)
                .max(Comparator.naturalOrder())
                .orElse(null);
    }

    /**
     * Извлекает текст адреса для поля AMR: адрес с tipAdresa.identifikator = 2.
     */
    private String extractAmr(SubEkt s) {
        if (s.getSpisokAdresov() == null || s.getSpisokAdresov().getAdres() == null) return null;
        return s.getSpisokAdresov().getAdres().stream()
                .filter(a -> a.getTipAdresa() != null && a.getTipAdresa().getIdentifikator() == 2)
                .map(Adres::getTekstAdresa)
                .filter(Objects::nonNull)
                .findFirst().orElse(null);
    }

    /**
     * Извлекает текст адреса для поля ADRESS: адрес с tipAdresa.identifikator != 2.
     */
    private String extractAdres(SubEkt s) {
        if (s.getSpisokAdresov() == null || s.getSpisokAdresov().getAdres() == null) return null;
        return s.getSpisokAdresov().getAdres().stream()
                .filter(a -> a.getTipAdresa() == null || a.getTipAdresa().getIdentifikator() != 2)
                .map(Adres::getTekstAdresa)
                .filter(Objects::nonNull)
                .findFirst().orElse(null);
    }

    /**
     * Извлекает код страны для поля KODCR (для fl): адрес с tipAdresa.identifikator = 1.
     */
    private String extractKodcr(SubEkt s) {
        if (s.getSpisokAdresov() == null || s.getSpisokAdresov().getAdres() == null) return null;
        return s.getSpisokAdresov().getAdres().stream()
                .filter(a -> a.getTipAdresa() != null && a.getTipAdresa().getIdentifikator() == 1
                        && a.getStrana() != null)
                .map(a -> a.getStrana().getKod())
                .filter(Objects::nonNull)
                .findFirst().orElse(null);
    }

    /**
     * Извлекает код страны для поля KODCR (для org): адрес с tipAdresa.identifikator = 2.
     */
    private String extractKodcrOrg(SubEkt s) {
        if (s.getSpisokAdresov() == null || s.getSpisokAdresov().getAdres() == null) return null;
        return s.getSpisokAdresov().getAdres().stream()
                .filter(a -> a.getTipAdresa() != null && a.getTipAdresa().getIdentifikator() == 2
                        && a.getStrana() != null)
                .map(a -> a.getStrana().getKod())
                .filter(Objects::nonNull)
                .findFirst().orElse(null);
    }

    /**
     * Извлекает код страны для поля KODCN (для org): адрес с tipAdresa.identifikator = 5.
     */
    private String extractKodcnOrg(SubEkt s) {
        if (s.getSpisokAdresov() == null || s.getSpisokAdresov().getAdres() == null) return null;
        return s.getSpisokAdresov().getAdres().stream()
                .filter(a -> a.getTipAdresa() != null && a.getTipAdresa().getIdentifikator() == 5
                        && a.getStrana() != null)
                .map(a -> a.getStrana().getKod())
                .filter(Objects::nonNull)
                .findFirst().orElse(null);
    }

    /** Проверяет что строка не null и не пустая. */
    private boolean isNotBlank(String s) {
        return s != null && !s.isBlank();
    }

    /** Возвращает список документов из SpisokDokumentov, либо пустой список если null. */
    private List<Dokument> getDocs(SpisokDokumentov sd) {
        if (sd == null || sd.getDokument() == null) return Collections.emptyList();
        return sd.getDokument();
    }

    /**
     * Маппирует identifikator типа документа в код KD согласно таблице {@link #KD_MAP}.
     * Если значение не найдено — возвращает null.
     */
    private String mapKd(Dokument doc) {
        if (doc.getTipDokumenta() == null) return null;
        return KD_MAP.get(doc.getTipDokumenta().getIdentifikator());
    }

    /**
     * Формирует значение поля VD: naimenovanie + organVydachi + dataVydachi через пробел.
     * Пустые части пропускаются.
     */
    private String buildVd(Dokument doc) {
        if (doc.getTipDokumenta() == null) return null;
        return joinNonBlank(" ",
                doc.getTipDokumenta().getNaimenovanie(),
                doc.getOrganVydachi(),
                doc.getDataVydachi());
    }

    /** Преобразует строку в Long для поля NUMBER INTEGER. При ошибке возвращает null. */
    private Long toLong(String value) {
        if (value == null) return null;
        try { return Long.parseLong(value.trim()); } catch (NumberFormatException e) { return null; }
    }

    /** Преобразует строку в Integer. При ошибке возвращает null. */
    private Integer toInteger(String value) {
        if (value == null || value.isBlank()) return null;
        try { return Integer.parseInt(value.trim()); } catch (NumberFormatException e) { return null; }
    }

    /**
     * Усекает строку до указанной максимальной длины. null пропускает.
     *
     * @param value  исходная строка
     * @param maxLen максимальная длина согласно DDL таблицы
     * @return усечённая строка или null
     */
    private String trunc(String value, int maxLen) {
        if (value == null) return null;
        return value.length() <= maxLen ? value : value.substring(0, maxLen);
    }

    /**
     * Объединяет непустые строки через указанный разделитель. null и пустые значения пропускаются.
     *
     * @param sep   разделитель
     * @param parts части строки
     * @return собранная строка
     */
    private String joinNonBlank(String sep, String... parts) {
        return Arrays.stream(parts)
                .filter(p -> p != null && !p.isBlank())
                .collect(Collectors.joining(sep));
    }

    /** Преобразует {@link LocalDate} в {@link Date} для JDBC. null пропускает. */
    private Date toDate(LocalDate date) {
        return date != null ? Date.valueOf(date) : null;
    }

    /** Парсит строку в {@link Date}. При ошибке парсинга возвращает null. */
    private Date toDate(String date) {
        if (date == null || date.isBlank()) return null;
        try { return Date.valueOf(LocalDate.parse(date)); } catch (Exception e) { return null; }
    }
}
