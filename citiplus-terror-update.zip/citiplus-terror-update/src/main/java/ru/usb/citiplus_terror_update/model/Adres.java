package ru.usb.citiplus_terror_update.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Adres {
    private TipAdresa tipAdresa;
    private String tekstAdresa;
    private Strana strana;
    private String indeks;
    private String okato;
    private String region;
    private String rajon;
    private String gorod;
    private String ulitsa;
    private String dom;
    private String stroenie;
    private String pomeschenie;
}
