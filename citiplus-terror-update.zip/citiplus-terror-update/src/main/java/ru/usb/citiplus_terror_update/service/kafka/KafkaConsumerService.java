package ru.usb.citiplus_terror_update.service.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import ru.usb.citiplus_terror_update.config.LG;
import ru.usb.citiplus_terror_update.model.TerrorListDto;
import ru.usb.citiplus_terror_update.service.TerrorListService;
import ru.usb.citiplus_terror_update.service.db.TerrorInsertService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Kafka consumer сервис для чтения обновлений террористических списков.
 * <p>
 * Реализует три ветки обработки входящих сообщений:
 * <ul>
 *   <li>Ветка 1 — значение содержит субъект с полем {@code fl} (физическое лицо)</li>
 *   <li>Ветка 2 — значение содержит субъект с полем {@code org} (организация)</li>
 *   <li>Ветка 3 — ключ сообщения содержит {@code finish=1} (конец файла)</li>
 * </ul>
 * Сообщения накапливаются в буфере и сбрасываются в БД пакетом при достижении {@code batch.size}
 * или при получении сигнала {@code finish=1}.
 */
@Slf4j
@Service
public class KafkaConsumerService implements ConsumerSeekAware {

    /** Идентификатор Kafka listener, используется для управления через registry. */
    private static final String LISTENER_ID = "terrorListener";

    private final ObjectMapper objectMapper;
    private final TerrorListService terrorListService;
    private final TerrorInsertService terrorInsertService;
    private final KafkaListenerEndpointRegistry registry;
    private final int batchSize;

    /** Буфер накопления DTO перед пакетной вставкой в БД. */
    private final List<TerrorListDto> buffer = new ArrayList<>();

    /** Флаг однократной перемотки offset в начало топика. */
    private final AtomicBoolean rewindRequested = new AtomicBoolean(false);

    public KafkaConsumerService(ObjectMapper objectMapper,
                                TerrorListService terrorListService,
                                TerrorInsertService terrorInsertService,
                                @Lazy KafkaListenerEndpointRegistry registry,
                                @Value("${batch.size}") int batchSize) {
        this.objectMapper = objectMapper;
        this.terrorListService = terrorListService;
        this.terrorInsertService = terrorInsertService;
        this.registry = registry;
        this.batchSize = batchSize;
    }

    /**
     * Вызывается при назначении партиций Kafka данному консьюмеру.
     * Если был запрошен rewind — перематывает offset в начало всех назначенных партиций.
     */
    @Override
    public void onPartitionsAssigned(Map<TopicPartition, Long> assignments, ConsumerSeekCallback callback) {
        if (rewindRequested.compareAndSet(true, false)) {
            callback.seekToBeginning(assignments.keySet());
            log.info("{}: Kafka seekToBeginning выполнен для {} партиций", LG.USBLOGINFO, assignments.size());
        } else {
            log.info("{}: Kafka партиции назначены count=[{}]", LG.USBLOGINFO, assignments.size());
        }
    }

    /**
     * Запрашивает однократную перемотку топика в начало.
     * Устанавливает флаг и перезапускает listener.
     * Фактическая перемотка выполняется в {@link #onPartitionsAssigned} при следующем назначении партиций.
     */
    @SuppressWarnings("java:S1612")
    public void rewindToBeginning() {
        rewindRequested.set(true);
        MessageListenerContainer container = registry.getListenerContainer(LISTENER_ID);
        if (container == null) {
            log.warn("{}: Kafka listener не найден: {}", LG.USBLOGINFO, LISTENER_ID);
            return;
        }
        if (!container.isRunning()) {
            container.start();
        } else {
            container.stop(() -> container.start());
        }
        log.info("{}: Kafka rewind запрошен, consumer перезапускается", LG.USBLOGINFO);
    }

    /**
     * Основной метод обработки входящих сообщений Kafka.
     * <p>
     * Порядок обработки:
     * <ol>
     *   <li>Проверяет ключ на наличие {@code finish=1} → Ветка 3: сброс буфера + вызов процедуры</li>
     *   <li>Парсит значение сообщения в {@link TerrorListDto}</li>
     *   <li>Если субъект содержит {@code fl} → Ветка 1: добавление в буфер</li>
     *   <li>Если субъект содержит {@code org} → Ветка 2: добавление в буфер</li>
     *   <li>При достижении {@code batch.size} выполняет принудительный сброс буфера</li>
     * </ol>
     *
     * @param record Kafka сообщение (ключ и значение в формате JSON)
     * @param ack    объект подтверждения обработки сообщения
     */
    @SuppressWarnings({"java:S1141","java:S6213","java:S3776","java:S6541"})
    @KafkaListener(id = LISTENER_ID, topics = "${terror.file.topic}", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        log.debug("{}: Kafka получено сообщение topic=[{}] partition=[{}] offset=[{}] keySize=[{}] valueSize=[{}]",
                LG.USBLOGINFO, record.topic(), record.partition(), record.offset(),
                record.key() != null ? record.key().length() : 0,
                record.value() != null ? record.value().length() : 0);
        try {
            // Ветка 3: проверяем ключ на finish=1
            if (record.key() != null) {
                log.debug("{}: Kafka парсинг ключа offset=[{}] key=[{}]",
                        LG.USBLOGINFO, record.offset(), record.key());
                try {
                    TerrorListDto key = objectMapper.readValue(record.key(), TerrorListDto.class);
                    log.debug("{}: Kafka ключ распарсен Subject=[{}] finish=[{}] filename=[{}]",
                            LG.USBLOGINFO, key.getSubject(), key.getFinish(), key.getFilename());
                    if (Integer.valueOf(1).equals(key.getFinish())) {
                        log.info("{}: Kafka [Ветка 3] finish=1 filename=[{}], сброс буфера count=[{}]",
                                LG.USBLOGINFO, key.getFilename(), buffer.size());
                        flushBuffer();
                        terrorInsertService.callUploadCompleted();
                        ack.acknowledge();
                        log.debug("{}: Kafka [Ветка 3] сообщение подтверждено offset=[{}]", LG.USBLOGINFO, record.offset());
                        return;
                    }
                } catch (Exception ex) {
                    log.error("{}: Kafka ошибка парсинга ключа offset=[{}] error=[{}]",
                            LG.USBLOGERROR, record.offset(), ex.getMessage());
                }
            }

            log.debug("{}: Kafka парсинг значения offset=[{}]", LG.USBLOGINFO, record.offset());
            TerrorListDto dto = objectMapper.readValue(record.value(), TerrorListDto.class);
            log.debug("{}: Kafka DTO распарсен versiya=[{}] dataPerechnya=[{}] subEktCount=[{}]",
                    LG.USBLOGINFO, dto.getVersiyaFormata(), dto.getDataPerechnya(),
                    dto.getAktualNyjPerechen() != null && dto.getAktualNyjPerechen().getSubEkt() != null
                            ? dto.getAktualNyjPerechen().getSubEkt().size() : 0);
            if (log.isDebugEnabled()) {
                log.debug("{}: Kafka сообщение offset=[{}] value=[{}]",
                        LG.USBLOGINFO, record.offset(), record.value());
                log.debug("{}: Kafka DTO подробно offset=[{}] {}",
                        LG.USBLOGINFO, record.offset(), dto.printDebug());
            }

            terrorListService.fillDates(dto);

            if (dto.getAktualNyjPerechen() != null && dto.getAktualNyjPerechen().getSubEkt() != null) {
                dto.getAktualNyjPerechen().getSubEkt().forEach(s ->
                        log.info("{}: Kafka subEkt idSubEkta=[{}] fl.fio=[{}] org.naimenovanie=[{}]",
                                LG.USBLOGINFO,
                                s.getIdSubEkta(),
                                s.getFl() != null ? s.getFl().getFio() : null,
                                s.getOrg() != null ? s.getOrg().getNaimenovanie() : null)
                );
            }

            boolean hasFl = dto.getAktualNyjPerechen() != null
                    && dto.getAktualNyjPerechen().getSubEkt() != null
                    && dto.getAktualNyjPerechen().getSubEkt().stream().anyMatch(s -> s.getFl() != null);

            boolean hasOrg = dto.getAktualNyjPerechen() != null
                    && dto.getAktualNyjPerechen().getSubEkt() != null
                    && dto.getAktualNyjPerechen().getSubEkt().stream().anyMatch(s -> s.getOrg() != null);

            if (hasFl) {
                // Ветка 1: физические лица
                log.debug("{}: Kafka [Ветка 1] fl добавлено в буфер offset=[{}] buffer=[{}]",
                        LG.USBLOGINFO, record.offset(), buffer.size() + 1);
                buffer.add(dto);
            } else if (hasOrg) {
                // Ветка 2: организации
                log.debug("{}: Kafka [Ветка 2] org добавлено в буфер offset=[{}] buffer=[{}]",
                        LG.USBLOGINFO, record.offset(), buffer.size() + 1);
                buffer.add(dto);
            } else {
                log.debug("{}: Kafka сообщение без fl/org пропущено offset=[{}]", LG.USBLOGINFO, record.offset());
            }

            log.debug("{}: Kafka буфер накоплено=[{}] из batch.size=[{}]", LG.USBLOGINFO, buffer.size(), batchSize);
            if (buffer.size() >= batchSize) {
                log.debug("{}: Kafka буфер достиг batch.size=[{}], запуск сброса", LG.USBLOGINFO, batchSize);
                flushBuffer();
            }

            ack.acknowledge();
            log.debug("{}: Kafka сообщение подтверждено offset=[{}]", LG.USBLOGINFO, record.offset());
        } catch (Exception e) {
            log.error("{}: Kafka ошибка обработки сообщения offset=[{}] error=[{}]",
                    LG.USBLOGERROR, record.offset(), e.getMessage(), e);
            ack.acknowledge();
        }
    }

    /**
     * Сбрасывает накопленный буфер в БД через пакетную вставку.
     * На время вставки приостанавливает Kafka listener во избежание переполнения буфера.
     * После успешной вставки очищает буфер и возобновляет listener.
     */
    private void flushBuffer() {
        if (buffer.isEmpty()) {
            log.debug("{}: flushBuffer буфер пуст, вставка пропущена", LG.USBLOGINFO);
            return;
        }
        log.info("{}: DB начало пакетной вставки записей=[{}]", LG.USBLOGINFO, buffer.size());
        terrorInsertService.insertBatch(new ArrayList<>(buffer));
        buffer.clear();
        log.info("{}: DB пакетная вставка завершена, буфер очищен", LG.USBLOGINFO);
    }
}
