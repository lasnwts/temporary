package ru.usb.citiplus_terror_update;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.citiplus_terror_update.config.LG;

@Slf4j
@SpringBootApplication
public class CitiplusTerrorUpdateApplication implements CommandLineRunner {

	@Value("${server.port}")
	private int port;

	@Value("${server.servlet.contextPath:/}")
	private String contextPath;

	public static void main(String[] args) {
		SpringApplication.run(CitiplusTerrorUpdateApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		String ctx = contextPath.equals("/") ? "" : contextPath;
		log.info("{}:=======================================================-", LG.USBLOGINFO);
		log.info("{}: Сервис    : citiplus-terror-update", LG.USBLOGINFO);
		log.info("{}: Версия    : 0.0.1  Автор: Lyapustin A.S.  Дата: 18.03.2026", LG.USBLOGINFO);
		log.info("{}: Описание  : Чтение обновлений террористических списков из Kafka, запись в Oracle INTEGRATION_TERR", LG.USBLOGINFO);
		log.info("{}:--------------------------------------------------------", LG.USBLOGINFO);
		log.info("{}: Основные функции:", LG.USBLOGINFO);
		log.info("{}: - Ветка 1: обработка субъектов типа физическое лицо (fl)", LG.USBLOGINFO);
		log.info("{}: - Ветка 2: обработка субъектов типа организация (org)", LG.USBLOGINFO);
		log.info("{}: - Ветка 3: обработка сигнала окончания файла (finish=1), сброс буфера + вызов процедуры", LG.USBLOGINFO);
		log.info("{}:--------------------------------------------------------", LG.USBLOGINFO);
		log.info("{}: Web API:", LG.USBLOGINFO);
		log.info("{}: - Swagger  : http://localhost:{}{}/swagger-ui/index.html", LG.USBLOGINFO, port, ctx);
		log.info("{}: - Health   : http://localhost:{}{}/actuator/health", LG.USBLOGINFO, port, ctx);
		log.info("{}: - Log      : http://localhost:{}{}/actuator/logfile", LG.USBLOGINFO, port, ctx);
		log.info("{}: - Kafka    : POST http://localhost:{}{}/api/kafka/start|stop, GET /api/kafka/status", LG.USBLOGINFO, port, ctx);
		log.info("{}: - Search   : GET  http://localhost:{}{}/api/terror/search?number=", LG.USBLOGINFO, port, ctx);
		log.info("{}: - Search   : GET  http://localhost:{}{}/api/terror/search-by-name?nameu=", LG.USBLOGINFO, port, ctx);
		log.info("{}:=======================================================", LG.USBLOGINFO);
		log.info("{}: Modified   : 0.0.3 :Lyapustin A.S. 21.04.2026 | KODCN и KODCR -> VARCHAR(255)", LG.USBLOGINFO);
		log.info("{}: Modified   : 0.0.4 :Lyapustin A.S. 22.04.2026 | KafkaConsumerService - убрано consume - pause.", LG.USBLOGINFO);
		log.info("{}:=======================================================", LG.USBLOGINFO);
	}
}
