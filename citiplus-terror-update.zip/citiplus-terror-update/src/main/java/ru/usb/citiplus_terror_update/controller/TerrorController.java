package ru.usb.citiplus_terror_update.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.citiplus_terror_update.service.db.TerrorSearchService;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/terror")
@Validated
@Tag(name = "Terror DB", description = "Поиск записей в таблице INTEGRATION_TERR")
public class TerrorController {

    private final TerrorSearchService terrorSearchService;

    @Operation(
            summary = "Поиск по NUMBER",
            description = "Возвращает все записи из таблицы INTEGRATION_TERR по значению поля NUMBER (idSubEkta)"
    )
    @GetMapping("/search")
    public ResponseEntity<List<Map<String, Object>>> searchByNumber(
            @Parameter(description = "Значение поля NUMBER (idSubEkta субъекта)", required = true)
            @RequestParam @NotBlank @Size(max = 150) String number) {
        List<Map<String, Object>> result = terrorSearchService.findByNumber(number);
        if (result.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(result);
    }

    @Operation(
            summary = "Поиск по NAMEU",
            description = "Возвращает записи где NAMEU содержит указанную строку (без учёта регистра)"
    )
    @GetMapping("/search-by-name")
    public ResponseEntity<List<Map<String, Object>>> searchByNameu(
            @Parameter(description = "Часть наименования для поиска", required = true)
            @RequestParam @NotBlank @Size(min = 2, max = 255) String nameu) {
        List<Map<String, Object>> result = terrorSearchService.findByNameu(nameu);
        if (result.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(result);
    }
}
