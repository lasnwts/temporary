package ru.usb.citiplus_terror_update.service.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.citiplus_terror_update.model.TerrorListDto;
import ru.usb.citiplus_terror_update.service.TerrorListService;
import ru.usb.citiplus_terror_update.service.db.TerrorInsertService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class KafkaConsumerServiceTest {

    @Mock private TerrorListService terrorListService;
    @Mock private TerrorInsertService terrorInsertService;
    @Mock private KafkaListenerEndpointRegistry registry;
    @Mock private MessageListenerContainer container;
    @Mock private Acknowledgment ack;

    private KafkaConsumerService service;

    private static final String KEY_NORMAL = """
            {"Subject": 1, "filename": "TEST.XML"}
            """;

    private static final String KEY_FINISH = """
            {"Subject": 1, "finish": 1, "filename": "TEST.XML"}
            """;

    private static final String VALUE_FL = """
            {
              "versiyaFormata": "2.1",
              "dataPerechnya": "2022-07-11",
              "dataPredyduschegoPerechnya": "2022-07-03",
              "aktualNyjPerechen": {
                "subEkt": [{
                  "idSubEkta": "22222",
                  "uns": null,
                  "tipSubEkta": { "identifikator": 4, "naimenovanie": "Физическое лицо" },
                  "istoriya": {
                    "dataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya": [
                      { "name": "DataVklyucheniya", "value": "2017-10-07" }
                    ]
                  },
                  "fl": {
                    "fio": "ИВАНОВ ИВАН ИВАНОВИЧ",
                    "familiya": "ИВАНОВ",
                    "imya": "ИВАН",
                    "otchestvo": "ИВАНОВИЧ",
                    "dataRozhdeniya": "1973-11-20",
                    "godRozhdeniya": "1973",
                    "mestoRozhdeniya": "П. МИРНЫЙ АНГАРСКОГО РАЙОНА ИРКУТСКАЯ ОБЛАСТИ",
                    "inn": "2222222222",
                    "snils": "000-000-000 01",
                    "spisokDokumentov": {
                      "dokument": [{
                        "tipDokumenta": { "identifikator": 1631726, "naimenovanie": "ПАСПОРТ РФ" },
                        "seriya": "4444",
                        "nomer": "444444",
                        "organVydachi": "ВЫДАН СВЕРДЛОВСКИМ РОВД Г. ИРКУТСКА",
                        "dataVydachi": "2002-01-25"
                      }]
                    },
                    "spisokDrNaimenovanij": null,
                    "spisokGrazhdanstv": { "grazhdanstvo": ["РОССИЙСКАЯ ФЕДЕРАЦИЯ"] },
                    "fiolat": "IVANOV IVAN IVANOVICH"
                  },
                  "org": null,
                  "spisokAdresov": {
                    "adres": [{
                      "tipAdresa": { "identifikator": 2, "naimenovanie": "Адрес места регистрации" },
                      "tekstAdresa": "ОБЛ ИРКУТСКАЯ, Г ИРКУТСК, УЛ МИРА, Д 1, КВ 1",
                      "strana": { "naimenovanie": "РОССИЙСКАЯ ФЕДЕРАЦИЯ", "kod": "643" }
                    }]
                  },
                  "primechanie": "В РОЗЫСКЕ",
                  "terrorist": true
                }]
              }
            }
            """;

    private static final String VALUE_ORG = """
            {
              "versiyaFormata": "2.1",
              "dataPerechnya": "2022-07-11",
              "dataPredyduschegoPerechnya": "2022-07-03",
              "aktualNyjPerechen": {
                "subEkt": [{
                  "idSubEkta": "111111",
                  "uns": null,
                  "tipSubEkta": { "identifikator": 3, "naimenovanie": "Организация" },
                  "istoriya": {
                    "dataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya": [
                      { "name": "DataVklyucheniya", "value": "2018-08-30" },
                      { "name": "DataIzmeneniya",   "value": "2018-09-15" }
                    ]
                  },
                  "fl": null,
                  "org": {
                    "naimenovanie": "МЕСТНАЯ РЕЛИГИОЗНАЯ ОРГАНИЗАЦИЯ СВИДЕТЕЛЕЙ ИЕГОВЫ В Г. САРАТОВЕ",
                    "naimenovanieLat": "MESTNAIA RELIGIOZNAIA ORGANIZATCIIA SVIDETELEI IEGOVY V G. SARATOVE",
                    "dataRegistratsii": null,
                    "mestoRegistratsii": null,
                    "inn": "1111111111",
                    "ogrn": "2222222222222",
                    "spisokDrNaimenovanij": null
                  },
                  "spisokAdresov": {
                    "adres": [{
                      "tipAdresa": { "identifikator": 2, "naimenovanie": "Адрес места регистрации" },
                      "tekstAdresa": "ОБЛ САРАТОВСКАЯ, Г САРАТОВ, ПРОЕЗД 1-Й, Д 1, КВ 1",
                      "strana": { "naimenovanie": "РОССИЙСКАЯ ФЕДЕРАЦИЯ", "kod": "643" }
                    }]
                  },
                  "primechanie": null,
                  "terrorist": false
                }]
              }
            }
            """;

    @BeforeEach
    void setUp() {
        service = new KafkaConsumerService(
                new ObjectMapper(), terrorListService, terrorInsertService, registry, 10000);
    }

    // -------------------------------------------------------------------------
    // Ветка 1 — fl
    // -------------------------------------------------------------------------

    @Test
    @DisplayName("Ветка 1: сообщение с fl добавляется в буфер, insertBatch не вызывается")
    void branch1_fl_addedToBuffer() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, KEY_NORMAL, VALUE_FL);

        service.consume(record, ack);

        verify(terrorListService).fillDates(any(TerrorListDto.class));
        verify(terrorInsertService, never()).insertBatch(any());
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("Ветка 1: при достижении batch.size выполняется flushBuffer")
    void branch1_fl_flushOnBatchSize() {
        when(registry.getListenerContainer("terrorListener")).thenReturn(container);
        service = new KafkaConsumerService(
                new ObjectMapper(), terrorListService, terrorInsertService, registry, 1);

        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, KEY_NORMAL, VALUE_FL);
        service.consume(record, ack);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<TerrorListDto>> captor = ArgumentCaptor.forClass(List.class);
        verify(terrorInsertService).insertBatch(captor.capture());
        assertEquals(1, captor.getValue().size());
        assertNotNull(captor.getValue().get(0).getAktualNyjPerechen().getSubEkt().get(0).getFl());
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("Ветка 1: маппинг fl — проверка полей subEkt")
    void branch1_fl_fieldsMapping() throws Exception {
        TerrorListDto dto = new ObjectMapper().readValue(VALUE_FL, TerrorListDto.class);
        new TerrorListService().fillDates(dto);

        var subEkt = dto.getAktualNyjPerechen().getSubEkt().get(0);
        assertAll(
                () -> assertEquals("22222", subEkt.getIdSubEkta()),
                () -> assertEquals(4L, subEkt.getTipSubEkta().getIdentifikator()),
                () -> assertTrue(subEkt.isTerrorist()),
                () -> assertEquals("В РОЗЫСКЕ", subEkt.getPrimechanie()),
                () -> assertNotNull(subEkt.getFl()),
                () -> assertNull(subEkt.getOrg()),
                () -> assertEquals("ИВАНОВ ИВАН ИВАНОВИЧ", subEkt.getFl().getFio()),
                () -> assertEquals("IVANOV IVAN IVANOVICH", subEkt.getFl().getFioLat()),
                () -> assertEquals("2222222222", subEkt.getFl().getInn()),
                () -> assertEquals("000-000-000 01", subEkt.getFl().getSnils()),
                () -> assertEquals(1631726L, subEkt.getFl().getSpisokDokumentov()
                        .getDokument().get(0).getTipDokumenta().getIdentifikator()),
                () -> assertEquals("РОССИЙСКАЯ ФЕДЕРАЦИЯ", subEkt.getFl()
                        .getSpisokGrazhdanstv().getGrazhdanstvo().get(0))
        );
    }

    // -------------------------------------------------------------------------
    // Ветка 2 — org
    // -------------------------------------------------------------------------

    @Test
    @DisplayName("Ветка 2: сообщение с org добавляется в буфер, insertBatch не вызывается")
    void branch2_org_addedToBuffer() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 1L, KEY_NORMAL, VALUE_ORG);

        service.consume(record, ack);

        verify(terrorListService).fillDates(any(TerrorListDto.class));
        verify(terrorInsertService, never()).insertBatch(any());
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("Ветка 2: маппинг org — проверка полей subEkt")
    void branch2_org_fieldsMapping() throws Exception {
        TerrorListDto dto = new ObjectMapper().readValue(VALUE_ORG, TerrorListDto.class);
        new TerrorListService().fillDates(dto);

        var subEkt = dto.getAktualNyjPerechen().getSubEkt().get(0);
        assertAll(
                () -> assertEquals("111111", subEkt.getIdSubEkta()),
                () -> assertEquals(3L, subEkt.getTipSubEkta().getIdentifikator()),
                () -> assertFalse(subEkt.isTerrorist()),
                () -> assertNull(subEkt.getFl()),
                () -> assertNotNull(subEkt.getOrg()),
                () -> assertEquals("МЕСТНАЯ РЕЛИГИОЗНАЯ ОРГАНИЗАЦИЯ СВИДЕТЕЛЕЙ ИЕГОВЫ В Г. САРАТОВЕ",
                        subEkt.getOrg().getNaimenovanie()),
                () -> assertEquals("MESTNAIA RELIGIOZNAIA ORGANIZATCIIA SVIDETELEI IEGOVY V G. SARATOVE",
                        subEkt.getOrg().getNaimenovanieLat()),
                () -> assertEquals("1111111111", subEkt.getOrg().getInn()),
                () -> assertEquals("2222222222222", subEkt.getOrg().getOgrn())
        );
    }

    // -------------------------------------------------------------------------
    // Ветка 3 — finish=1
    // -------------------------------------------------------------------------

    @Test
    @DisplayName("Ветка 3: finish=1 вызывает flushBuffer и callUploadCompleted")
    void branch3_finish_flushAndProcedure() {
        when(registry.getListenerContainer("terrorListener")).thenReturn(container);
        ConsumerRecord<String, String> recordFl = new ConsumerRecord<>("topic", 0, 0L, KEY_NORMAL, VALUE_FL);
        service.consume(recordFl, ack);

        ConsumerRecord<String, String> recordFinish = new ConsumerRecord<>("topic", 0, 1L, KEY_FINISH, VALUE_FL);
        service.consume(recordFinish, ack);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<TerrorListDto>> captor = ArgumentCaptor.forClass(List.class);
        verify(terrorInsertService).insertBatch(captor.capture());
        assertEquals(1, captor.getValue().size());
        verify(terrorInsertService).callUploadCompleted();
        verify(ack, times(2)).acknowledge();
    }

    @Test
    @DisplayName("Ветка 3: finish=1 с пустым буфером — insertBatch не вызывается, callUploadCompleted вызывается")
    void branch3_finish_emptyBuffer() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, KEY_FINISH, VALUE_FL);
        service.consume(record, ack);

        verify(terrorInsertService, never()).insertBatch(any());
        verify(terrorInsertService).callUploadCompleted();
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("Сообщение без fl и org — пропускается, буфер не заполняется")
    void branch_noFlNoOrg_skipped() {
        String valueEmpty = """
                {
                  "versiyaFormata": "2.1",
                  "aktualNyjPerechen": {
                    "subEkt": [{
                      "idSubEkta": "99999",
                      "tipSubEkta": { "identifikator": 1, "naimenovanie": "Тест" },
                      "istoriya": null,
                      "fl": null,
                      "org": null,
                      "spisokAdresov": null,
                      "primechanie": null,
                      "terrorist": false
                    }]
                  }
                }
                """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, KEY_NORMAL, valueEmpty);
        service.consume(record, ack);

        verify(terrorInsertService, never()).insertBatch(any());
        verify(ack).acknowledge();
    }
}
