package ru.usb.citiplus_terror_update;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiplusTerrorUpdateApplicationTests {

    @Test
    void contextLoads() {
    }
}
