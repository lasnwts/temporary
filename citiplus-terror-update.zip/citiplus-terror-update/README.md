# citiplus-terror-update

Сервис читает обновления террористических списков из Apache Kafka и записывает данные в таблицу Oracle `TMP_TERROR_INFO`.

## Стек технологий

| Компонент | Версия |
|---|---|
| Java | 17 |
| Spring Boot | 3.4.8 |
| Spring Kafka | — |
| Spring JDBC | — |
| Oracle JDBC (ojdbc11) | 23.5.0.24.07 |
| Lombok | — |

---

## Конфигурация (application.properties)

| Свойство | Описание |
|---|---|
| `terror.file.topic` | Топик Kafka с сообщениями |
| `batch.size` | Размер буфера перед пакетной вставкой в БД |
| `terror.db.table` | Имя таблицы Oracle для вставки |
| `spring.kafka.consumer.group-id` | Группа консьюмера Kafka |
| `datasource.jdbc-url` | JDBC URL подключения к Oracle |

---

## Структура сообщений Kafka

Каждое сообщение Kafka состоит из **ключа** и **значения**, оба в формате JSON.

### Ключ сообщения

```json
{
  "Subject": 4,
  "finish": 1,
  "filename": "ПРИМЕР XML 2.1 COR.XML"
}
```

| Поле JSON | Поле DTO | Тип | Описание |
|---|---|---|---|
| `Subject` | `subject` | Integer | Идентификатор субъекта |
| `finish` | `finish` | Integer | Необязательное. `1` — конец файла |
| `filename` | `filename` | String | Имя исходного файла |

### Значение сообщения — маппинг на TerrorListDto

| Поле JSON | Поле DTO | Тип |
|---|---|---|
| `versiyaFormata` | `versiyaFormata` | String |
| `dataPerechnya` | `dataPerechnya` | String |
| `dataPredyduschegoPerechnya` | `dataPredyduschegoPerechnya` | String |
| `aktualNyjPerechen.subEkt` | `aktualNyjPerechen.subEkt` | List\<SubEkt\> |
| `subEkt.idSubEkta` | `idSubEkta` | String |
| `subEkt.tipSubEkta.identifikator` | `tipSubEkta.identifikator` | long |
| `subEkt.tipSubEkta.naimenovanie` | `tipSubEkta.naimenovanie` | String |
| `subEkt.istoriya.dataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya` | `istoriya.dataVklyucheniyaOrDataIsklyucheniyaOrDataIzmeneniya` | List\<HistoryEvent\> |
| `subEkt.terrorist` | `terrorist` | boolean |
| `subEkt.primechanie` | `primechanie` | String |
| `subEkt.dataVklyucheniya` | `dataVklyucheniya` | LocalDate (заполняется из istoriya) |
| `subEkt.dataIsklyucheniya` | `dataIsklyucheniya` | LocalDate (заполняется из istoriya) |
| `subEkt.fl.fio` | `fl.fio` | String |
| `subEkt.fl.fiolat` | `fl.fioLat` | String (`@JsonProperty("fiolat")`) |
| `subEkt.fl.dataRozhdeniya` | `fl.dataRozhdeniya` | String |
| `subEkt.fl.godRozhdeniya` | `fl.godRozhdeniya` | String |
| `subEkt.fl.mestoRozhdeniya` | `fl.mestoRozhdeniya` | String |
| `subEkt.fl.inn` | `fl.inn` | String |
| `subEkt.fl.snils` | `fl.snils` | String |
| `subEkt.fl.spisokDokumentov.dokument` | `fl.spisokDokumentov.dokument` | List\<Dokument\> |
| `subEkt.fl.spisokDrNaimenovanij.drNaimenovanie` | `fl.spisokDrNaimenovanij.drNaimenovanie` | List\<DrNaimenovanie\> |
| `subEkt.fl.spisokGrazhdanstv.grazhdanstvo` | `fl.spisokGrazhdanstv.grazhdanstvo` | List\<String\> |
| `subEkt.org.naimenovanie` | `org.naimenovanie` | String |
| `subEkt.org.naimenovanieLat` | `org.naimenovanieLat` | String |
| `subEkt.org.dataRegistratsii` | `org.dataRegistratsii` | String |
| `subEkt.org.mestoRegistratsii` | `org.mestoRegistratsii` | String |
| `subEkt.org.inn` | `org.inn` | String |
| `subEkt.org.ogrn` | `org.ogrn` | String |
| `subEkt.spisokAdresov.adres` | `spisokAdresov.adres` | List\<Adres\> |
| `adres.tipAdresa.identifikator` | `tipAdresa.identifikator` | long |
| `adres.tekstAdresa` | `tekstAdresa` | String |
| `adres.strana.kod` | `strana.kod` | String |

---

## Три ветки обработки

### Ветка 1 — Физическое лицо (fl)

Срабатывает когда в `aktualNyjPerechen.subEkt` хотя бы один элемент содержит поле `fl`.  
Сообщение добавляется в буфер. При достижении `batch.size` буфер сбрасывается в БД.

### Ветка 2 — Организация (org)

Срабатывает когда в `aktualNyjPerechen.subEkt` хотя бы один элемент содержит поле `org` (и нет `fl`).  
Сообщение добавляется в буфер. При достижении `batch.size` буфер сбрасывается в БД.

### Ветка 3 — Конец файла (finish=1)

Срабатывает когда в **ключе** сообщения присутствует поле `finish=1`.  
Выполняется в следующем порядке:
1. Принудительный сброс буфера в БД (`flushBuffer`)
2. UPDATE таблицы: `INTEGRATION_STATUS = 1`
3. Подтверждение сообщения Kafka (`ack.acknowledge`)

---

## Структура таблицы TMP_TERROR_INFO

```sql
CREATE TABLE TMP_TERROR_INFO (
  number             INTEGER,
  tu                 INTEGER,
  cb_date            DATE,
  ce_date            DATE,
  nameu              NVARCHAR2(4000),
  gr                 DATE,
  yr                 INTEGER,
  mr                 NVARCHAR2(255),
  nd                 NVARCHAR2(30),
  descript           NVARCHAR2(255),
  kd                 NVARCHAR2(2),
  vd                 NVARCHAR2(512),
  sd                 NVARCHAR2(50),
  rg                 NVARCHAR2(50),
  kodcn              INTEGER,
  kodcr              INTEGER,
  amr                NVARCHAR2(255),
  adress             NVARCHAR2(255),
  terrtype           NVARCHAR2(50),
  terror             INTEGER,
  integration_status INTEGER,
  director           NVARCHAR2(255),
  founder            NVARCHAR2(255),
  row_id             INTEGER,
  updated            DATE default sysdate
)
```

---

## Маппинг полей — Физическое лицо (fl)

Для каждого `subEkt` с `fl` формируется одна или несколько строк в таблице.  
Строки перемножаются по: **гражданства × документы**.  
Для каждого элемента `drNaimenovanie` создаются отдельные строки.

| Поле таблицы | Тип | Источник JSON | Логика |
|---|---|---|---|
| `number` | INTEGER | `subEkt.idSubEkta` | toLong() |
| `tu` | INTEGER | `subEkt.tipSubEkta.identifikator` | 1→1, 2→3, 3→1, 4→3 |
| `cb_date` | DATE | `subEkt.dataVklyucheniya`, `istoriya.dataIzmeneniya` | Максимум из двух |
| `ce_date` | DATE | `subEkt.dataIsklyucheniya` | |
| `nameu` | NVARCHAR2(4000) | `fl.fio` ; `fl.fiolat` | Объединение через `;`, только непустые |
| `gr` | DATE | `fl.dataRozhdeniya` / `drNaimenovanie.dataRozhdeniya` | |
| `yr` | INTEGER | `fl.godRozhdeniya` / `drNaimenovanie.godRozhdeniya` | toInteger() |
| `mr` | NVARCHAR2(255) | `fl.mestoRozhdeniya` | |
| `nd` | NVARCHAR2(30) | `fl.inn` / `drNaimenovanie.inn` | |
| `descript` | NVARCHAR2(255) | `fl.snils` / `drNaimenovanie.snils` | |
| `kd` | NVARCHAR2(2) | `dokument.tipDokumenta.identifikator` | По таблице маппинга KD |
| `vd` | NVARCHAR2(512) | `tipDokumenta.naimenovanie` + `organVydachi` + `dataVydachi` | Через пробел |
| `sd` | NVARCHAR2(50) | `dokument.seriya` | |
| `rg` | NVARCHAR2(50) | `dokument.nomer` | |
| `kodcn` | INTEGER | — | TODO: уточнить источник |
| `kodcr` | INTEGER | `adres.strana.kod` | `tipAdresa.identifikator = 1`, toInteger() |
| `amr` | NVARCHAR2(255) | `adres.tekstAdresa` | `tipAdresa.identifikator = 2` |
| `adress` | NVARCHAR2(255) | `adres.tekstAdresa` | `tipAdresa.identifikator != 2` |
| `terrtype` | NVARCHAR2(50) | `subEkt.primechanie` | |
| `terror` | INTEGER | `subEkt.terrorist` | `true` → `1`, `false` → `0` |
| `integration_status` | INTEGER | — | При вставке всегда `0`. При `finish=1` → UPDATE всей таблицы в `1` |

---

## Маппинг полей — Организация (org)

Если заполнены оба `naimenovanie` и `naimenovanieLat` — создаются **две записи**, иначе одна.

| Поле таблицы | Тип | Источник JSON | Логика |
|---|---|---|---|
| `number` | INTEGER | `subEkt.idSubEkta` | toLong() |
| `tu` | INTEGER | `subEkt.tipSubEkta.identifikator` | 1→1, 2→3, 3→1, 4→3 |
| `cb_date` | DATE | `subEkt.dataVklyucheniya`, `istoriya.dataIzmeneniya` | Максимум из двух |
| `ce_date` | DATE | `subEkt.dataIsklyucheniya` | |
| `nameu` | NVARCHAR2(4000) | `org.naimenovanie` / `org.naimenovanieLat` | Отдельная запись на каждое |
| `gr` | DATE | `org.dataRegistratsii` | |
| `mr` | NVARCHAR2(255) | `org.mestoRegistratsii` | |
| `nd` | NVARCHAR2(30) | `org.inn` | |
| `rg` | NVARCHAR2(50) | `org.ogrn` | |
| `kodcn` | INTEGER | `adres.strana.kod` | `tipAdresa.identifikator = 5`, toInteger() |
| `kodcr` | INTEGER | `adres.strana.kod` | `tipAdresa.identifikator = 2`, toInteger() |
| `amr` | NVARCHAR2(255) | `adres.tekstAdresa` | `tipAdresa.identifikator = 2` |
| `adress` | NVARCHAR2(255) | `adres.tekstAdresa` | `tipAdresa.identifikator != 2` |
| `terrtype` | NVARCHAR2(50) | `subEkt.primechanie` | |
| `terror` | INTEGER | `subEkt.terrorist` | `true` → `1`, `false` → `0` |
| `integration_status` | INTEGER | — | При вставке всегда `0`. При `finish=1` → UPDATE всей таблицы в `1` |

Поля `yr`, `descript`, `kd`, `vd`, `sd` для организаций не заполняются (`null`).

---

## Маппинг кода документа (KD)

| `tipDokumenta.identifikator` | `KD` |
|---|---|
| 1631718 | 02 |
| 1631725 | 02 |
| 1631726 | 01 |
| 1631727 | 02 |
| 14382683 | 04 |
| 74199428 | 02 |
| 74199429 | 02 |
| 74199431 | 02 |
| 74984730 | 02 |
| 746085885 | 03 |
| 746085996 | 03 |
| 746140005 | 03 |
| 1215068989 | 02 |
| 1215068990 | 02 |
| 1215068992 | 04 |
| иное значение | не передаётся (null) |

---

## Маппинг типа субъекта (TU)

| `tipSubEkta.identifikator` | `TU` |
|---|---|
| 1 | 1 |
| 2 | 3 |
| 3 | 1 |
| 4 | 3 |

---

## Сборка и запуск

```bash
mvn clean package
java -jar target/citiplus-terror-update-0.0.1.jar
```

Сервис доступен на порту `8080`.  
Swagger UI: `http://localhost:8080/swagger-ui/index.html`  
Actuator: `http://localhost:8080/actuator/health`

---

## Web API

### Kafka — управление чтением сообщений

Base URL: `/api/kafka`

| Метод | URL | Описание | Ответ |
|---|---|---|---|
| `POST` | `/api/kafka/start` | Запускает Kafka listener | `200 OK` |
| `POST` | `/api/kafka/stop` | Останавливает Kafka listener | `200 OK` |
| `GET` | `/api/kafka/status` | Текущий статус listener | `200 OK` |
| `POST` | `/api/kafka/rewind` | Перечитать топик с начала (однократно) | `200 OK` |

Пример ответа:
```
Listener [terrorListener] запущен
```

---

### Terror DB — поиск в таблице TMP_TERROR_INFO

Base URL: `/api/terror`

| Метод | URL | Описание | Ответ |
|---|---|---|---|
| `GET` | `/api/terror/search?number={number}` | Поиск по точному значению `number` | `200 OK` — список, `204` — не найдено |
| `GET` | `/api/terror/search-by-name?nameu={nameu}` | Поиск по части `nameu` без учёта регистра | `200 OK` — список, `204` — не найдено |

#### Параметры

| Параметр | Тип | Ограничения | Описание |
|---|---|---|---|
| `number` | string | max 150 | Точное значение `idSubEkta` субъекта |
| `nameu` | string | min 2, max 255 | Часть наименования (`%значение%`) |

---

### Logging — управление уровнем логирования

Base URL: `/api/log`

| Метод | URL | Описание | Ответ |
|---|---|---|---|
| `POST` | `/api/log/level?level=DEBUG` | Установить уровень для пакета сервиса | `200 OK` |
| `POST` | `/api/log/level?level=DEBUG&logger=ru.usb...` | Установить уровень для конкретного пакета/класса | `200 OK` |
| `GET` | `/api/log/level` | Текущий уровень пакета сервиса | `200 OK` |
| `GET` | `/api/log/levels` | Уровни всех логгеров с явно установленным уровнем | `200 OK` |

Допустимые уровни: `TRACE`, `DEBUG`, `INFO`, `WARN`, `ERROR`

Пример:
```
POST /api/log/level?level=DEBUG
→ Logger [ru.usb.citiplus_terror_update] уровень изменён: INFO -> DEBUG
```

---

### Ссылки

| Ресурс | URL |
|---|---|
| Swagger UI | `http://localhost:8080/swagger-ui/index.html` |
| Actuator Health | `http://localhost:8080/actuator/health` |
| Actuator Log | `http://localhost:8080/actuator/logfile` |
