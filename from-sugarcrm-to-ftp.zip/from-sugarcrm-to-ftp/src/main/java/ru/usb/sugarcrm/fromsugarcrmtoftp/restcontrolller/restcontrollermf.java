package ru.usb.sugarcrm.fromsugarcrmtoftp.restcontrolller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.Error;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.FileRequest;
import ru.usb.sugarcrm.fromsugarcrmtoftp.model.FileResponse;
import ru.usb.sugarcrm.fromsugarcrmtoftp.service.FileService;

import static org.springframework.http.ResponseEntity.status;

@RestController
@RequestMapping("/api/v1")
@ApiOperation(value = "Rest controller", notes = "Контроллер для передачи файла из SugarCRM на FTP сервер")
public class restcontrollermf  {

    Logger logger = LoggerFactory.getLogger(restcontrollermf.class);
    private final FileService fileService;

    @Autowired
    public restcontrollermf(FileService fileService) {
        this.fileService = fileService;
    }

    @PostMapping(path = "/file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
/*    @ApiOperation(value = "Передача файла для FTP сервера",
            notes = "Запись будет добавлена",
            response = FileResponse.class)*/
    public ResponseEntity<FileResponse> FileToFtp(
        @ApiParam(name = "fileName", value = "Имя файла", defaultValue = "")
        @RequestParam(value = "fileName", required = false, defaultValue = "") String filename,
        @RequestParam(value = "fileContent", required = false) MultipartFile file) {
        ResponseEntity<FileResponse> result;
        try {
                FileRequest fileRequest = new FileRequest(filename, file);
            result = ResponseEntity.ok(fileService.saveAndRename(fileRequest));
        } catch (Exception ex) {
                if (ex.getMessage().contains("exceeds")) {
                    logger.error("Превышен максимальный размер файла.");
                } else {
                    logger.error(ex.getMessage());
                }
                logger.error("=======================================================");
                FileResponse fileResponse = new FileResponse();
                fileResponse.setFileName(filename);
                fileResponse.setStatus("not delivered");
                Error error = new Error();
                error.setErrorCode(1);
                error.setErrorText(ex.getMessage());
                fileResponse.setError(error);
            result = status(HttpStatus.EXPECTATION_FAILED).body(fileResponse);
        }

        return result;
    }
}
