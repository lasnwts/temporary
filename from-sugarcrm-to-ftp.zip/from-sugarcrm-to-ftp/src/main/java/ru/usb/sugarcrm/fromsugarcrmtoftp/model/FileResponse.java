package ru.usb.sugarcrm.fromsugarcrmtoftp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Ответ сервиса при передаче файла на FTP сервер")
public class FileResponse {

    @ApiModelProperty(notes = "Имя файла")
    private String fileName;

    @ApiModelProperty(notes = "Статус передачи файла.\n в случае успешной доставки:delivered.\n В случае неуспешной доставки:not delivered")
    private String status;

    @ApiModelProperty(notes = "Строковое представление ошибки")
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Error error;

//    @ApiModelProperty(notes = "Строковое представление ошибки")
//    private String error;
//
//    @ApiModelProperty(notes = "Код ошибки. Поле возвращается, только в случае ошибочной доставки.\n Код в таком случае равен 1.")
//    private String errorCode;
//
//    @ApiModelProperty(notes = "Текст ошибки")
//    private String errorText;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "FileResponse{" +
                "fileName='" + fileName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }


}
