package ru.usb.sugarcrm.fromsugarcrmtoftp;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.sugarcrm.fromsugarcrmtoftp.configs.ConfigureFTP;
import ru.usb.sugarcrm.fromsugarcrmtoftp.restcontrolller.restcontrollermf;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class FromSugarcrmToFtpApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(FromSugarcrmToFtpApplication.class);

    @Autowired
    ConfigureFTP configureFTP;

    public static void main(String[] args) {
        SpringApplication.run(FromSugarcrmToFtpApplication.class, args);
    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb.sugarcrm"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Alexander Lyapustin, Vsevolod Mishev", "../", "LyapustinAS@spb.uralsib.ru;MishevVD@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Spring boot 2 Api Title 16/09/2021")
                .description("Api Definition by @alexander")
                .version("0.0.1")
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }


    @Override
    public void run(String... args) throws Exception {
        logger.info(configureFTP.toString());
    }
}
