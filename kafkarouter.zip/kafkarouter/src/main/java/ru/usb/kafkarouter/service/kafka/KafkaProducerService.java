package ru.usb.kafkarouter.service.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import ru.usb.kafkarouter.config.LG;

/**
 * Класс отправки сообщений Кафка
 * https://kafka.apache.org/21/documentation.html#producerconfigs
 */
@Slf4j
@Service
public class KafkaProducerService {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     *  Простой вариант отправки сообщений, без проверки
     * @param topic - топик
     * @param msg - сообщение
     */
    public void sendMessage(String topic, String msg, long threadNum) {
        log.debug("{}: T{}: Отправляю в топик:{} - сообщение:{}", LG.UsbLogInfo, threadNum, topic, msg);
        kafkaTemplate.send(topic, msg);
    }

    /**
     * Вариант отправки сообщений, с ключом, и количеством попыток отправки
     * @param topic - топик
     * @param key - ключ сообщения
     * @param value - сообщение
     * @param retryTimes - количество попыток отправки
     */
    public void sendMessage(String topic, String key, String value, Integer retryTimes) {
        try {
            kafkaTemplate.send(topic, key, value);
        } catch (Exception e) {
            //if retryTimes
            if (retryTimes < 3) {
                sendMessage(topic, key, value, ++retryTimes);
            }
        }
    }

    /**
     * Отправка сообщения в другой топик
     * @param topic - имя топика куда отправляем
     * @param value - сообщение
     * @param retryTimes - количество попыток отправки
     * @return
     */
    public boolean sendMessage2(String topic, String value, Integer retryTimes, long threadNum) {
        log.debug("{}: T{}: Отправляю в топик:{} - сообщение:{}", LG.UsbLogInfo, threadNum, topic, value);
        try {
            kafkaTemplate.send(topic, value);
            return true;
        } catch (Exception e) {
            //if retryTimes
            if (retryTimes < 3) {
                sendMessage2(topic, value, ++retryTimes, threadNum);
            } else {
                return false;
            }
        }
        return false;
    }

}
