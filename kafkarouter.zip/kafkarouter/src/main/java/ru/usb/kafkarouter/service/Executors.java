package ru.usb.kafkarouter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.kafkarouter.config.Configure;
import ru.usb.kafkarouter.config.LG;
import ru.usb.kafkarouter.dto.MessageFromKafka;
import ru.usb.kafkarouter.service.kafka.KafkaProducerService;
import ru.usb.kafkarouter.service.mail.ServiceMailError;
import ru.usb.kafkarouter.utils.MapperEvents;
import ru.usb.kafkarouter.utils.RouteFinder;

import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

@Slf4j
@Service
public class Executors {

    private static ExecutorService executorService;

    ObjectMapper objectMapper = new ObjectMapper();

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    @Value("${kafka.mapper.topic:siebel-kafka-router.in.mapper}")
    private String kafkaMapperTopic;

    private final Configure configure;
    private final KafkaProducerService kafkaProducerService;
    private final ServiceMailError serviceMailError;
    private final MapperEvents mapperEvents;
    private final RouteFinder routeFinder;

    @Autowired
    public Executors(Configure configure, KafkaProducerService kafkaProducerService, ServiceMailError serviceMailError, MapperEvents mapperEvents, RouteFinder routeFinder) {
        this.configure = configure;
        this.kafkaProducerService = kafkaProducerService;
        this.serviceMailError = serviceMailError;
        this.mapperEvents = mapperEvents;
        this.routeFinder = routeFinder;
    }

    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String messageBody) {
        log.info("{}:Запуск getTask потока, с сообщением:{}", LG.UsbLogInfo, messageBody);
        log.info("{}:Длина очереди задач:{}", LG.UsbLogInfo, configure.addThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody));
        } catch (Exception e) {
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.UsbLogError);
            log.error("{}:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", LG.UsbLogError, e);
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", LG.UsbLogError);
        }
        log.info("{}:Поток передан на запуск в executor service. Поток с сообщением:{}", LG.UsbLogInfo, messageBody);
    }


    class MyThread implements Runnable {
        String recordValue;
        CountDownLatch latch;


        MyThread(CountDownLatch c, String messageBody) {
            latch = c;
            recordValue = messageBody;
            new Thread(this);
        }

        /***************************************************************
         * Основной процесс
         ***************************************************************/
        public void run() {
            log.info("{}:Запуск потока id={}", LG.UsbLogInfo, Thread.currentThread().getId());
            //1 Проверяем, что событие парсится в документ событий
            Optional<MessageFromKafka> messageFromKafka = mapperEvents.getMessage(recordValue);
            if (messageFromKafka.isPresent()) {
                log.info("{}:T{} Получено сообщение для обработки:{}", LG.UsbLogInfo, Thread.currentThread().getId(), messageFromKafka);
                if (messageFromKafka.get().getPack() == null || messageFromKafka.get().getPackID() == null) {
                    log.error("{}:T{} Получено сообщение, которое не удалось распарсить сообщение удалено:{}", LG.UsbLogInfo, Thread.currentThread().getId(), recordValue);
                } else {
                    // DTO для передачи в другой топик
                    log.info("{}:T{} Сообщение для маршрутизации:{}", LG.UsbLogInfo, Thread.currentThread().getId(), messageFromKafka.get());
                    // Проверяем, есь маппер?
                    if (messageFromKafka.get().getMapper() != null && !messageFromKafka.get().getMapper().trim().isEmpty() && !messageFromKafka.get().getMapper().trim().equalsIgnoreCase("null")) {
                        // Если маппер требуется, т.е. поле mapper содержит ЛЮБОЙ символ, отправляем в очередь сервису Mapper
                        log.info("{}:T{} Сообщение отправлено в маппер, в Топик::{}  сообщение:{}", LG.UsbLogInfo, Thread.currentThread().getId(), kafkaMapperTopic, recordValue);
                        kafkaProducerService.sendMessage(kafkaMapperTopic, recordValue, Thread.currentThread().getId());
                    } else { //here
                        processing(messageFromKafka.get(), recordValue);
                    }
                }
            } else {
                log.error("{}:T{} Error: Сообщение не распарсилось в объект событий:MessageFromKafka, поэтому его просто игнорируем. Сообщение с кафка:{}", LG.UsbLogError,
                        Thread.currentThread().getId(), recordValue);
            }

            //Подвал завершения потока
            log.info("{}:Поток завершен id={}", LG.UsbLogInfo, Thread.currentThread().getId());
            log.info("{}:T{}:done:Длина очереди задач={}", LG.UsbLogInfo, Thread.currentThread().getId(), configure.decThreads());
            configure.incSummaryDone(); //+1 в число обработанных задач
        }

        /**
         * Под процесс
         *
         * @param message       - сообщение в виде POJO
         * @param bodyFromKafka - строковое сообщение (body) из kafka
         */
        private void processing(MessageFromKafka message, String bodyFromKafka) {
            //смотрим кому отправить сообщение
            Optional<String[]> routeFind = routeFinder.getRoute(message, Thread.currentThread().getId());
            routeFind.ifPresent(s -> log.debug("{}: T{} routeFind:{}", LG.UsbLogInfo, Thread.currentThread().getId(), s[0]));
            //Проверяем, что маршрут найден
            if (routeFind.isEmpty() || routeFind.get()[0] ==null) {
                //Раз не найден. то ищем маршрут куда отправить ошибку, по одному параметру
                Optional<String> routeError = routeFinder.getRouteError(message, Thread.currentThread().getId());
                routeError.ifPresent(s -> log.debug("{}: T{} routeError:{}", LG.UsbLogInfo, Thread.currentThread().getId(), s));
                log.error("{}:T{} Не найден маршрут для system_to:{} сообщение:{}", LG.UsbLogInfo, Thread.currentThread().getId(), message.getSystemTo(), bodyFromKafka);
                serviceMailError.sendMailError("Не найден маршрут для (No route found for) system_to:" + message.getSystemTo() + " сообщение(message):" + bodyFromKafka);
                message.setError("Router:404");
                message.setErrortext("Не найден маршрут для (No route found for) system_to:" + message.getSystemTo());
                sendErrorMessage(routeError, message);
            } else {
                log.debug("{}:T{} Топик::{}, сообщение:{}", LG.UsbLogInfo, Thread.currentThread().getId(), routeFind.get()[0], bodyFromKafka);
                if (kafkaProducerService.sendMessage2(routeFind.get()[0], bodyFromKafka, 0,Thread.currentThread().getId())) {
                    log.info("{}:T{} Маршрутизация прошла успешно, сообщение отправлено в Топик::{},  сообщение:{}", LG.UsbLogInfo, Thread.currentThread().getId(), routeFind.get()[0], bodyFromKafka);
                } else {
                    log.info("{}:T{} Ошибка отправки сообщения, Топик::{},  сообщение не отправлено:{}", LG.UsbLogInfo, Thread.currentThread().getId(), routeFind.get(), bodyFromKafka);
                    message.setError("Router:500");
                    message.setErrortext("Сообщение не было отправлено, произошла ошибка. Отправьте сообщение еще раз.The message was not sent, an error occurred. Send the message again.");
                    sendErrorMessage(Optional.ofNullable(routeFind.get()[1]), message);
                    serviceMailError.sendMailError("Ошибка отправки сообщения, Топик::" + routeFind.get()[0] + " сообщение не отправлено:" + bodyFromKafka);
                }
            }//here
        }


        /**
         * Обертка над значением null в строке
         *
         * @param line - переданная строка
         * @return - строка после проверки на NULL.
         */
        public String getWrapNull(String line) {
            if (line == null) {
                return "";
            } else {
                return line.trim();
            }
        }

        /**
         * Отправка сообщения в систему источник
         *
         * @param routeError - маршрут куда отправить
         * @param message    - сообщение
         */
        private void sendErrorMessage(Optional<String> routeError, MessageFromKafka message) {
            if (routeError.isPresent()) {
                try {
                    kafkaProducerService.sendMessage(routeError.get(), objectMapper.writeValueAsString(message), Thread.currentThread().getId());
                } catch (JsonProcessingException e) {
                    log.error("{}:T{} Ошибка отправки в топик [topicsystemfromerror] сообщения:{}", LG.UsbLogError, Thread.currentThread().getId(), message);
                    log.error("{}:T{} Ошибка преобразования объекта в Json: {}", LG.UsbLogError, Thread.currentThread().getId(), e.getMessage());
                    log.debug("{}:T{} Ошибка преобразования объекта в Json", LG.UsbLogError, Thread.currentThread().getId(), e);
                    serviceMailError.sendMailError("Ошибка отправки в топик [topicsystemfromerror] сообщения:" + message + "   " +
                            "\r\n Ошибка преобразования объекта в Json" + e.getMessage());
                }
            } else {
                log.error("{}:T{} Ошибка поиска очереди [topicsystemfromerror] для сообщения:{}", LG.UsbLogError, Thread.currentThread().getId(), message);
                serviceMailError.sendMailError("Ошибка поиска очереди [topicsystemfromerror] для сообщения " + message);
            }
        }

    }

}





