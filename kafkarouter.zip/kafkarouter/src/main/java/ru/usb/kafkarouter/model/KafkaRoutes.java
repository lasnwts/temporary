package ru.usb.kafkarouter.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "routes")
public class KafkaRoutes {

    private List<ru.usb.kafkarouter.model.topiclist>   topiclist = new ArrayList<>();

    public KafkaRoutes() {
    }

    public List<ru.usb.kafkarouter.model.topiclist> getTopiclist() {
        return topiclist;
    }

    public void setTopiclist(List<ru.usb.kafkarouter.model.topiclist> topiclist) {
        this.topiclist = topiclist;
    }
}
