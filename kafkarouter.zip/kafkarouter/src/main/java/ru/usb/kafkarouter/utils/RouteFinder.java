package ru.usb.kafkarouter.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.kafkarouter.config.LG;
import ru.usb.kafkarouter.dto.MessageFromKafka;
import ru.usb.kafkarouter.model.KafkaRoutes;

import java.util.Optional;

/**
 * Класс поиска маршрута для сообщения
 * Используется класс KafkaRoutes для сопоставления маршрута
 */
@Component
public class RouteFinder {

    Logger logger = LoggerFactory.getLogger(RouteFinder.class);

    private final KafkaRoutes kafkaRoutes;

    @Autowired
    public RouteFinder(KafkaRoutes kafkaRoutes) {
        this.kafkaRoutes = kafkaRoutes;
    }

    /**
     * Метод поиска маршрута по тэгам system_to
     *
     * @param message - сообщение от Кафка в универсальном формате
     * @return - строка с именем топика
     */
    public Optional<String[]> getRoute(MessageFromKafka message, long threadNumber) {
        final String[] route = new String[2];
        route[0] = null;
        /**
         * Если маршруты не прочитаны. Возвращаем null
         * Значит нет маршрута
         */
        if (kafkaRoutes.getTopiclist().isEmpty()) {
            logger.info("{}: T{} Справочник маршрутов пуст, искать маршруты негде. Заполните topiclist!", LG.UsbLogInfo, threadNumber);
        } else {
            //Инициализируем маршрут

            kafkaRoutes.getTopiclist().forEach(topiclist -> {
                if (route[0] == null && topiclist.getSystemto().trim().equalsIgnoreCase(message.getSystemTo().trim()) &&
                        topiclist.getSystemfrom().trim().equalsIgnoreCase(message.getSystemFrom().trim())) {
                    route[0] = topiclist.getTopicsystemto().trim();
                    route[1] = topiclist.getTopicsystemfromerror().trim();
                    logger.debug("{}: T{} Найден маршрут[topic]={},  для сообщения, в систему systemto::{}", LG.UsbLogInfo, threadNumber, route[0], message.getSystemTo().trim().toLowerCase());
                    logger.debug("{}: T{} topiclist:{}", LG.UsbLogInfo, threadNumber, topiclist);
                }
            });
        }
        logger.debug("{}: T{} return route={}", LG.UsbLogInfo, threadNumber, route[0]);
        return Optional.ofNullable(route);
    }


    /**
     * Метод поиска маршрута по тэгам topicsystemfromerror
     * Этот метод используется для передачи ошибки в исходящую систему
     *
     * @param message - сообщение от Кафка в универсальном формате
     * @return - строка с именем топика
     */
    public Optional<String> getRouteError(MessageFromKafka message, long threadNumber) {

        /**
         * Если маршруты не прочитаны. Возвращаем null
         * Значит нет маршрута
         */
        final String[] route = new String[1];
        route[0] = null;
        if (kafkaRoutes.getTopiclist().isEmpty()) {
            logger.info("{}: T{} Справочник маршрутов пуст, искать маршруты негде. Заполните topiclist", LG.UsbLogInfo, threadNumber);
        } else {
            kafkaRoutes.getTopiclist().forEach(topiclist -> {
                if (route[0] == null && topiclist.getSystemfrom().trim().equalsIgnoreCase(message.getSystemFrom().trim()) && !topiclist.getTopicsystemfromerror().isEmpty()) {
                    route[0] = topiclist.getTopicsystemfromerror().trim();
                    logger.info("{}: T{} Найден маршрут куда вернуть сообщение, в случае возникновения ошибки. [topic]=={}", LG.UsbLogInfo, threadNumber, route[0]);
                }
            });
        }
        return Optional.ofNullable(route[0]);
    }

}
