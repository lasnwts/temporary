package ru.usb.kafkarouter.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.kafkarouter.dto.MessageFromKafka;
import ru.usb.kafkarouter.model.KafkaRoutes;
import ru.usb.kafkarouter.model.topiclist;

import java.util.function.Consumer;

/**
 * Класс поиска маршрута для сообщения
 * Используется класс KafkaRoutes для сопоставления маршрута
 */
@Component
public class RouteFinder {

    Logger logger = LoggerFactory.getLogger(RouteFinder.class);
    private String route;

    @Autowired
    KafkaRoutes kafkaRoutes;

    /**
     * Метод поиска маршрута по тэгам system_to
     *
     * @param message - сообщение от Кафка в универсальном формате
     * @return - строка с именем топика
     */
    public String getRoute(MessageFromKafka message) {

        /**
         * Если маршруты не прочитаны. Возвращаем null
         * Значит нет маршрута
         */
        if (kafkaRoutes.getTopiclist().size() == 0) {
            logger.info("Справочник маршрутов пуст, искать маршруты негде. Заполните topiclist");
            return null;
        }

        //Инициализируем маршрут
        route = null;

        try {
            kafkaRoutes.getTopiclist().forEach(new Consumer<topiclist>() {
                @Override
                public void accept(topiclist topiclist) {

                    if (topiclist.getSystemto().trim().toLowerCase().equals(message.getSystem_to().trim().toLowerCase())) {
                        route = topiclist.getTopicsystemto().trim();
                        throw new RuntimeException();
                    }
                }
            });

        } catch (RuntimeException breakException) {
            logger.info("Найден маршрут[topic]" + route + " для сообщения, в систему systemto::" + message.getSystem_to().trim().toLowerCase());
        }

        if (route == null) {
            logger.info("Маршрут не найден, для сообщения" + message.toString());
        }

        return route;
    }


    /**
     * Метод поиска маршрута по тэгам topicsystemfromerror
     * Этот метод используется для передачи ошибки в исходящую систему
     * @param message - сообщение от Кафка в универсальном формате
     * @return - строка с именем топика
     */
    public String getRouteError(MessageFromKafka message) {

        /**
         * Если маршруты не прочитаны. Возвращаем null
         * Значит нет маршрута
         */
        if (kafkaRoutes.getTopiclist().size() == 0) {
            logger.info("Справочник маршрутов пуст, искать маршруты негде. Заполните topiclist");
            return null;
        }

        //Инициализируем маршрут
        route = null;

        try {
            kafkaRoutes.getTopiclist().forEach(new Consumer<topiclist>() {
                @Override
                public void accept(topiclist topiclist) {

                    if (topiclist.getSystemfrom().trim().toLowerCase().equals(message.getSystem_from().trim().toLowerCase())) {
                        route = topiclist.getTopicsystemfromerror().trim();
                        throw new RuntimeException();
                    }
                }
            });

        } catch (RuntimeException breakException) {
            logger.info("Найден маршрут[topic]" + route + " для сообщения, в систему systemto::" + message.getSystem_to().trim().toLowerCase());
        }

        if (route == null) {
            logger.info("Маршрут не найден, доя сообщения" + message.toString());
        }

        return route;
    }

}
