package ru.usb.kafkarouter.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.util.FileCopyUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.Properties;

/**
 * Подключение JKS к проекту для Кафка
 */
@Configuration
public class JKSConfig {
    private static final Logger logger = LoggerFactory.getLogger(JKSConfig.class);

    /**
     * /**
     * SSL JKS Файл для Kafka
     */
//    @Value("${service.path.ssl}")
    private String servicePathSsl;

    //    @Value("${service.file.ssl}")
    private String serviceFileSsl;


//    public JKSConfig() {
//
//        var resource = new ClassPathResource("/application.properties");
//        try {
//            Properties properties = PropertiesLoaderUtils.loadProperties(resource);
//            servicePathSsl = properties.getProperty("service.path.ssl");
//            serviceFileSsl = properties.getProperty("service.file.ssl");
//            logger.info("из файла application.properties считано значение service.path.ssl = {}", servicePathSsl);
//            logger.info("из файла application.properties считано значение service.file.ssl = {}", serviceFileSsl);
//        } catch (IOException e) {
//            logger.error(e.getMessage(), e);
//        }
//
//
//        logger.info("JKSConfig:" + servicePathSsl + FileSystems.getDefault().getSeparator() + serviceFileSsl);
////        ClassPathResource cpr = new ClassPathResource("certs/trustStoreKafka.jks");
//        ClassPathResource cpr = new ClassPathResource(servicePathSsl + FileSystems.getDefault().getSeparator() + serviceFileSsl);
//        try {
//            byte[] bdata = FileCopyUtils.copyToByteArray(cpr.getInputStream());
//            try (FileOutputStream fos = new FileOutputStream(serviceFileSsl)) {
//                fos.write(bdata);
//            }
//            logger.info("UsbLogInfo : " + "JKS файл создан");
//        } catch (IOException e) {
//            logger.error("UsbLogError : " + "ошибка при формировании jks файла: " + e.getMessage());
//        }
//    }
}
