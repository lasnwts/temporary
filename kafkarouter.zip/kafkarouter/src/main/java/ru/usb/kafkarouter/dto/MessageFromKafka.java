package ru.usb.kafkarouter.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Сообщение универсально для Зибель
 * JSON-схема универсального запроса:
 * <p>
 * {
 * "systemFrom":"string",
 * "systemTo":"string",
 * "service":"string",
 * "routeID":"string",
 * "mapper":"integer",
 * "packID":"string",
 * "pack":"string"
 * "error":"integer"
 * "errortext":"string"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
@Getter
@Setter
public class MessageFromKafka {

    @JsonProperty("system_from")
    private String systemFrom;

    @JsonProperty("system_to")
    private String systemTo;

    @JsonProperty("service")
    private String service;

    @JsonProperty("routeid")
    private String routeID;

    @JsonProperty("mapper")
    private String mapper;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    private String errortext;

    public MessageFromKafka() {
    }

    public MessageFromKafka(String systemFrom, String systemTo, String service,
                            String routeID, String mapper, String packID, String pack,
                            String error, String errortext) {
        this.systemFrom = systemFrom;
        this.systemTo = systemTo;
        this.service = service;
        this.routeID = routeID;
        this.mapper = mapper;
        this.packID = packID;
        this.pack = pack;
        this.error = error;
        this.errortext = errortext;
    }



    public void setSystemFrom(String systemFrom) {
        this.systemFrom = systemFrom;
    }

    public void setSystemTo(String systemTo) {
        this.systemTo = systemTo;
    }



    public void setService(String service) {
        this.service = service;
    }



    public void setRouteID(String routeID) {
        this.routeID = routeID;
    }



    public void setMapper(String mapper) {
        this.mapper = mapper;
    }



    public void setPackID(String packID) {
        this.packID = packID;
    }



    public void setPack(String pack) {
        this.pack = pack;
    }

    public String getError() {
        if (error == null) {
            return "";
        } else {
            return error;
        }
    }

    public void setError(String error) {
        this.error = error;
    }



    public void setErrortext(String errortext) {
        this.errortext = errortext;
    }

    @Override
    public String toString() {
        return "{" +
                "systemFrom='" + systemFrom + '\'' +
                ", systemTo='" + systemTo + '\'' +
                ", service='" + service + '\'' +
                ", routeID='" + routeID + '\'' +
                ", mapper='" + mapper + '\'' +
                ", packID='" + packID + '\'' +
                ", pack='" + pack + '\'' +
                ", error='" + error + '\'' +
                ", errortext='" + errortext + '\'' +
                '}';
    }
}
