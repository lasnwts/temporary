package ru.usb.kafkarouter.service;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import java.io.FileNotFoundException;

public interface EmailService {
    void sendSimpleEmail(final String toAddress, final String subject, final String message) throws AddressException;

    void sendEmailWithAttachment(final String toAddress, final String subject, final String message, final String attachment) throws MessagingException, FileNotFoundException;
}
