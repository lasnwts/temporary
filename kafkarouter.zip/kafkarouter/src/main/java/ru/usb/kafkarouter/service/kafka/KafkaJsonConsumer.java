package ru.usb.kafkarouter.service.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.kafkarouter.config.Configure;
import ru.usb.kafkarouter.config.LG;
import ru.usb.kafkarouter.service.MessageProcess;

@Configuration
@EnableKafka
public class KafkaJsonConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaJsonConsumer.class);

    private final MessageProcess messageProcess;
    private final Configure configure;

    @Autowired
    public KafkaJsonConsumer(MessageProcess messageProcess, Configure configure) {
        this.messageProcess = messageProcess;
        this.configure = configure;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${max.size.queue:100}") //Максимальное число записей, принятых в обработку
    private int maxSizeQueue;

    @Value("${ack.nack.duration:10}") //Задержка перед приемом новой порции сообщений
    private int ackDuration;

    @Value("${kafka.mapper.topic:siebel-kafka-router.in.mapper}")
    private String kafkaMapperTopic;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordValue, Acknowledgment ack) {
        logger.info("+++++++++++++++++++++++<Offset:{} >++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", String.valueOf(recordValue.offset()));
        if (logDebug) {
            logger.info("{}: KafkaListener(recordValue.partition) == {}", LG.UsbLogInfo, recordValue.partition());
            logger.info("{}: KafkaListener(topic)            == {}", LG.UsbLogInfo, recordValue.topic());
            logger.info("{}: KafkaListener(Offset)           == {}", LG.UsbLogInfo, String.valueOf(recordValue.offset()));
        }
        logger.info("{}: KafkaListener(recordValue.key)       == {}", LG.UsbLogInfo, recordValue.key());
        logger.info("{}: KafkaListener(recordValue.value)     == {}", LG.UsbLogInfo, recordValue.value());
        logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");


        //Если очередь длиннее чем заданная тормозим принятие новых сообщений
//        if (configure.getThreads().get() > maxSizeQueue) {
//            logger.info("{} Притормаживаем процесс вычитывания очереди на {} секунд, достигнут заданный порог длины очереди={}", LG.UsbLogInfo, ackDuration, maxSizeQueue);
//            ack.nack(ackDuration * 1000L);
//        } else {
//            logger.info("{} Возобновляем процесс вычитывания сообщений, длина очереди сейчас={}", LG.UsbLogInfo, configure.getThreads());
//            ack.acknowledge(); //Сообщение забираем сразу
//            /******************************************************************
//             * Обработка сообщения
//             * @param message  - тело сообщения
//             *****************************************************************/
//            //Маршрутизируем
//            messageProcess.runTask(recordValue.value());
//        }

        ack.acknowledge(); //Сообщение забираем сразу
        /******************************************************************
         * Обработка сообщения
         * @param message  - тело сообщения
         *****************************************************************/
        //Маршрутизируем
        messageProcess.runTask(recordValue.value());
    }
}
