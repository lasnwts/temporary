package ru.usb.kafkarouter.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@RefreshScope
@ConfigurationProperties
@Data
public class Configure {
    /**
     * Количество задач в очереди
     */
    //private int threads;
    public AtomicInteger threads = new AtomicInteger();

    public int decThreads() {
        return threads.decrementAndGet();
    }

    public int addThreads() {
        return threads.incrementAndGet();
    }

    public AtomicInteger getThreads() {
        return threads;
    }

    //Суммарное количество сообщений прочитано
    private long summary;

    //Суммарное количество сообщений обработано
    private long summaryDone;

    public synchronized long getSummaryDoneSync() {
        return summaryDone;
    }

    public synchronized long getSummarySync() {
        return summary;
    }

    public synchronized void setSummarySync(long summary) {
        this.summary = summary;
    }

    public synchronized void incSummary(){
        this.summary++;
    }

    public synchronized void incSummaryDone(){
        this.summaryDone++;
    }

    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private Integer servicePoolSize;

    /**
     * Кол-во потоков
     */
//    public synchronized int getThreads() {
//        return threads;
//    }
//
//    public synchronized void setThreads(int threads) {
//        this.threads = threads;
//    }

    public int getServicePoolSize() {
        return servicePoolSize;
    }

    /**
     *  Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Версия из файла application.properties
     */
    @Value("${service.version:no data}")
    private String version;

    /**
     * Для вывода в REST
     */

    @Value("${server.port}")
    private String serverPort;

    @Value("${logging.level.root}")
    private String loggingLevelRoot;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:router}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    @Value("${kafka.consumer.topic}")
    private String kafkaConsumerTopic;

    @Value("${info.app.name:sinkAdapter}")
    private String infoAppName;

    @Value("${log.tag.info:info}")
    private String logTagInfo;

    @Value("${log.tag.error:error}")
    private String logTagError;

    @Value("${kafka.mapper.topic}")
    private String kafkaMapperTopic;

}
