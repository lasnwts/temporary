package ru.usb.kafkarouter.model;

import org.springframework.stereotype.Component;

@Component
public class topiclist {

    public String systemfrom;
    public String systemto;
    public String topicsystemto;
    public String topicsystemfromerror;

    public topiclist() {
    }

    public topiclist(String systemfrom, String systemto, String topicsystemto, String topicsystemfromerror) {
        this.systemfrom = systemfrom;
        this.systemto = systemto;
        this.topicsystemto = topicsystemto;
        this.topicsystemfromerror = topicsystemfromerror;
    }

    public String getSystemfrom() {
        return systemfrom;
    }

    public void setSystemfrom(String systemfrom) {
        this.systemfrom = systemfrom;
    }

    public String getSystemto() {
        return systemto;
    }

    public void setSystemto(String systemto) {
        this.systemto = systemto;
    }

    public String getTopicsystemto() {
        return topicsystemto;
    }

    public void setTopicsystemto(String topicsystemto) {
        this.topicsystemto = topicsystemto;
    }

    public String getTopicsystemfromerror() {
        return topicsystemfromerror;
    }

    public void setTopicsystemfromerror(String topicsystemfromerror) {
        this.topicsystemfromerror = topicsystemfromerror;
    }

    @Override
    public String toString() {
        return "{" +
                "systemfrom='" + systemfrom + '\'' +
                ", systemto='" + systemto + '\'' +
                ", topicsystemto='" + topicsystemto + '\'' +
                ", topicsystemfromerror='" + topicsystemfromerror + '\'' +
                '}';
    }
}
