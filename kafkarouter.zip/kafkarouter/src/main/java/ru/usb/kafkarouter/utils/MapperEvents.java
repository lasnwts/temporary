package ru.usb.kafkarouter.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.usb.kafkarouter.config.LG;
import ru.usb.kafkarouter.dto.MessageFromKafka;

import java.util.Optional;

@Slf4j
@Service
public class MapperEvents {

    ObjectMapper objectMapper = new ObjectMapper();


    /**
     * Получение документа в виде объекта
     * @param json - строка Json
     * @return - FactoringDocument
     */
    public Optional<MessageFromKafka> getMessage(String json) {
        if (json == null) {
            log.error("{}: На маппер getDocument поступил объект, строка [Json] == NULL!", LG.UsbLogError);
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(json, MessageFromKafka.class));
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге Json:{}", LG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге Json:", LG.UsbLogError, e);
            return Optional.empty();        }
    }

    /**
     * Получение документа в виде Json строки
     * @param document - FactoringDocument
     * @return - Json строка
     */
    public String getJson(MessageFromKafka document) {
        if (document == null) {
            log.error("{}: На маппер getJson поступил объект, строка [MessageFromKafka] == NULL!", LG.UsbLogError);
            return null;
        }
        try {
            return objectMapper.writeValueAsString(document);
        } catch (Exception e) {
            log.error("{}: Error : Ошибка при парсинге документа MessageFromKafka :{}", LG.UsbLogError, e.getMessage());
            log.debug("{}: PrintStackTrace : Ошибка при парсинге MessageFromKafka:", LG.UsbLogError, e);
            return null;
        }
    }
}
