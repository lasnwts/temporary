package ru.usb.kafkarouter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.kafkarouter.config.Configure;
import ru.usb.kafkarouter.dto.MessageFromKafka;
import ru.usb.kafkarouter.utils.RouteFinder;

@Configuration
@EnableKafka
public class KafkaJsonConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaJsonConsumer.class);

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    Configure configure;

    @Autowired
    KafkaProducerService kafkaProducerService;

    @Autowired
    RouteFinder routeFinder;

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.delay:60}")
    private int serviceDelay;

    @Value("${kafka.mapper.topic:siebel-kafka-router.in.mapper}")
    private String kafkaMapperTopic;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> record, Acknowledgment ack) {
        if (logDebug) {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.partition) == " + record.partition());
            logger.info("KafkaListener(record.key)       == " + record.key());
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("KafkaListener(topic)            == " + record.topic());
            logger.info("KafkaListener(Offset)           == " + String.valueOf(record.offset()));
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }


        /**
         * Сообщение забираем по любому
         */
        ack.acknowledge();

        /**
         * Сообщение по Kafka, готовим
         */
        MessageFromKafka message;

        try {
            message = objectMapper.readValue(StringUtils.newStringUtf8(StringUtils.getBytesUtf8(record.value())), MessageFromKafka.class);
            logger.info("Object MessageFromKafka::" + message.toString());
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : " + "Ошибка при парсинге Json: " + e.getMessage());
            message = null;
            serviceMailError.sendMailError("Topic:" + configure.getKafkaConsumerTopic() + " Ошибка при парсинге Json: " + e.getMessage());
        }

        if (message != null) {

            if (message.getPack() == null || message.getPackID() == null) {
                logger.error("Получено сообщение, которое не удалось распарсить  сообщение удалено." + message.toString());
                serviceMailError.sendMailError("Получено сообщение, которое не удалось распарсить  сообщение удалено:" + record.value());
            } else {
                /**
                 * DTO для передачи в другой топик
                 */
                logger.info("Сообщение для маршрутизации:" + message.toString());

                /**
                 * Проверяем, есь маппер?
                 */
                if (message.getMapper() != null && message.getMapper().trim().length() > 0 && !message.getMapper().trim().toLowerCase().equals("null")) {
                    /**
                     * Если маппер требуется, т.юе поле mapper содержит ЛЮБОЙ символ, отправляем в очередь сервису Mapper
                     */
                    logger.info("Сообщение отправлено в маппер, в Топик::" + kafkaMapperTopic + " сообщение:" + record.value());
                    kafkaProducerService.sendMessage(kafkaMapperTopic, record.value());
                } else { //here
                    /**
                     * Если меппер не требуется, смотрим кому отправить сообщение
                     */

                    if (routeFinder.getRoute(message) == null) {
                        logger.error("Не найден маршрут для system_to:" + message.getSystem_to() + " сообщение:" + record.value());
                        serviceMailError.sendMailError("Не найден маршрут для (No route found for) system_to:" + message.getSystem_to() + " сообщение(message):" + record.value());
                        message.setError("Router:404");
                        message.setErrortext("Не найден маршрут для (No route found for) system_to:" + message.getSystem_to());
                        if (routeFinder.getRouteError(message) != null && routeFinder.getRouteError(message).trim().length() > 0) {
                            try {
                                kafkaProducerService.sendMessage(routeFinder.getRouteError(message), objectMapper.writeValueAsString(message));
                            } catch (JsonProcessingException e) {
                                logger.error("Ошибка отправки в топик [topicsystemfromerror] сообщения:" + message.toString());
                                logger.error("Ошибка преобразования объекта в Json", e.getMessage());
                                serviceMailError.sendMailError("Ошибка отправки в топик [topicsystemfromerror] сообщения:" + message.toString() + "   " +
                                        "\r\n Ошибка преобразования объекта в Json" + e.getMessage());
                            }
                        } else {
                            logger.error("Ошибка поиска очереди [topicsystemfromerror] для сообщения " + message.toString());
                            serviceMailError.sendMailError("Ошибка поиска очереди [topicsystemfromerror] для сообщения " + message.toString());
                        }
                    } else {
                        if (kafkaProducerService.sendMessage2(routeFinder.getRoute(message), record.value(), 0)) {
                            logger.info("Маршрутизация прошла успешно, сообщение отправлено в Топик::" + routeFinder.getRoute(message) + " сообщение:" + record.value());
                        } else {
                            logger.info("Ошибка отправки сообщения, Топик::" + routeFinder.getRoute(message) + " сообщение не отправлено:" + record.value());
                            message.setError("Router:500");
                            message.setErrortext("Сообщение не было отправлено, произошла ошибка. Отправьте сообщение еще раз.The message was not sent, an error occurred. Send the message again.");
                            try {
                                kafkaProducerService.sendMessage(routeFinder.getRouteError(message), objectMapper.writeValueAsString(message));
                            } catch (JsonProcessingException e) {
                                logger.error("Ошибка преобразования объекта в Json", e.getMessage());
                            }
                            serviceMailError.sendMailError("Ошибка отправки сообщения, Топик::" + routeFinder.getRoute(message) + " сообщение не отправлено:" + record.value());
                        }
                    }//here
                }

            }
        }

    }
}
