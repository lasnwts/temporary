package ru.usb.kafkarouter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.kafkarouter.config.Configure;
import ru.usb.kafkarouter.dto.MessageFromKafka;
import ru.usb.kafkarouter.utils.RouteFinder;

@Configuration
@EnableKafka
public class KafkaJsonConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaJsonConsumer.class);

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    Configure configure;

    @Autowired
    KafkaProducerService kafkaProducerService;

    @Autowired
    RouteFinder routeFinder;

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.delay:60}")
    private int serviceDelay;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> record, Acknowledgment ack) {
        if (logDebug) {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.partition) == " + record.partition());
            logger.info("KafkaListener(record.key)       == " + record.key());
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("KafkaListener(topic)            == " + record.topic());
            logger.info("KafkaListener(Offset)           == " + String.valueOf(record.offset()));
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }


        /**
         * Сообщение по Kafka
         */
        MessageFromKafka message;

        try {
            message = objectMapper.readValue(StringUtils.newStringUtf8(StringUtils.getBytesUtf8(record.value())), MessageFromKafka.class);
            logger.info("Object MessageFromKafka::" + message.toString());
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : " + "Ошибка при парсинге Json: " + e.getMessage());
            serviceMailError.sendMailError("Topic:" + configure.getKafkaConsumerTopic() + " Ошибка при парсинге Json: " + e.getMessage());
            ack.acknowledge();
            message = null;
        }

        if (message != null) {

            if (message.getPack() == null & message.getPackID() == null) {
                logger.error("Получено сообщение, которое не удалось распарсить  сообщение удалено." + message.toString());
                ack.acknowledge();
                serviceMailError.sendMailError("Получено сообщение, которое не удалось распарсить  сообщение удалено:" + record.value());
            } else {
                /**
                 * DTO для передачи в другой топик
                 */
                logger.info("Сообщение для маршрутизации:" + message.toString());

                if (routeFinder.getRoute(message) == null) {
                    logger.error("Не найден маршрут для system_to:" + message.getSystem_to() + " сообщение:" + record.value());
                    serviceMailError.sendMailError("Не найден маршрут для (No route found for) system_to:" + message.getSystem_to() + " сообщение(message):" + record.value());
                    ack.acknowledge();
                    message.setError("404");
                    message.setErrortext("Не найден маршрут для (No route found for) system_to:" + message.getSystem_to());
                    kafkaProducerService.sendMessage(routeFinder.getRouteError(message), message.toString());
                } else {
                    if (kafkaProducerService.sendMessage2(routeFinder.getRoute(message), record.value(), 0)) {
                        logger.info("Маршрутизация прошла успешно, сообщение отправлено в Топик::" + routeFinder.getRoute(message) + " сообщение:" + record.value());
                    } else {
                        logger.info("Ошибка отправки сообщения, Топик::" + routeFinder.getRoute(message) + " сообщение не отправлено:" + record.value());
                        message.setError("500");
                        message.setErrortext("Сообщение не было отправлено, произошла ошибка. Отправьте сообщение еще раз.The message was not sent, an error occurred. Send the message again.");
                        kafkaProducerService.sendMessage(routeFinder.getRouteError(message), message.toString());
                        serviceMailError.sendMailError("Ошибка отправки сообщения, Топик::" + routeFinder.getRoute(message) + " сообщение не отправлено:" + record.value());
                    }
                    ack.acknowledge();
                }

            }
        }

    }


}
