package ru.usb.kafkarouter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.kafkarouter.config.Configure;
import ru.usb.kafkarouter.config.LG;
import ru.usb.kafkarouter.config.YamlConfig;
import ru.usb.kafkarouter.model.KafkaRoutes;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class KafkarouterApplication implements CommandLineRunner {


    Logger logger = LoggerFactory.getLogger(KafkarouterApplication.class);

    private final Configure configure;
    private final YamlConfig yamlConfig;
    private final KafkaRoutes kafkaRoutes;

    @Autowired
    public KafkarouterApplication(Configure configure, YamlConfig yamlConfig, KafkaRoutes kafkaRoutes) {
        this.configure = configure;
        this.yamlConfig = yamlConfig;
        this.kafkaRoutes = kafkaRoutes;
    }

    public static void main(String[] args) {
        SpringApplication.run(KafkarouterApplication.class, args);
    }

    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void baseJob() {
		logger.info("*****************************************<Start Scheduler process Garbage Collector:{} >*******************************************************", configure.getVersion());
        //Принудительный запуcк GC
        System.gc();
        logger.info("{}: Поступило из кафка сообщений, всего={}", LG.UsbLogInfo, configure.getSummarySync());
        logger.info("{}: Обработано         сообщений, всего={}", LG.UsbLogInfo, configure.getSummaryDoneSync());
        logger.info("{}:=-------------------------------------------------------------------------------------------------------------------+--=", LG.UsbLogInfo);
        logger.info("{}: Current version                        : 2.1.34", LG.UsbLogInfo);
        logger.info("{}:---------------------------------------------------------------------------------------------------------------------+--", LG.UsbLogInfo);
        logger.info("*****************************************<End   Scheduler process :{} ----------->*******************************************************", configure.getVersion());
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("*****************************************<YAML Config>*******************************************************");
        logger.info("using environment: {}", yamlConfig.getEnvironment());
        logger.info("name: {}", yamlConfig.getName());
        logger.info("*****************************************<Kafka Router init Start: {} >*******************************************************", configure.getVersion());
        logger.info("Печатаем перечень маршрутов");
        kafkaRoutes.getTopiclist().forEach(kafkaRoute-> {
                logger.info("System from: {}", kafkaRoute.getSystemfrom());
                logger.info("System to: {}", kafkaRoute.getSystemto());
                logger.info("Topic System to: {}", kafkaRoute.getTopicsystemto());
                logger.info("Topic System From Error: {}", kafkaRoute.getTopicsystemfromerror());
                logger.info("---------------------------------------------------------");
        });
        logger.info("*****************************************<EKafka Router init end {} >*******************************************************", configure.getVersion());
        logger.info("{}:=---------------------------------------------------------------------------------------------------------------------=", LG.UsbLogInfo);
        logger.info("{}: Current version                   : 2.1.34", LG.UsbLogInfo);
        logger.info("{}:-----------------------------------------------------------------------------------------------------------------------", LG.UsbLogInfo);

    }
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    //
}