package ru.usb.kafkarouter.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.kafkarouter.config.Configure;

@Slf4j
@Service
public class MessageProcess {

    private final Executors executors;
    private final Configure configure;

    @Autowired
    public MessageProcess(Executors executors, Configure configure) {
        this.executors = executors;
        this.configure = configure;
    }

    /**
     * Запуск задачи
     * @param body - тело сообщения
     */
    public void runTask(String body){
        configure.incSummary(); //+ 1 в числе прочитанных из кафка сообщений
        executors.getTask(body);
    }

}
