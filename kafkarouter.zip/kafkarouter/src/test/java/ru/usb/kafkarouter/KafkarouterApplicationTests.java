package ru.usb.kafkarouter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkarouterApplicationTests {

	@Test
	void contextLoads() {
	}

}
