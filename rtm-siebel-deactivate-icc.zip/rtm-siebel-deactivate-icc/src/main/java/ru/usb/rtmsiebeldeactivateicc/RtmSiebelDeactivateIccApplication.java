package ru.usb.rtmsiebeldeactivateicc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtmSiebelDeactivateIccApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtmSiebelDeactivateIccApplication.class, args);
	}

}
