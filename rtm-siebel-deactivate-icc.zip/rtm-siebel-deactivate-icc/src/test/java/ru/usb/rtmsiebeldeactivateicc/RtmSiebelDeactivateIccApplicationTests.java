package ru.usb.rtmsiebeldeactivateicc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtmSiebelDeactivateIccApplicationTests {

	@Test
	void contextLoads() {
	}

}
