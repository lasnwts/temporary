package ru.usb.rfr952329;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rfr952329ApplicationTests {

	@Test
	void contextLoads() {
	}

}
