package ru.usb.rfr952329.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {

    /**
     *  Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Версия из файла application.properties
     */
    @Value("${service.version:no data}")
    private String version;

    /**
     * Для вывода в REST
     */

    @Value("${server.port}")
    private String serverPort;

    @Value("${logging.level.root}")
    private String loggingLevelRoot;

    @Value("${spring.datasource.url}")
    private String springDatasourceUrl;

    @Value("${spring.datasource.username}")
    private String springDatasourceUsername;

    @Value("${spring.datasource.driver-class-name}")
    private String springDatasourceDriverClassName;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:ZSK}")
    private String mailSubjects;

    @Value("${mailFrom:rfr952329 problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    @Value("${kafka.consumer.topic}")
    private String kafkaConsumerTopic;

    public String getKafkaConsumerTopic() {
        return kafkaConsumerTopic;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getServerPort() {
        return serverPort;
    }

    public String getLoggingLevelRoot() {
        return loggingLevelRoot;
    }

    public String getSpringDatasourceUrl() {
        return springDatasourceUrl;
    }

    public String getSpringDatasourceUsername() {
        return springDatasourceUsername;
    }

    public String getSpringDatasourceDriverClassName() {
        return springDatasourceDriverClassName;
    }

    public String getVersion() {
        return version;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }
}
