package ru.usb.rfr952329.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "RrSite_dto", description = "Входящий Rest запрос : Запрос в БД")
@JsonIgnoreProperties(ignoreUnknown = true)
public class RrSite_dto {


    @ApiModelProperty(value = "id :: Тип источника :: ключ")
    @JsonProperty("Id")
    private long id;

    @ApiModelProperty(value = "orderumber :: номер заказа")
    @JsonProperty("ordernumber")
    private String ordernumber;

    @ApiModelProperty(value = "dt_create :: Дата")
    @JsonProperty("dt_create")
    private String dt_create;

    @ApiModelProperty(value = "xml_data :: Данные")
    @JsonProperty("xml_data")
    private String xml_data;

    public RrSite_dto() {
    }

    public RrSite_dto(long id, String ordernumber, String dt_create, String xml_data) {
        this.id = id;
        this.ordernumber = ordernumber;
        this.dt_create = dt_create;
        this.xml_data = xml_data;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(String ordernumber) {
        this.ordernumber = ordernumber;
    }

    public String getDt_create() {
        return dt_create;
    }

    public void setDt_create(String dt_create) {
        this.dt_create = dt_create;
    }

    public String getXml_data() {
        return xml_data;
    }

    public void setXml_data(String xml_data) {
        this.xml_data = xml_data;
    }

    @Override
    public String toString() {
        return "RrSite_dto{" +
                "id=" + id +
                ", orderumber='" + ordernumber + '\'' +
                ", dt_create='" + dt_create + '\'' +
                ", xml_data='" + xml_data + '\'' +
                '}';
    }
}
