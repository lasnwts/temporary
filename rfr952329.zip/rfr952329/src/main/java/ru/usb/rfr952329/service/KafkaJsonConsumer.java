package ru.usb.rfr952329.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.rfr952329.config.Configure;
import ru.usb.rfr952329.dto.MessageFromKafka;
import ru.usb.rfr952329.dto.RrSite_dto;
import ru.usb.rfr952329.model.RrSiteR;
import ru.usb.rfr952329.repository.JpaRepositoryRrSiteR;
import ru.usb.rfr952329.utils.ParseDate;

@Configuration
@EnableKafka
public class
KafkaJsonConsumer {

    Logger logger = LoggerFactory.getLogger(KafkaJsonConsumer.class);

    @Autowired
    ParseDate parseDate;

    @Autowired
    ServiceMapper serviceMapper;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    JpaRepositoryRrSiteR jpaRepositoryRrSiteR;

    @Autowired
    Configure configure;

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    @Value("${service.delay:60}")
    private int serviceDelay;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> record, Acknowledgment ack) {
        if (logDebug) {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.partition) == " + record.partition());
            logger.info("KafkaListener(record.key)       == " + record.key());
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("KafkaListener(topic)            == " + record.topic());
            logger.info("KafkaListener(Offset)           == " + String.valueOf(record.offset()));
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("+++++++++++++++++++++++<Offset:" + String.valueOf(record.offset()) + ">+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("KafkaListener(record.value)     == " + record.value());
            logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        /**
         * DTO для записи в БД
         */
        RrSite_dto rSite_dto;

        /**
         * Сообщение по Kafka
         */
        MessageFromKafka message;

        try {
            String germanString = "Wie heißen Sie?"; // What's your name?
            byte[] bytes = StringUtils.getBytesUtf8(germanString);
            String utf8String = StringUtils.newStringUtf8(bytes);
            System.out.println(utf8String);

            //message = objectMapper.readValue(record.value(), MessageFromKafka.class);
            message = objectMapper.readValue(StringUtils.newStringUtf8(StringUtils.getBytesUtf8(record.value())), MessageFromKafka.class);
            logger.info("Object MessageFromKafka::" + message.toString());
        } catch (JsonProcessingException e) {
            logger.error("UsbLogWarning : " + "Ошибка при парсинге Json: " + e.getMessage());
            serviceMailError.sendMailError("Topic:" + configure.getKafkaConsumerTopic() + " Ошибка при парсинге Json: " + e.getMessage());
            ack.acknowledge();
            message = null;
        }

        if (message != null) {
            /**
             * DTO для записи в БД
             */
            rSite_dto = new RrSite_dto();
            rSite_dto.setOrdernumber(message.getOrderNumber());
            rSite_dto.setXml_data(message.toString());
            if (addRecord(rSite_dto)) {
                ack.acknowledge();
            } else {
                //Задержка в NN секунд для обработки. Свойство - download.delay
                logger.info(" Seconds = " + serviceDelay + " - delay between downloaded.....");
                ack.nack(serviceDelay);
            }
        }
    }

    /**
     * Метод вставки записи в базу данных
     *
     * @param rSite_dto - DTO для записи в БД
     * @return - boolean (true - добавлен)
     */
    private boolean addRecord(RrSite_dto rSite_dto) {
        RrSiteR rrSiteR = null;
        if (rSite_dto.getDt_create() == null) {
            rrSiteR = serviceMapper.mapDtoToModelwithoutDate(rSite_dto);
            logger.info("В базу данных будет добавлен: " + rrSiteR.toString());
        } else {
            if (parseDate.checkDate(rSite_dto.getDt_create())) {
                rrSiteR = serviceMapper.mapDtoToModel(rSite_dto);
                logger.info("В базу данных будет добавлен: " + rrSiteR.toString());
            } else {
                return false;
            }
        }
        try {
            jpaRepositoryRrSiteR.save(rrSiteR);
            logger.info("Запись добавлена в БД " + rrSiteR.toString());
            return true;
        } catch (Exception exception) {
            logger.error("!!Error! Ошибка добавления записи в БД::", exception);
            serviceMailError.sendMailError("!!Error! Ошибка добавления записи в БД::" + exception.toString());
            return false;
        }
    }


}
