package ru.usb.rfr952329.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.rfr952329.config.Configure;
import ru.usb.rfr952329.dto.RrSite_dto;
import ru.usb.rfr952329.model.RrSiteR;
import ru.usb.rfr952329.repository.JpaRepositoryRrSiteR;
import ru.usb.rfr952329.service.ServiceMapper;
import ru.usb.rfr952329.utils.ParseDate;

@RequestMapping("/api/v1")
@RestController
@Api(value = "user", description = "Контроллер для тестирования работы Sink адаптера.", tags = "1.Rest API базовое.")
public class RestControllerMF {

    @Autowired
    Configure configure;

    @Autowired
    ParseDate parseDate;

    @Autowired
    ServiceMapper serviceMapper;

    @Autowired
    JpaRepositoryRrSiteR jpaRepositoryRrSiteR;

    Logger logger = LoggerFactory.getLogger(RestControllerMF.class);

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() {
        logger.info("Get /version");
        if (configure.getVersion() == null) {
            logger.info("version not defined");
            return "version not defined";
        }
        logger.info("version: " + configure.getVersion());
        return (configure.getVersion());
    }

    @PostMapping("/add")
    //Вставляем API описание
    @ApiOperation(value = "Добавление записи в базу данных",
            notes = "Запись будет добавлена. id можно оставить =0, А формат даты: dd.MM.yy HH:mm:ss")
    public ResponseEntity<?> postRecord(@RequestBody RrSite_dto rSite_dto) {
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>POST input record>>>>>>>>>>>>>>>>>>");
        logger.info("postRecord:/ " + rSite_dto.toString());
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");
        RrSiteR rrSiteR = null;
        if (parseDate.checkDate(rSite_dto.getDt_create())) {
            rrSiteR = serviceMapper.mapDtoToModel(rSite_dto);
            logger.info("В базу данных будет добавлен: " + rrSiteR.toString());
            try {
                jpaRepositoryRrSiteR.save(rrSiteR);
                logger.info("Запись добавлена в БД " + rrSiteR.toString());
                return new ResponseEntity<>(
                        "Запись добавлена в базу данных:" + rrSiteR.toString(),
                        HttpStatus.OK);
            } catch (Exception exception) {
                logger.error("!!Error! Ошибка добавления записи в БД::", exception);
                return new ResponseEntity<>(
                        "Произошла ошибка добавления записи в базу данных:" + rrSiteR.toString() + "\n\r" + exception,
                        HttpStatus.NOT_ACCEPTABLE);
            }

        } else {
            return new ResponseEntity<>(
                    "Произошла ошибка дата :" + rSite_dto.getDt_create() +" не соответствует формату :: dd.MM.yyyy HH:mm:ss ",
                    HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/getCount")
    @ApiOperation(value = "Получить количество записей в таблице БД",
            notes = "Таблица T_RESTRUCT_REQUEST_SITE_R")
    public ResponseEntity<?> getCountRecords() {
        long countRecords = jpaRepositoryRrSiteR.count();
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>GET count of all record>>>>>>>>>>>>>>>>>>");
        logger.info("Counts Record:: " + countRecords);
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");
        return new ResponseEntity<>(
                countRecords,
                HttpStatus.OK);
    }

    @GetMapping("/id/{id}")
    @ApiOperation(value = "Получить запись из БД по id",
            notes = "Возвращается одна запись")
    public ResponseEntity<?> getById(@PathVariable long id) {
        logger.info("*****>>>>>>>>>>>>>>>>>>>>>GET last record>>>>>>>>>>>>>>>>>>");
        logger.info("Get id Record:=" + id);
        logger.info("******>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*");
        RrSiteR rrSiteR = null;
        try {
            rrSiteR = jpaRepositoryRrSiteR.getById(id);
            logger.info("В базе найдена запись с id=" + id);
            logger.info("Запись::" + rrSiteR.toString());
            return new ResponseEntity<>(
                    rrSiteR.toString(),
                    HttpStatus.OK);
        } catch (Exception exception) {
            logger.info("В базе не найдено записей с id=" + id);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Ошибка при поиске в таблице с id=" + id);
            logger.error("Error::", exception);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return new ResponseEntity<>(
                    "В базе не найдено записей с id=" + id,
                    HttpStatus.NOT_FOUND);
        }
    }


}
