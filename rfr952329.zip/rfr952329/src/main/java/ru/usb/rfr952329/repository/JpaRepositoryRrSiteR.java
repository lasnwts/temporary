package ru.usb.rfr952329.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.rfr952329.model.RrSiteR;

public interface JpaRepositoryRrSiteR extends JpaRepository<RrSiteR, Long> {

}
