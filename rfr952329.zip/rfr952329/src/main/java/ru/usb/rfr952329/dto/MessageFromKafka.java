package ru.usb.rfr952329.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageFromKafka {

    // import com.fasterxml.jackson.databind.ObjectMapper; // version 2.11.1
// import com.fasterxml.jackson.annotation.JsonProperty; // version 2.11.1
/* ObjectMapper om = new ObjectMapper();
Root root = om.readValue(myJsonString, Root.class); */
    @JsonProperty("additionalIncomeAmount")
    private String additionalIncomeAmount;

    @JsonProperty("orderNumber")
    private String orderNumber;

    @JsonProperty("additionalIncomeSource")
    private String additionalIncomeSource;

    @JsonProperty("allowablePayment")
    private String allowablePayment;

    @JsonProperty("countOfDependants")
    private String countOfDependants;

    @JsonProperty("personalDataBirthday")
    private String personalDataBirthday;

    @JsonProperty("personalDataPassportDate")
    private String personalDataPassportDate;

    @JsonProperty("personalDataPassportIssueBy")
    private String personalDataPassportIssueBy;

    @JsonProperty("personalDataPassportIssuerCode")
    private String personalDataPassportIssuerCode;

    @JsonProperty("personalDataPassportNumber")
    private String personalDataPassportNumber;

    @JsonProperty("personalDataPassportSeries")
    private String personalDataPassportSeries;

    @JsonProperty("email")
    private String email;

    @JsonProperty("familyIncome")
    private String familyIncome;

    @JsonProperty("incomeAmount")
    private String incomeAmount;

    @JsonProperty("incomeSource")
    private String incomeSource;

    @JsonProperty("jobCompanyName")
    private String jobCompanyName;

    @JsonProperty("jobCompanyPhone")
    private String jobCompanyPhone;

    @JsonProperty("jobPhoneExtension")
    private String jobPhoneExtension;

    @JsonProperty("jobPosition")
    private String jobPosition;

    @JsonProperty("realСlientAddressAppartment")
    private String realСlientAddressAppartment;

    @JsonProperty("realСlientAddressBuilding")
    private String realСlientAddressBuilding;

    @JsonProperty("realСlientAddressCity")
    private String realСlientAddressCity;

    @JsonProperty("realСlientAddressHouse")
    private String realСlientAddressHouse;

    @JsonProperty("realСlientAddressKorpus")
    private String realСlientAddressKorpus;

    @JsonProperty("realСlientAddressRegionName")
    private String realСlientAddressRegionName;

    @JsonProperty("realСlientAddressStreet")
    private String realСlientAddressStreet;

    @JsonProperty("maritalStatus")
    private String maritalStatus;

    @JsonProperty("personalDataFirstName")
    private String personalDataFirstName;

    @JsonProperty("personalDataMiddleName")
    private String personalDataMiddleName;

    @JsonProperty("personalDataMobilePhone")
    private String personalDataMobilePhone;

    @JsonProperty("personalDataBirthplace")
    private String personalDataBirthplace;

    @JsonProperty("previousSurname")
    private String previousSurname;

    @JsonProperty("product")
    private String product;

    @JsonProperty("permanentСlientAddressApartment")
    private String permanentСlientAddressApartment;

    @JsonProperty("permanentСlientAddressBuilding")
    private String permanentСlientAddressBuilding;

    @JsonProperty("permanentСlientAddressCity")
    private String permanentСlientAddressCity;

    @JsonProperty("permanentСlientAddressHouse")
    private String permanentСlientAddressHouse;

    @JsonProperty("permanentСlientAddressKorpus")
    private String permanentСlientAddressKorpus;

    @JsonProperty("realAndPermanentAreSame")
    private boolean realAndPermanentAreSame;

    @JsonProperty("permanentСlientAddressRegionName")
    private String permanentСlientAddressRegionName;

    @JsonProperty("permanentСlientAddressStreet")
    private String permanentСlientAddressStreet;

    @JsonProperty("restructuringLoanDetails")
    private String restructuringLoanDetails;

    @JsonProperty("restructuringReason")
    private String restructuringReason;

    @JsonProperty("restructuringReasonOther")
    private String restructuringReasonOther;

    @JsonProperty("restructuringReasonProductType")
    private String restructuringReasonProductType;

    @JsonProperty("spouseName")
    private String spouseName;

    @JsonProperty("sumOfExpensesForChildren")
    private String sumOfExpensesForChildren;

    @JsonProperty("sumOfMicroloans")
    private String sumOfMicroloans;

    @JsonProperty("sumOfOtherCredits")
    private String sumOfOtherCredits;

    @JsonProperty("sumOfOtherExpenses")
    private String sumOfOtherExpenses;

    @JsonProperty("sumOfUtilities")
    private String sumOfUtilities;

    @JsonProperty("personalDataLastName")
    private String personalDataLastName;

    public MessageFromKafka() {
    }

    public MessageFromKafka(String additionalIncomeAmount, String orderNumber, String additionalIncomeSource,
                            String allowablePayment, String countOfDependants, String personalDataBirthday,
                            String personalDataPassportDate, String personalDataPassportIssueBy,
                            String personalDataPassportIssuerCode, String personalDataPassportNumber,
                            String personalDataPassportSeries, String email, String familyIncome,
                            String incomeAmount, String incomeSource, String jobCompanyName, String jobCompanyPhone,
                            String jobPhoneExtension, String jobPosition, String realСlientAddressAppartment,
                            String realСlientAddressBuilding, String realСlientAddressCity, String realСlientAddressHouse,
                            String realСlientAddressKorpus, String realСlientAddressRegionName,
                            String realСlientAddressStreet, String maritalStatus, String personalDataFirstName,
                            String personalDataMiddleName, String personalDataMobilePhone, String personalDataBirthplace,
                            String previousSurname, String product, String permanentСlientAddressApartment,
                            String permanentСlientAddressBuilding, String permanentСlientAddressCity,
                            String permanentСlientAddressHouse, String permanentСlientAddressKorpus,
                            boolean realAndPermanentAreSame, String permanentСlientAddressRegionName,
                            String permanentСlientAddressStreet, String restructuringLoanDetails, String restructuringReason,
                            String restructuringReasonOther, String restructuringReasonProductType, String spouseName,
                            String sumOfExpensesForChildren, String sumOfMicroloans, String sumOfOtherCredits,
                            String sumOfOtherExpenses, String sumOfUtilities, String personalDataLastName) {
        this.additionalIncomeAmount = additionalIncomeAmount;
        this.orderNumber = orderNumber;
        this.additionalIncomeSource = additionalIncomeSource;
        this.allowablePayment = allowablePayment;
        this.countOfDependants = countOfDependants;
        this.personalDataBirthday = personalDataBirthday;
        this.personalDataPassportDate = personalDataPassportDate;
        this.personalDataPassportIssueBy = personalDataPassportIssueBy;
        this.personalDataPassportIssuerCode = personalDataPassportIssuerCode;
        this.personalDataPassportNumber = personalDataPassportNumber;
        this.personalDataPassportSeries = personalDataPassportSeries;
        this.email = email;
        this.familyIncome = familyIncome;
        this.incomeAmount = incomeAmount;
        this.incomeSource = incomeSource;
        this.jobCompanyName = jobCompanyName;
        this.jobCompanyPhone = jobCompanyPhone;
        this.jobPhoneExtension = jobPhoneExtension;
        this.jobPosition = jobPosition;
        this.realСlientAddressAppartment = realСlientAddressAppartment;
        this.realСlientAddressBuilding = realСlientAddressBuilding;
        this.realСlientAddressCity = realСlientAddressCity;
        this.realСlientAddressHouse = realСlientAddressHouse;
        this.realСlientAddressKorpus = realСlientAddressKorpus;
        this.realСlientAddressRegionName = realСlientAddressRegionName;
        this.realСlientAddressStreet = realСlientAddressStreet;
        this.maritalStatus = maritalStatus;
        this.personalDataFirstName = personalDataFirstName;
        this.personalDataMiddleName = personalDataMiddleName;
        this.personalDataMobilePhone = personalDataMobilePhone;
        this.personalDataBirthplace = personalDataBirthplace;
        this.previousSurname = previousSurname;
        this.product = product;
        this.permanentСlientAddressApartment = permanentСlientAddressApartment;
        this.permanentСlientAddressBuilding = permanentСlientAddressBuilding;
        this.permanentСlientAddressCity = permanentСlientAddressCity;
        this.permanentСlientAddressHouse = permanentСlientAddressHouse;
        this.permanentСlientAddressKorpus = permanentСlientAddressKorpus;
        this.realAndPermanentAreSame = realAndPermanentAreSame;
        this.permanentСlientAddressRegionName = permanentСlientAddressRegionName;
        this.permanentСlientAddressStreet = permanentСlientAddressStreet;
        this.restructuringLoanDetails = restructuringLoanDetails;
        this.restructuringReason = restructuringReason;
        this.restructuringReasonOther = restructuringReasonOther;
        this.restructuringReasonProductType = restructuringReasonProductType;
        this.spouseName = spouseName;
        this.sumOfExpensesForChildren = sumOfExpensesForChildren;
        this.sumOfMicroloans = sumOfMicroloans;
        this.sumOfOtherCredits = sumOfOtherCredits;
        this.sumOfOtherExpenses = sumOfOtherExpenses;
        this.sumOfUtilities = sumOfUtilities;
        this.personalDataLastName = personalDataLastName;
    }

    public String getAdditionalIncomeAmount() {
        return additionalIncomeAmount;
    }

    public void setAdditionalIncomeAmount(String additionalIncomeAmount) {
        this.additionalIncomeAmount = additionalIncomeAmount;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getAdditionalIncomeSource() {
        return additionalIncomeSource;
    }

    public void setAdditionalIncomeSource(String additionalIncomeSource) {
        this.additionalIncomeSource = additionalIncomeSource;
    }

    public String getAllowablePayment() {
        return allowablePayment;
    }

    public void setAllowablePayment(String allowablePayment) {
        this.allowablePayment = allowablePayment;
    }

    public String getCountOfDependants() {
        return countOfDependants;
    }

    public void setCountOfDependants(String countOfDependants) {
        this.countOfDependants = countOfDependants;
    }

    public String getPersonalDataBirthday() {
        return personalDataBirthday;
    }

    public void setPersonalDataBirthday(String personalDataBirthday) {
        this.personalDataBirthday = personalDataBirthday;
    }

    public String getPersonalDataPassportDate() {
        return personalDataPassportDate;
    }

    public void setPersonalDataPassportDate(String personalDataPassportDate) {
        this.personalDataPassportDate = personalDataPassportDate;
    }

    public String getPersonalDataPassportIssueBy() {
        return personalDataPassportIssueBy;
    }

    public void setPersonalDataPassportIssueBy(String personalDataPassportIssueBy) {
        this.personalDataPassportIssueBy = personalDataPassportIssueBy;
    }

    public String getPersonalDataPassportIssuerCode() {
        return personalDataPassportIssuerCode;
    }

    public void setPersonalDataPassportIssuerCode(String personalDataPassportIssuerCode) {
        this.personalDataPassportIssuerCode = personalDataPassportIssuerCode;
    }

    public String getPersonalDataPassportNumber() {
        return personalDataPassportNumber;
    }

    public void setPersonalDataPassportNumber(String personalDataPassportNumber) {
        this.personalDataPassportNumber = personalDataPassportNumber;
    }

    public String getPersonalDataPassportSeries() {
        return personalDataPassportSeries;
    }

    public void setPersonalDataPassportSeries(String personalDataPassportSeries) {
        this.personalDataPassportSeries = personalDataPassportSeries;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFamilyIncome() {
        return familyIncome;
    }

    public void setFamilyIncome(String familyIncome) {
        this.familyIncome = familyIncome;
    }

    public String getIncomeAmount() {
        return incomeAmount;
    }

    public void setIncomeAmount(String incomeAmount) {
        this.incomeAmount = incomeAmount;
    }

    public String getIncomeSource() {
        return incomeSource;
    }

    public void setIncomeSource(String incomeSource) {
        this.incomeSource = incomeSource;
    }

    public String getJobCompanyName() {
        return jobCompanyName;
    }

    public void setJobCompanyName(String jobCompanyName) {
        this.jobCompanyName = jobCompanyName;
    }

    public String getJobCompanyPhone() {
        return jobCompanyPhone;
    }

    public void setJobCompanyPhone(String jobCompanyPhone) {
        this.jobCompanyPhone = jobCompanyPhone;
    }

    public String getJobPhoneExtension() {
        return jobPhoneExtension;
    }

    public void setJobPhoneExtension(String jobPhoneExtension) {
        this.jobPhoneExtension = jobPhoneExtension;
    }

    public String getJobPosition() {
        return jobPosition;
    }

    public void setJobPosition(String jobPosition) {
        this.jobPosition = jobPosition;
    }

    public String getRealСlientAddressAppartment() {
        return realСlientAddressAppartment;
    }

    public void setRealСlientAddressAppartment(String realСlientAddressAppartment) {
        this.realСlientAddressAppartment = realСlientAddressAppartment;
    }

    public String getRealСlientAddressBuilding() {
        return realСlientAddressBuilding;
    }

    public void setRealСlientAddressBuilding(String realСlientAddressBuilding) {
        this.realСlientAddressBuilding = realСlientAddressBuilding;
    }

    public String getRealСlientAddressCity() {
        return realСlientAddressCity;
    }

    public void setRealСlientAddressCity(String realСlientAddressCity) {
        this.realСlientAddressCity = realСlientAddressCity;
    }

    public String getRealСlientAddressHouse() {
        return realСlientAddressHouse;
    }

    public void setRealСlientAddressHouse(String realСlientAddressHouse) {
        this.realСlientAddressHouse = realСlientAddressHouse;
    }

    public String getRealСlientAddressKorpus() {
        return realСlientAddressKorpus;
    }

    public void setRealСlientAddressKorpus(String realСlientAddressKorpus) {
        this.realСlientAddressKorpus = realСlientAddressKorpus;
    }

    public String getRealСlientAddressRegionName() {
        return realСlientAddressRegionName;
    }

    public void setRealСlientAddressRegionName(String realСlientAddressRegionName) {
        this.realСlientAddressRegionName = realСlientAddressRegionName;
    }

    public String getRealСlientAddressStreet() {
        return realСlientAddressStreet;
    }

    public void setRealСlientAddressStreet(String realСlientAddressStreet) {
        this.realСlientAddressStreet = realСlientAddressStreet;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getPersonalDataFirstName() {
        return personalDataFirstName;
    }

    public void setPersonalDataFirstName(String personalDataFirstName) {
        this.personalDataFirstName = personalDataFirstName;
    }

    public String getPersonalDataMiddleName() {
        return personalDataMiddleName;
    }

    public void setPersonalDataMiddleName(String personalDataMiddleName) {
        this.personalDataMiddleName = personalDataMiddleName;
    }

    public String getPersonalDataMobilePhone() {
        return personalDataMobilePhone;
    }

    public void setPersonalDataMobilePhone(String personalDataMobilePhone) {
        this.personalDataMobilePhone = personalDataMobilePhone;
    }

    public String getPersonalDataBirthplace() {
        return personalDataBirthplace;
    }

    public void setPersonalDataBirthplace(String personalDataBirthplace) {
        this.personalDataBirthplace = personalDataBirthplace;
    }

    public String getPreviousSurname() {
        return previousSurname;
    }

    public void setPreviousSurname(String previousSurname) {
        this.previousSurname = previousSurname;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getPermanentСlientAddressApartment() {
        return permanentСlientAddressApartment;
    }

    public void setPermanentСlientAddressApartment(String permanentСlientAddressApartment) {
        this.permanentСlientAddressApartment = permanentСlientAddressApartment;
    }

    public String getPermanentСlientAddressBuilding() {
        return permanentСlientAddressBuilding;
    }

    public void setPermanentСlientAddressBuilding(String permanentСlientAddressBuilding) {
        this.permanentСlientAddressBuilding = permanentСlientAddressBuilding;
    }

    public String getPermanentСlientAddressCity() {
        return permanentСlientAddressCity;
    }

    public void setPermanentСlientAddressCity(String permanentСlientAddressCity) {
        this.permanentСlientAddressCity = permanentСlientAddressCity;
    }

    public String getPermanentСlientAddressHouse() {
        return permanentСlientAddressHouse;
    }

    public void setPermanentСlientAddressHouse(String permanentСlientAddressHouse) {
        this.permanentСlientAddressHouse = permanentСlientAddressHouse;
    }

    public String getPermanentСlientAddressKorpus() {
        return permanentСlientAddressKorpus;
    }

    public void setPermanentСlientAddressKorpus(String permanentСlientAddressKorpus) {
        this.permanentСlientAddressKorpus = permanentСlientAddressKorpus;
    }

    public boolean isRealAndPermanentAreSame() {
        return realAndPermanentAreSame;
    }

    public void setRealAndPermanentAreSame(boolean realAndPermanentAreSame) {
        this.realAndPermanentAreSame = realAndPermanentAreSame;
    }

    public String getPermanentСlientAddressRegionName() {
        return permanentСlientAddressRegionName;
    }

    public void setPermanentСlientAddressRegionName(String permanentСlientAddressRegionName) {
        this.permanentСlientAddressRegionName = permanentСlientAddressRegionName;
    }

    public String getPermanentСlientAddressStreet() {
        return permanentСlientAddressStreet;
    }

    public void setPermanentСlientAddressStreet(String permanentСlientAddressStreet) {
        this.permanentСlientAddressStreet = permanentСlientAddressStreet;
    }

    public String getRestructuringLoanDetails() {
        return restructuringLoanDetails;
    }

    public void setRestructuringLoanDetails(String restructuringLoanDetails) {
        this.restructuringLoanDetails = restructuringLoanDetails;
    }

    public String getRestructuringReason() {
        return restructuringReason;
    }

    public void setRestructuringReason(String restructuringReason) {
        this.restructuringReason = restructuringReason;
    }

    public String getRestructuringReasonOther() {
        return restructuringReasonOther;
    }

    public void setRestructuringReasonOther(String restructuringReasonOther) {
        this.restructuringReasonOther = restructuringReasonOther;
    }

    public String getRestructuringReasonProductType() {
        return restructuringReasonProductType;
    }

    public void setRestructuringReasonProductType(String restructuringReasonProductType) {
        this.restructuringReasonProductType = restructuringReasonProductType;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }

    public String getSumOfExpensesForChildren() {
        return sumOfExpensesForChildren;
    }

    public void setSumOfExpensesForChildren(String sumOfExpensesForChildren) {
        this.sumOfExpensesForChildren = sumOfExpensesForChildren;
    }

    public String getSumOfMicroloans() {
        return sumOfMicroloans;
    }

    public void setSumOfMicroloans(String sumOfMicroloans) {
        this.sumOfMicroloans = sumOfMicroloans;
    }

    public String getSumOfOtherCredits() {
        return sumOfOtherCredits;
    }

    public void setSumOfOtherCredits(String sumOfOtherCredits) {
        this.sumOfOtherCredits = sumOfOtherCredits;
    }

    public String getSumOfOtherExpenses() {
        return sumOfOtherExpenses;
    }

    public void setSumOfOtherExpenses(String sumOfOtherExpenses) {
        this.sumOfOtherExpenses = sumOfOtherExpenses;
    }

    public String getSumOfUtilities() {
        return sumOfUtilities;
    }

    public void setSumOfUtilities(String sumOfUtilities) {
        this.sumOfUtilities = sumOfUtilities;
    }

    public String getPersonalDataLastName() {
        return personalDataLastName;
    }

    public void setPersonalDataLastName(String personalDataLastName) {
        this.personalDataLastName = personalDataLastName;
    }

    @Override
    public String toString() {
        return "{" +
                "additionalIncomeAmount='" + additionalIncomeAmount + '\'' +
                ", orderNumber='" + orderNumber + '\'' +
                ", additionalIncomeSource='" + additionalIncomeSource + '\'' +
                ", allowablePayment='" + allowablePayment + '\'' +
                ", countOfDependants='" + countOfDependants + '\'' +
                ", personalDataBirthday='" + personalDataBirthday + '\'' +
                ", personalDataPassportDate='" + personalDataPassportDate + '\'' +
                ", personalDataPassportIssueBy='" + personalDataPassportIssueBy + '\'' +
                ", personalDataPassportIssuerCode='" + personalDataPassportIssuerCode + '\'' +
                ", personalDataPassportNumber='" + personalDataPassportNumber + '\'' +
                ", personalDataPassportSeries='" + personalDataPassportSeries + '\'' +
                ", email='" + email + '\'' +
                ", familyIncome='" + familyIncome + '\'' +
                ", incomeAmount='" + incomeAmount + '\'' +
                ", incomeSource='" + incomeSource + '\'' +
                ", jobCompanyName='" + jobCompanyName + '\'' +
                ", jobCompanyPhone='" + jobCompanyPhone + '\'' +
                ", jobPhoneExtension='" + jobPhoneExtension + '\'' +
                ", jobPosition='" + jobPosition + '\'' +
                ", realСlientAddressAppartment='" + realСlientAddressAppartment + '\'' +
                ", realСlientAddressBuilding='" + realСlientAddressBuilding + '\'' +
                ", realСlientAddressCity='" + realСlientAddressCity + '\'' +
                ", realСlientAddressHouse='" + realСlientAddressHouse + '\'' +
                ", realСlientAddressKorpus='" + realСlientAddressKorpus + '\'' +
                ", realСlientAddressRegionName='" + realСlientAddressRegionName + '\'' +
                ", realСlientAddressStreet='" + realСlientAddressStreet + '\'' +
                ", maritalStatus='" + maritalStatus + '\'' +
                ", personalDataFirstName='" + personalDataFirstName + '\'' +
                ", personalDataMiddleName='" + personalDataMiddleName + '\'' +
                ", personalDataMobilePhone='" + personalDataMobilePhone + '\'' +
                ", personalDataBirthplace='" + personalDataBirthplace + '\'' +
                ", previousSurname='" + previousSurname + '\'' +
                ", product='" + product + '\'' +
                ", permanentСlientAddressApartment='" + permanentСlientAddressApartment + '\'' +
                ", permanentСlientAddressBuilding='" + permanentСlientAddressBuilding + '\'' +
                ", permanentСlientAddressCity='" + permanentСlientAddressCity + '\'' +
                ", permanentСlientAddressHouse='" + permanentСlientAddressHouse + '\'' +
                ", permanentСlientAddressKorpus='" + permanentСlientAddressKorpus + '\'' +
                ", realAndPermanentAreSame=" + realAndPermanentAreSame +
                ", permanentСlientAddressRegionName='" + permanentСlientAddressRegionName + '\'' +
                ", permanentСlientAddressStreet='" + permanentСlientAddressStreet + '\'' +
                ", restructuringLoanDetails='" + restructuringLoanDetails + '\'' +
                ", restructuringReason='" + restructuringReason + '\'' +
                ", restructuringReasonOther='" + restructuringReasonOther + '\'' +
                ", restructuringReasonProductType='" + restructuringReasonProductType + '\'' +
                ", spouseName='" + spouseName + '\'' +
                ", sumOfExpensesForChildren='" + sumOfExpensesForChildren + '\'' +
                ", sumOfMicroloans='" + sumOfMicroloans + '\'' +
                ", sumOfOtherCredits='" + sumOfOtherCredits + '\'' +
                ", sumOfOtherExpenses='" + sumOfOtherExpenses + '\'' +
                ", sumOfUtilities='" + sumOfUtilities + '\'' +
                ", personalDataLastName='" + personalDataLastName + '\'' +
                '}';
    }



}
