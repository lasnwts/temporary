package ru.usb.rfr952329.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Date;

@Component
public class ParseDate {

    /**
     * формат даты-времени 2022-02-01T00:00:00
     */
    Date date;
    SimpleDateFormat sdfInput = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    SimpleDateFormat sdfDateOutput = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdfTimeOutput = new SimpleDateFormat("HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ParseDate.class);

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm:ss
     */
    public Date parseDate(String sDate) {
        logger.info(" Дата в запросе :: " + sDate);
        try {
            date = sdfInput.parse(sDate);
            return date;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату :: dd.MM.yyyy HH:mm:ss");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Преобразование даты в строку
     * @param sDate - Date
     * @return - строка
     */
    public String getStrDate(Date sDate) {
        logger.info("Дата :: " + sDate.toString());
        String strDate = sdfDateOutput.format(sDate);
        String strTime = sdfTimeOutput.format(sDate);
        logger.info("Преобразование даты :" + strDate + " в строку нужного формата :: yyyy-MM-dd'T'HH:mm:ss");
        return strDate + "T" + strTime;
    }

    /**
     * Проверка даты
     * @param sDate  даты в виде строки
     * @return - true если парсится номально
     */
    public boolean checkDate(String sDate){
        logger.info("Проверка, что дата в запросе может преобразована:: " + sDate);
        try {
            date = sdfInput.parse(sDate);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = " + sDate + " не соответствует формату :: dd.MM.yyyy HH:mm:ss");
            return false;
        } catch (ParseException e) {
            logger.error("!!Error!print StackTrace", e);
            return false;
        }
    }

}
