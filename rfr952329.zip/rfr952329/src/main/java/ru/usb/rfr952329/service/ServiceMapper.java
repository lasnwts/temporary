package ru.usb.rfr952329.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.rfr952329.dto.RrSite_dto;
import ru.usb.rfr952329.model.RrSiteR;
import ru.usb.rfr952329.utils.ParseDate;

import java.util.Date;

@Service
public class ServiceMapper {

    @Autowired
    ParseDate parseDate;

    /**
     * Маппер объектов DTO - Model
     *
     * @param rrSite_dto - dto
     * @return RrSiteR model
     */
    public RrSiteR mapDtoToModel(RrSite_dto rrSite_dto) {

        if (parseDate.checkDate(rrSite_dto.getDt_create())) {
            RrSiteR rrSiteR = new RrSiteR(rrSite_dto.getOrdernumber(), parseDate.parseDate(rrSite_dto.getDt_create()), rrSite_dto.getXml_data());
            return rrSiteR;
        } else {
            return null;
        }
    }

    /**
     * Маппер объектов DTO - Model
     *
     * @param rrSite_dto - dto
     * @return RrSiteR model
     */
    public RrSiteR mapDtoToModelwithoutDate(RrSite_dto rrSite_dto) {
        RrSiteR rrSiteR = new RrSiteR(rrSite_dto.getOrdernumber(), new Date(), rrSite_dto.getXml_data());
        return rrSiteR;
    }


}
