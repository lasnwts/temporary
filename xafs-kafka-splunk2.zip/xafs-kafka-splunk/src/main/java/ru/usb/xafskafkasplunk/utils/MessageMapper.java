package ru.usb.xafskafkasplunk.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.xafskafkasplunk.model.XafsMessage;
import ru.usb.xafskafkasplunk.model.XafsResponse;

@Component
public class MessageMapper {

    Logger logger = LoggerFactory.getLogger(MessageMapper.class);
    ObjectMapper objectMapper = new ObjectMapper();

    private final AuxMethods aux;

    @Autowired
    public MessageMapper(AuxMethods aux) {
        this.aux = aux;
    }

    /**
     * Преобразование объекта в строку JSON
     *
     * @param xafsMessage объект
     * @return - строка Json
     */
    public String getMessageToXafs(XafsMessage xafsMessage) {

        if (xafsMessage == null) {
            logger.error("UsbLog:=!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:На маппер поступил объект == NULL, Класс [MessageMapper] метод [getMessageToXafs]");
            logger.error("UsbLog:--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

        try {
            return objectMapper.writeValueAsString(xafsMessage);
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:==!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Ошибка преобразования объекта [xafsMessage]] в JSON строку! Класс [MessageMapper] метод [getMessageToXafs]");
            logger.error("UsbLog:Описание ошибки:{}", e.getMessage());
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!==");
            return null;
        }
    }


    public XafsResponse mapApiResponse(String message) {

        if (message == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-+");
            logger.error("UsbLog:На маппер [MessKafkaMapper]:[mapKafkaMessage] поступил объект [message] == NULL! Класс [MessageFromKafka] метод [mapKafkaMessage]");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!--");
            return null;
        }

        XafsResponse xafsResponse = null;

        try {
            xafsResponse = objectMapper.readValue(aux.wrapNullJson(message), XafsResponse.class);
            logger.info("UsbLog:Returned answer, from RestAPI Object [XafsResponse]:{}", xafsResponse);
            return xafsResponse;
        } catch (JsonProcessingException e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Warning : Ошибка при парсинге Json:{}", message);
            logger.error("UsbLog:Warning : StackTrace:", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return null;
        }
    }

}
