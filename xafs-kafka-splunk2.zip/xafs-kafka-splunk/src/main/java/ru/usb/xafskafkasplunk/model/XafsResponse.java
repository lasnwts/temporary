package ru.usb.xafskafkasplunk.model;


import org.springframework.http.HttpStatus;

public class XafsResponse {

    //Поле успеха или ошибки
    //true - успех
    //false - ошибка
    private Boolean errorCode;

    //Тело сообщения
    private String messageBody;

    private int code;
    private HttpStatus httpStatus;

    private String text;

    public XafsResponse() {
        //
    }

    public XafsResponse(Boolean errorCode, String messageBody, int code, HttpStatus httpStatus, String text) {
        this.errorCode = errorCode;
        this.messageBody = messageBody;
        this.code = code;
        this.httpStatus = httpStatus;
        this.text = text;
    }

    public XafsResponse(int code, String text) {
        this.code = code;
        this.text = text;
    }

    public XafsResponse(Boolean errorCode, String messageBody) {
        this.errorCode = errorCode;
        this.messageBody = messageBody;
    }

    public Boolean getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Boolean errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessageBody() {
        return messageBody;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "XafsResponse{" +
                "errorCode=" + errorCode +
                ", messageBody='" + messageBody + '\'' +
                ", code=" + code +
                ", httpStatus=" + httpStatus +
                ", text='" + text + '\'' +
                '}';
    }
}
