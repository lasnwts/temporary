package ru.usb.xafskafkasplunk.service.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import ru.usb.xafskafkasplunk.configure.Configure;
import ru.usb.xafskafkasplunk.model.XafsMessage;
import ru.usb.xafskafkasplunk.service.MessageProcess;
import ru.usb.xafskafkasplunk.service.mail.ServiceMailError;
import ru.usb.xafskafkasplunk.utils.AuxMethods;

import java.io.PrintWriter;
import java.io.StringWriter;


@Configuration
@EnableKafka
public class KafkaListenerService {
    Logger logger = LoggerFactory.getLogger(KafkaListenerService.class);

    private final ServiceMailError serviceMailError;

    private final MessageProcess messageProcess;

    private final AuxMethods aux;

    private final Configure configure;

    @Autowired
    public KafkaListenerService(ServiceMailError serviceMailError, MessageProcess messageProcess, AuxMethods aux, Configure configure) {
        this.serviceMailError = serviceMailError;
        this.messageProcess = messageProcess;
        this.aux = aux;
        this.configure = configure;
    }

    @Value("${service.log.debug:true}")
    private boolean logDebug;

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "${kafka.consumer.topic}", containerFactory = "kafkaListenerContainerFactory")
    public void orderListener(ConsumerRecord<Long, String> recordKafka, Acknowledgment ack) {
        if (logDebug) {
            logger.info("UsbLog:-+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener (record.value)    == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:-++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        } else {
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        /**
         * Сообщение забираем сразу, если поток работает в многопоточном режиме
         * Переменная service.mode=true
         */
        if (configure.isServiceMode()) {
            ack.acknowledge();
        }

        /**
         * Сообщение по Kafka, готовим
         */
        String message;
        message = recordKafka.value();

        if (message == null) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Сообщение из Kafka пришло пустое см. ниже полное описание сообщения!!!");
            logger.info("UsbLog:+++++++++++++++++++++++<Offset:{}>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", recordKafka.offset());
            logger.info("UsbLog:KafkaListener(record.partition) == {}", recordKafka.partition());
            logger.info("UsbLog:KafkaListener(record.key)       == {}", recordKafka.key());
            logger.info("UsbLog:KafkaListener(record.value)     == {}", recordKafka.value());
            logger.info("UsbLog:KafkaListener(topic)            == {}", recordKafka.topic());
            logger.info("UsbLog:KafkaListener(Offset)           == {}", recordKafka.offset());
            logger.info("UsbLog:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            ack.acknowledge();
            serviceMailError.sendMailErrorSubject(configure.getUrlCircuit() + " сервис:" + configure.getAppName() + " Сообщение из Kafka пришло пустое",
                    aux.getWrapNull(recordKafka.value()) + " Topic=" + recordKafka.topic() + " Offset=" + recordKafka.offset());
        } else {
            /**
             * Вызов метода обработки сообщения из Кафка
             */
            try {
                //Работаем в много поточном режиме
                if (configure.isServiceMode()) {
                    messageProcess.processed(new XafsMessage(message, configure.getServiceSourceType()));
                } else {
                    //Работаем в однопоточном режиме
                    if (messageProcess.processOne(new XafsMessage(message, configure.getServiceSourceType()))) {
                        ack.acknowledge();
                    } else {
                        //Если AckMode = true - тогда независимо от результата, всегда подтверждаем сообщение
                        if (configure.isServiceAckMode()) {
                            logger.info("UsbLog: Установлен параметр: [service.ack.mode=true], поэтому сообщение все равно принимаем: ack.acknowledge()");
                            ack.acknowledge();
                        } else {
                            logger.info("UsbLog: Установлен параметр: [service.ack.mode=false], поэтому сообщение не принимаем: ack.nack({})", configure.getServiceWait());
                            ack.nack(configure.getServiceWait());
                        }
                    }
                }
            } catch (Exception e) {
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(Start of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                ack.acknowledge();
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                e.printStackTrace(pw);
                String sStackTrace = sw.toString(); // stack trace as a string
                serviceMailError.sendMailErrorSubject(configure.getUrlCircuit() + " сервис:" + configure.getAppName()
                                + " Возникла ошибка при обработке сообщения [KafkaListenerService] ",
                        "----------------------- Сообщение: ---------------------\n" +
                                aux.getWrapNull(recordKafka.value()) + "\n" +
                                " ------------------- Описание ошибки -----------------::\n"
                                + sStackTrace);
                logger.error("UsbLog:Описание ошибки:", e);
                logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR(end of description)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
        }
    }
}
