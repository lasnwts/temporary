package ru.usb.xafskafkasplunk.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * Класс вспомогательных методов
 */
@Component
public class AuxMethods {
    Logger logger = LoggerFactory.getLogger(AuxMethods.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Исключение пустых полей из сообщения SD
     * Как пример: "init_sapid": , замена на "init_sapid": "",
     * -------------------------------------------------------
     *
     * @param message - строка
     * @return
     */
    public String wrapNullJson(String message) {
        String messagePrepared = null;
        if (message == null) {
            return "";
        }
        if (message.contains(": ,") || message.contains(":,") || message.contains(":  ,") || message.contains(":   ,")) {
            logger.info("UsbLog:Сообщение содержит пустое значение в поле, что делает невозможным его распознавание[: ,]");
            logger.info("UsbLog:Сообщение будет модифицировано - значение =[: ,], будет заменено на строковое пустое, знак двойной кавычки");
            logger.info("UsbLog:Входящее сообщение, до модификации [message]:{}", message);
            messagePrepared = message.replace(": ,", ":\"\",").replace(":,", ":\"\",").replace(":  ,", ":\"\",").replace(":   ,", ":\"\",");
            logger.info("UsbLog:Обработанное сообщение [message]:{}", messagePrepared);
            return messagePrepared;
        } else {
            return message;
        }
    }

}
