package ru.usb.xafskafkasplunk.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class XafsMessage {

    @JsonProperty("event")
    private String event;

    @JsonProperty("sourcetype")
    private String sourcetype;

    public XafsMessage() {
        //
    }
    public XafsMessage(String event, String sourcetype) {
        this.event = event;
        this.sourcetype = sourcetype;
    }

    @JsonProperty("event")
    public String getEvent() {
        return event;
    }

    @JsonProperty("event")
    public void setEvent(String event) {
        this.event = event;
    }

    @JsonProperty("sourcetype")
    public String getSourcetype() {
        return sourcetype;
    }

    @JsonProperty("sourcetype")
    public void setSourcetype(String sourcetype) {
        this.sourcetype = sourcetype;
    }

    @Override
    public String toString() {
        return "XafsMessage{" +
                "event='" + event + '\'' +
                ", sourcetype='" + sourcetype + '\'' +
                '}';
    }
}
