package ru.usb.put_statuses_cft.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.put_statuses_cft.config.Config;
import ru.usb.put_statuses_cft.config.LG;

@RestController
@RequestMapping("/api/admin")
@Tag(name = "Контроллер для управления сервисом", description = "Управление")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);
    private final Config configure;

    @Autowired
    public ApiController(Config configure) {
        this.configure = configure;
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/set/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@PathVariable("enabled") boolean enabled) {
        configure.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + configure.isServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Включение/отключение Рабочего времени сервиса
     */
    @PutMapping(value = "/work-time/{enabled}")
    @Operation(summary = "Включить рабочее время/отключить рабочее время. В рабочее время сервис может передавать сообщения в ЦФТ.")
    public ResponseEntity<String> setWorkTimeService(@PathVariable("enabled") boolean enabled) {
        configure.setWorkTime(enabled);
        if (enabled) {
            logger.info("{}:[set Work Time Service = TRUE] Web API. Рабочее время включено.", LG.USBLOGINFO);
        } else {
            logger.info("{}:[set Work Time Service = FALSE] Web API. Рабочее время сервиса - выключено.", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Set Work Time Service =:" + configure.isWorkTime(), HttpStatus.OK);
    }

    @GetMapping(value = "/status")
    @Operation(summary = "Посмотреть статус работы сервиса")
    public ResponseEntity<String> getStatus(){
        String response = "Service enabled:" + configure.isServiceEnabled() + "\n" +
                "Work time:" + configure.isWorkTime() + "\n";
        logger.info("{}:[getStatus] Web API. Service status: {}", LG.USBLOGINFO, response);
        return new ResponseEntity<>("Статус сервиса:\n" + response, HttpStatus.OK);
    }

}
