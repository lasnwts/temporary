package ru.usb.put_statuses_cft.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * Информация о клиенте ЮЛ
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Client {

    /**
     * Пример XML взят из письма Сергея Будылина.
     * Письмо приведено выше в требованиях заказчика. В примере XML состоит из двух записей,
     * но вероятнее всего надо делать сообщения по одной записи.
     * ======================================================================================
     *                     <CLIENT>
     *                            <INN>0987654321</INN>
     *                            <OGRN>32456</OGRN>
     *                            <KPP>87564637</KPP>
     *                            <NameP>Продам слона</NameP>
     *                            <NameS>Продам Слона</NameS>
     *                            <StatusLiqID>345678</StatusLiqID>
     *                            <StatusLiq>АВЫЛАВЫАВЫ</StatusLiq>
     *                            <DStart>01.01.2024</DStart>
     *                            <DataPrekrUL></DataPrekrUL>
     *                            <OKATO>33333</OKATO>
     *                            <Index>44444</Index>
     *                            <RegionName>РБ</RegionName>
     *                            <RaionName>кировский</RaionName>
     *                            <GorodName>Уфа</GorodName>
     *                            <NasPunktName>Уфа</NasPunktName>
     *                            <StreetName>Кольцеваяя</StreetName>
     *                            <Dom>1</Dom>
     *                            <Korp>2</Korp>
     *                            <Kvart>3</Kvart>
     *                     </CLIENT>
     */

    @JsonProperty(value = "INN", required = true)
    private String inn;
    @JsonProperty(value = "OGRN", required = true)
    private String ogrn;
    @JsonProperty(value = "KPP")
    private String kpp;
    @JsonProperty(value = "NameP")
    private String nameP;
    @JsonProperty(value = "NameS")
    private String nameS;
    @JsonProperty(value = "StatusLiqID")
    private String statusLiqID;
    @JsonProperty(value = "StatusLiq")
    private String statusLiq;
    @JsonProperty(value = "DStart")
    private String dStart;
    @JsonProperty(value = "DataPrekrUL")
    private String dataPrekrUL;
    @JsonProperty(value = "OKATO")
    private String okato;
    @JsonProperty(value = "Index")
    private String index;
    @JsonProperty(value = "RegionName")
    private String regionName;
    @JsonProperty(value = "RaionName")
    private String raionName;
    @JsonProperty(value = "GorodName")
    private String gorodName;
    @JsonProperty(value = "NasPunktName")
    private String nasPunktName;
    @JsonProperty(value = "StreetName")
    private String streetName;
    @JsonProperty(value = "Dom")
    private String dom;
    @JsonProperty(value = "Korp")
    private String korp;
    @JsonProperty(value = "Kvart")
    private String kvart;

    public Client() {
        //
    }

    public Client(String inn, String ogrn, String kpp, String nameP, String nameS,
                  String statusLiqID, String statusLiq, String dStart, String dataPrekrUL,
                  String okato, String index, String regionName, String raionName,
                  String gorodName, String nasPunktName, String streetName, String dom,
                  String korp, String kvart) {
        this.inn = inn;
        this.ogrn = ogrn;
        this.kpp = kpp;
        this.nameP = nameP;
        this.nameS = nameS;
        this.statusLiqID = statusLiqID;
        this.statusLiq = statusLiq;
        this.dStart = dStart;
        this.dataPrekrUL = dataPrekrUL;
        this.okato = okato;
        this.index = index;
        this.regionName = regionName;
        this.raionName = raionName;
        this.gorodName = gorodName;
        this.nasPunktName = nasPunktName;
        this.streetName = streetName;
        this.dom = dom;
        this.korp = korp;
        this.kvart = kvart;
    }

    @Override
    public String toString() {
        return "Client{" +
                "inn='" + inn + '\'' +
                ", ogrn='" + ogrn + '\'' +
                ", kpp='" + kpp + '\'' +
                ", nameP='" + nameP + '\'' +
                ", nameS='" + nameS + '\'' +
                ", statusLiqID='" + statusLiqID + '\'' +
                ", statusLiq='" + statusLiq + '\'' +
                ", dStart=" + dStart +
                ", dataPrekrUL='" + dataPrekrUL + '\'' +
                ", okato='" + okato + '\'' +
                ", index=" + index +
                ", regionName='" + regionName + '\'' +
                ", raionName='" + raionName + '\'' +
                ", gorodName='" + gorodName + '\'' +
                ", nasPunktName='" + nasPunktName + '\'' +
                ", streetName='" + streetName + '\'' +
                ", dom='" + dom + '\'' +
                ", korp='" + korp + '\'' +
                ", kvart='" + kvart + '\'' +
                '}';
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getKpp() {
        return kpp;
    }

    public void setKpp(String kpp) {
        this.kpp = kpp;
    }

    public String getNameP() {
        return nameP;
    }

    public void setNameP(String nameP) {
        this.nameP = nameP;
    }

    public String getNameS() {
        return nameS;
    }

    public void setNameS(String nameS) {
        this.nameS = nameS;
    }

    public String getStatusLiqID() {
        return statusLiqID;
    }

    public void setStatusLiqID(String statusLiqID) {
        this.statusLiqID = statusLiqID;
    }

    public String getStatusLiq() {
        return statusLiq;
    }

    public void setStatusLiq(String statusLiq) {
        this.statusLiq = statusLiq;
    }

    public String getdStart() {
        return dStart;
    }

    public void setdStart(String dStart) {
        this.dStart = dStart;
    }

    public String getDataPrekrUL() {
        return dataPrekrUL;
    }

    public void setDataPrekrUL(String dataPrekrUL) {
        this.dataPrekrUL = dataPrekrUL;
    }

    public String getOkato() {
        return okato;
    }

    public void setOkato(String okato) {
        this.okato = okato;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getRaionName() {
        return raionName;
    }

    public void setRaionName(String raionName) {
        this.raionName = raionName;
    }

    public String getGorodName() {
        return gorodName;
    }

    public void setGorodName(String gorodName) {
        this.gorodName = gorodName;
    }

    public String getNasPunktName() {
        return nasPunktName;
    }

    public void setNasPunktName(String nasPunktName) {
        this.nasPunktName = nasPunktName;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getDom() {
        return dom;
    }

    public void setDom(String dom) {
        this.dom = dom;
    }

    public String getKorp() {
        return korp;
    }

    public void setKorp(String korp) {
        this.korp = korp;
    }

    public String getKvart() {
        return kvart;
    }

    public void setKvart(String kvart) {
        this.kvart = kvart;
    }
}
