package ru.usb.put_statuses_cft.repository;

import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.put_statuses_cft.model.db.DwhRecord;

import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface DwhRecordRepo extends JpaRepository<DwhRecord, Long> {

    //Функция возвращает список всех записей -- Графики кредитных каникул: Запрос вложений по HOLIDAYS_ID
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = """
            select distinct ul.SVYUL_INN as inn-- ИНН ЮЛ
            ,ul.SVYUL_OGRN as ogrn-- ОГРН ЮЛ
            ,ul.SVYUL_KPP as kpp--КПП ЮЛ
            ,ul.SVYUL_SVNAIMYUL_NAIMYULPOLN as namep --Полное наименование ЮЛ
            ,ul.SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as names --Краткое наименование ЮЛ
            ,ul.SVYUL_SVPREKRYUL_SPPREKRYUL_KODSPPREKRYUL as status_liquidation_inner_id --Статус ЮЛ (внутренний идентификатор)
            ,ul.SVYUL_SVPREKRYUL_SPPREKRYUL_NAIMSPPREKRYUL as status_liquidation
            ,ul.SVYUL_SVPREKRYUL_GRNDATA_DATAZAPISI as dtstart -- Дата присвоения статуса
            ,ul.SVYUL_SVPREKRYUL_DATAPREKRYUL as dataprekrul-- Дата прекращения деятельности
            ,ul.SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as okato
            ,ul.SVYUL_SVADRESYUL_ADRESRF_INDEKS as indeks--  Индекс
            ,ul.SVYUL_SVADRESYUL_ADRESRF_REGION_NAIMREGION as region_name-- Наименование региона
            ,ul.SVYUL_SVADRESYUL_ADRESRF_RAYON_NAIMRAYON as raion_name--   Наименование района
            ,ul.SVYUL_SVADRESYUL_ADRESRF_GOROD_NAIMGOROD as gorod_name--   Наименование города
            ,ul.SVYUL_SVADRESYUL_ADRESRF_NASELPUNKT_NAIMNASELPUNKT as naspunkt_name--  Наименование населенного пункта
            ,ul.SVYUL_SVADRESYUL_ADRESRF_ULITSA_NAIMULITSA as street_name-- Адрес ЮЛ - Улица
            ,ul.SVYUL_SVADRESYUL_ADRESRF_DOM as dom--  Адрес ЮЛ - Дом
            ,ul.SVYUL_SVADRESYUL_ADRESRF_KORPUS as korp--   Адрес ЮЛ - Корпус
            ,ul.SVYUL_SVADRESYUL_ADRESRF_KVART as kvart-- Адрес ЮЛ - Квартира
             from ODS_FNS_EGRUL_SVYUL ul
            """)
    Stream<DwhRecord> getStreamFromDwh();

    //Функция возвращает список всех записей -- Графики кредитных каникул: Запрос вложений по HOLIDAYS_ID
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = """            
            select distinct ul.SVYUL_INN as inn-- ИНН ЮЛ
            ,ul.SVYUL_OGRN as ogrn-- ОГРН ЮЛ
            ,ul.SVYUL_KPP as kpp--КПП ЮЛ
            ,ul.SVYUL_SVNAIMYUL_NAIMYULPOLN as namep --Полное наименование ЮЛ
            ,ul.SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as names --Краткое наименование ЮЛ
            ,ul.SVYUL_SVPREKRYUL_SPPREKRYUL_KODSPPREKRYUL as status_liquidation_inner_id --Статус ЮЛ (внутренний идентификатор)
            ,ul.SVYUL_SVPREKRYUL_SPPREKRYUL_NAIMSPPREKRYUL as status_liquidation
            ,ul.SVYUL_SVPREKRYUL_GRNDATA_DATAZAPISI as dtstart -- Дата присвоения статуса
            ,ul.SVYUL_SVPREKRYUL_DATAPREKRYUL as dataprekrul-- Дата прекращения деятельности
            ,ul.SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as okato
            ,ul.SVYUL_SVADRESYUL_ADRESRF_INDEKS as indeks--  Индекс
            ,ul.SVYUL_SVADRESYUL_ADRESRF_REGION_NAIMREGION as region_name-- Наименование региона
            ,ul.SVYUL_SVADRESYUL_ADRESRF_RAYON_NAIMRAYON as raion_name--   Наименование района
            ,ul.SVYUL_SVADRESYUL_ADRESRF_GOROD_NAIMGOROD as gorod_name--   Наименование города
            ,ul.SVYUL_SVADRESYUL_ADRESRF_NASELPUNKT_NAIMNASELPUNKT as naspunkt_name--  Наименование населенного пункта
            ,ul.SVYUL_SVADRESYUL_ADRESRF_ULITSA_NAIMULITSA as street_name-- Адрес ЮЛ - Улица
            ,ul.SVYUL_SVADRESYUL_ADRESRF_DOM as dom--  Адрес ЮЛ - Дом
            ,ul.SVYUL_SVADRESYUL_ADRESRF_KORPUS as korp--   Адрес ЮЛ - Корпус
            ,ul.SVYUL_SVADRESYUL_ADRESRF_KVART as kvart-- Адрес ЮЛ - Квартира
             from ODS_FNS_EGRUL_SVYUL ul
            """)
    List<DwhRecord> getListFromDwh();
}
