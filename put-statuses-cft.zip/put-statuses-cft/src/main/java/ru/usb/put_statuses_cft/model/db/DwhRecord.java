package ru.usb.put_statuses_cft.model.db;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

import java.util.Date;

@Entity
@Immutable
@Subselect(
        """
 select distinct ul.SVYUL_INN as inn-- ИНН ЮЛ
,ul.SVYUL_OGRN as ogrn-- ОГРН ЮЛ
,ul.SVYUL_KPP as kpp--КПП ЮЛ
,ul.SVYUL_SVNAIMYUL_NAIMYULPOLN as namep --Полное наименование ЮЛ
,SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as names --Краткое наименование ЮЛ
,SVYUL_SVPREKRYUL_SPPREKRYUL_KODSPPREKRYUL as status_liquidation_inner_id --Статус ЮЛ (внутренний идентификатор)
,SVYUL_SVPREKRYUL_SPPREKRYUL_NAIMSPPREKRYUL as status_liquidation
,SVYUL_SVPREKRYUL_GRNDATA_DATAZAPISI as dtstart -- Дата присвоения статуса
,ul.SVYUL_SVPREKRYUL_DATAPREKRYUL as dataprekrul-- Дата прекращения деятельности
,ul.SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as okato
,ul.SVYUL_SVADRESYUL_ADRESRF_INDEKS as indeks--  Индекс
,ul.SVYUL_SVADRESYUL_ADRESRF_REGION_NAIMREGION as region_name-- Наименование региона
,ul.SVYUL_SVADRESYUL_ADRESRF_RAYON_NAIMRAYON as raion_name--   Наименование района
,ul.SVYUL_SVADRESYUL_ADRESRF_GOROD_NAIMGOROD as gorod_name--   Наименование города
,ul.SVYUL_SVADRESYUL_ADRESRF_NASELPUNKT_NAIMNASELPUNKT as naspunkt_name--  Наименование населенного пункта
,ul.SVYUL_SVADRESYUL_ADRESRF_ULITSA_NAIMULITSA as street_name-- Адрес ЮЛ - Улица
,ul.SVYUL_SVADRESYUL_ADRESRF_DOM as dom--  Адрес ЮЛ - Дом
,ul.SVYUL_SVADRESYUL_ADRESRF_KORPUS as korp--   Адрес ЮЛ - Корпус
,ul.SVYUL_SVADRESYUL_ADRESRF_KVART as kvart-- Адрес ЮЛ - Квартира
 from ODS_FNS_EGRUL_SVYUL ul where rownum=1"""
)
public class DwhRecord {

    /**
     *ul.SVYUL_INN as inn-- ИНН ЮЛ
     * ,ul.SVYUL_OGRN as ogrn-- ОГРН ЮЛ
     * ,ul.SVYUL_KPP as kpp--КПП ЮЛ
     * ,ul.SVYUL_SVNAIMYUL_NAIMYULPOLN as namep --Полное наименование ЮЛ
     * ,nvl(SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR,ul.SVYUL_SVNAIMYUL_NAIMYULSOKR) as names --Краткое наименование ЮЛ
     * ,SVYUL_SVPREKRYUL_SPPREKRYUL_KODSPPREKRYUL as status_liquidation_inner_id --Статус ЮЛ (внутренний идентификатор)
     * ,SVYUL_SVPREKRYUL_SPPREKRYUL_NAIMSPPREKRYUL as status_liquidation
     * ,SVYUL_SVPREKRYUL_GRNDATA_DATAZAPISI as dtstart -- Дата присвоения статуса
     * ,ul.SVYUL_SVPREKRYUL_DATAPREKRYUL as dataprekrul-- Дата прекращения деятельности
     * ,SVYUL_SVNAIMYUL_SVNAIMYULSOKR_NAIMSOKR as okato  ОКАТО
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_INDEKS as indeks--  Индекс
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_REGION_NAIMREGION as region_name-- Наименование региона
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_RAYON_NAIMRAYON as raion_name--   Наименование района
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_GOROD_NAIMGOROD as gorod_name--   Наименование города
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_NASELPUNKT_NAIMNASELPUNKT as naspunkt_name--  Наименование населенного пункта
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_ULITSA_NAIMULITSA as street_name-- Адрес ЮЛ - Улица
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_DOM as dom--  Адрес ЮЛ - Дом
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_KORPUS as korp--   Адрес ЮЛ - Корпус
     * ,ul.SVYUL_SVADRESYUL_ADRESRF_KVART as kvart-- Адрес ЮЛ - Квартира
     */

    @Id
    private String inn;
    private String ogrn;
    private String kpp;
    private String namep;
    private String names;
    private String status_liquidation_inner_id;
    private String status_liquidation;
    private Date dtstart;
    private Date dataprekrul;
    private String okato;
    private String indeks;
    private String region_name;
    private String raion_name;
    private String gorod_name;
    private String naspunkt_name;
    private String street_name;
    private String dom;
    private String korp;
    private String kvart;

    public DwhRecord(String inn, String ogrn, String kpp, String namep, String names,
                     String status_liquidation_inner_id, String status_liquidation, Date dtstart,
                     Date dataprekrul, String okato, String indeks, String region_name,
                     String raion_name, String gorod_name, String naspunkt_name, String street_name,
                     String dom, String korp, String kvart) {
        this.inn = inn;
        this.ogrn = ogrn;
        this.kpp = kpp;
        this.namep = namep;
        this.names = names;
        this.status_liquidation_inner_id = status_liquidation_inner_id;
        this.status_liquidation = status_liquidation;
        this.dtstart = dtstart;
        this.dataprekrul = dataprekrul;
        this.okato = okato;
        this.indeks = indeks;
        this.region_name = region_name;
        this.raion_name = raion_name;
        this.gorod_name = gorod_name;
        this.naspunkt_name = naspunkt_name;
        this.street_name = street_name;
        this.dom = dom;
        this.korp = korp;
        this.kvart = kvart;
    }

    public DwhRecord() {
        //
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getKpp() {
        return kpp;
    }

    public void setKpp(String kpp) {
        this.kpp = kpp;
    }

    public String getNamep() {
        return namep;
    }

    public void setNamep(String namep) {
        this.namep = namep;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getStatus_liquidation_inner_id() {
        return status_liquidation_inner_id;
    }

    public void setStatus_liquidation_inner_id(String status_liquidation_inner_id) {
        this.status_liquidation_inner_id = status_liquidation_inner_id;
    }

    public String getStatus_liquidation() {
        return status_liquidation;
    }

    public void setStatus_liquidation(String status_liquidation) {
        this.status_liquidation = status_liquidation;
    }

    public Date getDtstart() {
        return dtstart;
    }

    public void setDtstart(Date dtstart) {
        this.dtstart = dtstart;
    }

    public Date getDataprekrul() {
        return dataprekrul;
    }

    public void setDataprekrul(Date dataprekrul) {
        this.dataprekrul = dataprekrul;
    }

    public void setStreet_name(String street_name) {
        this.street_name = street_name;
    }

    public String getOkato() {
        return okato;
    }

    public void setOkato(String okato) {
        this.okato = okato;
    }

    public String getIndeks() {
        return indeks;
    }

    public void setIndeks(String indeks) {
        this.indeks = indeks;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getRaion_name() {
        return raion_name;
    }

    public void setRaion_name(String raion_name) {
        this.raion_name = raion_name;
    }

    public String getGorod_name() {
        return gorod_name;
    }

    public void setGorod_name(String gorod_name) {
        this.gorod_name = gorod_name;
    }

    public String getNaspunkt_name() {
        return naspunkt_name;
    }

    public void setNaspunkt_name(String naspunkt_name) {
        this.naspunkt_name = naspunkt_name;
    }

    public String getStreet_name() {
        return street_name;
    }

    public void setStreetName(String street_name) {
        this.street_name = street_name;
    }

    public String getDom() {
        return dom;
    }

    public void setDom(String dom) {
        this.dom = dom;
    }

    public String getKorp() {
        return korp;
    }

    public void setKorp(String korp) {
        this.korp = korp;
    }

    public String getKvart() {
        return kvart;
    }

    public void setKvart(String kvart) {
        this.kvart = kvart;
    }

    @Override
    public String toString() {
        return "DwhRecord{" +
                "inn='" + inn + '\'' +
                ", ogrn='" + ogrn + '\'' +
                ", kpp='" + kpp + '\'' +
                ", namep='" + namep + '\'' +
                ", names='" + names + '\'' +
                ", status_liquidation_inner_id='" + status_liquidation_inner_id + '\'' +
                ", status_liquidation='" + status_liquidation + '\'' +
                ", dtstart='" + dtstart + '\'' +
                ", dataprekrul='" + dataprekrul + '\'' +
                ", okato='" + okato + '\'' +
                ", indeks='" + indeks + '\'' +
                ", region_name='" + region_name + '\'' +
                ", raion_name='" + raion_name + '\'' +
                ", gorod_name='" + gorod_name + '\'' +
                ", naspunkt_name='" + naspunkt_name + '\'' +
                ", street_name='" + street_name + '\'' +
                ", dom='" + dom + '\'' +
                ", korp='" + korp + '\'' +
                ", kvart='" + kvart + '\'' +
                '}';
    }
}
