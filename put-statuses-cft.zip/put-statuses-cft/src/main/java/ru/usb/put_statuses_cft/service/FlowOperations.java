package ru.usb.put_statuses_cft.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.put_statuses_cft.config.Config;
import ru.usb.put_statuses_cft.config.LG;
import ru.usb.put_statuses_cft.model.db.DwhRecord;
import ru.usb.put_statuses_cft.repository.DwhRecordRepo;
import ru.usb.put_statuses_cft.repository.DwhRepository;
import ru.usb.put_statuses_cft.service.kafka.KafkaProducerService;
import ru.usb.put_statuses_cft.service.mail.ServiceMailError;
import ru.usb.put_statuses_cft.utils.CftXml;
import ru.usb.put_statuses_cft.utils.DbMapper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Stream;

@Service
public class FlowOperations {

    Logger logger = LoggerFactory.getLogger(FlowOperations.class);

    int lineCount; //Общее Количество сообщений
    int lineCountMessage; //Количество сообщений для отправки
    String bodyMessage = ""; //Тело сообщения

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy_HH:mm:ss");

    private final DwhRepository dwhRepository;
    private final DwhRecordRepo dwhRecordRepo;
    private final Config config;
    private final EntityManager entityManager;
    private final CftXml cftXml;
    private final DbMapper dbMapper;
    private final KafkaProducerService kafkaProducerService;
    private final ServiceMailError serviceMailError;

    @Autowired
    public FlowOperations(DwhRepository dwhRepository, DwhRecordRepo dwhRecordRepo, Config config,
                          EntityManager entityManager, CftXml cftXml, DbMapper dbMapper,
                          KafkaProducerService kafkaProducerService, ServiceMailError serviceMailError) {
        this.dwhRepository = dwhRepository;
        this.dwhRecordRepo = dwhRecordRepo;
        this.config = config;
        this.entityManager = entityManager;
        this.cftXml = cftXml;
        this.dbMapper = dbMapper;
        this.kafkaProducerService = kafkaProducerService;
        this.serviceMailError = serviceMailError;
    }

    /**
     * Проверка флага готовности потока ЦХД
     *
     * @return - true, если поток готов к запуску
     */
    public boolean checkFlagReadyFlow() {
        try {
            int flagReady = dwhRepository.getFlagReady();
            return flagReady > 0;
        } catch (Exception exception) {
            logger.error("{}: Ошибка при получении флага готовности потока ЦХД: {}", LG.USBLOGERROR, exception.getMessage());
            return false;
        }
    }

    /**
     * Запуск основного потока
     */
    @Transactional
    public boolean startFlow() {
        logger.info("{}: Выгрузка данных из ЦХД в Кафка запущена. [startFlow]", LG.USBLOGINFO);
        //Сначала выключаем сервис т.е. выгрузка запрещена
        config.setWorkTime(false); //Выключаем время работы сервиса
        //Получаем список записей из базы
        Stream<DwhRecord> fTableStream;

        try {
            fTableStream = dwhRecordRepo.getStreamFromDwh();
            if (fTableStream == null) {
                logger.error("{} fTableStream = dwhRecordRepo.getStreamFromDwh() - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return false;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = dwhRecordRepo.getStreamFromDwh()", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return false;
        }
        lineCount = 0; //Обнулили счетчик записей, строк
        lineCountMessage = 0; //Обнуляем число сообщений перед отправкой
        try {
            fTableStream.forEach(fTable -> {
                if (fTable != null) {
                    lineCount = lineCount + 1; //Подсчитываем число записей в файле
                    lineCountMessage = lineCountMessage + 1; //Считаем число сообщений, в конкретной отправке
                    try {
                        String xml = cftXml.getClientUpper(cftXml.getSerialize(dbMapper.mapClient(fTable)));
                        logger.info("XML:  {}", xml);
                        //Отправляем сообщение тут....
                        bodyMessage = bodyMessage + xml;
                    } catch (Exception e) {
                        logger.error("{}", e.getMessage());
                    }
                }
                entityManager.detach(fTable);

                //Проверяем, что готовы отправлять......
                if (lineCountMessage >= config.getMessageCount()) {
                    lineCountMessage = 0; //Обнуляем число
                    logger.info("{}:Обработано записей:{}, отправляем сообщение в ЦФТ.", LG.USBLOGINFO, lineCount);
                    if (!kafkaProducerService.sendMessage(config.getCftTopic(), getKey(lineCount), cftXml.prepareXml(bodyMessage))) {
                        logger.error("{}: Ошибка отправки сообщения в топик:{} ", LG.USBLOGERROR, config.getCftTopic());
                    }
                    bodyMessage = ""; //Сообщения удаляем..
                }
            });
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = dwhRecordRepo.getStreamFromDwh(fTableStream.forEach(fTable):{}", LG.USBLOGERROR, e.getMessage());
            logger.debug("{}", LG.USBLOGERROR, e);
            serviceMailError.sendMailBusinessSubjectCheck("put-statuses-cft. МП 971797 Получение данных в ЦФТ-Банк о статусах ЮЛ в ЕГРЮЛ путем интеграции с ЦХД",
                    "Возникла ошибка при получении данных из базы ЦХД. [fTableStream.forEach] \n" + e.getMessage());
            serviceMailError.sendMailErrorSubject("put-statuses-cft. МП 971797 Получение данных в ЦФТ-Банк о статусах ЮЛ в ЕГРЮЛ путем интеграции с ЦХД",
                    "Возникла ошибка при получении данных из базы ЦХД. [fTableStream.forEach] \n" + e.getMessage());
            return false;
        } finally {
            fTableStream.close();
        }
        //Отправляем остаток сообщений
        if (lineCountMessage > 0) {
            logger.info("{}:Обработано записей:{}, последняя порция:{}, отправляем сообщение в ЦФТ.", LG.USBLOGINFO, lineCount, lineCountMessage);
            if (!kafkaProducerService.sendMessage(config.getCftTopic(), getKey(lineCount), cftXml.prepareXml(bodyMessage))) {
                logger.error("{}: Ошибка отправки последней порции, сообщений в топик:{} ", LG.USBLOGERROR, config.getCftTopic());
            }
            lineCountMessage = 0; //Обнуляем число
            bodyMessage = null; //Сообщения удаляем
        }
        return true; //Все успешно
    }


    /**
     * Получение ключа сообщения
     *
     * @param i - номер записи
     * @return - ключ сообщения
     */
    private String getKey(int i) {
        return String.format("%s_%s", i, sdf.format(new Date()));
    }


}
