package ru.usb.put_statuses_cft.model;

import java.util.List;

/**
 * Обертка для тела сообщения в Кафка для ЦФТ.
 */
public class Body {

    private List<Client> clients;

    public Body() {
        //
    }

    public Body(List<Client> clients) {
        this.clients = clients;
    }

    public List<Client> getClients() {
        return clients;
    }

    public void setClients(List<Client> clients) {
        this.clients = clients;
    }
}
