package ru.usb.put_statuses_cft.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Класс для парсинга XML сообщения
 */
public class CFTxml {
    @JsonProperty(value = "BODY", required = true)
    Body body;

    public CFTxml(Body body) {
        this.body = body;
    }

    public CFTxml() {
        //
    }

    public Body getBody() {
        return body;
    }

    public void setBody(Body body) {
        this.body = body;
    }
}
