package ru.usb.put_statuses_cft;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.put_statuses_cft.config.LG;

@SpringBootApplication
public class PutStatusesCftApplication implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(PutStatusesCftApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(PutStatusesCftApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${spring.application.name}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r Service [Микросервис: put-statuses-cft] Интеграционный поток.  МП 971797.")
                .contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
                .version(appVersion)
                .description("API для [Интеграционный поток.МП 971797 Получение данных в ЦФТ-Банк о статусах ЮЛ в ЕГРЮЛ путем интеграции с ЦХД.]" +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : put-statuses-cft", LG.USBLOGINFO);
        logger.info("{}:| Description of service       : Интеграционный поток. МП 971797 Получение данных в ЦФТ-Банк о статусах ЮЛ в ЕГРЮЛ путем интеграции с ЦХД.", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 25/03/2025", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                  25.03.2025  : 0.0.10 Базовая версия.", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("..");
        logger.info(".");
    }
}
