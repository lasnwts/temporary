package ru.usb.put_statuses_cft.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CftXml {

    Logger logger = LoggerFactory.getLogger(CftXml.class);

    JacksonXmlModule module = new JacksonXmlModule();
    XmlMapper mapper = new XmlMapper(module);
    ObjectMapper objectMapper = new ObjectMapper();

    public String getSerialize(Object object) {

        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
        String xml = null;
        try {
            xml = mapper.writeValueAsString(object);
        } catch (Exception e) {
            logger.error("USBLOGERROR:ERROR: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("USBLOGERROR:ERROR: CftXml:getSerialize:xml = mapper.writeValueAsString(object)");
            logger.error("USBLOGERROR:ERROR: CftXml:getSerialize:Неудачное преобразование объекта в строку= NULL!!");
            logger.error("USBLOGERROR:ERROR: CftXml:getSerialize:object:{}", object);
            logger.error("USBLOGERROR:ERROR: CftXml:getSerialize:Exception:{}", e.getMessage());
            logger.error("USBLOGERROR:ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }
        return xml;
    }

    /**
     * Замена тега <Client> на <CLIENT> и </Client> на </CLIENT>
     * @param xml - строка с xml
     * @return - строка с xml
     */
    public String getClientUpper(String xml){
        return xml.replace("<Client>", "<CLIENT>").replace("</Client>", "</CLIENT>");
    }

    /**
     * Записываем начало и конце XML сообщения
     * @param bodyMessage - строка с xml
     * @return - строка с заголовками
     */
    public String prepareXml(String bodyMessage) {
        String s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<BODY>\n" + bodyMessage + "\n</BODY>";
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<BODY>\n" + bodyMessage + "\n</BODY>";
    }

}
