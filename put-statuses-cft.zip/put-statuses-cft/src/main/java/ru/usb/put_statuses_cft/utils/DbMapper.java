package ru.usb.put_statuses_cft.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.put_statuses_cft.model.Client;
import ru.usb.put_statuses_cft.model.db.DwhRecord;

import java.text.SimpleDateFormat;

/**
 * Маппер из записи БД в объект клиента
 */

@Component
public class DbMapper {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    Logger logger = LoggerFactory.getLogger(DbMapper.class);

    public Client mapClient(DwhRecord dwhRecord) {

        /**
         *     private String inn;
         *     private String ogrn;
         *     private String kpp;
         *     private String namep;
         *     private String names;
         *     private String status_liquidation_inner_id;
         *     private String status_liquidation;
         *     private String dtstart;
         *     private String dataprekrul;
         *     private String okato;
         *     private String indeks;
         *     private String region_name;
         *     private String raion_name;
         *     private String gorod_name;
         *     private String naspunkt_name;
         *     private String street_name;
         *     private String dom;
         *     private String korp;
         *     private String kvart;
         */

        Client client = new Client();
        client.setInn(dwhRecord.getInn());
        client.setOgrn(dwhRecord.getOgrn());
        client.setKpp(dwhRecord.getKpp());
        client.setNameP(dwhRecord.getNamep());
        client.setNameS(dwhRecord.getNames());
        client.setStatusLiqID(dwhRecord.getStatus_liquidation_inner_id());
        client.setStatusLiq(dwhRecord.getStatus_liquidation());
        if (dwhRecord.getDtstart() != null) {
            client.setdStart(sdf.format(dwhRecord.getDtstart()));
        }
        if (dwhRecord.getDataprekrul() != null) {
            client.setDataPrekrUL(sdf.format(dwhRecord.getDataprekrul()));
        }
        client.setOkato(dwhRecord.getOkato());
        client.setIndex(dwhRecord.getIndeks());
        client.setRegionName(dwhRecord.getRegion_name());
        client.setRaionName(dwhRecord.getRaion_name());
        client.setGorodName(dwhRecord.getGorod_name());
        client.setNasPunktName(dwhRecord.getNaspunkt_name());
        client.setStreetName(dwhRecord.getStreet_name());
        client.setDom(dwhRecord.getDom());
        client.setKorp(dwhRecord.getKorp());
        client.setKvart(dwhRecord.getKvart());
        return client;
    }

}
