package ru.usb.put_statuses_cft.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties
public class Config {

    /**
     * Kafka property
     * Топик для сообщений в ЦФТ
     */
    @Value("${kafka.cft.topic}")
    private String cftTopic;

    /**
     * Количество сообщений перед отправкой в ЦФТ
     */
    @Value("${kafka.count.message}")
    private int messageCount;

    /**
     * Время работы сервиса. Сервис работает с 5 часов утра до 23 часов вечера.
     * true - работает
     * false - не работает
     */
    @Value("${work.time}")
    private boolean workTime;

    /**
     * Флаг готовности ЦХД к работе
     * раз в 10 минут проверяет флаг готовности ЦХД отдать данные с помощью запроса:
     * select count(*) from ctl.ctl_workflows_load where workflow_name = ‘WF_ODS_FNS_EGRUL_SVYUL’ and  trunc(end_run_dttm) = trunc(sysdate);
     * Флагом готовности данных является результат больше нуля
     */
    private boolean flagReady;

    /**
     * Периодичность запуска сервиса
     */
    @Value("${scheduler.delay}")
    private String schedulerDelay;

    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;


    /**
     *  Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    /**
     * Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;
    @Value("${spring.mail.port:25}")
    private String mailPort;
    @Value("${spring.mail.username}")
    private String mailUsername;
    @Value("${spring.mail.password}")
    private String mailPassword;
    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;
    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;
    @Value("${mailSubjects}")
    private String mailSubjects;
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailTo}")
    private String mailTo;
    @Value("${mailToBusiness}")
    private String mailToBusiness;


    public boolean isServiceEnabled() {
        return serviceEnabled;
    }

    public void setServiceEnabled(boolean serviceEnabled) {
        this.serviceEnabled = serviceEnabled;
    }

    public String getServiceUser() {
        return serviceUser;
    }

    public String getServicePassword() {
        return servicePassword;
    }

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getMailToBusiness() {
        return mailToBusiness;
    }

    public boolean isWorkTime() {
        return workTime;
    }

    public void setWorkTime(boolean workTime) {
        this.workTime = workTime;
    }

    public boolean isFlagReady() {
        return flagReady;
    }

    public void setFlagReady(boolean flagReady) {
        this.flagReady = flagReady;
    }

    public String getSchedulerDelay() {
        return schedulerDelay;
    }

    public String getCftTopic() {
        return cftTopic;
    }

    public void setCftTopic(String cftTopic) {
        this.cftTopic = cftTopic;
    }

    public int getMessageCount() {
        return messageCount;
    }
}
