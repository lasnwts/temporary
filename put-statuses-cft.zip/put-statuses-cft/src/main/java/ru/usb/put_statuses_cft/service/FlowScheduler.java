package ru.usb.put_statuses_cft.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.put_statuses_cft.config.Config;
import ru.usb.put_statuses_cft.config.LG;


@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final FlowOperations flowOperations;

    public FlowScheduler(Config config, FlowOperations flowOperations) {
        this.config = config;
        this.flowOperations = flowOperations;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    /**
     * Проверки, что можно стартовать опрос
     */
    @Scheduled(cron = "${start-cron}")
    public void checkStartWork() {
        logger.info("{}: cron-start. Время работы наступило.", LG.USBLOGINFO);
        config.setWorkTime(true); //Время работы наступило
    }

    /**
     * Проверки, что можно закончить опрос
     */
    @Scheduled(cron = "${stop-cron}")
    public void checkStopWork() {
        logger.info("{}: cron-start. Время работы закончилось.", LG.USBLOGINFO);
        config.setWorkTime(false); //Время работы завершилось
    }

    /**
     * Основной поток
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void startScheduler() {
        logger.info("{}: Старт scheduler.", LG.USBLOGINFO);
        //Если время наступило и поток готов
        if (config.isWorkTime() && flowOperations.checkFlagReadyFlow() && config.isServiceEnabled()) {
                flowOperations.startFlow();
            }
        logger.info("{}: Стоп Scheduler.", LG.USBLOGINFO);
    }
}
