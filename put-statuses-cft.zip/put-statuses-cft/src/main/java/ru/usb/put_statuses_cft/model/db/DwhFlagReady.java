package ru.usb.put_statuses_cft.model.db;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class DwhFlagReady {

    @Id
    private int flagReady;

    public DwhFlagReady(int flagReady) {
        this.flagReady = flagReady;
    }

    public DwhFlagReady() {
        //
    }

    public int getFlagReady() {
        return flagReady;
    }

    public void setFlagReady(int flagReady) {
        this.flagReady = flagReady;
    }
}
