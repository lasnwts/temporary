package ru.usb.put_statuses_cft.service.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import ru.usb.put_statuses_cft.config.LG;


/**
 * Класс отправки сообщений Кафка
 */
@Service
public class KafkaProducerService {

    Logger log = LoggerFactory.getLogger(KafkaProducerService.class);

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Простой вариант отправки сообщений, без проверки
     *
     * @param topic - топик
     * @param msg   - сообщение
     */
    public boolean sendMessage(String topic, String msg) {
        try {
            kafkaTemplate.send(topic, msg);
            log.info("UsbLog:Success send.Topic={}; Send message={}", topic, msg);
            return true;
        } catch (Exception exception) {
            log.error("{}:!!!!!<ERROR send message>[sendMessage(String topic, String msg)]!!!", LG.USBLOGERROR);
            log.error("{}:}send failure:topic:{}", LG.USBLOGERROR, topic);
            log.error("{}:}send failure:message:{}", LG.USBLOGERROR, msg);
            log.error("{}:Exception:", LG.USBLOGERROR, exception);
            return false;
        }
    }

    /**
     * Простой вариант отправки сообщений, без проверки2
     *
     * @param topic - топик
     * @param msg   - сообщение
     */
    public boolean sendMessage(String topic, String key, String msg) {
        try {
            kafkaTemplate.send(topic, key, msg);
            log.info("{}:Success send.Topic={}; key={}; Send message={};", LG.USBLOGINFO, topic, key, msg);
            return true;
        } catch (Exception exception) {
            log.error("{}:!!!<ERROR send message>[sendMessage(String topic, String key, String msg)]!!!!!", LG.USBLOGERROR);
            log.error("{}:send failure:topic:{}", LG.USBLOGERROR, topic);
            log.error("{}:send failure:message:{}",LG.USBLOGERROR, msg);
            log.error("{}:Exception::",LG.USBLOGERROR, exception);
            return false;
        }
    }

}
