package ru.usb.put_statuses_cft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PutStatusesCftApplicationTests {

	@Test
	void contextLoads() {
	}

}
