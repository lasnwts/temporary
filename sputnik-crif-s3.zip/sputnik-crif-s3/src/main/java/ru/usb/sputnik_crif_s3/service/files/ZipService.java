package ru.usb.sputnik_crif_s3.service.files;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.usb.sputnik_crif_s3.config.UsbLogger;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Component
public class ZipService {
    @Value("zip")
    String localDir;

    public boolean toZipFile(String base64String, String requestId) throws IOException {
        try {
            byte[] fileBytes = Base64.getDecoder().decode(base64String);
            Files.write(Path.of(localDir, requestId), fileBytes);
            return true;
        } catch (Exception e) {
            UsbLogger.error(e.getMessage());
            return false;
        }
    }

    public void unzip(Path zipFile, String requestId) {
        byte[] buffer = new byte[1024];

        try (FileInputStream fis = new FileInputStream(zipFile.toFile());
             ZipInputStream zis = new ZipInputStream(fis, Charset.forName("CP866")))
        {
            ZipEntry zipEntry = zis.getNextEntry();
            while (zipEntry != null) {
                String filename = zipEntry.getName();
                File newFile = new File(Path.of(String.valueOf(zipFile.getParent()), requestId, filename).toUri());
                new File(newFile.getParent()).mkdirs();

                try (FileOutputStream fos = new FileOutputStream(newFile)) {
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                }
                zis.closeEntry();
                zipEntry = zis.getNextEntry();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
