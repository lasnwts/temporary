package ru.usb.sputnik_crif_s3.model.sputnik.mkk;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
public enum DocumentLinks {
    PaymentGraphMKK("/График платежей по Договору потребительского займа.pdf"),
    LetterForBankMKK("/Доверенность на Банк.pdf"),
    LetterMKK("/Доверенность на МКК.pdf"),
    AppPersonalLoanMKK("/Заявление о предоставлении потребительского займа.pdf"),
    AppFormOpenCreditMKK("/Заявление-анкета об открытии текущего банковского счета.pdf"),
    IndividualConditionsMKK("/Индивидуальные условия договора потребительского займа.pdf"),
    InsuranceMKK("/Информация и документы по дополнительной услуге.pdf"),
    ConsentPersonalMKK("/Согласие на обработку персональных данных, на получение-предоставление информации в БКИ.pdf"),
    ConsentASPMKK("/Соглашение об использовании АСП.pdf");


    private final String fileName;

}
