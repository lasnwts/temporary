package ru.usb.sputnik_crif_s3.model.sputnik;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Response {
    String requestId;
    String message;
    String errorMessage;
}
