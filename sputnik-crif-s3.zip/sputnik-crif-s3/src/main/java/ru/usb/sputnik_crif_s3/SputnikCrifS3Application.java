package ru.usb.sputnik_crif_s3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
public class SputnikCrifS3Application {

	public static void main(String[] args) {
		SpringApplication.run(SputnikCrifS3Application.class, args);
	}

}
