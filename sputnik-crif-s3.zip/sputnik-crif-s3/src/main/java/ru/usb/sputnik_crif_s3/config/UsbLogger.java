package ru.usb.sputnik_crif_s3.config;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UsbLogger {
    private UsbLogger(){}
    private static final String INFO_PREFIX = "UsbLogInfo :";
    private static final String WARN_PREFIX = "UsbLogWarn :";
    private static final String ERROR_PREFIX = "UsbLogError :";
    private static final String DEBUG_PREFIX = "UsbLogDebug :";

    private static String getClassName(){
        return Thread.currentThread().getStackTrace()[4].getClassName();
    }

    private static String getMethodName(){
        return Thread.currentThread().getStackTrace()[4].getMethodName();
    }

    private static String formatMessage(String prefix, String message){
        String className = getClassName();
        String methodName = getMethodName();
        return String.format("%s Класс %s -> Метод %s - %s", prefix, className, methodName, message);
    }

    public static void info(String message){
        log.info(formatMessage(INFO_PREFIX, message));
    }
    public static void warn(String message){
        log.warn(formatMessage(WARN_PREFIX, message));
    }
    public static void error(String message){
        log.error(formatMessage(ERROR_PREFIX,  message));
    }
    public static void debug(String message){
        log.debug(formatMessage(DEBUG_PREFIX, message));
    }
    public static void info(String message, Object... args){
        log.info(formatMessage(INFO_PREFIX, message), args);
    }
    public static void warn(String message, Object... args){
        log.warn(formatMessage(WARN_PREFIX, message), args);
    }
    public static void error(String message, Object... args){
        log.error(formatMessage(ERROR_PREFIX, message), args);
    }
    public static void debug(String message, Object... args){
        log.debug(formatMessage(DEBUG_PREFIX, message), args);
    }

}
