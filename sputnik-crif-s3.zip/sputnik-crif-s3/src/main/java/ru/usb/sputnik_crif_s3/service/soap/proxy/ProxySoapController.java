package ru.usb.sputnik_crif_s3.service.soap.proxy;

import creditflow.cribisnet._2005_10_05.proxy.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ProxySoapController {
    final WSProxySoap wsProxySoap;

    @Value("${crif.soap.proxy.login.username}")
    String username;

    @Value("${crif.soap.proxy.login.password}")
    String password;



    public LoginResult callLogin() {
        return wsProxySoap.login(
                null,
                null,
                username,
                password
                );
    }
    public ProcessEngineInfoGetResult callProcessEngineInfoGet(String token, String processEngineGuid) {
        return wsProxySoap.processEngineInfoGet(
                token,
                processEngineGuid
        );
    }

    public ProcessUnfreezeResult callProcessUnfreeze(String token, String activityEngineGuid,
                                                     String commandName, String documentInputXML) {

        return wsProxySoap.processUnfreeze(
               token,
                activityEngineGuid,
                commandName,
                documentInputXML
        );
    }

    public LogoutResult callLogout(String token) {
        return wsProxySoap.logout(token);
    }
}
