package ru.usb.sputnik_crif_s3.service.soap.facade;

import com.crif.cf.wsfacade.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class FacadeSoapController {
    final IWSFacade wsFacadeSoap;

    public ProcessIdResult callGetProcessId(String token, ProcessIdRequest processIdRequest) throws WSFacadeException_Exception {
        return wsFacadeSoap.getProcessId(
                token,
                processIdRequest
                );
    }
}
