package ru.usb.sputnik_crif_s3.service.soap.proxy;

import creditflow.cribisnet._2005_10_05.proxy.WSProxySoap;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProxySoapClientConfig {

    @Value("${crif.soap.proxy.service-url}")
    String serviceUrl;

    @Bean
    WSProxySoap wsProxySoap() {
        JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
        factoryBean.setServiceClass(WSProxySoap.class);
        factoryBean.setAddress(serviceUrl);

        return (WSProxySoap) factoryBean.create();
    }
}
