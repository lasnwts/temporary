package ru.usb.sputnik_crif_s3.ex;

public class RetryException extends RuntimeException{

    public RetryException(String message) {
        super(message);
    }
}
