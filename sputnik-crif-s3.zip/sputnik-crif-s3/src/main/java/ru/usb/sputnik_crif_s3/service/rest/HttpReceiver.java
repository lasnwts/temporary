package ru.usb.sputnik_crif_s3.service.rest;

import com.crif.cf.wsfacade.WSFacadeException_Exception;
import jakarta.xml.bind.JAXBException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.usb.crif.unfreeze.Data;
import ru.usb.crif.unfreeze.ObjectFactory;
import ru.usb.sputnik_crif_s3.config.UsbLogger;
import ru.usb.sputnik_crif_s3.model.sputnik.Request;
import ru.usb.sputnik_crif_s3.model.sputnik.Response;
import ru.usb.sputnik_crif_s3.model.sputnik.mkk.DocumentLinks;
import ru.usb.sputnik_crif_s3.service.CrifService;
import ru.usb.sputnik_crif_s3.service.RequestValidator;
import ru.usb.sputnik_crif_s3.service.files.LocalFileService;
import ru.usb.sputnik_crif_s3.service.files.S3Service;
import ru.usb.sputnik_crif_s3.service.files.XmlParser;
import ru.usb.sputnik_crif_s3.service.files.ZipService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequiredArgsConstructor
@Setter
@Getter
public class HttpReceiver {
    final
    S3Service s3Service;
    final
    RequestValidator requestValidator;
    final
    CrifService crifService;
    final ZipService zipService;
    final LocalFileService localFileService;

    @PostMapping(value = "/",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE)
    public Response processFileUpload(@RequestBody Request request) throws IOException, WSFacadeException_Exception, JAXBException {
        UsbLogger.info("Received : {}", request.getRequestId());
        try {
            Data data = new ObjectFactory().createData();
            Data.MKKData mkkData = new Data.MKKData();
            if (!requestValidator.isNullAndEmpty(request.getDocumentsZipArchive())) {

                String zipName = request.getRequestId() + ".zip";
                zipService.toZipFile(request.getDocumentsZipArchive(), zipName);
                zipService.unzip(Path.of("zip", zipName), request.getRequestId());
                File dir = new File(Path.of("zip", request.getRequestId()).toUri());
                File[] files = dir.listFiles();

                if (files != null) {
                    for (File file : files) {
                        s3Service.processFileUpload(request.getRequestId(), file.getName());
                    }
                }

                mkkData.setIndividualConditionsMKK(request.getRequestId().concat(DocumentLinks.IndividualConditionsMKK.getFileName()));
                mkkData.setPaymentGraphMKK(request.getRequestId().concat(DocumentLinks.PaymentGraphMKK.getFileName()));
                mkkData.setLetterMKK(request.getRequestId().concat(DocumentLinks.LetterMKK.getFileName()));
                mkkData.setLetterForBankMKK(request.getRequestId().concat(DocumentLinks.LetterForBankMKK.getFileName()));
                mkkData.setAppPersonalLoanMKK(request.getRequestId().concat(DocumentLinks.AppPersonalLoanMKK.getFileName()));
                mkkData.setAppFormOpenCreditMKK(request.getRequestId().concat(DocumentLinks.AppFormOpenCreditMKK.getFileName()));
                mkkData.setInsuranceMKK(request.getRequestId().concat(DocumentLinks.InsuranceMKK.getFileName()));
                mkkData.setConsentPersonalMKK(request.getRequestId().concat(DocumentLinks.ConsentPersonalMKK.getFileName()));
                mkkData.setConsentASPMKK(request.getRequestId().concat(DocumentLinks.ConsentASPMKK.getFileName()));

            } else if (requestValidator.isNullAndEmpty(request.getPhase())) {

                Response response = new Response();
                response.setRequestId(request.getRequestId());
                response.setMessage("false");
                response.setErrorMessage("false");
                localFileService.deleteDir(request.getRequestId());

                return response;

            }

            mkkData.setPhase(request.getPhase());
            if (request.getCreditLimit() != null) {
                mkkData.setCreditLimit(String.valueOf(request.getCreditLimit()));
            }
            mkkData.setAccountNumber(request.getAccountNumber());
            mkkData.setFlagSignDBO(request.getFlagSignDbo());
            if(request.getInterestRate() != null ) {
                mkkData.setInterestRate(String.valueOf(request.getInterestRate()));

            }
            mkkData.setRequestId(request.getRequestId());
            if(request.getPskSum() != null) {
                mkkData.setPskSum(String.valueOf(request.getPskSum()));
            }
            if(request.getLoanTerm() != null) {
                mkkData.setLoanTerm(String.valueOf(request.getLoanTerm()));

            }
            if(request.getPskPercent() != null) {
                mkkData.setPskPercent(String.valueOf(request.getPskPercent()));
            }
            if (request.getInsurancePremium() != null) {
                mkkData.setInsurancePremium(String.valueOf(request.getInsurancePremium()));
            }

            data.setMKKData(mkkData);
            String xml = XmlParser.toXml(data);
            crifService.processRequest(request, xml);

            return okResponse(request);
        } catch (
                Exception e) {
            Response response = new Response();
            response.setRequestId(request.getRequestId());
            response.setMessage("false");
            response.setErrorMessage(e.getMessage());
            localFileService.deleteDir(request.getRequestId());


            return response;
        }

    }

    private Response okResponse(Request request) throws IOException {
        Response response = new Response();
        response.setRequestId(request.getRequestId());
        response.setMessage("success");
        response.setErrorMessage("");
        localFileService.deleteDir(request.getRequestId());

        return response;
    }
}
