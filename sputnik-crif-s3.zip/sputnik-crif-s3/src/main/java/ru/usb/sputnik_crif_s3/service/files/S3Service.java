package ru.usb.sputnik_crif_s3.service.files;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import ru.usb.sputnik_crif_s3.config.UsbLogger;

import java.io.File;

@Service
@Setter
@RequiredArgsConstructor
@ConfigurationProperties(prefix = "s3")
public class S3Service {
    String url;
    String accessKey;
    String secretKey;
    String bucketName;
    final AmazonS3 s3Client;

    public boolean processFileUpload(String requestId, String s3Key) {
        try {
            File file = new File("zip/" + requestId + "/" + s3Key);
            if (!file.exists() || file.isDirectory()) {
                UsbLogger.info("Файл не найден или является директорией: {}", file.getAbsoluteFile().toString());
                return false;
            }

            PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, requestId + "/" + s3Key, file);

            s3Client.putObject(putObjectRequest);
            UsbLogger.info("Файл загружен: {} -> s3://{}/{}", file.getAbsoluteFile().toString(),
                    bucketName, requestId + "/" + s3Key);

            return true;
        } catch (Exception e) {
            UsbLogger.error("Ошибка загрузки: {}", e.getMessage());
            return false;
        }

    }


}
