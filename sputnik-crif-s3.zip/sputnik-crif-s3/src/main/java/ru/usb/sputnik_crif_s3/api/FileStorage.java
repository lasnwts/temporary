package ru.usb.sputnik_crif_s3.api;

public interface FileStorage {
    String uploadFile();
}
