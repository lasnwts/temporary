package ru.usb.sputnik_crif_s3.service;

import org.springframework.stereotype.Component;
import ru.usb.sputnik_crif_s3.model.sputnik.Request;
@Component
public class RequestValidator {
    public boolean validate(Request request) {
        if (isNullAndEmpty(request.getPhase())) {
            return !isNullAndEmpty(request.getDocumentsZipArchive());
        } else {
            return true;
        }
    }

    public boolean isNullAndEmpty(String field) {
        return field == null || field.isEmpty();
    }
}
