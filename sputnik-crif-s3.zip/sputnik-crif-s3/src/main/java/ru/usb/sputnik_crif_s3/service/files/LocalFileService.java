package ru.usb.sputnik_crif_s3.service.files;

import jakarta.annotation.PostConstruct;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.stereotype.Service;
import ru.usb.sputnik_crif_s3.config.UsbLogger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class LocalFileService {
    @PostConstruct
    void clearDir() throws IOException {
        Files.createDirectory(Paths.get("zip"));
        FileUtils.cleanDirectory(new File("zip"));
        UsbLogger.info("Локальная папка очищена");
    }

    public void deleteDir(String requestId) throws IOException {
        String path = "zip/" + requestId;
        FileUtils.deleteDirectory(new File(path));
        UsbLogger.info("папка {} удалена", path);
    }

}
