package ru.usb.sputnik_crif_s3.service;

import com.crif.cf.wsfacade.ProcessIdRequest;
import com.crif.cf.wsfacade.ProcessIdResult;
import com.crif.cf.wsfacade.WSFacadeException_Exception;
import creditflow.cribisnet._2005_10_05.proxy.LoginResult;
import creditflow.cribisnet._2005_10_05.proxy.LogoutResult;
import creditflow.cribisnet._2005_10_05.proxy.ProcessEngineInfoGetResult;
import creditflow.cribisnet._2005_10_05.proxy.ProcessUnfreezeResult;
import lombok.RequiredArgsConstructor;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import ru.usb.sputnik_crif_s3.config.UsbLogger;
import ru.usb.sputnik_crif_s3.ex.RetryException;
import ru.usb.sputnik_crif_s3.model.sputnik.Request;
import ru.usb.sputnik_crif_s3.service.soap.facade.FacadeSoapController;
import ru.usb.sputnik_crif_s3.service.soap.proxy.ProxySoapController;

@Service
@RequiredArgsConstructor
public class CrifService {

    final
    ProxySoapController proxyController;
    final
    FacadeSoapController facadeController;
    final
    RetryTemplate retryTemplate;

    public void processRequest(Request request, String xml) throws WSFacadeException_Exception {
        LoginResult loginResult = proxyController.callLogin();
        UsbLogger.info("Login code: {}", loginResult.getCode());
        ProcessIdRequest processIdRequest = new ProcessIdRequest();
        processIdRequest.setApplicationId(Integer.valueOf(request.getRequestId()));
        ProcessIdResult processIdResult = facadeController.callGetProcessId(
                loginResult.getToken(),
                processIdRequest
        );
        UsbLogger.info("GetProcessId -> OK. ProcessEngineGuid: {}", processIdResult.getProcessEngineGuid());
        ProcessEngineInfoGetResult processEngineInfoGetResult = proxyController.callProcessEngineInfoGet(
                loginResult.getToken(),
                processIdResult.getProcessEngineGuid()
        );
        UsbLogger.info("EngineInfoGet -> OK. ActivityEngineGuid: {}",
                processEngineInfoGetResult.getProcessEngineShortInfo().getActivityEngineGuid());


        UsbLogger.info("Activity -> {}",
                processEngineInfoGetResult.getProcessEngineShortInfo().getActivityCacheId());

        ProcessUnfreezeResult unfreezeResult = this.unfreezeProcess(
                loginResult.getToken(),
                processIdResult.getProcessEngineGuid(),
                xml
        );
        UsbLogger.info("Unfreeze code: {}", unfreezeResult.getCode());
        LogoutResult logoutResult = proxyController.callLogout(loginResult.getToken());
        UsbLogger.info("Logout code: {}", logoutResult.getCode());

    }

    public ProcessUnfreezeResult unfreezeProcess(String token, String processEngineGuid, String xml) {

        return retryTemplate.execute(context -> {
            ProcessEngineInfoGetResult processEngineInfoGetResult =
                    proxyController.callProcessEngineInfoGet(token, processEngineGuid);
            UsbLogger.info("EngineInfoGet -> OK. ActivityEngineGuid: {}",
                    processEngineInfoGetResult.getProcessEngineShortInfo().getActivityEngineGuid());

            ProcessUnfreezeResult unfreezeResult = proxyController.callProcessUnfreeze(
                    token,
                    processEngineInfoGetResult.getProcessEngineShortInfo().getActivityEngineGuid(),
                    "Updated",
                    xml
            );
            if (processEngineInfoGetResult.getProcessEngineShortInfo().getActivityCacheId().equals("WA_60_50_WaitAnswerByMKK")
                    || processEngineInfoGetResult.getProcessEngineShortInfo().getActivityCacheId().equals("WA_60_80_WaitResponseSravniRuOrMKK")
                    || processEngineInfoGetResult.getProcessEngineShortInfo().getActivityCacheId().equals("WA_60_160_AnswerByMKKIssue")) {
                return unfreezeResult;
            } else {
                UsbLogger.info("Получена не та активность, требуется повторная попытка");
                throw new RetryException("");
            }
        }, context -> {
            UsbLogger.warn("Все попытки исчерпаны. Возвращаем значение");
            ProcessEngineInfoGetResult processEngineInfoGetResult =
                    proxyController.callProcessEngineInfoGet(token, processEngineGuid);
            UsbLogger.info("EngineInfoGet -> OK. ActivityEngineGuid: {}",
                    processEngineInfoGetResult.getProcessEngineShortInfo().getActivityEngineGuid());

            return proxyController.callProcessUnfreeze(
                    token,
                    processEngineInfoGetResult.getProcessEngineShortInfo().getActivityEngineGuid(),
                    "Updated",
                    xml
            );
        });
    }
}
