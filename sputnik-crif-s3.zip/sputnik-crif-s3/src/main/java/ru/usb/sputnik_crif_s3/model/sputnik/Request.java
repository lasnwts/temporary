package ru.usb.sputnik_crif_s3.model.sputnik;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Data
@Component
public class Request {
    @JsonProperty(required = true)
    String requestId;
    @JsonProperty
    BigDecimal creditLimit;
    @JsonProperty
    BigDecimal insurancePremium;
    @JsonProperty
    Integer loanTerm;
    @JsonProperty
    BigDecimal interestRate;
    @JsonProperty()
    String phase;
    @JsonProperty
    String flagSignDbo;
    @JsonProperty
    BigDecimal pskPercent;
    @JsonProperty
    BigDecimal pskSum;
    @JsonProperty
    String accountNumber;
    @JsonProperty
    String documentsZipArchive;
}
