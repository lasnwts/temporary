package ru.usb.sputnik_crif_s3.api;

public interface ExternalServiceClient {
    void sendFileLink(String json);
}
