package ru.usb.sputnik_crif_s3.api;

import ru.usb.sputnik_crif_s3.model.sputnik.Request;

public interface ProcessingService {


    void processFileUpload(Request request);
}
