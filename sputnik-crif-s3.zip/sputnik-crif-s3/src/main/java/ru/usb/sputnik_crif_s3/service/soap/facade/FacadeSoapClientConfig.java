package ru.usb.sputnik_crif_s3.service.soap.facade;

import com.crif.cf.wsfacade.IWSFacade;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FacadeSoapClientConfig {

    @Value("${crif.soap.facade.service-url}")
    String serviceUrl;

    @Bean
    IWSFacade wsFacadeSoap() {
        JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
        factoryBean.setServiceClass(IWSFacade.class);
        factoryBean.setAddress(serviceUrl);

        return (IWSFacade) factoryBean.create();
    }
}
