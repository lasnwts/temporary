package ru.usb.factorin_s3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactorinS3Application {

	public static void main(String[] args) {
		SpringApplication.run(FactorinS3Application.class, args);
	}

}
