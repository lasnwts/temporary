package ru.usb.getrps963722.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import ru.usb.getrps963722.controller.RestController;
import ru.usb.getrps963722.model.rps.DataRow;

@Component
public class ParseNodeYearyields {

    private Logger logger = LoggerFactory.getLogger(ParseNodeYearyields.class);

    public void getRows(Node node) {

//        NodeList nodeRows = node.getChildNodes();
//        NodeList sections =  doc.getElementsByTagName("data");

        logger.info("section={}", node.getNodeValue());


        NodeList nodeList = node.getChildNodes();

        int numSections = nodeList.getLength();
        logger.info("section.length={}", numSections);

        for (int i = 0; i < numSections; i++) {
            Node nrows = nodeList.item(i);// A <sect1>
            //  NamedNodeMap attributes = sections.item(i).getAttributes();
            logger.info("Node={}", nrows.getNodeValue());
        }

//        NodeList nodeList2 = node.getOwnerDocument().getElementsByTagName("row");
//        logger.info("row count={}", nodeList2.getLength());

//        numSections = nodeList2.getLength();
//        for (int i = 0; i < numSections; i++) {
//            Node nNode = nodeList2.item(i);// A <sect1>
//            //  NamedNodeMap attributes = sections.item(i).getAttributes();
//
//            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//                org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
//                logger.info("Node2={}",eElement.getFirstChild().getNodeValue());
//            }
//        }

    }

    public void getTest1(Document document) {
        Element root = document.getDocumentElement();
        System.out.println(root.getNodeName());

        //Get all employees
        NodeList nList = document.getElementsByTagName("row");

        System.out.println("============================");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node node = nList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                //Print each employee's detail
                Element eElement = (Element) node;
                System.out.println("\ntradedate  : " + eElement.getAttribute("tradedate"));
                System.out.println("\ntradetime  : " + eElement.getAttribute("tradetime"));
                System.out.println("\nperiod  : " + eElement.getAttribute("period"));
                System.out.println("\nvalue  : " + eElement.getAttribute("value"));
                NamedNodeMap attributes = nList.item(temp).getParentNode().getParentNode().getAttributes();
                Node p = attributes.getNamedItem("id");
                //logger.info(p.getNodeValue());
                System.out.println(p.getNodeValue());

            }
        }


    }


    /**
     * Извлечение данных их XML документа
     * @param document - xml документ
     * @return - данные
     */
    public DataRow getDataPeriod10(Document document) {

        Element root = document.getDocumentElement();
        //Get all employees
        NodeList nList = document.getElementsByTagName("row");

        DataRow dataRow = new DataRow();

        for (int temp = 0; temp < nList.getLength(); temp++) {

            Node node = nList.item(temp);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                NamedNodeMap attributes = nList.item(temp).getParentNode().getParentNode().getAttributes();
                Node p = attributes.getNamedItem("id");
                Element eElement = (Element) node;
                if (p.getNodeValue().equals("yearyields")) {
                    if (eElement.getAttribute("period").equals("10.00")) {
                        dataRow.setTradedate(eElement.getAttribute("tradedate"));
                        dataRow.setTradetime(eElement.getAttribute("tradetime"));
                        dataRow.setPeriod(eElement.getAttribute("period"));
                        dataRow.setValue(eElement.getAttribute("value"));
                    }
                }
            }
        }
        return dataRow;
    }
}
