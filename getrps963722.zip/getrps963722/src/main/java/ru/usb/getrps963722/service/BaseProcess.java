package ru.usb.getrps963722.service;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import ru.usb.getrps963722.configure.Configure;
import ru.usb.getrps963722.controller.RestController;
import ru.usb.getrps963722.model.rps.DataRow;
import ru.usb.getrps963722.utils.Mapper;
import ru.usb.getrps963722.utils.ParseDate;
import ru.usb.getrps963722.utils.ParseNodeYearyields;

import java.util.Date;

@Service
public class BaseProcess {

    @Autowired
    Configure configure;

    @Autowired
    Mapper mapper;

    @Autowired
    ParserXML parserXML;

    @Autowired
    ParseDate parseDate;

    @Autowired
    GetRestRPS getRestRPS;

    @Autowired
    ParseNodeYearyields parseNodeYearyields;

    private Logger logger = LoggerFactory.getLogger(BaseProcess.class);

    /**
     * Основной процесс обработки
     * @return true - если успешно, false - если нет
     */
    public boolean startProcess(){

        logger.info("Текущая дата = {}", new Date());
        logger.info("Дата запроса в ЦБ = {}", DateUtils.addDays(new Date(), -2));
        String dateStrToCB = parseDate.getDateToStringSDF(DateUtils.addDays(new Date(), -2));
        logger.info("Дата, после преобразования в строке для ЦБ:{}", dateStrToCB);

        String xmlstr  = getRestRPS.get(dateStrToCB);
        Document doc =  mapper.getXMLFromString(xmlstr);
        //parseNodeYearyields.getTest1(doc);
        DataRow dataRow = parseNodeYearyields.getDataPeriod10(doc);
        logger.info(dataRow.toString());
        return true;
    }
}
