package ru.usb.getrps963722;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.getrps963722.configure.Configure;
import ru.usb.getrps963722.service.BaseProcess;

@SpringBootApplication
public class Getrps963722Application implements CommandLineRunner {

	@Autowired
	Configure configure;

	@Autowired
	BaseProcess baseProcess;

	private Logger logger = LoggerFactory.getLogger(Getrps963722Application.class);

	public static void main(String[] args) {
		SpringApplication.run(Getrps963722Application.class, args);
	}

	@Bean
	public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API (RTM->IBSO Retail)")
				.version(appVersion)
				.description("API для канала РТМ - Ритейл." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	@Override
	public void run(String... args) throws Exception {

		logger.info("Result base process={}",baseProcess.startProcess());


	}

	/**
	 * Sheduler 1.  Шедулер 1. по Cron.
	 */
	@Scheduled(cron = "${interval-in-cron}")
	public void CronSheduler() {
		logger.info("");
		logger.info("");
		logger.info("*****************************************<Start CronSheduler Scheduler process " + configure.getAppVersion() + ">*******************************************************");


		logger.info("*****************************************<Stop  CronSheduler Scheduler process " + configure.getAppVersion() + ">*******************************************************");
		logger.info("");
		logger.info("");
	}


}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
	/**
	 * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
	 * https://habr.com/ru/post/580062/
	 */
}