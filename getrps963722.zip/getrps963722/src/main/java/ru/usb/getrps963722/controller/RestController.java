package ru.usb.getrps963722.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.*;
import ru.usb.getrps963722.configure.Configure;
import ru.usb.getrps963722.model.rps.DataRow;
import ru.usb.getrps963722.service.GetRestRPS;
import ru.usb.getrps963722.service.ParserXML;
import ru.usb.getrps963722.utils.Mapper;
import ru.usb.getrps963722.utils.ParseDate;
import ru.usb.getrps963722.utils.ParseNodeYearyields;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Tag(name = "Работа с сообщениями из РТМ", description = "API для тестирования работы канала РТМ -> Ритейл")
public class RestController {

    @Autowired
    Configure configure;

    @Autowired
    Mapper mapper;

    @Autowired
    ParserXML parserXML;

    @Autowired
    ParseDate parseDate;

    @Autowired
    GetRestRPS getRestRPS;

    @Autowired
    ParseNodeYearyields parseNodeYearyields;

    private Logger logger = LoggerFactory.getLogger(RestController.class);

    @GetMapping("/getrps")
    @Operation(summary = "Получаем страницу с сайта ЦБ,")
    public ResponseEntity RPS(){

        String xmlstr  = getRestRPS.get(parseDate.getNowDate());

        return new ResponseEntity<>(xmlstr, HttpStatus.OK);
    }

    @PostMapping("/str")
    @Operation(summary = "Сообщение в виде строки текста для эмуляции сообщения из RTM. Это чисто для теста,")
    public ResponseEntity strToMapper(@RequestBody String srtMessage) {

        if (srtMessage == null || srtMessage.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания сообщения из РТМ");
        }

        logger.info(">>>>>>>>>Reuest string.............");
        logger.info(configure.getInfoLevel(), srtMessage.toString());

        Document doc =  mapper.getXMLFromString(srtMessage);

        //parseNodeYearyields.getTest1(doc);
        DataRow dataRow = parseNodeYearyields.getDataPeriod10(doc);

        logger.info(dataRow.toString());





        //String xmlstr = mapper.getStringFromXML(doc);
        logger.info(">>>>>>>>>Response XML to string.............");



        return new ResponseEntity<>(dataRow.toString(), HttpStatus.OK);
    }


    @GetMapping("/getrps2/{date}")
    @Operation(summary = "Получаем страницу с сайта ЦБ, введите дату в формате yyyy-mm-dd, пример 2023-09-23")
    public ResponseEntity RPS2(@PathVariable("date") String date){

        if (date == null || date.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка, вы ввели пустое значение даты, введите дату в формате yyyy-mm-dd, пример 2023-09-23");
        }

        if (!parseDate.parseDate(date)){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.TEXT_PLAIN).body("Возникла ошибка распознавания даты из параметра, введите дату в формате yyyy-mm-dd, пример 2023-09-23");
        }


        String xmlstr  = getRestRPS.get(date);

        Document doc =  mapper.getXMLFromString(xmlstr);

        //parseNodeYearyields.getTest1(doc);
        DataRow dataRow = parseNodeYearyields.getDataPeriod10(doc);

        logger.info(dataRow.toString());

        return new ResponseEntity<>(dataRow.toString(), HttpStatus.OK);
    }

}
