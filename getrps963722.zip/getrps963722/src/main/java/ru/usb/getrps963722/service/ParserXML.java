package ru.usb.getrps963722.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import ru.usb.getrps963722.service.email.ServiceMailError;
import ru.usb.getrps963722.utils.ParseDate;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.StandardCharsets;

@Service
public class ParserXML {

    @Autowired
    ParseDate parseDate;

    @Autowired
    ServiceMailError serviceMailError;

    Logger logger = LoggerFactory.getLogger(ParserXML.class);

    public void parseXML(String xmlstr) {

//        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
//        XMLEventReader reader;
//
//        try {
//            //XMLEventReader reader = xmlInputFactory.createXMLEventReader(new FileInputStream(fullPath));
//            reader = xmlInputFactory.createXMLEventReader(new ByteArrayInputStream(xmlstr.getBytes(StandardCharsets.UTF_8)));
//
//        } catch (XMLStreamException e) {
//            throw new RuntimeException(e);
//        }
//
//
//        while(eventReader.hasNext()){
//            XMLEvent event = eventReader.nextEvent();
//            if(event.getEventType() == XMLStreamConstants.START_ELEMENT){
//                StartElement startElement = event.asStartElement();
//                System.out.println(startElement.getName().getLocalPart());
//            }
//            //handle more event types here...
//        }
//       // Источник: https://java-blog.ru/osnovy/api-interfeys-iterator-klassa-xmleventreader-v-java-stax
    }



}
