package ru.usb.getrps963722.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.usb.getrps963722.configure.Configure;
import org.springframework.http.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GetRestRPS {

    Logger logger = LoggerFactory.getLogger(GetRestRPS.class);

    @Autowired
    Configure configure;

    //RestTemplate restTemplate = new RestTemplate();
    RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));

    public String get(String sDate){

        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);

        ResponseEntity<String> response = null;

        /**
         * Заголовки
         */
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<?> entity = new HttpEntity<>(headers);


        /**
         * Формирование строки запроса
         */
        String urlTemplate = UriComponentsBuilder.fromHttpUrl("https://iss.moex.com//iss/engines/stock/zcyc.xml")
                .queryParam("date", "{date}")
                .encode()
                .toUriString();

        Map<String, String> params = new HashMap<>();
        params.put("date", sDate);


        try {
            response =
                //    restTemplate.exchange("https://iss.moex.com//iss/engines/stock/zcyc.xml?date=2023-05-02",
                    restTemplate.exchange(urlTemplate,
                            HttpMethod.GET,
                            entity,
                            String.class,
                            params);
        } catch (Exception e) {
            logger.error("Starus code::{}", e.getMessage());
            return null;
        }

        logger.info("Status Code={}",response.getStatusCode());
        logger.info("Response.Body.toString={}",response.getBody().toString());
        return response.getBody().toString();
    }


}
