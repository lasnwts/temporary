package ru.usb.getrps963722.model.rps;

import java.util.List;

public class Yearyields {

    private List<DataRow> dataRowList;

    public Yearyields() {
    }

    public Yearyields(List<DataRow> dataRowList) {
        this.dataRowList = dataRowList;
    }

    public List<DataRow> getDataRowList() {
        return dataRowList;
    }

    public void setDataRowList(List<DataRow> dataRowList) {
        this.dataRowList = dataRowList;
    }

    @Override
    public String toString() {
        return "Yearyields{" +
                "dataRowList=" + dataRowList +
                '}';
    }
}
