package ru.usb.getrps963722.model.rps;


public class DataRow {
    //"tradedate", "tradetime", "period", "value
    
    private String tradedate;
    private String tradetime;
    private String period;
    private String value;

    public DataRow() {
    }

    public DataRow(String tradedate, String tradetime, String period, String value) {
        this.tradedate = tradedate;
        this.tradetime = tradetime;
        this.period = period;
        this.value = value;
    }

    public String getTradedate() {
        return tradedate;
    }

    public void setTradedate(String tradedate) {
        this.tradedate = tradedate;
    }

    public String getTradetime() {
        return tradetime;
    }

    public void setTradetime(String tradetime) {
        this.tradetime = tradetime;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Data{" +
                "tradedate='" + tradedate + '\'' +
                ", tradetime='" + tradetime + '\'' +
                ", period='" + period + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
