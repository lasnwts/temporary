package ru.usb.getrps963722;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Getrps963722ApplicationTests {

	@Test
	void contextLoads() {
	}

}
