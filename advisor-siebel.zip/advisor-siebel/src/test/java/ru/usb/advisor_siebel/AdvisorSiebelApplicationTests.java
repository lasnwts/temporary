package ru.usb.advisor_siebel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvisorSiebelApplicationTests {

	@Test
	void contextLoads() {
	}

}
