package ru.usb.advisor_siebel.utils;


import org.springframework.stereotype.Component;
import ru.usb.advisor_siebel.model.MessageFromKafka;

@Component
public class MessageMapper {

    /**
     * Формирование сообщения в Кафка
     * @param messageFromKafka - сообщение в кафка
     * @return - строка сообщения
     */
    public String mapperToString(MessageFromKafka messageFromKafka) {
        return messageFromKafka.toString();
    }
}
