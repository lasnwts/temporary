package ru.usb.advisor_siebel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.advisor_siebel.config.Config;
import ru.usb.advisor_siebel.config.LG;


@Component
@EnableScheduling
public class FlowScheduler {

    private final Config config;
    private final FlowBatchProcess flowBatchProcess;

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    @Autowired
    public FlowScheduler(Config config, FlowBatchProcess flowBatchProcess) {
        this.config = config;
        this.flowBatchProcess = flowBatchProcess;
    }

    @Scheduled(cron = "${cron-scheduler1}")
    public void startScheduler1() {
        logger.info("{} <<<<<<<<<<<<<< Scheduler-1 start. Стартовал Scheduler-1. >>>>>>>>>>>>>>>>>", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            flowBatchProcess.process();
        }
        logger.info("{} <<<<<<<<<<< Scheduler-1 stop. Завершено время работы Scheduler-1. >>>>>>>>>", LG.USBLOGINFO);
    }

    @Scheduled(cron = "${cron-scheduler2}")
    public void startScheduler2() {
        logger.info("{} <<<<<<<<<<<<<< Scheduler-2 start. Стартовал Scheduler-2. >>>>>>>>>>>>>>>>>", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            flowBatchProcess.process();
        }
        logger.info("{} <<<<<<<<<<< Scheduler-2 stop. Завершено время работы Scheduler-2. >>>>>>>>>", LG.USBLOGINFO);
    }


    @Scheduled(cron = "${cron-scheduler3}")
    public void startScheduler3() {
        logger.info("{} <<<<<<<<<<<<<< Scheduler-3 start. Стартовал Scheduler-3. >>>>>>>>>>>>>>>>>", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            flowBatchProcess.process();
        }
        logger.info("{} <<<<<<<<<<< Scheduler-3 stop. Завершено время работы Scheduler-3. >>>>>>>>>", LG.USBLOGINFO);
    }


    @Scheduled(cron = "${cron-scheduler4}")
    public void startScheduler4() {
        logger.info("{} <<<<<<<<<<<<<< Scheduler-4 start. Стартовал Scheduler-4. >>>>>>>>>>>>>>>>>", LG.USBLOGINFO);
        if (config.isServiceEnabled()) {
            flowBatchProcess.process();
        }
        logger.info("{} <<<<<<<<<<< Scheduler-4 stop. Завершено время работы Scheduler-4. >>>>>>>>>", LG.USBLOGINFO);
    }

}



