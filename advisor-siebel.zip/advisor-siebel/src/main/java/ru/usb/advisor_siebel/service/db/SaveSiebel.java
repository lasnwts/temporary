package ru.usb.advisor_siebel.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.advisor_siebel.config.JdbcConfig;
import ru.usb.advisor_siebel.config.LG;
import ru.usb.advisor_siebel.model.siebel.SrvSovetnikBk;

import java.sql.*;

@Service
public class SaveSiebel {

    Logger log = LoggerFactory.getLogger(SaveSiebel.class);

    @Autowired
    JdbcConfig jdbcConfig;

    private static final String INSERT_TO_SIEBEL = "insert into siebelbk (inn,STRATEGY_TXT,RECOMMEND_ACC_OPEN,RISK_KYC_BLOCK_MOD_TXT,REC_PROD_CL_TXT,REC_PROD_NOT_CL_TXT,REC_PU_NOT_CL_TXT) values (?,?,?,?,?,?,?)";


    /**
     * Сохранение в БД
     * @param currentRecord - текущая запись из БД
     * @throws SQLException - ошибка при сохранении в БД
     */
    public void save(SrvSovetnikBk currentRecord) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.siebelDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_SIEBEL);

            insertStatement.setString(1, currentRecord.getInn());
            insertStatement.setString(2, currentRecord.getStrategyTxt());
            insertStatement.setString(3, currentRecord.getRecommendAccOpen());
            insertStatement.setString(4, currentRecord.getRiskKycBlockModTxt());
            insertStatement.setString(5, currentRecord.getRecProdClTxt());
            insertStatement.setString(6, currentRecord.getRecProdNotClTxt());
            insertStatement.setString(7, currentRecord.getRecPuNotClTxt());
            insertStatement.execute();
        } finally {
            if (insertStatement != null) try {
                insertStatement.close();
            } catch (SQLException exception) {
                log.error("{}: Ошибка при закрытии insertStatement: {}", LG.USBLOGERROR, exception.getMessage());
            }
            if (connection != null) try {
                connection.close();
            } catch (SQLException exception) {
                log.error("{}: Ошибка при закрытии connection: {}", LG.USBLOGERROR, exception.getMessage());
            }
        }
    }

}
