package ru.usb.advisor_siebel.service;

import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.advisor_siebel.config.Config;
import ru.usb.advisor_siebel.config.LG;
import ru.usb.advisor_siebel.model.MessageFromKafka;
import ru.usb.advisor_siebel.model.siebel.SrvSovetnikBk;
import ru.usb.advisor_siebel.repository.SrvSovetnikBkRepository;
import ru.usb.advisor_siebel.service.db.BatchSaveSiebel;
import ru.usb.advisor_siebel.service.kafka.KafkaProducerService;
import ru.usb.advisor_siebel.utils.MessageMapper;

import javax.xml.crypto.Data;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

@Service
public class FlowBatchProcess {

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HHmmss");

    Logger logger = LoggerFactory.getLogger(FlowBatchProcess.class);

    private final EntityManager entityManager;
    private final KafkaProducerService producerService;
    private final BatchSaveSiebel saveSiebel;
    private final Config config;
    private final SrvSovetnikBkRepository srvSovetnikBkRepository;
    private final MessageMapper mapper;

    @Autowired
    public FlowBatchProcess(EntityManager entityManager, KafkaProducerService producerService, BatchSaveSiebel saveSiebel,
                            Config config, SrvSovetnikBkRepository srvSovetnikBkRepository, MessageMapper mapper) {
        this.entityManager = entityManager;
        this.producerService = producerService;
        this.saveSiebel = saveSiebel;
        this.config = config;
        this.srvSovetnikBkRepository = srvSovetnikBkRepository;
        this.mapper = mapper;
    }

    //Количество строк
    int lineCount = 0;     //Общее Количество строк

    /**
     * Основной процесс
     */
    @Transactional
    public void process() {
        logger.info("{} Start process.", LG.USBLOGINFO);

        //Проверяем, что сервис не активен
        if (config.isWorkProcess()) {
            logger.info("{}:## < FlowBatchProcess.Process Flow : SrvSovetnikBk уже включен, необходимо выйти из процесса. Переменная (config.isWorkProcess()=true > ##", LG.USBLOGINFO);
            return;
        }

        config.setWorkProcess(true);//Процесс стартовал
        config.setLastCount(0);
        config.setDateWorkProcess(new Date());

        //Получаем список записей из базы
        Stream<SrvSovetnikBk> fTableStream;
        List<SrvSovetnikBk> bkList = new ArrayList<>();

        try {
            logger.info("{}:#SQL# ", LG.USBLOGINFO);
            fTableStream = srvSovetnikBkRepository.getSrvSov();
            if (fTableStream == null) {
                logger.error("{} fTableStream = srvSovetnikBkRepository.getSrvSov() - поток вернулся = NULL! Так быть не должно!", LG.USBLOGERROR);
                return;
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream =  Stream<SrvSovetnikBk>", LG.USBLOGERROR);
            logger.error(e.getMessage());
            return;
        }


        logger.info("{}:## < Starting the process Flow : SrvSovetnikBk > ##", LG.USBLOGINFO);
        lineCount = 0; //Обнулили счетчик записей, строк

        try {
            fTableStream.forEach(srvSovetnikBk -> {
                lineCount++;
                logger.debug("DB={}", srvSovetnikBk);
                bkList.add(srvSovetnikBk);
                if (bkList.size() >= config.getBatchSize() && config.isServiceEnabled()) {
                    saveSiebel.batchSave(bkList);
                    bkList.clear();
                    System.gc();
                }
                entityManager.detach(srvSovetnikBk);
            });
            if (!bkList.isEmpty() && config.isServiceEnabled()) {
                saveSiebel.batchSave(bkList);
                bkList.clear();
                System.gc();
            }
            config.setLastCount(lineCount);
            //Отправляем сообщение в Кафка
            producerService.sendMessage(config.getSiebelTopic(), mapper.mapperToString(
                    new MessageFromKafka(config.getSystemFrom(),
                            config.getSystemTo(), config.getService(), "", null,
                            getGuid(new Date()), "count_record=" + lineCount, null, null)));
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, при обработке потока: fTableStream.forEach", LG.USBLOGERROR);
            logger.error(e.getMessage());
        } finally {
            fTableStream.close();
        }
        logger.info("{}: Количество обработанных записей: {}", LG.USBLOGINFO, lineCount);
        logger.info("{} Stop process. {}", LG.USBLOGINFO, lineCount);
        config.setWorkProcess(false);//Процесс остановился
        config.setDateWorkProcess(new Date());
    }

    /**
     * Получаем GUID
     *
     * @param date - дата в формате yyyy-MM-dd_HHmmss
     * @return - GUID в формате yyyy-MM-dd_HHmmss + UUID
     */
    private String getGuid(Date date) {
        return sdf.format(date) + java.util.UUID.randomUUID().toString();
    }
}
