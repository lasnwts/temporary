package ru.usb.advisor_siebel;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import ru.usb.advisor_siebel.config.Config;
import ru.usb.advisor_siebel.config.LG;

import java.util.Date;

@SpringBootApplication
public class AdvisorSiebelApplication implements CommandLineRunner {

    private final Config config;

    public AdvisorSiebelApplication(Config config) {
        this.config = config;
    }

    private static final Logger logger = LoggerFactory.getLogger(AdvisorSiebelApplication.class);


    public static void main(String[] args) {
        SpringApplication.run(AdvisorSiebelApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${spring.application.name}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API \n\r Service [Микросервис: advisor-siebel] Интеграционный поток. МП 983804.")
                .contact(new Contact().email("lyapustinas@spb.uralsib.ru"))
                .version(appVersion)
                .description("API для [Интеграционный поток. МП 983804 Интеграция Советника в карточку клиента в Siebel CRM]" +
                        " library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info(".");
        logger.info("..");
        logger.info("...");
        logger.info("{}::----------------------------------------------------------------------------------------------------------------------------------------------------------+", LG.USBLOGINFO);
        logger.info("{}:| Name service                 : advisor-siebel", LG.USBLOGINFO);
        logger.info("{}:| Description of service       : Интеграционный поток. Интеграционный поток. МП 983804 Интеграция Советника в карточку клиента в Siebel CRM.", LG.USBLOGINFO);
        logger.info("{}:| Date created                 : 10/06/2025", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                              : Информация          ", LG.USBLOGINFO);
        logger.info("{}:+-----------------------------------------------------------------------------------------------------------------------------------------------------------_", LG.USBLOGINFO);
        logger.info("{}:|                  10.06.2025  : 0.0.10 Базовая версия.", LG.USBLOGINFO);
        logger.info("{}:=----------------------------------------------------------------------------------------------------------------------------------------------------------=", LG.USBLOGINFO);
        logger.info("...");
        logger.info("..");
        logger.info(".");

        //Инициализация
        config.setLastCount(0);
        config.setDateWorkProcess(new Date());
        config.setWorkProcess(false);

    }
}
