package ru.usb.advisor_siebel.repository;

import jakarta.persistence.QueryHint;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.advisor_siebel.model.siebel.SrvSovetnikBk;

import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
@Transactional
public interface SrvSovetnikBkRepository extends JpaRepository<SrvSovetnikBk , Long> {

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select concat(inn,STRATEGY_TXT) as id , inn,STRATEGY_TXT,Interaction_scenario,RECOMMEND_ACC_OPEN,RISK_KYC_BLOCK_MOD_TXT,REC_PROD_CL_TXT,REC_PROD_NOT_CL_TXT,REC_PU_NOT_CL_TXT,last_date_upload from srv_sovetnik_bk")
    Stream<SrvSovetnikBk> getSrvSov();
}
