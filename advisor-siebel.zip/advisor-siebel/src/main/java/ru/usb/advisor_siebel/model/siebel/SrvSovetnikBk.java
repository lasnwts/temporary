package ru.usb.advisor_siebel.model.siebel;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/**
 * inn varchar2(50),
 * STRATEGY_TXT varchar2(150),
 * Interaction_scenario  varchar2(250),
 * RECOMMEND_ACC_OPEN  varchar2(150),
 * RISK_KYC_BLOCK_MOD_TXT  varchar2(150),
 * REC_PROD_CL_TXT  varchar2(150),
 * REC_PROD_NOT_CL_TXT  varchar2(150),
 * REC_PU_NOT_CL_TXT  varchar2(150),
 * last_date_upload date
 * )
 */

@Entity
public class SrvSovetnikBk {

    @Id
    private String id;

    @Column(name = "inn")
    private String inn;

    @Column(name = "STRATEGY_TXT")
    private String strategyTxt;

    @Column(name = "Interaction_scenario")
    private String interactionScenario;

    @Column(name = "RECOMMEND_ACC_OPEN")
    private String recommendAccOpen;

    @Column(name = "RISK_KYC_BLOCK_MOD_TXT")
    private String riskKycBlockModTxt;

    @Column(name = "REC_PROD_CL_TXT")
    private String recProdClTxt;

    @Column(name = "REC_PROD_NOT_CL_TXT")
    private String recProdNotClTxt;

    @Column(name = "REC_PU_NOT_CL_TXT")
    private String recPuNotClTxt;

    @Column(name = "last_date_upload")
    private String lastDateUpload;


    public SrvSovetnikBk() {
        //empty
    }

    public SrvSovetnikBk(String id, String inn, String strategyTxt, String interactionScenario,
                         String recommendAccOpen, String riskKycBlockModTxt, String recProdClTxt,
                         String recProdNotClTxt, String recPuNotClTxt, String lastDateUpload) {
        this.id = id;
        this.inn = inn;
        this.strategyTxt = strategyTxt;
        this.interactionScenario = interactionScenario;
        this.recommendAccOpen = recommendAccOpen;
        this.riskKycBlockModTxt = riskKycBlockModTxt;
        this.recProdClTxt = recProdClTxt;
        this.recProdNotClTxt = recProdNotClTxt;
        this.recPuNotClTxt = recPuNotClTxt;
        this.lastDateUpload = lastDateUpload;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getStrategyTxt() {
        return strategyTxt;
    }

    public void setStrategyTxt(String strategyTxt) {
        this.strategyTxt = strategyTxt;
    }

    public String getInteractionScenario() {
        return interactionScenario;
    }

    public void setInteractionScenario(String interactionScenario) {
        this.interactionScenario = interactionScenario;
    }

    public String getRecommendAccOpen() {
        return recommendAccOpen;
    }

    public void setRecommendAccOpen(String recommendAccOpen) {
        this.recommendAccOpen = recommendAccOpen;
    }

    public String getRiskKycBlockModTxt() {
        return riskKycBlockModTxt;
    }

    public void setRiskKycBlockModTxt(String riskKycBlockModTxt) {
        this.riskKycBlockModTxt = riskKycBlockModTxt;
    }

    public String getRecProdClTxt() {
        return recProdClTxt;
    }

    public void setRecProdClTxt(String recProdClTxt) {
        this.recProdClTxt = recProdClTxt;
    }

    public String getRecProdNotClTxt() {
        return recProdNotClTxt;
    }

    public void setRecProdNotClTxt(String recProdNotClTxt) {
        this.recProdNotClTxt = recProdNotClTxt;
    }

    public String getRecPuNotClTxt() {
        return recPuNotClTxt;
    }

    public void setRecPuNotClTxt(String recPuNotClTxt) {
        this.recPuNotClTxt = recPuNotClTxt;
    }

    public String getLastDateUpload() {
        return lastDateUpload;
    }

    public void setLastDateUpload(String lastDateUpload) {
        this.lastDateUpload = lastDateUpload;
    }

    @Override
    public String toString() {
        return "SrvSovetnikBk{" +
                "id='" + id + '\'' +
                ", inn='" + inn + '\'' +
                ", strategyTxt='" + strategyTxt + '\'' +
                ", interactionScenario='" + interactionScenario + '\'' +
                ", recommendAccOpen='" + recommendAccOpen + '\'' +
                ", riskKycBlockModTxt='" + riskKycBlockModTxt + '\'' +
                ", recProdClTxt='" + recProdClTxt + '\'' +
                ", recProdNotClTxt='" + recProdNotClTxt + '\'' +
                ", recPuNotClTxt='" + recPuNotClTxt + '\'' +
                ", lastDateUpload='" + lastDateUpload + '\'' +
                '}';
    }
}
