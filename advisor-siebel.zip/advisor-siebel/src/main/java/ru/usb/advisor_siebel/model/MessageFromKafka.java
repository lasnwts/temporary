package ru.usb.advisor_siebel.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Сообщение универсально для Зибель
 * JSON-схема универсального запроса:
 * <p>
 * {
 * "system_from":"string",
 * "system_to":"string",
 * "service":"string",
 * "routeID":"string",
 * "mapper":"integer",
 * "packID":"string",
 * "pack":"string"
 * "error":"integer"
 * "errortext":"string"
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class MessageFromKafka {

    @JsonProperty("system_from")
    private String systemFrom;

    @JsonProperty("system_to")
    private String systemTo;

    @JsonProperty("service")
    private String service;

    @JsonProperty("routeid")
    private String routeID;

    @JsonProperty("mapper")
    private String mapper;

    @JsonProperty("packID")
    private String packID;

    @JsonProperty("pack")
    private String pack;

    @JsonProperty("error")
    private String error;

    @JsonProperty("errortext")
    private String errorText;

    public MessageFromKafka() {
        //empty
    }

    public MessageFromKafka(String systemFrom, String systemTo, String service, String routeID,
                            String mapper, String packID, String pack, String error, String errorText) {
        this.systemFrom = systemFrom;
        this.systemTo = systemTo;
        this.service = service;
        this.routeID = routeID;
        this.mapper = mapper;
        this.packID = packID;
        this.pack = pack;
        this.error = error;
        this.errorText = errorText;
    }

    public String getSystemFrom() {
        return systemFrom;
    }

    public void setSystemFrom(String systemFrom) {
        this.systemFrom = systemFrom;
    }

    public String getSystemTo() {
        return systemTo;
    }

    public void setSystemTo(String systemTo) {
        this.systemTo = systemTo;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getRouteID() {
        return routeID;
    }

    public void setRouteID(String routeID) {
        this.routeID = routeID;
    }

    public String getMapper() {
        return mapper;
    }

    public void setMapper(String mapper) {
        this.mapper = mapper;
    }

    public String getPackID() {
        return packID;
    }

    public void setPackID(String packID) {
        this.packID = packID;
    }

    public String getPack() {
        return pack;
    }

    public void setPack(String pack) {
        this.pack = pack;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }

    public String getError() {
        if (error == null) {
            return "";
        } else {
            return error;
        }
    }

    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "MessageFromKafka{" +
                "systemFrom='" + systemFrom + '\'' +
                ", systemTo='" + systemTo + '\'' +
                ", service='" + service + '\'' +
                ", routeID='" + routeID + '\'' +
                ", mapper='" + mapper + '\'' +
                ", packID='" + packID + '\'' +
                ", pack='" + pack + '\'' +
                ", error='" + error + '\'' +
                ", errorText='" + errorText + '\'' +
                '}';
    }
}
