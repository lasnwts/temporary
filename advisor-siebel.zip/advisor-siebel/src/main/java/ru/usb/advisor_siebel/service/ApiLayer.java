package ru.usb.advisor_siebel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.advisor_siebel.config.Config;
import ru.usb.advisor_siebel.config.LG;


@Service
public class ApiLayer {

    private final Config config;
    private final FlowBatchProcess flowBatchProcess;

    @Autowired
    public ApiLayer(Config config, FlowBatchProcess flowBatchProcess) {
        this.config = config;
        this.flowBatchProcess = flowBatchProcess;
    }

    private final Logger logger = LoggerFactory.getLogger(ApiLayer.class);


    /**
     * Включен или выключен сервис
     *
     * @return -  - true - сервис включен, false - сервис выключен
     */
    public boolean getServiceEnabled() {
        return config.isServiceEnabled();
    }

    /**
     * Проверка работы сервиса
     * <p>
     * Возвращает количество переданных записей при последнем запуске и дату последнего запуска
     */
    public String getStatus() {
        String response = "\n\r <br>" + "Количество переданных записей при последнем запуске:" + config.getLastCount() + "\n\r <br>" +
                "Дата последнего запуска: " + config.getDateWorkProcess() + "\n\r <br>";
        if (config.isWorkProcess()) {
            response += "Процесс сейчас запущен";
        } else {
            response += "Процесс сейчас не запущен";
        }
        return response;
    }


    /**
     * Включить или выключить сервис
     *
     * @param serviceEnabled - true - включить, false - выключить
     */
    public void setServiceEnabled(boolean serviceEnabled) {
        if (serviceEnabled) {
            logger.info("{}:[serviceStart] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[serviceStop] Web API. Service disabled", LG.USBLOGINFO);
        }
        config.setServiceEnabled(serviceEnabled);
        config.setWorkProcess(false);
    }

    /**
     * Выключение сервиса
     */
    public void serviceExit() {
        logger.info("{}:[serviceExit] Web API. Service exited=0", LG.USBLOGINFO);
        System.exit(0);
    }

    /**
     * Запуск процесса
     */
    public boolean startProcess() {
        if (config.isWorkProcess()) {
            logger.info("{}:[startProcess] Web API. Process already started/Поэтому старт по Web API отменяем. Ждем окончания процесса.", LG.USBLOGINFO);
            return false;
        } else {
            logger.info("{}:[startProcess] Web API. Process started. Запущен процесс переноса.", LG.USBLOGINFO);
            flowBatchProcess.process();
            return true;
        }
    }
}
