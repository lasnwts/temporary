package ru.usb.advisor_siebel.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.util.Objects;

/**
 * Класс конфигурации для создания DataSource, которые используются для обращения к базе данных.
 * В данном классе устанавливаются параметры для подключения, взятые с application.properties
 */
@Configuration
public class JdbcConfig {

    private Environment env;

    @Autowired
    public JdbcConfig(Environment env) {
        this.env = env;
    }

    @Bean(name = "siebelDataSource")
    public DataSource siebelDataSource() {
        DriverManagerDataSource datasource = new DriverManagerDataSource();
        datasource.setDriverClassName(Objects.requireNonNull(env.getProperty("siebel.driverClassName")));
        datasource.setUrl(env.getProperty("siebel.url"));
        datasource.setUsername(env.getProperty("siebel.username"));
        datasource.setPassword(env.getProperty("siebel.password"));
        return datasource;
    }
}
