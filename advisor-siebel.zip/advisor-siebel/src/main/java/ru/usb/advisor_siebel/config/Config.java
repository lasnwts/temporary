package ru.usb.advisor_siebel.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
@ConfigurationProperties
public class Config {

    private boolean workProcess; //Работает процесс или нет, true - работает, false - нет
    private int lastCount; //Кол-во переданных записей
    private Date dateWorkProcess; //Дата процесса

    public boolean isWorkProcess() {
        return workProcess;
    }

    public void setWorkProcess(boolean workProcess) {
        this.workProcess = workProcess;
    }

    public int getLastCount() {
        return lastCount;
    }

    public void setLastCount(int lastCount) {
        this.lastCount = lastCount;
    }

    public Date getDateWorkProcess() {
        return dateWorkProcess;
    }

    public void setDateWorkProcess(Date dateWorkProcess) {
        this.dateWorkProcess = dateWorkProcess;
    }

    //system.from=KIMB-BK-Sovetnik-Load-dev
    @Value("${system.from}")
    private String systemFrom;

    //system.to=siebel.dev
    @Value("${system.to}")
    private String systemTo;

    //service=KIMB BK Sovetnik Load
    @Value("${service}")
    private String service;

    //Топик отправки сообщений в Зибель
    @Value("${siebel.topic}")
    private String siebelTopic;

    /**
     * Размер пакета для обработки
     */
    @Value("${siebel.batch.size:1000}")
    private int siebelBatchSize;
    /**
     * Включение сервиса
     */
    @Value("${service.enabled}")
    private boolean serviceEnabled;

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;


    /**
     * Параметры версии Info, description
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;


    public boolean isServiceEnabled() {
        return serviceEnabled;
    }

    public int getBatchSize() {
        return siebelBatchSize;
    }

    public String getSiebelTopic() {
        return siebelTopic;
    }

    public String getSystemFrom() {
        return systemFrom;
    }

    public String getSystemTo() {
        return systemTo;
    }

    public String getService() {
        return service;
    }

    public void setServiceEnabled(boolean serviceEnabled) {
        this.serviceEnabled = serviceEnabled;
    }
}
