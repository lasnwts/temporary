package ru.usb.advisor_siebel.service.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.advisor_siebel.config.JdbcConfig;
import ru.usb.advisor_siebel.config.LG;
import ru.usb.advisor_siebel.model.siebel.SrvSovetnikBk;

import java.sql.*;
import java.util.List;

@Service
public class BatchSaveSiebel {

    Logger log = LoggerFactory.getLogger(BatchSaveSiebel.class);

    private static final String INSERT_TO_SIEBEL = "insert into siebelbk (inn,STRATEGY_TXT,RECOMMEND_ACC_OPEN,RISK_KYC_BLOCK_MOD_TXT,REC_PROD_CL_TXT,REC_PROD_NOT_CL_TXT,REC_PU_NOT_CL_TXT) values (?,?,?,?,?,?,?)";

    private final JdbcConfig jdbcConfig;

    @Autowired
    public BatchSaveSiebel(JdbcConfig jdbcConfig) {
        this.jdbcConfig = jdbcConfig;
    }

    /**
     * Метод для массового сохранения в БД
     *
     * @param sovetnikBkList - список записей из БД
     * @throws SQLException - ошибка при сохранении в БД
     */
    public void batchSave(List<SrvSovetnikBk> sovetnikBkList) {
        try (Connection connection = jdbcConfig.siebelDataSource().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_TO_SIEBEL)) {
            connection.setAutoCommit(false); // Disable auto-commit
            for (SrvSovetnikBk currentRecord : sovetnikBkList) {
                preparedStatement.setString(1, currentRecord.getInn());
                preparedStatement.setString(2, currentRecord.getStrategyTxt());
                preparedStatement.setString(3, currentRecord.getRecommendAccOpen());
                preparedStatement.setString(4, currentRecord.getRiskKycBlockModTxt());
                preparedStatement.setString(5, currentRecord.getRecProdClTxt());
                preparedStatement.setString(6, currentRecord.getRecProdNotClTxt());
                preparedStatement.setString(7, currentRecord.getRecPuNotClTxt());
                preparedStatement.addBatch();
            }
            int[] affectedRows = preparedStatement.executeBatch();
            connection.commit(); // Commit the transaction
            log.info("{}: Batch insert successful. Rows affected: {}", LG.USBLOGINFO, affectedRows.length);
        } catch (BatchUpdateException e) {
            log.error("{}: Batch insert failed.", LG.USBLOGERROR);
            int[] updateCounts = e.getUpdateCounts();
            for (int i = 0; i < updateCounts.length; i++) {
                if (updateCounts[i] == Statement.EXECUTE_FAILED) {
                    log.warn("{}: Statement at index {} failed.", LG.USBLOGERROR, i);
                }
            }
        } catch (SQLException e) {
            log.error("{}: Batch insert failed.Error during batch insert: {}", LG.USBLOGERROR, e.getMessage());
            log.debug("{}: Batch insert failed. PrintStack trace:", LG.USBLOGERROR, e);
        }
    }
}
