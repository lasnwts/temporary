package ru.usb.advisor_siebel.controlller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.advisor_siebel.config.LG;
import ru.usb.advisor_siebel.service.ApiLayer;

@RestController
@RequestMapping("/api")
@Tag(name = "Контроллер ввода данных", description = "Установка даты, получение отчета")
public class ApiController {

    private final Logger logger = LoggerFactory.getLogger(ApiController.class);

    private final ApiLayer apiLayer;

    @Autowired
    public ApiController(ApiLayer apiLayer) {
        this.apiLayer = apiLayer;
    }

    /**
     * Включение/отключение работы сервиса
     */
    @PutMapping(value = "/sets/{enabled}")
    @Operation(summary = "Включить/отключить работу сервиса")
    public ResponseEntity<String> setEnableService(@Parameter(description = "true - включить, false - выключить") @PathVariable("enabled") boolean enabled) {
        apiLayer.setServiceEnabled(enabled);
        if (enabled) {
            logger.info("{}:[setEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[setEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled(), HttpStatus.OK);
    }

    /**
     * Проверка работы сервиса
     */
    @GetMapping(value = "/get")
    @Operation(summary = "Посмотреть работу сервиса")
    public ResponseEntity<String> getEnableService() {
        if (apiLayer.getServiceEnabled()) {
            logger.info("{}:[getEnableService] Web API. Service enabled", LG.USBLOGINFO);
        } else {
            logger.info("{}:[getEnableService] Web API. Service disabled", LG.USBLOGINFO);
        }
        return new ResponseEntity<>("Service enabled:" + apiLayer.getServiceEnabled() + apiLayer.getStatus(), HttpStatus.OK);
    }

    /**
     * Отключение сервиса
     */
    @PutMapping(value = "/exit")
    @Operation(summary = "Выключить сервис")
    public ResponseEntity<String> exitService() {
        logger.info("{}:[exitService] Web API. Service disabled", LG.USBLOGINFO);
        apiLayer.serviceExit();
        return new ResponseEntity<>("Service disabled", HttpStatus.OK);
    }

    /**
     * Запуск процесса
     */
    @GetMapping(value = "/start")
    @Operation(summary = "Тестовый запуск процесса переноса")
    public ResponseEntity<String> test() {
        logger.info("{}:[Start process] Web API. Test", LG.USBLOGINFO);
        if (apiLayer.startProcess()){
            return new ResponseEntity<>("Процесса запущен.. Результаты можно посмотреть в логе", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Процесс уже запущен. Пока что запуск невозможен!", HttpStatus.OK);
        }
    }

}
