package ru.usb.citixlsimport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitixlsimportApplicationTests {

	@Test
	void contextLoads() {
	}

}
