package ru.usb.citixlsimport.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "total_pay_ofpl")
public class TotalPlayOfPL {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //Номер Кредитного договора
    //Поле 2
    private String ACC_NUM;

    //Сумма основного долга (срочного и просроченного) на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal TOT_LOAN_SUM;

    //Сумма основного долга (просроченного) на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal LOAN_DEB_SUM;

    //Сумма основного долга (срочного) на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal LOAN_SUM;

    //Сумма процентов (срочных и просроченных, включая проценты по 106-ФЗ) на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal TOT_PRC_SUM;

    //Сумма процентов (просроченных) на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal PRC_DEB_SUM;

    //Сумма процентов (срочных) на 21.11.22 (не включают проценты по 106-ФЗ)
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal PRC_SUM;

    //Сумма процентов, начисленных за период Кредитных каникул (106_ФЗ) на 21.11.22.
    //(данная сумма процентов не включена в сумму срочных процентов)
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal PRC_SUM_HOLIDAY;

    //Комиссии за просроченный основной долг на 21.11.22
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal SUM_PENI;

    //Сумма общей задолженности по кредиту на 21.11.22 включая: сумму основного долга (колонка C) + сумму процентов срочных и просроченных,
    // включая проценты по 106-ФЗ(колонка F) + комиссии за просроченный основной долг (колонка J)
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal TOTAL_SUM;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int NumStr;

    public TotalPlayOfPL() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getACC_NUM() {
        return ACC_NUM;
    }

    public void setACC_NUM(String ACC_NUM) {
        this.ACC_NUM = ACC_NUM;
    }

    public BigDecimal getTOT_LOAN_SUM() {
        return TOT_LOAN_SUM;
    }

    public void setTOT_LOAN_SUM(BigDecimal TOT_LOAN_SUM) {
        this.TOT_LOAN_SUM = TOT_LOAN_SUM;
    }

    public BigDecimal getLOAN_DEB_SUM() {
        return LOAN_DEB_SUM;
    }

    public void setLOAN_DEB_SUM(BigDecimal LOAN_DEB_SUM) {
        this.LOAN_DEB_SUM = LOAN_DEB_SUM;
    }

    public BigDecimal getLOAN_SUM() {
        return LOAN_SUM;
    }

    public void setLOAN_SUM(BigDecimal LOAN_SUM) {
        this.LOAN_SUM = LOAN_SUM;
    }

    public BigDecimal getTOT_PRC_SUM() {
        return TOT_PRC_SUM;
    }

    public void setTOT_PRC_SUM(BigDecimal TOT_PRC_SUM) {
        this.TOT_PRC_SUM = TOT_PRC_SUM;
    }

    public BigDecimal getPRC_DEB_SUM() {
        return PRC_DEB_SUM;
    }

    public void setPRC_DEB_SUM(BigDecimal PRC_DEB_SUM) {
        this.PRC_DEB_SUM = PRC_DEB_SUM;
    }

    public BigDecimal getPRC_SUM() {
        return PRC_SUM;
    }

    public void setPRC_SUM(BigDecimal PRC_SUM) {
        this.PRC_SUM = PRC_SUM;
    }

    public BigDecimal getPRC_SUM_HOLIDAY() {
        return PRC_SUM_HOLIDAY;
    }

    public void setPRC_SUM_HOLIDAY(BigDecimal PRC_SUM_HOLIDAY) {
        this.PRC_SUM_HOLIDAY = PRC_SUM_HOLIDAY;
    }

    public BigDecimal getSUM_PENI() {
        return SUM_PENI;
    }

    public void setSUM_PENI(BigDecimal SUM_PENI) {
        this.SUM_PENI = SUM_PENI;
    }

    public BigDecimal getTOTAL_SUM() {
        return TOTAL_SUM;
    }

    public void setTOTAL_SUM(BigDecimal TOTAL_SUM) {
        this.TOTAL_SUM = TOTAL_SUM;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return NumStr;
    }

    public void setNumStr(int numStr) {
        NumStr = numStr;
    }

    @Override
    public String toString() {
        return "TotalPlayOfPL{" +
                "id=" + id +
                ", ACC_NUM='" + ACC_NUM + '\'' +
                ", TOT_LOAN_SUM=" + TOT_LOAN_SUM +
                ", LOAN_DEB_SUM=" + LOAN_DEB_SUM +
                ", LOAN_SUM=" + LOAN_SUM +
                ", TOT_PRC_SUM=" + TOT_PRC_SUM +
                ", PRC_DEB_SUM=" + PRC_DEB_SUM +
                ", PRC_SUM=" + PRC_SUM +
                ", PRC_SUM_HOLIDAY=" + PRC_SUM_HOLIDAY +
                ", SUM_PENI=" + SUM_PENI +
                ", TOTAL_SUM=" + TOTAL_SUM +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                ", NumStr=" + NumStr +
                '}';
    }
}
