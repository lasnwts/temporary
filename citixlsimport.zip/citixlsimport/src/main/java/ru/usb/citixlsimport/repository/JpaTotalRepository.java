package ru.usb.citixlsimport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citixlsimport.model.TotalPlayOfPL;

public interface JpaTotalRepository extends JpaRepository<TotalPlayOfPL, Long> {
}
