package ru.usb.citixlsimport.service.readxls;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.citixlsimport.config.Configure;
import ru.usb.citixlsimport.model.Psk;
import ru.usb.citixlsimport.repository.JpaPskRepository;
import ru.usb.citixlsimport.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

@Component
public class ReadPskXlsx {

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    Configure configure;

    @Autowired
    JpaPskRepository jpaPskRepository;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadPskXlsx.class);

    public Workbook workbook;
    private String sDate;
    private int rowEnd;


    public boolean getFileXLS(File xlsFile) {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(xlsFile);
        } catch (FileNotFoundException e) {
            logger.error("ReadPskXlsx:getFileXLS:FileNotFoundException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        }
        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = null;
        try {
            myWorkBook = new XSSFWorkbook(fis);

            /**
             * Основное тело
             */

            // Return first sheet from the XLSX workbook
            XSSFSheet mySheet = myWorkBook.getSheetAt(0);

            // Get iterator to all the rows in current sheet
            Iterator<Row> rowIterator = mySheet.iterator();

            // Traversing over each row of XLSX file
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                if (row.getRowNum() == 0) {
                    row = rowIterator.next();
                }

                Psk psk = new Psk();

                // For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                int currentCell = 0;

                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    if (currentCell == 0) {
                        psk.setACC_NUM(cell.getStringCellValue());
                    }

                    if (currentCell == 1) {
                        psk.setPSK_SUM(String.format("%.2f", cell.getNumericCellValue()));
                        psk.setPSK_SUM_B(new BigDecimal(cell.getNumericCellValue()));
                    }

                    currentCell = currentCell + 1;

                    if (currentCell > 1) {
                        break;
                    }

                }
                /**
                 * Служебные параметры дата и время вставки + имя файла
                 */
                psk.setInputDate(new Date());
                psk.setFILENAME(xlsFile.getName());
                psk.setNumStr(row.getRowNum());
                jpaPskRepository.save(psk);
//                logger.info(psk.toString());
                psk = null;
            }


        } catch (IOException e) {
            logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        } finally {
            try {
                myWorkBook.close();
            } catch (IOException e) {
                logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
            try {
                fis.close();
            } catch (IOException e) {
                logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
        }
        return true;
    }


}
