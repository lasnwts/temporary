package ru.usb.citixlsimport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citixlsimport.model.Depart;

public interface JpaDepartRepository extends JpaRepository<Depart, Long> {
}
