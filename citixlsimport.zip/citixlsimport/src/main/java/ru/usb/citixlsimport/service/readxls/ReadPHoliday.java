package ru.usb.citixlsimport.service.readxls;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.citixlsimport.config.Configure;
import ru.usb.citixlsimport.model.PlHoliday;
import ru.usb.citixlsimport.repository.JpaPHolidayRepository;
import ru.usb.citixlsimport.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Iterator;

@Component
public class ReadPHoliday {

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    Configure configure;

    @Autowired
    JpaPHolidayRepository jpaPHolidayRepository;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadPHoliday.class);

    public Workbook workbook;
    private String sDate;
    private int rowEnd;


    /**
     * Получаем число
     *
     * @param cell
     * @return
     */
    private BigDecimal getBD(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return new BigDecimal("0");
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return new BigDecimal("0");
                    }
                    return new BigDecimal(cell.getStringCellValue());
                } catch (Exception e) {
                    return new BigDecimal("0");
                }
            case NUMERIC:
                //tPlay.setTOT_LOAN_SUM_STR(String.format("%.2f", cell.getNumericCellValue()));
                return new BigDecimal(cell.getNumericCellValue());
            default:
                return new BigDecimal("0");
        }
    }


    /**
     * Возвращает строку
     *
     * @return
     */
    private String get2String(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return "";
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return "";
                    }
                    if (cell.getStringCellValue().length() > 2) {
                        return cell.getStringCellValue().trim().substring(0, 2);
                    } else {
                        return cell.getStringCellValue().trim();
                    }

                } catch (Exception e) {
                    return "";
                }
            default:
                return "";
        }
    }

    private String getString(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return null;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return "";
                    }
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return null;
                }
            default:
                return null;
        }
    }

    /**
     * Основной код чтения и создания объектов из записей XLS файла
     *
     * @param xlsFile
     * @return
     */

    public boolean getFileXLS(File xlsFile) {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(xlsFile);
        } catch (FileNotFoundException e) {
            logger.error("ReadPHoliday:getFileXLS:FileNotFoundException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        }
        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = null;
        try {
            myWorkBook = new XSSFWorkbook(fis);

            /**
             * Основное тело
             */

            // Return first sheet from the XLSX workbook
            XSSFSheet mySheet = myWorkBook.getSheetAt(0);

            // Get iterator to all the rows in current sheet
            Iterator<Row> rowIterator = mySheet.iterator();

            // Traversing over each row of XLSX file
            while (rowIterator.hasNext()) {

                Row row = rowIterator.next();

                if (row.getRowNum() == 0) {
                    row = rowIterator.next();
                }

                if (row.getRowNum() == 1) {
                    row = rowIterator.next();
                }

                PlHoliday plHoliday = new PlHoliday();

                // For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                int currentCell = 0;

                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    if (currentCell == 0) {
                        plHoliday.setACC_NUM(getString(cell));
                    }

                    if (currentCell == 1) {
                        plHoliday.setCLIENT_NUM(getString(cell));
                    }

                    if (currentCell == 2) {
                        plHoliday.setHOLIDAY_TYPE(get2String(cell));
                    }

                    if (currentCell == 3) {
                        plHoliday.setHOLIDAY_DATE_APPL(getDate(cell));
                    }

                    if (currentCell == 4) {
                        plHoliday.setHOLIDAY_DATE_PROV(getDate(cell));
                    }

                    if (currentCell == 5) {
                        plHoliday.setHOLIDAY_DATE_BEGIN(getDate(cell));
                    }

                    if (currentCell == 6) {
                        plHoliday.setHOLIDAY_DATE_END_PLAN(getDate(cell));
                    }

                    if (currentCell == 7) {
                        plHoliday.setHOLIDAY_DATE_END_FACT(getDate(cell));
                    }

                    if (currentCell == 8) {
                        plHoliday.setHOLIDAY_END_REASON(get2String(cell));
                    }

                    if (currentCell == 9) {
                        plHoliday.setHOLIDAY_DATE_TERM_APPL(getDate(cell));
                    }

                    if (currentCell == 10) {
                        plHoliday.setAFTER_HOLIDAY_DATE_FIRST_PAY_FACT(getDate(cell));
                    }

                    if (currentCell == 11) {
                        plHoliday.setHOLIDAY_DATE_FIRST_REAB_PAY(getDate(cell));
                    }

                    if (currentCell == 12) {
                        plHoliday.setHOLIDAY_DATE_LAST_REAB_PAY(getDate(cell));
                    }

                    if (currentCell == 13) {
                        plHoliday.setHOLIDAY_PRC_RATE(getBD(cell));
                    }

                    if (currentCell == 14) {
                        plHoliday.setHOLIDAY_PRC_SUM_TOT(getBD(cell));
                    }

                    if (currentCell == 15) {
                        plHoliday.setHOLIDAY_STATUS(get2String(cell));
                    }

                    if (currentCell == 16) {
                        plHoliday.setAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN(getDate(cell));
                    }

                    if (currentCell == 17) {
                        plHoliday.setDATE_END_BEFORE(getDate(cell));
                    }

                    if (currentCell == 18) {
                        plHoliday.setDATE_END_ACTUAL(getDate(cell));
                    }

                    if (currentCell == 19) {

                    }

                    if (currentCell == 20) {

                    }

                    if (currentCell == 21) {
                        plHoliday.setHOLIDAY_PRC_SUM_REM(getBD(cell));
                    }

                    currentCell = currentCell + 1;

                    if (currentCell > 21) {
                        break;
                    }

                }
                /**
                 * Служебные параметры дата и время вставки + имя файла
                 */
                plHoliday.setInputDate(new Date());
                plHoliday.setFILENAME(xlsFile.getName());
                plHoliday.setNumStr(row.getRowNum() + 1);
                jpaPHolidayRepository.save(plHoliday);
                if (configure.isFileFlagCSV()) {
                    logger.info(plHoliday.toString());
                }
                plHoliday = null;
            }


        } catch (IOException e) {
            logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        } finally {
            try {
                myWorkBook.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
            try {
                fis.close();
            } catch (IOException e) {
                logger.error("ReadPHoliday:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
        }
        return true;
    }


    /**
     * Получение даты
     * @param cell
     * @return
     */
    private Date getDate(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    if (cell.getStringCellValue() == null) {
                        return null;
                    }
                    if (cell.getStringCellValue().length() == 0) {
                        return null;
                    }
                    return null;
                } catch (Exception e) {
                    return null;
                }
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    return null;
                }
            default:
                return null;
        }
    }



}
