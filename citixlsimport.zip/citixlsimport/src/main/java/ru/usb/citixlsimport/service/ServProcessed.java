package ru.usb.citixlsimport.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citixlsimport.config.Configure;
import ru.usb.citixlsimport.service.readxls.ReadPskXlsx;
import ru.usb.citixlsimport.service.readxls.ReadTotalPlayOff;
import ru.usb.citixlsimport.utils.WorkWithFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;

@Service
public class ServProcessed {


    Logger logger = LoggerFactory.getLogger(ServProcessed.class);

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    ReadPskXlsx readPskXlsx;

    @Autowired
    ReadTotalPlayOff readTotalPlayOff;

    /**
     * Запуск обработки файла PSK
     */
    public void PskService(File fName) {
        try {
            if (readPskXlsx.getFileXLS(fName)) {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
            } else {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName.getName());
            }
        } catch (Exception e) {
            logger.error("Ошибка обраболтки файла: {}, короткое наименование файла : {}", fName.getAbsolutePath(), fName.getName());
            logger.error("Error:{}", e.getMessage());
        }
    }

    /**
     * Запуск обработки файла total pay Off
     */
    public void TotalPayService(File fName) {
        try {
            if (readTotalPlayOff.getFileXLS(fName)) {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
            } else {
                withFiles.moveFileSName(fName.getAbsolutePath(), configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName.getName());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName.getName());
            }
        } catch (Exception e) {
            logger.error("Ошибка обраболтки файла: {}, короткое наименование файла : {}", fName.getAbsolutePath(), fName.getName());
            logger.error("Error:{}", e.getMessage());
        }
    }
}
