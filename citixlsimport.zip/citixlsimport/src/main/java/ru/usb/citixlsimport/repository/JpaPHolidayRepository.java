package ru.usb.citixlsimport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citixlsimport.model.PlHoliday;

public interface JpaPHolidayRepository extends JpaRepository<PlHoliday, Long> {
}
