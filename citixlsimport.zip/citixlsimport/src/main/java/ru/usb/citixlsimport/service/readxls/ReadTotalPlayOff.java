package ru.usb.citixlsimport.service.readxls;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.citixlsimport.config.Configure;
import ru.usb.citixlsimport.model.TotalPlayOfPL;
import ru.usb.citixlsimport.repository.JpaTotalRepository;
import ru.usb.citixlsimport.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

@Component
public class ReadTotalPlayOff {

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    Configure configure;

    @Autowired
    JpaTotalRepository jpaTotalRepository;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(ReadTotalPlayOff.class);

    public Workbook workbook;
    private String sDate;
    private int rowEnd;
    private boolean flgEndOfFile;


    public boolean getFileXLS(File xlsFile) {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(xlsFile);
        } catch (FileNotFoundException e) {
            logger.error("ReadPskXlsx:getFileXLS:FileNotFoundException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        }
        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = null;
        try {
            myWorkBook = new XSSFWorkbook(fis);

            /**
             * Основное тело
             */

            // Return first sheet from the XLSX workbook
            XSSFSheet mySheet = myWorkBook.getSheetAt(0);

            // Get iterator to all the rows in current sheet
            Iterator<Row> rowIterator = mySheet.iterator();

            //flg=true
            flgEndOfFile = true;

            // Traversing over each row of XLSX file
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                if (row.getRowNum() == 0) {
                    row = rowIterator.next();
                }

                if (!flgEndOfFile) {
                    break;
                }

                TotalPlayOfPL tPlay = new TotalPlayOfPL();

                // For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                int currentCell = 0;

                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    if (currentCell == 0) {
                        if (getEnded(cell)) {
                            flgEndOfFile = false;
                            break;
                        }
                    }

                    if (currentCell == 1) {
                        tPlay.setACC_NUM(cell.getStringCellValue());
                    }

                    if (currentCell == 2) {
                        tPlay.setTOT_LOAN_SUM(getBD(cell));
                    }

                    if (currentCell == 3) {
                        tPlay.setLOAN_DEB_SUM(getBD(cell));
                    }

                    if (currentCell == 4) {
                        tPlay.setLOAN_SUM(getBD(cell));
                    }

                    if (currentCell == 5) {
                        tPlay.setTOT_PRC_SUM(getBD(cell));
                    }

                    if (currentCell == 6) {
                        tPlay.setPRC_DEB_SUM(getBD(cell));
                    }

                    if (currentCell == 7) {
                        tPlay.setPRC_SUM(getBD(cell));
                    }

                    if (currentCell == 8) {
                        tPlay.setPRC_SUM_HOLIDAY(getBD(cell));
                    }

                    if (currentCell == 9) {
                        tPlay.setSUM_PENI(getBD(cell));
                    }

                    if (currentCell == 10) {
                        tPlay.setTOTAL_SUM(getBD(cell));
                    }

                    currentCell = currentCell + 1;

                    if (currentCell > 10) {
                        break;
                    }

                }
                /**
                 * Служебные параметры дата и время вставки + имя файла
                 */
                if (flgEndOfFile) {
                    tPlay.setInputDate(new Date());
                    tPlay.setFILENAME(xlsFile.getName());
                    tPlay.setNumStr(row.getRowNum());
                    jpaTotalRepository.save(tPlay);
                    if (configure.isFileFlagCSV()){
                        logger.info(tPlay.toString());
                    }
                    tPlay = null;
                }
            }


        } catch (IOException e) {
            logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                    "Возникла ошибка при обработке файла" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
            return false;
        } finally {
            try {
                myWorkBook.close();
            } catch (IOException e) {
                logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [myWorkBook.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
            try {
                fis.close();
            } catch (IOException e) {
                logger.error("ReadPskXlsx:getFileXLS:IOException:{}", e.getMessage());
                logger.error("Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath());
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(),
                        "Возникла ошибка при закрытие файла [fis.close()]" + xlsFile.getAbsolutePath() + " Error::" + e.getMessage());
                return false;
            }
        }
        return true;
    }


    /**
     * Получаем число
     *
     * @param cell
     * @return
     */
    private BigDecimal getBD(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                try {
                    return new BigDecimal(cell.getStringCellValue());
                } catch (Exception e) {
                    return new BigDecimal("0");
                }
            case NUMERIC:
                //tPlay.setTOT_LOAN_SUM_STR(String.format("%.2f", cell.getNumericCellValue()));
                return new BigDecimal(cell.getNumericCellValue());
            default:
                return new BigDecimal("0");
        }
    }


    /**
     * @param cell
     * @return
     */
    private boolean getEnded(Cell cell) {

        switch (cell.getCellType()) {
            case STRING:
                if (cell.getStringCellValue().toUpperCase(Locale.ROOT).contains("ИТОГО")) {
                    return true;
                } else {
                    return false;
                }
            default:
                return false;
        }
    }

}
