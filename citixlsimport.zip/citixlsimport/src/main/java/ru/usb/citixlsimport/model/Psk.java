package ru.usb.citixlsimport.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
public class Psk {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    private String ACC_NUM;
    private String PSK_SUM;
    @Column(nullable=false, precision=15, scale=2)
    private BigDecimal PSK_SUM_B;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int NumStr;

    public Psk() {
    }

    public Psk(long id, String ACC_NUM, String PSK_SUM, BigDecimal PSK_SUM_B, Date inputDate, String FILENAME) {
        this.id = id;
        this.ACC_NUM = ACC_NUM;
        this.PSK_SUM = PSK_SUM;
        this.PSK_SUM_B = PSK_SUM_B;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getACC_NUM() {
        return ACC_NUM;
    }

    public void setACC_NUM(String ACC_NUM) {
        this.ACC_NUM = ACC_NUM;
    }

    public String getPSK_SUM() {
        return PSK_SUM;
    }

    public void setPSK_SUM(String PSK_SUM) {
        this.PSK_SUM = PSK_SUM;
    }

    public BigDecimal getPSK_SUM_B() {
        return PSK_SUM_B;
    }

    public void setPSK_SUM_B(BigDecimal PSK_SUM_B) {
        this.PSK_SUM_B = PSK_SUM_B;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return NumStr;
    }

    public void setNumStr(int numStr) {
        NumStr = numStr;
    }

    @Override
    public String toString() {
        return "Psk{" +
                "id=" + id +
                ", ACC_NUM='" + ACC_NUM + '\'' +
                ", PSK_SUM='" + PSK_SUM + '\'' +
                ", PSK_SUM_B=" + PSK_SUM_B +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
