package ru.usb.citixlsimport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citixlsimport.model.Psk;

public interface JpaPskRepository extends JpaRepository<Psk, Long> {
}
