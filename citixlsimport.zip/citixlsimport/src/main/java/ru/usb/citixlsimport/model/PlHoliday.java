package ru.usb.citixlsimport.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "plholidays")
public class PlHoliday {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    private String ACC_NUM;
    private String CLIENT_NUM;

    //Первые 2 символа
    private String HOLIDAY_TYPE;
    private LocalDate HOLIDAY_DATE_APPL;
    private LocalDate HOLIDAY_DATE_PROV;
    private LocalDate HOLIDAY_DATE_BEGIN;
    private LocalDate HOLIDAY_DATE_END_PLAN;
    private LocalDate HOLIDAY_DATE_END_FACT;

    //Первые 2 символа
    private String HOLIDAY_END_REASON;
    private LocalDate HOLIDAY_DATE_TERM_APPL;
    private LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_FACT;
    private LocalDate HOLIDAY_DATE_FIRST_REAB_PAY;
    private LocalDate HOLIDAY_DATE_LAST_REAB_PAY;

    @Column(nullable=false, precision=18, scale=7)
    private BigDecimal HOLIDAY_PRC_RATE;

    @Column(nullable=false, precision=18, scale=5)
    private BigDecimal HOLIDAY_PRC_SUM_TOT;

    //Первые 2 символ строки
    private String HOLIDAY_STATUS;
    private LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN;
    private LocalDate DATE_END_BEFORE;
    private LocalDate DATE_END_ACTUAL;

    /**
     * 2 поля пропускаем
     * 19 и 20
     */

    //BigDecimal 18,5
            //Поле номер 21
    @Column(nullable=false, precision=18, scale=5)
    private BigDecimal HOLIDAY_PRC_SUM_REM;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int numStr;

    public PlHoliday() {
    }


    public PlHoliday(long id, String ACC_NUM, String CLIENT_NUM, String HOLIDAY_TYPE, LocalDate HOLIDAY_DATE_APPL,
                     LocalDate HOLIDAY_DATE_PROV, LocalDate HOLIDAY_DATE_BEGIN, LocalDate HOLIDAY_DATE_END_PLAN,
                     LocalDate HOLIDAY_DATE_END_FACT, String HOLIDAY_END_REASON, LocalDate HOLIDAY_DATE_TERM_APPL,
                     LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_FACT, LocalDate HOLIDAY_DATE_FIRST_REAB_PAY,
                     LocalDate HOLIDAY_DATE_LAST_REAB_PAY, BigDecimal HOLIDAY_PRC_RATE, BigDecimal HOLIDAY_PRC_SUM_TOT,
                     String HOLIDAY_STATUS, LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN, LocalDate DATE_END_BEFORE,
                     LocalDate DATE_END_ACTUAL, BigDecimal HOLIDAY_PRC_SUM_REM, Date inputDate, String FILENAME,
                     int numStr) {
        this.id = id;
        this.ACC_NUM = ACC_NUM;
        this.CLIENT_NUM = CLIENT_NUM;
        this.HOLIDAY_TYPE = HOLIDAY_TYPE;
        this.HOLIDAY_DATE_APPL = HOLIDAY_DATE_APPL;
        this.HOLIDAY_DATE_PROV = HOLIDAY_DATE_PROV;
        this.HOLIDAY_DATE_BEGIN = HOLIDAY_DATE_BEGIN;
        this.HOLIDAY_DATE_END_PLAN = HOLIDAY_DATE_END_PLAN;
        this.HOLIDAY_DATE_END_FACT = HOLIDAY_DATE_END_FACT;
        this.HOLIDAY_END_REASON = HOLIDAY_END_REASON;
        this.HOLIDAY_DATE_TERM_APPL = HOLIDAY_DATE_TERM_APPL;
        this.AFTER_HOLIDAY_DATE_FIRST_PAY_FACT = AFTER_HOLIDAY_DATE_FIRST_PAY_FACT;
        this.HOLIDAY_DATE_FIRST_REAB_PAY = HOLIDAY_DATE_FIRST_REAB_PAY;
        this.HOLIDAY_DATE_LAST_REAB_PAY = HOLIDAY_DATE_LAST_REAB_PAY;
        this.HOLIDAY_PRC_RATE = HOLIDAY_PRC_RATE;
        this.HOLIDAY_PRC_SUM_TOT = HOLIDAY_PRC_SUM_TOT;
        this.HOLIDAY_STATUS = HOLIDAY_STATUS;
        this.AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN = AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN;
        this.DATE_END_BEFORE = DATE_END_BEFORE;
        this.DATE_END_ACTUAL = DATE_END_ACTUAL;
        this.HOLIDAY_PRC_SUM_REM = HOLIDAY_PRC_SUM_REM;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
        this.numStr = numStr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getACC_NUM() {
        return ACC_NUM;
    }

    public void setACC_NUM(String ACC_NUM) {
        this.ACC_NUM = ACC_NUM;
    }

    public String getCLIENT_NUM() {
        return CLIENT_NUM;
    }

    public void setCLIENT_NUM(String CLIENT_NUM) {
        this.CLIENT_NUM = CLIENT_NUM;
    }

    public String getHOLIDAY_TYPE() {
        return HOLIDAY_TYPE;
    }

    public void setHOLIDAY_TYPE(String HOLIDAY_TYPE) {
        this.HOLIDAY_TYPE = HOLIDAY_TYPE;
    }

    public LocalDate getHOLIDAY_DATE_APPL() {
        return HOLIDAY_DATE_APPL;
    }

    public void setHOLIDAY_DATE_APPL(LocalDate HOLIDAY_DATE_APPL) {
        this.HOLIDAY_DATE_APPL = HOLIDAY_DATE_APPL;
    }

    public LocalDate getHOLIDAY_DATE_PROV() {
        return HOLIDAY_DATE_PROV;
    }

    public void setHOLIDAY_DATE_PROV(LocalDate HOLIDAY_DATE_PROV) {
        this.HOLIDAY_DATE_PROV = HOLIDAY_DATE_PROV;
    }

    public LocalDate getHOLIDAY_DATE_BEGIN() {
        return HOLIDAY_DATE_BEGIN;
    }

    public void setHOLIDAY_DATE_BEGIN(LocalDate HOLIDAY_DATE_BEGIN) {
        this.HOLIDAY_DATE_BEGIN = HOLIDAY_DATE_BEGIN;
    }

    public LocalDate getHOLIDAY_DATE_END_PLAN() {
        return HOLIDAY_DATE_END_PLAN;
    }

    public void setHOLIDAY_DATE_END_PLAN(LocalDate HOLIDAY_DATE_END_PLAN) {
        this.HOLIDAY_DATE_END_PLAN = HOLIDAY_DATE_END_PLAN;
    }

    public LocalDate getHOLIDAY_DATE_END_FACT() {
        return HOLIDAY_DATE_END_FACT;
    }

    public void setHOLIDAY_DATE_END_FACT(LocalDate HOLIDAY_DATE_END_FACT) {
        this.HOLIDAY_DATE_END_FACT = HOLIDAY_DATE_END_FACT;
    }

    public String getHOLIDAY_END_REASON() {
        return HOLIDAY_END_REASON;
    }

    public void setHOLIDAY_END_REASON(String HOLIDAY_END_REASON) {
        this.HOLIDAY_END_REASON = HOLIDAY_END_REASON;
    }

    public LocalDate getHOLIDAY_DATE_TERM_APPL() {
        return HOLIDAY_DATE_TERM_APPL;
    }

    public void setHOLIDAY_DATE_TERM_APPL(LocalDate HOLIDAY_DATE_TERM_APPL) {
        this.HOLIDAY_DATE_TERM_APPL = HOLIDAY_DATE_TERM_APPL;
    }

    public LocalDate getAFTER_HOLIDAY_DATE_FIRST_PAY_FACT() {
        return AFTER_HOLIDAY_DATE_FIRST_PAY_FACT;
    }

    public void setAFTER_HOLIDAY_DATE_FIRST_PAY_FACT(LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_FACT) {
        this.AFTER_HOLIDAY_DATE_FIRST_PAY_FACT = AFTER_HOLIDAY_DATE_FIRST_PAY_FACT;
    }

    public LocalDate getHOLIDAY_DATE_FIRST_REAB_PAY() {
        return HOLIDAY_DATE_FIRST_REAB_PAY;
    }

    public void setHOLIDAY_DATE_FIRST_REAB_PAY(LocalDate HOLIDAY_DATE_FIRST_REAB_PAY) {
        this.HOLIDAY_DATE_FIRST_REAB_PAY = HOLIDAY_DATE_FIRST_REAB_PAY;
    }

    public LocalDate getHOLIDAY_DATE_LAST_REAB_PAY() {
        return HOLIDAY_DATE_LAST_REAB_PAY;
    }

    public void setHOLIDAY_DATE_LAST_REAB_PAY(LocalDate HOLIDAY_DATE_LAST_REAB_PAY) {
        this.HOLIDAY_DATE_LAST_REAB_PAY = HOLIDAY_DATE_LAST_REAB_PAY;
    }

    public BigDecimal getHOLIDAY_PRC_RATE() {
        return HOLIDAY_PRC_RATE;
    }

    public void setHOLIDAY_PRC_RATE(BigDecimal HOLIDAY_PRC_RATE) {
        this.HOLIDAY_PRC_RATE = HOLIDAY_PRC_RATE;
    }

    public BigDecimal getHOLIDAY_PRC_SUM_TOT() {
        return HOLIDAY_PRC_SUM_TOT;
    }

    public void setHOLIDAY_PRC_SUM_TOT(BigDecimal HOLIDAY_PRC_SUM_TOT) {
        this.HOLIDAY_PRC_SUM_TOT = HOLIDAY_PRC_SUM_TOT;
    }

    public String getHOLIDAY_STATUS() {
        return HOLIDAY_STATUS;
    }

    public void setHOLIDAY_STATUS(String HOLIDAY_STATUS) {
        this.HOLIDAY_STATUS = HOLIDAY_STATUS;
    }

    public LocalDate getAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN() {
        return AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN;
    }

    public void setAFTER_HOLIDAY_DATE_FIRST_PAY_PLAN(LocalDate AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN) {
        this.AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN = AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN;
    }

    public LocalDate getDATE_END_BEFORE() {
        return DATE_END_BEFORE;
    }

    public void setDATE_END_BEFORE(LocalDate DATE_END_BEFORE) {
        this.DATE_END_BEFORE = DATE_END_BEFORE;
    }

    public LocalDate getDATE_END_ACTUAL() {
        return DATE_END_ACTUAL;
    }

    public void setDATE_END_ACTUAL(LocalDate DATE_END_ACTUAL) {
        this.DATE_END_ACTUAL = DATE_END_ACTUAL;
    }

    public BigDecimal getHOLIDAY_PRC_SUM_REM() {
        return HOLIDAY_PRC_SUM_REM;
    }

    public void setHOLIDAY_PRC_SUM_REM(BigDecimal HOLIDAY_PRC_SUM_REM) {
        this.HOLIDAY_PRC_SUM_REM = HOLIDAY_PRC_SUM_REM;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return numStr;
    }

    public void setNumStr(int numStr) {
        this.numStr = numStr;
    }

    @Override
    public String toString() {
        return "PlHoliday{" +
                "id=" + id +
                ", ACC_NUM='" + ACC_NUM + '\'' +
                ", CLIENT_NUM='" + CLIENT_NUM + '\'' +
                ", HOLIDAY_TYPE='" + HOLIDAY_TYPE + '\'' +
                ", HOLIDAY_DATE_APPL=" + HOLIDAY_DATE_APPL +
                ", HOLIDAY_DATE_PROV=" + HOLIDAY_DATE_PROV +
                ", HOLIDAY_DATE_BEGIN=" + HOLIDAY_DATE_BEGIN +
                ", HOLIDAY_DATE_END_PLAN=" + HOLIDAY_DATE_END_PLAN +
                ", HOLIDAY_DATE_END_FACT=" + HOLIDAY_DATE_END_FACT +
                ", HOLIDAY_END_REASON='" + HOLIDAY_END_REASON + '\'' +
                ", HOLIDAY_DATE_TERM_APPL=" + HOLIDAY_DATE_TERM_APPL +
                ", AFTER_HOLIDAY_DATE_FIRST_PAY_FACT=" + AFTER_HOLIDAY_DATE_FIRST_PAY_FACT +
                ", HOLIDAY_DATE_FIRST_REAB_PAY=" + HOLIDAY_DATE_FIRST_REAB_PAY +
                ", HOLIDAY_DATE_LAST_REAB_PAY=" + HOLIDAY_DATE_LAST_REAB_PAY +
                ", HOLIDAY_PRC_RATE=" + HOLIDAY_PRC_RATE +
                ", HOLIDAY_PRC_SUM_TOT=" + HOLIDAY_PRC_SUM_TOT +
                ", HOLIDAY_STATUS='" + HOLIDAY_STATUS + '\'' +
                ", AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN=" + AFTER_HOLIDAY_DATE_FIRST_PAY_PLAN +
                ", DATE_END_BEFORE=" + DATE_END_BEFORE +
                ", DATE_END_ACTUAL=" + DATE_END_ACTUAL +
                ", HOLIDAY_PRC_SUM_REM=" + HOLIDAY_PRC_SUM_REM +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                ", numStr=" + numStr +
                '}';
    }
}
