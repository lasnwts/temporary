package ru.usb.citixlsimport.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class PlHoliday {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    private String ACC_NUM;
    private String CLIENT_NUM;
    private String HOLIDAY_TYPE;
    private LocalDate HOLIDAY_DATE_APPL;
    private LocalDate HOLIDAY_DATE_PROV;
    private LocalDate HOLIDAY_DATE_BEGIN;
    private LocalDate HOLIDAY_DATE_END_PLAN;
    private LocalDate HOLIDAY_DATE_END_FACT;
    private String HOLIDAY_END_REASON;
    private LocalDate HOLIDAY_DATE_TERM_APPL;
    private LocalDate HOLIDAY_DATE_FIRST_NORM_PAY;
    private LocalDate HOLIDAY_DATE_FIRST_REAB_PAY;
    private LocalDate HOLIDAY_DATE_LAST_REAB_PAY;
    private String HOLIDAY_PRC_RATE;
    private String HOLIDAY_PRC_SUM;
    private String HOLIDAY_STATUS;
    private LocalDate LOAN_NXT_DUE_DT_after_PV;
    private LocalDate DATE_END_BEFORE;
    private LocalDate DATE_END_ACTUAL;
    private String APR_Change_DT;
    private String init_LQD_AMT;
    private String HOLIDAY_PRC_SUM_REM;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public PlHoliday() {
    }



    public PlHoliday(long id, String ACC_NUM, String CLIENT_NUM, String HOLIDAY_TYPE, LocalDate HOLIDAY_DATE_APPL,
                     LocalDate HOLIDAY_DATE_PROV, LocalDate HOLIDAY_DATE_BEGIN, LocalDate HOLIDAY_DATE_END_PLAN,
                     LocalDate HOLIDAY_DATE_END_FACT, String HOLIDAY_END_REASON, LocalDate HOLIDAY_DATE_TERM_APPL,
                     LocalDate HOLIDAY_DATE_FIRST_NORM_PAY, LocalDate HOLIDAY_DATE_FIRST_REAB_PAY,
                     LocalDate HOLIDAY_DATE_LAST_REAB_PAY, String HOLIDAY_PRC_RATE, String HOLIDAY_PRC_SUM,
                     String HOLIDAY_STATUS, LocalDate LOAN_NXT_DUE_DT_after_PV, LocalDate DATE_END_BEFORE,
                     LocalDate DATE_END_ACTUAL, String APR_Change_DT, String init_LQD_AMT,
                     String HOLIDAY_PRC_SUM_REM) {
        this.id = id;
        this.ACC_NUM = ACC_NUM;
        this.CLIENT_NUM = CLIENT_NUM;
        this.HOLIDAY_TYPE = HOLIDAY_TYPE;
        this.HOLIDAY_DATE_APPL = HOLIDAY_DATE_APPL;
        this.HOLIDAY_DATE_PROV = HOLIDAY_DATE_PROV;
        this.HOLIDAY_DATE_BEGIN = HOLIDAY_DATE_BEGIN;
        this.HOLIDAY_DATE_END_PLAN = HOLIDAY_DATE_END_PLAN;
        this.HOLIDAY_DATE_END_FACT = HOLIDAY_DATE_END_FACT;
        this.HOLIDAY_END_REASON = HOLIDAY_END_REASON;
        this.HOLIDAY_DATE_TERM_APPL = HOLIDAY_DATE_TERM_APPL;
        this.HOLIDAY_DATE_FIRST_NORM_PAY = HOLIDAY_DATE_FIRST_NORM_PAY;
        this.HOLIDAY_DATE_FIRST_REAB_PAY = HOLIDAY_DATE_FIRST_REAB_PAY;
        this.HOLIDAY_DATE_LAST_REAB_PAY = HOLIDAY_DATE_LAST_REAB_PAY;
        this.HOLIDAY_PRC_RATE = HOLIDAY_PRC_RATE;
        this.HOLIDAY_PRC_SUM = HOLIDAY_PRC_SUM;
        this.HOLIDAY_STATUS = HOLIDAY_STATUS;
        this.LOAN_NXT_DUE_DT_after_PV = LOAN_NXT_DUE_DT_after_PV;
        this.DATE_END_BEFORE = DATE_END_BEFORE;
        this.DATE_END_ACTUAL = DATE_END_ACTUAL;
        this.APR_Change_DT = APR_Change_DT;
        this.init_LQD_AMT = init_LQD_AMT;
        this.HOLIDAY_PRC_SUM_REM = HOLIDAY_PRC_SUM_REM;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getACC_NUM() {
        return ACC_NUM;
    }

    public void setACC_NUM(String ACC_NUM) {
        this.ACC_NUM = ACC_NUM;
    }

    public String getCLIENT_NUM() {
        return CLIENT_NUM;
    }

    public void setCLIENT_NUM(String CLIENT_NUM) {
        this.CLIENT_NUM = CLIENT_NUM;
    }

    public String getHOLIDAY_TYPE() {
        return HOLIDAY_TYPE;
    }

    public void setHOLIDAY_TYPE(String HOLIDAY_TYPE) {
        this.HOLIDAY_TYPE = HOLIDAY_TYPE;
    }

    public LocalDate getHOLIDAY_DATE_APPL() {
        return HOLIDAY_DATE_APPL;
    }

    public void setHOLIDAY_DATE_APPL(LocalDate HOLIDAY_DATE_APPL) {
        this.HOLIDAY_DATE_APPL = HOLIDAY_DATE_APPL;
    }

    public LocalDate getHOLIDAY_DATE_PROV() {
        return HOLIDAY_DATE_PROV;
    }

    public void setHOLIDAY_DATE_PROV(LocalDate HOLIDAY_DATE_PROV) {
        this.HOLIDAY_DATE_PROV = HOLIDAY_DATE_PROV;
    }

    public LocalDate getHOLIDAY_DATE_BEGIN() {
        return HOLIDAY_DATE_BEGIN;
    }

    public void setHOLIDAY_DATE_BEGIN(LocalDate HOLIDAY_DATE_BEGIN) {
        this.HOLIDAY_DATE_BEGIN = HOLIDAY_DATE_BEGIN;
    }

    public LocalDate getHOLIDAY_DATE_END_PLAN() {
        return HOLIDAY_DATE_END_PLAN;
    }

    public void setHOLIDAY_DATE_END_PLAN(LocalDate HOLIDAY_DATE_END_PLAN) {
        this.HOLIDAY_DATE_END_PLAN = HOLIDAY_DATE_END_PLAN;
    }

    public LocalDate getHOLIDAY_DATE_END_FACT() {
        return HOLIDAY_DATE_END_FACT;
    }

    public void setHOLIDAY_DATE_END_FACT(LocalDate HOLIDAY_DATE_END_FACT) {
        this.HOLIDAY_DATE_END_FACT = HOLIDAY_DATE_END_FACT;
    }

    public String getHOLIDAY_END_REASON() {
        return HOLIDAY_END_REASON;
    }

    public void setHOLIDAY_END_REASON(String HOLIDAY_END_REASON) {
        this.HOLIDAY_END_REASON = HOLIDAY_END_REASON;
    }

    public LocalDate getHOLIDAY_DATE_TERM_APPL() {
        return HOLIDAY_DATE_TERM_APPL;
    }

    public void setHOLIDAY_DATE_TERM_APPL(LocalDate HOLIDAY_DATE_TERM_APPL) {
        this.HOLIDAY_DATE_TERM_APPL = HOLIDAY_DATE_TERM_APPL;
    }

    public LocalDate getHOLIDAY_DATE_FIRST_NORM_PAY() {
        return HOLIDAY_DATE_FIRST_NORM_PAY;
    }

    public void setHOLIDAY_DATE_FIRST_NORM_PAY(LocalDate HOLIDAY_DATE_FIRST_NORM_PAY) {
        this.HOLIDAY_DATE_FIRST_NORM_PAY = HOLIDAY_DATE_FIRST_NORM_PAY;
    }

    public LocalDate getHOLIDAY_DATE_FIRST_REAB_PAY() {
        return HOLIDAY_DATE_FIRST_REAB_PAY;
    }

    public void setHOLIDAY_DATE_FIRST_REAB_PAY(LocalDate HOLIDAY_DATE_FIRST_REAB_PAY) {
        this.HOLIDAY_DATE_FIRST_REAB_PAY = HOLIDAY_DATE_FIRST_REAB_PAY;
    }

    public LocalDate getHOLIDAY_DATE_LAST_REAB_PAY() {
        return HOLIDAY_DATE_LAST_REAB_PAY;
    }

    public void setHOLIDAY_DATE_LAST_REAB_PAY(LocalDate HOLIDAY_DATE_LAST_REAB_PAY) {
        this.HOLIDAY_DATE_LAST_REAB_PAY = HOLIDAY_DATE_LAST_REAB_PAY;
    }

    public String getHOLIDAY_PRC_RATE() {
        return HOLIDAY_PRC_RATE;
    }

    public void setHOLIDAY_PRC_RATE(String HOLIDAY_PRC_RATE) {
        this.HOLIDAY_PRC_RATE = HOLIDAY_PRC_RATE;
    }

    public String getHOLIDAY_PRC_SUM() {
        return HOLIDAY_PRC_SUM;
    }

    public void setHOLIDAY_PRC_SUM(String HOLIDAY_PRC_SUM) {
        this.HOLIDAY_PRC_SUM = HOLIDAY_PRC_SUM;
    }

    public String getHOLIDAY_STATUS() {
        return HOLIDAY_STATUS;
    }

    public void setHOLIDAY_STATUS(String HOLIDAY_STATUS) {
        this.HOLIDAY_STATUS = HOLIDAY_STATUS;
    }

    public LocalDate getLOAN_NXT_DUE_DT_after_PV() {
        return LOAN_NXT_DUE_DT_after_PV;
    }

    public void setLOAN_NXT_DUE_DT_after_PV(LocalDate LOAN_NXT_DUE_DT_after_PV) {
        this.LOAN_NXT_DUE_DT_after_PV = LOAN_NXT_DUE_DT_after_PV;
    }

    public LocalDate getDATE_END_BEFORE() {
        return DATE_END_BEFORE;
    }

    public void setDATE_END_BEFORE(LocalDate DATE_END_BEFORE) {
        this.DATE_END_BEFORE = DATE_END_BEFORE;
    }

    public LocalDate getDATE_END_ACTUAL() {
        return DATE_END_ACTUAL;
    }

    public void setDATE_END_ACTUAL(LocalDate DATE_END_ACTUAL) {
        this.DATE_END_ACTUAL = DATE_END_ACTUAL;
    }

    public String getAPR_Change_DT() {
        return APR_Change_DT;
    }

    public void setAPR_Change_DT(String APR_Change_DT) {
        this.APR_Change_DT = APR_Change_DT;
    }

    public String getInit_LQD_AMT() {
        return init_LQD_AMT;
    }

    public void setInit_LQD_AMT(String init_LQD_AMT) {
        this.init_LQD_AMT = init_LQD_AMT;
    }

    public String getHOLIDAY_PRC_SUM_REM() {
        return HOLIDAY_PRC_SUM_REM;
    }

    public void setHOLIDAY_PRC_SUM_REM(String HOLIDAY_PRC_SUM_REM) {
        this.HOLIDAY_PRC_SUM_REM = HOLIDAY_PRC_SUM_REM;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "PlHoliday{" +
                "id=" + id +
                ", ACC_NUM='" + ACC_NUM + '\'' +
                ", CLIENT_NUM='" + CLIENT_NUM + '\'' +
                ", HOLIDAY_TYPE='" + HOLIDAY_TYPE + '\'' +
                ", HOLIDAY_DATE_APPL=" + HOLIDAY_DATE_APPL +
                ", HOLIDAY_DATE_PROV=" + HOLIDAY_DATE_PROV +
                ", HOLIDAY_DATE_BEGIN=" + HOLIDAY_DATE_BEGIN +
                ", HOLIDAY_DATE_END_PLAN=" + HOLIDAY_DATE_END_PLAN +
                ", HOLIDAY_DATE_END_FACT=" + HOLIDAY_DATE_END_FACT +
                ", HOLIDAY_END_REASON='" + HOLIDAY_END_REASON + '\'' +
                ", HOLIDAY_DATE_TERM_APPL=" + HOLIDAY_DATE_TERM_APPL +
                ", HOLIDAY_DATE_FIRST_NORM_PAY=" + HOLIDAY_DATE_FIRST_NORM_PAY +
                ", HOLIDAY_DATE_FIRST_REAB_PAY=" + HOLIDAY_DATE_FIRST_REAB_PAY +
                ", HOLIDAY_DATE_LAST_REAB_PAY=" + HOLIDAY_DATE_LAST_REAB_PAY +
                ", HOLIDAY_PRC_RATE='" + HOLIDAY_PRC_RATE + '\'' +
                ", HOLIDAY_PRC_SUM='" + HOLIDAY_PRC_SUM + '\'' +
                ", HOLIDAY_STATUS='" + HOLIDAY_STATUS + '\'' +
                ", LOAN_NXT_DUE_DT_after_PV=" + LOAN_NXT_DUE_DT_after_PV +
                ", DATE_END_BEFORE=" + DATE_END_BEFORE +
                ", DATE_END_ACTUAL=" + DATE_END_ACTUAL +
                ", APR_Change_DT='" + APR_Change_DT + '\'' +
                ", init_LQD_AMT='" + init_LQD_AMT + '\'' +
                ", HOLIDAY_PRC_SUM_REM='" + HOLIDAY_PRC_SUM_REM + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
