package ru.usb.citixlsimport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.citixlsimport.config.Configure;
import ru.usb.citixlsimport.service.ServProcessed;
import ru.usb.citixlsimport.service.readxls.ReadPskXlsx;
import ru.usb.citixlsimport.utils.WorkWithFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

@SpringBootApplication
public class CitixlsimportApplication implements CommandLineRunner {

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    Configure configure;

    @Autowired
    ServProcessed servProcessed;

    //включаем логирование
    Logger logger = LoggerFactory.getLogger(CitixlsimportApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitixlsimportApplication.class, args);
    }

    /*
     * Sheduler 1. Первый шедулер
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {

        List<File> fileList = new ArrayList<>();

        /**
         * Запускаем сканирование каталога c файлами из СИТИ
         */
        fileList = withFiles.getDirList(configure.getFileDirectory());
        //Если файлы есть то отрабатываем по каждому файл
        if (fileList.size() > 0) {
            logger.info("Start Sheduler job");
            fileList.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {
                    if (file.getName().toUpperCase(Locale.ROOT).contains("XLS")) {
                        logger.info("File:Найден файл формата XLS:{}", file.getAbsolutePath());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("ПСК")) {
                        logger.info("ПСК:СТАРТ ОБРАБОТКИ файла:{}", file.getAbsolutePath());
                        servProcessed.PskService(file);
                        logger.info("ПСК:ОБРАБОТА ЗАВЕРШЕНА, файл:{}", file.getAbsolutePath());
                        System.gc();
                    }
                    if (file.getName().toLowerCase(Locale.ROOT).contains("total") && file.getName().toLowerCase(Locale.ROOT).contains("payoff")) {
                        logger.info("TOTAL PAYOFF PL:СТАРТ ОБРАБОТКИ файла:{}", file.getAbsolutePath());
                        servProcessed.TotalPayService(file);
                        logger.info("TOTAL PAYOFF PL:ОБРАБОТА ЗАВЕРШЕНА, файл:{}", file.getAbsolutePath());
                        System.gc();
                    }
//                    logger.info("Stop Sheduler job");
                }
            });
            logger.info("Stop Sheduler job");
        }


    }

    @Override
    public void run(String... args) throws Exception {
        // Показываем версию
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Service:" + configure.getAppName());
        logger.info("| Version of service:" + configure.getAppVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        /**
         * Проверка директорий
         */
        if (withFiles.checkPathExists(configure.getFileCsvDirectory())) {
            logger.info("Success. Директория: " + configure.getFileCsvDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileCsvDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileCsvDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileDirectory())) {
            logger.info("Success. Директория: " + configure.getFileDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileMoveDirectory())) {
            logger.info("Success. Директория: " + configure.getFileMoveDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileMoveDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileMoveDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileErrDirectory())) {
            logger.info("Success. Директория: " + configure.getFileErrDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileErrDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileErrDirectory());
        }
    }
}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}