package ru.usb.citixlsimport.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Depart {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;


    private String idCredit;

    private String department;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    //Номер строки
    private int numStr;

    public Depart() {
    }

    public Depart(long id, String idCredit, String department, Date inputDate, String FILENAME, int numStr) {
        this.id = id;
        this.idCredit = idCredit;
        this.department = department;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
        this.numStr = numStr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIdCredit() {
        return idCredit;
    }

    public void setIdCredit(String idCredit) {
        this.idCredit = idCredit;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public int getNumStr() {
        return numStr;
    }

    public void setNumStr(int numStr) {
        this.numStr = numStr;
    }

    @Override
    public String toString() {
        return "Depart{" +
                "id=" + id +
                ", idCredit='" + idCredit + '\'' +
                ", department='" + department + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                ", numStr=" + numStr +
                '}';
    }
}
