package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
public class CUSTMISC {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //CA_CUSTNO
    private String CA_CUSTNO;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public CUSTMISC() {
    }

    public CUSTMISC(long id, String CA_CUSTNO, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CA_CUSTNO = CA_CUSTNO;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCA_CUSTNO() {
        return CA_CUSTNO;
    }

    public void setCA_CUSTNO(String CA_CUSTNO) {
        this.CA_CUSTNO = CA_CUSTNO;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "CUSTMISC{" +
                "id=" + id +
                ", CA_CUSTNO='" + CA_CUSTNO + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
