package ru.usb.citisplitter.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class Configure {

    @Value("${file.directory}")
    private String fileDirectory;

    @Value("${file.csvdirectory}")
    private String fileCsvDirectory;

    @Value("${file.procdirectory}")
    private String fileMoveDirectory;

    @Value("${file.errdirectory}")
    private String fileErrDirectory;

    @Value("${file.obj:false}")
    private boolean fileFlagCSV;

    @Value("${file.show:false}")
    private boolean fileOriginalLineShow;
    /**
     * String replace
     */

    @Value("${shield.replace}")
    private String shieldReplace;

    /**
     * info.app.name=citiSplitter
     * info.app.description=citiSplitter. Designed Lyapustin A.S. 08.11.2022
     * info.app.version=1.0.0
     */

    @Value("${info.app.name}")
    private String appName;

    @Value("${info.app.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:Проверка ЗСК – ошибка передачи данных}")
    private String mailSubjects;

    @Value("${mailFrom:siebeluniversal@problem}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    /**
     * Реализация GET
     */

    public String getFileDirectory() {
        return fileDirectory;

    }

    public String getShieldReplace() {
        return shieldReplace;
    }

    public String getFileCsvDirectory() {
        return fileCsvDirectory;
    }

    public boolean isFileFlagCSV() {
        return fileFlagCSV;
    }

    public boolean isFileOriginalLineShow() {
        return fileOriginalLineShow;
    }

    public String getFileMoveDirectory() {
        return fileMoveDirectory;
    }

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public String getFileErrDirectory() {
        return fileErrDirectory;
    }
}
