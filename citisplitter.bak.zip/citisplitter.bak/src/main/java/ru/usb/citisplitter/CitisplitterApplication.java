package ru.usb.citisplitter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.service.ServProcessed;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

@SpringBootApplication
public class CitisplitterApplication implements CommandLineRunner {

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    Configure configure;

    @Autowired
    ServProcessed servProcessed;


    Logger logger = LoggerFactory.getLogger(CitisplitterApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitisplitterApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        // Показываем версию
        logger.info("");
        logger.info("-----------------------------------------------");
        logger.info("| Service:" + configure.getAppName());
        logger.info("| Version of service:" + configure.getAppVersion());
        logger.info("-----------------------------------------------");
        logger.info("");

        /**
         * Проверка директорий
         */
        if (withFiles.checkPathExists(configure.getFileCsvDirectory())) {
            logger.info("Success. Директория: " + configure.getFileCsvDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileCsvDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileCsvDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileDirectory())) {
            logger.info("Success. Директория: " + configure.getFileDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileMoveDirectory())) {
            logger.info("Success. Директория: " + configure.getFileMoveDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileMoveDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileMoveDirectory());
        }

        if (withFiles.checkPathExists(configure.getFileErrDirectory())) {
            logger.info("Success. Директория: " + configure.getFileErrDirectory() + " обнаружена.");
        } else {
            logger.error("Error. Директория: " + configure.getFileErrDirectory() + " не обнаружена! Работа невозможна.");
            withFiles.createdDirectory(configure.getFileErrDirectory());
        }

    }

    /*
     * Sheduler 1. Первый шедулер
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {

        List<File> fileList = new ArrayList<>();

        /**
         * Запускаем сканирование каталога c файлами из СИТИ
         */
        fileList = withFiles.getDirList(configure.getFileDirectory());
        //Если файлы есть то отрабатываем по каждому файл
        if (fileList.size() > 0) {
            fileList.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {
                    //GRBMAST
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBMAST.PER")) {
                        logger.info("File GRBMAST.PER найден:{}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBMASTPER(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBMAST.NPER")) {
                        logger.info("File GRBMAST.NPER найден:{}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBMASTPER(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //CUSTID
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTID.PER")) {
                        logger.info("File CUSTID.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTID(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTID.NPER")) {
                        logger.info("File CUSTID.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTID(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //ADDRESS
                    if (file.getName().toUpperCase(Locale.ROOT).contains("ADDRESS.PER")) {
                        logger.info("File ADDRESS.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBAddr(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("ADDRESS.NPER")) {
                        logger.info("File ADDRESS.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBAddr(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //GRBTEL
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBTEL.PER")) {
                        logger.info("File GRBTEL.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBTEL(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBTEL.NPER")) {
                        logger.info("File GRBTEL.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGRBTEL(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //CUSTEMPL
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTEMPL.PER")) {
                        logger.info("File CUSTEMPL.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTEMPL(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTEMPL.NPER")) {
                        logger.info("File CUSTEMPL.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTEMPL(file.getAbsolutePath(), "NPL", file.getName());
                    }

                    //18.11.2022
                    //CUSTMISC (CUSTMISC)
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTMISC.PER")) {
                        logger.info("File CUSTMISC.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTMISC(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("CUSTMISC.NPER")) {
                        logger.info("File CUSTMISC.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcCUSTMISC(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //GRBRELN
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBRELN.PER")) {
                        logger.info("File GRBRELN.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGrbReln(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBRELN.NPER")) {
                        logger.info("File GRBRELN.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcGrbReln(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //AMUW1
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUW1") && file.getName().toUpperCase(Locale.ROOT).contains(".PER")) {
                        logger.info("File AMUW1.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUW1(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUW1") && file.getName().toUpperCase(Locale.ROOT).contains("NPER")) {
                        logger.info("File AMUW1.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUW1(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //AMUW2
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUW2") && file.getName().toUpperCase(Locale.ROOT).contains(".PER")) {
                        logger.info("File AMUW2.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUW2(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUW2") && file.getName().toUpperCase(Locale.ROOT).contains("NPER")) {
                        logger.info("File AMUW2.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUW2(file.getAbsolutePath(), "NPL", file.getName());
                    }
                    //AMUWG
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUWG") && file.getName().toUpperCase(Locale.ROOT).contains(".PER")) {
                        logger.info("File AMUWG.PER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUWG(file.getAbsolutePath(), "PL", file.getName());
                    }
                    if (file.getName().toUpperCase(Locale.ROOT).contains("AMUWG") && file.getName().toUpperCase(Locale.ROOT).contains("NPER")) {
                        logger.info("File AMUWG.NPER найден: {}", file.getAbsolutePath());
                        servProcessed.serviceProcAMUWG(file.getAbsolutePath(), "NPL", file.getName());
                    }

                }
            });
        }

        logger.info("Service find and processed files closed.");

    }


}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}
