package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class AMUW2 {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //AMXTDWU2-RT-ACCT-NUM
    private String AMXTDWU2RTACCTNUM;

    //19112022
    /**
     *
     * AMXTDWU2-AC-ACCR-DAY
     * AMXTDWU2-RT-CURR-DUE-AMT
     * AMXTDWU2-BL-FRST-DUE-DATE
     * AMXTDWU2-RT-LST-PMT-DATE
     * AMXTDWU2-RT-CURR-TERM
     * AMXTDWU2-RT-LST-PMT-AMT
     * AMXTDWU2-DQ-TOT-AMT-PDUE
     * AMXTDWU2-RT-NUM-PMTS-REM
     * AMXTDWU2-RT-NUM-PMTS-MADE
     */
    //AMXTDWU2-AC-ACCR-DAY
    private String AMXTDWU2ACACCRDAY;

    //AMXTDWU2-RT-CURR-DUE-AMT
    private String AMXTDWU2RTCURRDUEAMT;

    //AMXTDWU2-BL-FRST-DUE-DATE
    private LocalDate AMXTDWU2BLFRSTDUEDATE;

    //AMXTDWU2-RT-LST-PMT-DATE
    private LocalDate AMXTDWU2RTLSTPMTDATE;

    //AMXTDWU2-RT-CURR-TERM
    private String AMXTDWU2RTCURRTERM;

    //AMXTDWU2-RT-LST-PMT-AMT
    private String AMXTDWU2RTLSTPMTAMT;

    //AMXTDWU2-DQ-TOT-AMT-PDUE
    private String AMXTDWU2_DQ_TOT_AMT_PDUE;

    //AMXTDWU2_RT_NUM_PMTS_REM
    private String AMXTDWU2_RT_NUM_PMTS_REM;

    //AMXTDWU2-RT-NUM-PMTS-MADE
    private String AMXTDWU2_RT_NUM_PMTS_MADE;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public AMUW2() {
    }

    public AMUW2(long id, String AMXTDWU2RTACCTNUM, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWU2RTACCTNUM = AMXTDWU2RTACCTNUM;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public AMUW2(long id, String AMXTDWU2RTACCTNUM, String AMXTDWU2ACACCRDAY, String AMXTDWU2RTCURRDUEAMT, LocalDate AMXTDWU2BLFRSTDUEDATE,
                 LocalDate AMXTDWU2RTLSTPMTDATE, String AMXTDWU2RTCURRTERM, String AMXTDWU2RTLSTPMTAMT, String AMXTDWU2_DQ_TOT_AMT_PDUE,
                 String AMXTDWU2_RT_NUM_PMTS_REM, String AMXTDWU2_RT_NUM_PMTS_MADE, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWU2RTACCTNUM = AMXTDWU2RTACCTNUM;
        this.AMXTDWU2ACACCRDAY = AMXTDWU2ACACCRDAY;
        this.AMXTDWU2RTCURRDUEAMT = AMXTDWU2RTCURRDUEAMT;
        this.AMXTDWU2BLFRSTDUEDATE = AMXTDWU2BLFRSTDUEDATE;
        this.AMXTDWU2RTLSTPMTDATE = AMXTDWU2RTLSTPMTDATE;
        this.AMXTDWU2RTCURRTERM = AMXTDWU2RTCURRTERM;
        this.AMXTDWU2RTLSTPMTAMT = AMXTDWU2RTLSTPMTAMT;
        this.AMXTDWU2_DQ_TOT_AMT_PDUE = AMXTDWU2_DQ_TOT_AMT_PDUE;
        this.AMXTDWU2_RT_NUM_PMTS_REM = AMXTDWU2_RT_NUM_PMTS_REM;
        this.AMXTDWU2_RT_NUM_PMTS_MADE = AMXTDWU2_RT_NUM_PMTS_MADE;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAMXTDWU2RTACCTNUM() {
        return AMXTDWU2RTACCTNUM;
    }

    public void setAMXTDWU2RTACCTNUM(String AMXTDWU2RTACCTNUM) {
        this.AMXTDWU2RTACCTNUM = AMXTDWU2RTACCTNUM;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getAMXTDWU2ACACCRDAY() {
        return AMXTDWU2ACACCRDAY;
    }

    public void setAMXTDWU2ACACCRDAY(String AMXTDWU2ACACCRDAY) {
        this.AMXTDWU2ACACCRDAY = AMXTDWU2ACACCRDAY;
    }

    public String getAMXTDWU2RTCURRDUEAMT() {
        return AMXTDWU2RTCURRDUEAMT;
    }

    public void setAMXTDWU2RTCURRDUEAMT(String AMXTDWU2RTCURRDUEAMT) {
        this.AMXTDWU2RTCURRDUEAMT = AMXTDWU2RTCURRDUEAMT;
    }

    public LocalDate getAMXTDWU2BLFRSTDUEDATE() {
        return AMXTDWU2BLFRSTDUEDATE;
    }

    public void setAMXTDWU2BLFRSTDUEDATE(LocalDate AMXTDWU2BLFRSTDUEDATE) {
        this.AMXTDWU2BLFRSTDUEDATE = AMXTDWU2BLFRSTDUEDATE;
    }

    public LocalDate getAMXTDWU2RTLSTPMTDATE() {
        return AMXTDWU2RTLSTPMTDATE;
    }

    public void setAMXTDWU2RTLSTPMTDATE(LocalDate AMXTDWU2RTLSTPMTDATE) {
        this.AMXTDWU2RTLSTPMTDATE = AMXTDWU2RTLSTPMTDATE;
    }

    public String getAMXTDWU2RTCURRTERM() {
        return AMXTDWU2RTCURRTERM;
    }

    public void setAMXTDWU2RTCURRTERM(String AMXTDWU2RTCURRTERM) {
        this.AMXTDWU2RTCURRTERM = AMXTDWU2RTCURRTERM;
    }

    public String getAMXTDWU2RTLSTPMTAMT() {
        return AMXTDWU2RTLSTPMTAMT;
    }

    public void setAMXTDWU2RTLSTPMTAMT(String AMXTDWU2RTLSTPMTAMT) {
        this.AMXTDWU2RTLSTPMTAMT = AMXTDWU2RTLSTPMTAMT;
    }

    public String getAMXTDWU2_DQ_TOT_AMT_PDUE() {
        return AMXTDWU2_DQ_TOT_AMT_PDUE;
    }

    public void setAMXTDWU2_DQ_TOT_AMT_PDUE(String AMXTDWU2_DQ_TOT_AMT_PDUE) {
        this.AMXTDWU2_DQ_TOT_AMT_PDUE = AMXTDWU2_DQ_TOT_AMT_PDUE;
    }

    public String getAMXTDWU2_RT_NUM_PMTS_REM() {
        return AMXTDWU2_RT_NUM_PMTS_REM;
    }

    public void setAMXTDWU2_RT_NUM_PMTS_REM(String AMXTDWU2_RT_NUM_PMTS_REM) {
        this.AMXTDWU2_RT_NUM_PMTS_REM = AMXTDWU2_RT_NUM_PMTS_REM;
    }

    public String getAMXTDWU2_RT_NUM_PMTS_MADE() {
        return AMXTDWU2_RT_NUM_PMTS_MADE;
    }

    public void setAMXTDWU2_RT_NUM_PMTS_MADE(String AMXTDWU2_RT_NUM_PMTS_MADE) {
        this.AMXTDWU2_RT_NUM_PMTS_MADE = AMXTDWU2_RT_NUM_PMTS_MADE;
    }

    @Override
    public String toString() {
        return "AMUW2{" +
                "id=" + id +
                ", AMXTDWU2RTACCTNUM='" + AMXTDWU2RTACCTNUM + '\'' +
                ", AMXTDWU2ACACCRDAY='" + AMXTDWU2ACACCRDAY + '\'' +
                ", AMXTDWU2RTCURRDUEAMT='" + AMXTDWU2RTCURRDUEAMT + '\'' +
                ", AMXTDWU2BLFRSTDUEDATE=" + AMXTDWU2BLFRSTDUEDATE +
                ", AMXTDWU2RTLSTPMTDATE=" + AMXTDWU2RTLSTPMTDATE +
                ", AMXTDWU2RTCURRTERM='" + AMXTDWU2RTCURRTERM + '\'' +
                ", AMXTDWU2RTLSTPMTAMT='" + AMXTDWU2RTLSTPMTAMT + '\'' +
                ", AMXTDWU2_DQ_TOT_AMT_PDUE='" + AMXTDWU2_DQ_TOT_AMT_PDUE + '\'' +
                ", AMXTDWU2_RT_NUM_PMTS_REM='" + AMXTDWU2_RT_NUM_PMTS_REM + '\'' +
                ", AMXTDWU2_RT_NUM_PMTS_MADE='" + AMXTDWU2_RT_NUM_PMTS_MADE + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
