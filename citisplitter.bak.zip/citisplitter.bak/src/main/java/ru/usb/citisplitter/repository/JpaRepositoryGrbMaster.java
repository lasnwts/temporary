package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.GRBMASTPER;

public interface JpaRepositoryGrbMaster extends JpaRepository<GRBMASTPER, Long> {
}
