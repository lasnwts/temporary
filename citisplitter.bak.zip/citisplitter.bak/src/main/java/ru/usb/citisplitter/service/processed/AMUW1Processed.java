package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitAMUW1;
import ru.usb.citisplitter.model.AMUW1;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.repository.JpaRepositoryAmuw1;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class AMUW1Processed {

    Logger logger = LoggerFactory.getLogger(AMUW1Processed.class);

    @Autowired
    SplitAMUW1 splitAMUW1;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryAmuw1 jpaRepositoryAmuw1;

    File file;

    String output_file = "AMUW1Processed.txt";


    /**
     * Базовая последовательность
     *
     * @param filePath
     * @param per
     * @param fName
     * @return
     * @throws IOException
     */
    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitAMUW1.getMuw1().size() == 0) {
            logger.info("Пустой список splitAMUW1");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    count.incrementAndGet();
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (count.get() > 1 || line.trim().length() > 90) {

                            AMUW1 amuw1 = getNewAMUW1(line);
                            amuw1.setPER(per);
                            amuw1.setInputDate(new Date());
                            amuw1.setFILENAME(fName);
                            jpaRepositoryAmuw1.save(amuw1);


                            if (configure.isFileFlagCSV()) {
                                writer.write((count.get()) + ";" + amuw1.toString() + System.lineSeparator());
                            }

                            //Удаляем объект
                            amuw1 = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект
     *
     * @param line
     * @return
     */
    private AMUW1 getNewAMUW1(String line) {

        AMUW1 amuw1 = new AMUW1();

        splitAMUW1.getMuw1().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "AMXTDWU1-RT-ACCT-NUM":
                        try {
                            amuw1.setAMXTDWU1RTACCTNUM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTACCTNUM("");
                        }
                        break;
                    //19.11.2022
                    case "AMXTDWU1-CF-CUST-NUM":
                        try {
                            amuw1.setAMXTDWU1CFCUSTNUM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1CFCUSTNUM("");
                        }
                        break;
                    case "AMXTDWU1-COST-CTR":
                        try {
                            amuw1.setAMXTDWU1COSTCTR(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1COSTCTR("");
                        }
                        break;
                    case "AMXTDWU1-CF-PRIM-BR":
                        try {
                            amuw1.setAMXTDWU1CFPRIMBR(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1CFPRIMBR("");
                        }
                        break;
                    case "AMXTDWU1-RT-ACCT-EFF-DATE":
                        try {
                            amuw1.setAMXTDWU1RTACCTEFFDATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTACCTEFFDATE(parseDate.getDtf("19170101"));
                        }
                        break;
                    case "AMXTDWU1-RT-CURR-MATUR-DATE":
                        try {
                            amuw1.setAMXTDWU1RTCURRMATURDATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTCURRMATURDATE(parseDate.getDtf("19170101"));
                        }
                        break;
                    case "AMXTDWU1-RT-ORIG-LOAN-AMT":
                        try {
                            amuw1.setAMXTDWU1RTORIGLOANAMT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTORIGLOANAMT("");
                        }
                        break;
                    case "AMXTDWU1-RT-TOT-PRIN":
                        try {
                            amuw1.setAMXTDWU1RTTOTPRIN(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTTOTPRIN("");
                        }
                        break;
                    case "AMXTDWU1-OUT-BAL":
                        try {
                            amuw1.setAMXTDWU1OUTBAL(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1OUTBAL("");
                        }
                        break;
                    case "AMXTDWU1-SE-PRI-BAL-AT-SALE":
                        try {
                            amuw1.setAMXTDWU1SEPRIBALATSALE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1SEPRIBALATSALE("");
                        }
                        break;
                    case "AMXTDWU1-RT-TOT-INT-REC":
                        try {
                            amuw1.setAMXTDWU1RTTOTINTREC(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTTOTINTREC("");
                        }
                        break;
                    case "AMXTDWU1-BT-INT-TOT":
                        try {
                            amuw1.setAMXTDWU1BTINTTOT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1BTINTTOT("");
                        }
                        break;
                    case "AMXTDWU1-RT-LOAN-ENTRY-DATE":
                        try {
                            amuw1.setAMXTDWU1RTLOANENTRYDATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTLOANENTRYDATE(parseDate.getDtf("19170101"));
                        }
                        break;
                    case "AMXTDWU1-RT-USER-AMT1":
                        try {
                            amuw1.setAMXTDWU1RTUSERAMT1(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTUSERAMT1("");
                        }
                        break;
                    case "AMXTDWU1-RT-LOAN-RATE":
                        try {
                            amuw1.setAMXTDWU1RTLOANRATE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTLOANRATE("");
                        }
                        break;
                    case "AMXTDWU1-RT-POFF-PNLTY-AMT":
                        try {
                            amuw1.setAMXTDWU1RTPOFFPNLTYAMT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw1.setAMXTDWU1RTPOFFPNLTYAMT("");
                        }
                        break;
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });
        return amuw1;
    }


}
