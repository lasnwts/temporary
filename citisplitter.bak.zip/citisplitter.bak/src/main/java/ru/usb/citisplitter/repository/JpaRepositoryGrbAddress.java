package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.GRBADDRESS;

public interface JpaRepositoryGrbAddress extends JpaRepository<GRBADDRESS, Long> {
}
