package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "grbmasterper")
public class SplitGRBMASTPER {

    private List<Fields> customer = new ArrayList<>();

    public SplitGRBMASTPER() {
    }

    public List<Fields> getCustomer() {
        return customer;
    }

    public void setCustomer(List<Fields> customer) {
        this.customer = customer;
    }
}
