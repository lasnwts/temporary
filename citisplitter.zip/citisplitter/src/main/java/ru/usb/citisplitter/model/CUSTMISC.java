package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
public class CUSTMISC {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //CA_CUSTNO
    private String CA_CUSTNO;

    /**
     * 20.11.2022
     * Данные по органу выдачи паспорта содержатся в CUSTMISC
     * Комбинация полей содержит полную информацию из документа, без структурного разделения на отдельные поля
     * По клиенту можно найти пары ключ-значение (CA_KEY_VAL-CA_FIELD_VAL) с ключом IDPP01, IDPP02
     * Таким образом нам нужны поля
     * CA_KEY_VAL CHAR 10 25 34
     * CA_FIELD_VAL CHAR 80 35 114
     * ну и само собой номер клиента
     * CA_CUSTNO CHAR 9 16 24
     */

    //CA_KEY_VAL
    private String CA_KEY_VAL;
    //CA_FIELD_VAL
    private String CA_FIELD_VAL;


    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public CUSTMISC() {
    }

    public CUSTMISC(long id, String CA_CUSTNO, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CA_CUSTNO = CA_CUSTNO;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public CUSTMISC(long id, String CA_CUSTNO, String CA_KEY_VAL, String CA_FIELD_VAL, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CA_CUSTNO = CA_CUSTNO;
        this.CA_KEY_VAL = CA_KEY_VAL;
        this.CA_FIELD_VAL = CA_FIELD_VAL;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCA_CUSTNO() {
        return CA_CUSTNO;
    }

    public void setCA_CUSTNO(String CA_CUSTNO) {
        this.CA_CUSTNO = CA_CUSTNO;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getCA_KEY_VAL() {
        return CA_KEY_VAL;
    }

    public void setCA_KEY_VAL(String CA_KEY_VAL) {
        this.CA_KEY_VAL = CA_KEY_VAL;
    }

    public String getCA_FIELD_VAL() {
        return CA_FIELD_VAL;
    }

    public void setCA_FIELD_VAL(String CA_FIELD_VAL) {
        this.CA_FIELD_VAL = CA_FIELD_VAL;
    }

    @Override
    public String toString() {
        return "CUSTMISC{" +
                "id=" + id +
                ", CA_CUSTNO='" + CA_CUSTNO + '\'' +
                ", CA_KEY_VAL='" + CA_KEY_VAL + '\'' +
                ", CA_FIELD_VAL='" + CA_FIELD_VAL + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
