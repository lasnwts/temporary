package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitAMUW2;
import ru.usb.citisplitter.model.AMUW2;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.repository.JpaRepositoryAmuw2;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class AMUW2Processed {

    Logger logger = LoggerFactory.getLogger(AMUW2Processed.class);

    @Autowired
    SplitAMUW2 splitAMUW2;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryAmuw2 jpaRepositoryAmuw2;

    File file;

    String output_file = "AMUW2Processed.txt";


    /**
     * @param filePath
     * @param per
     * @param fName
     * @return
     * @throws IOException
     */
    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitAMUW2.getMuw2().size() == 0) {
            logger.info("Пустой список splitAMUW2");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    count.incrementAndGet();
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (count.get() > 1 && line.trim().length() > 99) {

                            AMUW2 amuw2 = getNewAMUW2(line);
                            amuw2.setPER(per);
                            amuw2.setInputDate(new Date());
                            amuw2.setFILENAME(fName);
                            jpaRepositoryAmuw2.save(amuw2);


                            if (configure.isFileFlagCSV()) {
                                writer.write((count.get()) + ";" + amuw2.toString() + System.lineSeparator());
                            }

                            //Удаляем объект
                            amuw2 = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект
     *
     * @param line
     * @return
     */
    private AMUW2 getNewAMUW2(String line) {

        AMUW2 amuw2 = new AMUW2();

        splitAMUW2.getMuw2().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "AMXTDWU2-RT-ACCT-NUM":
                        try {
                            amuw2.setAMXTDWU2RTACCTNUM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTACCTNUM("");
                        }
                        break;
                    case "AMXTDWU2-AC-ACCR-DAY":
                        try {
                            amuw2.setAMXTDWU2ACACCRDAY(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2ACACCRDAY("");
                        }
                        break;
                    case "AMXTDWU2-RT-CURR-DUE-AMT":
                        try {
                            amuw2.setAMXTDWU2RTCURRDUEAMT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTCURRDUEAMT("");
                        }
                        break;
                    case "AMXTDWU2-BL-FRST-DUE-DATE":
                        try {
                            amuw2.setAMXTDWU2BLFRSTDUEDATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                           // amuw2.setAMXTDWU2BLFRSTDUEDATE(null);
                        }
                        break;
                    case "AMXTDWU2-RT-LST-PMT-DATE":
                        try {
                            amuw2.setAMXTDWU2RTLSTPMTDATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                            //amuw2.setAMXTDWU2RTLSTPMTDATE(null);
                        }
                        break;
                    case "AMXTDWU2-RT-CURR-TERM":
                        try {
                            amuw2.setAMXTDWU2RTCURRTERM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTCURRTERM("");
                        }
                        break;
                    case "AMXTDWU2-RT-LST-PMT-AMT":
                        try {
                            amuw2.setAMXTDWU2RTLSTPMTAMT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTLSTPMTAMT("");
                        }
                        break;
                    case "AMXTDWU2-DQ-TOT-AMT-PDUE":
                        try {
                            amuw2.setAMXTDWU2_DQ_TOT_AMT_PDUE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2_DQ_TOT_AMT_PDUE("");
                        }
                        break;
                    case "AMXTDWU2-RT-NUM-PMTS-REM":
                        try {
                            amuw2.setAMXTDWU2_RT_NUM_PMTS_REM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2_RT_NUM_PMTS_REM("");
                        }
                        break;
                    case "AMXTDWU2-RT-NUM-PMTS-MADE":
                        try {
                            amuw2.setAMXTDWU2_RT_NUM_PMTS_MADE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2_RT_NUM_PMTS_MADE("");
                        }
                        break;
                    //20.11.2022
                    case "AMXTDWU2-RT-ORIG-TERM":
                        try {
                            amuw2.setAMXTDWU2RTORIGTERM(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTORIGTERM("");
                        }
                        break;
                    //21.11.2002
                    //AMXTDWU2-AC-ORIG-RATE
                    case "AMXTDWU2-AC-ORIG-RATE":
                        try {
                            amuw2.setAMXTDWU2ACORIGRATE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2ACORIGRATE("");
                        }
                        break;
                    case "AMXTDWU2-BA-DUE-NOT-PD":
                        try {
                            amuw2.setAMXTDWU2BADUENOTPD(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2BADUENOTPD("");
                        }
                        break;
                    case "AMXTDWU2-RT-TOT-ASSD-LT-CHRG":
                        try {
                            amuw2.setAMXTDWU2RTTOTASSDLTCHRG(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            amuw2.setAMXTDWU2RTTOTASSDLTCHRG("");
                        }
                        break;
                    //def
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }
            }
        });
        return amuw2;
    }


}
