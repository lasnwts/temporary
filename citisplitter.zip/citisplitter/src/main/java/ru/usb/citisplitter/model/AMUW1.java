package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

/**
 * AMUW1	AMXTDWU1-CF-CUST-NUM	ALPHANUMERIC	14	1019	1032	Number assigned to this customer.	Номер, присвоенный этому клиенту.
 * AMUW1	AMXTDWU1-RT-ACCT-NUM	ALPHANUMERIC	14	13	26	Loan account number, 14-digit number.	Номер кредитного счета, 14-значный номер.
 * AMUW1	AMXTDWU1-COST-CTR 	ALPHANUMERIC	10	2690	2699	Cost center	Отделение?????
 * AMUW1	AMXTDWU1-CF-PRIM-BR	ALPHANUMERIC	5	134	138	User-defined code identifying the primary branch where the loan originated.	Определяемый пользователем код, идентифицирующий основной филиал, в котором был выдан кредит.
 * AMUW1	AMXTDWU1-RT-ACCT-EFF-DATE	DATE	8	77	84	Effective date of this loan.	Дата вступления в силу этого кредита.
 * AMUW1	AMXTDWU1-RT-CURR-MATUR-DATE	DATE	8	139	146	Current date this loan is scheduled to mature.	Текущая дата этого кредита планируется погасить.
 * AMUW1	AMXTDWU1-RT-ORIG-LOAN-AMT	NUMERIC	16	160	175	Original amount of this loan.	Первоначальная сумма этого кредита.
 * AMUW1	AMXTDWU1-RT-TOT-PRIN	NUMERIC	16	176	191	Current principal balance that is normally included in the receivable balance.  This balance represents the sum of AMMSBA01-BA-CURR-BAL for all balance data groups with a TYPE of Pxx.	Текущий остаток основного долга, который обычно включается в остаток к получению. Этот баланс представляет собой сумму AMMSBA01-BA-CURR-BAL для всех групп данных баланса с TYPE Pxx.
 * AMUW1	AMXTDWU1-OUT-BAL	NUMERIC	16	382	397	Current principal balance that is normally included in the receivable balance.  This balance represents the sum of AMMSBA01-BA-CURR-BAL for all balance data groups with a TYPE of Pxx.	Текущий остаток основного долга, который обычно включается в остаток к получению. Этот баланс представляет собой сумму AMMSBA01-BA-CURR-BAL для всех групп данных баланса с TYPE Pxx.
 * AMUW1	AMXTDWU1-SE-PRI-BAL-AT-SALE	NUMERIC	16	2293	2308	Principal balance of the loan at the time it was sold	Остаток основного долга на момент продажи
 * AMUW1	AMXTDWU1-RT-TOT-INT-REC	NUMERIC	16	350	365	Current interest receivable balance that is normally included in the receivable balance.  This balance represents the sum of the Net Due amounts for all accrual data groups with a TYPE of INT and a value of S in the AMMSAC01-AC-CALC-TYPE field.	Остаток текущих процентов к получению, который обычно включается в остаток к получению. Этот баланс представляет собой сумму сумм Net Due для всех групп данных начисления с TYPE INT и значением S в поле AMMSAC01-AC-CALC-TYPE.
 * AMUW1	AMXTDWU1-BT-INT-TOT	NUMERIC	16	2329	2344	TOTAL AMOUNT OF INTEREST ACCRUED	ОБЩАЯ СУММА НАЧИСЛЕННЫХ ПРОЦЕНТОВ
 * AMUW1	AMXTDWU1-RT-LOAN-ENTRY-DATE	DATE	8	1288	1295	Date this loan was booked	Дата оформления кредита
 * AMUW1	AMXTDWU1-RT-USER-AMT1	NUMERIC	16	2214	2229	Original UID.	Оригинальный UID.
 */

@Entity
public class AMUW1 {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //AMXTDWU1-RT-ACCT-NUM
    private String AMXTDWU1RTACCTNUM;

    /**
     * AMXTDWU1-CF-CUST-NUM
     * <p>
     * AMXTDWU1-COST-CTR
     * AMXTDWU1-CF-PRIM-BR
     * AMXTDWU1-RT-ACCT-EFF-DATE
     * AMXTDWU1-RT-CURR-MATUR-DATE
     * AMXTDWU1-RT-ORIG-LOAN-AMT
     * AMXTDWU1-RT-TOT-PRIN
     * AMXTDWU1-OUT-BAL
     * AMXTDWU1-SE-PRI-BAL-AT-SALE
     * AMXTDWU1-RT-TOT-INT-REC
     * AMXTDWU1-BT-INT-TOT
     * AMXTDWU1-RT-LOAN-ENTRY-DATE
     * AMXTDWU1-RT-USER-AMT1
     */

    //AMXTDWU1-CF-CUST-NUM
    private String AMXTDWU1CFCUSTNUM;

    //AMXTDWU1-COST-CTR
    private String AMXTDWU1COSTCTR;

    //AMXTDWU1-CF-PRIM-BR
    private String AMXTDWU1CFPRIMBR;

    //AMXTDWU1-RT-ACCT-EFF-DATE
    private LocalDate AMXTDWU1RTACCTEFFDATE;

    //AMXTDWU1-RT-CURR-MATUR-DATE
    private LocalDate AMXTDWU1RTCURRMATURDATE;

    //AMXTDWU1-RT-ORIG-LOAN-AMT
    private String AMXTDWU1RTORIGLOANAMT;

    //AMXTDWU1-RT-TOT-PRIN
    private String AMXTDWU1RTTOTPRIN;

    //AMXTDWU1-OUT-BAL
    private String AMXTDWU1OUTBAL;

    //AMXTDWU1-SE-PRI-BAL-AT-SALE
    private String AMXTDWU1SEPRIBALATSALE;

    //AMXTDWU1-RT-TOT-INT-REC
    private String AMXTDWU1RTTOTINTREC;

    //AMXTDWU1-BT-INT-TOT
    private String AMXTDWU1BTINTTOT;

    //AMXTDWU1-RT-LOAN-ENTRY-DATE
    private LocalDate AMXTDWU1RTLOANENTRYDATE;

    //AMXTDWU1-RT-USER-AMT1
    private String AMXTDWU1RTUSERAMT1;

    //AMXTDWU1-RT-POFF-PNLTY-AMT
    private String AMXTDWU1RTPOFFPNLTYAMT;

    /**
     * AMXTDWU1-RT-LOAN-RATE
     * AMXTDWU1-RT-POFF-PNLTY-AMT
     */

    //AAMXTDWU1-RT-LOAN-RATE
    private String AMXTDWU1RTLOANRATE;

    /**
     * 20.11.2022
     * AMXTDWU1-AC-INT-DUE-NOT-PD
     * AMXTDWU1-BH-SCHED-PMT-AMT
     * AMXTDWU1-RT-ORIG-MATUR-DATE
     * AMXTDWU1-DQ-TOT-DAYS-PDUE
     */
    //AMXTDWU1-AC-INT-DUE-NOT-PD
    private String AMXTDWU1ACINTDUENOTPD;

    //
    private String AMXTDWU1BHSCHEDPMTAMT;

    //AMXTDWU1-RT-ORIG-MATUR-DATE
    private LocalDate AMXTDWU1RTORIGMATURDATE;


    //AMXTDWU1-DQ-TOT-DAYS-PDUE
    private String AMXTDWU1DQTOTDAYSPDUE;

    /**
     * 21.11.2022
     * AMUW1 AMXTDWU1-DQ-TOT-DAYS-PDU --потеряли букву в коде поля (должно быть AMXTDWU1-DQ-TOT-DAYS-PDUE) - поправил
     * AMUW1 AMXTDWU1-BL-DAY (позиции 1578-1579)
     * AMUW1 AMXTDWU1-RT-NXT-DUE-DATE (позиции 788-795) 20260111     *
     */

    //AMXTDWU1-BL-DAY
    private String AMXTDWU1BLDAY;

    //AMXTDWU1-RT-NXT-DUE-DATE
    private LocalDate AMXTDWU1RTNXTDUEDATE;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public AMUW1() {
    }

    public AMUW1(long id, String AMXTDWU1RTACCTNUM, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWU1RTACCTNUM = AMXTDWU1RTACCTNUM;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }


    public AMUW1(long id, String AMXTDWU1RTACCTNUM, String AMXTDWU1CFCUSTNUM, String AMXTDWU1COSTCTR,
                 String AMXTDWU1CFPRIMBR, LocalDate AMXTDWU1RTACCTEFFDATE, LocalDate AMXTDWU1RTCURRMATURDATE,
                 String AMXTDWU1RTORIGLOANAMT, String AMXTDWU1RTTOTPRIN, String AMXTDWU1OUTBAL,
                 String AMXTDWU1SEPRIBALATSALE, String AMXTDWU1RTTOTINTREC, String AMXTDWU1BTINTTOT,
                 LocalDate AMXTDWU1RTLOANENTRYDATE, String AMXTDWU1RTUSERAMT1, String AMXTDWU1RTPOFFPNLTYAMT,
                 String AMXTDWU1RTLOANRATE, String AMXTDWU1ACINTDUENOTPD, String AMXTDWU1BHSCHEDPMTAMT,
                 LocalDate AMXTDWU1RTORIGMATURDATE, String AMXTDWU1DQTOTDAYSPDUE, String AMXTDWU1BLDAY,
                 LocalDate AMXTDWU1RTNXTDUEDATE, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWU1RTACCTNUM = AMXTDWU1RTACCTNUM;
        this.AMXTDWU1CFCUSTNUM = AMXTDWU1CFCUSTNUM;
        this.AMXTDWU1COSTCTR = AMXTDWU1COSTCTR;
        this.AMXTDWU1CFPRIMBR = AMXTDWU1CFPRIMBR;
        this.AMXTDWU1RTACCTEFFDATE = AMXTDWU1RTACCTEFFDATE;
        this.AMXTDWU1RTCURRMATURDATE = AMXTDWU1RTCURRMATURDATE;
        this.AMXTDWU1RTORIGLOANAMT = AMXTDWU1RTORIGLOANAMT;
        this.AMXTDWU1RTTOTPRIN = AMXTDWU1RTTOTPRIN;
        this.AMXTDWU1OUTBAL = AMXTDWU1OUTBAL;
        this.AMXTDWU1SEPRIBALATSALE = AMXTDWU1SEPRIBALATSALE;
        this.AMXTDWU1RTTOTINTREC = AMXTDWU1RTTOTINTREC;
        this.AMXTDWU1BTINTTOT = AMXTDWU1BTINTTOT;
        this.AMXTDWU1RTLOANENTRYDATE = AMXTDWU1RTLOANENTRYDATE;
        this.AMXTDWU1RTUSERAMT1 = AMXTDWU1RTUSERAMT1;
        this.AMXTDWU1RTPOFFPNLTYAMT = AMXTDWU1RTPOFFPNLTYAMT;
        this.AMXTDWU1RTLOANRATE = AMXTDWU1RTLOANRATE;
        this.AMXTDWU1ACINTDUENOTPD = AMXTDWU1ACINTDUENOTPD;
        this.AMXTDWU1BHSCHEDPMTAMT = AMXTDWU1BHSCHEDPMTAMT;
        this.AMXTDWU1RTORIGMATURDATE = AMXTDWU1RTORIGMATURDATE;
        this.AMXTDWU1DQTOTDAYSPDUE = AMXTDWU1DQTOTDAYSPDUE;
        this.AMXTDWU1BLDAY = AMXTDWU1BLDAY;
        this.AMXTDWU1RTNXTDUEDATE = AMXTDWU1RTNXTDUEDATE;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAMXTDWU1RTACCTNUM() {
        return AMXTDWU1RTACCTNUM;
    }

    public void setAMXTDWU1RTACCTNUM(String AMXTDWU1RTACCTNUM) {
        this.AMXTDWU1RTACCTNUM = AMXTDWU1RTACCTNUM;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getAMXTDWU1CFCUSTNUM() {
        return AMXTDWU1CFCUSTNUM;
    }

    public void setAMXTDWU1CFCUSTNUM(String AMXTDWU1CFCUSTNUM) {
        this.AMXTDWU1CFCUSTNUM = AMXTDWU1CFCUSTNUM;
    }

    public String getAMXTDWU1COSTCTR() {
        return AMXTDWU1COSTCTR;
    }

    public void setAMXTDWU1COSTCTR(String AMXTDWU1COSTCTR) {
        this.AMXTDWU1COSTCTR = AMXTDWU1COSTCTR;
    }

    public String getAMXTDWU1CFPRIMBR() {
        return AMXTDWU1CFPRIMBR;
    }

    public void setAMXTDWU1CFPRIMBR(String AMXTDWU1CFPRIMBR) {
        this.AMXTDWU1CFPRIMBR = AMXTDWU1CFPRIMBR;
    }

    public LocalDate getAMXTDWU1RTACCTEFFDATE() {
        return AMXTDWU1RTACCTEFFDATE;
    }

    public void setAMXTDWU1RTACCTEFFDATE(LocalDate AMXTDWU1RTACCTEFFDATE) {
        this.AMXTDWU1RTACCTEFFDATE = AMXTDWU1RTACCTEFFDATE;
    }

    public LocalDate getAMXTDWU1RTCURRMATURDATE() {
        return AMXTDWU1RTCURRMATURDATE;
    }

    public void setAMXTDWU1RTCURRMATURDATE(LocalDate AMXTDWU1RTCURRMATURDATE) {
        this.AMXTDWU1RTCURRMATURDATE = AMXTDWU1RTCURRMATURDATE;
    }

    public String getAMXTDWU1RTORIGLOANAMT() {
        return AMXTDWU1RTORIGLOANAMT;
    }

    public void setAMXTDWU1RTORIGLOANAMT(String AMXTDWU1RTORIGLOANAMT) {
        this.AMXTDWU1RTORIGLOANAMT = AMXTDWU1RTORIGLOANAMT;
    }

    public String getAMXTDWU1RTTOTPRIN() {
        return AMXTDWU1RTTOTPRIN;
    }

    public void setAMXTDWU1RTTOTPRIN(String AMXTDWU1RTTOTPRIN) {
        this.AMXTDWU1RTTOTPRIN = AMXTDWU1RTTOTPRIN;
    }

    public String getAMXTDWU1OUTBAL() {
        return AMXTDWU1OUTBAL;
    }

    public void setAMXTDWU1OUTBAL(String AMXTDWU1OUTBAL) {
        this.AMXTDWU1OUTBAL = AMXTDWU1OUTBAL;
    }

    public String getAMXTDWU1SEPRIBALATSALE() {
        return AMXTDWU1SEPRIBALATSALE;
    }

    public void setAMXTDWU1SEPRIBALATSALE(String AMXTDWU1SEPRIBALATSALE) {
        this.AMXTDWU1SEPRIBALATSALE = AMXTDWU1SEPRIBALATSALE;
    }

    public String getAMXTDWU1RTTOTINTREC() {
        return AMXTDWU1RTTOTINTREC;
    }

    public void setAMXTDWU1RTTOTINTREC(String AMXTDWU1RTTOTINTREC) {
        this.AMXTDWU1RTTOTINTREC = AMXTDWU1RTTOTINTREC;
    }

    public String getAMXTDWU1BTINTTOT() {
        return AMXTDWU1BTINTTOT;
    }

    public void setAMXTDWU1BTINTTOT(String AMXTDWU1BTINTTOT) {
        this.AMXTDWU1BTINTTOT = AMXTDWU1BTINTTOT;
    }

    public LocalDate getAMXTDWU1RTLOANENTRYDATE() {
        return AMXTDWU1RTLOANENTRYDATE;
    }

    public void setAMXTDWU1RTLOANENTRYDATE(LocalDate AMXTDWU1RTLOANENTRYDATE) {
        this.AMXTDWU1RTLOANENTRYDATE = AMXTDWU1RTLOANENTRYDATE;
    }

    public String getAMXTDWU1RTUSERAMT1() {
        return AMXTDWU1RTUSERAMT1;
    }

    public void setAMXTDWU1RTUSERAMT1(String AMXTDWU1RTUSERAMT1) {
        this.AMXTDWU1RTUSERAMT1 = AMXTDWU1RTUSERAMT1;
    }

    public String getAMXTDWU1RTPOFFPNLTYAMT() {
        return AMXTDWU1RTPOFFPNLTYAMT;
    }

    public void setAMXTDWU1RTPOFFPNLTYAMT(String AMXTDWU1RTPOFFPNLTYAMT) {
        this.AMXTDWU1RTPOFFPNLTYAMT = AMXTDWU1RTPOFFPNLTYAMT;
    }

    public String getAMXTDWU1RTLOANRATE() {
        return AMXTDWU1RTLOANRATE;
    }

    public void setAMXTDWU1RTLOANRATE(String AMXTDWU1RTLOANRATE) {
        this.AMXTDWU1RTLOANRATE = AMXTDWU1RTLOANRATE;
    }

    public String getAMXTDWU1ACINTDUENOTPD() {
        return AMXTDWU1ACINTDUENOTPD;
    }

    public void setAMXTDWU1ACINTDUENOTPD(String AMXTDWU1ACINTDUENOTPD) {
        this.AMXTDWU1ACINTDUENOTPD = AMXTDWU1ACINTDUENOTPD;
    }

    public String getAMXTDWU1BHSCHEDPMTAMT() {
        return AMXTDWU1BHSCHEDPMTAMT;
    }

    public void setAMXTDWU1BHSCHEDPMTAMT(String AMXTDWU1BHSCHEDPMTAMT) {
        this.AMXTDWU1BHSCHEDPMTAMT = AMXTDWU1BHSCHEDPMTAMT;
    }

    public LocalDate getAMXTDWU1RTORIGMATURDATE() {
        return AMXTDWU1RTORIGMATURDATE;
    }

    public void setAMXTDWU1RTORIGMATURDATE(LocalDate AMXTDWU1RTORIGMATURDATE) {
        this.AMXTDWU1RTORIGMATURDATE = AMXTDWU1RTORIGMATURDATE;
    }

    public String getAMXTDWU1DQTOTDAYSPDUE() {
        return AMXTDWU1DQTOTDAYSPDUE;
    }

    public void setAMXTDWU1DQTOTDAYSPDUE(String AMXTDWU1DQTOTDAYSPDUE) {
        this.AMXTDWU1DQTOTDAYSPDUE = AMXTDWU1DQTOTDAYSPDUE;
    }

    public String getAMXTDWU1BLDAY() {
        return AMXTDWU1BLDAY;
    }

    public void setAMXTDWU1BLDAY(String AMXTDWU1BLDAY) {
        this.AMXTDWU1BLDAY = AMXTDWU1BLDAY;
    }

    public LocalDate getAMXTDWU1RTNXTDUEDATE() {
        return AMXTDWU1RTNXTDUEDATE;
    }

    public void setAMXTDWU1RTNXTDUEDATE(LocalDate AMXTDWU1RTNXTDUEDATE) {
        this.AMXTDWU1RTNXTDUEDATE = AMXTDWU1RTNXTDUEDATE;
    }

    @Override
    public String toString() {
        return "AMUW1{" +
                "id=" + id +
                ", AMXTDWU1RTACCTNUM='" + AMXTDWU1RTACCTNUM + '\'' +
                ", AMXTDWU1CFCUSTNUM='" + AMXTDWU1CFCUSTNUM + '\'' +
                ", AMXTDWU1COSTCTR='" + AMXTDWU1COSTCTR + '\'' +
                ", AMXTDWU1CFPRIMBR='" + AMXTDWU1CFPRIMBR + '\'' +
                ", AMXTDWU1RTACCTEFFDATE=" + AMXTDWU1RTACCTEFFDATE +
                ", AMXTDWU1RTCURRMATURDATE=" + AMXTDWU1RTCURRMATURDATE +
                ", AMXTDWU1RTORIGLOANAMT='" + AMXTDWU1RTORIGLOANAMT + '\'' +
                ", AMXTDWU1RTTOTPRIN='" + AMXTDWU1RTTOTPRIN + '\'' +
                ", AMXTDWU1OUTBAL='" + AMXTDWU1OUTBAL + '\'' +
                ", AMXTDWU1SEPRIBALATSALE='" + AMXTDWU1SEPRIBALATSALE + '\'' +
                ", AMXTDWU1RTTOTINTREC='" + AMXTDWU1RTTOTINTREC + '\'' +
                ", AMXTDWU1BTINTTOT='" + AMXTDWU1BTINTTOT + '\'' +
                ", AMXTDWU1RTLOANENTRYDATE=" + AMXTDWU1RTLOANENTRYDATE +
                ", AMXTDWU1RTUSERAMT1='" + AMXTDWU1RTUSERAMT1 + '\'' +
                ", AMXTDWU1RTPOFFPNLTYAMT='" + AMXTDWU1RTPOFFPNLTYAMT + '\'' +
                ", AMXTDWU1RTLOANRATE='" + AMXTDWU1RTLOANRATE + '\'' +
                ", AMXTDWU1ACINTDUENOTPD='" + AMXTDWU1ACINTDUENOTPD + '\'' +
                ", AMXTDWU1BHSCHEDPMTAMT='" + AMXTDWU1BHSCHEDPMTAMT + '\'' +
                ", AMXTDWU1RTORIGMATURDATE=" + AMXTDWU1RTORIGMATURDATE +
                ", AMXTDWU1DQTOTDAYSPDUE='" + AMXTDWU1DQTOTDAYSPDUE + '\'' +
                ", AMXTDWU1BLDAY='" + AMXTDWU1BLDAY + '\'' +
                ", AMXTDWU1RTNXTDUEDATE=" + AMXTDWU1RTNXTDUEDATE +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
