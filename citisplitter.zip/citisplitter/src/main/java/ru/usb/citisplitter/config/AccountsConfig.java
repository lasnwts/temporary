package ru.usb.citisplitter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;


@Component
@ConfigurationProperties(prefix = "tableaccount")
public class AccountsConfig {

    private List<Fields> account = new ArrayList<>();

    public AccountsConfig() {
    }

    public List<Fields> getAccount() {
        return account;
    }

    public void setAccount(List<Fields> account) {
        this.account = account;
    }
}
