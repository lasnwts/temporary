package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitAMUW1;
import ru.usb.citisplitter.config.file.SplitCUSTMISC;
import ru.usb.citisplitter.model.AMUW1;
import ru.usb.citisplitter.model.CUSTMISC;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.repository.JpaRepositoryAmuw1;
import ru.usb.citisplitter.repository.JpaRepositoryCusrMisc;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class CUSTMISCProcessed {


    Logger logger = LoggerFactory.getLogger(CUSTMISCProcessed.class);

    @Autowired
    SplitCUSTMISC splitCUSTMISC;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryCusrMisc jpaRepositoryCusrMisc;

    File file;

    String output_file = "CUSTMISCProcessed.txt";

    /**
     * Базовая последовательность
     *
     * @param filePath
     * @param per
     * @param fName
     * @return
     * @throws IOException
     */
    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitCUSTMISC.getMisc().size() == 0) {
            logger.info("Пустой список splitCUSTMISC");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    count.incrementAndGet();
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (count.get() > 1 && line.trim().length() > 79) {

                            CUSTMISC custmisc = getNewCUSTMISC(line);
                            custmisc.setPER(per);
                            custmisc.setInputDate(new Date());
                            custmisc.setFILENAME(fName);
                            jpaRepositoryCusrMisc.save(custmisc);

                            if (configure.isFileFlagCSV()) {
                                writer.write((count.get()) + ";" + custmisc.toString() + System.lineSeparator());
                            }

                            //Удаляем объект
                            custmisc = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект
     *
     * @param line
     * @return
     */
    private CUSTMISC getNewCUSTMISC(String line) {

        CUSTMISC custmisc = new CUSTMISC();

        splitCUSTMISC.getMisc().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "CA_CUSTNO":
                        try {
                            custmisc.setCA_CUSTNO(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custmisc.setCA_CUSTNO("");
                        }
                        break;
                        //20.11.2022
                    case "CA_KEY_VAL":
                        try {
                            custmisc.setCA_KEY_VAL(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custmisc.setCA_KEY_VAL("");
                        }
                        break;
                    case "CA_FIELD_VAL":
                        try {
                            custmisc.setCA_FIELD_VAL(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custmisc.setCA_FIELD_VAL("");
                        }
                        break;
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }

            }
        });
        return custmisc;
    }


}
