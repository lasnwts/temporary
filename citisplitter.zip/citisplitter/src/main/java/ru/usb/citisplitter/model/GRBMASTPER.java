package ru.usb.citisplitter.model;

import java.time.LocalDate;
import java.util.Date;

/**
 * Customer information
 */
public class GRBMASTPER {

    //Customer Identification Number (ex: 003589701)
    private String CM_CUST_CUSTNUMB;

    //Customer Name
    private String CM_CUST_INDCORPNAME;

    //Customer Surname
    private String CM_SURNAME_PART;

    //Customer Name
    private String CM_NAME_PART;

    //PP English Name
    private String CM_FATHER_NAME;

    //Date of Birth
    private LocalDate CM_CUST_BIRTH_DATE;

    //Customer Birth Place
    private String CM_BIRTH_PLACE;

    //Customer Birth Country
    private String CM_BIRTH_CTRY;

    //Customer’s Tax ID
    private String CM_CUST_TAX_ID;


    public GRBMASTPER() {
    }

    public GRBMASTPER(String CM_CUST_CUSTNUMB, String CM_CUST_INDCORPNAME, String CM_SURNAME_PART, String CM_NAME_PART,
                      String CM_FATHER_NAME, Date CM_CUST_BIRTH_DATE, String CM_BIRTH_PLACE, String CM_BIRTH_CTRY) {
        this.CM_CUST_CUSTNUMB = CM_CUST_CUSTNUMB;
        this.CM_CUST_INDCORPNAME = CM_CUST_INDCORPNAME;
        this.CM_SURNAME_PART = CM_SURNAME_PART;
        this.CM_NAME_PART = CM_NAME_PART;
        this.CM_FATHER_NAME = CM_FATHER_NAME;

        this.CM_BIRTH_PLACE = CM_BIRTH_PLACE;
        this.CM_BIRTH_CTRY = CM_BIRTH_CTRY;
    }

    public String getCM_CUST_CUSTNUMB() {
        return CM_CUST_CUSTNUMB;
    }



    public String getCM_CUST_INDCORPNAME() {
        return CM_CUST_INDCORPNAME;
    }

    public void setCM_CUST_INDCORPNAME(String CM_CUST_INDCORPNAME) {
        this.CM_CUST_INDCORPNAME = CM_CUST_INDCORPNAME;
    }

    public String getCM_SURNAME_PART() {
        return CM_SURNAME_PART;
    }

    public void setCM_SURNAME_PART(String CM_SURNAME_PART) {
        this.CM_SURNAME_PART = CM_SURNAME_PART;
    }

    public String getCM_NAME_PART() {
        return CM_NAME_PART;
    }

    public void setCM_NAME_PART(String CM_NAME_PART) {
        this.CM_NAME_PART = CM_NAME_PART;
    }

    public String getCM_FATHER_NAME() {
        return CM_FATHER_NAME;
    }

    public void setCM_FATHER_NAME(String CM_FATHER_NAME) {
        this.CM_FATHER_NAME = CM_FATHER_NAME;
    }



    public String getCM_BIRTH_PLACE() {
        return CM_BIRTH_PLACE;
    }

    public void setCM_BIRTH_PLACE(String CM_BIRTH_PLACE) {
        this.CM_BIRTH_PLACE = CM_BIRTH_PLACE;
    }

    public String getCM_BIRTH_CTRY() {
        return CM_BIRTH_CTRY;
    }


    public String getCM_CUST_TAX_ID() {
        return CM_CUST_TAX_ID;
    }

    public void setCM_CUST_TAX_ID(String CM_CUST_TAX_ID) {
        this.CM_CUST_TAX_ID = CM_CUST_TAX_ID;
    }

    public void setCM_CUST_CUSTNUMB(String CM_CUST_CUSTNUMB) {
        this.CM_CUST_CUSTNUMB = CM_CUST_CUSTNUMB;
    }

    public void setCM_BIRTH_CTRY(String CM_BIRTH_CTRY) {
        this.CM_BIRTH_CTRY = CM_BIRTH_CTRY;
    }

    public LocalDate getCM_CUST_BIRTH_DATE() {
        return CM_CUST_BIRTH_DATE;
    }

    public void setCM_CUST_BIRTH_DATE(LocalDate CM_CUST_BIRTH_DATE) {
        this.CM_CUST_BIRTH_DATE = CM_CUST_BIRTH_DATE;
    }

    @Override
    public String toString() {
        return "GRBMASTPER{" +
                "CM_CUST_CUSTNUMB='" + CM_CUST_CUSTNUMB + '\'' +
                ", CM_CUST_INDCORPNAME='" + CM_CUST_INDCORPNAME + '\'' +
                ", CM_SURNAME_PART='" + CM_SURNAME_PART + '\'' +
                ", CM_NAME_PART='" + CM_NAME_PART + '\'' +
                ", CM_FATHER_NAME='" + CM_FATHER_NAME + '\'' +
                ", CM_CUST_BIRTH_DATE=" + CM_CUST_BIRTH_DATE +
                ", CM_BIRTH_PLACE='" + CM_BIRTH_PLACE + '\'' +
                ", CM_BIRTH_CTRY='" + CM_BIRTH_CTRY + '\'' +
                ", CM_CUST_TAX_ID='" + CM_CUST_TAX_ID + '\'' +
                '}';
    }
}
