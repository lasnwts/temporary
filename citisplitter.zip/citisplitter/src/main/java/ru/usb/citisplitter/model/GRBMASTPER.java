package ru.usb.citisplitter.model;

import java.time.LocalDate;
import java.util.Date;

/**
 * Customer information
 */
public class GRBMASTPER {

    //Customer Identification Number (ex: 003589701)
    private String CM_CUST_CUSTNUMB;

    //Customer Name
    private String CM_CUST_INDCORPNAME;

    //Customer Surname
    private String CM_SURNAME_PART;

    //Customer Name
    private String CM_NAME_PART;

    //PP English Name
    private String CM_FATHER_NAME;

    //Date of Birth
    private LocalDate CM_CUST_BIRTH_DATE;

    //Customer Birth Place
    private String CM_BIRTH_PLACE;

    //Customer Birth Country
    private String CM_BIRTH_CTRY;

    //Customer’s Tax ID
    private String CM_CUST_TAX_ID;


    /**
     * 16	SEX_CODE	Пол	 	     * Женский - Ж      * Мужской - М	GRBMAST	CM_CUST_SEX	CHAR	1	259	259	Gender of customer	Пол клиента
     * 23	MARIGE_STATUS_CODE	Семейное положение. Код	 	Код из справочника "Семейное положение"	GRBMAST	CM_CUST_MSSTAT	CHAR	1	121	121	Marital Status	Семейное положение
     * 29	LEV_EDUC_CODE	Уровень образования. Код	 	Код из справочника "Уровень образования"	GRBMAST	CM_EDUC_TITLE	CHAR	25	1683	1707	Customer's Education Title	Уровень образования клиента
     */
    //Gender of customer SEX_CODE
    private String CM_CUST_SEX;

    //Marital Status MARIGE_STATUS_CODE
    private String CM_CUST_MSSTAT;

    //Customer's Education Title LEV_EDUC_CODE
    private String CM_EDUC_TITLE;


    public GRBMASTPER() {
    }


    public GRBMASTPER(String CM_CUST_CUSTNUMB, String CM_CUST_INDCORPNAME, String CM_SURNAME_PART, String CM_NAME_PART,
                      String CM_FATHER_NAME, LocalDate CM_CUST_BIRTH_DATE, String CM_BIRTH_PLACE, String CM_BIRTH_CTRY,
                      String CM_CUST_TAX_ID, String CM_CUST_SEX, String CM_CUST_MSSTAT, String CM_EDUC_TITLE) {
        this.CM_CUST_CUSTNUMB = CM_CUST_CUSTNUMB;
        this.CM_CUST_INDCORPNAME = CM_CUST_INDCORPNAME;
        this.CM_SURNAME_PART = CM_SURNAME_PART;
        this.CM_NAME_PART = CM_NAME_PART;
        this.CM_FATHER_NAME = CM_FATHER_NAME;
        this.CM_CUST_BIRTH_DATE = CM_CUST_BIRTH_DATE;
        this.CM_BIRTH_PLACE = CM_BIRTH_PLACE;
        this.CM_BIRTH_CTRY = CM_BIRTH_CTRY;
        this.CM_CUST_TAX_ID = CM_CUST_TAX_ID;
        this.CM_CUST_SEX = CM_CUST_SEX;
        this.CM_CUST_MSSTAT = CM_CUST_MSSTAT;
        this.CM_EDUC_TITLE = CM_EDUC_TITLE;
    }

    public String getCM_CUST_CUSTNUMB() {
        return CM_CUST_CUSTNUMB;
    }


    public String getCM_CUST_INDCORPNAME() {
        return CM_CUST_INDCORPNAME;
    }

    public void setCM_CUST_INDCORPNAME(String CM_CUST_INDCORPNAME) {
        this.CM_CUST_INDCORPNAME = CM_CUST_INDCORPNAME;
    }

    public String getCM_SURNAME_PART() {
        return CM_SURNAME_PART;
    }

    public void setCM_SURNAME_PART(String CM_SURNAME_PART) {
        this.CM_SURNAME_PART = CM_SURNAME_PART;
    }

    public String getCM_NAME_PART() {
        return CM_NAME_PART;
    }

    public void setCM_NAME_PART(String CM_NAME_PART) {
        this.CM_NAME_PART = CM_NAME_PART;
    }

    public String getCM_FATHER_NAME() {
        return CM_FATHER_NAME;
    }

    public void setCM_FATHER_NAME(String CM_FATHER_NAME) {
        this.CM_FATHER_NAME = CM_FATHER_NAME;
    }


    public String getCM_BIRTH_PLACE() {
        return CM_BIRTH_PLACE;
    }

    public void setCM_BIRTH_PLACE(String CM_BIRTH_PLACE) {
        this.CM_BIRTH_PLACE = CM_BIRTH_PLACE;
    }

    public String getCM_BIRTH_CTRY() {
        return CM_BIRTH_CTRY;
    }


    public String getCM_CUST_TAX_ID() {
        return CM_CUST_TAX_ID;
    }

    public void setCM_CUST_TAX_ID(String CM_CUST_TAX_ID) {
        this.CM_CUST_TAX_ID = CM_CUST_TAX_ID;
    }

    public void setCM_CUST_CUSTNUMB(String CM_CUST_CUSTNUMB) {
        this.CM_CUST_CUSTNUMB = CM_CUST_CUSTNUMB;
    }

    public void setCM_BIRTH_CTRY(String CM_BIRTH_CTRY) {
        this.CM_BIRTH_CTRY = CM_BIRTH_CTRY;
    }

    public LocalDate getCM_CUST_BIRTH_DATE() {
        return CM_CUST_BIRTH_DATE;
    }

    public void setCM_CUST_BIRTH_DATE(LocalDate CM_CUST_BIRTH_DATE) {
        this.CM_CUST_BIRTH_DATE = CM_CUST_BIRTH_DATE;
    }

    @Override
    public String toString() {
        return "GRBMASTPER{" +
                "CM_CUST_CUSTNUMB='" + CM_CUST_CUSTNUMB + '\'' +
                ", CM_CUST_INDCORPNAME='" + CM_CUST_INDCORPNAME + '\'' +
                ", CM_SURNAME_PART='" + CM_SURNAME_PART + '\'' +
                ", CM_NAME_PART='" + CM_NAME_PART + '\'' +
                ", CM_FATHER_NAME='" + CM_FATHER_NAME + '\'' +
                ", CM_CUST_BIRTH_DATE=" + CM_CUST_BIRTH_DATE +
                ", CM_BIRTH_PLACE='" + CM_BIRTH_PLACE + '\'' +
                ", CM_BIRTH_CTRY='" + CM_BIRTH_CTRY + '\'' +
                ", CM_CUST_TAX_ID='" + CM_CUST_TAX_ID + '\'' +
                ", CM_CUST_SEX='" + CM_CUST_SEX + '\'' +
                ", CM_CUST_MSSTAT='" + CM_CUST_MSSTAT + '\'' +
                ", CM_EDUC_TITLE='" + CM_EDUC_TITLE + '\'' +
                '}';
    }

    public String toCSVhead() {
        return "CM_CUST_CUSTNUMB" + ';' +
                "CM_CUST_INDCORPNAME" + ';' +
                "CM_SURNAME_PART" + ';' +
                "CM_NAME_PART" + ';' +
                "CM_FATHER_NAME" + ';' +
                "CM_CUST_BIRTH_DATE" + ';' +
                "CM_BIRTH_PLACE" + ';' +
                "CM_BIRTH_CTRY" + ';' +
                "CM_CUST_TAX_ID" + ';' +
                "CM_CUST_SEX" + ';' +
                "CM_CUST_MSSTAT" + ';' +
                "CM_EDUC_TITLE";
    }

    public String toCSV() {
        return getShield(CM_CUST_CUSTNUMB) + ';' +
                getShield(CM_CUST_INDCORPNAME) + ';' +
                getShield(CM_SURNAME_PART) + ';' +
                getShield(CM_NAME_PART) + ';' +
                getShield(CM_FATHER_NAME) + ';' +
                CM_CUST_BIRTH_DATE + ';' +
                getShield(CM_BIRTH_PLACE) + ';' +
                getShield(CM_BIRTH_CTRY) + ';' +
                getShield(CM_CUST_TAX_ID) + ';' +
                getShield(CM_CUST_SEX) + ';' +
                getShield(CM_CUST_MSSTAT) + ';' +
                getShield(CM_EDUC_TITLE);
    }

    private String getShield(String line) {
        if (line==null){
            return "";
        }
        return line.replace(";", "<:>");
    }

}
