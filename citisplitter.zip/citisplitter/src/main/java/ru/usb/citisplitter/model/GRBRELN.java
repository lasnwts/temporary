package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * RELN
 * - CM_RELN_CUSTNUMB (позиции с 16 по 24)
 * - CM_RELN_ACCTNUMB (позиции с 39 по 58)
 */

@Entity
public class GRBRELN {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //CM_RELN_CUSTNUMB
    private String CM_RELN_CUSTNUMB;

    //CM_RELN_ACCTNUMB
    private String CM_RELN_ACCTNUMB;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public GRBRELN() {
    }

    public GRBRELN(long id, String CM_RELN_CUSTNUMB, String CM_RELN_ACCTNUMB, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CM_RELN_CUSTNUMB = CM_RELN_CUSTNUMB;
        this.CM_RELN_ACCTNUMB = CM_RELN_ACCTNUMB;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCM_RELN_CUSTNUMB() {
        return CM_RELN_CUSTNUMB;
    }

    public void setCM_RELN_CUSTNUMB(String CM_RELN_CUSTNUMB) {
        this.CM_RELN_CUSTNUMB = CM_RELN_CUSTNUMB;
    }

    public String getCM_RELN_ACCTNUMB() {
        return CM_RELN_ACCTNUMB;
    }

    public void setCM_RELN_ACCTNUMB(String CM_RELN_ACCTNUMB) {
        this.CM_RELN_ACCTNUMB = CM_RELN_ACCTNUMB;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "GRBRELN{" +
                "id=" + id +
                ", CM_RELN_CUSTNUMB='" + CM_RELN_CUSTNUMB + '\'' +
                ", CM_RELN_ACCTNUMB='" + CM_RELN_ACCTNUMB + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
