package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitGRBADDRESS;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.model.GRBADDRESS;
import ru.usb.citisplitter.model.GRBMASTPER;
import ru.usb.citisplitter.repository.JpaRepositoryGrbAddress;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class GRBADDRESSProcessed {

    Logger logger = LoggerFactory.getLogger(GRBADDRESSProcessed.class);

    @Autowired
    SplitGRBADDRESS splitGRBADDRESS;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryGrbAddress jpaRepositoryGrbAddress;


    File file;

    String output_file = "GRBADDRESS_PER.txt";


    /**
     * Получаем объект GRBADDRESS
     *
     * @param line
     * @return
     */
    private GRBADDRESS getGRBADDRESS(String line) {

        GRBADDRESS grbaddress = new GRBADDRESS();

        splitGRBADDRESS.getAddr().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "DWHADDR-TYPE-CODE":
                        try {
                            grbaddress.setDWHADDRTYPECODE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRTYPECODE("");
                        }
                        break;
                    case "DWHADDR-TOWNCITY-DESC":
                        try {
                            grbaddress.setDWHADDRTOWNCITYDESC(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRTOWNCITYDESC("");
                        }
                        break;
                    case "DWHADDR-LINE6":
                        try {
                            grbaddress.setDWHADDRLINE6(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRLINE6("");
                        }
                        break;
                    case "DWHADDR-LINE7":
                        try {
                            grbaddress.setDWHADDRLINE7(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRLINE7("");
                        }
                        break;
                    case "DWHADDR-POST-CODE":
                        try {
                            grbaddress.setDWHADDRPOSTCODE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRPOSTCODE("");
                        }
                        break;
                    case "DWHADDR-ESTBDATE":
                        try {
                            grbaddress.setDWHADDRESTBDATE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRESTBDATE("");
                        }
                        break;
                        //
                    case "DWHADDR-LINE2":
                        try {
                            grbaddress.setDWHADDRLINE2(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRLINE2("");
                        }
                        break;
                    case "DWHADDR-STATE":
                        try {
                            grbaddress.setDWHADDRSTATE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRSTATE("");
                        }
                        break;
                    case "DWHADDR-CTRY-DESC":
                        try {
                            grbaddress.setDWHADDRCTRYDESC(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRCTRYDESC("");
                        }
                        break;
                    case "DWHADDR-LINE4":
                        try {
                            grbaddress.setDWHADDRLINE4(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRLINE4("");
                        }
                        break;
                    case "DWHADDR-NUMBER":
                        try {
                            grbaddress.setDWHADDRNUMBER(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbaddress.setDWHADDRNUMBER("");
                        }
                        break;

                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });

        return grbaddress;
    }

    /**
     * Основной поток получения объектов с Адрресом
     * @param filePath
     * @return
     * @throws IOException
     */
    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitGRBADDRESS.getAddr().size() == 0) {
            logger.info("Пустой список splitGRBADDRESS");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file,Charset.forName("Cp866") );


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (line.trim().length() > 200) {

                            GRBADDRESS grbaddress = getGRBADDRESS(line);
                            grbaddress.setPER(per);
                            grbaddress.setInputDate(new Date());
                            grbaddress.setFILENAME(fName);
                            jpaRepositoryGrbAddress.save(grbaddress);

                            if (configure.isFileFlagCSV()) {
                                writer.write((count.incrementAndGet()) + ";" + grbaddress.toString() + System.lineSeparator());
                            }
                            //Удаляем объект
                            grbaddress = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


}
