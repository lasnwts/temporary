package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.CUSTID;

public interface JpaRepositoryCustId extends JpaRepository<CUSTID, Long> {
}
