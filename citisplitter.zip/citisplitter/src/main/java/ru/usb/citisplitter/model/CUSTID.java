package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * CUSTID
 * связь по полю CM-ACID-CUST-NBR (id клиента) - 9 символов, позиция с 15 по 23
 */
@Entity
public class CUSTID {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    /**
     * CM-ACID-ISSUE-DATE
     * CM-ACID-EXPIRY-DATE
     * CM-ACID-CUST-ID-CD
     * CM-ACID-CUST-ID
     * CM-ACID-CUST-ID
     * ???
     * CM-ACID-CUST-ID-TYP
     * CM-ACID-ISSUE-AUTH
     * CM-ACID-ISSUE-PLACE
     * CM-ACID-CUST-ID-CTRY-OF-ISSUE
     */

    //CM-ACID-ISSUE-DATE
    private String CMACIDISSUEDATE;

    //CM-ACID-EXPIRY-DATE
    private String CMACIDEXPIRYDATE;

    //CM-ACID-CUST-ID-CD
    private String CMACIDCUSTIDCD;

    //CM-ACID-CUST-ID
    private String CMACIDCUSTID;

    //CM-ACID-CUST-ID-TYP
    private String CMACIDCUSTIDTYP;

    //CM-ACID-ISSUE-AUTH
    private String CMACIDISSUEAUTH;

    //CM-ACID-ISSUE-PLACE
    private String CMACIDISSUEPLACE;

    //CM-ACID-CUST-ID-CTRY-OF-ISSUE
    private String CMACIDCUSTIDCTRYOFISSUE;

    //18112022
    //CM-ACID-CUST-NBR
    private String CMACIDCUSTNBR;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public CUSTID() {
    }

    public CUSTID(String CMACIDISSUEDATE, String CMACIDEXPIRYDATE, String CMACIDCUSTIDCD, String CMACIDCUSTID, String CMACIDCUSTIDTYP,
                  String CMACIDISSUEAUTH, String CMACIDISSUEPLACE, String CMACIDCUSTIDCTRYOFISSUE) {
        this.CMACIDISSUEDATE = CMACIDISSUEDATE;
        this.CMACIDEXPIRYDATE = CMACIDEXPIRYDATE;
        this.CMACIDCUSTIDCD = CMACIDCUSTIDCD;
        this.CMACIDCUSTID = CMACIDCUSTID;
        this.CMACIDCUSTIDTYP = CMACIDCUSTIDTYP;
        this.CMACIDISSUEAUTH = CMACIDISSUEAUTH;
        this.CMACIDISSUEPLACE = CMACIDISSUEPLACE;
        this.CMACIDCUSTIDCTRYOFISSUE = CMACIDCUSTIDCTRYOFISSUE;
    }

    public CUSTID(long id, String CMACIDISSUEDATE, String CMACIDEXPIRYDATE, String CMACIDCUSTIDCD, String CMACIDCUSTID,
                  String CMACIDCUSTIDTYP, String CMACIDISSUEAUTH, String CMACIDISSUEPLACE,
                  String CMACIDCUSTIDCTRYOFISSUE, String CMACIDCUSTNBR, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CMACIDISSUEDATE = CMACIDISSUEDATE;
        this.CMACIDEXPIRYDATE = CMACIDEXPIRYDATE;
        this.CMACIDCUSTIDCD = CMACIDCUSTIDCD;
        this.CMACIDCUSTID = CMACIDCUSTID;
        this.CMACIDCUSTIDTYP = CMACIDCUSTIDTYP;
        this.CMACIDISSUEAUTH = CMACIDISSUEAUTH;
        this.CMACIDISSUEPLACE = CMACIDISSUEPLACE;
        this.CMACIDCUSTIDCTRYOFISSUE = CMACIDCUSTIDCTRYOFISSUE;
        this.CMACIDCUSTNBR = CMACIDCUSTNBR;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public String getCMACIDISSUEDATE() {
        return CMACIDISSUEDATE;
    }

    public void setCMACIDISSUEDATE(String CMACIDISSUEDATE) {
        this.CMACIDISSUEDATE = CMACIDISSUEDATE;
    }

    public String getCMACIDEXPIRYDATE() {
        return CMACIDEXPIRYDATE;
    }

    public void setCMACIDEXPIRYDATE(String CMACIDEXPIRYDATE) {
        this.CMACIDEXPIRYDATE = CMACIDEXPIRYDATE;
    }

    public String getCMACIDCUSTIDCD() {
        return CMACIDCUSTIDCD;
    }

    public void setCMACIDCUSTIDCD(String CMACIDCUSTIDCD) {
        this.CMACIDCUSTIDCD = CMACIDCUSTIDCD;
    }

    public String getCMACIDCUSTID() {
        return CMACIDCUSTID;
    }

    public void setCMACIDCUSTID(String CMACIDCUSTID) {
        this.CMACIDCUSTID = CMACIDCUSTID;
    }

    public String getCMACIDCUSTIDTYP() {
        return CMACIDCUSTIDTYP;
    }

    public void setCMACIDCUSTIDTYP(String CMACIDCUSTIDTYP) {
        this.CMACIDCUSTIDTYP = CMACIDCUSTIDTYP;
    }

    public String getCMACIDISSUEAUTH() {
        return CMACIDISSUEAUTH;
    }

    public void setCMACIDISSUEAUTH(String CMACIDISSUEAUTH) {
        this.CMACIDISSUEAUTH = CMACIDISSUEAUTH;
    }

    public String getCMACIDISSUEPLACE() {
        return CMACIDISSUEPLACE;
    }

    public void setCMACIDISSUEPLACE(String CMACIDISSUEPLACE) {
        this.CMACIDISSUEPLACE = CMACIDISSUEPLACE;
    }

    public String getCMACIDCUSTIDCTRYOFISSUE() {
        return CMACIDCUSTIDCTRYOFISSUE;
    }

    public void setCMACIDCUSTIDCTRYOFISSUE(String CMACIDCUSTIDCTRYOFISSUE) {
        this.CMACIDCUSTIDCTRYOFISSUE = CMACIDCUSTIDCTRYOFISSUE;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getCMACIDCUSTNBR() {
        return CMACIDCUSTNBR;
    }

    public void setCMACIDCUSTNBR(String CMACIDCUSTNBR) {
        this.CMACIDCUSTNBR = CMACIDCUSTNBR;
    }

    @Override
    public String toString() {
        return "CUSTID{" +
                "id=" + id +
                ", CMACIDISSUEDATE='" + CMACIDISSUEDATE + '\'' +
                ", CMACIDEXPIRYDATE='" + CMACIDEXPIRYDATE + '\'' +
                ", CMACIDCUSTIDCD='" + CMACIDCUSTIDCD + '\'' +
                ", CMACIDCUSTID='" + CMACIDCUSTID + '\'' +
                ", CMACIDCUSTIDTYP='" + CMACIDCUSTIDTYP + '\'' +
                ", CMACIDISSUEAUTH='" + CMACIDISSUEAUTH + '\'' +
                ", CMACIDISSUEPLACE='" + CMACIDISSUEPLACE + '\'' +
                ", CMACIDCUSTIDCTRYOFISSUE='" + CMACIDCUSTIDCTRYOFISSUE + '\'' +
                ", CMACIDCUSTNBR='" + CMACIDCUSTNBR + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
