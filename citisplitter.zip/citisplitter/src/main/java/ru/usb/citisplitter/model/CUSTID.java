package ru.usb.citisplitter.model;

/**
 * CUSTID
 * связь по полю CM-ACID-CUST-NBR (id клиента) - 9 символов, позиция с 15 по 23
 */
public class CUSTID {


    //CM-ACID-ISSUE-DATE
    private String CMACIDISSUEDATE;

    //CM-ACID-EXPIRY-DATE
    private String CMACIDEXPIRYDATE;

    //CM-ACID-CUST-ID-CD
    private String CMACIDCUSTIDCD;

    //CM-ACID-CUST-ID
    private String CMACIDCUSTID;

    //CM-ACID-CUST-ID-TYP
    private String CMACIDCUSTIDTYP;

    //CM-ACID-ISSUE-AUTH
    private String CMACIDISSUEAUTH;

    //CM-ACID-ISSUE-PLACE
    private String CMACIDISSUEPLACE;

    //CM-ACID-CUST-ID-CTRY-OF-ISSUE
    private String CMACIDCUSTIDCTRYOFISSUE;

    public CUSTID() {
    }

    public CUSTID(String CMACIDISSUEDATE, String CMACIDEXPIRYDATE, String CMACIDCUSTIDCD, String CMACIDCUSTID, String CMACIDCUSTIDTYP,
                  String CMACIDISSUEAUTH, String CMACIDISSUEPLACE, String CMACIDCUSTIDCTRYOFISSUE) {
        this.CMACIDISSUEDATE = CMACIDISSUEDATE;
        this.CMACIDEXPIRYDATE = CMACIDEXPIRYDATE;
        this.CMACIDCUSTIDCD = CMACIDCUSTIDCD;
        this.CMACIDCUSTID = CMACIDCUSTID;
        this.CMACIDCUSTIDTYP = CMACIDCUSTIDTYP;
        this.CMACIDISSUEAUTH = CMACIDISSUEAUTH;
        this.CMACIDISSUEPLACE = CMACIDISSUEPLACE;
        this.CMACIDCUSTIDCTRYOFISSUE = CMACIDCUSTIDCTRYOFISSUE;
    }

    public String getCMACIDISSUEDATE() {
        return CMACIDISSUEDATE;
    }

    public void setCMACIDISSUEDATE(String CMACIDISSUEDATE) {
        this.CMACIDISSUEDATE = CMACIDISSUEDATE;
    }

    public String getCMACIDEXPIRYDATE() {
        return CMACIDEXPIRYDATE;
    }

    public void setCMACIDEXPIRYDATE(String CMACIDEXPIRYDATE) {
        this.CMACIDEXPIRYDATE = CMACIDEXPIRYDATE;
    }

    public String getCMACIDCUSTIDCD() {
        return CMACIDCUSTIDCD;
    }

    public void setCMACIDCUSTIDCD(String CMACIDCUSTIDCD) {
        this.CMACIDCUSTIDCD = CMACIDCUSTIDCD;
    }

    public String getCMACIDCUSTID() {
        return CMACIDCUSTID;
    }

    public void setCMACIDCUSTID(String CMACIDCUSTID) {
        this.CMACIDCUSTID = CMACIDCUSTID;
    }

    public String getCMACIDCUSTIDTYP() {
        return CMACIDCUSTIDTYP;
    }

    public void setCMACIDCUSTIDTYP(String CMACIDCUSTIDTYP) {
        this.CMACIDCUSTIDTYP = CMACIDCUSTIDTYP;
    }

    public String getCMACIDISSUEAUTH() {
        return CMACIDISSUEAUTH;
    }

    public void setCMACIDISSUEAUTH(String CMACIDISSUEAUTH) {
        this.CMACIDISSUEAUTH = CMACIDISSUEAUTH;
    }

    public String getCMACIDISSUEPLACE() {
        return CMACIDISSUEPLACE;
    }

    public void setCMACIDISSUEPLACE(String CMACIDISSUEPLACE) {
        this.CMACIDISSUEPLACE = CMACIDISSUEPLACE;
    }

    public String getCMACIDCUSTIDCTRYOFISSUE() {
        return CMACIDCUSTIDCTRYOFISSUE;
    }

    public void setCMACIDCUSTIDCTRYOFISSUE(String CMACIDCUSTIDCTRYOFISSUE) {
        this.CMACIDCUSTIDCTRYOFISSUE = CMACIDCUSTIDCTRYOFISSUE;
    }

    @Override
    public String toString() {
        return "CUSTID{" +
                "CMACIDISSUEDATE='" + CMACIDISSUEDATE + '\'' +
                ", CMACIDEXPIRYDATE='" + CMACIDEXPIRYDATE + '\'' +
                ", CMACIDCUSTIDCD='" + CMACIDCUSTIDCD + '\'' +
                ", CMACIDCUSTID='" + CMACIDCUSTID + '\'' +
                ", CMACIDCUSTIDTYP='" + CMACIDCUSTIDTYP + '\'' +
                ", CMACIDISSUEAUTH='" + CMACIDISSUEAUTH + '\'' +
                ", CMACIDISSUEPLACE='" + CMACIDISSUEPLACE + '\'' +
                ", CMACIDCUSTIDCTRYOFISSUE='" + CMACIDCUSTIDCTRYOFISSUE + '\'' +
                '}';
    }
}
