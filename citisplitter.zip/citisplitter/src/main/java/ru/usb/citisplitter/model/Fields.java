package ru.usb.citisplitter.model;

import org.springframework.stereotype.Component;

@Component
public class Fields {

    private String name;
    private int start;
    private int end;
    private String typeField;

    public Fields() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public String getTypeField() {
        return typeField;
    }

    public void setTypeField(String typeField) {
        this.typeField = typeField;
    }

    @Override
    public String toString() {
        return "Fileds{" +
                "name='" + name + '\'' +
                ", start=" + start +
                ", end=" + end +
                ", typeField='" + typeField + '\'' +
                '}';
    }
}
