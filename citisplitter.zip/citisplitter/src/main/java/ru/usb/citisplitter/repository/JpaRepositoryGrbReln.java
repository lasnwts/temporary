package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.GRBRELN;

public interface JpaRepositoryGrbReln extends JpaRepository<GRBRELN, Long> {
}
