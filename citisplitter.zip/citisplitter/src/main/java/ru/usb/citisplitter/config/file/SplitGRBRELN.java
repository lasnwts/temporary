package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "grbreln")
public class SplitGRBRELN {

    private List<Fields> reln = new ArrayList<>();

    public List<Fields> getReln() {
        return reln;
    }

    public void setReln(List<Fields> reln) {
        this.reln = reln;
    }
}
