package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "custmisc")
public class SplitCUSTMISC {

    //misc
    private List<Fields> misc = new ArrayList<>();

    public List<Fields> getMisc() {
        return misc;
    }

    public void setMisc(List<Fields> misc) {
        this.misc = misc;
    }
}
