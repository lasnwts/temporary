package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "address")
public class SplitGRBADDRESS {

    private List<Fields> addr = new ArrayList<>();

    public SplitGRBADDRESS() {
    }

    public List<Fields> getAddr() {
        return addr;
    }

    public void setAddr(List<Fields> addr) {
        this.addr = addr;
    }
}
