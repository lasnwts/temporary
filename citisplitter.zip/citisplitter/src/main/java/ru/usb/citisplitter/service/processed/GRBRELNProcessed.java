package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitGRBRELN;
import ru.usb.citisplitter.model.AMUW1;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.model.GRBRELN;
import ru.usb.citisplitter.repository.JpaRepositoryGrbReln;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class GRBRELNProcessed {

    Logger logger = LoggerFactory.getLogger(GRBRELNProcessed.class);

    @Autowired
    SplitGRBRELN splitGRBRELN;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryGrbReln jpaRepositoryGrbReln;

    File file;

    String output_file = "GRBRELNProcessed.txt";


    /**
     * Базовая последовательность
     *
     * @param filePath
     * @param per
     * @param fName
     * @return
     * @throws IOException
     */
    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitGRBRELN.getReln().size() == 0) {
            logger.info("Пустой список splitGRBRELN");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    count.incrementAndGet();
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (count.get() > 1 && line.trim().length() > 70) {

                            GRBRELN grbreln = getNewGrbReln(line);
                            grbreln.setPER(per);
                            grbreln.setInputDate(new Date());
                            grbreln.setFILENAME(fName);
                            jpaRepositoryGrbReln.save(grbreln);

                            if (configure.isFileFlagCSV()) {
                                writer.write((count.get()) + ";" + grbreln.toString() + System.lineSeparator());
                            }

                            //Удаляем объект
                            grbreln = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект
     *
     * @param line
     * @return
     */
    private GRBRELN getNewGrbReln(String line) {

        GRBRELN grbreln = new GRBRELN();

        splitGRBRELN.getReln().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "CM_RELN_CUSTNUMB":
                        try {
                            grbreln.setCM_RELN_CUSTNUMB(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbreln.setCM_RELN_CUSTNUMB("");
                        }
                        break;
                    case "CM_RELN_ACCTNUMB":
                        try {
                            grbreln.setCM_RELN_ACCTNUMB(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbreln.setCM_RELN_ACCTNUMB("");
                        }
                        break;
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });
        return grbreln;
    }

}
