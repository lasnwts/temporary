package ru.usb.citisplitter.service;

import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
public class FileReader {

 //   String filePath = "C:\\AppServer\\Data\\Parking_Violations_Issued_-_Fiscal_Year_2015.csv";

    File file;

    public void readFiles(String filePath) {
        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();
        try (Stream<String> lines = Files.lines(Paths.get(filePath)).filter(s -> s.contains("HONDA"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.parallel().forEach(line -> {
                        try {
                            System.out.println(" # " + line + System.lineSeparator());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
    }


}
