package ru.usb.citisplitter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "tables")
public class ClientsConfig {

    private List<Fields> client = new ArrayList<>();

    public ClientsConfig() {
    }

    public List<Fields> getClient() {
        return client;
    }

    public void setClient(List<Fields> client) {
        this.client = client;
    }
}
