package ru.usb.citisplitter.utlis;

import org.springframework.stereotype.Component;

/**
 * Строковые утилиты
 */

@Component
public class StringsUtils {


    /**
     * Заменяем символ ; в строке на lineReplace ля формирования CSV файла
     * @param line
     * @param lineReplace
     * @return
     */
    public String getShield(String line, String lineReplace){
        return line.replace(";", lineReplace);
    }


}
