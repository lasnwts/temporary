package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitGRBMASTPER;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.model.GRBMASTPER;
import ru.usb.citisplitter.repository.JpaRepositoryGrbMaster;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class GRBMASTPERprocessed {

    Logger logger = LoggerFactory.getLogger(GRBMASTPERprocessed.class);

    @Autowired
    SplitGRBMASTPER splitGRBMASTPER;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryGrbMaster jpaRepositoryGrbMaster;


    File file;

    String output_file = "GRBMASTPER.txt";


    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitGRBMASTPER.getCustomer().size() == 0) {
            logger.info("Пустой список grbmastper");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        //Получаем объект
                        if (line.length() > 100) {
                            GRBMASTPER grbmastper = getNewGRBMASTPER(line);
                            grbmastper.setPER(per);
                            grbmastper.setInputDate(new Date());
                            grbmastper.setFILENAME(fName);
                            jpaRepositoryGrbMaster.save(grbmastper);
                            if (configure.isFileFlagCSV()) {
                                writer.write((count.incrementAndGet()) + ";" + grbmastper.toString() + System.lineSeparator());
                            }
                            //Удаляем объект
                            grbmastper = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект GRBMASTPER
     *
     * @param line
     * @return
     */
    private GRBMASTPER getNewGRBMASTPER(String line) {

        GRBMASTPER grbmastper = new GRBMASTPER();

        splitGRBMASTPER.getCustomer().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "CM_CUST_CUSTNUMB":
                        try {
                            grbmastper.setCM_CUST_CUSTNUMB("CITI_" + line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_CUSTNUMB("");
                        }
                        break;
                    case "CM_CUST_INDCORPNAME":
                        try {
                            grbmastper.setCM_CUST_INDCORPNAME(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_INDCORPNAME("");
                        }
                        break;
                    case "CM_SURNAME_PART":
                        try {
                            grbmastper.setCM_SURNAME_PART(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_SURNAME_PART("");
                        }
                        break;
                    case "CM_NAME_PART":
                        try {
                            grbmastper.setCM_NAME_PART(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_NAME_PART("");
                        }
                        break;
                    case "CM_FATHER_NAME":
                        try {
                            grbmastper.setCM_FATHER_NAME(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_FATHER_NAME("");
                        }
                        break;
                    case "CM_CUST_BIRTH_DATE":
                        try {
                            grbmastper.setCM_CUST_BIRTH_DATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd())));
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_BIRTH_DATE(parseDate.getDtf("19170101"));
                        }
                        break;
                    case "CM_BIRTH_PLACE":
                        try {
                            grbmastper.setCM_BIRTH_PLACE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_BIRTH_PLACE("");
                        }
                        break;
                    case "CM_BIRTH_CTRY":
                        try {
                            grbmastper.setCM_BIRTH_CTRY(getCM_BIRTH_CTRY(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_BIRTH_CTRY("RU");
                        }
                        break;
                    case "CM_CUST_TAX_ID":
                        try {
                            grbmastper.setCM_CUST_TAX_ID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_TAX_ID("");
                        }
                        break;
                    case "CM_CUST_SEX":
                        try {
                            grbmastper.setCM_CUST_SEX(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_SEX("");
                        }
                        break;
                    case "CM_CUST_MSSTAT":
                        try {
                            grbmastper.setCM_CUST_MSSTAT(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_MSSTAT("");
                        }
                        break;
                    case "CM_EDUC_TITLE":
                        try {
                            grbmastper.setCM_EDUC_TITLE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_EDUC_TITLE("");
                        }
                        break;
                        //16.11.2022
                    case "CM_CUST_EMAIL_ADDR_1":
                        try {
                            grbmastper.setCM_CUST_EMAIL_ADDR_1(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_EMAIL_ADDR_1("");
                        }
                        break;
                    case "CM_CUST_EMAIL_ADDR_2":
                        try {
                            grbmastper.setCM_CUST_EMAIL_ADDR_2(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_CUST_EMAIL_ADDR_2("");
                        }
                        break;
                    case "CM_RESIDENT_INDICATOR":
                        try {
                            grbmastper.setCM_RESIDENT_INDICATOR(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            grbmastper.setCM_RESIDENT_INDICATOR("");
                        }
                        break;

                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });

        return grbmastper;
    }


    /**
     * Обработка
     * CM_BIRTH_CTRY='', --Пока данных нет, у нас при пустом поле загрузка отваливается с ошибкой, придется заполнять, предварительно по умолчанию всем = "RU"
     *
     * @param line
     * @return
     */
    private String getCM_BIRTH_CTRY(String line) {
        if (line == null) {
            return "RU";
        }
        if (line.trim().isEmpty()) {
            return "RU";
        } else {
            return line;
        }
    }

    /**
     * Заголовок файла CSV
     *
     * @return
     */
    public String toCSVhead() {
        return "NUMSTR" + ';' +
                "CM_CUST_CUSTNUMB" + ';' +
                "CM_CUST_INDCORPNAME" + ';' +
                "CM_SURNAME_PART" + ';' +
                "CM_NAME_PART" + ';' +
                "CM_FATHER_NAME" + ';' +
                "CM_CUST_BIRTH_DATE" + ';' +
                "CM_BIRTH_PLACE" + ';' +
                "CM_BIRTH_CTRY" + ';' +
                "CM_CUST_TAX_ID" + ';' +
                "CM_CUST_SEX" + ';' +
                "CM_CUST_MSSTAT" + ';' +
                "CM_EDUC_TITLE";
    }

}
