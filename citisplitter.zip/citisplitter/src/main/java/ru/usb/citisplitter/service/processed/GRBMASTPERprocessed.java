package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitGRBMASTPER;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.model.GRBMASTPER;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class GRBMASTPERprocessed {

    Logger logger = LoggerFactory.getLogger(GRBMASTPERprocessed.class);

    @Autowired
    SplitGRBMASTPER splitGRBMASTPER;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;


    File file;

    String output_file = "GRBMASTPER.txt";


    public boolean readFiles(String filePath) throws IOException {

        if (splitGRBMASTPER.getCustomer().size() == 0) {
            logger.info("Пустой список grbmastper");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    try {
                        System.out.println(" # " + line);
                        // writer.write((count.incrementAndGet()) + " # " + s.trim() + System.lineSeparator());
                        if (line.trim().length() > 1000) {
                            //logger.info(getNewGRBMASTPER(line).toString());
                            if (configure.isFileFlagCSV()) {
                                // writer.write((count.incrementAndGet()) + ";" + getNewGRBMASTPER(line).toCSV() + System.lineSeparator());
                                writer.write((count.incrementAndGet()) + ";" + getNewGRBMASTPER(line).toString() + System.lineSeparator());
                            }
                        } else {
                            if (configure.isFileFlagCSV()) {
                                if (count.get() < 2) {
                                    writer.write(toCSVhead() + System.lineSeparator());
                                }
                            }
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        }
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект GRBMASTPER
     *
     * @param line
     * @return
     */
    private GRBMASTPER getNewGRBMASTPER(String line) {

        GRBMASTPER grbmastper = new GRBMASTPER();

        splitGRBMASTPER.getCustomer().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "CM_CUST_CUSTNUMB":
                        grbmastper.setCM_CUST_CUSTNUMB("CITI_" + line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_CUST_INDCORPNAME":
                        try {
                            grbmastper.setCM_CUST_INDCORPNAME(withFiles.getUTF(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (UnsupportedEncodingException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                    case "CM_SURNAME_PART":
                        grbmastper.setCM_SURNAME_PART(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_NAME_PART":
                        grbmastper.setCM_NAME_PART(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_FATHER_NAME":
                        grbmastper.setCM_FATHER_NAME(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_CUST_BIRTH_DATE":
                        grbmastper.setCM_CUST_BIRTH_DATE(parseDate.getDtf(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd())));
                        break;
                    case "CM_BIRTH_PLACE":
                        grbmastper.setCM_BIRTH_PLACE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_BIRTH_CTRY":
                        grbmastper.setCM_BIRTH_CTRY(getCM_BIRTH_CTRY(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        break;
                    case "CM_CUST_TAX_ID":
                        grbmastper.setCM_CUST_TAX_ID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_CUST_SEX":
                        grbmastper.setCM_CUST_TAX_ID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_CUST_MSSTAT":
                        grbmastper.setCM_CUST_TAX_ID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    case "CM_EDUC_TITLE":
                        grbmastper.setCM_CUST_TAX_ID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        break;
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });

        return grbmastper;
    }


    /**
     * Обработка
     * CM_BIRTH_CTRY='', --Пока данных нет, у нас при пустом поле загрузка отваливается с ошибкой, придется заполнять, предварительно по умолчанию всем = "RU"
     *
     * @param line
     * @return
     */
    private String getCM_BIRTH_CTRY(String line) {
        if (line == null) {
            return "RU";
        }
        if (line.trim().isEmpty()) {
            return "RU";
        } else {
            return line;
        }
    }

    /**
     * Заголовок файла CSV
     *
     * @return
     */
    public String toCSVhead() {
        return "NUMSTR" + ';' +
                "CM_CUST_CUSTNUMB" + ';' +
                "CM_CUST_INDCORPNAME" + ';' +
                "CM_SURNAME_PART" + ';' +
                "CM_NAME_PART" + ';' +
                "CM_FATHER_NAME" + ';' +
                "CM_CUST_BIRTH_DATE" + ';' +
                "CM_BIRTH_PLACE" + ';' +
                "CM_BIRTH_CTRY" + ';' +
                "CM_CUST_TAX_ID" + ';' +
                "CM_CUST_SEX" + ';' +
                "CM_CUST_MSSTAT" + ';' +
                "CM_EDUC_TITLE";
    }

}
