package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "custempl")
public class SplitCUSTEMPL {

    private List<Fields> cust = new ArrayList<>();

    public List<Fields> getCust() {
        return cust;
    }

    public void setCust(List<Fields> cust) {
        this.cust = cust;
    }
}
