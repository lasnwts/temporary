package ru.usb.citisplitter.config.file;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "amuw1")
public class SplitAMUW1 {

    private List<Fields> muw1 = new ArrayList<>();

    public List<Fields> getMuw1() {
        return muw1;
    }

    public void setMuw1(List<Fields> muw1) {
        this.muw1 = muw1;
    }
}
