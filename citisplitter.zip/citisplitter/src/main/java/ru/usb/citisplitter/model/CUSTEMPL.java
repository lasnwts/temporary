package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

/**
 * Дата начала работы
 * Имя работодателя
 * CM-EMPL-START-DT
 * CM-EMPR-NAME
 */
@Entity
public class CUSTEMPL {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    private LocalDate CMEMPLSTARTDT;
    private String CMEMPRNAME;

    //18112022 CM-CUST-NUMB
    private String CMCUSTNUMB;


    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;



    public CUSTEMPL() {
    }


    public CUSTEMPL(long id, LocalDate CMEMPLSTARTDT, String CMEMPRNAME, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CMEMPLSTARTDT = CMEMPLSTARTDT;
        this.CMEMPRNAME = CMEMPRNAME;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public CUSTEMPL(long id, LocalDate CMEMPLSTARTDT, String CMEMPRNAME, String CMCUSTNUMB, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CMEMPLSTARTDT = CMEMPLSTARTDT;
        this.CMEMPRNAME = CMEMPRNAME;
        this.CMCUSTNUMB = CMCUSTNUMB;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public String getCMCUSTNUMB() {
        return CMCUSTNUMB;
    }

    public void setCMCUSTNUMB(String CMCUSTNUMB) {
        this.CMCUSTNUMB = CMCUSTNUMB;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getCMEMPLSTARTDT() {
        return CMEMPLSTARTDT;
    }

    public void setCMEMPLSTARTDT(LocalDate CMEMPLSTARTDT) {
        this.CMEMPLSTARTDT = CMEMPLSTARTDT;
    }

    public String getCMEMPRNAME() {
        return CMEMPRNAME;
    }

    public void setCMEMPRNAME(String CMEMPRNAME) {
        this.CMEMPRNAME = CMEMPRNAME;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "CUSTEMPL{" +
                "id=" + id +
                ", CMEMPLSTARTDT=" + CMEMPLSTARTDT +
                ", CMEMPRNAME='" + CMEMPRNAME + '\'' +
                ", CMCUSTNUMB='" + CMCUSTNUMB + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
