package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
public class AMUWG {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //AMXTDWUG-RT-ACCT-NUM
    private String AMXTDWUGRTACCTNUM;

    //20.11.2022
    //AMXTDWUG-ZA-MEMO-NOTE
    private String AMXTDWUGZAMEMONOTE;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public AMUWG() {
    }

    public AMUWG(long id, String AMXTDWUGRTACCTNUM, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWUGRTACCTNUM = AMXTDWUGRTACCTNUM;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public AMUWG(long id, String AMXTDWUGRTACCTNUM, String AMXTDWUGZAMEMONOTE, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.AMXTDWUGRTACCTNUM = AMXTDWUGRTACCTNUM;
        this.AMXTDWUGZAMEMONOTE = AMXTDWUGZAMEMONOTE;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAMXTDWUGRTACCTNUM() {
        return AMXTDWUGRTACCTNUM;
    }

    public void setAMXTDWUGRTACCTNUM(String AMXTDWUGRTACCTNUM) {
        this.AMXTDWUGRTACCTNUM = AMXTDWUGRTACCTNUM;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getAMXTDWUGZAMEMONOTE() {
        return AMXTDWUGZAMEMONOTE;
    }

    public void setAMXTDWUGZAMEMONOTE(String AMXTDWUGZAMEMONOTE) {
        this.AMXTDWUGZAMEMONOTE = AMXTDWUGZAMEMONOTE;
    }

    @Override
    public String toString() {
        return "AMUWG{" +
                "id=" + id +
                ", AMXTDWUGRTACCTNUM='" + AMXTDWUGRTACCTNUM + '\'' +
                ", AMXTDWUGZAMEMONOTE='" + AMXTDWUGZAMEMONOTE + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
