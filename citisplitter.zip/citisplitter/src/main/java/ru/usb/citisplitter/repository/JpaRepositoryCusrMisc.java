package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.CUSTMISC;

public interface JpaRepositoryCusrMisc  extends JpaRepository<CUSTMISC, Long> {
}
