package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * GRBTEL для телефонов
 * связь по полю CM-CUST-TEL-CUSTNO (id клиента) - 9 символов, позиция со 2 по 10
 * <p>
 * GRBMAST для e-mail
 */
@Entity
public class GRBTEL {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    /**
     * CM-CUST-TEL-NBR
     * CM-CUST-TEL-TYPE
     */
    //CM-CUST-TEL-NBR
    //Line Number
    private String CMCUSTTELNBR;

    //CM-CUST-TEL-TYPE
    //Telephone Type
    private String CMCUSTTELTYPE;

    //CM-CUST-TEL-CUSTNO
    private String CMCUSTTELCUSTNO;

    /**
     * 24.11.2022
     * CM-CUST-TEL-AREA-CODE	CHAR	6	32	37  Код города
     */

    //CM-CUST-TEL-AREA-CODE
    private String CMCUSTTELAREACODE;

    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;


    public GRBTEL() {
    }


    public GRBTEL(String CMCUSTTELNBR, String CMCUSTTELTYPE, String PER, Date inputDate, String FILENAME) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public GRBTEL(long id, String CMCUSTTELNBR, String CMCUSTTELTYPE, String CMCUSTTELCUSTNO, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.CMCUSTTELNBR = CMCUSTTELNBR;
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
        this.CMCUSTTELCUSTNO = CMCUSTTELCUSTNO;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public String getCMCUSTTELNBR() {
        return CMCUSTTELNBR;
    }

    public void setCMCUSTTELNBR(String CMCUSTTELNBR) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
    }

    public String getCMCUSTTELTYPE() {
        return CMCUSTTELTYPE;
    }

    public void setCMCUSTTELTYPE(String CMCUSTTELTYPE) {
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    public String getCMCUSTTELCUSTNO() {
        return CMCUSTTELCUSTNO;
    }

    public void setCMCUSTTELCUSTNO(String CMCUSTTELCUSTNO) {
        this.CMCUSTTELCUSTNO = CMCUSTTELCUSTNO;
    }

    public String getCMCUSTTELAREACODE() {
        return CMCUSTTELAREACODE;
    }

    public void setCMCUSTTELAREACODE(String CMCUSTTELAREACODE) {
        this.CMCUSTTELAREACODE = CMCUSTTELAREACODE;
    }

    @Override
    public String toString() {
        return "GRBTEL{" +
                "id=" + id +
                ", CMCUSTTELNBR='" + CMCUSTTELNBR + '\'' +
                ", CMCUSTTELTYPE='" + CMCUSTTELTYPE + '\'' +
                ", CMCUSTTELCUSTNO='" + CMCUSTTELCUSTNO + '\'' +
                ", CMCUSTTELAREACODE='" + CMCUSTTELAREACODE + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
