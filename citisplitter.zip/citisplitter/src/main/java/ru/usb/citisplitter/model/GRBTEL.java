package ru.usb.citisplitter.model;

/**
 * GRBTEL для телефонов
 * связь по полю CM-CUST-TEL-CUSTNO (id клиента) - 9 символов, позиция со 2 по 10
 *
 * GRBMAST для e-mail
 */
public class GRBTEL {

    //CM-CUST-TEL-NBR
    //Line Number
    private String CMCUSTTELNBR;

    //CM-CUST-TEL-TYPE
    //Telephone Type
    private String CMCUSTTELTYPE;

    //Customer's Email Address 1
    private String CM_CUST_EMAIL_ADDR_1;

    //CM_CUST_EMAIL_ADDR_2
    //Customer's Email Address 2
    private String CM_CUST_EMAIL_ADDR_2;


    public GRBTEL() {
    }

    public GRBTEL(String CMCUSTTELNBR, String CMCUSTTELTYPE, String CM_CUST_EMAIL_ADDR_1, String CM_CUST_EMAIL_ADDR_2) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
        this.CM_CUST_EMAIL_ADDR_1 = CM_CUST_EMAIL_ADDR_1;
        this.CM_CUST_EMAIL_ADDR_2 = CM_CUST_EMAIL_ADDR_2;
    }

    public String getCMCUSTTELNBR() {
        return CMCUSTTELNBR;
    }

    public void setCMCUSTTELNBR(String CMCUSTTELNBR) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
    }

    public String getCMCUSTTELTYPE() {
        return CMCUSTTELTYPE;
    }

    public void setCMCUSTTELTYPE(String CMCUSTTELTYPE) {
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
    }

    public String getCM_CUST_EMAIL_ADDR_1() {
        return CM_CUST_EMAIL_ADDR_1;
    }

    public void setCM_CUST_EMAIL_ADDR_1(String CM_CUST_EMAIL_ADDR_1) {
        this.CM_CUST_EMAIL_ADDR_1 = CM_CUST_EMAIL_ADDR_1;
    }

    public String getCM_CUST_EMAIL_ADDR_2() {
        return CM_CUST_EMAIL_ADDR_2;
    }

    public void setCM_CUST_EMAIL_ADDR_2(String CM_CUST_EMAIL_ADDR_2) {
        this.CM_CUST_EMAIL_ADDR_2 = CM_CUST_EMAIL_ADDR_2;
    }

    @Override
    public String toString() {
        return "GRBTEL{" +
                "CMCUSTTELNBR='" + CMCUSTTELNBR + '\'' +
                ", CMCUSTTELTYPE='" + CMCUSTTELTYPE + '\'' +
                ", CM_CUST_EMAIL_ADDR_1='" + CM_CUST_EMAIL_ADDR_1 + '\'' +
                ", CM_CUST_EMAIL_ADDR_2='" + CM_CUST_EMAIL_ADDR_2 + '\'' +
                '}';
    }
}
