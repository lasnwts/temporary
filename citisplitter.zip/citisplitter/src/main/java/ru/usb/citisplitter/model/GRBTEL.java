package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * GRBTEL для телефонов
 * связь по полю CM-CUST-TEL-CUSTNO (id клиента) - 9 символов, позиция со 2 по 10
 *
 * GRBMAST для e-mail
 */
@Entity
public class GRBTEL {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    /**
     * CM-CUST-TEL-NBR
     * CM-CUST-TEL-TYPE
     */
    //CM-CUST-TEL-NBR
    //Line Number
    private String CMCUSTTELNBR;

    //CM-CUST-TEL-TYPE
    //Telephone Type
    private String CMCUSTTELTYPE;


    //Customer's Email Address 1
//    private String CM_CUST_EMAIL_ADDR_1;

    //CM_CUST_EMAIL_ADDR_2
    //Customer's Email Address 2
//    private String CM_CUST_EMAIL_ADDR_2;


    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;


    public GRBTEL() {
    }


    public GRBTEL(String CMCUSTTELNBR, String CMCUSTTELTYPE, String PER, Date inputDate, String FILENAME) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public String getCMCUSTTELNBR() {
        return CMCUSTTELNBR;
    }

    public void setCMCUSTTELNBR(String CMCUSTTELNBR) {
        this.CMCUSTTELNBR = CMCUSTTELNBR;
    }

    public String getCMCUSTTELTYPE() {
        return CMCUSTTELTYPE;
    }

    public void setCMCUSTTELTYPE(String CMCUSTTELTYPE) {
        this.CMCUSTTELTYPE = CMCUSTTELTYPE;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }

    @Override
    public String toString() {
        return "GRBTEL{" +
                "id=" + id +
                ", CMCUSTTELNBR='" + CMCUSTTELNBR + '\'' +
                ", CMCUSTTELTYPE='" + CMCUSTTELTYPE + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
