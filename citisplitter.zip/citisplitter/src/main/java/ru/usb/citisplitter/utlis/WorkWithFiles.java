package ru.usb.citisplitter.utlis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.service.EmailServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class WorkWithFiles {

    @Autowired
    Configure configure;

    @Autowired
    EmailServiceImpl emailService;

    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.info("Directory :: [" + targetPath + "] Not Exist! Fail!");
        return false;
    }


    /**
     * Получаем список файлов в директории
     *
     * @param directory
     * @return
     */
    public List<File> getDirList(String directory) {

        if (!checkPathExists(directory)) {
            logger.error("WorkWithFiles:GetDirListFiles::Error! Directory not exists! ::" + directory);
            return null;
        }

        // Reading only files in the directory
        try {
            List<File> files = Files.list(Paths.get(directory))
                    .map(Path::toFile)
                    .filter(File::isFile)
                    .collect(Collectors.toList());
            files.forEach(System.out::println);
            return files;
        } catch (IOException e) {
            logger.error("PrintStackTrace:Не удалось получить список файлов в директории::{}", e);
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Не удалось получить список файлов в директории::" + directory + ", возникла ошибка::" + e.getMessage());
            return null;
        }

    }

    /**
     * Метод проверки и создания директорий при необходимости
     *
     * @param pathDirectory - строка с полным путем для директорий
     * @return - true : директория создана или существует, false : директория не создана
     */
    public boolean createdDirectory(String pathDirectory) {

        if (pathDirectory == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Error try created directory, parameters with name [pathDirectory]=NULL!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return false;
        }

        Path path = Paths.get(pathDirectory);

        if (!Files.exists(path)) {
            try {
                Files.createDirectory(path);
                logger.info("Directory created::{}", path.toString());
                return true;
            } catch (IOException e) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("Error try created directory!!!::{} ", path.toString());
                logger.error("Stack", e.getMessage());
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Error try created directory!!!::" + path.toString() + " Error::" + e.getMessage());
                return false;
            }
        } else {
//            System.out.println("Directory" + path.toString() + " = already exists");
            return true;
        }
    }

    /**
     * Удаление файла, представленных  строковым именем
     *
     * @param fromFile - полное имя файла, который надо удалить
     */
    public boolean delFilesSName(String fromFile) {
        Path from = Paths.get(fromFile);
        try {
            logger.info("Try delete file:" + fromFile);
            Files.deleteIfExists(from);
            logger.info("File:" + from.toString() + " delete successfully.");
            return true;
        } catch (IOException e) {
            logger.error("PrintStackTrace::delete file:{} error::{}", fromFile, e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "delete file:{} error:" + fromFile + " error:" + e.getMessage());
            return false;
        }
    }

    /**
     * Проверка возможности работы с файлом, что он не заблокирован записью
     *
     * @param file
     * @return
     */

    public boolean isFilelocked(File file) {
        try {

            FileInputStream in = new FileInputStream(file);
            in.close();
            return false;
        } catch (FileNotFoundException e) {
            if (file.exists()) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Проверка того, что файл:{} заблокирован другим процессом, ошибка:{}", file.getAbsolutePath(), e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Ошибка во время проверки того, что файл:" + file.getAbsolutePath() + " заблокирован другим процессом, ошибка:" + e.getMessage());
        }

        return false;
    }

    /**
     * Удаление файла, представленных подготовленными объектами Paths(nio)
     *
     * @param from что удалить
     */
    public void delFiles(Path from) {
        try {
            Files.deleteIfExists(from);
        } catch (IOException e) {
            logger.error("!ERROR!PrintStackTrace:Удаление файла:{}, представленных подготовленными объектами Paths(nio):{}", from.toString(), e.getMessage());
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Ошибка при удалении файла:" + from.toString() + ", ошибка:" + e.getMessage());
        }
    }


    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param toFile   - куда (полный путь с именем)
     */
    public void moveFileSName(String fromFile, String toFile) {
        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile);
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toString())) {
                Files.deleteIfExists(from);
                logger.info("file:: " + from + " moved to:" + to);
            } else {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("Error for operation move:: file:: " + from + " moved to:" + to);
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Error for operation move:: file:: " + from + " moved to:" + to);
            }
        } catch (IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::", e);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Error for operation move:: file:: " + from + " moved to:" + to + ", error: " + e.getMessage());
        }
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameFull) {
        Path path = Paths.get(fileNameFull);
        if (Files.exists(path)) {
            // действия, если файл существует
//            logger.info("File :: [" + fileNameShort + "] exist.Ok.");
            return true;
        }
        logger.info("File :: [" + fileNameFull + "] not Exist.Fail!");
        return false;
    }


    /**
     * Проверка того что в имени файла есть пробелы.
     *
     * @param fileNameShort - имя файла
     * @return - true - пробелов нет, false - есть пробелы
     */
    public boolean checkFileName(String fileNameShort) {
        if (fileNameShort.contains(" ")) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * Возвращаем только имя файла без расширения
     *
     * @param filename - переменная типа File
     * @return - имя файла строка
     */
    public String getFileNameWithoutExt(File filename) {
        return filename.getName().replaceFirst("[.][^.]+$", "");
    }


    /**
     * для получения реальной позиции в файле.
     *
     * @param i
     * @return
     */
    public int getPos(int i) {
        return i - 1;
    }


}
