package ru.usb.citisplitter.service.processed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.config.file.SplitCUSTID;
import ru.usb.citisplitter.model.CUSTID;
import ru.usb.citisplitter.model.Fields;
import ru.usb.citisplitter.repository.JpaRepositoryCustId;
import ru.usb.citisplitter.utlis.ParseDate;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class CUSTIDProcessed {

    Logger logger = LoggerFactory.getLogger(CUSTIDProcessed.class);

    @Autowired
    SplitCUSTID splitCUSTID;

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    ParseDate parseDate;

    @Autowired
    Configure configure;

    @Autowired
    JpaRepositoryCustId jpaRepositoryCustId;

    File file;

    String output_file = "CUSTID_PER.txt";


    public boolean readFiles(String filePath, String per, String fName) throws IOException {

        if (splitCUSTID.getCust().size() == 0) {
            logger.info("Пустой список splitCUSTID");
            return false;
        }

        /**
         * Если нужен вывод в csv
         */
        //Вторая часть, здесь реализован несколько другой метод чтения больших файлов
        FileWriter writer = new FileWriter(configure.getFileCsvDirectory() + FileSystems.getDefault().getSeparator() + output_file, Charset.forName("Cp866"));


        file = new File(filePath);
        if (file.exists()) {
            System.out.println("File [" + file.getName() + "] - exist.");
        } else {
            System.out.println("Not exist! > File [" + file.getName() + "]...");
            return false;
        }
        System.out.println("Размер файла ::" + file.length());
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();

        startTime = System.currentTimeMillis();

        try (Stream<String> lines = Files.lines(Paths.get(filePath), Charset.forName("Cp866"))) {
            final AtomicInteger count = new AtomicInteger();
            lines.forEach(new Consumer<String>() {
                @Override
                public void accept(String line) {
                    count.incrementAndGet();
                    try {
                        if (configure.isFileOriginalLineShow()) {
                            System.out.println(" # " + line);
                        }
                        if (count.get() > 1 && line.trim().length() > 79) {

                            CUSTID custid = getNewCUSTID(line);
                            custid.setPER(per);
                            custid.setInputDate(new Date());
                            custid.setFILENAME(fName);

                            jpaRepositoryCustId.save(custid);

                            if (configure.isFileFlagCSV()) {
                                writer.write((count.get()) + ";" + custid.toString() + System.lineSeparator());
                            }

                            //Удаляем объект
                            custid = null;
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            writer.write("");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return false;
        }
        System.gc();
        endTime = System.currentTimeMillis();
        System.out.print(" Время прошедшее с начала работы в сек :: ");
        System.out.println((endTime - startTime) / 1000);
        return true;
    }


    /**
     * Получаем объект CUSTID
     *
     * @param line
     * @return
     */
    private CUSTID getNewCUSTID(String line) {

        CUSTID custid = new CUSTID();

        splitCUSTID.getCust().forEach(new Consumer<Fields>() {
            @Override
            public void accept(Fields fields) {
                switch (fields.getName()) {
                    case "CM-ACID-ISSUE-DATE":
                        try {
                            custid.setCMACIDISSUEDATE(parseDate.getDtf2(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
//                            custid.setCMACIDISSUEDATE(parseDate.getDtf2("1917-01-01"));
                        }
                        break;
                    case "CM-ACID-EXPIRY-DATE":
                        try {
                            custid.setCMACIDEXPIRYDATE(parseDate.getDtf2(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim()));
                        } catch (StringIndexOutOfBoundsException e) {
//                            custid.setCMACIDEXPIRYDATE(parseDate.getDtf2("1917-01-01"));
                        }
                        break;
                    case "CM-ACID-CUST-ID-CD":
                        try {
                            custid.setCMACIDCUSTIDCD(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDCUSTIDCD("");
                        }
                        break;
                    case "CM-ACID-CUST-ID":
                        try {
                            custid.setCMACIDCUSTID(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDCUSTID("");
                        }
                        break;
                    case "CM-ACID-CUST-ID-TYP":
                        try {
                            custid.setCMACIDCUSTIDTYP(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDCUSTIDTYP("");
                        }
                        break;
                    case "CM-ACID-ISSUE-AUTH":
                        try {
                            custid.setCMACIDISSUEAUTH(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDISSUEAUTH("");
                        }
                        break;
                    case "CM-ACID-ISSUE-PLACE":
                        try {
                            custid.setCMACIDISSUEPLACE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDISSUEPLACE("");
                        }
                        break;
                    case "CM-ACID-CUST-ID-CTRY-OF-ISSUE":
                        try {
                            custid.setCMACIDCUSTIDCTRYOFISSUE(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDCUSTIDCTRYOFISSUE("");
                        }
                        break;
                    case "CM-ACID-CUST-NBR":
                        try {
                            custid.setCMACIDCUSTNBR(line.substring(withFiles.getPos(fields.getStart()), fields.getEnd()).trim());
                        } catch (StringIndexOutOfBoundsException e) {
                            custid.setCMACIDCUSTNBR("");
                        }
                        break;
                    default:
                        logger.error("Произошла ошибка, нужно остановить программу!");
                        break;
                }


            }
        });

        return custid;
    }


}
