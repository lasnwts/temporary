package ru.usb.citisplitter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.usb.citisplitter.model.AMUW2;

public interface JpaRepositoryAmuw2 extends JpaRepository<AMUW2, Long> {
}
