package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "grbtel")
public class SplitGRBTEL {
    //tel
    private List<Fields> tel = new ArrayList<>();

    public List<Fields> getTel() {
        return tel;
    }

    public void setTel(List<Fields> tel) {
        this.tel = tel;
    }
}
