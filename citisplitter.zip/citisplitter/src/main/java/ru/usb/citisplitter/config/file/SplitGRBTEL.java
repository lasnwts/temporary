package ru.usb.citisplitter.config.file;

public class SplitGRBTEL {
}
