package ru.usb.citisplitter.config.file;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "amuwg")
public class SplitAMUWG {

    private List<Fields> muwg = new ArrayList<>();

    public List<Fields> getMuwg() {
        return muwg;
    }

    public void setMuwg(List<Fields> muwg) {
        this.muwg = muwg;
    }
}
