package ru.usb.citisplitter.config.file;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.usb.citisplitter.model.Fields;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "amuw2")
public class SplitAMUW2 {

    private List<Fields> muw2 = new ArrayList<>();

    public List<Fields> getMuw2() {
        return muw2;
    }

    public void setMuw2(List<Fields> muw2) {
        this.muw2 = muw2;
    }
}
