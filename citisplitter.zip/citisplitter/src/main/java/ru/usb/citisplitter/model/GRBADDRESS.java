package ru.usb.citisplitter.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * ADDRESS
 * связь по полю DWHADDR-NUMBER (id клиента) - 9 символов, позиция с 9 по 17
 * DWHADDR-TYPE-CODE - y
 * DWHADDR-CTRY-DESC     -y
 * <p>
 * DWHADDR-LINE2
 * DWHADDR-STATE
 * DWHADDR-TOWNCITY-DESC
 * DWHADDR-LINE4
 * DWHADDR-LINE6  -y
 * DWHADDR-LINE7 -y
 * DWHADDR-ESTBDATE -y
 * <p>
 * DWHADDR-POST-CODE -y
 */
@Entity
public class GRBADDRESS {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    //DWHADDR-TYPE-CODE
    private String DWHADDRTYPECODE;

    //DWHADDR-TOWNCITY-DESC
    private String DWHADDRTOWNCITYDESC;

    //DWHADDR-LINE6
    private String DWHADDRLINE6;

    //DWHADDR-LINE7
    private String DWHADDRLINE7;

    //DWHADDR-POST-CODE
    private String DWHADDRPOSTCODE;

    //DWHADDR-ESTBDATE
    private String DWHADDRESTBDATE;

    /**
     * DWHADDR-LINE2
     * DWHADDR-STATE
     * DWHADDR-CTRY-DESC
     * DWHADDR-LINE4
     */

    private String DWHADDRLINE2;
    private String DWHADDRSTATE;
    private String DWHADDRCTRYDESC;
    private String DWHADDRLINE4;

    //18-11-2022 DWHADDR-NUMBER
    private String DWHADDRNUMBER;

    /**
     * 24.11.2022
     * 	ADDRESS	DWHADDR-LINE3         	CHAR	40	196	235	Адресная строка 3
     * 	ADDRESS	DWHADDR-LINE5         	CHAR	40	276	315	Адресная строка 5
     */

    //DWHADDR-LINE3
    private String DWHADDRLINE3;

    //DWHADDR-LINE5
    private String DWHADDRLINE5;


    //Признак таблицы
    private String PER;

    //Дата вставки записи в таблицу
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputDate;

    //Имя файла
    private String FILENAME;

    public GRBADDRESS() {
    }


    public GRBADDRESS(long id, String DWHADDRTYPECODE, String DWHADDRTOWNCITYDESC, String DWHADDRLINE6,
                      String DWHADDRLINE7, String DWHADDRPOSTCODE, String DWHADDRESTBDATE, String DWHADDRLINE2,
                      String DWHADDRSTATE, String DWHADDRCTRYDESC, String DWHADDRLINE4, String DWHADDRNUMBER,
                      String DWHADDRLINE3, String DWHADDRLINE5, String PER, Date inputDate, String FILENAME) {
        this.id = id;
        this.DWHADDRTYPECODE = DWHADDRTYPECODE;
        this.DWHADDRTOWNCITYDESC = DWHADDRTOWNCITYDESC;
        this.DWHADDRLINE6 = DWHADDRLINE6;
        this.DWHADDRLINE7 = DWHADDRLINE7;
        this.DWHADDRPOSTCODE = DWHADDRPOSTCODE;
        this.DWHADDRESTBDATE = DWHADDRESTBDATE;
        this.DWHADDRLINE2 = DWHADDRLINE2;
        this.DWHADDRSTATE = DWHADDRSTATE;
        this.DWHADDRCTRYDESC = DWHADDRCTRYDESC;
        this.DWHADDRLINE4 = DWHADDRLINE4;
        this.DWHADDRNUMBER = DWHADDRNUMBER;
        this.DWHADDRLINE3 = DWHADDRLINE3;
        this.DWHADDRLINE5 = DWHADDRLINE5;
        this.PER = PER;
        this.inputDate = inputDate;
        this.FILENAME = FILENAME;
    }

    public String getDWHADDRTYPECODE() {
        return DWHADDRTYPECODE;
    }

    public void setDWHADDRTYPECODE(String DWHADDRTYPECODE) {
        this.DWHADDRTYPECODE = DWHADDRTYPECODE;
    }

    public String getDWHADDRTOWNCITYDESC() {
        return DWHADDRTOWNCITYDESC;
    }

    public void setDWHADDRTOWNCITYDESC(String DWHADDRTOWNCITYDESC) {
        this.DWHADDRTOWNCITYDESC = DWHADDRTOWNCITYDESC;
    }

    public String getDWHADDRLINE6() {
        return DWHADDRLINE6;
    }

    public void setDWHADDRLINE6(String DWHADDRLINE6) {
        this.DWHADDRLINE6 = DWHADDRLINE6;
    }

    public String getDWHADDRLINE7() {
        return DWHADDRLINE7;
    }

    public void setDWHADDRLINE7(String DWHADDRLINE7) {
        this.DWHADDRLINE7 = DWHADDRLINE7;
    }

    public String getDWHADDRPOSTCODE() {
        return DWHADDRPOSTCODE;
    }

    public void setDWHADDRPOSTCODE(String DWHADDRPOSTCODE) {
        this.DWHADDRPOSTCODE = DWHADDRPOSTCODE;
    }

    public String getDWHADDRESTBDATE() {
        return DWHADDRESTBDATE;
    }

    public void setDWHADDRESTBDATE(String DWHADDRESTBDATE) {
        this.DWHADDRESTBDATE = DWHADDRESTBDATE;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPER() {
        return PER;
    }

    public void setPER(String PER) {
        this.PER = PER;
    }

    public Date getInputDate() {
        return inputDate;
    }

    public void setInputDate(Date inputDate) {
        this.inputDate = inputDate;
    }

    public String getFILENAME() {
        return FILENAME;
    }

    public void setFILENAME(String FILENAME) {
        this.FILENAME = FILENAME;
    }


    public String getDWHADDRLINE2() {
        return DWHADDRLINE2;
    }

    public void setDWHADDRLINE2(String DWHADDRLINE2) {
        this.DWHADDRLINE2 = DWHADDRLINE2;
    }

    public String getDWHADDRSTATE() {
        return DWHADDRSTATE;
    }

    public void setDWHADDRSTATE(String DWHADDRSTATE) {
        this.DWHADDRSTATE = DWHADDRSTATE;
    }

    public String getDWHADDRCTRYDESC() {
        return DWHADDRCTRYDESC;
    }

    public void setDWHADDRCTRYDESC(String DWHADDRCTRYDESC) {
        this.DWHADDRCTRYDESC = DWHADDRCTRYDESC;
    }

    public String getDWHADDRLINE4() {
        return DWHADDRLINE4;
    }

    public void setDWHADDRLINE4(String DWHADDRLINE4) {
        this.DWHADDRLINE4 = DWHADDRLINE4;
    }

    public String getDWHADDRNUMBER() {
        return DWHADDRNUMBER;
    }

    public void setDWHADDRNUMBER(String DWHADDRNUMBER) {
        this.DWHADDRNUMBER = DWHADDRNUMBER;
    }

    public String getDWHADDRLINE3() {
        return DWHADDRLINE3;
    }

    public void setDWHADDRLINE3(String DWHADDRLINE3) {
        this.DWHADDRLINE3 = DWHADDRLINE3;
    }

    public String getDWHADDRLINE5() {
        return DWHADDRLINE5;
    }

    public void setDWHADDRLINE5(String DWHADDRLINE5) {
        this.DWHADDRLINE5 = DWHADDRLINE5;
    }

    @Override
    public String toString() {
        return "GRBADDRESS{" +
                "id=" + id +
                ", DWHADDRTYPECODE='" + DWHADDRTYPECODE + '\'' +
                ", DWHADDRTOWNCITYDESC='" + DWHADDRTOWNCITYDESC + '\'' +
                ", DWHADDRLINE6='" + DWHADDRLINE6 + '\'' +
                ", DWHADDRLINE7='" + DWHADDRLINE7 + '\'' +
                ", DWHADDRPOSTCODE='" + DWHADDRPOSTCODE + '\'' +
                ", DWHADDRESTBDATE='" + DWHADDRESTBDATE + '\'' +
                ", DWHADDRLINE2='" + DWHADDRLINE2 + '\'' +
                ", DWHADDRSTATE='" + DWHADDRSTATE + '\'' +
                ", DWHADDRCTRYDESC='" + DWHADDRCTRYDESC + '\'' +
                ", DWHADDRLINE4='" + DWHADDRLINE4 + '\'' +
                ", DWHADDRNUMBER='" + DWHADDRNUMBER + '\'' +
                ", DWHADDRLINE3='" + DWHADDRLINE3 + '\'' +
                ", DWHADDRLINE5='" + DWHADDRLINE5 + '\'' +
                ", PER='" + PER + '\'' +
                ", inputDate=" + inputDate +
                ", FILENAME='" + FILENAME + '\'' +
                '}';
    }
}
