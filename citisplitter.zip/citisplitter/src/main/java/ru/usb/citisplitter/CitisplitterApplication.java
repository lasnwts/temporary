package ru.usb.citisplitter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.service.ServProcessed;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

@SpringBootApplication
public class CitisplitterApplication implements CommandLineRunner {

    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    Configure configure;

    @Autowired
    ServProcessed servProcessed;


    Logger logger = LoggerFactory.getLogger(CitisplitterApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CitisplitterApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info("start");

        logger.info("stop");

    }

    /*
     * Sheduler 1. Первый шедулер
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob() {

        List<File> fileList = new ArrayList<>();

        /**
         * Запускаем сканирование каталога c файлами из СИТИ
         */
        fileList = withFiles.getDirList(configure.getFileDirectory());
        //Если файлы есть то отрабатываем по каждому файл
        if (fileList.size() > 0) {
            fileList.forEach(new Consumer<File>() {
                @Override
                public void accept(File file) {
                    if (file.getName().toUpperCase(Locale.ROOT).contains("GRBMAST.PER")){
                        logger.info("File GRBMAST.PER найден!");
                        servProcessed.serviceProcGRBMASTPER(file.getAbsolutePath());
                    }
                }
            });
        }


    }


}

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /*
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}
