package ru.usb.citisplitter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.service.processed.GRBMASTPERprocessed;

import java.io.IOException;

@Service
public class ServProcessed {

    @Autowired
    GRBMASTPERprocessed grbmastpeRprocessed;

    public void serviceProcGRBMASTPER(String filename) {
        try {
            grbmastpeRprocessed.readFiles(filename);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
