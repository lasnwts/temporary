package ru.usb.citisplitter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.config.Configure;
import ru.usb.citisplitter.service.processed.*;
import ru.usb.citisplitter.utlis.WorkWithFiles;

import java.io.IOException;
import java.nio.file.FileSystems;

@Service
public class ServProcessed {

    @Autowired
    Configure configure;
    @Autowired
    WorkWithFiles withFiles;

    @Autowired
    EmailServiceImpl emailService;

    /**
     * Processed..
     */
    @Autowired
    GRBMASTPERprocessed grbmastpeRprocessed;
    @Autowired
    CUSTIDProcessed custidProcessed;
    @Autowired
    GRBADDRESSProcessed grbaddressProcessed;

    @Autowired
    GRBTELProcessed grbtelProcessed;

    @Autowired
    CUSTEMPLProcessed custemplProcessed;


    /**
     * Запуск обработки файла GRBMAST
     *
     * @param filename
     */
    public void serviceProcGRBMASTPER(String filename, String per, String fName) {
        try {
            if (grbmastpeRprocessed.readFiles(filename, per, fName)) {
                withFiles.moveFileSName(filename, configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName);
            } else {
                withFiles.moveFileSName(filename, configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName);
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки CUSTID.PER
     *
     * @param filename
     */
    public void serviceProcCUSTID(String filename, String per, String fName) {
        try {
            if (custidProcessed.readFiles(filename, per, fName)) {
                withFiles.moveFileSName(filename, configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName);
            } else {
                withFiles.moveFileSName(filename, configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName);
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки GRBADDRESS
     *
     * @param filename
     */
    public void serviceProcGRBAddr(String filename, String per, String fName) {
        try {
            if (grbaddressProcessed.readFiles(filename, per, fName)) {
                withFiles.moveFileSName(filename, configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName);
            } else {
                withFiles.moveFileSName(filename, configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName);
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки GRBTEL
     *
     * @param filename
     */
    public void serviceProcGRBTEL(String filename, String per, String fName) {
        try {
            if (grbtelProcessed.readFiles(filename, per, fName)) {
                withFiles.moveFileSName(filename, configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName);
            } else {
                withFiles.moveFileSName(filename, configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName);
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки CUSTEMPL
     *
     * @param filename
     */
    public void serviceProcCUSTEMPL(String filename, String per, String fName) {
        try {
            if (custemplProcessed.readFiles(filename, per, fName)) {
                withFiles.moveFileSName(filename, configure.getFileMoveDirectory() + FileSystems.getDefault().getSeparator() + fName);
            } else {
                withFiles.moveFileSName(filename, configure.getFileErrDirectory() + FileSystems.getDefault().getSeparator() + fName);
                emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), "Возникла ошибка при обработке файла" + fName);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
