package ru.usb.citisplitter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.citisplitter.service.processed.CUSTIDProcessed;
import ru.usb.citisplitter.service.processed.GRBADDRESSProcessed;
import ru.usb.citisplitter.service.processed.GRBMASTPERprocessed;

import java.io.IOException;

@Service
public class ServProcessed {

    @Autowired
    GRBMASTPERprocessed grbmastpeRprocessed;
    @Autowired
    CUSTIDProcessed custidProcessed;

    @Autowired
    GRBADDRESSProcessed grbaddressProcessed;


    /**
     * Запуск обработки файла GRBMAST
     * @param filename
     */
    public void serviceProcGRBMASTPER(String filename) {
        try {
            grbmastpeRprocessed.readFiles(filename);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки CUSTID.PER
     * @param filename
     */
    public void serviceProcCUSTID(String filename) {
        try {
            custidProcessed.readFiles(filename);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Запуск обработки GRBADDRESS
     * @param filename
     */
    public void serviceProcGRBAddr(String filename) {
        try {
            grbaddressProcessed.readFiles(filename);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
