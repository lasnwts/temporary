package ru.usb.citisplitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitisplitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
