package ru.usb.filesoperations.service.files;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.filesoperations.configure.Configure;
import ru.usb.filesoperations.utils.WorkWithFiles;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Вы можете увидеть Java-документ ThreadPoolTaskExecutor :
 * Из документации Spring Framework.
 * Конфигурация по умолчанию — это основной пул размером 1 с неограниченным максимальным размером пула и неограниченной емкостью очереди.
 * Это примерно эквивалентно Executors.newSingleThreadExecutor() , использующему один поток для всех задач.
 * Установка для « queueCapacity » значения 0 имитирует Executors.newCachedThreadPool() с немедленным масштабированием потоков в пуле до потенциально очень большого числа.
 * Также рассмотрите возможность установки « maxPoolSize » в этот момент, а также, возможно, более высокого « corePoolSize »
 * (см. также режим масштабирования « allowCoreThreadTimeOut »).
 * *******************************************************************
 * Разница между тремя исполнителями:
 * *******************************************************************
 * newFixedThreadPool :
 * создает пул потоков, который повторно использует фиксированное количество потоков, работающих в общей неограниченной очереди.
 * В любой момент не более потоков nThreads будут активными задачами обработки. Если дополнительные задачи отправляются, когда все потоки активны,
 * они будут ждать в очереди, пока поток не станет доступен. Если какой-либо поток завершается из-за сбоя во время выполнения перед завершением работы,
 * его место займет новый, если это необходимо для выполнения последующих задач. Потоки в пуле будут существовать до тех пор, пока он не будет явно отключен.
 * =====================================================================
 * newSingleThreadExecutor :
 * Создает Executor, который использует один рабочий поток, работающий в неограниченной очереди.
 * (Однако обратите внимание, что если этот единственный поток завершается из-за сбоя во время выполнения до завершения работы,
 * его место займет новый, если это необходимо для выполнения последующих задач.) Задачи гарантированно выполняются последовательно,
 * и не более одной задачи будет активным. в любой момент времени. В отличие от эквивалента newFixedThreadPool(1),
 * возвращаемый исполнитель гарантированно не может быть переконфигурирован для использования дополнительных потоков.
 * =====================================================================
 * newCachedThreadPool :
 * создает пул потоков, который создает новые потоки по мере необходимости, но будет повторно использовать ранее созданные потоки,
 * когда они станут доступны. Эти пулы обычно улучшают производительность программ, выполняющих множество кратковременных асинхронных задач.
 * Вызовы выполнения будут повторно использовать ранее созданные потоки, если они доступны. Если существующий поток недоступен,
 * будет создан новый поток и добавлен в пул. Потоки, которые не использовались в течение шестидесяти секунд, завершаются и удаляются из кэша.
 * Таким образом, пул, который простаивает достаточно долго, не будет потреблять никаких ресурсов. Обратите внимание, что пулы со схожими свойствами,
 * но с разными деталями (например, параметрами тайм-аута) могут быть созданы с помощью конструкторов ThreadPoolExecutor.
 * =====================================================================
 */

@Service
public class Executors {
    private final Configure configure;
    private final WorkWithFiles wow;

    @Autowired
    public Executors(Configure configure, WorkWithFiles wow) {
        this.configure = configure;
        this.wow = wow;
    }

    /**
     * Первый вариант инициализации: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }

    Logger logger = LoggerFactory.getLogger(Executors.class);


    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService executorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(String fileFrom, String fileTo, boolean deleted) {
        configure.setThreads(configure.getThreads() + 1);
        logger.info("UsbLog:Запуск getTask(fileFrom={}, fileTo={}, deleted={}) потока...", fileFrom, fileTo, deleted);
        logger.info("UsbLog:Длина очереди задач={}", configure.getThreads());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, fileFrom, fileTo, deleted));
        } catch (Exception e) {
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", e);
            logger.error("UsbLog:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
        logger.info("UsbLog:Поток getTask(fileFrom={}, fileTo={}, deleted={}) завершен...", fileFrom, fileTo, deleted);
    }

    class MyThread implements Runnable {
        String pfileFromThread;
        String pfileToThread;
        boolean pdeleteThread;
        CountDownLatch latch;

        MyThread(CountDownLatch c, String fileFromThread, String fileToThread, boolean deleteThread) {
            latch = c;
            pfileFromThread = fileFromThread;
            pfileToThread = fileToThread;
            pdeleteThread = deleteThread;
            new Thread(this);
        }

        public void run() {
            logger.info("UsbLog:Запуск filePrecessing потока id={}", Thread.currentThread().getId());
            wow.filePrecessing(pfileFromThread, pfileToThread, pdeleteThread);
            logger.info("UsbLog:Поток filePrecessing завершен id={}", Thread.currentThread().getId());
            configure.setThreads(configure.getThreads() - 1);
            logger.info("UsbLog:Длина очереди задач={}", configure.getThreads());
        }
    }


}
