package ru.usb.filesoperations.service.files;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.filesoperations.configure.Configure;
import ru.usb.filesoperations.model.FileRoute;
import ru.usb.filesoperations.model.topiclist;
import ru.usb.filesoperations.service.mail.ServiceMailError;
import ru.usb.filesoperations.utils.WorkWithFiles;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class FilesProcessing {
    private final FileRoute fileRoute;
    private final WorkWithFiles wow;
    private final Configure configure;
    private final Executors executors;

    @Autowired
    public FilesProcessing(FileRoute fileRoute, WorkWithFiles wow, Configure configure, Executors executors) {
        this.fileRoute = fileRoute;
        this.wow = wow;
        this.configure = configure;
        this.executors = executors;
    }

    Logger logger = LoggerFactory.getLogger(FilesProcessing.class);

    /**
     * 1. Читаем каталог,
     * 2. Отбираем файлы
     * 3. Обрабатываем файл
     */
    public void mainProcess() {
        fileRoute.getTopiclist().forEach(topiclist -> {
            List<File> fileList;
            if (topiclist.isDirectorywalking()) {
                fileList = wow.getAllDirListFiles(topiclist.getPathfrom());
            } else {
                fileList = wow.getCurrentDirListFiles(topiclist.getPathfrom());
            }
            if (!fileList.isEmpty()) {
                logger.info("UsbLog:------ Обработка маршрута [{}]:  | Файлов в каталоге=[{}] ------", topiclist.getServicename(), fileList.size());
                fileList.forEach(file -> {
                    if (configure.isLogDebug()) {
                        logger.info("UsbLog:File={}", file.getAbsoluteFile());
                    }
                    fileWork(topiclist, file);
                });
            }
        });
    }


    /**
     * *************************************
     * Получаем список расширений
     * *************************************
     *
     * @param topicListExtension - строка с расширениями
     * @return - список расширений
     */
    private List<String> getExtension(String topicListExtension) {
        if (topicListExtension != null) {
            return Arrays.asList(topicListExtension.split(","));
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * **************************************
     * Определяем есть расширение или нет
     * **************************************
     *
     * @param topicListExtension - список расширений
     * @return - true - есть расширение, false - нет расширений
     */
    private boolean isExtension(String topicListExtension) {
        return topicListExtension != null;
    }

    /**
     * Проверяем подходит файл для обработки, или его надо пропустить.
     *
     * @param topic - обрабатывваемфый маршрут
     * @param file  - файл
     * @return - результат, true - файл подходит для обработки, false - файл не подходит
     */
    private void fileWork(topiclist topic, File file) {
        if (!isExtension(topic.getExtension())) {
            process(topic, file);
        } else {
            List<String> ext = getExtension(topic.getExtension());
            ext.forEach(extension -> {
                if (extension.equalsIgnoreCase(wow.getExtensionFromFile(file))) {
                    process(topic, file);
                }
            });
        }
    }


    /**
     * **************************************
     * Обработка файла
     * **************************************
     *
     * @param topic - маршрут
     * @param file  - файл для обработки
     */
    private void process(topiclist topic, File file) {
        if (topic.isMoved()) {
            if (configure.isServiceMode()) {
                executors.getTask(file.getAbsolutePath(), topic.getPathto(), true); //Многопоточный режим
            } else {
                wow.filePrecessing(file.getAbsolutePath(), topic.getPathto(), true); //Одно поточный режим
            }
            logger.info("UsbLog:process(isMoved) Файл переносим:{} в каталог:{}", file.getAbsoluteFile(), topic.getPathto() + File.separator + file.getName());
        } else if (topic.isCopied()) {
            if (configure.isServiceMode()) {
                executors.getTask(file.getAbsolutePath(), topic.getPathto(), false);
            } else {
                wow.filePrecessing(file.getAbsolutePath(), topic.getPathto(), false);
            }
            logger.info("UsbLog:process(isMoved) Файл копируем:{} в каталог:{}", file.getAbsoluteFile(), topic.getPathto() + File.separator + file.getName());
        } else if (topic.isDeleted()) {
            logger.info("UsbLog:process(isDeleted) Файл удаляем:{}", file.getAbsoluteFile());
            wow.delFiles(file.toPath());
        }
        System.gc();
    }


}
