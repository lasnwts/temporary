package ru.usb.filesoperations.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.filesoperations.configure.Configure;
import ru.usb.filesoperations.model.MessageError;


import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class ServiceMailError {

    public static final long MINUTE = 60000; // in milli-seconds.

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    Logger logger = LoggerFactory.getLogger(ServiceMailError.class);

    private final MessageError messageError;
    private final Configure configure;
    private final EmailServiceImpl emailService;

    @Autowired
    public ServiceMailError(MessageError messageError, Configure configure, EmailServiceImpl emailService) {
        this.messageError = messageError;
        this.configure = configure;
        this.emailService = emailService;
    }

    /**
     * Проверка когда отправляли почту в последний раз
     *
     * @return -- true - можно отправлять письмо, false - еще не прошло время с последней отправки
     */
    public boolean checkMail() {
        if (messageError.getDate() == null) {
            logger.info("Email error еще ни разу не отправлялся с момента запуска сервиса, можно отправлять.");
            return true;
        } else {
            if (new Date().after(new Date(messageError.getDate().getTime() + configure.getMailDelayMinutes() * MINUTE))) {
                logger.info("Email error был отправлен:{}, сейчас::{} что превысило время ожидания в минутах: {}  => можно отправлять.",
                      getWnull(sdf.format(messageError.getDate())),sdf.format(new Date()),  configure.getMailDelayMinutes());
                return true;
            } else {
                logger.info("Email error был отправлен:{}, сейчас::{} время ожидания в минутах:{}",
                        getWnull(sdf.format(messageError.getDate())),sdf.format(new Date()),  configure.getMailDelayMinutes() + " отправлять нельзя.");
                return false;
            }
        }
    }

    /**
     * Отправка почтового сообщения администраторам
     *
     * @param body - тело сообщения
     */
    public void sendMailError(String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), body);
            messageError.setBody(body);
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(configure.getMailSubjects());
            messageError.setDate(new Date());
            logger.info("Отправлено письмо по адресам:{} Сообщение:{}", configure.getMailTo(), messageError);
        }
    }

    /**
     * Отправка почтового сообщения администраторам, с темой
     *
     * @param subject - тема сообщения
     * @param body    - тело сообщения
     */
    public void sendMailErrorSubject(String subject, String body) {
        if (checkMail()) {
            emailService.sendSimpleEmail(configure.getMailTo(), subject, body);
            messageError.setBody(body);
            messageError.setCount(messageError.getCount() + 1);
            messageError.setSubject(configure.getMailSubjects());
            messageError.setDate(new Date());
            logger.info("Отправлено письмо по адресам:{} Сообщение:{}", configure.getMailTo(), messageError);
        }
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWnull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

}
