package ru.usb.filesoperations.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "routes")
public class FileRoute {
    private List<topiclist> topiclist =new ArrayList<>();
    public FileRoute() {
        //
    }

    public List<ru.usb.filesoperations.model.topiclist> getTopiclist() {
        return topiclist;
    }

    public void setTopiclist(List<ru.usb.filesoperations.model.topiclist> topiclist) {
        this.topiclist = topiclist;
    }
}
