package ru.usb.filesoperations.service.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.filesoperations.configure.Configure;


import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * ********************************************************************************************************
 * Последняя версия файла
 * 1.0.10 - добавлена обработка исключений для отправки с файлами вложений
 * 22.02.2024
 * ********************************************************************************************************
 */
@Service
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender emailSender;

    private final Configure configure;

    @Autowired
    public EmailServiceImpl(JavaMailSender emailSender, Configure configure) {
        this.emailSender = emailSender;
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    /**
     * Отправка простого письма без вложенияч по списку адресов
     *
     * @param toAddress - список Email адресов
     * @param subject   - тема для письма
     * @param message   - тело сообщения
     */
    @Override
    public void sendSimpleEmail(String toAddress, String subject, String message) {

        if (toAddress == null || subject == null || message == null) {
            logger.error("UsbLog:Error:: Переменные toAddress, subject, message не могут быть NULL!");
            return;
        }
        String subjectReal = configure.getWrapNull(configure.getAppName()) + " (" + configure.getWrapNull(configure.getAppStand()) + ") " + subject;

        logger.info("Send email message, toAddress:{} |subject:{} [ |message:{}]", toAddress, subjectReal, message);
        String[] mailRecepients = toAddress.split(",");
        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
                    simpleMailMessage.setFrom(configure.getMailFrom());
                    simpleMailMessage.setSubject(subjectReal);
                    simpleMailMessage.setSentDate(new Date());
                    simpleMailMessage.setText(message);
                    simpleMailMessage.setTo(mailRecepient);
                    logger.info("UsbLog:Email подготовлен к отправке по адресу:{}", mailRecepient);
                    try {
                        emailSender.send(simpleMailMessage);
                        logger.info("UsbLog:Email отправлен отправке по адресу:{}", mailRecepient);
                    } catch (Exception mailEx) {
                        logger.error("UsbLog:Возникла ошибка при отправке письма:", mailEx);
                    }
                });
            } else {
                logger.error("UsbLog:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!");
            }
        } else {
            logger.error("UsbLog:ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!");
        }
    }

    /**
     * Отправка почтового письма с вложением
     *
     * @param toAddress  - список Email адресов
     * @param subject    - тема для письма
     * @param message    - тело сообщения
     * @param attachment - файл с вложением
     */
    @Override
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String attachment) {

        if (toAddress == null || subject == null || message == null || attachment == null) {
            logger.error("UsbLog:Error:: Переменные toAddress, subject, message, attachment не могут быть NULL!");
            return;
        }
        String subjectReal = configure.getWrapNull(configure.getAppName()) + " (" + configure.getWrapNull(configure.getAppStand()) + ") " + subject;

        logger.info("Send email [sendEmailWithAttachment] message, toAddress:{} |subject:{}  |message:{} |attachment:{}", toAddress, subjectReal, message, attachment);
        String[] mailRecepients = toAddress.split(",");

        if (mailRecepients.length > 0) {
            List<String> items = Arrays.asList(toAddress.split("\\s*,\\s*"));
            if (!items.isEmpty()) {
                items.forEach(mailRecepient -> {
                    MimeMessage mimeMessage = emailSender.createMimeMessage();
                    MimeMessageHelper messageHelper = null;
                    try {
                        messageHelper = new MimeMessageHelper(mimeMessage, true);
                        messageHelper.setFrom(configure.getMailFrom());
                        messageHelper.setTo(mailRecepients);
                        messageHelper.setSubject(subjectReal);
                        messageHelper.setText(message);
                        FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(attachment));
                        messageHelper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
                        emailSender.send(mimeMessage);
                        logger.info("UsbLog:Email отправлен отправке по адресу:{}", mailRecepient);
                    } catch (MessagingException mailEx) {
                        logger.error("UsbLog:Возникла ошибка при отправке письма:", mailEx);
                    } catch (FileNotFoundException e) {
                        logger.error("UsbLog:Возникла ошибка при отправке письма:FileNotFoundException", e);
                    }
                });
            } else {
                logger.error("UsbLog:ERROR:List<String> items = Arrays.asList(toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!");
            }
        } else {
            logger.error("UsbLog:ERROR:toAddress.split - выдает пустое значение - заведите почтовые адреса через запятую!");
        }
    }
}
