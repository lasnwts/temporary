package ru.usb.filesoperations.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.usb.filesoperations.service.mail.ServiceMailError;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Класс для работы с файлами
 */
@Component
public class WorkWithFiles {

    @Value("${service.log.debug}")
    private boolean logDebug;
    private final ServiceMailError serviceMailError;

    @Autowired
    public WorkWithFiles(ServiceMailError serviceMailError) {
        this.serviceMailError = serviceMailError;
    }

    Logger logger = LoggerFactory.getLogger(WorkWithFiles.class);

    /**
     * **************************************************
     * Проверка существования шары
     * **************************************************
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.error("WorkWithFiles:checkPathExists::Error! Directory not exists! Не удалось получить список файлов в директории ::{}", targetPath);
        return false;
    }

    /**
     * Удаление файла, представленных подготовленными объектами Paths(nio)
     *
     * @param from что удалить
     */
    public void delFiles(Path from) {
        try {
            Files.deleteIfExists(from);
        } catch (IOException e) {
            logger.error("!ERROR!PrintStackTrace:Удаление файла:{}, представленных подготовленными объектами Paths(nio):", from, e);
            serviceMailError.sendMailErrorSubject("Ошибка при удалении файла::", "Ошибка при удалении файла:" + from.toString() + ", ошибка:" + e.getMessage());
        }
    }


    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameFull) {
        Path path = Paths.get(fileNameFull);
        if (Files.exists(path)) {
            return true;
        }
        logger.error("File :: [{}] not Exist!", fileNameFull);
        return false;
    }


    /**
     * Возвращаем только имя файла без расширения
     *
     * @param filename - переменная типа File
     * @return - имя файла строка
     */
    public String getFileNameWithoutExt(File filename) {
        return filename.getName().replaceFirst("[.][^.]+$", "");
    }

    /**
     * Возвращает EXT расширение если имя файла представлено строкой
     *
     * @param fileName - строковое имя файла
     * @return - расширение
     */
    public String getExtensionFromFile(String fileName) {
        return StringUtils.getFilenameExtension(new File(fileName).getName());
    }


    /**
     * Возвращает EXT расширение
     *
     * @param fileName - файл с типом File
     * @return - расширение
     */
    public String getExtensionFromFile(File fileName) {
        String ext = StringUtils.getFilenameExtension(fileName.getName());
        if (ext == null) {
            ext = "";
        }
        return ext;
    }

    /**
     * Передача всех файлов директории
     *
     * @param directory - имя директории как строка
     * @return - список файлов File
     */
    public List<File> getCurrentDirListFiles(String directory) {
        if (!checkPathExists(directory)) {
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории:", "Не удалось получить список файлов в директории ::" + directory + ", WorkWithFiles:GetDirListFiles::Error! Directory not exists! ::" + directory);
            return Collections.emptyList();
        }
        List<Path> pathList = new ArrayList<>();
        try (Stream<Path> stream = Files.walk(Paths.get(directory), 1)) {
            pathList = stream.map(Path::normalize)
                    .filter(Files::isRegularFile)
                    .collect(Collectors.toList());
            return pathList.stream().map(Path::toFile).collect(Collectors.toList());
        } catch (IOException e) {
            logger.error("PrintStackTrace:Не удалось получить список файлов в директории:Не удалось получить список файлов в директории:", e);
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории:getCurrentDirListFiles:", "Не удалось получить список файлов в директории:1:" + directory + ", возникла ошибка:" + e.getMessage());
            return Collections.emptyList();
        }

    }

    /**
     * Получаем список файлов в директории
     *
     * @param directory - строка с Директорий тип (String)
     * @return - список объектов File
     */
    public List<File> getAllDirListFiles(String directory) {
        if (!checkPathExists(directory)) {
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории:", "Не удалось получить список файлов в директории ::" + directory + ", WorkWithFiles:GetDirListFiles::Error! Directory not exists! ::" + directory);
            return Collections.emptyList();
        }
        List<Path> pathList = new ArrayList<>();
        try (Stream<Path> stream = Files.walk(Paths.get(directory))) {
            pathList = stream.map(Path::normalize)
                    .filter(Files::isRegularFile)
                    .collect(Collectors.toList());
            return pathList.stream().map(Path::toFile).collect(Collectors.toList());
        } catch (IOException e) {
            logger.error("PrintStackTrace:Не удалось получить список файлов в директории:Не удалось получить список файлов в директории:", e);
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории::", "Не удалось получить список файлов в директории::" + directory + ", возникла ошибка:" + e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile откуда (полный путь с именем)
     * @param toFile   - куда (полный путь с именем)
     * @param isDelete - true - удалять файл, false - оставить
     */
    public void filePrecessing(String fromFile, String toFile, boolean isDelete) {
        if (fromFile == null || toFile == null) {
            logger.error("UsbLog:FilePrecessing(String fromFile, String toFile) - не могут быть NULL!");
            return;
        }
        if (!checkPathExists(toFile)) {
            logger.error("UsbLog:Нет доступа к директории={}", toFile);
            serviceMailError.sendMailErrorSubject(" Нет доступа к директории назначения ", " Ошибка доступа к директории=" + toFile);
            return;
        }
        Path from = Paths.get(fromFile);
        Path to = Paths.get(toFile + File.separator + from.getFileName());
        try {
            logger.info("UsbLog:Копируем файл(source)={} размер файла={} в файл(destination)={}", from, from.toFile().length(), to);
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toString())) {
                logger.info("file:{} successfully copied to:{} size destination={}", from, to, to.toFile().length());
                if (isDelete) {
                    Files.deleteIfExists(from);
                    logger.info("file:{} deleted successfully ", from);
                }
            } else {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("Error for operation move:: file:{} copied to:{}", fromFile, toFile);
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                serviceMailError.sendMailErrorSubject("Ошибка при обработке файла :", "Error for operation copied:: file:: " + from + " copy to:" + to);
            }
        } catch (IOException e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("PrintStackTrace::", e);
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            serviceMailError.sendMailErrorSubject("Ошибка при обработке файла :", "Error[IOException] for operation copy:: file:: " + from + " copy to:" + to + " error: " + e.getMessage());
        }
    }


}
