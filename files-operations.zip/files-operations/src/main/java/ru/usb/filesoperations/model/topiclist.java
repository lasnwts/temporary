package ru.usb.filesoperations.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *       servicename: serv1_may_numberMP-orInitiative
 *       pathfrom: siebel-dev.external.in.client.json.0
 *       pathto: siebel-dev.external.in.client.json.0
 *       moved: false
 *       copied: false
 *       deleted: false
 *       extension: xls,xlsx
 *       directorywalking: false
 */
@Component
public class topiclist {

    public String servicename;
    public String pathfrom;
    public String pathto;
    public boolean moved;
    public boolean copied;
    public boolean deleted;
    public String extension;
    public boolean directorywalking;

    @Autowired
    public topiclist() {
        //
    }

    public topiclist(String servicename, String pathfrom, String pathto, boolean moved, boolean copied,
                     boolean deleted, String extension, boolean directorywalking) {
        this.servicename = servicename;
        this.pathfrom = pathfrom;
        this.pathto = pathto;
        this.moved = moved;
        this.copied = copied;
        this.deleted = deleted;
        this.extension = extension;
        this.directorywalking = directorywalking;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getPathfrom() {
        return pathfrom;
    }

    public void setPathfrom(String pathfrom) {
        this.pathfrom = pathfrom;
    }

    public String getPathto() {
        return pathto;
    }

    public void setPathto(String pathto) {
        this.pathto = pathto;
    }

    public boolean isMoved() {
        return moved;
    }

    public void setMoved(boolean moved) {
        this.moved = moved;
    }

    public boolean isCopied() {
        return copied;
    }

    public void setCopied(boolean copied) {
        this.copied = copied;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public boolean isDirectorywalking() {
        return directorywalking;
    }

    public void setDirectorywalking(boolean directorywalking) {
        this.directorywalking = directorywalking;
    }

    @Override
    public String toString() {
        return "topiclist{" +
                "servicename='" + servicename + '\'' +
                ", pathfrom='" + pathfrom + '\'' +
                ", pathto='" + pathto + '\'' +
                ", moved='" + moved + '\'' +
                ", copied='" + copied + '\'' +
                ", deleted='" + deleted + '\'' +
                ", extension='" + extension + '\'' +
                ", directorywalking='" + directorywalking + '\'' +
                '}';
    }
}
