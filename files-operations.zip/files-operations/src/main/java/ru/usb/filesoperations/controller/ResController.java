package ru.usb.filesoperations.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.filesoperations.configure.Configure;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер REST API", description = "Инициатива 792. МП 939150. Информирование Клиента и основной точки обслуживания о регистрации доверенности.")
public class ResController {
    private final Logger logger = LoggerFactory.getLogger(ResController.class);
    private final Configure configure;

    @Autowired
    public ResController(Configure configure) {
        this.configure = configure;
    }


    @GetMapping(value = "/count")
    @Operation(summary = "Получить информацию о количестве записей в таблице")
    public ResponseEntity<String> getCount() {
        logger.info("UsbLog:Запрос на информацию о количестве записей в таблице:{}", 0);
        return new ResponseEntity<>("Количество записей в таблице:" + 0
                , HttpStatus.OK);
    }
}
