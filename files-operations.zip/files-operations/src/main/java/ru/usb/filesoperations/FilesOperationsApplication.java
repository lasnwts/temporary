package ru.usb.filesoperations;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.filesoperations.model.FileRoute;

import java.util.concurrent.atomic.AtomicInteger;

@EnableScheduling
@SpringBootApplication
public class FilesOperationsApplication implements CommandLineRunner {
    private final FileRoute fileRoute;
    @Autowired
    public FilesOperationsApplication(FileRoute fileRoute) {
        this.fileRoute = fileRoute;
    }
    @Value("${info.application.name:none}")
    String nameApp;
	@Value("${info.application.description:none}")
	String descApp;
    @Value("${service.pool.size:5}")
    private java.lang.Integer servicePoolSize;
    Logger logger = LoggerFactory.getLogger(FilesOperationsApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(FilesOperationsApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API Initiative 792. Service (ibso-trust-kafka-siebel) transmit to EFS notifications about the registration from Retail")
                .version(appVersion)
                .description("Инициатива 792. МП 939150. Информирование Клиента и основной точки обслуживания о регистрации доверенности." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("+---------------------------------------------------------------------------------------------------------+");
        logger.info("| Created by 22.02.2024       : Author: Lyapustin A.S.");
        logger.info("-----------------------------------------------------------------------------------------------------------");
        logger.info("| Name of service             : {}", nameApp);
        logger.info("| Description of service      : {}", descApp);
        logger.info("| .......                     : {}", "");
        logger.info("=---------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason             : {}", "0.0.1 Первая версия                                                       ");
        logger.info("---------------------------------------------------------------------------------------------------------");
        logger.info("UsbLog:Многопоточный режим. Число потоков={}", servicePoolSize);
        if (fileRoute.getTopiclist().isEmpty()){
            logger.info("Файл application.yml в части routes:topiclist: - не заполнен по сути работать не с чем!");
            logger.info("Заполните файл application.yml!");
        } else {
            logger.info("Количество маршрутов::{}", fileRoute.getTopiclist().size()); AtomicInteger i = new AtomicInteger();
            fileRoute.getTopiclist().forEach(topiclist ->{
                i.set(i.get() + 1);
                logger.info("--------------------------------------[Номер маршрута:{}, начало описания]--------------------------------------------", i);
                logger.info("Наименование маршрута   [servicename]:          | {}", topiclist.getServicename());
                logger.info("Путь откуда брать файлы [pathfrom]:             | {}", topiclist.getPathfrom());
                logger.info("Путь куда копировать файлы [pathto]:            | {}", topiclist.getPathto());
                logger.info("Файлы переносить [moved]:                       | {}", topiclist.isMoved());
                logger.info("Файлы копировать [copied]:                      | {}", topiclist.isCopied());
                logger.info("Файлы исходники удалять [deleted]:              | {}", topiclist.isDeleted());
                logger.info("Расширение файлов [extension]:                  | {}", topiclist.getExtension());
                logger.info("Обход вложенных директорий [directorywalking]:  | {}", topiclist.isDirectorywalking());
                logger.info("--------------------------------------[Номер маршрута:{}, конец описания]---------------------------------------------", i);
                logger.info("");
            });
        }



    }
}
