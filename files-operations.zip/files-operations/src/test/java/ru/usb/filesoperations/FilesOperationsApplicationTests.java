package ru.usb.filesoperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilesOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
