package ru.usb.demo32221;


import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@OpenAPIDefinition
public class Demo32221Application {

	@Bean
	public OpenAPI customOpenAPI(@Value("101") String appVersion) {
		return new OpenAPI().info(new Info()
				.title("API Project 3197. Service Mobile-App to Siebel")
				.version(appVersion)
				.description("Проект 3197. Обмен между Мобильным приложением и Siebel." +
						"a library for OpenAPI 3 with spring boot.")
				.termsOfService("../")
				.license(new License().name("Uralsib Bank license")
						.url("http://uralsib.ru")));
	}

	public static void main(String[] args) {
		SpringApplication.run(Demo32221Application.class, args);
	}

}
