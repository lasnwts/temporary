package ru.usb.demo32221;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo32221ApplicationTests {

	@Test
	void contextLoads() {
	}

}
