package ru.usb.multicard.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties()
public class Config {

    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;


    /**
     * Признак разрешения на удаление файлов
     */
    @Value("${service.enable.delete:false}")
    private boolean serviceEnableDelete;

    /**
     * Задержка
     */
    @Value("${service.delay.allow.directory:10}")
    private long serviceDelay;

    @Value("${service.mounth.archived:2}")
    private long serviceMounth;

    @Value("${service.count.delay:4}")
    private int serviceCountDelay;



    /**
     * Иконникова
     */
    @Value("${mailFrom}")
    private String mailFrom;
    @Value("${mailSubjects:EIC}")
    private String mailSubjects;
    @Value("${mailTo}")
    private String mailTo;

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }
    /**
     * Ляпустин
     */
    /**
     * Application properties
     */

    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.application.version}")
    private String appVersion;

    /**
     * Mail property
     */

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    /**
     * Задержка в минутах между отправкой письма администратороам
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

    public String getAppName() {
        return appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public long getMailDelayMinutes() {
        return mailDelayMinutes;
    }

    /**
     * Файловые директории
     * directory.in.deshifr=C:\\AppServer\\Data\\ikonnikova\\IN
     * directory.out.deshifr=C:\\AppServer\\Data\\ikonnikova\\out_for_user
     * directory.in=C:\\AppServer\\Data\\ikonnikova\\IN
     * directory.out=C:\\AppServer\\Data\\ikonnikova\\OUT
     * directory.archive_IN=C:\\AppServer\\Data\\ikonnikova\\IN
     * directory.archive_OUT=C:\\AppServer\\Data\\ikonnikova\\OUT
     * directory.moveout = C:\\AppServer\\Data\\ikonnikova\\
     */
    @Value("${directory.in.deshifr}")
    private String directoryInDeshifr;
    @Value("${directory.out.deshifr}")
    private String directoryOutDeshifr;
    @Value("${directory.in}")
    private String directoryIn;
    @Value("${directory.out}")
    private String directoryOut;
    @Value("${directory.archive_IN}")
    private String directoryArchiveIN;
    @Value("${directory.archive_OUT}")
    private String directoryArchiveOut;
    @Value("${directory.moveout}")
    private String directoryMoveOut;

    public String getDirectoryInDeshifr() {
        return directoryInDeshifr;
    }

    public String getDirectoryOutDeshifr() {
        return directoryOutDeshifr;
    }

    public String getDirectoryIn() {
        return directoryIn;
    }

    public String getDirectoryOut() {
        return directoryOut;
    }

    public String getDirectoryArchiveIN() {
        return directoryArchiveIN;
    }

    public String getDirectoryArchiveOut() {
        return directoryArchiveOut;
    }

    public String getDirectoryMoveOut() {
        return directoryMoveOut;
    }

    public synchronized boolean isServiceEnableDelete() {
        return serviceEnableDelete;
    }

    public synchronized void setServiceEnableDelete(boolean serviceEnableDelete) {
        this.serviceEnableDelete = serviceEnableDelete;
    }

    public long getServiceDelay() {
        return serviceDelay;
    }


    public long getServiceMounth() {
        return serviceMounth;
    }

    public int getServiceCountDelay() {
        return serviceCountDelay;
    }

    public String getServiceUser() {
        return serviceUser;
    }

    public String getServicePassword() {
        return servicePassword;
    }
}
