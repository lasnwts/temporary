package ru.usb.multicard.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.multicard.config.Config;
import ru.usb.multicard.model.FileInfo;
import ru.usb.multicard.service.FileTransferService;
import ru.usb.multicard.service.mail.ServiceMailError;

import java.io.*;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Класс для архивирования в формат zip всех файлов
 * Внесено изменение 01.08.2023 Ляпустин А.С.
 * +  SimpleDateFormat df = new SimpleDateFormat("yyyy");
 * + (2 строки)  df.format(new Date())); //Внесено изменение, вместо константы 2022, приведение года
 */

@Service
public class ZipMultipleFiles {

    SimpleDateFormat df = new SimpleDateFormat("yyyy");
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");
    FileTransferService fileTransferService = new FileTransferService();

    static final Logger log = LoggerFactory.getLogger(ZipMultipleFiles.class);

    @Autowired
    FileHelper fileHelper;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    Config config;

    /**
     * Метод для архивирования в формат zip всех файлов
     * из папки МУЛЬТИКАРТА/OUT в папку АРХИВ/OUT
     * из папки МУЛЬТИКАРТА/IN в папку АРХИВ/IN
     * В начале месяца все файлы из МУЛЬТИКАРТА\АРХИВ\OUT архивируются в файл Архив_0_2022.zip
     * В начале месяца все файлы из МУЛЬТИКАРТА\АРХИВ\IN архивируются в файл Архив_0_2022.zip
     * Архивируются файлы за месяц перед предыдущим
     * Этот файл помещается в МУЛЬТИКАРТА\АРХИВ/OUT\2022
     * Например, 01.05.2022 архивируются С УДАЛЕНИЕМ все файлы за 03.2022.
     * Файлы за 04.2022 не архивируются.
     * Архив_0_2022.zip помещается в МУЛЬТИКАРТА/АРХИВ/IN/2022
     * Архив_0_2022.zip помещается в МУЛЬТИКАРТА/АРХИВ/OUT/2022
     */

    public void archiveIN(String sourceDirectory)
            throws IOException {

        File directoryOutToZip = new File(sourceDirectory);
        File archiveFolder = new File(directoryOutToZip, df.format(new Date())); //Внесено изменение, вместо константы 2022, приведение года

        fileTransferService.createDirectory
                (archiveFolder.getPath());

        log.info("Archiving started from {} at {}", directoryOutToZip, LocalDateTime.now());

        LocalDate localDate = LocalDate.now();
        Month month = localDate.getMonth().minus(2);
        String strMonth = "";
        if (month.getValue() < 12) {
            strMonth = "0" + month.getValue();
        } else {
            strMonth = String.valueOf(month.getValue());
        }

        String fileName = "АРХИВ_МК _" + strMonth + "_" + localDate.getYear() + ".zip";

        zipFileIN(directoryOutToZip,
                new File(archiveFolder, fileName).getPath(), String.format("%d%02d",
                        localDate.getYear(), month.getValue()));

        log.info("Archiving completed at {}", LocalDateTime.now());

    }

    /**
     * Метод для архивирования в формат zip всех файлов
     * из папки МУЛЬТИКАРТА/OUT в папку АРХИВ/OUT
     * из папки МУЛЬТИКАРТА/IN в папку АРХИВ/IN
     * В начале месяца все файлы из МУЛЬТИКАРТА\АРХИВ\OUT архивируются в файл Архив_0_2022.zip
     * В начале месяца все файлы из МУЛЬТИКАРТА\АРХИВ\IN архивируются в файл Архив_0_2022.zip
     * Архивируются файлы за месяц перед предыдущим
     * Этот файл помещается в МУЛЬТИКАРТА\АРХИВ/OUT\2022
     * Например, 01.05.2022 архивируются С УДАЛЕНИЕМ все файлы за 03.2022.
     * Файлы за 04.2022 не архивируются.
     * Архив_0_2022.zip помещается в МУЛЬТИКАРТА/АРХИВ/IN/2022
     * Архив_0_2022.zip помещается в МУЛЬТИКАРТА/АРХИВ/OUT/2022
     */

    public void archiveOUT(String sourceDirectory)
            throws IOException {

        File directoryOutToZip = new File(sourceDirectory);
        File archiveFolder = new File(directoryOutToZip, df.format(new Date())); //Внесено изменение, вместо константы 2022, приведение года

        fileTransferService.createDirectory
                (archiveFolder.getPath());

        log.info("Archiving started from {} at {}", directoryOutToZip, LocalDateTime.now());

        LocalDate localDate = LocalDate.now();
        Month month = localDate.getMonth().minus(2);
        String strMonth = "";
        if (month.getValue() < 12) {
            strMonth = "0" + month.getValue();
        } else {
            strMonth = String.valueOf(month.getValue());
        }
        String fileName = "АРХИВ_МК _" + strMonth + "_" + localDate.getYear() + ".zip";

        zipFileOUT(directoryOutToZip,
                new File(archiveFolder, fileName).getPath(), String.format("%d%02d",
                        localDate.getYear(), month.getValue()));

        log.info("Archiving completed at {}", LocalDateTime.now());

    }

    /**
     * Новая версия упаковщика
     *
     * @param sourceDirectory      - директория из которой берем файлы
     * @param destinationDirectory - директория куда формируем архив
     * @param localDate            - дата за которую производится упаковка
     */
    public String archiveV2(String sourceDirectory, String destinationDirectory, LocalDate localDate) {
        File directoryOutToZip = new File(destinationDirectory);
        File archiveFolder = new File(directoryOutToZip, dtf.format(localDate)); //Внесено изменение, вместо константы 2022, приведение года
        if (!fileHelper.checkPathExists(archiveFolder.getPath())) {
            if (fileTransferService.createDirectory(archiveFolder.getPath()) == null) {
                log.error("UsbLog: Произошла критическая ошибка, продолжение работы невозможно!");
                serviceMailError.sendMailError("Произошла критическая ошибка, продолжение работы невозможно! Не удалось создать каталог: " + archiveFolder.getPath());
                return "";
            }
        }
        Month month = localDate.getMonth();
        String strMonth = "";
        if (month.getValue() < 10) {
            strMonth = "0" + month.getValue();
        } else {
            strMonth = String.valueOf(month.getValue());
        }
        String fileName = archiveFolder.getAbsolutePath() + FileSystems.getDefault().getSeparator() + "АРХИВ_МК _" + strMonth + "_" + localDate.getYear() + ".zip";
        log.info("UsbLog: Маска для отбора файлов:{}, Дата для анализа:{}, имя файла Архива={}", fileHelper.getMask(localDate), localDate, fileName);
        log.info("Archiving started from directory:{} to file:{}, take year={}, take month={}", sourceDirectory, fileName, localDate.getYear(), localDate.getMonth());
        zipFilev2(getFileList(sourceDirectory, localDate), fileName);
        log.info("Archiving completed at {}", LocalDateTime.now());
        return fileName;
    }

    /**
     * Информационный класс - получяить список файлов для обработки по критериям - директория + дата
     *
     * @param sourceDirectory - директория,
     * @param localDate       - дата
     * @return - список
     */
    public List<FileInfo> archiveInfo(String sourceDirectory, LocalDate localDate) {
        List<File> fileList = fileHelper.getCurrentDirListFiles(sourceDirectory);
        List<FileInfo> fileInfoList = new ArrayList<>();
        log.info("UsbLog: Маска для отбора файлов:{}, Дата для анализа:{}", fileHelper.getMask(localDate), localDate);
        fileList.forEach(file -> {
            LocalDate fileLocalDate = fileHelper.getDateCreateFromFile(file);
            if (fileLocalDate == null) {
                log.error("UsbLog: Error произошла ошибка при определении даты создания файла:{}", file.getAbsolutePath());
            } else {
                if ((fileLocalDate.getYear() == localDate.getYear() && fileLocalDate.getMonth().equals(localDate.getMonth())) || (fileHelper.checkMaskMatching(file.getName(), localDate))) {
                    fileInfoList.add(new FileInfo(file.getAbsolutePath(), file.length(), fileLocalDate));
                    log.info("UsbLog: Отобран файл:{} размер={}, дата создания:{}", file.getAbsolutePath(), file.length(), fileLocalDate);
                }
            }
        });
        return fileInfoList;
    }

    /**
     * Информационный класс - получить список файлов для обработки по критериям - директория + дата
     *
     * @param sourceDirectory - директория,
     * @param localDate       - дата
     * @return - список
     */
    public File[] getFileList(String sourceDirectory, LocalDate localDate) {
        List<File> fileList = fileHelper.getCurrentDirListFiles(sourceDirectory);
        List<File> fileDestList = new ArrayList<>();
        fileList.forEach(file -> {
            LocalDate fileLocalDate = fileHelper.getDateCreateFromFile(file);
            if (fileLocalDate == null) {
                log.error("UsbLog: Error произошла ошибка при определении даты создания файла:{}", file.getAbsolutePath());
            } else {
                if ((fileLocalDate.getYear() == localDate.getYear() && fileLocalDate.getMonth().equals(localDate.getMonth())) || (fileHelper.checkMaskMatching(file.getName(), localDate))) {
                    fileDestList.add(file);
                    log.info("UsbLog: Отобран файл:{} размер={}, дата создания:{}", file.getAbsolutePath(), file.length(), fileLocalDate);
                }
            }
        });
        if (fileDestList.isEmpty()) {
            return null;
        }
        File[] files = new File[fileDestList.size()];
        return fileDestList.toArray(files);
    }

    /**
     * Метод архивирует все файлы из каталога МУЛЬТИКАРТА/АРХИВ/OUT и МУЛЬТИКАРТА/АРХИВ/IN
     * Чтобы сжать каталоги, рекурсивно перебираем их
     * Каждый раз, когда находим каталог, добавляем его имя к имени ZipEntry потомков,
     * Также создается запись каталога для каждого пустого каталога
     * Все файлы из МУЛЬТИКАРТА\АРХИВ\IN за месяц
     * архивируются в файл Архив_0_2022.zip
     * и удаляются из корня МУЛЬТИКАРТА/АРХИВ/OUT и МУЛЬТИКАРТА/АРХИВ/IN после попадания в архив
     * Этот файл помещается в МУЛЬТИКАРТА\АРХИВ/OUT\2022
     * Этот файл помещается в МУЛЬТИКАРТА\АРХИВ/IN\2022
     */

    public void zipFileIN
    (File sourceFolder, String filePath, String filterName)
            throws IOException {

        try (FileOutputStream fileOutputStream = new FileOutputStream(filePath);

             ZipOutputStream zipOut = new ZipOutputStream(fileOutputStream)) {

            if (sourceFolder.isHidden()) {
                return;
            }
            if (sourceFolder.isDirectory()) {

                File[] children = sourceFolder.listFiles();
                for (File childFile : children) {
                    if (childFile.isDirectory()) {
                        continue;
                    }


                    if (childFile.getName().contains(filterName)) {
                        byte[] buffer = Files.readAllBytes(childFile.toPath());
                        ZipEntry zipEntry = new ZipEntry(childFile.getName());
                        zipEntry.setTime(childFile.lastModified());
                        zipOut.putNextEntry(zipEntry);
                        zipOut.write(buffer, 0, buffer.length);
                        zipOut.closeEntry();
//                        Files.delete(childFile.toPath());
//                        Files.delete(childFile.toPath());


                    }

                }
            }
        } catch (IOException e) {
            log.error(e.getMessage());
            throw e;
        }
    }

    public void zipFileOUT
            (File sourceFolder, String filePath, String filterName)
            throws IOException {


        try (FileOutputStream fileOutputStream = new FileOutputStream(filePath);

             ZipOutputStream zipOut = new ZipOutputStream(fileOutputStream)) {

            if (sourceFolder.isHidden()) {
                return;
            }
            if (sourceFolder.isDirectory()) {

                File[] children = sourceFolder.listFiles();
                for (File childFile : children) {
                    if (childFile.isDirectory()) {
                        continue;
                    }

                    if (childFile.getName().contains(filterName)) {
                        byte[] buffer = Files.readAllBytes(childFile.toPath());
                        ZipEntry zipEntry = new ZipEntry(childFile.getName());
                        zipEntry.setTime(childFile.lastModified());
                        zipOut.putNextEntry(zipEntry);
                        zipOut.write(buffer, 0, buffer.length);
                        zipOut.closeEntry();
                        Files.delete(childFile.toPath());


                    }
                }
            }
        } catch (IOException e) {
            log.error(e.getMessage());
            throw e;
        }
    }


    /**
     * Упаковываем файлы
     *
     * @param listFiles - массив файлов
     * @param filePath  - имя архива
     */
    public void zipFilev2(File[] listFiles, String filePath) {
        if (filePath == null) {
            log.error("UsbLog:Error: zipFilev2(File[] listFiles, String filePath) -> filePath = Параметр передан как NULL!");
            return;
        }
        if (listFiles == null || listFiles.length == 0) {
            log.info("UsbLog: zipFilev2(File[] listFiles, String filePath) -> listFiles:пуст. Нет подходящих файлов для упаковки");
            return;
        }
        try (FileOutputStream fileOutputStream = new FileOutputStream(filePath);
             ZipOutputStream zipOut = new ZipOutputStream(fileOutputStream)) {
            File[] children = listFiles;
            for (File childFile : children) {
                if (childFile.isDirectory()) {
                    continue;
                }
                log.info("UsbLog: Упаковываем файл:{}", childFile.toPath());
                byte[] buffer = Files.readAllBytes(childFile.toPath());
                ZipEntry zipEntry = new ZipEntry(childFile.getName());
                zipEntry.setTime(childFile.lastModified());
                zipOut.putNextEntry(zipEntry);
                zipOut.write(buffer, 0, buffer.length);
                zipOut.closeEntry();
                //Если разрешено удаление, удаляем
                if (config.isServiceEnableDelete()) {
                    log.info("UsbLog: Файл:{} - удален.", childFile.toPath());
                    Files.delete(childFile.toPath());
                }
            }
            File file = new File(filePath);
            log.info("UsbLog: Файл архива создан:{}, размер файла:{}", file, file.length());
        } catch (IOException e) {
            log.error("UsbLog: Ошибка при выполнении операции упаковки.", e);
            serviceMailError.sendMailError("Ошибка при выполнении операции упаковки [zipFilev2] в файл " + filePath + "\n Описание ошибки:" + e.getMessage());
        }
    }

}

