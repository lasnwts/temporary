package ru.usb.multicard.service;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import ru.usb.multicard.config.Config;
import ru.usb.multicard.service.mail.ServiceMailError;
import ru.usb.multicard.util.FileHelper;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

@Service
@PropertySource("classpath:application.properties")
public class FileTransferService {

    private static final Logger log = LoggerFactory.getLogger(FileTransferService.class);

    @Autowired
    JavaMailSender emailSender;

    @Autowired
    Config configure;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    FileHelper fileHelper;

    /**
     * Метод получает из папки МУЛЬТИКАРТА/OUT список всех файлов
     */

    public boolean listFiles(String startDir) {
        try (Stream<Path> walk = Files.walk(Paths.get(startDir))) {
            List<String> result = walk.filter(Files::isRegularFile)
                    .map(x -> x.toString()).collect(Collectors.toList());
            log.info("List of files from {} received", startDir);
            result.forEach(s -> {
                logFile(s);
            });
            return true;
        } catch (IOException e) {
            log.error("UsbLog: Произошла ошибка при сканировании каталога, класс FileTransferService. метод listFiles(String startDir)");
            log.error("UsbLog: ошибка:", e);
            serviceMailError.sendMailError("Произошла ошибка при сканировании каталога, класс FileTransferService. метод listFiles(String startDir):" + fileHelper.getWrapNull(e.getMessage()));
            return false;
        }
    }


    /**
     * Получение списка файлов
     * @param startDir - директория
     * @return - список строк
     */
    public List<String> listFilesController(String startDir) {
        try (Stream<Path> walk = Files.walk(Paths.get(startDir))) {
            List<String> result = walk.filter(Files::isRegularFile)
                    .map(x -> x.toString()).collect(Collectors.toList());
            log.info("List of files from {} received", startDir);
            result.forEach(s -> {
                logFile(s);
            });
            return result;
        } catch (IOException e) {
            log.error("UsbLog: Произошла ошибка при сканировании каталога, класс FileTransferService. метод listFiles(String startDir)");
            log.error("UsbLog: ошибка:", e);
            return null;
        }
    }

    private void logFile(String line) {
        log.info("UsbLog:Обнаружен файл:{}", line);
    }

    /**
     * Метод копирует все файлы из МУЛЬТИКАРТА/OUT, исключая маску "CORR_ACCT_LIMITS*.txt"
     * Перекладывает в папку filepro/IN для шифрования и подписания
     * Проходимся по дереву файлов, используя Files.walk()
     * Вызываем Files.copy() для каждого файла и каталога, которые мы нашли
     */

    public boolean copyFiles(String sourceDirectoryLocation, String destinationDirectoryLocation) {

        Date now = new Date();
        try {
            Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .filter(source -> !source.getName().startsWith("CORR_ACCT_LIMITS"))
                    //                .filter(source -> (now.getMonth() - 2) == new Date(source.lastModified()).getMonth())
                    .filter(source -> (now.getMonth()) == new Date(source.lastModified()).getMonth())
                    .forEach(source -> {
                        try {
                            File file = new File(destinationDirectoryLocation, source.getName());
                            log.info("Prepare copy source {}(size={})", source, source.length());
                            FileUtils.copyFile(source, file, true);
                            log.info("Сopy source {}(size={})  to file {}(size={})", source, source.length(), file, file.length());
                        } catch (IOException e) {
                            log.info("Error while copy file  from {} ", sourceDirectoryLocation);
                            log.info("Error,   stack: ", e);
                            serviceMailError.sendMailError("Error,  copyFiles(String sourceDirectoryLocation, String  destinationDirectoryLocation) \n" + e.getMessage());
                        }
                    });
            return true;
        } catch (IOException e) {
            log.info("Error,  copyFiles(String sourceDirectoryLocation, String destinationDirectoryLocation), while copy file from {} ", sourceDirectoryLocation);
            log.info("Error, stack:: ", e);
            serviceMailError.sendMailError("Error,  copyFiles(String sourceDirectoryLocation, String destinationDirectoryLocation)\n" + e.getMessage());
            return false;
        }
    }

    /**
     * Метод перемещает файлы из папки МУЛЬТИКАРТА/OUT в МУЛЬТИКАРТА/АРХИВ/OUT
     */
    public boolean moveFiles(String sourceDirectoryLocation, String destinationDirectoryLocation) {
        Date now = new Date();
        try {
            Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .filter(source -> !source.getName().startsWith("CORR_ACCT_LIMITS"))
                    //                .filter(source -> (now.getMonth() - 2) == new Date(source.lastModified()).getMonth())
                    .filter(source -> (now.getMonth()) == new Date(source.lastModified()).getMonth())
                    .forEach(source -> {
                        try {
                            File file = new File(destinationDirectoryLocation, source.getName());
                            log.info("Prepare move file {}(size={})", source, source.length());
                            FileUtils.moveFile(source, file);
                            log.info("Move file {} to {}(size={})", source, file, file.length());
                            log.info("File sent to directory:  {}.{}", destinationDirectoryLocation, source.getName());
                        } catch (IOException e) {
                            log.info("Error  while copy file from {} ", sourceDirectoryLocation);
                            log.info("Error, stack ", e);
                            serviceMailError.sendMailError("Error,  copyFiles(String sourceDirectoryLocation, String destinationDirectoryLocation)\n" + e.getMessage());
                        }
                    });
            return true;
        } catch (IOException e) {
            log.info("Error Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile) ");
            log.info("Error, stack ", e);
            serviceMailError.sendMailError("Error,  Error Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)\n" + e.getMessage());
            return false;
        }
    }

    /**
     * Метод перемещает файлы из папки МУЛЬТИКАРТА/OUT в DCDCB\ДПББП\REPORT\КФУ Мультикарта
     */

    public void moveFiles2(String sourceDirectoryLocation, String destinationDirectoryLocation /*,String archLoc*/){
        Date now = new Date();
        try {
            Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .filter(source -> source.getName().startsWith("URSI_CORR_ACCT_BAL_ALL"))
                    .filter(source -> (now.getMonth()) == new Date(source.lastModified()).getMonth())
                    .forEach(source -> {
                       /* try {
                            File file = new File(destinationDirectoryLocation, source.getName());
                            log.info("Data transfer to KFU has started at{}", LocalDateTime.now());
                            FileUtils.copyFile(source, file, true);
                            log.info("File was copy to " + source);
                        } catch (IOException e) {
                            log.info("Error while copy file from {} ", sourceDirectoryLocation);
                        }*/
                        try {
                            log.info("Data transfer to KFU has started at{}", LocalDateTime.now());
                            log.info("Prepare move file {}(size={})", source, source.length());
                            File file2 = new File(destinationDirectoryLocation, source.getName());
                            FileUtils.moveFile(source, file2);
                            log.info("File sent to directory: {}.{}", destinationDirectoryLocation, source.getName());
                            log.info("Move file {} to {}(size={})", source, file2, file2.length());
                            log.info("Data transfer to KFU ended at {}", LocalDateTime.now());
                        } catch (IOException e) {
                            log.info("Error while move file from {} ", sourceDirectoryLocation);
                            log.info("Error,moveFiles2.Files.walk(Paths.get(sourceDirectoryLocation)).FileUtils.moveFile(source, file2); stack IOException:", e);
                            serviceMailError.sendMailError("Error,moveFiles2.Files.walk(Paths.get(sourceDirectoryLocation)).FileUtils.moveFile(source, file2); stack IOException:\n" + e.getMessage());
                        }
                    });
        } catch (IOException e) {
            log.info("Error,moveFiles2.Files.walk(Paths.get(sourceDirectoryLocation)) stack IOException:", e);
            serviceMailError.sendMailError("Error,moveFiles2.Files.walk(Paths.get(sourceDirectoryLocation)) stack IOException:\n" + e.getMessage());
        }
    }


    /**
     * Метод отправляет файлы с маской URSI _CORR_ACCT_BAL_ALARM на почту
     */
    public void sendEmailWithAttachment(String toAddress, String subject, String message, String sourceDirectoryLocation, String sourceDir) throws IOException, MessagingException {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
        messageHelper.setFrom(configure.getMailFrom());
        String[] mailRecepients = toAddress.split(",");
        messageHelper.setTo(mailRecepients);
        messageHelper.setSubject(subject);
        messageHelper.setText(message);
        AtomicReference<Integer> a = new AtomicReference<>(0);

        Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)
                .map(Path::toFile)
                .filter(source -> source.getName().startsWith("URSI_CORR_ACCT_BAL_ALARM"))
                .forEach(source -> {
                    try {
                        FileSystemResource file = new FileSystemResource(ResourceUtils.getFile(source.toString()));
                        messageHelper.addAttachment(file.getFilename(), file);
                        a.getAndSet(a.get() + 1);
                        log.info("Send email message, toAddress:" + toAddress + " |subject:" + subject + " |message:" + message + " |attachment" + source.toString());
                    } catch (IOException e) {
                        log.info("Error while move file from {} ", sourceDirectoryLocation);
                        log.info("Error,IOException, messageHelper.addAttachment(file.getFilename(), file);, stack ", e);
                        serviceMailError.sendMailError("Error, MessagingException, messageHelper.addAttachment(file.getFilename(), file), IOException:\n" + e.getMessage());
                    } catch (MessagingException e) {
                        log.info("Error while copy file from {} ", sourceDirectoryLocation);
                        log.info("Error,MessagingException, messageHelper.addAttachment(file.getFilename(), file);, stack ", e);
                        serviceMailError.sendMailError("Error, MessagingException, messageHelper.addAttachment(file.getFilename(), file), MessagingException:\n" + e.getMessage());
                    }
                });

        if (a.get() > 0) {
            try {
                emailSender.send(mimeMessage);
                Files.walk(Paths.get(sourceDirectoryLocation)).filter(Files::isRegularFile)
                        .map(Path::toFile)
                        .filter(source -> source.getName().startsWith("URSI_CORR_ACCT_BAL_ALARM"))
                        .forEach(source -> {
                            try {
                                File file = new File(sourceDir, source.getName());
                                log.info("Prepare move file {}(size={})", source, source.length());
                                FileUtils.moveFile(source, file);
                                log.info("File sent to directory: {}.{}", sourceDir, source.getName());
                                log.info("Move file {} to {}(size={})", source, file, file.length());
                            } catch (IOException e) {
                                log.info("Error while copy file from {} ", sourceDirectoryLocation);
                                log.info("Error, Error, emailSender.send(mimeMessage), FileUtils.moveFile(source, file);, stack ", e);
                                serviceMailError.sendMailError("Error, emailSender.send(mimeMessage), FileUtils.moveFile(source, file);\n" + e.getMessage());
                            }
                        });
            } catch (Exception e) {
                log.info("Error, Error, emailSender.send(mimeMessage), stack ", e);
                serviceMailError.sendMailError("Error, emailSender.send(mimeMessage)\n" + e.getMessage());
            }
        }
    }


    /**
     * Метод, который создает директорию
     *
     * @return
     */

    public String createDirectory(String dir) {

        try {
            FileUtils.forceMkdir(new File(dir));
        } catch (IOException e) {
            log.error("UsbLog:createDirectory: Ошибка создания директории:{}", dir);
            log.error("UsbLog:Error stack:", e);
            return null;
        }
        log.info("New Directory created: " + dir);
        return dir;
    }

}







