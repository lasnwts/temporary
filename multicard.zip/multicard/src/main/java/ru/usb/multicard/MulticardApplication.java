package ru.usb.multicard;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.usb.multicard.config.Config;
import ru.usb.multicard.service.SchedulerService;
import ru.usb.multicard.service.mail.ServiceMailError;
import ru.usb.multicard.util.FileHelper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@SpringBootApplication
@EnableScheduling
public class MulticardApplication implements CommandLineRunner {
    Logger logger = LoggerFactory.getLogger(MulticardApplication.class);
    private final Config config;
    private final FileHelper fileHelper;
    private final ServiceMailError serviceMailError;

    @Autowired
    public MulticardApplication(Config config, FileHelper fileHelper, ServiceMailError serviceMailError) {
        this.config = config;
        this.fileHelper = fileHelper;
        this.serviceMailError = serviceMailError;
    }

    public static void main(String[] args) {
        SpringApplication.run(MulticardApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API MultiCard.")
                .version(appVersion)
                .description("Мультикарта Архивирование." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info("+-----------------------------------------------------------------------------------------------------------+");
        logger.info(" Modified by 04.03.2024   : Author (of modified): Lyapustin A.S.");
        logger.info("=------------------------------------------------------------------------------------------------------------=");
        logger.info("| Modified reason               :{}", "0.1.120 Первая доработанная версия                                     ");
        logger.info("--------------------------------------------------------------------------------------------------------------");

        /**
         * Блок проверки наличия всех директорий, при запуске.
         */
        if (!fileHelper.checkPathExists(config.getDirectoryArchiveIN())) {
            logger.error("UsbLog:ERROR: Директория:{}, не существует или к ней нет доступа!.", config.getDirectoryArchiveIN());
            serviceMailError.sendMailError("Директория  :" + fileHelper.getWrapNull(config.getDirectoryArchiveIN()) + ",  не существует или к ней нет доступа!");
        }

		if (!fileHelper.checkPathExists(config.getDirectoryArchiveOut())) {
			logger.error("UsbLog:ERROR: Директория:{}, не существует или к ней нет доступа!..", config.getDirectoryArchiveOut());
			serviceMailError.sendMailError("Директория:  " + fileHelper.getWrapNull(config.getDirectoryArchiveOut()) + ", не  существует или к ней нет доступа!");
		}

		if (!fileHelper.checkPathExists(config.getDirectoryIn())) {
			logger.error("UsbLog:ERROR: Директория:{}, не существует или к ней нет доступа!...", config.getDirectoryIn());
			serviceMailError.sendMailError("Директория :" + fileHelper.getWrapNull(config.getDirectoryIn()) + ", не существует  или к ней нет доступа!");
		}

		if (!fileHelper.checkPathExists(config.getDirectoryOut())) {
			logger.error("UsbLog:ERROR:  Директория:{}, не существует или к ней нет доступа! ", config.getDirectoryOut());
			serviceMailError.sendMailError( " Директория :" + fileHelper.getWrapNull(config.getDirectoryOut()) + ", не существует или  к ней нет доступа!");
		}

		if (!fileHelper.checkPathExists(config.getDirectoryInDeshifr())) {
			logger.error("UsbLog:ERROR: Директория:{}, не  существует или к ней нет доступа!", config.getDirectoryInDeshifr());
			serviceMailError.sendMailError("Директория : " + fileHelper.getWrapNull(config.getDirectoryInDeshifr()) + ", не существует или к ней нет  доступа!");
		}

		if (!fileHelper.checkPathExists(config.getDirectoryOutDeshifr())) {
			logger.error("UsbLog:ERROR: Директория:{}, не существует  или к ней нет доступа!", config.getDirectoryOutDeshifr());
			serviceMailError.sendMailError( " Директория " + fileHelper.getWrapNull(config.getDirectoryOutDeshifr()) + ", не существует  или к ней нет доступа!");
		}
	}
}
