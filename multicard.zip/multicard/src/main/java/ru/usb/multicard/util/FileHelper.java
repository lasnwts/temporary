package ru.usb.multicard.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.multicard.service.mail.ServiceMailError;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Вспомогательный файловый класс
 */

@Component
public class FileHelper {
    Logger logger = LoggerFactory.getLogger(FileHelper.class);

    private final ServiceMailError serviceMailError;

    @Autowired
    public FileHelper(ServiceMailError serviceMailError) {
        this.serviceMailError = serviceMailError;
    }

    /**
     * **************************************************
     * Проверка существования шары
     * **************************************************
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            return true;
        }
        logger.error("WorkWithFiles:checkPathExists::Error! Directory not exists! Не удалось подключиться к директории ::{}", targetPath);
        return false;
    }

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Передача всех файлов директории
     *
     * @param directory - имя директории как строка
     * @return - список файлов File
     */
    public List<File> getCurrentDirListFiles(String directory) {
        if (!checkPathExists(directory)) {
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории:", "Не удалось получить список файлов в директории ::" + directory + ", WorkWithFiles:GetDirListFiles::Error! Directory not exists! ::" + directory);
            return Collections.emptyList();
        }
        List<Path> pathList = new ArrayList<>();
        try (Stream<Path> stream = Files.walk(Paths.get(directory), 1)) {
            pathList = stream.map(Path::normalize)
                    .filter(Files::isRegularFile)
                    .collect(Collectors.toList());
            return pathList.stream().map(Path::toFile).collect(Collectors.toList());
        } catch (IOException e) {
            logger.error("PrintStackTrace:Не удалось получить список файлов в директории:Не удалось получить список файлов в директории:", e);
            serviceMailError.sendMailErrorSubject("Не удалось получить список файлов в директории:getCurrentDirListFiles:", "Не удалось получить список файлов в директории:1:" + directory + ", возникла ошибка:" + e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Проверка соответствия маски и имени файла. Если файл содержит маску, то берем его в работу = true, иначе = false
     *
     * @param fileName  имя файла
     * @param localDate - дата, которую преобразуем в маску
     * @return - результат сравнения
     */
    public boolean checkMaskMatching(String fileName, LocalDate localDate) {
        if (fileName == null || localDate == null) {
            logger.error("UsbLog: Ошибка checkMaskMatching(String fileName) маски в имени файла: fileName=NULL или localDate=NULL!");
            return false;
        } else return fileName.contains(getMask(localDate));
    }

    /**
     * Создание маски для отбора файлов, тип _yyyyMM, пример 202401
     *
     * @param localDate - дата для создания маски
     * @return - строка с маской
     */
    public String getMask(LocalDate localDate) {
        if (localDate.getMonthValue() < 10) {
            return "_" + Integer.toString(localDate.getYear()) + "0" + Integer.toString(localDate.getMonthValue());
        } else {
            return "_" + Integer.toString(localDate.getYear()) + Integer.toString(localDate.getMonthValue());
        }
    }


    /**
     * Получаем LocalDate - от файла
     *
     * @param file - файл
     * @return - дата создания в формате LocalDate
     */
    public LocalDate getDateCreateFromFile(File file) {
        Path filePath = file.toPath();
        BasicFileAttributes attributes = null;
        try {
            attributes =
                    Files.readAttributes(filePath, BasicFileAttributes.class);
        } catch (IOException exception) {
            logger.info("Exception handled when trying to get file attributes: ", exception);
        }
        long milliseconds = attributes.creationTime().to(TimeUnit.MILLISECONDS);
        if ((milliseconds > Long.MIN_VALUE) && (milliseconds < Long.MAX_VALUE)) {
            Date creationDate =
                    new Date(attributes.creationTime().to(TimeUnit.MILLISECONDS));

//            System.out.println("File " + filePath.toString() + " created " +
//                    creationDate.getDate() + "/" +
//                    (creationDate.getMonth() + 1) + "/" +
//                    (creationDate.getYear() + 1900));
            LocalDate localDate = LocalDate.parse(new SimpleDateFormat("yyyy-MM-dd").format(creationDate));
            return localDate;
        }
        return null;
    }


}
