package ru.usb.multicard.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.usb.multicard.config.Config;
import ru.usb.multicard.model.FileInfo;
import ru.usb.multicard.service.mail.ServiceMailError;
import ru.usb.multicard.util.FileHelper;
import ru.usb.multicard.util.ZipMultipleFiles;

import javax.mail.MessagingException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Класс для запуска процессов выгрузки по расписанию
 */
@Service
public class SchedulerService {

    @Value("${directory.out}")
    private String directoryOut;

    @Value("${directory.in}")
    private String directoryIn;

    @Value("${directory.in.deshifr}")
    private String directoryINdeshifr;

    @Value("${directory.archive_OUT}")
    private String dirArchiveOut;

    @Value("${directory.moveout}")
    private String dirMoveOut;

    @Value("${directory.archive_IN}")
    private String dirArchiveIn;

    @Autowired
    Config configure;
    @Autowired
    FileTransferService fileTransferService;

    @Autowired
    ZipMultipleFiles zipMultipleFiles;

    @Autowired
    ServiceMailError serviceMailError;

    @Autowired
    FileHelper fileHelper;

    private static final Logger log = LoggerFactory.getLogger(SchedulerService.class);

    /**
     * Запуск процесса копирования из МУЛЬТИКАРТА/OUT  в filepro/IN 3 раза в день
     * Перемещение файлов из МУЛЬТИКАРТА/OUT в корень МУЛЬТИКАРТА/АРХИВ/OUT
     */
    @Scheduled(cron = "${cron.copy}", zone = "Europe/Moscow")
    public void copy() {

        log.info("The daily upload process has started at{}", LocalDateTime.now());

        if (fileTransferService.listFiles(directoryOut)) {
            if (fileTransferService.copyFiles(directoryOut, directoryINdeshifr)) {
                if (fileTransferService.moveFiles(directoryOut, dirArchiveOut)) {
                    log.info("UsbLog:void copy() successfully done.");
                } else {
                    log.error("UsbLog: Возникла ошибка при выполнении fileTransferService.moveFiles({}, {})", directoryOut, dirArchiveOut);
                }
            } else {
                log.error("UsbLog: Возникла ошибка при выполнении fileTransferService.copyFiles({}, {})", directoryOut, dirArchiveOut);
            }
        } else {
            log.error("UsbLog: Ошибка получения списка файлов - fileTransferService.listFiles({})", directoryOut);
        }
        log.info("The daily upload process ended at {}", LocalDateTime.now());
    }


    /**
     * Получения полного списка файлов в директории
     *
     * @return
     */
    public List<String> getListFile() {
        return fileTransferService.listFilesController(dirArchiveOut);
    }


    /**
     * Проверяет алармы в корневой папке, отравляет если есть на почту Н.Шехову, после отправки переносит файлы в новую папку
     */
    @Scheduled(cron = "${cron.send}", zone = "Europe/Moscow")
    public void sendEmail() {
        try {
            fileTransferService.sendEmailWithAttachment(configure.getMailTo(), configure.getMailSubjects(), " Были превышения порогового значения. Подробную информацию о суммах превышения необходимо смотреть в отчете: ", directoryIn, dirMoveOut);
        } catch (IOException e) {
            log.info("Error sendEmail.fileTransferService.sendEmailWithAttachment.IOException: ", e);
            serviceMailError.sendMailError("Error, Error sendEmail.fileTransferService.sendEmailWithAttachment.IOException::\n" + e.getMessage());
        } catch (MessagingException e) {
            log.info("Error sendEmail.fileTransferService.sendEmailWithAttachment.MessagingException: ", e);
            serviceMailError.sendMailError("Error, Error sendEmail.fileTransferService.sendEmailWithAttachment.MessagingException::\n" + e.getMessage());
        }
    }

    @Scheduled(cron = "${cron.kfu}", zone = "Europe/Moscow")
    public void moveKFU() {
        fileTransferService.moveFiles2(directoryIn, dirMoveOut /*, dirArchiveIn*/);
    }


    /**
     * Запуск процесса архивирования 1 числа каждого месяца в 08:00 утра
     */
    @Scheduled(cron = "${cron.archive}", zone = "Europe/Moscow")
    public void archive() throws IOException {
        log.info("The month archiving process has started at {}", LocalDateTime.now());
/*
        Старая реализация Марии Иконниковой
        zipMultipleFiles.archiveOUT(dirArchiveOut);
        zipMultipleFiles.archiveIN(dirArchiveIn);
*/
        LocalDate lDate = LocalDate.now().minusMonths(configure.getServiceMounth());
        log.info("UsbLog: Подготавливаем упаковку в архив файлов за месяц;{} и год:{}", lDate.getMonth(), lDate.getYear());
        long arcOutDelay = 1000 * 60 * configure.getServiceDelay();

        /**
         * Ожидание доступности ресурса в виде директории configure.getDirectoryArchiveOut()
         */
        int i = 0; //Счетчик циклов
        do {
            i = i + 1;
            if (fileHelper.checkPathExists(configure.getDirectoryArchiveOut())) {
                launchArchFile(configure.getDirectoryArchiveOut(), configure.getDirectoryArchiveOut(), lDate);
                i = 5;
            } else {
                log.error("UsbLog: Директория - {} - сейчас недоступна, сервис переходит в ожидание на {} минут ", configure.getDirectoryArchiveOut(), configure.getServiceDelay());
                try {
                    Thread.sleep(arcOutDelay);
                } catch (InterruptedException e) {
                    log.error("UsbLog: Системная Ошибка archive - InterruptedException", e);
                    Thread.currentThread().interrupt();
                }
            }
        } while (configure.getServiceCountDelay() > i);

        /**
         * Ожидание доступности ресурса в виде директории configure.getDirectoryArchiveIN()
         */
        int j = 0; //Счетчик циклов
        do {
            j = j + 1;
            if (fileHelper.checkPathExists(configure.getDirectoryArchiveIN())) {
                launchArchFile(configure.getDirectoryArchiveIN(), configure.getDirectoryArchiveIN(), lDate);
                j = 5;
            } else {
                try {
                    log.error("UsbLog: Директория - {} - сейчас недоступна, сервис переходит в ожидание на {} минут ", configure.getDirectoryArchiveIN(), configure.getServiceDelay());
                    Thread.sleep(arcOutDelay);
                } catch (InterruptedException e) {
                    log.error("UsbLog: Системная Ошибка archive - InterruptedException", e);
                    Thread.currentThread().interrupt();
                }
            }
        } while (configure.getServiceCountDelay() > j);


        log.info("The month archiving process ended at {}", LocalDateTime.now());
    }

    /**
     * Обретка для restAPI
     *
     * @param directoryArch - директория
     * @param localDate     - дата
     * @return - список файлов
     */
    public List<FileInfo> getFileInfo(String directoryArch, LocalDate localDate) {
        return zipMultipleFiles.archiveInfo(directoryArch, localDate);
    }

    /**
     * Обретка на упаковкой файлов
     *
     * @param directorySource      - директория источник файлов
     * @param directoryDestination - директория куда файлы располагать
     * @param localDate            - дата за которую надо упаковать файлы
     */
    public String launchArchFileApi(String directorySource, String directoryDestination, LocalDate localDate) {
       return zipMultipleFiles.archiveV2(directorySource, directoryDestination, localDate);
    }

    /**
     * Обретка на упаковкой файлов
     *
     * @param directorySource      - директория источник файлов
     * @param directoryDestination - директория куда файлы располагать
     * @param localDate            - дата за которую надо упаковать файлы
     */
    public void launchArchFile(String directorySource, String directoryDestination, LocalDate localDate) {
        zipMultipleFiles.archiveV2(directorySource, directoryDestination, localDate);
    }

}
