package ru.usb.multicard.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDate;
import java.util.Date;

/**
 * Список файлов попадающих под критерии выборки
 */

@Schema(name = "FileInfo", description = "Информация о файлах")
public class FileInfo {

    @Schema(name = "fileName", description = "Имя файла")
    private String fileName;
    @Schema(name = "fileSize", description = "Размер файла в байтах")
    private long fileSize;
    @Schema(name = "fileCreate", description = "Дата создания файла")
    private LocalDate fileCreate;

    public FileInfo() {
        //
    }

    public FileInfo(String fileName, long fileSize, LocalDate fileCreate) {
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.fileCreate = fileCreate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public LocalDate getFileCreate() {
        return fileCreate;
    }

    public void setFileCreate(LocalDate fileCreate) {
        this.fileCreate = fileCreate;
    }

    @Override
    public String toString() {
        return "FileInfo{" +
                "fileName='" + fileName + '\'' +
                ", fileSize=" + fileSize +
                ", fileCreate=" + fileCreate +
                '}';
    }
}
