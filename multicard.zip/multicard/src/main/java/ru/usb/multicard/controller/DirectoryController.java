package ru.usb.multicard.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.multicard.config.Config;
import ru.usb.multicard.model.FileInfo;
import ru.usb.multicard.service.SchedulerService;
import ru.usb.multicard.util.FileHelper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер REST API", description = "Multicard")
public class DirectoryController {

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final Logger log = LoggerFactory.getLogger(DirectoryController.class);
    @Value("${directory.out}")
    private String directoryOut;

    @Value("${directory.archive_OUT}")
    private String directoryArchiveOut;

    @Value("${directory.in.deshifr}")
    private String directoryINdeshifr;

    @Value("${directory.archive_IN}")
    private String directoryArchiveIn;

    private final Config config;
    private final SchedulerService schedulerService;

    private final FileHelper fileHelper;

    @Autowired
    public DirectoryController(Config config, SchedulerService schedulerService, FileHelper fileHelper) {
        this.config = config;
        this.schedulerService = schedulerService;
        this.fileHelper = fileHelper;
    }

    @GetMapping("/copy")
    @Operation(summary = "Ручной запуск процедуры копирования из МУЛЬТИКАРТА/OUT  в filepro/IN 3 раза в день и Перемещение файлов из МУЛЬТИКАРТА/OUT в корень МУЛЬТИКАРТА/АРХИВ/OUT")
    public void copy() {
        schedulerService.copy();
    }

    @GetMapping(value = "/archive-in/{archiveDate}")
    @Operation(summary = "Получить список файлов в директории IN попадающий под выборку для архива. Введите дату в формате дд.мм.гггг (dd.mm.yyyy), например: 28.01.2023")
    public ResponseEntity<List<FileInfo>> getListFileInfo(@Parameter(description = "Месяц и Год для архивации будет выбран по этой дате", example = "01.03.2023")
                                                          @PathVariable String archiveDate) {
        log.info("UsbLog:Получить список файлов в директории попадающий под выборку для архива Введена дата для просмотра файлов:{}", archiveDate);
        List<FileInfo> fileInfoList = new ArrayList<>();
        try {
            LocalDate lDate = LocalDate.parse(archiveDate, dtf);
            fileInfoList = schedulerService.getFileInfo(directoryArchiveIn, lDate);
            if (fileInfoList.isEmpty()) {
                log.info("UsbLog: Файлов с датой {} (от даты берется месяц и год)  в каталоге - {} нет.", archiveDate, directoryArchiveIn);
            } else {
                log.info("---------------------------------");
                log.info("UsbLog: Отобрана группа файлов в количестве - {}:", fileInfoList.size());
                fileInfoList.forEach(fileInfo -> log.info("UsbLog:{}", fileInfo));
                log.info("--------------------------------");
            }
            return new ResponseEntity<>(fileInfoList, HttpStatus.OK);
        } catch (Exception e) {
            log.error("UsbLog: Error: Возникла ошибка преобразования даты, или не получен список файлов в директории");
            log.error("UsbLog: Error:  ", e);
            return new ResponseEntity<>(fileInfoList, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/archive-out/{archiveDate}")
    @Operation(summary = "Получить список файлов в директории OUT попадающий под выборку для архива. Введите дату в формате дд.мм.гггг (dd.mm.yyyy), например: 28.01.2023")
    public ResponseEntity<List<FileInfo>> getFileArchDirOut(@Parameter(description = "Месяц и Год для архивации будет выбран по этой дате", example = "01.03.2023")
                                                            @PathVariable String archiveDate) {
        log.info("UsbLog:Получить список файлов в директории попадающий под выборку для архива Введена дата для просмотра файлов:{}", archiveDate);
        List<FileInfo> fileInfoList = new ArrayList<>();
        try {
            LocalDate lDate = LocalDate.parse(archiveDate, dtf);
            fileInfoList = schedulerService.getFileInfo(directoryArchiveOut, lDate);
            if (fileInfoList.isEmpty()) {
                log.info("UsbLog: Файлов с датой {} (от даты берется месяц и год)  в каталоге - {} нет.", archiveDate, directoryArchiveIn);
            } else {
                log.info("---------------------------------");
                log.info("UsbLog: Отобрана группа файлов в количестве - {}:", fileInfoList.size());
                fileInfoList.forEach(fileInfo -> log.info("UsbLog:{}", fileInfo));
                log.info("--------------------------------");
            }
            return new ResponseEntity<>(fileInfoList, HttpStatus.OK);
        } catch (Exception e) {
            log.error("UsbLog: Error: Возникла ошибка преобразования даты, или не получен список файлов в директории");
            log.error("UsbLog: Error : ", e);
            return new ResponseEntity<>(fileInfoList, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/delete")
    @Operation(summary = "Просмотр значения параметра, разрешающего удаление файлов после архивирования. Application.properties->service.enable.delete")
    public ResponseEntity<String> getStatusDeleteEnble() {
        if (config.isServiceEnableDelete()) {
            return new ResponseEntity<>("Удаление файлов после архивирования включено!", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Удаление файлов после архивирования ВЫКЛЮЧЕНО!", HttpStatus.OK);
        }
    }

    @PutMapping(value = "/delete/{enabled}")
    @Operation(summary = "Установка значения параметра, разрешающего удаление файлов после архивирования. Учтите, что после перезагрузки сервис возьмет параметр из настроек! Application.properties->service.enable.delete.")
    public ResponseEntity<String> putServiceEnable(@PathVariable boolean enabled) {
        log.info("UsbLog: Изменение работы сервиса,  service.enabled.process={}", enabled);
        if (enabled) {
            log.info("UsbLog: Удаление файлов после архивирования Включаем!");
        } else {
            log.info("UsbLog: Удаление файлов после архивирования ВЫКЛЮЧАЕМ=false!");
        }
        config.setServiceEnableDelete(enabled);
        if (config.isServiceEnableDelete()) {
            log.info("UsbLog: Удаление файлов после архивирования включено!");
            return new ResponseEntity<>("Удаление файлов после архивирования включено!", HttpStatus.OK);
        } else {
            log.info("UsbLog:Удаление файлов после архивирования ВЫКЛЮЧЕНО!");
            return new ResponseEntity<>("Удаление файлов после архивирования ВЫКЛЮЧЕНО!", HttpStatus.OK);
        }
    }

    @PutMapping(value = "/archive-out/{archiveDate}")
    @Operation(summary = "Запустить архивацию файлов в директории OUT попадающий под выборку для архива. Введите дату в формате дд.мм.гггг (dd.mm.yyyy), например: 28.01.2023")
    public ResponseEntity<String> launchArchiveOut(@Parameter(description = "Месяц и Год для архивации будет выбран по этой дате", example = "01.03.2023")
                                                   @PathVariable String archiveDate) {
        log.info("UsbLog:Запустить архивацию файлов в директорию {} попадающий под выборку для архива Введена дата для просмотра файлов:{}", config.getDirectoryArchiveOut(), archiveDate);
        try {
            LocalDate lDate = LocalDate.parse(archiveDate, dtf);
            String fileArchive = schedulerService.launchArchFileApi(config.getDirectoryArchiveOut(), config.getDirectoryArchiveOut(), lDate);
            return new ResponseEntity<>("Создан файл архива:" + fileHelper.getWrapNull(fileArchive), HttpStatus.OK);
        } catch (Exception e) {
            log.error("UsbLog: Error: Возникла ошибка запуска процесса архивации файлов");
            log.error("UsbLog: Error: ", e);
            return new ResponseEntity<>("Возникла ошибка запуска процесса архивации файлов", HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping(value = "/archive-in/{archiveDate}")
    @Operation(summary = "Запустить архивацию файлов в директории IN попадающий под выборку для архива. Введите дату в формате дд.мм.гггг (dd.mm.yyyy), например: 28.01.2023")
    public ResponseEntity<String> launchArchiveIn(@Parameter(description = "Месяц и Год для архивации будет выбран по этой дате", example = "01.03.2023")
                                                  @PathVariable String archiveDate) {
        log.info("UsbLog:Запустить архивацию файлов в директории {} попадающий под выборку для архива Введена дата для просмотра файлов:{}", config.getDirectoryArchiveIN(), archiveDate);
        try {
            LocalDate lDate = LocalDate.parse(archiveDate, dtf);
            String fileArchive = schedulerService.launchArchFileApi(config.getDirectoryArchiveIN(), config.getDirectoryArchiveIN(), lDate);
            return new ResponseEntity<>("Создан файл архива:" + fileHelper.getWrapNull(fileArchive), HttpStatus.OK);
        } catch (Exception e) {
            log.error("UsbLog: Error: Возникла ошибка запуска процесса архивации файлов");
            log.error("UsbLog: Error: ", e);
            return new ResponseEntity<>("Возникла ошибка запуска процесса архивации файлов", HttpStatus.BAD_REQUEST);
        }
    }

}
