package ru.usb.strategists_sftp_gocpa.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.usb.strategists_sftp_gocpa.configure.Configure;

class SupportTest {

    private Support support;
    private Configure configure;

    @BeforeEach
    void setUp() {
        configure = new Configure();
        support = new Support(configure);
    }

    @Test
    void getWrapNull() {
        System.out.println(support.getWrapNull(null));
        Assertions.assertEquals("", support.getWrapNull(null));
        Assertions.assertEquals("abcd", support.getWrapNull("abcd"));
    }
}