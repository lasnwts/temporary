package ru.usb.strategists_sftp_gocpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrategistsSftpGocpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
