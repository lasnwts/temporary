package ru.usb.strategists_sftp_gocpa.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.model.FileMove;
import ru.usb.strategists_sftp_gocpa.service.dbase.GetFlowPM;
import ru.usb.strategists_sftp_gocpa.service.sftp.SftpPutFileService;

import java.io.File;
import java.time.LocalDate;

@Service
public class ApiLayer {

    Logger logger = LoggerFactory.getLogger(ApiLayer.class);

    private final Support support;
    private final GetFlowPM getFlowPM;
    private final SftpPutFileService sftpPutFileService;

    @Autowired
    public ApiLayer(Support support, GetFlowPM getFlowPM, SftpPutFileService sftpPutFileService) {
        this.support = support;
        this.getFlowPM = getFlowPM;
        this.sftpPutFileService = sftpPutFileService;
    }

    /**
     * Job выгрузка за период
     *
     * @param begin        - стартовая дата
     * @param end          - дата окончания
     * @param fileName     - имя файла
     * @param directoryOut - директория на sftp сервере
     * @return - результат
     */
    public boolean sendPeriod(LocalDate begin, LocalDate end, String fileName, String directoryOut) {
        LocalDate lData = begin;
        FileMove fileMove;
        if (begin.isAfter(end)) {
            logger.info("{}: Начальная дата:{} больше даты конца периода:{}, работу прекращаем.", Elog.UsbLogInfo,
                    support.getLocalDate(begin), support.getLocalDate(end));
            return false;
        }
        if (fileName == null) {
            logger.info("{}: Имя файла не может быть NULL", Elog.UsbLogError);
            return false;
        }
        do {
            fileMove = getFlowPM.getFlowPM(support.getDateFromLocalDate(lData), fileName); //Change Result
            lData = lData.plusDays(1);
        } while (lData.isBefore(end.plusDays(1)) || !fileMove.isResult());
        if (fileMove.isResult()) {
            return sftpPutFileService.putFileToSftp(fileMove.getFile(), directoryOut, true);
        } else {
            return false;
        }
    }

    /**
     * Отправка единичного файлв на sftp сервер
     *
     * @param file         - файл
     * @param directoryOut - директория на sftp сервере
     * @param delFile      - true - удалить файл, после отправки
     * @return - результат (true - успех)
     */
    public boolean sendGOCPA(File file, String directoryOut, boolean delFile) {
        return sftpPutFileService.putFileToSftp(file, directoryOut, delFile);
    }
}
