package ru.usb.strategists_sftp_gocpa.service.sftp;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;


import java.io.File;

@Service
public class SftpGetFile {

    private Configure configure;

    @Autowired
    public SftpGetFile(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(SftpGetFile.class);

    /**
     * Передача файла с сервера sftp
     */
    public File getFileFromSftp(String file, String sftpDir) {

        /**
         * Создаем соединение
         */
        JSch jSch = new JSch();

        /**
         * Создаем сессию
         */
        Session session = null;
        try {
            if (configure.isSftpNeedKey()) {
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            ChannelSftp channel = null;
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            channel.cd("/" + sftpDir);
            if (!channel.stat(file).isDir()) {
                channel.get(file, configure.getNetFileShare() + File.separator + file);
                logger.info("{}:File={} download successfully from sftp, to directory:{}{}{}", Elog.UsbLogInfo, file, configure.getSftpDirectoryToBank(), File.separator, file);
                //Закрываем соединение
                setFinalConnected(session, channel);
            } else {
                logger.info("{} данный объект - не файл а директория: {}", Elog.UsbLogInfo, file);
                return null;
            }
        } catch (JSchException e) {
            logger.error("{}:SftpService:GetFileToSftp(file).Session = Error!!", Elog.UsbLogError);
            logger.error("{}: Session.error::", Elog.UsbLogError, e);
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            return null;
        } catch (SftpException e) {
            if (session.isConnected()) {
                session.disconnect();
            }
            logger.error("{}: SftpService:GetFileToSftp(file).channel.cd({})", Elog.UsbLogError, configure.getSftpDirectory());
            logger.error("{}:channel.cd.error::", Elog.UsbLogError, e);
            logger.error("{}:SftpService:GetFileToSftp(file).channel.get({})", Elog.UsbLogError, sftpDir + "/" + file);
            logger.error("{}: channel.Get.error::", Elog.UsbLogError, e);
            return null;
        }


        File f = new File(configure.getNetFileShare() + File.separator + file);
        logger.info("{}: Загружен файл с сервера SFTP:{}", Elog.UsbLogInfo, f.getAbsolutePath());
        /**
         * Тут логика обработки файла
         */
        return f; //Файл успешно загружен
    }


    /**
     * закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }
}
