package ru.usb.strategists_sftp_gocpa.service.sftp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.utils.Support;


import java.util.List;

@Service
public class DownLoadService {

    private final SftpListFileService sftpListFileService;
    private final SftpDelFileService sftpDelFileService;
    private final SftpGetFile sftpGetFile;
    private final Configure configure;
    private final Support support;

    @Autowired
    public DownLoadService(SftpListFileService sftpListFileService, SftpDelFileService sftpDelFileService,
                           SftpGetFile sftpGetFile, Configure configure, Support support) {
        this.sftpListFileService = sftpListFileService;
        this.sftpDelFileService = sftpDelFileService;
        this.sftpGetFile = sftpGetFile;
        this.configure = configure;
        this.support = support;
    }

    Logger logger = LoggerFactory.getLogger(DownLoadService.class);

    /**
     * Получаем файлы и скачиваем с sftp
     */
    public void getFileFromSftp() {
        List<String> fileToSftp = sftpListFileService.getListFileToSftp(configure.getSftpDirectoryToBank());
        fileToSftp.forEach(str -> {
            logger.info("{}: Обнаружен файл:{}", Elog.UsbLogInfo, str);
            if (support.moveFileSName(sftpGetFile.getFileFromSftp(str, configure.getSftpDirectoryToBank()), configure.getDirectoryArchivedFromSftp())) {
                logger.info("{}: Удаляем файл:{}/{}", Elog.UsbLogInfo, configure.getSftpDirectoryToBank(), str);
                sftpDelFileService.delFile(str, configure.getSftpDirectoryToBank());
            }
        });
    }
}
