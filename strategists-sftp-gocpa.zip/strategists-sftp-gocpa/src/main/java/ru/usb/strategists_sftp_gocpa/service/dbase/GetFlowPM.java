package ru.usb.strategists_sftp_gocpa.service.dbase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.model.FileMove;
import ru.usb.strategists_sftp_gocpa.model.FlowPM;
import ru.usb.strategists_sftp_gocpa.repository.JpaFlowPM;
import ru.usb.strategists_sftp_gocpa.service.FileWriter;
import ru.usb.strategists_sftp_gocpa.service.mail.EmailServiceImpl;
import ru.usb.strategists_sftp_gocpa.service.mail.ServiceMailError;
import ru.usb.strategists_sftp_gocpa.utils.Support;


import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.stream.Stream;

/**
 * 08.05.2024 - внесены изменения по требованию, см. ниже.
 */

@Service
public class GetFlowPM {

    Logger logger = LoggerFactory.getLogger(GetFlowPM.class);

    private final Configure configure;
    private final Support support;
    private final JpaFlowPM jpaFlowPM;
    private final EntityManager entityManager;
    private final ServiceMailError sendMailError;
    private final EmailServiceImpl emailService;

    String fullFileNameCSV;
    //Количество строк
    int lineCount;

    public GetFlowPM(Configure configure, Support support, JpaFlowPM jpaFlowPM, EntityManager entityManager,
                     ServiceMailError sendMailError, EmailServiceImpl emailService) {
        this.configure = configure;
        this.support = support;
        this.jpaFlowPM = jpaFlowPM;
        this.entityManager = entityManager;
        this.sendMailError = sendMailError;
        this.emailService = emailService;
    }


    @Transactional(readOnly = true)
    public FileMove getFlowPM(Date data, String fileName) {

        //Получаем список записей из базы
        Stream<FlowPM> fTableStream = null;

        try {
            int recordCount = jpaFlowPM.getCountPM(support.getSSDate(data));
            logger.info("{} Число записей в таблице: GOCPA={}", Elog.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                logger.info("{} Поскольку число записей в таблице: SEND_GOCPA=0, то обработку завершаем! ->false", Elog.UsbLogInfo);
                return new FileMove(false, "Поскольку число записей в таблице: SEND_GOCPA=0, то обработку завершаем!", HttpStatus.BAD_REQUEST, null);
            }
            fTableStream = jpaFlowPM.getFlowPM(support.getSSDate(data));
            if (!support.checkStreamTable(fTableStream)) {
                logger.error("{} fTableStream = jpaFlowPM.getFlowPM() - поток вернулся = NULL! Так быть не должно!", Elog.UsbLogError);
                return new FileMove(false, "fTableStream = jpaFlowPM.getFlowPM() - поток вернулся = NULL! Так быть не должно!", HttpStatus.BAD_REQUEST, null);
            }
        } catch (Exception e) {
            logger.error("{}:Возникла ошибка, получения потока из БД: fTableStream = jpaFlowPM.getFlowPM()", Elog.UsbLogError);
            logger.error("{}:Print stack:", Elog.UsbLogError, e);
            emailService.sendSimpleEmail(configure.getMailToBusiness(), support.getWrapNull(configure.getMailSubjects())
                            + " Ошибка доступа к витрине данных SEND_GOCPA. <Передача реестра заявок в goCPA>"
                    , " Возникла ошибка при обращении к витрине SEND_GOCPA \n\r" + "Описание: " + e.getMessage());
            sendMailError.sendMailErrorSubject(support.getWrapNull(configure.getMailSubjects())
                            + " Ошибка доступа к витрине данных SEND_GOCPA. <Передача реестра заявок в goCPA>"
                    , " Возникла ошибка при обращении к витрине SEND_GOCPA \n\r" + "Описание: " + e.getMessage());
            return new FileMove(false, "Возникла ошибка, получения потока из БД: fTableStream = jpaFlowPM.getFlowPM()" + e.getMessage(), HttpStatus.BAD_REQUEST, null);
        }


        logger.info("{}:###################### < Starting the process Flow PM of unloading data from a table to a file > ##############################", Elog.UsbLogError);
        lineCount = 0; //Обнулили счетчик записей, строк
        fullFileNameCSV = configure.getTempDirUploadFile() + File.separator + fileName; //Создаем файл во временной директории

        try {
            fTableStream.forEach(fTable -> {
                logger.debug(fTable.toString());
                /**
                 * Фильтруем строку Points = 0, и где LoyaltyId не пустой
                 */
                if (checkRecord(fTable)) {
                    try {
                        FileWriter.write(fullFileNameCSV, support.getCsdf(fTable.getCreatedDate()) + ";" +
                                support.getComma(support.getWrapNull(fTable.getActionDate())) + ";" +
                                support.getComma(support.getWrapNull(fTable.getPartnerId())) + ";" +
                                support.getComma(support.getWrapNull(fTable.getRefId())) + ";" +
                                support.getComma(support.getWrapNull(fTable.getSessionUuid())) + ";" +
                                support.getComma(support.getWrapNull(fTable.getOfferId())) + ";" +
                                support.getComma(support.getWrapNull(fTable.getIsActive1000()))
                        );
                    } catch (IOException e) {
                        logger.error("{}: Ошибка в процессе выгрузки записей из Базы в файл FileWriter.write:{}", Elog.UsbLogError, e.getMessage());
                        logger.error("{}: Ошибка в процессе выгрузки записей из Базы в файл. Ошибка на записи={}", Elog.UsbLogError, fTable);
                        logger.debug("{}:StackTrace", Elog.UsbLogError, e);
                        sendEmail(e.getMessage());
                    }
                    lineCount = lineCount + 1; //Подсчитываем число записей в файле
                }
                entityManager.detach(fTable);
            });
            logger.info("{}:Выгружено записей:{}", Elog.UsbLogInfo, lineCount);
            logger.info("{}:Output data in File ={}", Elog.UsbLogInfo, fullFileNameCSV);
        } catch (Exception e) {
            logger.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", Elog.UsbLogError);
            logger.error("{}:Произошла ошибка при работе потока чтения данных из таблицы и записи в файл:{}", Elog.UsbLogError, e.getMessage());
            logger.debug("{}:!PrintStackTrace:", Elog.UsbLogError, e);
            sendEmail(e.getMessage());
            return new FileMove(false, "Произошла ошибка при работе потока чтения данных из таблицы и записи в файл:" + e.getMessage(), HttpStatus.BAD_REQUEST, null);
        } finally {
            fTableStream.close();
        }
        /**
         * Отправка файла в sftp
         */
        return new FileMove(true, "", HttpStatus.OK, new File(fullFileNameCSV));
    }

    private void sendEmail(String ex) {
        try {
            sendMailError.sendMailError("Возникла ошибка Starting the process Flow PM " + "\n\r" + " Сообщение о ошибке:" + ex);
        } catch (Exception exception) {
            logger.error("{}:UsbLog:Возникла ошибка при отправке письма [  serviceMailError.sendMailError] Exception:{}", Elog.UsbLogError, exception.getMessage());
            logger.error("{}:UsbLog:Возникла ошибка при отправке письма [  serviceMailError.sendMailError] Stack Trace:", Elog.UsbLogError, exception);
        }
    }

    /**
     * Проверка полноты записи
     *
     * @param flowPM
     * @return
     */
    private boolean checkRecord(FlowPM flowPM) {
        return flowPM != null && flowPM.getActionDate() != null && !flowPM.getActionDate().isEmpty()
                && flowPM.getCreatedDate() != null
                && flowPM.getPartnerId() != null && !flowPM.getPartnerId().isEmpty()
                && flowPM.getRefId() != null && !flowPM.getRefId().isEmpty()
                && flowPM.getSessionUuid() != null && !flowPM.getSessionUuid().isEmpty()
                && flowPM.getOfferId() != null && !flowPM.getOfferId().isEmpty()
                && flowPM.getIsActive1000() != null && !flowPM.getIsActive1000().isEmpty()
                && flowPM.getIsCardIssued() != null && !flowPM.getIsCardIssued().isEmpty();
    }
}