package ru.usb.strategists_sftp_gocpa.repository;

/**
 * Параметры подключения к витрине:
 * Сервер стратегического планирования: msk-ds02sds.fc.uralsibbank.ru [IP 10.167.76.36]
 * Порт: 1523
 * наименование сервиса: marktpr2
 * Схема: DGTL
 *
 * C компьютера
 *    Имя компьютера  . . . . . . . . . : SPB01-S50307
 *    IPv4-адрес. . . . . . . . . . . . : 10.61.79.89(Основной)
 *
 * 4. Организовать папки для работы с системой передачи. Т.е. определиться, на каких сетевых ресурсах будет находится файлы для отправки в SFTP.
 * 5. Определиться, куда записывать получаемые из SFTP файлы.
 * 6. Если требуются архивы, то куда копировать файлы для ведения архивов.
 */

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.strategists_sftp_gocpa.model.FlowPM;


import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JpaFlowPM extends JpaRepository<FlowPM, Long> {

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select created_date, action_date, partner_id, ref_id, session_uuid, offer_id, is_card_issued, is_active_1000 from send_gocpa where action_date like :sdate")
    Stream<FlowPM> getFlowPM(String sdate);

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select created_date, action_date, partner_id, ref_id, session_uuid, offer_id, is_card_issued, is_active_1000 from send_gocpa where action_date like :sdate")
    List<FlowPM> getListFlowPM(String sdate);

    //Функция возвращает список всех записей
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "105"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "select created_date, action_date, partner_id, ref_id, session_uuid, offer_id, is_card_issued, is_active_1000 from send_gocpa where ROWNUM < 101")
    List<FlowPM> get100ListFlowPM();

    //Функция возвращает количество записей
    @QueryHints(value = {
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    //@Query(nativeQuery = true, value = "select count(*) from send_gocpa")
    @Query(nativeQuery = true, value = "select count(*) from send_gocpa where action_date like :sdate")
    int getCountPM(String sdate);

}
