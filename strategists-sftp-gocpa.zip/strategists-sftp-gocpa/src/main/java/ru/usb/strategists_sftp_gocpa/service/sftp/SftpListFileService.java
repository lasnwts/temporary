package ru.usb.strategists_sftp_gocpa.service.sftp;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

@Service
public class SftpListFileService {
    private final Configure configure;

    @Autowired
    public SftpListFileService(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(SftpListFileService.class);

    /**
     * Передача файла на сервер sftp
     */
    public List<String> getListFileToSftp(String sftpDirectory) {

        // Создаем соединение
        JSch jSch = new JSch();
        /**
         * Создаем сессию
         *         jSch.setKnownHosts(known_hosts);
         *         jSch.addIdentity(sftp_key);
         *         Session session = jSch.getSession(sftp_user, host, port);
         */
        Session session = null;
        //Создаем канал
        ChannelSftp channel = null;
        //         * Получаем список файлов
        List<String> listFiles = new ArrayList<>();
        try {
            if (configure.isSftpNeedKey()){
                jSch.addIdentity(configure.getSftpKeyFile());
            }
            session = jSch.getSession(configure.getSftpUser(), configure.getSftpHost(), configure.getSftpPort());
            session.setPassword(configure.getSftpPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            Vector<ChannelSftp.LsEntry> filelist = channel.ls(sftpDirectory);
            for (ChannelSftp.LsEntry lsEntry : filelist) {
                if (lsEntry.getFilename().equals(".") || lsEntry.getFilename().equals("..")) {
                    //Тут ничего не надо
                } else {
                    listFiles.add(lsEntry.getFilename());
                }
            }
        } catch (JSchException e) {
            logger.error("{}:SftpService:getListFileToSftp.Session = Error!!", Elog.UsbLogError);
            logger.error("{}:Session.error::", Elog.UsbLogError, e);
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            if (channel != null && channel.isConnected()) {
                channel.disconnect();
            }
            return Collections.emptyList();
        } catch (SftpException e) {
            logger.error("{}:SftpService:getListFileToSftp(file).channel.ls(sftpDirectory)({})", Elog.UsbLogError, sftpDirectory);
            logger.error("{}: channel.list.error:list files:", Elog.UsbLogError, e);
            setFinalConnected(session, channel);
            return Collections.emptyList();
        }
        //Закрываем соединение
        setFinalConnected(session, channel);
        return listFiles; //Список файлов
    }

    /**
     * закрытие соединений
     *
     * @param session - сессия
     * @param channel - канал
     */
    private void setFinalConnected(Session session, ChannelSftp channel) {
        if (channel.isConnected()) {
            channel.disconnect();
        }
        if (session.isConnected()) {
            session.disconnect();
        }
    }

}
