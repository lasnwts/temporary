package ru.usb.strategists_sftp_gocpa.utils;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.model.FlowPM;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.stream.Stream;


/**
 * Вспомогательный класс для работы
 */
@Component
public class Support {

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    Logger logger = LoggerFactory.getLogger(Support.class);
    /**
     * формат даты-времени
     */
    LocalDate date;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    SimpleDateFormat sdfHead = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat sdfPartName = new SimpleDateFormat("ddMMyy");
    SimpleDateFormat hourPart = new SimpleDateFormat("HH");
    DateTimeFormatter formatterHeader = DateTimeFormatter.ofPattern("yyyyMMdd");
    SimpleDateFormat csdf = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");
    //GOCPA_URSB.ггггммддчч:мм
    SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHH.mm");
    SimpleDateFormat checkDate = new SimpleDateFormat("dd.MM.yyyy");

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * Провекра, что поток не NULL
     *
     * @param fTableStream - поток
     * @return
     */
    public boolean checkStreamTable(Stream<FlowPM> fTableStream) {
        if (fTableStream == null) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!+++");
            logger.error("!!!!!!!!!!!!! fTableStream==null");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!----");
            return false;
        }
        return true;
    }



    /**
     * Получаем сумму для PM файла.
     * Формат без разделителя - запятой.
     * Пример 164.78 = '16478' или 164.7 = '16470'
     *
     * @param summa - строка суммы
     * @return - готовое значение
     */

    public String getSummaFormatter(String summa) {
        if (summa == null) {
            return "";
        }
        if (summa.contains(".")) {
            String firstPart = summa.trim().substring(0, summa.indexOf("."));
            String secondPart = summa.trim().substring(summa.indexOf(".") + 1, summa.length());
            if (firstPart.equals(".")) {
                firstPart = "";
            }
            if (secondPart.isEmpty()) {
                secondPart = "00";
            }
            if (secondPart.length() == 1) {
                secondPart = secondPart + "0";
            }
            if (secondPart.length() > 2) {
                logger.error("Передана сумма с ошибкой, число после запятой должно быть 2, передано больше! SUMMA={}", summa);
                secondPart = secondPart.substring(0, 1);
            }
            if (configure.isLogDebug()) {
                String line = firstPart + secondPart;
                logger.info("Преобразование суммы [getSummaFormatter], пришло: {} после преобразования: {} ", summa, line);
            }
            return firstPart + secondPart;
        } else {
            if (configure.isLogDebug()) {
                String line = summa.trim() + "00";
                logger.info("Преобразование суммы [getSummaFormatter], пришло:  {} после преобразования: {} ", summa, line);
            }
            return summa.trim() + "00";
        }
    }

    /**
     * Получаем имя фала
     *
     * @return - готовое имя файла
     */
    public String getFileName() {
        return "GOCPA_URSB" + getDatePartName();
    }

    /**
     * Часть даты + час, пример 10.04.2024 12 часов => 1004242
     *
     * @return - возвращает 1004242
     */
    private String getDatePartName() {
        return fdf.format(new Date());
    }


    /**
     * Проверка существования файла
     *
     * @param fileNameFull - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(File fileNameFull) {
        if (fileNameFull == null) {
            return false;
        }
        Path path = Paths.get(fileNameFull.getAbsolutePath());
        if (Files.exists(path)) {
            return true;
        }
        logger.info("{}: File :: [{}] not Exist.Fail!", Elog.UsbLogWarning, fileNameFull);
        return false;
    }

    /**
     * Экранирование двойных кавычек.
     *
     * @param line
     * @return
     */
    public String getDoubleQuote(String line) {
        return "\"" + getWrapNull(line).replace("\"", "\"\"") + "\"";
    }


    /**
     * Перенос файлов, представленных строковым именем
     *
     * @param fromFile             откуда (полный путь с именем)
     * @param destinationDirectory - куда (полный путь с именем)
     */
    public boolean moveFileSName(File fromFile, String destinationDirectory) {
        if (fromFile == null) {
            return false;
        }
        Path from = fromFile.toPath();
        Path to = Paths.get(destinationDirectory + FileSystems.getDefault().getSeparator() + fromFile.getName());
        try {
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
            if (checkFileExists(to.toFile())) {
                FileUtils.forceDelete(from.toFile());
                logger.info("{}: file:: {} moved to:{}", Elog.UsbLogError, from, to);
                return true;
            } else {
                logger.error("{}: Error for operation move:: file::{} moved to:{}", Elog.UsbLogError, from, to);
                return false;
            }
        } catch (IOException e) {
            logger.error("{}:PrintStackTrace::", Elog.UsbLogError, e);
            return false;
        }
    }

    /**
     * Получаем дату в формате yyyyMMdd
     *
     * @return - строка с датой
     */
    public String getDate() {
        return sdfHead.format(new Date()) + "%";
    }

    /**
     * Получаем дату в формате yyyyMMdd
     *
     * @return - строка с датой
     */
    public String getSSDate(Date data) {
        return sdfHead.format(data) + "%";
    }

    /**
     * Получаем дату в строке формата dd.MM.yyyy hh:mm:ss
     *
     * @param date
     * @return - dd.MM.yyyy hh:mm:ss
     */
    public String getCsdf(java.sql.Date date) {
        return csdf.format(date);
    }

    /**
     * Экранирование строки и спец. символов
     *
     * @param line
     * @return
     */
    public String getComma(String line) {
        if (line != null && line.isEmpty()) {
            return "";
        }
        //Если поле содержит двойные кавычки, то все поле заключается в двойные кавычки и двойная кавычка
        // экранируется также двойной кавычкой: Пример - "Тестовый ""Тест"""
        if (line != null && line.contains("\"")) {
            return "\"" + line.trim().replace("\"", "\"\"") + "\"";
        }
        if (line != null && line.contains(";")) {
            return "\"" + line.trim() + "\"";
        }
        return line; //Если ничего нет возвращаем ту же строку
    }

    /**
     * формат даты-времени
     */
    LocalDate lDate;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yy HH:mm
     */
    public boolean checkDate(String sDate) {
        try {
            LocalDate.parse(sDate, formatter);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:[checkDate] Дата:{} =>  не соответствует формату :dd.mm.yyyy", Elog.UsbLogInfo, sDate);
            return false;
        }
    }

    /**
     * Преобразование строковой даты типа "dd.MM.yy HH:mm:ss" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate parseDate(String sDate) {
        try {
            return LocalDate.parse(sDate, formatter);
        } catch (DateTimeException dateTimeException) {
            logger.error("{}:[parseDate] Дата:{} =>  не соответствует формату :dd.mm.yyyy", Elog.UsbLogInfo, sDate);
            return null;
        }
    }

    /**
     * Получаем строку из даты
     *
     * @param data - LocalDate
     * @return - строка
     */
    public String getLocalDate(LocalDate data) {
        return data.format(formatter);
    }

    /**
     * Преобразование типов дат
     *
     * @param localDate - дата в LocalDate
     * @return - date (Date.Util)
     */
    public Date getDateFromLocalDate(LocalDate localDate) {
        return java.sql.Date.valueOf(localDate);
    }
}
