package ru.usb.strategists_sftp_gocpa.model;

import org.springframework.http.HttpStatus;

import java.io.File;

/**
 * Класс для отправки файла
 */
public class FileMove {
    private boolean result; //Успех true, неудача false
    private String message; //Строка для передачи сообщений
    private HttpStatus status; //передача статуса
    private File file; //файл для передачи

    public FileMove(boolean result, String message, HttpStatus status, File file) {
        this.result = result;
        this.message = message;
        this.status = status;
        this.file = file;
    }

    public FileMove() {
        //Пустой конструктор
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    @Override
    public String toString() {
        return "FileMove{" +
                "result=" + result +
                ", message='" + message + '\'' +
                ", status=" + status +
                ", file name=" + file.getName() +
                '}';
    }
}
