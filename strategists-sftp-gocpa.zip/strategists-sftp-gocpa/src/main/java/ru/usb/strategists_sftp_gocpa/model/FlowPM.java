package ru.usb.strategists_sftp_gocpa.model;

import javax.persistence.*;
import java.sql.Date;


/**
 * created_date, action_date, partner_id, ref_id, session_uuid, offer_id, is_card_issued, is_active_1000

 */

@Entity
public class FlowPM {

    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "action_date")
    private String actionDate;
    @Column(name = "partner_id")
    private String partnerId;
    @Column(name = "ref_id")
    private String refId;
    @Column(name = "session_uuid")
    @Id
    private String sessionUuid;
    @Column(name = "offer_id")
    private String offerId;
    @Column(name = "is_card_issued")
    private String isCardIssued;
    @Column(name = "is_active_1000")
    private String isActive1000;

    public FlowPM() {
        //
    }

    public FlowPM(Date createdDate, String actionDate, String partnerId, String refId, String sessionUuid,
                  String offerId, String isCardIssued, String isActive1000) {
        this.createdDate = createdDate;
        this.actionDate = actionDate;
        this.partnerId = partnerId;
        this.refId = refId;
        this.sessionUuid = sessionUuid;
        this.offerId = offerId;
        this.isCardIssued = isCardIssued;
        this.isActive1000 = isActive1000;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getSessionUuid() {
        return sessionUuid;
    }

    public void setSessionUuid(String sessionUuid) {
        this.sessionUuid = sessionUuid;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getIsCardIssued() {
        return isCardIssued;
    }

    public void setIsCardIssued(String isCardIssued) {
        this.isCardIssued = isCardIssued;
    }

    public String getIsActive1000() {
        return isActive1000;
    }

    public void setIsActive1000(String isActive1000) {
        this.isActive1000 = isActive1000;
    }

    @Override
    public String toString() {
        return "FlowPM{" +
                "createdDate=" + createdDate +
                ", actionDate='" + actionDate + '\'' +
                ", partnerId='" + partnerId + '\'' +
                ", refId='" + refId + '\'' +
                ", sessionUuid='" + sessionUuid + '\'' +
                ", offerId='" + offerId + '\'' +
                ", isCardIssued='" + isCardIssued + '\'' +
                ", isActive1000='" + isActive1000 + '\'' +
                '}';
    }
}
