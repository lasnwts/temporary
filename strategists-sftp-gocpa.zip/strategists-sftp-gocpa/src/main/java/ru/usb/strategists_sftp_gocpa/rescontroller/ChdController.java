package ru.usb.strategists_sftp_gocpa.rescontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.repository.JpaFlowPM;
import ru.usb.strategists_sftp_gocpa.service.dbase.GetFlowPM;
import ru.usb.strategists_sftp_gocpa.utils.ApiLayer;
import ru.usb.strategists_sftp_gocpa.utils.Support;

import java.util.Date;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Контроллер для работы с Базой Данных. Версия 0.0.10", description = "<Автоматизация процесса начисления бонусов по акциям>")
public class ChdController {

    private final JpaFlowPM jpaFlowPM;
    private final GetFlowPM getFlowPM;
    private final Support support;
    private final ApiLayer apiLayer;
    private final Configure configure;

    @Autowired
    public ChdController(JpaFlowPM jpaFlowPM, GetFlowPM getFlowPM, Support support, ApiLayer apiLayer, Configure configure) {
        this.jpaFlowPM = jpaFlowPM;
        this.getFlowPM = getFlowPM;
        this.support = support;
        this.apiLayer = apiLayer;
        this.configure = configure;
    }

    private final Logger logger = LoggerFactory.getLogger(ChdController.class);

    @GetMapping("/count/{data}")
    @Operation(summary = "Запрос на получение количества записей в таблице SEND_GOCPA для определенной даты. Формат YYYYMMDD, например:для даты 26.09.2024 надо ввести строку:20240926")
    public ResponseEntity<String> getCount(@Parameter(description = "YYYYMMDD")
                                           @PathVariable("data") String data) {
        logger.info("{}: Запрос количества записей в таблице SEND_GOCPA для даты:{}", Elog.UsbLogInfo, data);
        try {
            return ResponseEntity.status(HttpStatus.OK).body("Количество записей в таблице:[" + jpaFlowPM.getCountPM(data + "%") + "]");
        } catch (Exception ex) {
            logger.error("{}: Ошибка получения количества записей в таблице SEND_GOCPA", Elog.UsbLogError, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка получения количества записей в таблице SEND_GOCPA:" + ex.getMessage());
        }
    }

    @GetMapping("/record100")
    @Operation(summary = "Запрос на получение 100 первых записей из SEND_GOCPA. Чтобы понять что записи есть")
    public ResponseEntity<Object> get100Record() {
        logger.info("{}: Запрос на получение 100 записей в таблице SEND_GOCPA", Elog.UsbLogInfo);
        try {
            return ResponseEntity.status(HttpStatus.OK).body(jpaFlowPM.get100ListFlowPM());
        } catch (Exception ex) {
            logger.error("{}: Ошибка получения 100 количества записей в таблице SEND_GOCPA", Elog.UsbLogError, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка получения 100 всех записей из таблице SEND_GOCPA:" + ex.getMessage());
        }
    }

    @GetMapping("/record/{data}")
    @Operation(summary = "Запрос на получение записей из SEND_GOCPA за выбранный день")
    public ResponseEntity<Object> getRecord(@Parameter(description = "YYYYMMDD")
                                            @PathVariable("data") String data) {
        logger.info("{}: Запрос на получение всех записей в таблице SEND_GOCPA", Elog.UsbLogInfo);
        try {
            return ResponseEntity.status(HttpStatus.OK).body(jpaFlowPM.getListFlowPM(data + "%"));
        } catch (Exception ex) {
            logger.error("{}: Ошибка получения количества записей в таблице SEND_GOCPA", Elog.UsbLogError, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка получения всех записей из таблице SEND_GOCPA:" + ex.getMessage());
        }
    }


    @PutMapping("/start")
    @Operation(summary = "Запуск выгрузки за текущий день записей из SEND_GOCPA и отправки на сервер SFTP.")
    public ResponseEntity<String> startUploadPmFile() {
        if (apiLayer.sendGOCPA(getFlowPM.getFlowPM(new Date(), support.getFileName()).getFile(), configure.getSftpDirectory(), true)) {
            return ResponseEntity.status(HttpStatus.OK).body("Файл успешно сформирован и отправлен на сервере sftp");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Произошла ошибка при формировании и отправке файла PM на sftp сервер");
        }
    }

    @PutMapping("/period/{begin}-{end}")
    @Operation(summary = "Запуск выгрузки за период записей из SEND_GOCPA и отправки на сервер SFTP.")
    public ResponseEntity<String> startPeriodUploadPmFile(@Parameter(description = "dd.mm.yyyy")
                                                          @PathVariable("begin") String begin,
                                                          @Parameter(description = "dd.mm.yyyy")
                                                          @PathVariable("end") String emd) {
        logger.info("{}: Получен запрос на выгрузку c даты:{} по дату:{}", Elog.UsbLogInfo, begin, emd);
        if (!support.checkDate(begin) && !support.checkDate(support.getFileName())) {
            logger.info("{}: Ошибка ввода диапазона дат. Дата старта={}, дата конца периода={}", Elog.UsbLogInfo, begin, emd);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Ошибка ввода диапазона дат. Дата должна быть в формате dd.mm.yyyy");
        }
        if (apiLayer.sendPeriod(support.parseDate(begin), support.parseDate(emd), support.getFileName(), configure.getSftpDirectory())) {
            return ResponseEntity.status(HttpStatus.OK).body("Файл успешно сформирован и отправлен на сервере sftp");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Произошла ошибка при формировании и отправке файла PM на sftp сервер");
        }
    }

}
