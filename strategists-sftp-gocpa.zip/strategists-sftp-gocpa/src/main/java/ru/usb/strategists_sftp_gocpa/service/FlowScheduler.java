package ru.usb.strategists_sftp_gocpa.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.strategists_sftp_gocpa.configure.Configure;
import ru.usb.strategists_sftp_gocpa.configure.Elog;
import ru.usb.strategists_sftp_gocpa.model.FileMove;
import ru.usb.strategists_sftp_gocpa.service.dbase.GetFlowPM;
import ru.usb.strategists_sftp_gocpa.service.mail.EmailServiceImpl;
import ru.usb.strategists_sftp_gocpa.service.sftp.DownLoadService;
import ru.usb.strategists_sftp_gocpa.service.sftp.SftpPutFileService;
import ru.usb.strategists_sftp_gocpa.utils.Support;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class FlowScheduler {

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    private final GetFlowPM getFlowPM;
    private final EmailServiceImpl emailService;
    private final Configure configure;
    private boolean tryGetPm16hour = false; //Попробовать сформировать файл в 16 часов?
    private final DownLoadService downLoadService;
    private final Support support;
    private final SftpPutFileService sftpPutFileService;

    @Autowired
    public FlowScheduler(GetFlowPM getFlowPM, EmailServiceImpl emailService, Configure configure,
                         DownLoadService downLoadService, Support support, SftpPutFileService sftpPutFileService) {
        this.getFlowPM = getFlowPM;
        this.emailService = emailService;
        this.configure = configure;
        this.downLoadService = downLoadService;
        this.support = support;
        this.sftpPutFileService = sftpPutFileService;
    }

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    /**
     * Scheduler 1.  На 12 часов в будни, с понедельника по пятницу
     */
    @Scheduled(cron = "${interval-in-cron12}")
    public void cronScheduler12() {
        logger.info("{} Сработал таймер на 12 часов дня. ", Elog.UsbLogInfo);
        FileMove fileMove = getFlowPM.getFlowPM(new Date(), support.getFileName());
        if (fileMove.isResult() && sftpPutFileService.putFileToSftp(fileMove.getFile(), configure.getSftpDirectory(), true)) {
            tryGetPm16hour = false; //Передавать не надо, в 12 часов все передано
            logger.info("{}: Файл PM сформирован и передан успешно, отработка в 16 часов не нужна. successPmFile12Hour. tryGetPm16hour={}", Elog.UsbLogInfo, false);
        } else {
            tryGetPm16hour = true; //требуется попробовать передать файл в 16 часов
            logger.info("{}: Возникла проблема (возможно нет данных в таблице) при формировании или передаче файла PM в 12 часов. Необходимо повторить попытку в 16 часов.tryGetPm16hour={}", Elog.UsbLogInfo, true);
            logger.info("{}: Описание ошибки: {} ", Elog.UsbLogError, fileMove.getMessage());
        }
    }

    /**
     * Scheduler 2.  На 16 часов в будни, с понедельника по пятницу
     */
    @Scheduled(cron = "${interval-in-cron16}")
    public void cronScheduler16() {
        if (tryGetPm16hour){
            logger.info("{} Сработал таймер на 16 часов дня. ", Elog.UsbLogInfo);
            if(sftpPutFileService.putFileToSftp(getFlowPM.getFlowPM(new Date(), support.getFileName()).getFile(), configure.getSftpDirectory(), true)){
               logger.info("{} Файл PM успешно сформирован и передан в 16 часов. Обработку на сегодня {} завершаем", Elog.UsbLogInfo, new Date());
           } else {
               logger.info("{} Возникла проблема [cronScheduler16]  при формировании или передаче файла PM в 16 часов. Будет отправлен alert на email.", Elog.UsbLogWarning);
               //Тут надо отправить письмо
               emailService.sendSimpleEmail(configure.getMailToBusiness(), configure.getMailSubjects()
                       + "Alert! Витрина <Автоматизация процесса начисления бонусов по акциям> [SEND_GOCPA] пуста! Дата=" + sdf.format(new Date()) ,
                       "Повторное обращение к витрине в 16-00. Витрина пуста. Согласно требованиям - отправляем данное письмо. <br> \n\r Требование:<br>\\ Если при штатном обращении ИС к витрине данных обновленных записей не найдено, \n\r <br> то выполнить повторное обращение к витрине в 16:00, если при повторном обращение новых данных не найдено, то создать EMAIL_ALERT");
           }
            tryGetPm16hour = false; //отключаем таймер на 16 часов
        }

    }

    /**
     * Scheduler every 10 - 15 mib.
     */
    @Scheduled(initialDelay = 1000L, fixedDelayString = "${scheduler.delay}")
    public void updatePrices() {
        //Тут обработка входящих файлов
        downLoadService.getFileFromSftp();
    }

}
