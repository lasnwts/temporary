package ru.usb.oracleCursor;

import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.*;

@Service
public class ProcedureCursorCallable {




    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.username}")
    private String user;
    @Value("${spring.datasource.password}")
    private String pass;

    @Value("${ibso.schema}")
    private String ibsoSchema;
    @Value("${ibso.catalog}")
    private String ibsoCatalog;
    @Value("${ibso.procedure}")
    private String ibsoProcedure;

    @Value("${ibso.wait}")
    private int ibsoWait;
    @Value("${ibso.timeout}")
    private int ibsoTimeout;
    @Value("${ibso.timeoutErr}")
    private int ibsoTimeoutErr;

    public void getCursor(){

        try
            ( Connection conn = DriverManager.getConnection(url, user, pass);
            CallableStatement proc = conn.prepareCall("{call " + ibsoProcedure + "(?)}")){
                proc.registerOutParameter(1, OracleTypes.CURSOR);
                proc.setQueryTimeout(ibsoTimeout);
                proc.execute();
                ResultSet results = (ResultSet) proc.getObject(1);

            System.out.println("");
            System.out.println("");
                while (results.next()){
                    System.out.print(" | ");
                    System.out.print(results.getString("USER_ID"));
                    System.out.print(" | ");
                    System.out.print(results.getString("USERNAME"));
                    System.out.print(" | ");
                    System.out.print(results.getString("CREATED_BY"));
                    System.out.print(" | ");
                    System.out.print(results.getString("CREATED_DATE"));
                    System.out.println(" | ");
                }

            proc.close();
            if (proc.isClosed()){
                conn.close();
            }

            } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }




}
