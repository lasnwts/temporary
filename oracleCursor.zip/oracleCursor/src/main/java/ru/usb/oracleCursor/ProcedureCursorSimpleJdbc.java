package ru.usb.oracleCursor;

import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

@Service
public class ProcedureCursorSimpleJdbc {

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.username}")
    private String user;
    @Value("${spring.datasource.password}")
    private String pass;

    @Value("${ibso.schema}")
    private String ibsoSchema;
    @Value("${ibso.catalog}")
    private String ibsoCatalog;
    @Value("${ibso.procedure}")
    private String ibsoProcedure;

    @Value("${ibso.wait}")
    private int ibsoWait;
    @Value("${ibso.timeout}")
    private int ibsoTimeout;
    @Value("${ibso.timeoutErr}")
    private int ibsoTimeoutErr;

    public void getJJDBCSimple(){
        SimpleJdbcCall executor = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(ibsoProcedure).withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        //new SqlParameter("INparam1", Types.INTEGER),
                        //new SqlParameter("INparam2", Types.VARCHAR),
                        //new SqlOutParameter("OUTParam1", OracleTypes.CURSOR),
                        //new SqlOutParameter("OUTParam2", OracleTypes.VARCHAR)
                        new SqlOutParameter("c_dbuser", OracleTypes.CURSOR));
        executor.compile();
//        SqlParameterSource param = new MapSqlParameterSource()
//                .addValue("INparam1", loginPk)
//                .addValue("INparam2", email);

        //Map map = executor.execute(param);
        Map map = executor.execute();
//        Map<String, Object> results = executor.execute();

        for (Object key: map.keySet()) {
            System.out.println(key + "/" + map.get(key));
        }


        System.out.println(map.get("c_dbuser"));




        System.out.println("");

        //Iterator<Integer> iterator = map.values().iterator();





    }

}
