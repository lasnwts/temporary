package ru.usb.oracleCursor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleCursorApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(OracleCursorApplication.class);

	@Autowired
	ProcedureCursorCallable procedureCursor;

	@Autowired
	ProcedureCursorSimpleJdbc cursorSimpleJdbc;


	public static void main(String[] args) {
		SpringApplication.run(OracleCursorApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Показываем версию
		logger.info("12.07.2023г. v.0.0.1");
		logger.info("-----------------------------------------------");
		logger.info("| Service:" );
		logger.info("| Version of service:");
		logger.info("-----------------------------------------------");
		logger.info("");
		procedureCursor.getCursor();
		logger.info("-----------------------------------------------");
		cursorSimpleJdbc.getJJDBCSimple();
	}
}
