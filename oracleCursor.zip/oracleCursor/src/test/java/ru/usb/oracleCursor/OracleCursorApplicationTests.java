package ru.usb.oracleCursor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleCursorApplicationTests {

	@Test
	void contextLoads() {
	}

}
