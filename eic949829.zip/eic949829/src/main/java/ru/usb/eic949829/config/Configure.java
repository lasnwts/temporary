package ru.usb.eic949829.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Класс основной конфигурации сервиса
 */
@Component
@ConfigurationProperties
public class Configure {


    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ssZ");

    private boolean startMovedProcess;

    private Date dateStartMovedProcess;

    public void setDateStartMovedProcess(Date dateStartMovedProcess) {
        this.dateStartMovedProcess = dateStartMovedProcess;
    }

    public String getDateStartMovedProcess() {
        return sdf.format(dateStartMovedProcess);
    }

    public boolean isStartMovedProcess() {
        return startMovedProcess;
    }

    public void setStartMovedProcess(boolean startMovedProcess) {
        this.startMovedProcess = startMovedProcess;
    }



    @Value("${service.version}")
    private String version;

    @Value("${download.delay}")
    private long downloadDelay;

    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${interval-in-cron-1}")
    private String interval1;

    @Value("${interval-in-cron-2}")
    private String interval2;


    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects:EIC}")
    private String mailSubjects;

    @Value("${mailFrom:zsk service}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    @Value("${service.path.from}")
    private String servicePathFrom;

    @Value("${service.path.to}")
    private String servicePathTo;

    @Value("${service.tmppath}")
    private String tmpPath;

    public String getServicePathFrom() {
        return servicePathFrom;
    }

    public String getServicePathTo() {
        return servicePathTo;
    }

    public String getVersion() {
        return version;
    }

    public long getDownloadDelay() {
        return downloadDelay;
    }

    public String getMailHost() {
        return mailHost;
    }

    public String getMailPort() {
        return mailPort;
    }

    public String getMailUsername() {
        return mailUsername;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public boolean isMailAuth() {
        return mailAuth;
    }

    public boolean isMailStarttlsEnable() {
        return mailStarttlsEnable;
    }

    public String getMailSubjects() {
        return mailSubjects;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getInterval1() {
        return interval1;
    }

    public String getInterval2() {
        return interval2;
    }

    public String getTmpPath() {
        return tmpPath;
    }
}
