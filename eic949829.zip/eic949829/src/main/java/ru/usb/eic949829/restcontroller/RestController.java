package ru.usb.eic949829.restcontroller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.usb.eic949829.config.Configure;
import ru.usb.eic949829.model.FileStatistics;
import ru.usb.eic949829.service.ServiceMoveFile;

import java.io.IOException;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1")
@Api(value = "user", description = "Контроллер по REST API к сервису [EIC949879] Задача Проекта №949879 Этап 2." +
        "Электронные счета фактуры, проект № 3436.", tags = "Rest API 2.")
public class RestController {

    @Autowired
    Configure configure;

    @Autowired
    ServiceMoveFile serviceMoveFile;

    @Autowired
    FileStatistics fileStatistics;

    Logger logger = LoggerFactory.getLogger(RestController.class);

    @GetMapping("/version")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос версии сервиса",
            notes = "Версия сервиса, берется из application.properties",
            response = String.class)
    public String getVersion() throws IOException {
        if (configure.getVersion() == null) {
            logger.error("get /version :: Request get version, but version not defibed in application.properties");
            return "version not defined";
        }
        logger.error("get /version :: Request get version, " + configure.getVersion());
        return (configure.getVersion());
    }

    @GetMapping("/move")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос старта сервиса переноса файлов",
            notes = "Файлы будут перенесены",
            response = String.class)
    public String rumMovedFiles(){
        logger.info("Get Request /move");
        if (!configure.isStartMovedProcess()) {
            if (serviceMoveFile.JobMoveFiles("xml")) {
                return "Процесс успешно завершен. Статистика: "+fileStatistics.toString();
            } else {
                return "Ошибка! Процесс завершен c Ошибками. Статистика: "+fileStatistics.toString();
            }
        } else {
            return "Процесс переноса уже запущен...   [Дата и время запуска:"+configure.getDateStartMovedProcess()+"] Статистика:"+fileStatistics.toString();
        }
    }

    @GetMapping("/report")
    //Запрашиваем версию сервиса
    @ApiOperation(value = "Запрос отчета по последней операции переноса файлов",
            notes = "Отчет",
            response = String.class)
    public String getReport(){
        logger.info("Get Request /report");
        return fileStatistics.toString();
    }


}
