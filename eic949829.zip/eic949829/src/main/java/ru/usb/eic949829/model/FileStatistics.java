package ru.usb.eic949829.model;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Для анализа числа удачных и неудачных попыток отправить файл
 */
@Component
public class FileStatistics {

    //Общее число файлов для переноса
    private int FullFileCount;

    //Кол-во файлов успешно скопированных
    private int SuccessFileMove;

    //Кол-вр файлов с ошибками переноса
    private int FailFileMove;

    //Дата последнего обновления информации
    private Date dateModified;

    public int getSuccessFileMove() {
        return SuccessFileMove;
    }

    public void setSuccessFileMove(int successFileMove) {
        SuccessFileMove = successFileMove;
    }

    public int getFailFileMove() {
        return FailFileMove;
    }

    public void setFailFileMove(int failFileMove) {
        FailFileMove = failFileMove;
    }

    public int getFullFileCount() {
        return FullFileCount;
    }

    public void setFullFileCount(int fullFileCount) {
        FullFileCount = fullFileCount;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ssZ");

    @Override
    public String toString() {
        return "Информация последней выгрузки{" +
                "Общее число файлов = " + FullFileCount +
                ", Число успешно переданных файлов =" + SuccessFileMove +
                ", Число файлов с ошибкой передачи =" + FailFileMove +
                ", Дата и время обновления информации = " + sdf.format(dateModified) +
                '}';
    }
}
