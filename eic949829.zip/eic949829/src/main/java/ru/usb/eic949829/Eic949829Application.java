package ru.usb.eic949829;

import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.usb.eic949829.config.Configure;
import ru.usb.eic949829.model.FileStatistics;
import ru.usb.eic949829.restcontroller.RestController;
import ru.usb.eic949829.service.EmailService;
import ru.usb.eic949829.service.EmailServiceImpl;
import ru.usb.eic949829.service.ServiceMoveFile;
import ru.usb.eic949829.utils.WorkWithFiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

@EnableSwagger2
@SpringBootApplication
public class Eic949829Application implements CommandLineRunner {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    ServiceMoveFile serviceMoveFile;

    @Autowired
    FileStatistics fileStatistics;

    Logger logger = LoggerFactory.getLogger(Eic949829Application.class);

    public static void main(String[] args) {
        SpringApplication.run(Eic949829Application.class, args);
    }

    @Bean
    public Docket swaggerConfiguration() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .paths(Predicates.or(
                        PathSelectors.ant("/api/v1/**")
                ))
                .apis(RequestHandlerSelectors.basePackage("ru.usb"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("Help page of service EIC949829", "../", "LyapustinAS@spb.uralsib.ru");
        return new ApiInfoBuilder()
                .title("Задача Проекта №949879 Этап 2. Электронные счета фактуры, проект № 3436.Rest Api Title 12/07/2022")
                .description("Api Definition by @alexander")
                .version(configure.getVersion())
                .license("Apache 2.0")
                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0")
                .contact(contact)
                .build();
    }

    /**
     * Инициализация при старте
     *
     * @param args incoming main method arguments
     * @throws Exception
     */
    @Override
    public void run(String... args) throws Exception {

        emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), " eic949829 started...");

        /**
         * Инициализация объекта статистики
         */
        fileStatistics.setFailFileMove(0);
        fileStatistics.setFullFileCount(0);
        fileStatistics.setSuccessFileMove(0);
        fileStatistics.setDateModified(new Date());

        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                FileSystems.getDefault().getSeparator() + configure.getTmpPath());
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            System.out.println("Directory " + path.toString() + " = created");
        } else {
            System.out.println("Directory" + path.toString() + " = already exists");
        }
        //Очистка каталога при старте
        try {
            Files.walk(Paths.get(new FileSystemResource("").getFile().getAbsolutePath() +
                            FileSystems.getDefault().getSeparator() + configure.getTmpPath()))
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .forEach(File::delete);
            if (!workWithFiles.checkPathExists(configure.getServicePathFrom())) {
                logger.error("!!Error. Path not found=" + configure.getServicePathFrom());
            }
            if (!workWithFiles.checkPathExists(configure.getServicePathTo())) {
                logger.error("!!Error. Path not found=" + configure.getServicePathTo());
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload folder!");
        }

    }


    /**
     * Sheduler 1.  Шедулер 1. по Cron.
     * в applcation.properties value=interval-in-cron-1
     */
    @Scheduled(cron = "${interval-in-cron-1}")
    public void CronSheduler1() {
        logger.info("");
        logger.info("");
        logger.info("*****************************************<Start CronSheduler Scheduler process " + configure.getVersion() + " time:" + configure.getInterval1() + ">*******************************************************");
        //Запуск Job'a
        if (!configure.isStartMovedProcess()) {
            if (serviceMoveFile.JobMoveFiles("xml")) {
                logger.info("Текущая работа по переносу файлов, завершена успешно.");
            } else {
                logger.error("Error!! Ошибка!! Текущая работа по переносу файлов, завершена c ошибкой!!");
            }
            logger.info("Статистика:" + fileStatistics.toString());
        }
        logger.info("*****************************************<End CronSheduler Scheduler process " + configure.getVersion() + ">*******************************************************");
        logger.info("");
        logger.info("");

    }

    /**
     * Sheduler 2.  Шедулер 2. по Cron.
     * в applcation.properties value=interval-in-cron-1
     */
    @Scheduled(cron = "${interval-in-cron-2}")
    public void CronSheduler2() {
        logger.info("");
        logger.info("");
        logger.info("*****************************************<Start CronSheduler Scheduler process " + configure.getVersion() + " time:" + configure.getInterval2() + ">*******************************************************");
        //Запуск Job'a
        if (!configure.isStartMovedProcess()) {
            if (serviceMoveFile.JobMoveFiles("xml")) {
                logger.info("Текущая работа по переносу файлов, завершена успешно.");
            } else {
                logger.error("Error!! Ошибка!! Текущая работа по переносу файлов, завершена c ошибкой!!");
            }
            logger.info("Статистика:" + fileStatistics.toString());
        }
        logger.info("*****************************************<End CronSheduler Scheduler process " + configure.getVersion() + ">*******************************************************");
        logger.info("");
        logger.info("");

    }


}


@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /**
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}