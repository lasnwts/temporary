package ru.usb.eic949829.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.eic949829.config.Configure;
import ru.usb.eic949829.model.FileStatistics;
import ru.usb.eic949829.utils.WorkWithFiles;

import java.nio.file.FileSystems;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Service
public class ServiceMoveFile {

    @Autowired
    Configure configure;

    @Autowired
    WorkWithFiles workWithFiles;

    @Autowired
    EmailServiceImpl emailService;

    @Autowired
    FileStatistics fileStatistics;

    //Переменная для функции
    Boolean flagSuccessMoveFile;

    //Ошибка переноса
    private String mailSendErrorString;

    Logger logger = LoggerFactory.getLogger(ServiceMoveFile.class);

    /**
     * Фунция переноса файлов из каталога в каталог
     *
     * @param fileFrom - исходный файл
     * @param fileTo   - файл назначения
     * @return - логический флаг результата (true - успех), (false - ошибка)
     */
    public boolean moveFile(String fileFrom, String fileTo) {

        logger.info("Attempt::Try moved file:: (from) " + fileFrom + " -> moved (to ) " + fileTo);

        if (workWithFiles.moveFileSize(fileFrom, fileTo)) {
            return true;
        } else {
            //Чистим каталог приемник, если удалось скопировать часть файла
            workWithFiles.delFiles(fileTo);
            //Задержка в 60 секунд для обработки СКЗИ enc и sig. Свойство - download.delay
            logger.info(" Seconds = " + configure.getDownloadDelay() + " - delay between downloaded.....");

            try {
                TimeUnit.SECONDS.sleep(configure.getDownloadDelay());
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }
        return false;
    }


    /**
     * Функция упрощения кода переноса файлов
     *
     * @param file   - что переносим (файл)
     * @param fileTo - куда переносим (файл)
     * @return - результат (true- успех), (false - ошибка)
     */
    private boolean getMoved(String file, String fileTo) {

        if (moveFile(file, fileTo)) {
            logger.info("File (from)" + file + " moved successful to " + fileTo);
            return true;
        } else {
            logger.error("Error! File (from)" + file + " NOT moved to " + fileTo);
            mailSendErrorString = mailSendErrorString + "Error! File (from)" + file + " NOT moved to " + fileTo + "\n";
        }
        return false;
    }

    /**
     * Основной Job переноса файлов
     *
     * @return
     */
    public boolean JobMoveFiles(String extension) {

        //Установкаливаем флаг
        configure.setStartMovedProcess(true);
        configure.setDateStartMovedProcess(new Date());
        mailSendErrorString = "";

        if (!workWithFiles.checkPathExists(configure.getServicePathFrom())) {
            return false;
        }

        flagSuccessMoveFile = true;

        List<String> files = workWithFiles.getDirFileWithExt(configure.getServicePathFrom(), extension);

        fileStatistics.setDateModified(new Date());
        fileStatistics.setFullFileCount(files.size());
        fileStatistics.setFailFileMove(0);
        fileStatistics.setSuccessFileMove(0);

        if (files.size() == 0) {
            logger.info("Files with Extension " + extension + " not found in " + configure.getServicePathFrom());
            return true;
        } else {

            logger.info(" Count =" + files.size() + " Files with Extension " + extension + " found in " + configure.getServicePathFrom());

            files.forEach(new Consumer<String>() {
                @Override
                public void accept(String str) {
                    logger.info("File ready to move::" + str);
                }
            });

            files.forEach(new Consumer<String>() {
                @Override
                public void accept(String file) {

                    //Attempt 1
                    Boolean flag = getMoved(file, configure.getServicePathTo() +
                            FileSystems.getDefault().getSeparator() + workWithFiles.ConvertStringToFiles(file).getName());

                    //Attempt 2
                    if (!flag) {
                        logger.info("Attempt 2 in file:" + file);
                        flag = getMoved(file, configure.getServicePathTo() +
                                FileSystems.getDefault().getSeparator() + workWithFiles.ConvertStringToFiles(file).getName());
                    }

                    //Attempt 3
                    if (!flag) {
                        logger.info("Attempt 3 in file:" + file);
                        flag = getMoved(file, configure.getServicePathTo() +
                                FileSystems.getDefault().getSeparator() + workWithFiles.ConvertStringToFiles(file).getName());
                    }

                    if (!flag) {
                        flagSuccessMoveFile = false;
                        fileStatistics.setFailFileMove(fileStatistics.getFailFileMove() + 1);
                        logger.info("File moved fail::" + file);
                    } else {
                        fileStatistics.setSuccessFileMove(fileStatistics.getSuccessFileMove() + 1);
                        logger.info("File moved success::" + file);
                    }
                }
            });
        }
        configure.setStartMovedProcess(false);
        configure.setDateStartMovedProcess(new Date());
        fileStatistics.setDateModified(new Date());
        emailService.sendSimpleEmail(configure.getMailTo(), configure.getMailSubjects(), " eic949829 error on moved files..." + mailSendErrorString);
        return flagSuccessMoveFile;
    }
}
