package ru.usb.eic949829;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eic949829ApplicationTests {

	@Test
	void contextLoads() {
	}

}
