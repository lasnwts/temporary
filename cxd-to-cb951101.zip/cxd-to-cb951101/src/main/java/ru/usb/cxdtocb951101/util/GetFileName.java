package ru.usb.cxdtocb951101.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.usb.cxdtocb951101.service.ProcessCustomers2;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Класс возвращает имя файла в формате YYYYMMDD-Таблица1
 */
@Component
public class GetFileName {

    Logger logger = LoggerFactory.getLogger(GetFileName.class);

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * @param filaName - имя части файла типа Таблица1
     * @return Возвращаем имя файла в формате YYYYMMDD-fileName
     */
    public String getFileName(String filaName) {
        return sdf.format(new Date()) + filaName+".xlsx";
    }


    /**
     * Проверка существования шары
     *
     * @param targetPath - полный путь к каталогу шары
     * @return - true - если шара есть, false - шары нет
     */
    public boolean checkTargetPathExists(String targetPath) {
        Path path = Paths.get(targetPath);
        if (Files.exists(path)) {
            // действия, если папка существует
            return true;
        }
        return false;
    }

    /**
     * Проверка существования файла
     *
     * @param fileNameShort - имя проверяемого файла
     * @return (true - есть файл, false - нет)
     */
    public boolean checkFileExists(String fileNameShort) {
        Path path = Paths.get(fileNameShort);
        if (Files.exists(path)) {
            // действия, если файл существует
            logger.info("File :: "+fileNameShort+" Exist in target! unloading impossible. Sleep process....");
            return true;
        }
        logger.info("File :: "+fileNameShort+"not Exist in target! unloading process get started.");
        return false;
    }

}
