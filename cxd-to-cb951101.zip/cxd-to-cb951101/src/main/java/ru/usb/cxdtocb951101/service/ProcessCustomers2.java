package ru.usb.cxdtocb951101.service;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.cxdtocb951101.config.ApplicationProperties;
import ru.usb.cxdtocb951101.excel.ExcelToDisk;
import ru.usb.cxdtocb951101.excel.ExcelToDiskStream;
import ru.usb.cxdtocb951101.model.AnswerErrorMessage;
import ru.usb.cxdtocb951101.model.Customers;
import ru.usb.cxdtocb951101.repository.JpaRepositorycustomers2;
import ru.usb.cxdtocb951101.util.CheckDataRequest;
import ru.usb.cxdtocb951101.util.GetFileName;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Выгрузка данных по таблице Customers2
 */
@Service
public class ProcessCustomers2 {

    private SXSSFWorkbook workbook;

    Logger logger = LoggerFactory.getLogger(ProcessCustomers2.class);

    @Autowired
    GetFileName getFileName;

    @Autowired
    ExcelToDisk excelToDisk;

    @Autowired
    ExcelToDiskStream excelToDiskStream;

    @Autowired
    CheckDataRequest checkDataRequest;

    @Autowired
    private JpaRepositorycustomers2 jpaRepositorycustomers2;
    private EntityManager entityManager;

    public ProcessCustomers2(JpaRepositorycustomers2 jpaRepositorycustomers2, EntityManager entityManager) {
        this.jpaRepositorycustomers2 = jpaRepositorycustomers2;
        this.entityManager = entityManager;
    }

    @Autowired
    ApplicationProperties applicationProperties;

    private static String FILENAME = "CUSTOM";


    @Transactional
    public AnswerErrorMessage unloadProcessStart(AnswerErrorMessage answerErrorMessage) {
        //Проверяем есть ли файл в директории
        if (getFileName.checkFileExists(applicationProperties.getTargetPath() + File.separator + getFileName.getFileName(FILENAME))) {
            answerErrorMessage.setErrorFlag(true);
            answerErrorMessage.setErrorMessage("file exists");
            return answerErrorMessage;
        } else {

            /**
             * Проверяем есть ли флаг готовности данных в ЦХД
             */
            if (checkDataRequest.GetCheckDate("w") == 0) {
                logger.info("Request flag ready data return = 0. Sleep .....");
                return answerErrorMessage;
            }

            /**************************************************
             * Здесь должна быть процедура выгрузки в файл    *
             **************************************************/
            ProcessGetDataFromTable();

            /*************************************************
             * Здесь должны быть процедура копирования       *
             **************************************************/

        }
        return answerErrorMessage;
    }

    @Transactional(readOnly = true)
    private void ProcessGetDataFromTable() {
        //Получаем список записей из базы
        Stream<Customers> fTableStream = null;

        try {
            fTableStream = jpaRepositorycustomers2.getCustomers2All();
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while retrieving information from the CXD  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            e.printStackTrace();
        }

        try {
            workbook = excelToDiskStream.writeExcel();
            AtomicInteger rownum = new AtomicInteger();

            //Инициализируем переменную
            fTableStream.forEach(fTable -> {
                rownum.getAndIncrement();

                logger.info("Строка::"+
                        "CUSTOMER_ID='" + fTable.getCUSTOMER_ID() + '\'' +
                        ", CUSTOMER_NAME='" + fTable.getCUSTOMER_NAME() + '\'' +
                        ", ADDRESS='" + fTable.getADDRESS() + '\'' +
                        ", CITY='" + fTable.getCITY() + '\'' +
                        ", STATE='" + fTable.getSTATE() + '\'' +
                        ", ZIP_CODE='" + fTable.getZIP_CODE() + '\'' +
                        ", TMSTAMP=" + fTable.getTMSTAMP()
                        );

//                try {
//                    excelToDisk.openExcel(new File("C:\\AppSever\\Projects\\Banking\\backup\\cxd-to-cb951101\\employee.xlsx"));
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                } catch (InvalidFormatException e) {
//                    throw new RuntimeException(e);
//                }

                excelToDiskStream.WorkBookWriteRecord(workbook, rownum.intValue(),
                        fTable.getCUSTOMER_ID(),
                        fTable.getCUSTOMER_NAME(),
                        fTable.getADDRESS(),
                        fTable.getCITY(),
                        fTable.getSTATE(),
                        fTable.getZIP_CODE(),
                        fTable.getTMSTAMP()
                );

//                try {
//                    excelToDisk.WorkBookClose(workbook);
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }


                entityManager.detach(fTable);
            });
        } catch (Exception e) {
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!  An error occurred while uploading information to a file  !!!!!!!!!!");
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //Ставим, что произошла ошибка
            e.printStackTrace();
        } finally {
            try {
                excelToDiskStream.WorkBookClose(workbook);
                workbook = null;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            fTableStream.close();
        }

        logger.info("###################### < Starting the process of unloading data from a table to a file > ##############################");
    }


}
