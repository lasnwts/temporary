package ru.usb.cxdtocb951101.util;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class DateToStr {

//    SimpleDateFormat simpleDateFormatSec = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
//    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public String getDateToStr(Date date){
        return dateFormat.format(date);
    }

}
