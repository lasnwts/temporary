package ru.usb.cxdtocb951101.model;

import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

public class Customers2PK implements Serializable {

    private String CUSTOMER_ID;
    private String CUSTOMER_NAME;
    private String ADDRESS;
    private String CITY;
    private String STATE;
    private String ZIP_CODE;
    @Temporal(TemporalType.TIMESTAMP)
    private Date TMSTAMP;
}
