package ru.usb.cxdtocb951101;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.cxdtocb951101.config.ApplicationProperties;
import ru.usb.cxdtocb951101.excel.ExcelToDisk;
import ru.usb.cxdtocb951101.model.AnswerErrorMessage;
import ru.usb.cxdtocb951101.service.FileGenerator;
import ru.usb.cxdtocb951101.service.ProcessCustomers2;
import ru.usb.cxdtocb951101.util.GetFileName;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
public class CxdToCb951101Application implements CommandLineRunner {

    @Autowired
    AnswerErrorMessage answerErrorMessage;

    @Autowired
    FileGenerator fileGenerator;

    @Autowired
    ProcessCustomers2 processCustomers2;

    @Autowired
    GetFileName getFileName;

    Logger logger = LoggerFactory.getLogger(CxdToCb951101Application.class);

    @Autowired
    ApplicationProperties applicationProperties;

    public static void main(String[] args) {
        SpringApplication.run(CxdToCb951101Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Path path = Paths.get(new FileSystemResource("").getFile().getAbsolutePath() + "/srvtemp");
        if (!Files.exists(path)) {
            Files.createDirectory(path);
            System.out.println("Directory " + path.toString() + " = created");
        } else {
            System.out.println("Directory" + path.toString() + " = already exists");
        }
        logger.info("#####################################################################");
        logger.info("# Version of service::" + applicationProperties.getServiceVersion());
        logger.info("#####################################################################");
        logger.info(" ");
        logger.info(" ");
        logger.info(" ");
        logger.info("#########################TEST TEST ######################################");
        logger.info(fileGenerator.getTest("qwerty"));
        logger.info("Check = " + fileGenerator.getCheck("w"));
        logger.info("Check = " + fileGenerator.getCheck("w1"));
    }

    @Scheduled(initialDelay = 20000L, fixedDelayString = "${scheduler.delay}")
    public void BaseJob(){
        logger.info("*****************************************<Start Scheduler process " + applicationProperties.getServiceVersion() + ">*******************************************************");
        //Проверяем есть ли каталог назначения, если нет завершаем работу
        if (!getFileName.checkTargetPathExists(applicationProperties.getTargetPath())){
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("Error::taregt path not exists :: "+applicationProperties.getTargetPath());
            logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        } else {
        /**
         * Запускаем процесс выгрузки по таблице Customers2
         */
        //Инициализация
        answerErrorMessage.setErrorFlag(false); answerErrorMessage.setErrorMessage("");
        logger.info("init answer:"+answerErrorMessage.toString());
        answerErrorMessage = processCustomers2.unloadProcessStart(answerErrorMessage);
            /**
             * Здесь необходимо запускать Garbage collector
             */
        logger.info("after answer:"+answerErrorMessage.toString());
        }
        logger.info("*****************************************<End Scheduler process " + applicationProperties.getServiceVersion() + ">*******************************************************");
        System.gc();
    }
}



@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
}
