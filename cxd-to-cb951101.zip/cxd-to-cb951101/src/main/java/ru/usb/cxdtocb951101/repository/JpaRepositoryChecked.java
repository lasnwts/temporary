package ru.usb.cxdtocb951101.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ru.usb.cxdtocb951101.model.OutBoundDataCheck;

import java.util.List;

public interface JpaRepositoryChecked extends JpaRepository<OutBoundDataCheck, Long> {
        @Query(value = "select 1 as checked from dual where 'w' = ?", nativeQuery = true) //тест
        List<OutBoundDataCheck> getCheck(String string);

}
