package ru.usb.cxdtocb951101.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OutBoundDataCheck {
    @Id
    private int checked;

    public OutBoundDataCheck() {
    }

    public OutBoundDataCheck(int checked) {
        this.checked = checked;
    }

    public int getChecked() {
        return checked;
    }

    public void setChecked(int checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return "OutBoundDataCheck{" +
                "checked=" + checked +
                '}';
    }
}
