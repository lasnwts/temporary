package ru.usb.cxdtocb951101.excel;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.cxdtocb951101.util.DateToStr;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

@Component
public class ExcelToDiskStream {

    @Autowired
    DateToStr dateToStr;

    private XSSFCellStyle createStyleForTitle(SXSSFWorkbook workbook) {
        XSSFFont font = (XSSFFont) workbook.createFont();
        font.setBold(true);
        XSSFCellStyle style = (XSSFCellStyle) workbook.createCellStyle();
        style.setFont(font);
        return style;
    }

    public SXSSFWorkbook writeExcel() throws IOException {

        SXSSFWorkbook workbook = new SXSSFWorkbook(1000);
        SXSSFSheet sheet = workbook.createSheet("Employees sheet");

        int rownum = 0;
        Cell cell;
        Row row;
        //
        XSSFCellStyle style = createStyleForTitle(workbook);


        row = sheet.createRow(rownum);

        // EmpNo
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue("CUSTOMER_ID");
        cell.setCellStyle(style);
//        sheet.autoSizeColumn(0);
        // EmpName
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue("CUSTOMER_NAME");
        cell.setCellStyle(style);
//        sheet.autoSizeColumn(1);
        // Salary
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue("ADDRESS");
        cell.setCellStyle(style);
//        sheet.autoSizeColumn(2);
        // Grade
        cell = row.createCell(3, CellType.STRING);
        cell.setCellValue("CITY");
        cell.setCellStyle(style);
        // Bonus
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue("STATE");
        cell.setCellStyle(style);
        //
        cell = row.createCell(5, CellType.STRING);
        cell.setCellValue("ZIP_CODE");
        cell.setCellStyle(style);
        //Date
        cell = row.createCell(6, CellType.STRING);
        cell.setCellValue("TMSTAMP");
        cell.setCellStyle(style);

        return workbook;
    }

//    public SXSSFWorkbook openExcel(File file) throws IOException, InvalidFormatException {
//
//        SXSSFWorkbook workbook = new SXSSFWorkbook(file);
//
//        return workbook;
//    }

    public void WorkBookClose(SXSSFWorkbook workbook) throws IOException {
        File file = new File("C:\\AppSever\\Projects\\Banking\\backup\\cxd-to-cb951101\\employee.xlsx");
        file.getParentFile().mkdirs();

        FileOutputStream outFile = new FileOutputStream(file);
        workbook.write(outFile);
        workbook.close();
        outFile.close();
        System.out.println("Created file: " + file.getAbsolutePath());
    }

    public void WorkBookWriteRecord(SXSSFWorkbook workbook, int rownum,
                                    String CUSTOMER_ID,
                                    String CUSTOMER_NAME,
                                    String ADDRESS,
                                    String CITY,
                                    String STATE,
                                    String ZIP_CODE,
                                    Date TMSTAMP
    ) {
        SXSSFSheet sheet = workbook.getSheet("Employees sheet");
        Cell cell;
        Row row;
        row = sheet.createRow(rownum);
        // EmpNo (A)
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue(CUSTOMER_ID);
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue(CUSTOMER_NAME);
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue(ADDRESS);
        cell = row.createCell(3, CellType.STRING);
        cell.getCellStyle().setAlignment(HorizontalAlignment.CENTER);
        cell.setCellValue(CITY);
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue(STATE);
        cell = row.createCell(5, CellType.NUMERIC);
        cell.setCellValue(ZIP_CODE);
        //дата
        cell = row.createCell(6, CellType.NUMERIC);
        cell.getCellStyle().setDataFormat(HSSFDataFormat.getBuiltinFormat("d-mmm-yy"));
        cell.setCellValue(dateToStr.getDateToStr(TMSTAMP));


    }


}
