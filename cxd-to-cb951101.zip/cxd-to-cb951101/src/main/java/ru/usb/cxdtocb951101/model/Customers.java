package ru.usb.cxdtocb951101.model;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Класс записи
 */
@Entity
//@IdClass(Customers2PK.class)
//@IdClass(CustomerPKX.class)
public class Customers {

    private String CUSTOMER_ID;
    @Id
    private String CUSTOMER_NAME;

    private String ADDRESS;

    private String CITY;

    private String STATE;

    private String ZIP_CODE;
    @Temporal(TemporalType.TIMESTAMP)
    private Date TMSTAMP;


/*    @Id
    private String CUSTOMER_ID;
    @Id
    private String CUSTOMER_NAME;
    @Id
    private String ADDRESS;
    @Id
    private String CITY;
    @Id
    private String STATE;
    @Id
    private String ZIP_CODE;
    @Id
    @Temporal(TemporalType.TIMESTAMP)
    private Date TMSTAMP;*/

    public Customers() {
    }

    public Customers(String CUSTOMER_ID, String CUSTOMER_NAME, String ADDRESS, String CITY,
                     String STATE, String ZIP_CODE, Date TMSTAMP) {
        this.CUSTOMER_ID = CUSTOMER_ID;
        this.CUSTOMER_NAME = CUSTOMER_NAME;
        this.ADDRESS = ADDRESS;
        this.CITY = CITY;
        this.STATE = STATE;
        this.ZIP_CODE = ZIP_CODE;
        this.TMSTAMP = TMSTAMP;
    }

    public String getCUSTOMER_ID() {
        return CUSTOMER_ID;
    }

    public String getCUSTOMER_NAME() {
        return CUSTOMER_NAME;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public String getCITY() {
        return CITY;
    }

    public String getSTATE() {
        return STATE;
    }

    public String getZIP_CODE() {
        return ZIP_CODE;
    }

    public Date getTMSTAMP() {
        return TMSTAMP;
    }

    public void setCUSTOMER_ID(String CUSTOMER_ID) {
        this.CUSTOMER_ID = CUSTOMER_ID;
    }

    public void setCUSTOMER_NAME(String CUSTOMER_NAME) {
        this.CUSTOMER_NAME = CUSTOMER_NAME;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public void setCITY(String CITY) {
        this.CITY = CITY;
    }

    public void setSTATE(String STATE) {
        this.STATE = STATE;
    }

    public void setZIP_CODE(String ZIP_CODE) {
        this.ZIP_CODE = ZIP_CODE;
    }

    public void setTMSTAMP(Date TMSTAMP) {
        this.TMSTAMP = TMSTAMP;
    }

    @Override
    public String toString() {
        return "" +
                "CUSTOMER_ID='" + CUSTOMER_ID + '\'' +
                ", CUSTOMER_NAME='" + CUSTOMER_NAME + '\'' +
                ", ADDRESS='" + ADDRESS + '\'' +
                ", CITY='" + CITY + '\'' +
                ", STATE='" + STATE + '\'' +
                ", ZIP_CODE='" + ZIP_CODE + '\'' +
                ", TMSTAMP=" + TMSTAMP;
    }



}
