package ru.usb.cxdtocb951101.model;

import java.io.Serializable;

public class CustomerPKX implements Serializable {
    private String CUSTOMER_NAME;
}
