package ru.usb.cxdtocb951101.excel;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

@Component
public class ExcelToDisk {

//    private XSSFWorkbook workbook;

    private XSSFCellStyle createStyleForTitle(XSSFWorkbook workbook) {
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        XSSFCellStyle style = workbook.createCellStyle();
        style.setFont(font);
        return style;
    }

    public XSSFWorkbook writeExcel() throws IOException {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Employees sheet");

        int rownum = 0;
        Cell cell;
        Row row;
        //
        XSSFCellStyle style = createStyleForTitle(workbook);


        row = sheet.createRow(rownum);

        // EmpNo
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue("CUSTOMER_ID");
        cell.setCellStyle(style);
        sheet.autoSizeColumn(0);
        // EmpName
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue("CUSTOMER_NAME");
        cell.setCellStyle(style);
        sheet.autoSizeColumn(1);
        // Salary
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue("ADDRESS");
        cell.setCellStyle(style);
        sheet.autoSizeColumn(2);
        // Grade
        cell = row.createCell(3, CellType.STRING);
        cell.setCellValue("CITY");
        cell.setCellStyle(style);
        // Bonus
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue("STATE");
        cell.setCellStyle(style);
        //
        cell = row.createCell(5, CellType.STRING);
        cell.setCellValue("ZIP_CODE");
        cell.setCellStyle(style);
        //Date
        cell = row.createCell(6, CellType.STRING);
        cell.setCellValue("TMSTAMP");
        cell.setCellStyle(style);

        return workbook;
    }

    public XSSFWorkbook openExcel(File file) throws IOException, InvalidFormatException {

        XSSFWorkbook workbook = new XSSFWorkbook(file);

        return workbook;
    }

    public void WorkBookClose(XSSFWorkbook workbook) throws IOException {
        File file = new File("C:\\AppSever\\Projects\\Banking\\backup\\cxd-to-cb951101\\employee.xlsx");
        file.getParentFile().mkdirs();

        FileOutputStream outFile = new FileOutputStream(file);
        workbook.write(outFile);
        workbook.close();
        outFile.close();
        System.out.println("Created file: " + file.getAbsolutePath());
    }

    public void WorkBookWriteRecord(XSSFWorkbook workbook, int rownum,
                                    String CUSTOMER_ID,
                                    String CUSTOMER_NAME,
                                    String ADDRESS,
                                    String CITY,
                                    String STATE,
                                    String ZIP_CODE,
                                    Date TMSTAMP
    ) {
        XSSFSheet sheet = workbook.getSheet("Employees sheet");
        Cell cell;
        Row row;
        row = sheet.createRow(rownum);
        // EmpNo (A)
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue(CUSTOMER_ID);
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue(CUSTOMER_NAME);
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue(ADDRESS);
        cell = row.createCell(3, CellType.STRING);
        cell.setCellValue(CITY);
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue(STATE);
        cell = row.createCell(5, CellType.STRING);
        cell.setCellValue(ZIP_CODE);
        //дата
        cell = row.createCell(6, CellType.NUMERIC);
        cell.setCellValue(TMSTAMP);


    }


}
