package ru.usb.cxdtocb951101.model;

import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Класс для сообщения об ошибке
 */
@Component
public class AnswerErrorMessage {
    private String errorMessage;

    //В случае ошибки = true
    private boolean errorFlag;


    public AnswerErrorMessage(String errorMessage, boolean errorFlag) {
        this.errorMessage = errorMessage;
        this.errorFlag = errorFlag;
    }


    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isErrorFlag() {
        return errorFlag;
    }

    public void setErrorFlag(boolean errorFlag) {
        this.errorFlag = errorFlag;
    }

    public AnswerErrorMessage() {
    }

    @Override
    public String toString() {
        return "AnswerErrorMessage{" +
                "errorMessage='" + errorMessage + '\'' +
                ", errorFlag=" + errorFlag +
                '}';
    }
}
