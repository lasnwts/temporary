package ru.usb.cxdtocb951101.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.cxdtocb951101.model.OutBoundDataCheck;
import ru.usb.cxdtocb951101.repository.JpaRepositoryChecked;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Класс утилиты проверки готовности данных по конкретной таблице
 */
@Component
public class CheckDataRequest {
    Logger logger = LoggerFactory.getLogger(CheckDataRequest.class);

    @Autowired
    private JpaRepositoryChecked jpaRepositoryChecked;
    private EntityManager entityManager;

    /**
     * Метод проверки готовности к выгрузке таблицы
     *
     * @param tableName - имя проверяемой таблицы
     * @return - 1 - готова к выгрузке, 0 - - данные не готовы
     */
    public int GetCheckDate(String tableName) {
        logger.info("|Request ready data to unloading from table::" + tableName + "|");
        List<OutBoundDataCheck> outBoundDataCheckList = jpaRepositoryChecked.getCheck(tableName);
        if (outBoundDataCheckList.size() > 0) {
            logger.info("|Response data to unloading from table::" + tableName + "|" + outBoundDataCheckList.get(0).getChecked());
            return 1;
        } else {
            logger.info("|Response data to unloading from table::" + tableName + "| return empty value");
        }
        return 0;
    }

}
