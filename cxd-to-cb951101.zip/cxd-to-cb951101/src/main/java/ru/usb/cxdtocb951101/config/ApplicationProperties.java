package ru.usb.cxdtocb951101.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Класс для определения параметров из application.properties *
 */
@Configuration
public class ApplicationProperties {

    @Value("${service.version}")
    private String ServiceVersion;

    @Value("${service.targetpath}")
    private String targetPath;

    @Value("${service.tmppath}")
    private String tmpPath;
    public String getServiceVersion() {
        return ServiceVersion;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public String getTmpPath() {
        return tmpPath;
    }
}
