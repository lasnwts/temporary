package ru.usb.cxdtocb951101.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.cxdtocb951101.util.CheckDataRequest;
import ru.usb.cxdtocb951101.util.GetFileName;

@Service
public class FileGenerator {

    @Autowired
    GetFileName getFileName;

    @Autowired
    CheckDataRequest checkDataRequest;

    public String getTest(String str){
        return getFileName.getFileName(str);
    }

    public int getCheck(String str){
        return checkDataRequest.GetCheckDate(str);
    }

}
