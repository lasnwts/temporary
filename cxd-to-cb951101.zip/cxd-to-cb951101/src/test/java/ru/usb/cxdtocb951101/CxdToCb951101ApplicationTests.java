package ru.usb.cxdtocb951101;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CxdToCb951101ApplicationTests {

	@Test
	void contextLoads() {
	}

}
