package ru.usb.bankrupt_stop_list_company.repository.cb;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.bankrupt_stop_list_company.model.cb.CreSlCompany;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface CreSlCompanyRepo extends JpaRepository<CreSlCompany, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM CDSBIDM.cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss')")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT distinct ID , INN ,VALID_FROM , TYPE , NAME_FULL , NAME_SHORT FROM CDSBIDM.cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss') order by INN")
    Stream<CreSlCompany> getStreamAll();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT distinct ID , INN ,VALID_FROM , TYPE , NAME_FULL , NAME_SHORT FROM CDSBIDM.cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss') order by INN")
    List<CreSlCompany> getListAll();

    //SELECT DISTINCT  VALID_FROM , INN , ID FROM cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND INN = '0213896631' AND VALID_FROM =  to_date('12.03.1977 17:37:48' , 'dd.mm.yyyy hh24:mi:ss') AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss')

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "10"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT ID, INN,VALID_FROM , TYPE, NAME_FULL, NAME_SHORT FROM CDSBIDM.cre_sl_company WHERE SOURCE = 'ЗСК' AND REASON = 'C_AML' AND INN=:inn AND VALID_FROM=to_date(:sDate,'dd.mm.yyyy hh24:mi:ss') AND VALID_TILL=TO_DATE('01.01.2200 00:00:00','DD.MM.YYYY hh24:mi:ss') and ROWNUM=1")
    List<CreSlCompany> getSearch(String inn, String sDate);

}
