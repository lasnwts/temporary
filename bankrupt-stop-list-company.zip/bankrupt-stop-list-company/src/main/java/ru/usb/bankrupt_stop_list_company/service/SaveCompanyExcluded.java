package ru.usb.bankrupt_stop_list_company.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.bankrupt_stop_list_company.configure.JdbcConfig;
import ru.usb.bankrupt_stop_list_company.model.cb.CreSlCompany;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Log4j2
@Service
public class SaveCompanyExcluded {

    @Autowired
    JdbcConfig jdbcConfig;

    private static final String INSERT_TO_CRE = "INSERT INTO SL_COMPANY_TO_INSERT (SOURCE , REASON , VALID_FROM , VALID_TILL ,NOTE, EXCLUDE , LAST_UPDATE , TYPE , INN , KPP , OGRN , NAME_FULL , NAME_SHORT , GD , CA , [ID] , NUM_INSERT)\n" +
            "VALUES\n" +
            "(? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?,?)";


    public void save(List<CreSlCompany> entities, int numInsert) throws SQLException {
        Connection connection = null;
        PreparedStatement insertStatement = null;

        try {
            connection = jdbcConfig.creDataSource().getConnection();
            insertStatement = connection.prepareStatement(INSERT_TO_CRE);

            for (CreSlCompany currentRecord : entities) {

                insertStatement.setString(1, "ЗСК");
                insertStatement.setString(2, "C_AML");
                insertStatement.setTimestamp(3, currentRecord.getValidFrom());
                insertStatement.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now().minusDays(1L)));
                insertStatement.setString(5, "NOT ACTIVE");
                insertStatement.setString(6, "СЛ");
                insertStatement.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
                insertStatement.setString(8, currentRecord.getType());
                insertStatement.setString(9, currentRecord.getInn());
                insertStatement.setString(10, "");
                insertStatement.setString(11, "");
                insertStatement.setString(12, currentRecord.getNameFull());
                insertStatement.setString(13, currentRecord.getNameShort());
                insertStatement.setString(14, "");
                insertStatement.setString(15, "");
                insertStatement.setLong(16, currentRecord.getId());
                insertStatement.setInt(17, numInsert);
                insertStatement.addBatch();
            }

            insertStatement.executeBatch();
        } finally {
            if (insertStatement != null) try { insertStatement.close(); } catch (SQLException ignore) {}
            if (connection != null) try { connection.close(); } catch (SQLException ignore) {}
        }
    }

}
