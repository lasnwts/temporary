package ru.usb.bankrupt_stop_list_company;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.usb.bankrupt_stop_list_company.configure.TG;
import ru.usb.bankrupt_stop_list_company.repository.cb.CreSlCompanyRepo;
import ru.usb.bankrupt_stop_list_company.repository.kih.KihRepo;
import ru.usb.bankrupt_stop_list_company.service.FlowExcludeCompany;
import ru.usb.bankrupt_stop_list_company.service.FlowIncludedCompany;
import ru.usb.bankrupt_stop_list_company.utils.Support;

@Log4j2
@SpringBootApplication
public class BankruptStopListCompanyApplication implements CommandLineRunner {

    @Autowired
    CreSlCompanyRepo creSlCompanyRepo;
    @Autowired
    KihRepo kihRepo;
    @Autowired
    FlowExcludeCompany flowExcludeCompany;
    @Autowired
    FlowIncludedCompany flowIncludedCompany;
    @Autowired
    Support su;

    public static void main(String[] args) {
        SpringApplication.run(BankruptStopListCompanyApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        log.info("{}:+--------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}: Created by 07.06.2024             : initial version: 0.0.10 Author@Lyapustin A.S.", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
        log.info("{}: Описание пакетов                  :", TG.UsbLogInfo);
        log.info("{}:----------------------------------------------------------------------------------------------------------------------+", TG.UsbLogInfo);
        log.info("{}:=---------------------------------------------------------------------------------------------------------------------=", TG.UsbLogInfo);
        log.info("{}: Modified reason                   : 0.0.10", TG.UsbLogInfo);
        log.info("{}:-----------------------------------------------------------------------------------------------------------------------", TG.UsbLogInfo);
        log.info("KIh count={}", kihRepo.getCount());
        log.info("CB count={}", creSlCompanyRepo.getCount());



        flowExcludeCompany.startFlowCompany();
        //flowIncludedCompany.startFlowCompany();

    }
}
