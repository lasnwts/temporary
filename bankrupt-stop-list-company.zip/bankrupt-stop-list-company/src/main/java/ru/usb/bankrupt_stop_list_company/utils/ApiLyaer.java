package ru.usb.bankrupt_stop_list_company.utils;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.bankrupt_stop_list_company.configure.Configure;
import ru.usb.bankrupt_stop_list_company.configure.TG;
import ru.usb.bankrupt_stop_list_company.repository.cb.CreSlCompanyRepo;
import ru.usb.bankrupt_stop_list_company.repository.kih.KihRepo;
import ru.usb.bankrupt_stop_list_company.service.DeleteRecord;
import ru.usb.bankrupt_stop_list_company.service.FlowScheduler;

@Log4j2
@Component
public class ApiLyaer {

    private final CreSlCompanyRepo slCompanyRepo;
    private final KihRepo kihRepo;
    private final DeleteRecord deleteRecord;
    private final Configure configure;
    private final FlowScheduler flowScheduler;

    @Autowired
    public ApiLyaer(CreSlCompanyRepo slCompanyRepo, KihRepo kihRepo, DeleteRecord deleteRecord,
                    Configure configure, FlowScheduler flowScheduler) {
        this.slCompanyRepo = slCompanyRepo;
        this.kihRepo = kihRepo;
        this.deleteRecord = deleteRecord;
        this.configure = configure;
        this.flowScheduler = flowScheduler;
    }

    /**
     * Число записей
     * @return - результат в виде строки
     */
    public String getCount(){
        return "Записи за сегодня ЦХД=" + kihRepo.getCount() + " CreditBility=" + slCompanyRepo.getCount();
    }

    /**
     * Удаление NumInsert из CRE
     * @param numInsert - ID записей
     */
    public void deleteNumInsert(int numInsert){
        log.info("{}:Получена команда на удаление NumInsert= {}", TG.UsbLogInfo, numInsert);
        deleteRecord.deleteProcedure(numInsert);
    }

    /**
     * Запуск процессов выгрузки
     */
    public void startFlow(){
        log.info("{}:Получена команда на запуск процессов выгрузки компаний", TG.UsbLogInfo);
        flowScheduler.cronSchedulerExcluded();
    }



}
