package ru.usb.bankrupt_stop_list_company.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.usb.bankrupt_stop_list_company.configure.Configure;
import ru.usb.bankrupt_stop_list_company.configure.TG;
import ru.usb.bankrupt_stop_list_company.model.cb.CreSlCompany;
import ru.usb.bankrupt_stop_list_company.repository.kih.KihRepo;


import java.text.SimpleDateFormat;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * Executor service
 */
@Log4j2
@Service
public class Executors {

    private final Configure configure;
    private final KihRepo kihRepo;

    @Autowired
    public Executors(Configure configure, KihRepo kihRepo) {
        this.configure = configure;
        this.kihRepo = kihRepo;
    }

    /**
     * инициализация: ExecutorService executorService = Executors.newFixedThreadPool(configure.getServicePoolSize());
     */
    private static ExecutorService executorService;

    //Кол-во потоков задаем
    @Value("${service.pool.size:5}")
    public synchronized void setThreadPool(Integer poolSize) {
        executorService = java.util.concurrent.Executors.newFixedThreadPool(poolSize);
    }


    /**
     * Пул потоков
     * C записью числа Queue::ExecutorService = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(5));
     */
    public void getTask(CreSlCompany messageBody, CopyOnWriteArrayList<CreSlCompany> creSlCompanyList) {
        configure.addThreadSync();//+1
        log.debug("{}:Запуск getTask потока, с сообщением:{}", TG.UsbLogInfo, messageBody);
        log.debug("{}:getTask:Длина очереди задач:{}", TG.UsbLogInfo, configure.getThreadSync());
        CountDownLatch cdl = new CountDownLatch(5);
        try {
            executorService.execute(new MyThread(cdl, messageBody, creSlCompanyList));
        } catch (Exception e) {
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, START EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            log.error("{}:Error:executorService.execute(new MyThread(cdl, messageBody, messageKafka))", TG.UsbLogError, e);
            log.error("{}:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,ERROR, END EXECUTORS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", TG.UsbLogError);
            configure.setMistakeSync(true);
        }
        log.debug("{}:Поток передан на запуск в executor service. Поток с сообщением:{}", TG.UsbLogInfo, messageBody);
    }

    class MyThread implements Runnable {
        CreSlCompany message;
        CopyOnWriteArrayList<CreSlCompany> creSlList;
        CountDownLatch latch;

        MyThread(CountDownLatch c, CreSlCompany messageBody, CopyOnWriteArrayList<CreSlCompany> creSlCompanyList ) {
            latch = c;
            message = messageBody;
            creSlList = creSlCompanyList;
            new Thread(this);
        }

        public void run() {
            if (!configure.getMistakeSync()) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                log.debug("{}:Запуск потока id={}", TG.UsbLogInfo, Thread.currentThread().getId());
                try {
                    if (kihRepo.getExistCbKih(message.getInn(), sdf.format(message.getValidFrom())) == 0) {
                        log.debug("{} Запись:{} отсутствует в БД ЦХД", TG.UsbLogInfo, message);
                        creSlList.add(message);
                    } else {
                        log.debug("{} Запись:{} присутствует в БД ЦХД", TG.UsbLogInfo, message);
                    }
                } catch (Exception e) {
                    log.error("{}: Произошла ошибка в потоке getTask(CreSlCompany messageBody, CopyOnWriteArrayList<CreSlCompany> creSlCompanyList)", TG.UsbLogError);
                    log.error("{}: описание ошибки:{})", TG.UsbLogError, e.getMessage());
                    configure.setMistakeSync(true);
                }
                //Подвал завершения потока
                log.debug("{}:::Длина:run:очереди задач={}", TG.UsbLogInfo, configure.getThreadSync());
            }
            configure.decThreadSync();//-1
        }
    }


}
