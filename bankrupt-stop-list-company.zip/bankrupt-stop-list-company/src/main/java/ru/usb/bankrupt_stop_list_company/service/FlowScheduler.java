package ru.usb.bankrupt_stop_list_company.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.usb.bankrupt_stop_list_company.configure.Configure;
import ru.usb.bankrupt_stop_list_company.configure.TG;


import java.util.Date;

@Component
@EnableScheduling
public class FlowScheduler {

    Logger logger = LoggerFactory.getLogger(FlowScheduler.class);

    private final FlowExcludeCompany flowExcludeCompany;
    private final FlowIncludedCompany flowIncludedCompany;
    private final Configure configure;

    @Autowired
    public FlowScheduler(FlowExcludeCompany flowExcludeCompany, FlowIncludedCompany flowIncludedCompany, Configure configure) {
        this.flowExcludeCompany = flowExcludeCompany;
        this.flowIncludedCompany = flowIncludedCompany;
        this.configure = configure;
    }

    /**
     * Scheduler 1. flowExcludeCompany.startFlowCompany
     */
    @Scheduled(cron = "${interval-in-cron1}")
    public void cronSchedulerExcluded() {
        logger.info("{} Сработал таймер 1.[flowExcludeCompany.startFlowCompany] {} часов дня. ", TG.UsbLogInfo, new Date());
        configure.setMistakeSync(false); //Устанавливаем, что ошибки нет
        configure.setExcludedReadySync(false); //Готовность потоков = нет

        flowExcludeCompany.startFlowCompany();
        logger.info("{} Работа flowExcludeCompany.startFlowCompany завершена. {} ", TG.UsbLogInfo, new Date());
    }

    /**
     * Scheduler 2. flowIncludedCompany.startFlowCompany
     */
    @Scheduled(cron = "${interval-in-cron2}")
    public void cronSchedulerIncluded() {
        logger.info("{} Сработал таймер 2.[flowIncludedCompany.startFlowCompany] {} часов дня. ", TG.UsbLogInfo, new Date());
//        configure.setMistakeSync(false); //Устанавливаем, что ошибки нет
        configure.setIncludedReadySync(false); //Готовность потоков = нет
        flowIncludedCompany.startFlowCompany();
        logger.info("{} Работа flowIncludedCompany.startFlowCompany завершена. {} ", TG.UsbLogInfo, new Date());
    }

}
