package ru.usb.bankrupt_stop_list_company.configure;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;


@Component
@ConfigurationProperties
@Data
public class Configure {

    public AtomicInteger atomicInt = new AtomicInteger(0);


    /**
     * Количество задач в очереди
     */
    //private int threads;
    //public static AtomicInteger threads = new AtomicInteger(0);
    private int threads; // кол-во потоков, активных Excluded поток
    private int numInsert; //Номер для поля записи
    private int lineCounterExcluded; //Счетчик записей в обработке

    //Работа с ошибкой
    private boolean mistake; //Ошибка возникла? false - нет, true -да.
    public synchronized boolean getMistakeSync(){
        return mistake;
    }
    public synchronized void setMistakeSync(boolean mistake){
        this.mistake = mistake;
    }

    //Готовность выгрузки потока Excluded
    private boolean readyExcluded;
    public synchronized boolean getExcludedReadySync(){
        return readyExcluded;
    }
    public synchronized void setExcludedReadySync(boolean ready){
        this.readyExcluded = ready;
    }

    //Готовность выгрузки потока Included
    private boolean readyIncluded;
    public synchronized boolean getIncludedReadySync(){
        return readyIncluded;
    }
    public synchronized void setIncludedReadySync(boolean ready){
        this.readyIncluded = ready;
    }


    /**
     * service.pool.size=5
     * service.mode=one
     */
    @Value("${service.pool.size:5}")
    private java.lang.Integer servicePoolSize;

    /**
     * Количество записей
     */
    public synchronized int getLineCounterExcludedSync(){
        return lineCounterExcluded;
    }

    public synchronized void setLineCounterExcludedSync(int lineCount){
        this.lineCounterExcluded = lineCount;
    }

    public synchronized void addLineCounterExcludedSync(){
        lineCounterExcluded++;
    }

    public synchronized void decLineCounterExcludedSync(){
        lineCounterExcluded--;
    }

    /**
     * Кол-во потоков
     */

    public synchronized int getThreadSync() {
        return threads;
    }

    public synchronized void setThreadSync(int threads) {
        this.threads = threads;
    }

    public synchronized void addThreadSync(){
        threads++;
    }

    public synchronized void decThreadSync(){
        threads--;
    }

    public int getServicePoolSize() {
        return servicePoolSize;
    }

    /**
     * Security in properties     *
     */
    @Value("${service.user:user}")
    private String serviceUser;

    @Value("${service.password:p23051990}")
    private String servicePassword;

    /**
     * Включение или отключение сервиса
     * false - сервис отключен
     * true - включен
     */
    @Value("${service.app.include}")
    private boolean include;

    /**
     * Секция о программе
     */
    @Value("${info.application.name}")
    private String appName;

    @Value("${info.application.description}")
    private String appDescription;

    @Value("${info.app.version}")
    private String appVersion;


    /**
     * Mail property
     */
    @Value("${spring.mail.host:192.168.1.79}")
    private String mailHost;

    @Value("${spring.mail.port:25}")
    private String mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Value("${spring.mail.properties.mail.smtp.auth:false}")
    private boolean mailAuth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable:false}")
    private boolean mailStarttlsEnable;

    @Value("${mailSubjects}")
    private String mailSubjects;

    @Value("${mailFrom}")
    private String mailFrom;

    @Value("${mailTo}")
    private String mailTo;

    /**
     *  Задержка в минутах между отправкой письма администратором
     */
    @Value("${mail.delay.minutes}")
    private long mailDelayMinutes;

}
