package ru.usb.bankrupt_stop_list_company.configure;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;

/**
 * Конфигурация Oracle
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "cbEntityManagerFactory",
        transactionManagerRef = "cbTransactionManager",
        basePackages = {
                "ru.usb.bankrupt_stop_list_company.repository.cb"
        })
public class CbDbConfig {

    @Value("${cb.schema}")
    private String defSchema;


    @Primary
    @Bean(name = "cbDataSource")
    @ConfigurationProperties(prefix = "spring.cb.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "cbEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                       @Qualifier("cbDataSource") DataSource dataSource) {

        HashMap<String, Object> properties = new HashMap<>();
//        properties.put("hibernate.hbm2ddl.auto", "validate");
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");
        properties.put("hibernate.default_schema", defSchema);

        return builder.dataSource(dataSource)
                .properties(properties)
                .packages("ru.usb.bankrupt_stop_list_company.model.cb")
//                .persistenceUnit("Test2")
                .build();
    }

    @Primary
    @Bean(name = "cbTransactionManager")
    public PlatformTransactionManager bookTransactionManager(@Qualifier("cbEntityManagerFactory") EntityManagerFactory cbEntityManagerFactory) {
        return new JpaTransactionManager(cbEntityManagerFactory);
    }


}
