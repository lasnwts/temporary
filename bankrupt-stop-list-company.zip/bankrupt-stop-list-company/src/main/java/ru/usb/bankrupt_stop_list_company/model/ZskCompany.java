package ru.usb.bankrupt_stop_list_company.model;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * Модель записи юридического лица
 */
public class ZskCompany {

    private String source;
    private String reason;
    private String note;
    private Timestamp validFrom;
    private Timestamp validTill;
    private String exclude;
    private Timestamp lastUpdate;
    private String type;
    private String inn;
    private String kpp;
    private String ogrn;
    private String nameFull;
    private String nameShort;
    private String gd;
    private String ca;
    private Long id;
    private Integer numInsert;


    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Timestamp getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Timestamp validFrom) {
        this.validFrom = validFrom;
    }

    public Timestamp getValidTill() {
        return validTill;
    }

    public void setValidTill(Timestamp validTill) {
        this.validTill = validTill;
    }

    public String getExclude() {
        return exclude;
    }

    public void setExclude(String exclude) {
        this.exclude = exclude;
    }

    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getKpp() {
        return kpp;
    }

    public void setKpp(String kpp) {
        this.kpp = kpp;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getNameFull() {
        return nameFull;
    }

    public void setNameFull(String nameFull) {
        this.nameFull = nameFull;
    }

    public String getNameShort() {
        return nameShort;
    }

    public void setNameShort(String nameShort) {
        this.nameShort = nameShort;
    }

    public String getGd() {
        return gd;
    }

    public void setGd(String gd) {
        this.gd = gd;
    }

    public String getCa() {
        return ca;
    }

    public void setCa(String ca) {
        this.ca = ca;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getNumInsert() {
        return numInsert;
    }

    public void setNumInsert(Integer numInsert) {
        this.numInsert = numInsert;
    }



    @Override
    public String toString() {
        return "CreRecords{" +
                "source='" + source + '\'' +
                ", reason='" + reason + '\'' +
                ", note='" + note + '\'' +
                ", validFrom=" + validFrom +
                ", validTill=" + validTill +
                ", exclude='" + exclude + '\'' +
                ", lastUpdate=" + lastUpdate +
                ", type='" + type + '\'' +
                ", inn='" + inn + '\'' +
                ", kpp='" + kpp + '\'' +
                ", ogrn='" + ogrn + '\'' +
                ", nameFull='" + nameFull + '\'' +
                ", nameShort='" + nameShort + '\'' +
                ", gd='" + gd + '\'' +
                ", ca='" + ca + '\'' +
                ", id=" + id +
                ", numInsert=" + numInsert +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ZskCompany zskCompany = (ZskCompany) o;
        return Objects.equals(inn, zskCompany.inn) && Objects.equals(validFrom, zskCompany.validFrom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(inn, validFrom);
    }
}
