package ru.usb.bankrupt_stop_list_company.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.usb.bankrupt_stop_list_company.configure.Configure;
import ru.usb.bankrupt_stop_list_company.configure.TG;
import ru.usb.bankrupt_stop_list_company.model.cb.CreSlCompany;
import ru.usb.bankrupt_stop_list_company.repository.cb.CreSlCompanyRepo;
import ru.usb.bankrupt_stop_list_company.utils.Support;

import javax.persistence.EntityManager;
import java.sql.SQLException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Log4j2
@Service
public class FlowExcludeCompany {

    private final EntityManager entityManager;
    private final CreSlCompanyRepo creSlCompanyRepo;
    private final Support su;
    private final Executors executors;
    private final Configure configure;
    private final SaveCompanyExcluded saveCompanyExcluded;
    private final DeleteRecord deleteRecord;
    private final ProcedureService procedureService;

    @Autowired
    public FlowExcludeCompany(EntityManager entityManager, CreSlCompanyRepo creSlCompanyRepo, Support su,
                              Executors executors, Configure configure, SaveCompanyExcluded saveCompanyExcluded,
                              DeleteRecord deleteRecord, ProcedureService procedureService) {
        this.entityManager = entityManager;
        this.creSlCompanyRepo = creSlCompanyRepo;
        this.su = su;
        this.executors = executors;
        this.configure = configure;
        this.saveCompanyExcluded = saveCompanyExcluded;
        this.deleteRecord = deleteRecord;
        this.procedureService = procedureService;
    }

    @Transactional(value = "cbTransactionManager", readOnly = true)
    public void startFlowCompany() {

        //Установка номера Insert
        configure.setNumInsert(su.getNumInsert());

        //Получаем список записей из базы
        Stream<CreSlCompany> fTableStream = null;
        CopyOnWriteArrayList<CreSlCompany> creSlCompanyList = new CopyOnWriteArrayList<>();
        AtomicInteger lineCount = new AtomicInteger(0);

        try {
            System.gc();
            int recordCount = creSlCompanyRepo.getCount();
            log.info("{} Число записей в таблице: [cre_sl_company]={}", TG.UsbLogInfo, recordCount);
            if (recordCount == 0) {
                log.info("{} Поскольку число записей в таблице: [cre_sl_company]=0, то обработку завершаем! ->false", TG.UsbLogInfo);
                return;
            }
            fTableStream = creSlCompanyRepo.getStreamAll();
            if (!checkStream(fTableStream)) {
                log.error("{} fTableStream = creSlCompanyRepo.getStreamAll() - поток вернулся = NULL! Так быть не должно!", TG.UsbLogError);
                return;
            }

            configure.setLineCounterExcludedSync(0);
            configure.setThreadSync(0);
            //Проверяем если есть ошибка выходим
            if (configure.getMistakeSync()) {
                log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                return;
            }
            //############################################################################################################################
            log.info("{}: Запускаем процесс обработки исключаемых компаний [FlowExcludeCompany]", TG.UsbLogInfo);
            fTableStream.forEach(fTable -> {

                //Проверяем если есть ошибка выходим
                if (configure.getMistakeSync()) {
                    log.error("{}: Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.", TG.UsbLogInfo);
                    throw new RuntimeException("Найден флаг ошибки configure.getMistakeSync()=true. Выходим из процесса.");
                }

                lineCount.getAndIncrement(); //Подсчитываем число записей в файле
                log.debug("line count={}",lineCount.get());
                log.debug("{}: fTableStream:each:element:{}", TG.UsbLogDebug, fTable);

                executors.getTask(fTable, creSlCompanyList);
                entityManager.detach(fTable); //Очищаем

                if (configure.getThreadSync() >= 2000) {

                    while (configure.getThreadSync() != 0) {
                        try {
                            Thread.sleep(1000);
                            log.debug("wait=Длина  очереди:{}",configure.getThreadSync());
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    if (!creSlCompanyList.isEmpty()) {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        try {
                            saveCompanyExcluded.save(creSlCompanyList, configure.getNumInsert());
                            creSlCompanyList.clear();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }


            });
            while (configure.getThreadSync() > 0) {
                Thread.sleep(100);
            }
            if (!creSlCompanyList.isEmpty()) {
                saveCompanyExcluded.save(creSlCompanyList, configure.getNumInsert());
                creSlCompanyList.clear();
            }
            System.gc();
            //############################################################################################################################
            log.info("{}:обработано записей из CreB count={}", TG.UsbLogInfo, lineCount.get());
            log.info("Длина очереди задач:{}", configure.getThreadSync());
            log.info("{}: Останавливаем процесс обработки исключаемых компаний [FlowExcludeCompany]", TG.UsbLogInfo);
            configure.setExcludedReadySync(true);
        } catch (Exception e) {
            configure.setMistakeSync(true); //Устанавливаем, наличие ошибки
            log.error("{}:!!!!!!!!!!!!!   fTableStream.forEach(fTable  !!!!!!!!!!", TG.UsbLogError);
            log.error("{}:Произошла ошибка при работе потока чтения данных из таблицы [cre_sl_company]:{}", TG.UsbLogError, e.getMessage());
            log.error("{}:Удаляем из таблицы CRE =[SL_COMPANY_TO_INSERT] все записи с NUM_INSERT", TG.UsbLogError);
            log.debug("{}:!PrintStackTrace:", TG.UsbLogError, e);
            //Удаляем записи
            deleteRecord.deleteProcedure(configure.getNumInsert());
        } finally {
            if (fTableStream != null) {
                fTableStream.close();
            }
        }
        //Все хорошо, проверяем готовность потоков
        if (!configure.getMistakeSync() && configure.getIncludedReadySync()) {
            //дергаем процедуру
            //procedureService.insertProcedureCre("COMPANY");
        }
    }


    /**
     * Проверка, что поток не NULL
     *
     * @param fTableStream - поток
     * @return - if exist = true
     */
    public boolean checkStream(Stream<CreSlCompany> fTableStream) {
        if (fTableStream == null) {
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            log.error("!!!!!!!!!!!!!  Stream<CreSlCompany>                               !!!!!!!!!!");
            log.error("!!!!!!!!!!!!! fTableStream==null                                  !!!!!!!!!+");
            log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-");
            return false;
        }
        return true;
    }

}
