package ru.usb.bankrupt_stop_list_company.utils;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.usb.bankrupt_stop_list_company.configure.Configure;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Log4j2
@Component
public class Support {

    private final Configure configure;

    @Autowired
    public Support(Configure configure) {
        this.configure = configure;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    DateTimeFormatter formatterNumInsert = DateTimeFormatter.ofPattern("yyyyMMdd");

    public Date getDate24HfromString(String dateString){
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
            return null;
        }
    }

    public String getStrFromDate(Date date){
        return sdf.format(date);
    }


    /**
     * Получаем номер insert
     * @return - строка yyyymmdd
     */
    public int getNumInsert(){
        return Integer.parseInt(formatterNumInsert.format(LocalDateTime.now()));
    }


}
