package ru.usb.bankrupt_stop_list_company.repository.kih;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;
import ru.usb.bankrupt_stop_list_company.model.kih.KihView;

import javax.persistence.QueryHint;
import java.util.List;
import java.util.stream.Stream;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

@Repository
public interface KihRepo extends JpaRepository<KihView, Long> {

    @Query(nativeQuery = true, value = "SELECT count(*) FROM BW.ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='')")
    int getCount();

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heap size (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL FROM (SELECT INN,ADD_DATE, CASE WHEN REGEXP_LIKE(NAME,'(общество с ограниченной ответственностью|ооо|общество с органиченной ответственностью|общество с ограниченной отвественностью)','i') THEN 'ООО'  WHEN REGEXP_LIKE(NAME, '(открытое акционерное общество|оао)','i') THEN 'ОАО' WHEN REGEXP_LIKE(NAME,'(публичное акционерное общество|пао)','i') THEN 'ПАО' WHEN REGEXP_LIKE(NAME,'(закрытое акционерное общество|зао)','i') THEN 'ЗАО'  WHEN REGEXP_LIKE(NAME,'(ао)','i') THEN 'АО' ELSE NULL END as TYPE, CASE WHEN STATUS IS NULL THEN 'NOT ACTIVE' ELSE 'ACTIVE' END as NOTE, CASE WHEN (LENGTH(INN)<=0 or INN IS NULL) THEN  OGRN ELSE NULL END as OGRN, CASE WHEN INSTR(TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')),CHR(34)) > 0  THEN TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i'))||CHR(34) ELSE TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')) END as NAME, NAME as NAME_FULL FROM BW.ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='') order by INN) GROUP BY INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL")
    Stream<KihView> getStreamAll();

    /**
     * Поиск того, что запись есть в БД Киха
     * @param inn
     *
     * @return
     */
    //SELECT DISTINCT ADD_DATE as ADD_DATE, INN FROM ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='') AND (INN = '0835457887' AND ADD_DATE =  to_date('01.01.2200 00:00:00','dd.mm.yyyy hh24:mi:ss'))
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(nativeQuery = true, value = "SELECT count(*) FROM BW.ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='') AND (INN = :inn AND ADD_DATE = to_date(:addDate,'dd.mm.yyyy hh24:mi:ss'))")
    int getExistCbKih(String inn, String addDate);


//    "SELECT INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL FROM (SELECT INN,ADD_DATE, CASE WHEN REGEXP_LIKE(NAME,'(общество с ограниченной ответственностью|ооо|общество с органиченной ответственностью|общество с ограниченной отвественностью)','i') THEN 'ООО'  WHEN REGEXP_LIKE(NAME, '(открытое акционерное общество|оао)','i') THEN 'ОАО' WHEN REGEXP_LIKE(NAME,'(публичное акционерное общество|пао)','i') THEN 'ПАО' WHEN REGEXP_LIKE(NAME,'(закрытое акционерное общество|зао)','i') THEN 'ЗАО'  WHEN REGEXP_LIKE(NAME,'(ао)','i') THEN 'АО' ELSE NULL END as TYPE, CASE WHEN STATUS IS NULL THEN 'NOT ACTIVE' ELSE 'ACTIVE' END as NOTE, CASE WHEN (LENGTH(INN)<=0 or INN IS NULL) THEN  OGRN ELSE NULL END as OGRN, CASE WHEN INSTR(TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')),CHR(34)) > 0  THEN TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i'))||CHR(34) ELSE TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')) END as NAME, NAME as NAME_FULL FROM BW.ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='') order by INN) GROUP BY INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL"

    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
        // REAL
    @Query(nativeQuery = true, value = "SELECT INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL FROM (SELECT INN,ADD_DATE, CASE WHEN REGEXP_LIKE(NAME,'(общество с ограниченной ответственностью|ооо|общество с органиченной ответственностью|общество с ограниченной отвественностью)','i') THEN 'ООО'  WHEN REGEXP_LIKE(NAME, '(открытое акционерное общество|оао)','i') THEN 'ОАО' WHEN REGEXP_LIKE(NAME,'(публичное акционерное общество|пао)','i') THEN 'ПАО' WHEN REGEXP_LIKE(NAME,'(закрытое акционерное общество|зао)','i') THEN 'ЗАО'  WHEN REGEXP_LIKE(NAME,'(ао)','i') THEN 'АО' ELSE NULL END as TYPE, CASE WHEN STATUS IS NULL THEN 'NOT ACTIVE' ELSE 'ACTIVE' END as NOTE, CASE WHEN (LENGTH(INN)<=0 or INN IS NULL) THEN  OGRN ELSE NULL END as OGRN, CASE WHEN INSTR(TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')),CHR(34)) > 0  THEN TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i'))||CHR(34) ELSE TRIM(BOTH CHR(34) FROM REGEXP_REPLACE(NAME,'(общество с ограниченной ответственностью |ооо |общество с органиченной ответственностью |общество с ограниченной отвественностью |открытое акционерное общество |оао |публичное акционерное общество |пао |закрытое акционерное общество |зао | ао)','',1,0,'i')) END as NAME, NAME as NAME_FULL FROM BW.ZCLIENT_CHS_6001_VW WHERE CTG = 1 AND (NAME!='0' OR NAME!='') order by INN) GROUP BY INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL")
//    @Query(nativeQuery = true, value = "SELECT INN, ADD_DATE, TYPE, NOTE, OGRN, NAME, NAME_FULL FROM ZCLIENT_CHS_6001_VW")
    List<KihView> getListAll();

}
