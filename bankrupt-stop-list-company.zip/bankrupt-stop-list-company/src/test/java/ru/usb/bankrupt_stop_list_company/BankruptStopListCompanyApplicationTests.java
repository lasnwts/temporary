package ru.usb.bankrupt_stop_list_company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankruptStopListCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
