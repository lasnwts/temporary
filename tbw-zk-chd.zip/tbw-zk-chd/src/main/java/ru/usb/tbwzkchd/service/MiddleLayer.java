package ru.usb.tbwzkchd.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.tbwzkchd.model.OutgoingFlows;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;

@Service
public class MiddleLayer {

    @Autowired
    DbFlowService dbFlowService;

    @Autowired
    CreateJobs createJobs;

    Logger logger = LoggerFactory.getLogger(MiddleLayer.class);

    /**
     * Создание списка задач по датам
     *
     * @param date
     * @return
     */
    public List<OutgoingFlows> setJobs(Date date) {

        List<OutgoingFlows> outgoingFlowsList = new ArrayList<>();
        //1
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_MEMBERS(date)));
        //2
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_MEMBERS_STATUS(date)));
        //3
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_BUSINESS_CARD(date)));
        //4
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_CREDIT_CONTRACT_SIGN(date)));
        //5
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_CURR_CONTRACT(date)));
        //6
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_FIRST_ACC(date)));
        //7
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_MERCHANTS(date)));
        //8
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_ZP_PROJECTS(date)));
        //9
        outgoingFlowsList.add(dbFlowService.saveOutgoingFlows(createJobs.getORL_GLD_MB_OPERATIONS(date)));
        //returned
        return outgoingFlowsList;
    }

}

