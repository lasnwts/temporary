package ru.usb.tbwzkchd.model;

import io.swagger.v3.oas.annotations.media.Schema;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
@Entity
@Table(name = "chdzkflowlog")
public class ChdFlowLog {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    @Schema(description = "Дата добавления в таблицу")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputdate;

    @Schema(description = "Дата обновления")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastupdatedate;

    /**
     * Имя файла основного сообщения, имя, абсолютный путь с именем, размер
     */
    @Schema(description = "Имя файла")
    private String fileName;

    @Schema(description = "Размер файла")
    private long fileSize;

    /**
     * Сообщения об ошибках, связанное с отправкой сообщения
     * Описание, тут вербальное представление
     */
    @Schema(description = "Сообщение")
    private String message;

    /**
     * Имя потока ЦХД
     */
    @Schema(description = "Имя потока ЦХД")
    private String flowName;

    /**
     * Тип прием, отправка
     */
    @Schema(description = "Направление upload - передано из банка в ЗК. download - Получено из ЗК в Банк")
    private String direction;

    /**
     * Статус файла в логе
     */
    @Schema(description = "Статус обработки файла")
    private String status;

    public ChdFlowLog() {
    }

    public ChdFlowLog(long id, Date inputdate, Date lastupdatedate, String fileName,
                      long fileSize, String status, String message, String flowName, String direction) {
        this.id = id;
        this.inputdate = inputdate;
        this.lastupdatedate = lastupdatedate;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.status = status;
        this.message = message;
        this.flowName = flowName;
        this.direction = direction;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getInputdate() {
        return inputdate;
    }

    public void setInputdate(Date inputdate) {
        this.inputdate = inputdate;
    }

    public Date getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(Date lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    @Override
    public String toString() {
        return "ChdFlowLog{" +
                "id=" + id +
                ", inputdate=" + inputdate +
                ", lastupdatedate=" + lastupdatedate +
                ", fileName='" + fileName + '\'' +
                ", fileSize=" + fileSize +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", flowName='" + flowName + '\'' +
                ", direction='" + direction + '\'' +
                '}';
    }
}
