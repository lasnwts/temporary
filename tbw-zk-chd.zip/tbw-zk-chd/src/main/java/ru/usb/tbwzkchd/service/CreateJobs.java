package ru.usb.tbwzkchd.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.tbwzkchd.model.OutgoingFlows;
import ru.usb.tbwzkchd.utils.CUtility;

import java.util.Date;

/**
 * Класс создания задач
 *      * Имя таблицы:
 *      * -------------------------------------
 *      * ORL.ORL_GLD_MB_MEMBERS
 *      * ORL.ORL_GLD_MB_MEMBERS_STATUS
 *      * ORL.ORL_GLD_MB_BUSINESS_CARD
 *      * ORL.ORL_GLD_MB_CREDIT_CONTRACT_SIGN
 *      * ORL.ORL_GLD_MB_CURR_CONTRACT
 *      * ORL.ORL_GLD_MB_FIRST_ACC
 *      * ORL.ORL_GLD_MB_MERCHANTS
 *      * ORL.ORL_GLD_MB_ZP_PROJECTS
 *      * ORL. ORL_GLD_MB_OPERATIONS
 *      -------------------------------------
 *   "inputdate": "2023-10-16T19:16:05.410Z",
 *   "lastupdatedate": "2023-10-16T19:16:05.410Z",
 *   "status": 0,
 *   "tableName": "ORL.ORL_GLD_MB_MEMBERS",
 *   "flowName": "WF_ORL_GLD_MB_MEMBERS",
 *   "description": "PM Начисление на остаток",
 *   "fileMask": "PM_SSSS.nnnnnnn",
 *   "fileName": "pm_test2",
 *   "message": "",
 *
 *   "reportDate": "2023-10-16T19:16:05.410Z"
 *
 */
@Service
public class CreateJobs {
    Logger logger = LoggerFactory.getLogger(CreateJobs.class);
    @Autowired
    CUtility cu;

    /**
     * Подготовка Зиготы для задачи
     * @param date
     * @return
     */
    private OutgoingFlows setJob(Date date){
        OutgoingFlows outgoingFlows = new OutgoingFlows();
        //Дата отчета
        outgoingFlows.setReportDate(date);
        outgoingFlows.setReportSDate(cu.getStrDate(date));
        //Даты записи в БД
        outgoingFlows.setInputdate(new Date());
        outgoingFlows.setLastupdatedate(new Date());
        outgoingFlows.setStatus(0); //Старт
        return outgoingFlows;
    }

    /**
     * 1
     * Создание Job ORL_GLD_MB_MEMBERS
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_MEMBERS(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_MEMBERS");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_MEMBERS");
        outgoingFlows.setDescription("PM Начисление на остаток");
        outgoingFlows.setFileMask("PM_SSSS.nnnnnnn");
        return outgoingFlows;
    }

    /**
     * 2
     * Создание Job ORL.ORL_GLD_MB_MEMBERS_STATUS
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_MEMBERS_STATUS(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_MEMBERS_STATUS");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_MEMBERS_STATUS ");
        outgoingFlows.setDescription("CDB Регистрация клиентов SCA Изменение статуса клиента");
        outgoingFlows.setFileMask("CDB_SSSS.nnnnnnnn SCA_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 3
     * Создание Job ORL.ORL_GLD_MB_BUSINESS_CARD
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_BUSINESS_CARD(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_BUSINESS_CARD");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_BUSINESS_CARD");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 4
     * Создание Job ORL.ORL_GLD_MB_CREDIT_CONTRACT_SIGN
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_CREDIT_CONTRACT_SIGN(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_CREDIT_CONTRACT_SIGN");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_CREDIT_CONTRACT_SIGN");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 5
     * Создание Job ORL.ORL_GLD_MB_CURR_CONTRACT
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_CURR_CONTRACT(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_CURR_CONTRACT");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_CURR_CONTRACT");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 6
     * Создание Job ORL.ORL_GLD_MB_FIRST_ACC
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_FIRST_ACC(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_FIRST_ACC");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_FIRST_ACC");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 7
     * Создание Job ORL.ORL_GLD_MB_MERCHANTS
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_MERCHANTS(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_MERCHANTS");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_MERCHANTS");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 8
     * Создание Job ORL.ORL_GLD_MB_ZP_PROJECTS
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_ZP_PROJECTS(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_ZP_PROJECTS");
        outgoingFlows.setFlowName("WF_ORL_GLD_MB_ZP_PROJECTS");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

    /**
     * 9
     * Создание Job ORL.ORL_GLD_MB_OPERATIONS
     * @param date
     * @return
     */
    public OutgoingFlows getORL_GLD_MB_OPERATIONS(Date date){
        OutgoingFlows outgoingFlows = setJob(date);
        outgoingFlows.setTableName("ORL.ORL_GLD_MB_OPERATIONS");
        outgoingFlows.setFlowName("WF_ ORL_GLD_MB_OPERATIONS");
        outgoingFlows.setDescription("AB Передача событий для начисления бонусов");
        outgoingFlows.setFileMask("AB_SSSS.nnnnnnnn");
        return outgoingFlows;
    }

}
