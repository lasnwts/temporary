package ru.usb.tbwzkchd;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import ru.usb.tbwzkchd.configure.Configure;
import ru.usb.tbwzkchd.service.ReadyProcessJob;

@SpringBootApplication
public class TbwZkChdApplication implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(TbwZkChdApplication.class);

    @Autowired
    Configure configure;

    @Autowired
    ReadyProcessJob readyProcessJob;

    public static void main(String[] args) {
        SpringApplication.run(TbwZkChdApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI(@Value("${info.application.version:none}") String appVersion) {
        return new OpenAPI().info(new Info()
                .title("API (TBW Logger)")
                .version(appVersion)
                .description("API для канала Золотая Корона - ЦХД." +
                        "a library for OpenAPI 3 with spring boot.")
                .termsOfService("../")
                .license(new License().name("Uralsib Bank license")
                        .url("http://uralsib.ru")));
    }

    @Override
    public void run(String... args) throws Exception {

        logger.info("09.08.2023 14:45 ver. 0.0.1");
        logger.info("----------------------------------------------------------------------------------------------");
        logger.info("| Name of service        :" + configure.getAppName());
        logger.info("| Version of service     :" + configure.getAppVersion());
        logger.info("| Description of service :" + configure.getAppDescription());
        logger.info("----------------------------------------------------------------------------------------------");
    }

    /**
     * Sheduler
     */
    @Scheduled(initialDelay = 2000L, fixedDelayString = "${scheduler.delay}")
    public void ServiceJobSheduler() {
        readyProcessJob.process();
    }
}


@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "sheduling.enabled", matchIfMissing = true)
class ShedulingConfiguration {
    /**
     * https://betacode.net/11131/run-background-scheduled-tasks-in-spring
     * https://habr.com/ru/post/580062/
     */
}
