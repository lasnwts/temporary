package ru.usb.tbwzkchd.rescontroller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.tbwzkchd.model.OutgoingFlows;
import ru.usb.tbwzkchd.service.DbFlowService;
import ru.usb.tbwzkchd.service.MiddleLayer;
import ru.usb.tbwzkchd.utils.CUtility;

import java.util.List;

@RestController
@RequestMapping("/api/flow")
@Tag(name = "Контроллер для работы с таблицей Исходящие потоки (задачи на отправку)", description = "Работа с потоками на отправку")
public class DbFlows {

    Logger logger = LoggerFactory.getLogger(DbFlows.class);
    @Autowired
    DbFlowService dbService;

    @Autowired
    CUtility cUtility;

    @Autowired
    MiddleLayer middleLayer;

    /**
     * Сохранить запись в БД
     *
     * @param outgoingFlows
     * @return
     */
    @PostMapping(value = "/save")
    @Operation(summary = "Сохранить сообщение в БД.")
    public @ResponseBody ResponseEntity<?> save(@Parameter(description = "Сохраняет в БД объект, как запись")
                                                @RequestBody OutgoingFlows outgoingFlows) {
        if (outgoingFlows == null) {
            logger.error("UsbLog:Error - outgoingFlows объект не передан == NULL");
            return new ResponseEntity<>("outgoingFlows объект не передан == NULL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        try {
            dbService.saveOutgoingFlows(outgoingFlows);
            logger.info("Объект {} сохранен в таблице", outgoingFlows.toString());
            return ResponseEntity.status(HttpStatus.OK).body("Объект " + outgoingFlows.toString() + " сохранен в таблице");
        } catch (Exception e) {
            logger.error("UsbLog:Error - не удалось сохранить объект {} в таблице", outgoingFlows.toString());
            return new ResponseEntity<>("Ошибка, не удалось сохранить объект: " + outgoingFlows.toString() + " в таблице", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create/{sdate}")
    //Запрашиваем квоту на сообщения
    @Operation(summary = "Запрос на получение сообщения. Пример заполнения: messageId = df22462d-a599-4018-92a1-ae92010bf27b ")
    public ResponseEntity setJobs(@Parameter(description = "Дата в формате dd.mm.yyyy [Пример:14.10.2023]")
                                  @PathVariable("sdate") String sdate) {

        if (sdate == null) {
            logger.error("UsbLog:Error - sdate не должен быть NULL!");
            return new ResponseEntity<>("sdate не должен быть NULL, вы не передали значение date", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        logger.info("Get setJobs request date:" + sdate);

        if (!cUtility.parseDate(sdate)) {
            logger.error("UsbLog:Error - date не распарсился по шаблону dd.mm.yyyy!");
            return new ResponseEntity<>("date не распарсился по шаблону dd.mm.yyyy, вы не передали значение date", HttpStatus.INTERNAL_SERVER_ERROR);
        } else {


            List<OutgoingFlows> outgoingFlowsList = middleLayer.setJobs(cUtility.getDateFromStr(sdate));

            if (outgoingFlowsList == null) {
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                logger.error("UsbLog: List<OutgoingFlows> middleLayer.setJobs(cUtility.getDateFromStr(sdate)) == NULL!!!");
                logger.error("UsbLog: Не удалось создать задачи для ЦХД!");
                logger.error("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                return new ResponseEntity<>("Не удалось создать задачи для ЦХД. List<OutgoingFlows> middleLayer.setJobs(cUtility.getDateFromStr(sdate)) == NULL", HttpStatus.INTERNAL_SERVER_ERROR);
            }

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, "application/json")
                    .body(outgoingFlowsList);
        }
    }

}
