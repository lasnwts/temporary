package ru.usb.tbwzkchd.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.tbwzkchd.model.OutgoingFlows;
import ru.usb.tbwzkchd.repository.JpaRepoFlows;

import java.util.List;
import java.util.function.Consumer;

@Service
public class ReadyProcessJob {
    Logger logger = LoggerFactory.getLogger(ReadyProcessJob.class);

    @Autowired
    JpaRepoFlows jpaRepoFlows;

    public void process(){

        List<OutgoingFlows> outgoingFlowsList = jpaRepoFlows.getReadyStatus0();

        if (outgoingFlowsList == null){
            return;
        }

        if (outgoingFlowsList.size() == 0){
            return;
        }
        logger.info("======================================================================================================");
        logger.info("UsbLog: обнаружено {} записей в статусе - поток не готов [ready_flow_status = 0]", outgoingFlowsList.size());
        logger.info("======================================================================================================");

        outgoingFlowsList.forEach(new Consumer<OutgoingFlows>() {
            @Override
            public void accept(OutgoingFlows outgoingFlows) {
                logger.info("UsbLog:{}", outgoingFlows.toString());
            }
        });
        logger.info("======================================================================================================");

    }
}
