package ru.usb.tbwzkchd.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Configuration
public class CUtility {

    /**
     * формат даты-времени
     */
    LocalDate date;
    DateTimeFormatter shortDateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    Logger logger = LoggerFactory.getLogger(CUtility.class);

    /**
     * Обертка над значением null в строке
     *
     * @param line - переданная строка
     * @return - строка после проверки на NULL.
     */
    public String getWrapNull(String line) {
        if (line == null) {
            return "";
        } else {
            return line.trim();
        }
    }

    /**
     * @param sDate - строковое представление даты
     * @return True (истина) дата соответствует формату даты
     * False (ложь) - дата не соответствует заданному формату даты dd.MM.yyyy
     */
    public boolean parseDate(String sDate) {
        try {
            date = LocalDate.parse(sDate, shortDateFormat);
            return true;
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = {}  не соответствует формату ::{}", sDate, shortDateFormat.toString());
            return false;
        }
    }


    /**
     * Преобразование строковой даты типа "dd.MM.yyyy" в LocalDate
     *
     * @param sDate - строковый вид даты
     * @return LocalDate - тип даты
     */
    public LocalDate getDate(String sDate) {
        try {
            return LocalDate.parse(sDate, shortDateFormat);
        } catch (DateTimeException dateTimeException) {
            logger.error("Дата = {}  не соответствует формату ::{}", sDate, shortDateFormat.toString());
            return null;
        }
    }


    /**
     * Проеобразование между локальной датой LocalDate в Sql.Date
     *
     * @param ldate
     * @return
     */
    public Date getSqlDate(LocalDate ldate) {
        try {
            Date sqlDate = Date.valueOf(ldate);
            return sqlDate;
        } catch (Exception e) {
            logger.error("Дата = {} не соответствует формату ::{}", ldate, shortDateFormat.toString());
            return null;
        }
    }

    /**
     * Вовзращает строку в формате dd.mm.yyyy из Даты
     * @param date - Дата
     * @return - строка
     */
    public String getStrDate(java.util.Date date){
        if (date == null){
            return null;
        }
        return sdf.format(date);
    }


    /**
     * Возвращает дату
     * @param sDate
     * @return
     */
    public java.util.Date getDateFromStr(String sDate){
        if (sDate==null){
            return new java.util.Date();
        }
        try {
            return sdf.parse(sDate);
        } catch (ParseException e) {
            logger.error("Дата = {} не соответствует формату :dd.mm.yyyy:", sDate);
            logger.error("Ошибка = ::{}", e.getMessage());
            e.printStackTrace();
            return new java.util.Date();
        }
    }

}
