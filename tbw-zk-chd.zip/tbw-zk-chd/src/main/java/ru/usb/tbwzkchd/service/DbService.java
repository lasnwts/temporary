package ru.usb.tbwzkchd.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.tbwzkchd.configure.Configure;
import ru.usb.tbwzkchd.model.ChdFlowLog;
import ru.usb.tbwzkchd.repository.JPaRepoChdFlowLog;

/**
 * Сервис для работы с БД
 */
@Service
public class DbService {
    Logger logger = LoggerFactory.getLogger(DbService.class);
    @Autowired
    Configure configure;
    @Autowired
    JPaRepoChdFlowLog jPaRepoChdFlowLog;

    /**
     * Сохраняем запись в БД
     *
     * @param chdFlowLog
     */
    public void saveChdFlowLog(ChdFlowLog chdFlowLog) {
        if (chdFlowLog == null) {
            logger.error("UsbLog: Передан пустой chdFlowLog (NULL) объект для записи в БД");
            return;
        }

        try {
            jPaRepoChdFlowLog.saveAndFlush(chdFlowLog);
        } catch (Exception exception){
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Возникла ошибка сохранения сообщения в БД");
            logger.error("UsbLog: Сообщение:{}", chdFlowLog.toString());
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }

    }



}
