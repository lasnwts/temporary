package ru.usb.tbwzkchd.rescontroller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.usb.tbwzkchd.model.ChdFlowLog;
import ru.usb.tbwzkchd.service.DbService;

@RestController
@RequestMapping("/api/db")
@Tag(name = "Контроллер для работы с таблицей БД", description = "Работа с БД")
public class DbController {

    Logger logger = LoggerFactory.getLogger(DbController.class);
    @Autowired
    DbService dbService;

    /**
     * Сохранить запись в БД
     * @param chdFlowLog
     * @return
     */
    @PostMapping(value = "/save")
    @Operation(summary = "Сохранить сообщение в БД.")
    public @ResponseBody ResponseEntity<?> save(@Parameter(description = "Сохраняет в БД объект, как запись")
                                                @RequestBody ChdFlowLog chdFlowLog) {
        if (chdFlowLog == null) {
            logger.error("UsbLog:Error - ChdFlowLog объект не передан == NULL");
            return new ResponseEntity<>("ChdFlowLog объект не передан == NULL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        try {
            dbService.saveChdFlowLog(chdFlowLog);
            logger.info("Объект {} сохранен в таблице", chdFlowLog.toString());
            return ResponseEntity.status(HttpStatus.OK).body("Объект " + chdFlowLog.toString() + " сохранен в таблице");
        } catch (Exception e) {
            logger.error("UsbLog:Error - не удалось сохранить объект {} в таблице", chdFlowLog.toString());
            return new ResponseEntity<>("Ошибка, не удалось сохранить объект: " + chdFlowLog.toString() + " в таблице", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
