package ru.usb.tbwzkchd.model;

import io.swagger.v3.oas.annotations.media.Schema;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * ORL.ORL_GLD_MB_MEMBERS	WF_ORL_GLD_MB_MEMBERS	PM Начисление на остаток	PM_SSSS.nnnnnnn
 * ORL.ORL_GLD_MB_MEMBERS_STATUS	WF_ORL_GLD_MB_MEMBERS_STATUS	CDB Регистрация клиентов
 * SCA Изменение статуса клиента	CDB_SSSS.nnnnnnnn
 * SCA_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_BUSINESS_CARD	WF_ORL_GLD_MB_BUSINESS_CARD	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_CREDIT_CONTRACT_SIGN	WF_ORL_GLD_MB_CREDIT_CONTRACT_SIGN	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_CURR_CONTRACT	WF_ORL_GLD_MB_CURR_CONTRACT	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_FIRST_ACC	WF_ORL_GLD_MB_FIRST_ACC	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_MERCHANTS	WF_ORL_GLD_MB_MERCHANTS	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL.ORL_GLD_MB_ZP_PROJECTS	WF_ORL_GLD_MB_ZP_PROJECTS	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 * ORL. ORL_GLD_MB_OPERATIONS	WF_ ORL_GLD_MB_OPERATIONS	AB Передача событий для начисления бонусов	AB_SSSS.nnnnnnnn
 */
@Entity
@Table(name = "outgoingflows")
public class OutgoingFlows {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private long id;

    @Schema(description = "Дата добавления в таблицу")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inputdate;

    @Schema(description = "Дата обновления")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastupdatedate;

    /**
     * Табличное описание
     */

    /**
     * Статус отправки
     * 0 - не отправлен
     * 1- отправлен
     * 2 - ошибка
     */
    private int status;

    /**
     * Имя таблицы:
     * -------------------------------------
     * ORL.ORL_GLD_MB_MEMBERS
     * ORL.ORL_GLD_MB_MEMBERS_STATUS
     * ORL.ORL_GLD_MB_BUSINESS_CARD
     * ORL.ORL_GLD_MB_CREDIT_CONTRACT_SIGN
     * ORL.ORL_GLD_MB_CURR_CONTRACT
     * ORL.ORL_GLD_MB_FIRST_ACC
     * ORL.ORL_GLD_MB_MERCHANTS
     * ORL.ORL_GLD_MB_ZP_PROJECTS
     * ORL. ORL_GLD_MB_OPERATIONS
     */
    private String tableName;

    /**
     * Имя потока
     * --------------------------------------
     * WF_ORL_GLD_MB_MEMBERS
     * WF_ORL_GLD_MB_MEMBERS_STATUS
     * WF_ORL_GLD_MB_BUSINESS_CARD
     * WF_ORL_GLD_MB_CREDIT_CONTRACT_SIGN
     * WF_ORL_GLD_MB_CURR_CONTRACT
     * WF_ORL_GLD_MB_FIRST_ACC
     * WF_ORL_GLD_MB_MERCHANTS
     * WF_ORL_GLD_MB_ZP_PROJECTS
     * WF_ ORL_GLD_MB_OPERATIONS
     */
    private String flowName;

    /**
     * Описание потока:
     * ------------------------------------
     * PM Начисление на остаток
     * CDB Регистрация клиентов
     * SCA Изменение статуса клиента
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     * AB Передача событий для начисления бонусов
     */

    private String description;

    /**
     * Маска файла для отправки
     * ----------------------------------------
     * PM_SSSS.nnnnnnn
     * CDB_SSSS.nnnnnnnn
     * SCA_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     * AB_SSSS.nnnnnnnn
     */
    private String fileMask;

    /**
     * Имя файла сформированного для отправки
     */
    private String fileName;

    /**
     * Протокол отправки
     */
    private String message;

    /**
     * Дата отправки для ЦХД
     * Формат dd.mm.yyyy
     */
    private String reportSDate;

    /**
     * Дата отправки для ЦХД
     */
    private Date reportDate;

    /**
     * Статус отправки
     * processed - выполнен или завершен
     * error - ошибка
     * created -
     *
     */
    @Schema(description = "Статус вербальный")
    private String statusVerb;

    /**
     * Статус готовности отправки
     * true - поток готов
     * error - поток не готов
     */
    @Schema(description = "Статус готовности потока")
    private boolean readyFlowStatus;

    /**
     * Дата и время обновления информации по статусу готовности
     */
    @Schema(description = "Дата и время запроса статуса готовности")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFlowStatus;


    public OutgoingFlows() {
    }

    public OutgoingFlows(long id, Date inputdate, Date lastupdatedate, int status, String tableName,
                         String flowName, String description, String fileMask, String fileName,
                         String message, String reportSDate, Date reportDate) {
        this.id = id;
        this.inputdate = inputdate;
        this.lastupdatedate = lastupdatedate;
        this.status = status;
        this.tableName = tableName;
        this.flowName = flowName;
        this.description = description;
        this.fileMask = fileMask;
        this.fileName = fileName;
        this.message = message;
        this.reportSDate = reportSDate;
        this.reportDate = reportDate;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getInputdate() {
        return inputdate;
    }

    public void setInputdate(Date inputdate) {
        this.inputdate = inputdate;
    }

    public Date getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(Date lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileMask() {
        return fileMask;
    }

    public void setFileMask(String fileMask) {
        this.fileMask = fileMask;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReportSDate() {
        return reportSDate;
    }

    public void setReportSDate(String reportSDate) {
        this.reportSDate = reportSDate;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    @Override
    public String toString() {
        return "OutgoingFlows{" +
                "id=" + id +
                ", inputdate=" + inputdate +
                ", lastupdatedate=" + lastupdatedate +
                ", status=" + status +
                ", tableName='" + tableName + '\'' +
                ", flowName='" + flowName + '\'' +
                ", description='" + description + '\'' +
                ", fileMask='" + fileMask + '\'' +
                ", fileName='" + fileName + '\'' +
                ", message='" + message + '\'' +
                ", reportSDate='" + reportSDate + '\'' +
                ", reportDate=" + reportDate +
                '}';
    }
}
