package ru.usb.tbwzkchd.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.usb.tbwzkchd.configure.Configure;
import ru.usb.tbwzkchd.model.OutgoingFlows;
import ru.usb.tbwzkchd.repository.JpaRepoFlows;
import ru.usb.tbwzkchd.utils.CUtility;

import java.util.Date;
import java.util.List;

@Service
public class DbFlowService {

    Logger logger = LoggerFactory.getLogger(DbFlowService.class);
    @Autowired
    Configure configure;
    @Autowired
    JpaRepoFlows jpaRepoFlows;
    @Autowired
    CUtility cu;




    /**
     * Сохраняем запись в БД
     *
     * @param outgoingFlows
     */
    public OutgoingFlows saveOutgoingFlows(OutgoingFlows outgoingFlows) {

        if (outgoingFlows == null) {
            logger.error("UsbLog: Передан пустой outgoingFlows (NULL) объект для записи в БД");
            return null;
        }

        if (outgoingFlows.getReportDate()==null & outgoingFlows.getReportSDate()==null){
            outgoingFlows.setReportDate(new Date());
            outgoingFlows.setReportSDate(cu.getStrDate(new Date()));
        }

        if (outgoingFlows.getReportDate()==null){
            outgoingFlows.setReportDate(cu.getDateFromStr(outgoingFlows.getReportSDate()));
        }

        if (outgoingFlows.getReportSDate()==null){
            outgoingFlows.setReportSDate(cu.getStrDate(outgoingFlows.getReportDate()));
        }

        /**
         * Проверка, что такой записи нет в таблице
         */
        if (getSize(outgoingFlows)>0){
            logger.info("Уже существует запись в таблице с параметрами:{}", outgoingFlows.toString());
            return null;
        }

        try {
            jpaRepoFlows.saveAndFlush(outgoingFlows);
            return outgoingFlows;
        } catch (Exception exception){
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            logger.error("UsbLog: Возникла ошибка сохранения сообщения в БД");
            logger.error("UsbLog: Сообщение:{}", outgoingFlows.toString());
            logger.error("UsbLog: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return null;
        }

    }

    /**
     * Поиск уже существующих записей
     * @param outgoingFlows
     * @return
     */
    public List<OutgoingFlows> getStatTableDate(OutgoingFlows outgoingFlows){
        return jpaRepoFlows.getStatusDateTable(outgoingFlows.getTableName(),outgoingFlows.getStatus(), outgoingFlows.getReportSDate());
    }

    /**
     * Поиск уже существующих записей
     * @param outgoingFlows
     * @return
     */
    public int getSize(OutgoingFlows outgoingFlows){
        return jpaRepoFlows.getStatusDateTable(outgoingFlows.getTableName(),outgoingFlows.getStatus(), outgoingFlows.getReportSDate()).size();
    }

    /**
     * Список статусов с 0 статусом готовности потока
     */
    public List<OutgoingFlows> getReadyStatus0(){
        return jpaRepoFlows.getReadyStatus0();
    }
}
