package ru.usb.tbwzkchd.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import ru.usb.tbwzkchd.model.ChdFlowLog;
import ru.usb.tbwzkchd.model.OutgoingFlows;

import javax.persistence.QueryHint;
import java.util.List;

import static org.hibernate.annotations.QueryHints.READ_ONLY;
import static org.hibernate.jpa.QueryHints.HINT_CACHEABLE;
import static org.hibernate.jpa.QueryHints.HINT_FETCH_SIZE;

public interface JPaRepoChdFlowLog  extends JpaRepository<ChdFlowLog, Long> {


    /********************************************************************************************************************************************
     * Поиск по Status - отправки
     *******************************************************************************************************************************************/
    @QueryHints(value = {
            @QueryHint(name = HINT_FETCH_SIZE, value = "1000"), //Здесь можно изменять загрузку памяти heapsize (меньше значение, меньше потребление).
            @QueryHint(name = HINT_CACHEABLE, value = "false"),
            @QueryHint(name = READ_ONLY, value = "true")
    })
    @Query(value = "select id, description, file_mask, file_name, flow_name, inputdate, lastupdatedate, message, report_date, report_date, reportsdate, status, table_name, date_flow_status,ready_flow_status, status_verb from outgoingflows where ready_flow_status = 0", nativeQuery = true) //тест
    List<OutgoingFlows> getReadyStatus0();

}
